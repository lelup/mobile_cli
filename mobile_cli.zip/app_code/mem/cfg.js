let cfg = {
    server: '172.104.167.189'
};

cfg.rootUrl = `http://${cfg.server}:3002`;

export default cfg;