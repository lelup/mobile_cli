const InitialState = require('./homeInitialState').default;
const {
    HOME_DATA_LOADING
} = require('../../lib/constants').default;

const initialState = new InitialState;
export default function homeReducer(state = initialState, action) {
    if (!(state instanceof InitialState)) return initialState.mergeDeep(state);

    switch (action.type) {
        case HOME_DATA_LOADING: {
            let nextState = state.set('isHomeLoading', true);

            return nextState;
        }
        default:
            return state
    }
}
