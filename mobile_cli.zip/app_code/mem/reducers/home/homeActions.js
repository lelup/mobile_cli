const {
    HOME_DATA_LOADING,
} = require('../../lib/constants').default;

export function loadHomeDataRequest() {
    return {
        type: HOME_DATA_LOADING,
        payload: null
    }
}

export function fetchHomeData() {
    return (dispatch) => {
        dispatch(loadHomeDataRequest());
    }
}