/**
 * # globalActions.js
 * 
 * Actions that are global in nature
 */
'use strict';

/**
 * ## Imports
 * 
 * The actions supported
 */
const {
  LAUNCH_APP
} = require('../../lib/constants').default;

import log from '../../lib/logUtil';
export function lauchApp(data) {
  return {
      type: LAUNCH_APP,
      payload: data
  }
}