'use strict';

import {Record} from 'immutable';

var InitialState = Record({
  currentUser: new (Record({
    userID : null
  }))
});

export default InitialState;
