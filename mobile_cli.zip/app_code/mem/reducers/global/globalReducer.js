'use strict';

const {
  LOGIN_SUCCESS,
} = require('../../lib/constants').default;

import InitialState from './globalInitialState';
import log from '../../lib/logUtil';

const initialState = new InitialState;

export default function globalReducer(state = initialState, action) {
  if (!(state instanceof InitialState)) return initialState.merge(state);

  switch (action.type) {

    case LOGIN_SUCCESS: {
      let newState = state;
          console.log('==========> payload global', action.payload);
      return newState;
    }

  }

  return state;
}
