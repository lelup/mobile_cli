import home from './home/homeReducer';
import user from './user/userReducer';
import global from './global/globalReducer';
import alert from './alert/alertReducer';

import { combineReducers } from 'redux';

const rootReducer = combineReducers({
    home,
    user,
    global,
    alert

});

export default rootReducer;