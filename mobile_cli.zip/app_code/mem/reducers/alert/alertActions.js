const {
    ON_ALERT_FIELD_CHANGE
} = require('../../lib/constants').default;

export function onAlertFieldChange(field, value) {
    return {
        type: ON_ALERT_FIELD_CHANGE,
        payload: {field: field, value: value}
    };
}