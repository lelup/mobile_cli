import { Record } from 'immutable';

let InitialState = Record ({
    isHomeLoading: false,
    alertList: []
});

export default InitialState;