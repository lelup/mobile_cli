const InitialState = require('./alertInitialState').default;
const {
    HOME_DATA_LOADING,
    LOGIN_SUCCESS,
    ON_ALERT_FIELD_CHANGE
} = require('../../lib/constants').default;

import log from '../../lib/logUtil';
const initialState = new InitialState;
export default function alertReducer(state = initialState, action) {
    if (!(state instanceof InitialState)) return initialState.mergeDeep(state);

    switch (action.type) {
        case ON_ALERT_FIELD_CHANGE: {
            const { field, value } = action.payload;
            let nextState = state.set(field, value);
            return nextState;
        }

        case LOGIN_SUCCESS: {
            let data = action.payload;
            let alertList = data.inbox;
            return nexState =  state.set('alertList', alertList);
        }
        default:
            return state
    }
}
