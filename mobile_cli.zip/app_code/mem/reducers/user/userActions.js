const {
    LOGIN_REQUEST,
    LOGIN_SUCCESS,
    LOGIN_FAILURE,
    ALL_EQUIPMENTS_REQUEST,
    ALL_EQUIPMENTS_SUCCESS,
    ALL_EQUIPMENTS_FAILURE,
    ALL_OPERATION_HISTORY_REQUEST,
    ALL_OPERATION_HISTORY_SUCCESS,
    ALL_OPERATION_HISTORY_FAILURE,
    ALL_REPAIR_HISTORY_REQUEST,
    ALL_REPAIR_HISTORY_SUCCESS,
    ALL_REPAIR_HISTORY_FAILURE,
    ON_USER_FIELD_CHANGE,
    ON_USER_ALL_FIELD_CHANGE,
    ALL_SPARE_PART_REQUEST,
    ALL_SPARE_PART_SUCCESS,
    ALL_SPARE_PART_FAILURE,
} = require('../../lib/constants').default;
import log from '../../lib/logUtil';
import userApi from '../../lib/userApi';

export function onUserFieldChange(field, value) {
    return {
        type: ON_USER_FIELD_CHANGE,
        payload: {field: field, value: value}
    };
}

export function onUserAllFieldChange(value) {
    return {
        type: ON_USER_ALL_FIELD_CHANGE,
        payload: { value }
    };
}

export function loginRequest() {
    return {
        type: LOGIN_REQUEST,
        payload: null
    }
}

export function loginSuccess(payload) {
    return {
        type: LOGIN_SUCCESS,
        payload: payload
    };
}

export function loginFailure() {
    return {
        type: LOGIN_FAILURE,
        payload: null
    };
}

export function userLogin(dto) {

    return dispatch => {
        dispatch(loginRequest());
        return userApi.Login(dto)
            .then( res => {
                log.info('userActions.userLogin res ', res);
                if (res.status == 200) {
                    log.info('userActions.userLogin res.status == 200 ', res);
                    dispatch(loginSuccess(res.data));
                } else {
                    log.info('userActions.userLogin error ', res);
                    dispatch(loginFailure());
                }
                return res;
            });
    };
}


export function allEquipmentsRequest() {
    return {
        type: ALL_EQUIPMENTS_REQUEST,
        payload: null
    }
}

export function allEquipmentsSuccess(payload) {
    return {
        type: ALL_EQUIPMENTS_SUCCESS,
        payload: payload
    };
}

export function allEquipmentsFailure() {
    return {
        type: ALL_EQUIPMENTS_FAILURE,
        payload: null
    };
}

export function getAllEquipments(dto) {

    return dispatch => {
        dispatch(allEquipmentsRequest());
        return userApi.getAllEquipments(dto)
            .then( res => {
                log.info('allEquipmentRequest res ', res);
                if (res.status == 200) {
                    log.info('allEquipmentRequest res.status == 200 ', res);
                    dispatch(allEquipmentsSuccess(res.data));
                } else {
                    log.info('allEquipmentRequest error ', res);
                    dispatch(allEquipmentsFailure());
                }
                return res;
            });
    };
}


export function allOperationHistoryRequest() {
    return {
        type: ALL_OPERATION_HISTORY_REQUEST,
        payload: null
    }
}

export function allOperationHistorySuccess(payload) {
    return {
        type: ALL_OPERATION_HISTORY_SUCCESS,
        payload: payload
    };
}

export function allOperationHistoryFailure() {
    return {
        type: ALL_OPERATION_HISTORY_FAILURE,
        payload: null
    };
}

export function getAllOperationHistory(dto) {

    return dispatch => {
        dispatch(allOperationHistoryRequest());
        return userApi.getAllOperationHistory(dto)
            .then( res => {
                log.info('getAllOperationHistory res ', res);
                if (res.status == 200) {
                    log.info('getAllOperationHistory res.status == 200 ', res);
                    dispatch(allOperationHistorySuccess(res.data));
                } else {
                    log.info('getAllOperationHistory error ', res);
                    dispatch(allOperationHistoryFailure());
                }
                return res;
            });
    };
}


export function allRepairHistoryRequest() {
    return {
        type: ALL_REPAIR_HISTORY_REQUEST,
        payload: null
    }
}

export function allRepairHistorySuccess(payload) {
    return {
        type: ALL_REPAIR_HISTORY_SUCCESS,
        payload: payload
    };
}

export function allRepairHistoryFailure() {
    return {
        type: ALL_REPAIR_HISTORY_FAILURE,
        payload: null
    };
}

export function getAllRepairHistory(dto) {

    return dispatch => {
        dispatch(allRepairHistoryRequest());
        return userApi.getAllRepairHistory(dto)
            .then( res => {
                log.info('getAllRepairHistory res ', res);
                if (res.status == 200) {
                    log.info('getAllRepairHistory res.status == 200 ', res);
                    dispatch(allRepairHistorySuccess(res.data));
                } else {
                    log.info('getAllRepairHistory error ', res);
                    dispatch(allRepairHistoryFailure());
                }
                return res;
            });
    };
}


export function allSparepartRequest() {
    return {
        type: ALL_SPARE_PART_REQUEST,
        payload: null
    }
}

export function allSparepartSuccess(payload) {
    return {
        type: ALL_SPARE_PART_SUCCESS,
        payload: payload
    };
}

export function allSparepartFailure() {
    return {
        type: ALL_SPARE_PART_FAILURE,
        payload: null
    };
}

export function getAllSparepart(dto) {

    return dispatch => {
        dispatch(allSparepartRequest());
        return userApi.getAllSparepart(dto)
            .then( res => {
                log.info('getAllSparepart res ', res);
                if (res.status == 200) {
                    log.info('getAllSparepart res.status == 200 ', res);
                    dispatch(allSparepartSuccess(res.data));
                } else {
                    log.info('getAllSparepart error ', res);
                    dispatch(allSparepartFailure());
                }
                return res;
            });
    };
}

