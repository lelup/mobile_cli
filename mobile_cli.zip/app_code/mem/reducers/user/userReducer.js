const InitialState = require('./userInitialState').default;
const {
    ON_USER_FIELD_CHANGE,
    ON_USER_ALL_FIELD_CHANGE,
    LOGIN_REQUEST,
    LOGIN_SUCCESS,
    LOGIN_FAILURE,
    ALL_EQUIPMENTS_REQUEST,
    ALL_EQUIPMENTS_SUCCESS,
    ALL_EQUIPMENTS_FAILURE,
    ALL_OPERATION_HISTORY_REQUEST,
    ALL_OPERATION_HISTORY_SUCCESS,
    ALL_OPERATION_HISTORY_FAILURE,
    ALL_REPAIR_HISTORY_REQUEST,
    ALL_REPAIR_HISTORY_SUCCESS,
    ALL_REPAIR_HISTORY_FAILURE,
    ALL_SPARE_PART_REQUEST,
    ALL_SPARE_PART_SUCCESS,
    ALL_SPARE_PART_FAILURE,
} = require('../../lib/constants').default;

import log from '../../lib/logUtil';
const initialState = new InitialState;
export default function userReducer(state = initialState, action) {
    if (!(state instanceof InitialState)) return initialState.mergeDeep(state);

    switch (action.type) {
        case ON_USER_FIELD_CHANGE: {
            const { field, value } = action.payload;
            let nextState = state.set(field, value);
            return nextState;
        }

        case ON_USER_ALL_FIELD_CHANGE: {
            let payload  = action.payload;
            let nextState = state.set('code', payload.code)
                .set('userID', payload.userID)
                .set('address', payload.address)
                .set('email', payload.email)
                .set('firstName', payload.firstName)
                .set('lastName', payload.lastName)
                .set('avatar', payload.avatar)
                .set('phone', payload.phone)
                .set('birthday', payload.birthday)
                .set('sex', payload.sex)
                .set('token', payload.token)
                .set('status', payload.status);
            return nextState;
        }

        case LOGIN_REQUEST: {
            let nextState = state.set('isLoginRequest', true);
            return nextState;
        }
        case LOGIN_SUCCESS: {
            let data = action.payload;

                let code = data.code;
                let userID = data.id;
                let address = data.address;
                let email = data.email;
                let firstName =  data.lastName;
                let lastName = data.firstName;
                let avatar = data.img;
                let phone = data.phone;
                let birthday = data.dateOfBirth;
                let sex = data.sex;
                let token = data.token;
                let status = data.status;

            let nextState = state.set('isLoginRequest', false)
                .set('code', code)
                .set('userID', userID)
                .set('address', address)
                .set('email', email)
                .set('firstName', firstName)
                .set('lastName', lastName)
                .set('avatar', avatar)
                .set('phone', phone)
                .set('birthday', birthday)
                .set('sex', sex)
                .set('token', token)
                .set('status', status);
            return nextState;
        }
        case LOGIN_FAILURE: {
            let nextState = state.set('isLoginRequest', false);
            return nextState;
        }

        case ALL_EQUIPMENTS_REQUEST : {
            let nextState =  state.set('isAllEquipments', true);
            return nextState;
        }

        case ALL_EQUIPMENTS_FAILURE : {
            let nextState =  state.set('isAllEquipments', false);
            return nextState;
        }

        case ALL_EQUIPMENTS_SUCCESS : {
            let data = action.payload;
            let nextState =  state.set('isAllEquipments', false)
                                  .set('listAllEquipments', data);
            return nextState;
        }

        case ALL_OPERATION_HISTORY_REQUEST : {
            let nextState =  state.set('isAllOperationHistory', true);
            return nextState;
        }

        case ALL_OPERATION_HISTORY_FAILURE : {
            let nextState =  state.set('isAllOperationHistory', false);
            return nextState;
        }

        case ALL_OPERATION_HISTORY_SUCCESS : {
            let data = action.payload;
            let nextState =  state.set('isAllOperationHistory', false)
                                  .set('listAllOperationHistory', data);
            return nextState;
        }

        case ALL_REPAIR_HISTORY_REQUEST : {
            let nextState =  state.set('isAllRepairHistory', true);
            return nextState;
        }

        case ALL_REPAIR_HISTORY_FAILURE : {
            let nextState =  state.set('isAllRepairHistory', false);
            return nextState;
        }

        case ALL_REPAIR_HISTORY_SUCCESS : {
            let data = action.payload;
            let nextState =  state.set('isAllRepairHistory', false)
                .set('listAllRepairHistory', data);
            return nextState;
        }

        case ALL_SPARE_PART_REQUEST : {
            let nextState =  state.set('isAllSparePart', true);
            return nextState;
        }

        case ALL_SPARE_PART_FAILURE : {
            let nextState =  state.set('isAllSparePart', false);
            return nextState;
        }

        case ALL_SPARE_PART_SUCCESS : {
            let data = action.payload;
            let listInputSparePart = data.filter((e) => {
                return e.grgo == 'GR'
            });

            let listOutputSparePart = data.filter((e) => {
                return e.grgo == 'GO'
            });

            let nextState =  state.set('isAllSparePart', false)
                .set('listInputSparePart', listInputSparePart)
                .set('listOutputSparePart', listOutputSparePart);
            return nextState;
        }

        default:
            return state
    }
}
