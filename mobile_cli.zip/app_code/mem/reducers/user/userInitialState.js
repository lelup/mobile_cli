import { Record } from 'immutable';

let InitialState = Record ({
    isLoginRequest: false,
    code: '',
    userID: '',
    address: '',
    email: '',
    firstName: '',
    lastName: '',
    avatar: '',
    phone: '',
    birthday: '',
    sex: undefined,
    token: '',
    status: undefined,
    isAllEquipments: false,
    listAllEquipments: [],
    isAllOperationHistory: false,
    listAllOperationHistory: [],
    isAllRepairHistory: false,
    listAllRepairHistory: [],
    isAllSparePart: false,
    listInputSparePart: [],
    listOutputSparePart: []
});

export default InitialState;