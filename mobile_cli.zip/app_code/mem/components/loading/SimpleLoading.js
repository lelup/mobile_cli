import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    ActivityIndicator
} from 'react-native';

import gui from '../../lib/gui';
class SimpleLoading extends Component {

    render() {
        let {color, size} = this.props;
        return (
            <View style={styles.viewLoading}>
                <ActivityIndicator color={color} size={size}/>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    viewLoading: {
        position: 'absolute',
        top: gui.screenHeight/2 - 10,
        left: gui.screenWidth/2 - 10
    }
});

export default SimpleLoading;