'use strict';
import React, {Component} from 'react';

import {View, Text, StyleSheet, TouchableHighlight} from 'react-native';
import gui from '../../lib/gui';
import glyphMap from './FontAwesome5.json';

import { createIconSet } from 'react-native-vector-icons';

let Icon = createIconSet(glyphMap, 'Font Awesome 5 Solid', 'FontAwesomeSolid.ttf');

class FontAwesomeSolid extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let { iconProps, mainProps, color, name, size } = this.props;
        return(
            <View style={[styles.container, mainProps]} >
                <Icon color={color||gui.mainColor} name={name} size={size||22} {...iconProps} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'center',
        padding: 0
    },
    touchable: {
        overflow: 'hidden',
    },
    icon: {
        marginRight: 10,
    },
    text: {
        fontSize: 17,
        color:gui.mainColor,
        fontWeight: '600',
        backgroundColor: 'transparent',
        paddingLeft: 10
    }
});

FontAwesomeSolid.Icon = Icon;

export default FontAwesomeSolid;

