// Import some code we need
import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

import {Actions} from 'react-native-router-flux';

import gui from '../../lib/gui';

class SectionHeader extends Component {
    render() {
        let mainStyle = this.props.style;
        return (
            <View style={[styles.customPageHeader, mainStyle]}>
                <TouchableOpacity onPress={this._onBack.bind(this)}
                                  style={styles.viewBackStyle}
                >
                    <Ionicons name="ios-arrow-back" color={'#fff'} size={28}/>
                </TouchableOpacity>
                <View style={styles.customPageTitle}>
                    <Text style={styles.customPageTitleText}>
                        {this.props.headerTitle}
                    </Text>
                </View>
                <View style={styles.viewRightHeader}>
                    <Text style={styles.customRightTitleText}>
                        {this.props.rightTitle}
                    </Text>
                </View>
            </View>
        );
    }
    _onBack () {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: gui.navBarHeight,
        width: gui.screenWidth
    },
    customPageTitle: {
        height: gui.navBarHeight,
        width: gui.screenWidth - 180,
        justifyContent: 'center',
        alignItems: 'center'
    },
    customPageTitleText: {
        color: '#fff',
        fontSize: 17,
        fontWeight: '600',
        textAlign: 'center',
        marginTop: gui.marginTop
    },
    customRightTitleText: {
        color: '#fff',
        fontSize: 17,
        textAlign: 'center',
        marginTop: gui.marginTop
    },
    viewBackStyle: {
        height: gui.navBarHeight,
        width: 90,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingTop: gui.marginTop,
        paddingLeft: 22
    },
    viewRightHeader: {
        height: gui.navBarHeight,
        width: 90,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16
    }
});

export default SectionHeader;
