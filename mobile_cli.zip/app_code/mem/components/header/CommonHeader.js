import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import gui from '../../lib/gui';

class CommonHeader extends Component {
    render() {
        let mainStyle = this.props.style;
        return (
            <View style={[styles.customPageHeader, mainStyle]}>
                <View style={styles.viewBackStyle} />
                <View style={styles.customPageTitle}>
                    <Text style={styles.customPageTitleText}>
                        {this.props.headerTitle}
                    </Text>
                </View>
                <View style={{height: gui.navBarHeight, width: 55}}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: gui.navBarHeight,
        width: gui.screenWidth
    },
    customPageTitle: {
        height: gui.navBarHeight,
        width: gui.screenWidth - 110,
        justifyContent: 'center',
        alignItems: 'center'
    },
    customPageTitleText: {
        color: '#fff',
        fontSize: 17,
        fontWeight: '600',
        textAlign: 'center',
        marginTop: gui.marginTop
    },
    viewBackStyle: {
        height: gui.navBarHeight,
        width: 55,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingTop: gui.marginTop,
        paddingLeft: 22
    }
});

export default CommonHeader;
