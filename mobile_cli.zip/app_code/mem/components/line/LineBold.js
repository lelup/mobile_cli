import React, {Component} from 'react';
import {
    Text,
    View,
    StyleSheet

} from 'react-native';
import gui from '../../lib/gui';
class LineBold extends Component {

    render(){
        let mstyle = this.props.style || {};
        return(
            <View style={[styles.headerSeparate, mstyle]}></View>
        );
    }
}

const styles = StyleSheet.create({
    headerSeparate: {
        width: gui.screenWidth,
        height: 8,
        backgroundColor: 'rgba(235,235,235,1)',
    },

});

export default LineBold;