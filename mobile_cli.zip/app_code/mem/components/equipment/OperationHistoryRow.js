import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';

import DanhMuc from '../../assets/DanhMuc';
import gui from '../../lib/gui';

class OperationHistoryRow extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        let data = this.props.data;
        let name = data.deviceName;
        let position = data.location || "Hoi An, Quang Nam";
        let endDate = data.endDate;
        let status = DanhMuc.equipmentStatus[data.status] || "Available";
        let timeWorking = data.workingHour;
        let color = status == "Using" ? 'rgba(32,201,151,1)' : (status == "Available" ? "rgba(23,162,184,1)" : gui.mainTextColor);
        return(
            <TouchableOpacity style={styles.viewRowHistory}
                              onPress={this.onEquipmentHistory.bind(this, data)}
            >
                <View style={styles.viewNameEquipment}>
                    <Text style={styles.textName}>{name}</Text>
                </View>
                <View style={styles.viewContentHistory}>
                    <View style={styles.viewLeftContent}>
                        <View style={styles.childContent}>
                            <View style={styles.childLeftContent}>
                                <Text style={styles.textContent}>Position</Text>
                            </View>
                            <View style={styles.childRightContent}>
                                <Text style={[styles.textContent, {color: gui.textTimeColor}]}
                                      numberOfLines={1}>
                                    {position}
                                </Text>
                            </View>
                        </View>
                        <View style={styles.childContent}>
                            <View style={[styles.childLeftContent, {justifyContent: 'flex-start'}]}>
                                <Text style={styles.textContent}>End date</Text>
                            </View>
                            <View style={[styles.childRightContent, {flex: 1,  justifyContent: 'flex-start'}]}>
                                <Text style={[styles.textContent, {color: gui.textTimeColor}]}
                                      numberOfLines={1}>
                                    {endDate}
                                </Text>
                            </View>
                        </View>
                    </View>

                    <View style={[styles.viewLeftContent, { width: (gui.screenWidth - 32)/2 - 32,}]}>
                        <View style={styles.childContent}>
                            <View style={[styles.childLeftContent, {flex: 1}]}>
                                <Text style={styles.textContent}>Status</Text>
                            </View>
                            <View style={[styles.childRightContent, {flex: 1, paddingRight: 12}]}>
                                <Text style={[styles.textContent, {color: color}]}
                                      numberOfLines={1}>
                                    {status}
                                </Text>
                            </View>
                        </View>
                        <View style={styles.childContent}>
                            <View style={[styles.childLeftContent, {justifyContent: 'flex-start', flex: 2}]}>
                                <Text style={styles.textContent}>Working</Text>
                            </View>
                            <View style={[styles.childRightContent, {flex: 1,  justifyContent: 'flex-start', paddingRight: 12}]}>
                                <Text style={[styles.textContent, {color: gui.textTimeColor}]}
                                      numberOfLines={1}>
                                    {timeWorking}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    onEquipmentHistory(data) {
        Actions.OperationHistoryDetail({data: data});
    }

}


const styles = StyleSheet.create({
    viewRowHistory: {
        width: gui.screenWidth - 32,
        height: 108,
        borderWidth: 1,
        borderColor: 'rgba(137,137,137,0.5)',
        borderRadius: 5,
        marginTop: 12,
        marginLeft: 16
    },
    viewNameEquipment: {
        height: 32,
        width: gui.screenWidth - 32,
        paddingLeft: 12,
        justifyContent: 'flex-end'
    },
    textName: {
        fontSize: gui.titleFontSize,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewContentHistory: {
        height: 76,
        width: gui.screenWidth - 32,
        flexDirection: 'row'
    },
    viewLeftContent: {
        height: 76,
        width: (gui.screenWidth - 32)/2 + 32,
    },
    childContent: {
        flex: 1,
        flexDirection: 'row'
    },
    childLeftContent: {
        flex: 1,
        justifyContent: 'center',
        paddingLeft: 12
    },
    childRightContent: {
        flex: 2,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    textContent: {
        fontSize: gui.memSizeText,
        color: gui.mainTextColor
    }
});

export default OperationHistoryRow