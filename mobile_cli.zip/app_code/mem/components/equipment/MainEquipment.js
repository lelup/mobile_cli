import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput,
    ScrollView,
    ActivityIndicator
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import LineBold from '../line/LineBold';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';
import log from '../../lib/logUtil';
import utils from '../../lib/utils';
import DanhMuc from '../../assets/DanhMuc';
import EquipmentRow from './EquipmentRow';
import MaintenanceRow from './MaintenanceRow';
import OperationHistoryRow from './OperationHistoryRow';
import SimpleLoading from '../loading/SimpleLoading';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as userAction from '../../reducers/user/userActions';
import * as globalAction from '../../reducers/global/globalActions';
const actions = [
    userAction,
    globalAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MainEquipment extends Component {
    constructor(props) {
        super(props);
        let dataList = [
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Using'
            },
            {   'nameEquipment' : 'Soilmec (ABC19)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC5)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC15)',
                'state' : 'Using'
            },
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Using'
            },
        ];

        let dataMaintenance = [
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            },
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            },
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            }
        ];

        let dataOperation = [
            {   'name' : 'Soilmec (ABC1)',
                'position' : 'Hoi An, Quang Nam',
                'entranceDate' : '20-May-2018',
                'status' : 'Using',
                'timeWorking' : '10'
            },
            {   'name' : 'Soilmec (ABC1)',
                'position' : 'Hoi An, Quang Nam',
                'entranceDate' : '20-May-2018',
                'status' : 'Using',
                'timeWorking' : '10'
            },
            {   'name' : 'Soilmec (ABC1)',
                'position' : 'Hoi An, Quang Nam',
                'entranceDate' : '20-May-2018',
                'status' : 'Using',
                'timeWorking' : '10'
            }
        ];

        this.state = {
            dataList: dataList,
            dataMaintenance: dataMaintenance,
            dataOperation: dataOperation,
            listAllEquipments: props.user.listAllEquipments,
            listAllOperationHistory: props.user.listAllOperationHistory,
            listAllRepairHistory: props.user.listAllRepairHistory
        }
    }

    componentWillMount() {
        this.fetchData();
    }


    componentWillReceiveProps(nextProps) {
        if(this.props.user.listAllEquipments !== nextProps.user.listAllEquipments) {
            this.setState({ listAllEquipments: nextProps.user.listAllEquipments})
        }
        if(this.props.user.listAllOperationHistory !== nextProps.user.listAllOperationHistory) {
            this.setState({ listAllOperationHistory: nextProps.user.listAllOperationHistory})
        }
        if(this.props.user.listAllRepairHistory !== nextProps.user.listAllRepairHistory) {
            this.setState({ listAllRepairHistory: nextProps.user.listAllRepairHistory})
        }
    }

    fetchData() {
        let { token } = this.props.user;
        this.props.actions.getAllEquipments(
            {'token': token},
            (res) => {
                //log.info('respond data: =====>>>>>', res)
            },
            (error) => {
                log.info('error getAllEquipments data: =====>>>>>', error)
            }
            );
        this.props.actions.getAllOperationHistory(
            {'token': token},
            (res) => {
                //log.info('respond getAllOperationHistory data: =====>>>>>', res)
            },
            (error) => {
                log.info('error getAllOperationHistory data: =====>>>>>', error)
            }
            );
        this.props.actions.getAllRepairHistory(
            {'token': token},
            (res) => {
                log.info('respond getAllRepairHistory data: =====>>>>>', res)
            },
            (error) => {
                log.info('error getAllRepairHistory data: =====>>>>>', error)
            }
            );
    }

    render() {
        console.log('============= this.state.listAllEquipments', this.state.listAllRepairHistory)
        return (
            <View style={styles.container}>
                <SectionHeader headerTitle={"Equipment"}/>
                {this.renderMainEquipment()}
                {this.renderLoadingView()}
            </View>
        );
    }

    renderMainEquipment() {
        let { dataList, dataMaintenance, listAllEquipments, listAllOperationHistory, listAllRepairHistory } = this.state;
        let dataEquipmentList = utils.listMainCheck(listAllEquipments);
        let dataOperationHistory = utils.listMainCheck(listAllOperationHistory);
        let dataRepairHistory = utils.listMainCheck(listAllRepairHistory);
        return(
            <ScrollView style={styles.viewMainEquipment}
                        contentContainerStyle={{paddingBottom: 8}}
            >
                { dataEquipmentList.length > 0 ?
                    <View>
                        <FlatList
                            data={dataEquipmentList}
                            keyExtractor={(item, index) => "list" + index}
                            renderItem={(data) => this._renderRowList(data.item)}
                            removeClippedSubviews={false}
                            enableEmptySections
                            ListFooterComponent={this.renderFooter("equipmentList")}
                            //style={styles.viewListContainer}
                        />

                        <LineBold />
                    </View> : null }
                { dataOperationHistory.length > 0 ?
                    <View>
                        <FlatList
                            data={dataOperationHistory}
                            keyExtractor={(item, index) => "list" + index}
                            renderItem={(data) => this._renderRowOperation(data.item)}
                            removeClippedSubviews={false}
                            enableEmptySections
                            ListFooterComponent={this.renderFooter("operationList")}
                            //style={styles.viewListContainer}
                        />

                        <LineBold />
                    </View> : null }
                { dataRepairHistory.length > 0 ?
                        <FlatList
                        data={dataRepairHistory}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderRowMaintenance(data.item)}
                        removeClippedSubviews={false}
                        enableEmptySections
                        ListFooterComponent={this.renderFooter("maintenanceList")}
                        //style={styles.viewListContainer}
                    /> : null
                }
            </ScrollView>
        )
    }

    renderLoadingView() {
        if(this.props.user.isAllEquipments) {
            return(
                <SimpleLoading color={"gray"} size={"small"} />
            )
        } else return null;
    }

    _renderRowList(data) {
        return(
            <EquipmentRow data={data} />
        )
    }

    _renderRowOperation(data) {
        return (
            <OperationHistoryRow data={data}/>
        )
    }

    _renderRowMaintenance(data) {
        return (
            <MaintenanceRow data={data}/>
        )
    }

    renderFooter(type) {
        return(
            <TouchableOpacity style={styles.viewFooterList}
                              onPress={this.onListDetail.bind(this, type)}
            >
                <Text style={[styles.textContent, {color: gui.mainColor}]}>See more</Text>
                <FontAwesomeLight name={"chevron-right"}
                                  size={15}
                                  color={gui.mainColor}
                                  mainProps={{marginLeft: 3}}
                />
            </TouchableOpacity>
        )
    }

    onListDetail(type) {
        let { listAllEquipments, listAllOperationHistory, listAllRepairHistory } = this.state;
        if (type == 'equipmentList') {
            Actions.EquipmentList({listAllEquipments: listAllEquipments});
        } else if(type == 'operationList') {
            Actions.OperationHistoryList({listAllOperationHistory: listAllOperationHistory});
        } else if(type == 'maintenanceList') {
            Actions.MaintenanceHistoryList({listAllRepairHistory: listAllRepairHistory});
        } else console.log('==========> onListDetail')
    }


}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewMainEquipment: {
        flex: 1,
        backgroundColor: '#fff'
    },
    textName: {
        fontSize: gui.titleFontSize,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    textContent: {
        fontSize: gui.memSizeText,
        color: gui.mainTextColor
    },
    viewFooterList: {
        height: 44,
        width: gui.screenWidth,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewLoading: {
        position: 'absolute',
        top: gui.screenHeight/2 - 10,
        left: gui.screenWidth/2 - 10
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(MainEquipment);