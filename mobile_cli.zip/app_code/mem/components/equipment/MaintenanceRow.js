import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';
import DanhMuc from '../../assets/DanhMuc';
class MaintenanceRow extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        let data = this.props.data;
        let name = data.deviceName;
        let status =  DanhMuc.repaireStatus[data.status] || "Available";
        let oderDate = data.requiredDate;
        let completedDate = data.completedDate;
        let statusColor = status == 'Completed' ? 'rgba(248,79,52,1)' : (status == 'Using' ? 'rgba(32,201,151,1)' : gui.mainTextColor);
        return (
            <TouchableOpacity style={styles.viewRowHistory}
                              onPress={this.maintenanceHistory.bind(this, data)}
            >
                <View style={styles.viewNameEquipment}>
                    <Text style={styles.textName}>{name}</Text>
                    <Text style={[styles.textContent, {color: statusColor}]}>{status}</Text>
                </View>
                <View style={[styles.viewNameEquipment, {height: 38, alignItems: 'center'}]}>
                    <Text style={[styles.textName, {fontWeight: 'normal'}]}>Oder date</Text>
                    <Text style={[styles.textContent, {color: gui.textTimeColor}]}>{oderDate}</Text>
                </View>
                <View style={[styles.viewNameEquipment, {height: 38, alignItems: 'flex-start'}]}>
                    <Text style={[styles.textName, {fontWeight: 'normal'}]}>Completed date</Text>
                    <Text style={[styles.textContent, {color: gui.textTimeColor}]}>{completedDate}</Text>
                </View>
            </TouchableOpacity>
        )
    }

    maintenanceHistory(data) {
        Actions.MaintenanceHistory({data:data});
    }

}


const styles = StyleSheet.create({
    viewRowHistory: {
        width: gui.screenWidth - 32,
        height: 108,
        borderWidth: 1,
        borderColor: 'rgba(137,137,137,0.5)',
        borderRadius: 5,
        marginTop: 12,
        marginLeft: 16
    },
    viewNameEquipment: {
        height: 32,
        width: gui.screenWidth - 32,
        paddingHorizontal: 12,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-end'

    },
    textName: {
        fontSize: gui.titleFontSize,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    textContent: {
        fontSize: gui.memSizeText,
        color: gui.mainTextColor
    }
});

export default MaintenanceRow