import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput,
    Keyboard
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import Ionicons from 'react-native-vector-icons/Ionicons';

import gui from '../../lib/gui';
import CommonHeader from '../header/CommonHeader';
import TabButton from '../tab/TabButton';
import SimpleLoading from '../loading/SimpleLoading';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import InputRowManagement from './InputRowManagement';
import OutputRowManagement from './OutputRowManagement';


import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as userAction from '../../reducers/user/userActions';
import * as globalAction from '../../reducers/global/globalActions';
const actions = [
    userAction,
    globalAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class SpareParts extends Component {

    constructor(props) {
        super(props);
        let dataInput = [
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'qyt' : '50',
                'entranceDate' : '20-Jun-2018',
                'status' : 'Using',
                'stock' : '72'
            },
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'qyt' : '50',
                'entranceDate' : '20-Jun-2018',
                'status' : 'Using',
                'stock' : '72'
            },
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'qyt' : '50',
                'entranceDate' : '20-Jun-2018',
                'status' : 'Using',
                'stock' : '72'
            },
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'qyt' : '50',
                'entranceDate' : '20-Jun-2018',
                'status' : 'Using',
                'stock' : '72'
            },
        ];


        let dataOutput = [
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'available' : '30',
                'storage' : '90',
                'orderDate' : '20-Jun-2018',
            },
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'available' : '30',
                'storage' : '90',
                'orderDate' : '20-Jun-2018',
            },
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'available' : '30',
                'storage' : '90',
                'orderDate' : '20-Jun-2018',
            },
            {   'name' : 'Bolt',
                'equipment' : 'Soilmec',
                'available' : '30',
                'storage' : '90',
                'orderDate' : '20-Jun-2018',
            }
        ];
        this.state = {
            typeEquipment : 'input',
            searchEquipment: '',
            dataInput: props.user.listInputSparePart,
            dataOutput: props.user.listOutputSparePart,
        }
    }


    componentWillMount() {
        this.fetchData();
    }


    componentWillReceiveProps(nextProps) {
        if(this.props.user.listInputSparePart !== nextProps.user.listInputSparePart) {
            this.setState({ dataInput: nextProps.user.listInputSparePart})
        }
        if(this.props.user.listOutputSparePart !== nextProps.user.listOutputSparePart) {
            this.setState({ dataOutput: nextProps.user.listOutputSparePart})
        }
    }

    fetchData() {
        let { token } = this.props.user;
        this.props.actions.getAllSparepart(
            {   "token": token
            },
            (res) => {
                //log.info('respond data: =====>>>>>', res)
            },
            (error) => {
                log.info('error getAllSparepart data: =====>>>>>', error)
            }
        )
    }



    render() {
        return (
            <View style={styles.container}>
                {this.renderHeaderManagement()}
                {this.renderBodyManagement()}
                {this.renderLoadingView()}
            </View>
        );
    }

    renderBodyManagement() {
        return(
            <View style={styles.viewBodyMore}>
                <View style={styles.viewInputSort}>
                    <View style={styles.viewContentInput}>
                        <TextInput
                            style={styles.viewTextInput}
                            underlineColorAndroid='rgba(0,0,0,0)'
                            returnKeyType='done'
                            placeholder="Search"
                            placeholderTextColor={gui.textTimeColor}
                            onChangeText={text => this.searchFilterFunction(text)}
                            value={this.state.searchEquipment}

                        />
                    </View>
                    <View style={styles.viewFilterIcon}>
                        <FontAwesomeSolid name={"filter"}
                                          size={20}
                                          color={gui.textTimeColor}
                                          mainProps={{marginLeft: 0}}
                        />
                    </View>
                </View>
                <FullLine/>
                {this.renderListManagement()}
            </View>
        )
    }

    renderHeaderManagement() {
        return(
            <View style={styles.customPageHeader}>
                <TouchableOpacity onPress={this._onBack.bind(this)}
                                  style={styles.viewBackStyle}
                >
                    <Ionicons name="ios-arrow-back" color={'#fff'} size={28}/>
                </TouchableOpacity>
                <View style={styles.customPageTitle}>
                    {this.renderButtonTab()}
                </View>
                <View style={styles.viewRightHeader}>
                </View>
            </View>
        )
    }

    renderButtonTab() {
        return(
            <View style={styles.viewButtonTitle}>
                <TabButton name={'input'}
                                 onPress={this.onTypeEquipmentPress.bind(this)}
                                 selected={this.state.typeEquipment == 'input'}
                                 mainProps={styles.viewTabHeader}
                                 titleButton="INPUT"></TabButton>

                <TabButton name={'output'}
                                 onPress={this.onTypeEquipmentPress.bind(this)}
                                 selected={this.state.typeEquipment == 'output'}
                                 mainProps={styles.viewTabHeader}
                                 titleButton="OUTPUT"></TabButton>
            </View>
        )
    }

    renderListManagement() {
        let { typeEquipment, dataInput, dataOutput } = this.state;
        if(typeEquipment == 'input') {
            return(
                <FlatList
                    data={dataInput}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRowInput(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                    contentContainerStyle={{paddingBottom: 16}}
                    onMomentumScrollBegin={() => {Keyboard.dismiss()}}
                />
            )
        } else if (typeEquipment == 'output') {
            return(
                <FlatList
                    data={dataOutput}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRowOutput(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                    contentContainerStyle={{paddingBottom: 16}}
                    onMomentumScrollBegin={() => {Keyboard.dismiss()}}
                />
            )
        }
    }

    searchFilterFunction = text => {
        let listInputSparePart = this.props.user.listInputSparePart;
        let listOutputSparePart = this.props.user.listOutputSparePart;
        if(this.state.typeEquipment == 'input') {
            const newData = listInputSparePart.filter(item => {
                const itemData = `${item.deviceName.toUpperCase()} ${item.name.toUpperCase()}`;
                const textData = text.toUpperCase();
                return itemData.indexOf(textData) > -1;
            });
            this.setState({
                searchEquipment: text,
                dataInput: newData,
            });
        } else if (this.state.typeEquipment == 'output') {
            const newData = listOutputSparePart.filter(item => {
                const itemData = `${item.deviceName.toUpperCase()} ${item.name.toUpperCase()}`;
                const textData = text.toUpperCase();
                return itemData.indexOf(textData) > -1;
            });
            this.setState({
                searchEquipment: text,
                dataOutput: newData,
            });
        }
    };



    renderLoadingView() {
        if(this.props.user.isAllSparePart) {
            return(
                <SimpleLoading color={"gray"} size={"small"} />
            )
        } else return null;
    }

    _renderRowInput(data) {
        return(
            <InputRowManagement data={data} />
        )
    }

    _renderRowOutput(data) {
        return(
            <OutputRowManagement data={data} />
        )
    }

    onTypeEquipmentPress(value) {
        this.setState({
            typeEquipment: value,
            searchEquipment: ''
        });
    }

    _onBack () {
        Actions.pop();
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: gui.navBarHeight,
        width: gui.screenWidth
    },
    customPageTitle: {
        height: gui.navBarHeight,
        width: gui.screenWidth - 180,
        justifyContent: 'center',
        alignItems: 'center'
    },
    customPageTitleText: {
        color: '#fff',
        fontSize: 17,
        fontWeight: '600',
        textAlign: 'center',
        marginTop: gui.marginTop
    },
    customRightTitleText: {
        color: '#fff',
        fontSize: 17,
        textAlign: 'center',
        marginTop: gui.marginTop
    },
    viewBackStyle: {
        height: gui.navBarHeight,
        width: 90,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingTop: gui.marginTop,
        paddingLeft: 22
    },
    viewRightHeader: {
        height: gui.navBarHeight,
        width: 90,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyMore: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewButtonTitle: {
        height: 38,
        width: 140,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: "#fff",
        marginTop: 16,
        flexDirection: 'row'
    },
    viewTabHeader: {
        height: 30,
        width: 65,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 15
    },
    viewInputSort: {
        height: 34,
        width: gui.screenWidth,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewContentInput: {
        width: gui.screenWidth - 44,
        height: 34,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewFilterIcon: {
        height: 34,
        width: 44,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextInput: {
        height: 26,
        width: gui.screenWidth - 44 - 16,
        borderRadius: 13,
        paddingLeft: 13,
        backgroundColor: 'rgba(235,235,235,1)',
        fontSize: 15,
    },
    viewListContainer: {
        flex: 1
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(SpareParts);