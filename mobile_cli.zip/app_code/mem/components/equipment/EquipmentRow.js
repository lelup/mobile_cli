import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';
import DanhMuc from '../../assets/DanhMuc';
class EquipmentRow extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        let data = this.props.data;
        let name = data.name;
        let status =  DanhMuc.equipmentStatus[data.status] || "Available";
        let color = status == "Using" ? 'rgba(32,201,151,1)' : (status == "Available" ? "rgba(23,162,184,1)" : gui.mainTextColor);
        return(
            <TouchableOpacity style={styles.viewRowEquipment}
                              onPress={this.onEquipmentDetail.bind(this, data)}
            >
                <View style={styles.viewContent}>
                    <View style={styles.viewNameEquipment}>
                        <Text style={styles.textCommon}>{name}</Text>
                    </View>
                    <View style={styles.viewStateEquipment}>
                        <Text style={[styles.textCommon, {fontSize: gui.memSizeText, color: color}]}>{status}</Text>
                        <FontAwesomeLight name={"chevron-right"}
                                          size={20}
                                          color={gui.textTimeColor}
                                          mainProps={{marginLeft: 8}}
                        />
                    </View>
                </View>
                <FullLine style={{marginLeft: 16}} />
            </TouchableOpacity>
        )
    }

    onEquipmentDetail(data) {
        Actions.EquipmentDetail({data:data})
    }
}


const styles = StyleSheet.create({
    viewRowEquipment: {
        height: 45,
        width: gui.screenWidth
    },
    viewContent: {
        height: 44,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewNameEquipment: {
        flex: 2,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewStateEquipment: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingRight: 16,
        flexDirection: 'row'
    },
    textCommon: {
        fontSize: gui.titleFontSize,
        color: gui.mainTextColor
    },
});

export default EquipmentRow