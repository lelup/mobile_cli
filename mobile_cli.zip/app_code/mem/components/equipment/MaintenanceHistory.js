import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput,
    ScrollView,
    KeyboardAvoidingView
} from 'react-native';


import { Actions } from 'react-native-router-flux';
import FullLine from '../line/FullLine';
import SectionHeader from '../header/SectionHeader';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';

class MaintenanceHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            usermark: this.props.data.remark ? this.props.data.remark : ''
        }
    }

    render() {
        let deviceName = this.props.data.deviceName;
        return (
            <View style={styles.container}>
                <SectionHeader headerTitle={deviceName} />
                {this.renderBodyEquipmentHistory()}
            </View>
        );
    }

    renderBodyEquipmentHistory() {
        let  data  = this.props.data;
        return(
            <ScrollView contentContainerStyle={styles.viewBodyEquipmentDetail}>
                {this.renderHeaderDetail()}
                {this.renderChildContent("Required Date", data.requiredDate)}
                <FullLine style={{marginLeft: 16}} />
                {this.renderChildContent("Completed date", data.completedDate)}
                <FullLine style={{marginLeft: 16}} />
                {this.renderChildContent("Updated by", data.updateBy.name)}
                <FullLine style={{marginLeft: 16}} />
                {this.renderChildContent("Approved by", data.createBy.name)}
                <FullLine style={{marginLeft: 16}} />
                {this.renderMarkEquipment()}
            </ScrollView>
        )
    }

    renderHeaderDetail() {
        let  data  = this.props.data;
        let title = 'REPAIR/MAINTENANCE HISTORY';
        let avatar = require('../../assets/image/soilmec.jpg');
        let imageUri = {uri :data.deviceImg };

        return(
            <View style={styles.viewImageDetail}>
                <View style={styles.viewTitleContent}>
                    <TouchableOpacity style={styles.viewImageHistory}>
                        <Image style={styles.imageStyle}
                               source={imageUri}
                               resizeMode={'cover'}
                        />
                    </TouchableOpacity>
                    <View style={styles.viewContentTitle}>
                        {this.renderContentTitleDetail("Serial Number", data.serial)}
                        {this.renderContentTitleDetail("Equipment Type", "dang lam")}
                        {this.renderContentTitleDetail("Position", "Hoi An")}
                    </View>
                </View>
                <FullLine />
                <View style={styles.viewTitleHistory}>
                    <Text style={[styles.textCommon, {fontSize: gui.smallFontSize}]}>{title}</Text>
                </View>
                <FullLine style={{marginLeft: 16}} />
            </View>
        )
    }

    renderContentTitleDetail(equipmentHistory,content) {
        return(
            <View style={styles.viewContentTitleDetail}>
                <Text style={[styles.textCommon, {fontWeight: '500'}]}>{equipmentHistory}</Text>
                <Text style={[styles.textCommon, {fontSize: gui.memSizeText}]}>{content}</Text>
            </View>
        )
    }

    renderChildContent(equipmentHistory,content) {
        return(
            <View style={styles.viewContentTitleBottom}>
                <Text style={[styles.textCommon, {fontWeight: '500'}]}>{equipmentHistory}</Text>
                <Text style={[styles.textCommon, {fontSize: gui.memSizeText}]}>{content}</Text>
            </View>
        )
    }

    renderMarkEquipment() {
        let  data  = this.props.data;
        return(
            <View style={styles.viewRowEquipment}>
                <View style={styles.viewContentMark}>
                    <Text style={[styles.textCommon, {fontWeight: '500'}]}>Remark</Text>
                </View>
                <TextInput
                    style={styles.viewTextInput}
                    underlineColorAndroid='rgba(0,0,0,0)'
                    returnKeyType='done'
                    placeholder="Mark for equipment here!"
                    placeholderTextColor={gui.textTimeColor}
                    onChangeText={(text) => this.setState({usermark: (text)})}
                    value={this.state.usermark}
                    multiline={true}
                    autoGrow={true}
                />
                <FullLine style={{marginTop: 8}}/>
            </View>
        )
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyEquipmentDetail: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        flex: 1
    },
    viewRowEquipment: {
        height: 'auto',
        width: gui.screenWidth,
        paddingHorizontal: 16
    },
    viewContentMark: {
        height: 44,
        width: gui.screenWidth - 32,
        justifyContent: 'center'
    },
    textCommon: {
        fontSize: gui.titleFontSize,
        color: gui.mainTextColor
    },
    imageStyle: {
        width: 130,
        height: 88
    },
    viewImageDetail: {
        width: gui.screenWidth,
        height: 'auto'
    },
    viewTitleHistory: {
        height: 36,
        width: gui.screenWidth,
        paddingLeft: 16,
        justifyContent: 'center'
    },
    viewImageHistory: {
        height: 112,
        width: 155,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewTitleContent: {
        height: 112,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewContentTitle: {
        height: 112 ,
        width: gui.screenWidth - 155,
        justifyContent: 'center',
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewContentTitleDetail: {
        height: 30 ,
        width: gui.screenWidth - 155,
        paddingRight: 16,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewContentTitleBottom: {
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row',
        width: gui.screenWidth,
        paddingHorizontal: 16,
        height: 44
    },
    viewTextInput: {
        minHeight: 50,
        width: gui.screenWidth - 32,
        fontSize: 15,
    }
});

export default MaintenanceHistory;