import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput
} from 'react-native';


import { Actions } from 'react-native-router-flux';
import FullLine from '../line/FullLine';
import SectionHeader from '../header/SectionHeader';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';
import DanhMuc from '../../assets/DanhMuc';
class EquipmentDetail extends Component {
    constructor(props) {
        super(props);
        let data = this.props.data;
        console.log('=========> dataDetail', data);
        let status = data.status;
        let state = DanhMuc.equipmentStatus[status] || "Available";
        let dataDetail = [
            {   'equipmentProps' : 'Serial Number',
                'equipmentContent' : data.serial
            },
            {   'equipmentProps' : 'Equipment Type',
                'equipmentContent' : data.categorys[0].dsc
            },
            {   'equipmentProps' : 'Capacity',
                'equipmentContent' : '1000'
            },
            {   'equipmentProps' : 'Electric',
                'equipmentContent' : '1000W'
            },
            {   'equipmentProps' : 'Entrance date',
                'equipmentContent' : data.checkDate
            },
            {   'equipmentProps' : 'Next Maintenance Date',
                'equipmentContent' : data.nextMaintenanceDate
            },
            {   'equipmentProps' : 'Fuel Per Hour',
                'equipmentContent' : data.usageFuelPerHour
            },
            {   'equipmentProps' : 'Duration',
                'equipmentContent' : data.usedDuration
            },
            {   'equipmentProps' : 'Owner',
                'equipmentContent' : data.owner
            },
            {   'equipmentProps' : 'Position',
                'equipmentContent' : data.location
            },
            {   'equipmentProps' : 'State',
                'equipmentContent' : state
            },
        ];

        this.state = {
            data: dataDetail
        }
    }

    render() {
        let data = this.props.data;
        return (
            <View style={styles.container}>
                <SectionHeader headerTitle={data.name} />
                {this.renderBodyEquipmentDetail()}
            </View>
        );
    }

    renderBodyEquipmentDetail() {
        let { data } = this.state;
        return(
            <View style={styles.viewBodyEquipmentDetail}>
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    ListHeaderComponent={this.renderHeaderDetail()}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                    contentContainerStyle={{paddingBottom: 16}}
                />
            </View>
        )
    }

    renderHeaderDetail() {
        let data = this.props.data;
        let imageUri = {uri :data.img };
        return(
            <View style={styles.viewImageDetail}>
                <TouchableOpacity>
                    <Image style={styles.imageStyle}
                           source={imageUri}
                           resizeMode={'contain'}
                    />
                </TouchableOpacity>
                <FullLine style={{marginTop: 8}}/>
            </View>
        )
    }

    _renderRow(data) {
        let equipmentProps = data.equipmentProps;
        let equipmentContent =  data.equipmentContent;
        let color = equipmentContent == "Using" ? 'rgba(32,201,151,1)' : (equipmentContent == "Available" ? "rgba(23,162,184,1)" : gui.mainTextColor);
        return(
            <View style={styles.viewRowEquipment}>
                <View style={styles.viewContent}>
                    <View style={styles.viewNameEquipment}>
                        <Text style={[styles.textCommon, {fontWeight: '500'}]}>{equipmentProps}</Text>
                    </View>
                    <View style={styles.viewStateEquipment}>
                        <Text style={[styles.textCommon, {fontSize: gui.memSizeText, color: color}]}>{equipmentContent}</Text>
                    </View>
                </View>
                <FullLine style={{marginLeft: 16}} />
            </View>
        )
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyEquipmentDetail: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        flex: 1
    },
    viewRowEquipment: {
        height: 45,
        width: gui.screenWidth
    },
    viewContent: {
        height: 44,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewNameEquipment: {
        flex: 1,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewStateEquipment: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingRight: 16,
        flexDirection: 'row'
    },
    textCommon: {
        fontSize: gui.titleFontSize,
        color: gui.mainTextColor
    },
    imageStyle: {
        width: gui.screenWidth,
        height: 250
    },
    viewImageDetail: {
        width: gui.screenWidth,
        height: 'auto'
    }
});

export default EquipmentDetail;