import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput,
    Keyboard
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';

import MaintenanceRow from './MaintenanceRow';

class MaintenanceHistoryList extends Component {
    constructor(props) {
        super(props);
        let data = [
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            },
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            },
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            },
            {   'name' : 'Soilmec (ABC1)',
                'status' : 'Completed',
                'oderDate' : '20-Nov-2018',
                'completedDate' : '30-Nov-2018',
            },
        ];

        this.fullData = this.props.listAllRepairHistory;
        this.state = {
            data: this.props.listAllRepairHistory,
            searchMaintenance: ''
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <SectionHeader headerTitle={"Repair history"}
                               rightTitle={"Order"}
                />
                {this.renderMaintenanceHistoryList()}
            </View>
        );
    }

    renderMaintenanceHistoryList() {
        let { data } = this.state;
        return(
            <View style={styles.viewBodyEquipmentList}>
                <View style={styles.viewInputSort}>
                    <View style={styles.viewContentInput}>
                        <TextInput
                            style={styles.viewTextInput}
                            underlineColorAndroid='rgba(0,0,0,0)'
                            returnKeyType='done'
                            placeholder="Search"
                            placeholderTextColor={gui.textTimeColor}
                            onChangeText={text => this.searchFilterFunction(text)}
                            value={this.state.searchMaintenance}

                        />
                    </View>
                    <View style={styles.viewFilterIcon}>
                        <FontAwesomeSolid name={"filter"}
                                          size={20}
                                          color={gui.textTimeColor}
                                          mainProps={{marginLeft: 0}}
                        />
                    </View>
                </View>
                <FullLine />
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                    contentContainerStyle={{paddingBottom: 10}}
                    onMomentumScrollBegin={() => {Keyboard.dismiss()}}
                />
            </View>
        )
    }

    searchFilterFunction = text => {
        const newData = this.fullData.filter(item => {
            const itemData = `${item.deviceName.toUpperCase()}`;
            const textData = text.toUpperCase();
            return itemData.indexOf(textData) > -1;
        });
        this.setState({
            searchMaintenance: text,
            data: newData,
        });
    };

    _renderRow(data) {
         return (
            <MaintenanceRow data={data}/>
        )
    }

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyEquipmentList: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        flex: 1
    },
    viewRowEquipment: {
        height: 45,
        width: gui.screenWidth
    },
    textCommon: {
        fontSize: gui.titleFontSize,
        color: gui.mainTextColor
    },
    viewInputSort: {
        height: 34,
        width: gui.screenWidth,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewContentInput: {
        width: gui.screenWidth - 44,
        height: 34,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewFilterIcon: {
        height: 34,
        width: 44,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextInput: {
        height: 26,
        width: gui.screenWidth - 44 - 16,
        borderRadius: 13,
        paddingLeft: 13,
        backgroundColor: 'rgba(235,235,235,1)',
        fontSize: 15,
    },
    viewRowHistory: {
        width: gui.screenWidth - 32,
        height: 108,
        borderWidth: 1,
        borderColor: 'rgba(137,137,137,0.5)',
        borderRadius: 5,
        marginTop: 12,
        marginLeft: 16
    },
    viewNameEquipment: {
        height: 32,
        width: gui.screenWidth - 32,
        paddingHorizontal: 12,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-end'

    },
    textName: {
        fontSize: gui.titleFontSize,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    textContent: {
        fontSize: gui.memSizeText,
        color: gui.mainTextColor
    }
});

export default MaintenanceHistoryList