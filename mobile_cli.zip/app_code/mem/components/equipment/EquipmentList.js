import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput,
    Keyboard
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';
import EquipmentRow from './EquipmentRow';

class EquipmentList extends Component {
    constructor(props) {
        super(props);
        let data = [
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Using'
            },
            {   'nameEquipment' : 'Soilmec (ABC19)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC5)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC15)',
                'state' : 'Using'
            },
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Using'
            },
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC14)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Available'
            },
            {   'nameEquipment' : 'Soilmec (ABC91)',
                'state' : 'Using'
            },
            {   'nameEquipment' : 'Soilmec (ABC1)',
                'state' : 'Using'
            },
        ];

        this.fullData = this.props.listAllEquipments;

        this.state = {
            data: this.props.listAllEquipments,
            searchEquipment: ''
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <SectionHeader headerTitle={"Equipment list"}
                               rightTitle={"Order"}
                />
                {this.renderBodyEquipmentList()}
            </View>
        );
    }

    renderBodyEquipmentList() {
        let { data } = this.state;
        return(
            <View style={styles.viewBodyEquipmentList}>
                <View style={styles.viewInputSort}>
                    <View style={styles.viewContentInput}>
                        <TextInput
                            style={styles.viewTextInput}
                            underlineColorAndroid='rgba(0,0,0,0)'
                            returnKeyType='done'
                            placeholder="Search"
                            placeholderTextColor={gui.textTimeColor}
                            //onChangeText={(text) => this.setState({searchEquipment: (text)})}
                            onChangeText={text => this.searchFilterFunction(text)}
                            value={this.state.searchEquipment}

                        />
                    </View>
                    <View style={styles.viewFilterIcon}>
                        <FontAwesomeSolid name={"filter"}
                                          size={20}
                                          color={gui.textTimeColor}
                                          mainProps={{marginLeft: 0}}
                        />
                    </View>
                </View>
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                    contentContainerStyle={{paddingBottom: 10}}
                    onMomentumScrollBegin={() => {Keyboard.dismiss()}}
                />
            </View>
        )
    }

    searchFilterFunction = text => {
        const newData = this.fullData.filter(item => {
            const itemData = `${item.name.toUpperCase()}`;
            const textData = text.toUpperCase();
            return itemData.indexOf(textData) > -1;
        });
        this.setState({
            searchEquipment: text,
            data: newData,
        });
    };
    _renderRow(data) {
        return(
            <EquipmentRow data={data} />
        )
    }

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyEquipmentList: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        flex: 1
    },
    viewInputSort: {
        height: 34,
        width: gui.screenWidth,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewContentInput: {
        width: gui.screenWidth - 44,
        height: 34,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewFilterIcon: {
        height: 34,
        width: 44,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextInput: {
        height: 26,
        width: gui.screenWidth - 44 - 16,
        borderRadius: 13,
        paddingLeft: 13,
        backgroundColor: 'rgba(235,235,235,1)',
        fontSize: 15,
    }
});

export default EquipmentList