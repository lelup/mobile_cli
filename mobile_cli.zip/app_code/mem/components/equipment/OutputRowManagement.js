import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput
} from 'react-native';

import { Actions } from 'react-native-router-flux';

import SectionHeader from '../header/SectionHeader';
import FullLine from '../line/FullLine';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';

class OutputRowManagement extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        let data = this.props.data;
        let equipment = data.deviceName;
        let name = data.name;
        let serial= data.serial;
        let orderDate = data.date;
        let qty = data.quantity;
        return(
            <TouchableOpacity style={styles.viewRowHistory}
                              onPress={this.onSparePartsDetail.bind(this, data)}
            >
                <View style={styles.viewNameEquipment}>
                    <Text style={styles.textName}>{name}</Text>
                </View>
                <View style={styles.viewContentHistory}>
                    <View style={styles.viewLeftContent}>
                        <View style={styles.childContent}>
                            <View style={styles.childLeftContent}>
                                <Text style={styles.textContent}>Equipment</Text>
                            </View>
                            <View style={[styles.childRightContent, {paddingRight: 12}]}>
                                <Text style={[styles.textContent, {color: gui.textTimeColor}]}
                                      numberOfLines={1}>
                                    {equipment}
                                </Text>
                            </View>
                        </View>
                        <View style={styles.childContent}>
                            <View style={styles.childLeftContent}>
                                <Text style={styles.textContent}>QTY</Text>
                            </View>
                            <View style={[styles.childRightContent, {flex: 1, paddingRight: 12}]}>
                                <Text style={[styles.textContent, {color: gui.textTimeColor}]}
                                      numberOfLines={1}>
                                    {qty}
                                </Text>
                            </View>
                        </View>
                    </View>

                    <View style={[styles.viewLeftContent, { width: (gui.screenWidth - 32)/2 - 32,}]}>
                        <View style={styles.childContent}>
                        </View>
                        <View style={styles.childContent}>
                            <View style={[styles.childLeftContent, { flex: 1}]}>
                                <Text style={styles.textContent}>Serial</Text>
                            </View>
                            <View style={[styles.childRightContent, {flex: 1, paddingRight: 12}]}>
                                <Text style={[styles.textContent, {color: gui.textTimeColor}]}
                                      numberOfLines={1}>
                                    {serial}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
                <View style={styles.viewEntranceDate}>
                    <Text style={styles.textContent}>Order date</Text>
                    <Text style={[styles.textContent, {color: gui.textTimeColor}]}>{orderDate}</Text>
                </View>
            </TouchableOpacity>
        )
    }

    onSparePartsDetail(data) {
        Actions.SparePartsDetail({data: data})
    }

}


const styles = StyleSheet.create({
    viewRowHistory: {
        width: gui.screenWidth - 32,
        height: 134,
        borderWidth: 1,
        borderColor: 'rgba(137,137,137,0.5)',
        borderRadius: 5,
        marginTop: 12,
        marginLeft: 16
    },
    viewNameEquipment: {
        height: 32,
        width: gui.screenWidth - 32,
        paddingLeft: 12,
        justifyContent: 'flex-end'
    },
    textName: {
        fontSize: gui.titleFontSize,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewContentHistory: {
        height: 68,
        width: gui.screenWidth - 32,
        flexDirection: 'row'
    },
    viewLeftContent: {
        height: 68,
        width: (gui.screenWidth - 32)/2 + 32,
    },
    childContent: {
        flex: 1,
        flexDirection: 'row'
    },
    childLeftContent: {
        flex: 1,
        justifyContent: 'center',
        paddingLeft: 12
    },
    childRightContent: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    textContent: {
        fontSize: gui.memSizeText,
        color: gui.mainTextColor
    },
    viewEntranceDate: {
        height: 34,
        width: gui.screenWidth - 32,
        paddingHorizontal: 12,
        justifyContent: 'space-between',
        flexDirection: 'row',
        paddingTop: 3
    }
});

export default OutputRowManagement