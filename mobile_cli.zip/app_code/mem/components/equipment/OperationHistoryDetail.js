import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput
} from 'react-native';


import { Actions } from 'react-native-router-flux';
import FullLine from '../line/FullLine';
import SectionHeader from '../header/SectionHeader';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import gui from '../../lib/gui';
import DanhMuc from '../../assets/DanhMuc';

class OperationHistoryDetail extends Component {
    constructor(props) {
        super(props);
        console.log('=========> data', this.props.data);
        let data = this.props.data;
        let status =  DanhMuc.equipmentStatus[data.status] || "Available";
        let dataDetail = [
            {   'equipmentHistory' : 'Working hours',
                'contentHistory' : data.workingHour
            },
            {   'equipmentHistory' : 'Start Date',
                'contentHistory' : data.startDate
            },
            {   'equipmentHistory' : 'End Date',
                'contentHistory' : data.endDate
            },
            {   'equipmentHistory' : 'Updated by',
                'contentHistory' : data.updateBy.name
            },
            {   'equipmentHistory' : 'Approved by',
                'contentHistory' : data.createBy.name
            },
            {   'equipmentHistory' : 'Approved Status',
                'contentHistory' : status
            },
            // {   'equipmentHistory' : 'Material consumable',
            //     'contentHistory' : 'sample material consumable'
            // },
        ];

        this.state = {
            data: dataDetail
        }
    }

    render() {
        let name = this.props.data.deviceName;
        return (
            <View style={styles.container}>
                <SectionHeader headerTitle={name} />
                {this.renderBodyEquipmentHistory()}
            </View>
        );
    }

    renderBodyEquipmentHistory() {
        let { data } = this.state;
        return(
            <View style={styles.viewBodyEquipmentDetail}>
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    ListHeaderComponent={this.renderHeaderDetail()}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                    contentContainerStyle={{paddingBottom: 16}}
                />
            </View>
        )
    }

    renderHeaderDetail() {
        let data = this.props.data;
        let title = 'OPERATION HISTORY';
        let avatar = require('../../assets/image/soilmec.jpg');
        let imageUri = {uri :data.deviceImg };
        let dsc = data.dsc.length > 10 ? data.dsc.substring(0,8) + '...' : data.dsc;
        return(
            <View style={styles.viewImageDetail}>
                <View style={styles.viewTitleContent}>
                    <TouchableOpacity style={styles.viewImageHistory}>
                        <Image style={styles.imageStyle}
                               source={imageUri}
                               resizeMode={'cover'}
                        />
                    </TouchableOpacity>
                    <View style={styles.viewContentTitle}>
                        {this.renderContentTitleDetail("Serial Number", data.serial)}
                        {this.renderContentTitleDetail("Equipment Type", dsc)}
                        {this.renderContentTitleDetail("Position", data.location)}
                    </View>
                </View>
                <FullLine />
                <View style={styles.viewTitleHistory}>
                    <Text style={[styles.textCommon, {fontSize: gui.smallFontSize}]}>{title}</Text>
                </View>
                <FullLine style={{marginLeft: 16}} />
            </View>
        )
    }

    renderContentTitleDetail(equipmentHistory,content) {
        return(
            <View style={styles.viewContentTitleDetail}>
                <Text style={[styles.textCommon, {fontWeight: '500'}]}>{equipmentHistory}</Text>
                <Text style={[styles.textCommon, {fontSize: gui.memSizeText}]}>{content}</Text>
            </View>
        )
    }

    _renderRow(data) {
        let equipmentHistory = data.equipmentHistory;
        let content =  data.contentHistory;
        let color = content == "Approved" ? 'rgba(23,162,184,1)' : (content == "Deny" ? "rgba(23,162,184,1)" : gui.mainTextColor);
        return(
            <View style={styles.viewRowEquipment}>
                <View style={styles.viewContent}>
                    <View style={styles.viewNameEquipment}>
                        <Text style={[styles.textCommon, {fontWeight: '500'}]}>{equipmentHistory}</Text>
                    </View>
                    <View style={styles.viewStateEquipment}>
                        <Text style={[styles.textCommon, {fontSize: gui.memSizeText, color: color}]}
                              numberOfLines={1}>{content}</Text>
                    </View>
                </View>
                <FullLine style={{marginLeft: 16}} />
            </View>
        )
    }

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyEquipmentDetail: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        flex: 1
    },
    viewRowEquipment: {
        height: 45,
        width: gui.screenWidth
    },
    viewContent: {
        height: 44,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewNameEquipment: {
        flex: 1,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewStateEquipment: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingRight: 16,
        flexDirection: 'row'
    },
    textCommon: {
        fontSize: gui.titleFontSize,
        color: gui.mainTextColor
    },
    imageStyle: {
        width: 130,
        height: 88
    },
    viewImageDetail: {
        width: gui.screenWidth,
        height: 'auto'
    },
    viewTitleHistory: {
        height: 36,
        width: gui.screenWidth,
        paddingLeft: 16,
        justifyContent: 'center'
    },
    viewImageHistory: {
        height: 112,
        width: 155,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewTitleContent: {
        height: 112,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewContentTitle: {
        height: 112 ,
        width: gui.screenWidth - 155,
        justifyContent: 'center',
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewContentTitleDetail: {
        height: 30 ,
        width: gui.screenWidth - 155,
        paddingRight: 16,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    }
});

export default OperationHistoryDetail;