import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';

export default class TabButton extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';
        let mainViewStyle = selected ? 'mainViewSelected' : 'mainView';

        return (
            <TouchableOpacity
                onPress={() => this.props.onPress(this.props.name)}>
                <View style={[ styles[mainViewStyle], this.props.mainProps]}>

                    <Text style={styles[myStyle]} >
                        {this.props.titleButton}
                    </Text>
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    mainView: {

        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: gui.mainColor,
        borderColor : gui.mainColor,
    },
    mainViewSelected: {
        flexDirection: 'column',
        backgroundColor: '#fff'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 10,
        color: '#fff',
        fontWeight : '500'
    },
    buttonTextSelected: {
        alignSelf:'center',
        fontSize: 10,
        color: gui.mainTextColor,
        fontWeight : '500'
    }
});