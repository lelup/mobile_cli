import React, { PropTypes, Component } from 'react';
import { View, Text, TouchableWithoutFeedback, StyleSheet, Image } from 'react-native';
import gui from "../../lib/gui";

const propTypes = {
    children: PropTypes.object,
    content: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
};
class Modal extends Component {

    render() {
        const { children } = this.props;
        return (
            <View style={styles.modalContainer}>
                <Image
                    style={styles.imageIntro} resizeMode = {'cover'}
                    source={require('../../assets/image/logo.png')}
                />
                {children}
            </View >
        );
    }
}

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center'
    },
    modalTitle: {
        color: '#fff',
        fontSize: 19,
    },
    modalContent: {
        margin: 15,
        justifyContent: 'center',
        alignItems: 'center',
    },
    textContent: {
        color: gui.mainColor,
        fontSize: 19,
        fontWeight: '400'
    },
    imageIntro: {
        backgroundColor: 'transparent',
        transform: [
            {scaleX: 0.20},
            {scaleY: 0.20}
        ],
    }
});

Modal.propTypes = propTypes;
export { Modal };
