let danhMuc = {};
danhMuc.equipmentStatus = {
    "-1" : "Deleted",
    4 : "Available",
    5 : "Repairing",
    6 : "Using",
    7 : "WaitingForSpareParts"
},
danhMuc.orderStatus = {
    "-1" : "Deleted",
    1 : "Pending",
    2 : "Apply",
    3 : "Reject",
},
danhMuc.repaireStatus = {
    "-1" : "Deleted",
    0 : "Completed",
    1 : "Pending",
    2 : "Apply",
    3 : "Reject",
    5 : "Repairing"
},

module.exports = danhMuc;