import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image
} from 'react-native';

import CommonHeader from '../components/header/CommonHeader';
import FontAwesomeSolid from '../components/font/FontAwesomeSolid';
import FontAwesomeLight from '../components/font/FontAwesomeLight';
import FullLine from '../components/line/FullLine';
import LineBold from '../components/line/LineBold';
import gui from '../lib/gui';

import { Actions } from 'react-native-router-flux';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as userAction from '../reducers/user/userActions';
import * as globalAction from '../reducers/global/globalActions';

const actions = [
    userAction,
    globalAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class More extends Component {

    render() {
        return (
            <View style={styles.container}>
                <CommonHeader headerTitle={"More"} />
                {this.renderBodyMore()}
            </View>
        );
    }

    renderBodyMore() {
        return(
            <View style={styles.viewBodyMore}>
                {this.renderUserInfo()}
                <FullLine/>
                <LineBold/>
                <FullLine/>
                {this.renderMoreContent('info-square','Information')}
                <FullLine style={{marginLeft: 16}}/>
                {this.renderMoreContent('comment-alt-lines','Help')}
                <FullLine/>
                <LineBold/>
                <FullLine/>
                {this.renderLogOut()}
                <FullLine/>
                <LineBold/>
                <FullLine/>
            </View>
        )
    }

    renderUserInfo() {
        let {lastName, firstName, phone, avatar} =  this.props.user;
        let avatar1 = 'https://facebook.github.io/react-native/docs/assets/favicon.png';
        console.log('=========lastName', lastName, firstName);
        let fullName = `${lastName} ${firstName}`;
        let uriAvatar =  { uri : avatar1 };
        return(
            <View style={styles.viewUserInfo}>
                <View style={styles.userContent}>
                    <Text style={styles.textUserName}>{fullName}</Text>
                    <Text style={[styles.textCommon, {color: gui.textTimeColor}]}>{phone}</Text>
                </View>
                <View style={styles.viewAvatar}>
                    {/*<View style={styles.borderAvatar}>*/}
                         {/*<FontAwesomeLight*/}
                            {/*color={'rgba(85,85,85,1)'}*/}
                            {/*name={'user'}*/}
                            {/*size={25}*/}
                            {/*/>*/}
                        {/**/}
                    {/*</View>*/}
                    <Image
                        source={uriAvatar} // ? where avatar
                        resizeMode={"cover"}
                        style={styles.userAvatar}
                    />
                </View>
            </View>
        )
    }

    renderMoreContent(name,title ) {
        return(
            <TouchableOpacity style={styles.viewMoreChild}>
                <FontAwesomeSolid
                    color={gui.blurTextColor}
                    name={name}
                    size={17}
                />
                <Text style={[styles.textCommon, {marginLeft: 17}]}>{title}</Text>
            </TouchableOpacity>
        )
    }

    renderLogOut() {
        return(
            <TouchableOpacity style={styles.viewLogout}
                              onPress={this.onSignOut.bind(this)}
            >
                <Text style={[styles.textCommon, {color: 'rgba(255,60,56,1)'}]}>Sign out</Text>
            </TouchableOpacity>
        )
    }

    onSignOut() {
        let dto = {
            code: '',
            userID: '',
            address: '',
            email: '',
            firstName: '',
            lastName: '',
            avatar: '',
            phone: '',
            birthday: '',
            sex: undefined,
            token: '',
            status: undefined
        }
        this.props.actions.onUserAllFieldChange(dto);
        Actions.replace('Welcome')
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'gray',
        fontWeight : '500'
    },
    viewBodyMore: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewUserInfo: {
        width: gui.screenWidth,
        height: 93,
        flexDirection: 'row'
    },
    userContent: {
        height: 93,
        width: gui.screenWidth - 88,
        justifyContent: 'center',
        paddingLeft: 16
    },
    textUserName: {
        color: gui.mainTextColor,
        fontSize: 24,
        fontWeight: '500'
    },
    textCommon: {
        color: gui.mainTextColor,
        fontSize: gui.titleFontSize
    },
    viewAvatar: {
        width: 88,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    borderAvatar: {
        width: 56,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 28,
        borderWidth: 1,
        borderColor: 'lightgray'
    },
    userAvatar: {
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewMoreChild: {
        height: 50,
        width: gui.screenWidth,
        flexDirection: 'row',
        paddingLeft: 16,
        alignItems: 'center'
    },
    viewLogout: {
        height: 50,
        width: gui.screenWidth,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(More)