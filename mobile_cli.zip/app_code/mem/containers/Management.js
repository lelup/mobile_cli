import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity
} from 'react-native';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';

import {Actions} from 'react-native-router-flux';

import * as homeAction from '../reducers/home/homeActions';
import CommonHeader from '../components/header/CommonHeader';
import FontAweSomeSolid from '../components/font/FontAwesomeSolid';
import gui from '../lib/gui';
const actions = [
    homeAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
class Management extends Component {
    render() {
        return (
            <View style={styles.container}>
                <CommonHeader headerTitle={"Equipment manager"} />
                {this.renderBodyManagement()}
            </View>
        );
    }

    renderBodyManagement() {
        return(
            <View style={styles.viewBodyManagement}>
                {this.renderItemsManagement("cogs", "Equipment", this.onEquipment.bind(this))}
                {this.renderItemsManagement("warehouse", "Spare Parts", this.onSpareParts.bind(this))}
            </View>
        )
    }

    renderItemsManagement(name, title, onPress) {
        return(
            <TouchableOpacity style={styles.viewItemsManagement}
                              onPress={onPress}
            >
                <View style={styles.viewIconContent}>
                    <FontAweSomeSolid name={name} fontSize={30} color={'#fff'} mainProps={{marginRight: 0}} />
                </View>
                <View style={styles.viewItemsTitle}>
                    <Text style={styles.textTitle}>{title}</Text>
                </View>
            </TouchableOpacity>
        )
    }

    onEquipment() {
        Actions.MainEquipment();
    }
    onSpareParts() {
        // Actions.OperationHistoryDetail()
        // Actions.OperationHistoryList();
        // Actions.MaintenanceHistoryList();
         Actions.SpareParts();
    }
}




const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: '#000',
        fontWeight : '500'
    },
    textTitle: {
        fontSize: gui.titleFontSize,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    viewBodyManagement: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewItemsManagement: {
        height: 83,
        width: gui.screenWidth - 32,
        flexDirection: 'row',
        marginTop: 16,
        borderRadius: 6
    },
    viewIconContent: {
        height: 83,
        width: 83,
        borderTopLeftRadius: 6,
        borderBottomLeftRadius: 6,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewItemsTitle: {
        height: 83,
        width: gui.screenWidth - 83 - 32,
        borderTopRightRadius: 6,
        borderBottomRightRadius: 6,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Management)