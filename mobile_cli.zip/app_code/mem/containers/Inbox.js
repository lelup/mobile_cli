import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image
} from 'react-native';
import CommonHeader from '../components/header/CommonHeader';
import { Actions } from 'react-native-router-flux';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import gui from '../lib/gui';
import FullLine from '../components/line/FullLine';
class Inbox extends Component {

    constructor(props) {
        super(props);
        let data = [
            {   'name' : 'Nguyen Lam',
                'lastContent' : 'Equipment',
                'time' : '09:32',
                'avatar' : require('../assets/image/goit.jpg')
            },
            {   'name' : 'Bao Nam',
                'lastContent' : 'Soilmec',
                'time' : '08́:12',
                'avatar' : require('../assets/image/kyber.png')
            },
            {   'name' : 'Nguyen Van Dong',
                'lastContent' : 'Avaiable 30',
                'time' : 'Hôm qua',
                'avatar' : require('../assets/image/avatar_default.jpg')
            },
            {   'name' : 'Le Nguyen',
                'lastContent' : '20-Jun-2018',
                'time' : 'Tuần trước',
                'avatar' : require('../assets/image/inno.png')
            },
            {   'name' : 'Hieu',
                'lastContent' : '0976 522 336',
                'time' : 'Tháng tước',
                'avatar' : require('../assets/image/mog.jpg')
            },
            {   'name' : 'Yen Tran',
                'lastContent' : '01234 97856',
                'time' : 'Tháng tước',
                'avatar' : require('../assets/image/aroma.png')
            },
        ];

        this.state = {
            data: data
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <CommonHeader headerTitle={"Inbox"} />
                {this.renderBodyInbox()}
            </View>
        );
    }


    renderBodyInbox() {
        let { data } = this.state;
        return(
            <View style={styles.viewBodyInbox}>
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                />
            </View>
        );
    }

    _renderRow(data) {
        return(
            <View style={styles.viewRow}>
                <TouchableOpacity style={styles.viewRowAlert}>
                    {this._renderAvatar(data)}
                    {this._renderContent(data)}
                    {this._renderTimeContent(data)}
                </TouchableOpacity>
                <FullLine style={{marginLeft: 80}}/>
            </View>
        )
    }

    _renderContent(data) {
        return(
            <View style={styles.viewContent}>
                <Text style={styles.textName} numberOfLines={1}>{data.name}</Text>
                <Text style={styles.textTime} numberOfLines={1}>{data.lastContent}</Text>
            </View>
        )
    }

    _renderAvatar(data) {
        return(
            <View style={styles.viewAvatar}>
                <Image style={styles.imageStyle}
                       source={data.avatar}
                       resizeMode={'cover'}
                />
            </View>
        )
    }

    _renderTimeContent(data) {
        return(
            <View style={styles.timeContent}>
                <Text style={[styles.textTime, {marginTop: 0}]}>{data.time}</Text>
            </View>
        )
    }

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'yellow',
        fontWeight : '500'
    },
    viewBodyInbox: {
        flex: 1,
        backgroundColor: '#fff',
        paddingBottom: 50
    },
    viewListContainer: {
        flex: 1
    },
    viewRow: {
        height: 75,
        width: gui.screenWidth
    },
    viewRowAlert: {
        height: 74,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewAvatar: {
        height: 74,
        width: 80,
        paddingLeft: 16,
        justifyContent: 'center'
    },
    imageStyle: {
        height: 50,
        width: 50,
        borderRadius: 25
    },
    timeContent: {
        height: 74,
        width: 100,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewContent: {
        height: 74,
        width: gui.screenWidth - 180,
        justifyContent: 'center'
    },
    textName: {
        color: gui.mainTextSolid,
        fontSize: gui.memSizeText
    },
    textTime: {
        color: gui.textTimeColor,
        fontSize: gui.memSizeText,
        marginTop: 2
    }
});

export default Inbox;