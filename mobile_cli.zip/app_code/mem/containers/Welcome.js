import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    TextInput,
    TouchableOpacity,
    Alert,
    ActivityIndicator
} from 'react-native';

import gui from '../lib/gui';
import { Actions } from 'react-native-router-flux';
import LinearGradient from 'react-native-linear-gradient';
import FontAwesomeLight from '../components/font/FontAwesomeLight';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as userAction from '../reducers/user/userActions';
import * as globalAction from '../reducers/global/globalActions';
const actions = [
    userAction,
    globalAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class Welcome extends Component {
    constructor(props){
        super(props);
        this.state = {
            username: '',
            password: ''
        }
    }

    render() {
        let imageUri = require('../assets/image/imageSplash.jpg');
        return(
            <View style={styles.container}>
                <ImageBackground style={styles.imgSplash}
                                 resizeMode={'stretch'}
                                 source={imageUri} defaultSource={imageUri}>
                    <LinearGradient colors={['rgba(60, 60, 60, 0.5)', 'rgba(60, 60, 60, 0.5)']}
                                    style={styles.linearGradient}>
                        {this._renderViewLogo()}
                        {this._renderInputUser()}
                        {this._renderInputPassword()}
                        {this._renderButtonLogin()}
                    </LinearGradient>
                </ImageBackground>
            </View>
        )
    }

    _renderViewLogo() {
        let imageLogo = require('../assets/image/logo.png');
        let textWelCome = 'Welcome to MEM';
        return(
            <View style={styles.viewLogoMiti}>
                <Image source={imageLogo} style={styles.imageLogo}/>
                <Text style={styles.welcomeMiti}>{textWelCome}</Text>
            </View>
        );
    }
    _renderInputUser() {
        let { username } = this.state;
        return(
            <View style={styles.viewInputUser}>
                <View style={styles.viewIconUser}>
                    <FontAwesomeLight
                        color={'#fff'}
                        name={'user'}
                        size={19}
                    />
                </View>
                <TextInput
                    autoFocus={false}
                    autoCapitalize='none'
                    autoCorrect={false}
                    returnKeyType='done'
                    underlineColorAndroid='rgba(0,0,0,0)'
                    style={styles.viewTextInput}
                    selectionColor={'#fff'}
                    placeholder="Username" placeholderTextColor={'#fff'}
                    onChangeText={(text) => {this._onUsernameTextChange(text)}}
                    value={username}
                />
            </View>
        )
    }

    _renderInputPassword() {
        let { password } = this.state;
        return(
            <View style={[styles.viewInputUser, {marginTop: 40}]}>
                <View style={styles.viewIconUser}>
                    <FontAwesomeLight
                        color={'#fff'}
                        name={'key'}
                        size={17}
                    />
                </View>
                <TextInput
                    autoFocus={false}
                    autoCapitalize='none'
                    autoCorrect={false}
                    secureTextEntry={true}
                    returnKeyType='done'
                    underlineColorAndroid='rgba(0,0,0,0)'
                    style={styles.viewTextInput}
                    selectionColor={'#fff'}
                    placeholder="Password" placeholderTextColor={'#fff'}
                    onChangeText={(text) => {this._onPasswordTextChange(text)}}
                    value={password}
                />
            </View>
        )
    }

    _renderButtonLogin() {
        return(
            <TouchableOpacity style={styles.viewButtonLogin}
                              onPress={this._onLoginPress.bind(this)}
            >
                { this.props.user.isLoginRequest ?
                    <ActivityIndicator color={"#fff"} size={"small"}/> : <Text style={styles.textLogin}>LOGIN</Text>
                }
            </TouchableOpacity>
        );
    }

    _onLoginPress() {
        let { username, password } = this.state;
        let dto = {
            email: username,
            password: password
        };
        this.props.actions.userLogin(dto).then((res) => {
            if (res.status == 200) {
                Actions.Home()
            } else {
                Alert.alert('Error', 'Oops, something went wrong!')
            }
        })
            .catch((res) => {
                Alert.alert('Error', 'username or password is incorrect!')
            });
    }

    _onUsernameTextChange(value) {
        this.setState({
            username: value
        })
    }

    _onPasswordTextChange(value) {
        this.setState({
            password: value
        })
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    imgSplash: {
        width: gui.screenWidth,
        height: gui.screenHeight,
        alignSelf: 'auto'
    },
    linearGradient: {
        marginTop: 0,
        height: gui.screenHeight,
        width: gui.screenWidth,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewLogoMiti: {
        height: 'auto',
        width: gui.screenWidth,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 90
    },
    imageLogo: {
        height: 34,
        width: 141
        // transform: [
        //     {scaleX: 0.3},
        //     {scaleY: 0.3}
        // ]
    },
    welcomeMiti: {
        color: '#fff',
        fontSize: 24,
        marginTop: 24
    },
    viewInputUser: {
        height: 30,
        width: gui.screenWidth - 60,
        marginLeft: 30,
        marginRight: 30,
        marginTop: gui.screenHeight/4 - 10,
        flexDirection: 'row'
    },
    viewTextInput: {
        height: 30,
        width: gui.screenWidth - 90,
        fontSize: gui.normalFontSize,
        borderBottomWidth:1,
        borderColor:'#fff',
        marginLeft: 10,
        color: '#fff',
        marginRight: 30,
        paddingVertical: gui.paddingVertical
    },
    viewIconUser: {
        height: 30,
        width: 20,
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: 5
    },
    viewButtonLogin: {
        height: 42,
        width: gui.screenWidth - 60,
        marginLeft: 30,
        marginRight: 30,
        borderRadius: 21,
        marginTop: gui.screenHeight/6 - 6,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textLogin: {
        color: '#fff',
        fontSize: gui.normalFontSize,
        fontWeight: 'bold'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Welcome);