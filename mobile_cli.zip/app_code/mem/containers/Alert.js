import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    TouchableOpacity,
    Image
} from 'react-native';

import CommonHeader from '../components/header/CommonHeader';
import gui from '../lib/gui';
import FullLine from '../components/line/FullLine';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as userAction from '../reducers/user/userActions';
import * as alertAction from '../reducers/alert/alertActions';
const actions = [
    userAction,
    alertAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class Alert extends Component {
    constructor(props) {
        super(props);
        let data = [
            {   'name' : 'Hong Tham',
                'content' : 'Order 15 bolts for Soilmec (ABC123)',
                'unreadNoti': true,
                'avatar' : require('../assets/image/mind.jpg'),
                'equipmentUrl' : require('../assets/image/bolts.jpg')
            },
            {   'name' : 'Hung Nguyen',
                'content' : 'Order 1 Crane forHoi An project',
                'unreadNoti': false,
                'avatar' : require('../assets/image/learn.jpg'),
                'equipmentUrl' : require('../assets/image/crane.jpg')
            },
            {   'name' : 'Viet Hoang',
                'content' : 'Order 1000 litre Oil Soilmec (ABC123)',
                'unreadNoti': false,
                'avatar' : require('../assets/image/inno.png'),
                'equipmentUrl' : require('../assets/image/oil.jpg')
            },
            {   'name' : 'Tran Dong Do',
                'content' : 'Order 75 bolts for Soilmec (ABC123)',
                'unreadNoti': false,
                'avatar' : require('../assets/image/avatar_default.jpg'),
                'equipmentUrl' : require('../assets/image/bolts.jpg')
            },
            {   'name' : 'Hong Tham',
                'content' : 'Order 1500 litre Oil Soilmec (ABC123)',
                'unreadNoti': true,
                'avatar' : require('../assets/image/landber.png'),
                'equipmentUrl' : require('../assets/image/oil.jpg')
            },
            {   'name' : 'Hong Tham',
                'content' : 'Order 15 bolts for Soilmec (ABC123)',
                'unreadNoti': false,
                'avatar' : require('../assets/image/avatar_default.jpg'),
                'equipmentUrl' : require('../assets/image/bolts.jpg')
            },
        ];

        this.state = {
            alertList: props.alert.alertList
        }
    }

    componentWillReceiveProps(nextProps) {
        if(this.props.alert.alertList !== nextProps.alert.alertList) {
            this.setState({ alertList: nextProps.alert.alertList})
        }
    }
    render() {
        return (
            <View style={styles.container}>
                <CommonHeader headerTitle={"Alert"} />
                {this.renderBodyAlert()}
            </View>
        );
    }

    renderBodyAlert() {
        let { alertList } = this.state;
        console.log("=========> this.state.alertList",this.state.alertList);
        return(
            <View style={styles.viewBodyAlert}>
                <FlatList
                    data={alertList}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListContainer}
                />
            </View>
        )
    }

    _renderRow(data) {
        let color =  data.unread == 0 ? 'rgba(241,247,255,1)' : '#fff';
        return(
            <View style={styles.viewRow}>
                <TouchableOpacity style={[styles.viewRowAlert, {backgroundColor: color}]}>
                    {this._renderAvatar(data)}
                    {this._renderContent(data)}
                    {this._renderImageQuipment(data)}
                </TouchableOpacity>
                <FullLine />
            </View>
        )
    }

    _renderAvatar(data) {
        let avatarSource = 'https://facebook.github.io/react-native/docs/assets/favicon.png';
        let avatarUserOrder = { uri : avatarSource };
        return(
            <View style={styles.viewAvatar}>
                <Image style={styles.imageStyle}
                       source={avatarUserOrder}
                       resizeMode={'cover'}
                />
            </View>
        )
    }

    _renderContent(data) {
        let name = data.name;
        let content = ` ${data.content}`;
        return(
            <View style={styles.viewContent}>
                <View style={[styles.viewContent, {height: 48, justifyContent: 'flex-start', paddingTop: 8}]}>
                    {/*<Text style={styles.textName} numberOfLines={2}>*/}
                        {/*{name}*/}
                        {/*<Text style={styles.textTime} numberOfLines={1}>{content}</Text>*/}
                    {/*</Text>*/}
                    <Text style={[styles.textTime, {color: gui.mainTextColor}]} numberOfLines={2}>{content}</Text>
                </View>
                <View style={[styles.viewContent, {height: 34, alignItems: 'center', flexDirection: 'row'}]}>
                    <TouchableOpacity style={styles.viewButtonNoti}>
                        <Text style={styles.textNotiButton}>APPROVE</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.viewButtonReject}>
                        <Text style={[styles.textNotiButton, {color: gui.mainTextColor}]}>REJECT</Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _renderImageQuipment(data) {
        let equipmentUrl = { uri : data.img };
        return(
            <View style={styles.equipmentContent}>
                <Image style={styles.imageEquipmentStyle}
                       source={equipmentUrl}
                       resizeMode={'cover'}
                />
            </View>
        )
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 14,
        color: 'green',
        fontWeight : '500'
    },
    viewBodyAlert: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        flex: 1
    },
    viewRow: {
        height: 83,
        width: gui.screenWidth
    },
    viewRowAlert: {
        height: 82,
        width: gui.screenWidth,
        flexDirection: 'row'
    },
    viewAvatar: {
        height: 82,
        width: 80,
        paddingLeft: 12,
        justifyContent: 'center'
    },
    imageStyle: {
        height: 58,
        width: 58,
        borderRadius: 29
    },
    imageEquipmentStyle: {
        height: 66,
        width: 94,
    },
    equipmentContent: {
        height: 82,
        width: 106,
        paddingRight: 12,
        justifyContent: 'center',
        alignItems: 'flex-end',
    },
    viewContent: {
        height: 82,
        width: gui.screenWidth - 186,
        justifyContent: 'center'
    },
    textName: {
        color: gui.mainTextSolid,
        fontSize: gui.memSizeText,
        fontWeight: '500'
    },
    textTime: {
        color: gui.textTimeColor,
        fontSize: gui.memSizeText
    },
    viewButtonNoti: {
        paddingVertical: 5,
        paddingHorizontal: 9,
        backgroundColor: gui.mainColor,
        borderRadius: 3,
    },
    viewButtonReject: {
        paddingVertical: 5,
        paddingHorizontal: 9,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(137,137,137,0.5)',
        borderRadius: 3,
        marginLeft: 5
    },
    textNotiButton: {
        color: '#fff',
        fontSize: gui.smallFontSize
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Alert);