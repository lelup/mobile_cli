import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
} from "react-native";

import {
    Scene,
    Router,
    Tabs
} from "react-native-router-flux";

import { connect } from 'react-redux';

const RouterWithRedux = connect()(Router);

import Management from "./Management";
import Inbox from "./Inbox";
import Alert from "./Alert";
import More from "./More";
import Welcome from "./Welcome";
import TabIcon from "../components/tab/TabIcon";

import EquipmentList from "../components/equipment/EquipmentList";
import EquipmentDetail from "../components/equipment/EquipmentDetail";
import SparePartsDetail from "../components/equipment/SparePartsDetail";
import OperationHistoryList from "../components/equipment/OperationHistoryList";
import OperationHistoryDetail from "../components/equipment/OperationHistoryDetail";
import MaintenanceHistoryList from "../components/equipment/MaintenanceHistoryList";
import MaintenanceHistory from "../components/equipment/MaintenanceHistory";
import MainEquipment from "../components/equipment/MainEquipment";
import SpareParts from "../components/equipment/SpareParts";

import gui from '../lib/gui';
const AppScene = () => (
    <View style={{ flex: 1 }}>
        <RouterWithRedux>
            <Scene key="root" hideNavBar={true}
                   titleStyle={styles.titleStyle} duration={500}
            >
                <Scene key='Welcome' component={Welcome} hideNavBar={true} initial={true} />
                <Tabs key="Home"
                      gestureEnabled={false}
                      tabBarPosition="bottom"
                      showLabel={false}
                      tabs tabBarStyle={styles.tabBarStyle}
                      activeBackgroundColor="#fff"
                      animationEnabled={false}
                >
                    <Scene
                        key="Management"
                        component={Management}
                        title="MANAGEMENT"
                        hideNavBar={true}
                        icon={TabIcon}
                        iconSize={22}
                        iconName={"users"}
                        selectedIconName={"users"}
                        navigationBarStyle={{ backgroundColor: gui.mainColor }}
                        titleStyle={{ color: 'white', alignSelf: 'center' }}
                    />
                    <Scene
                        key="Inbox"
                        component={Inbox}
                        title="INBOX"
                        hideNavBar={true}
                        icon={TabIcon}
                        iconSize={22}
                        iconName={"comment"}
                        selectedIconName={"comment"}
                        navigationBarStyle={{ backgroundColor: gui.mainColor }}
                        titleStyle={{ color: 'white', alignSelf: 'center' }}
                    />
                    <Scene
                        key="Alert"
                        component={Alert}
                        title="ALERT"
                        hideNavBar={true}
                        icon={TabIcon}
                        iconSize={22}
                        iconName={"bell"}
                        selectedIconName={"bell"}
                        navigationBarStyle={{ backgroundColor: gui.mainColor }}
                        titleStyle={{ color: 'white', alignSelf: 'center' }}
                    />
                    <Scene
                        key="More"
                        component={More}
                        title="MORE"
                        hideNavBar={true}
                        icon={TabIcon}
                        iconSize={22}
                        iconName={"bars"}
                        selectedIconName={"bars"}
                        navigationBarStyle={{ backgroundColor: gui.mainColor }}
                        titleStyle={{ color: 'white', alignSelf: 'center' }}
                    />
                </Tabs>
                <Scene key="EquipmentList" component={EquipmentList} title={"EquipmentList"} hideNavBar={true} />
                <Scene key="EquipmentDetail" component={EquipmentDetail} title={"EquipmentDetail"} hideNavBar={true} />
                <Scene key="SparePartsDetail" component={SparePartsDetail} title={"SparePartsDetail"} hideNavBar={true} />
                <Scene key="OperationHistoryList" component={OperationHistoryList} title={"OperationHistoryList"} hideNavBar={true} />
                <Scene key="OperationHistoryDetail" component={OperationHistoryDetail} title={"OperationHistoryDetail"} hideNavBar={true} />
                <Scene key="MaintenanceHistoryList" component={MaintenanceHistoryList} title={"MaintenanceHistoryList"} hideNavBar={true} />
                <Scene key="MaintenanceHistory" component={MaintenanceHistory} title={"MaintenanceHistory"} hideNavBar={true} />
                <Scene key="MainEquipment" component={MainEquipment} title={"MainEquipment"} hideNavBar={true} />
                <Scene key="SpareParts" component={SpareParts} title={"SpareParts"} hideNavBar={true} />
            </Scene>
        </RouterWithRedux>
    </View>
);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
    },
    tabBarStyle: {
        backgroundColor: "#fff",
        height: 49,
        borderTopWidth: 1,
        borderTopColor: 'rgba(235,235,235,1)'
    },
    titleStyle: {
        color: 'white'
    }
});

export default AppScene;
