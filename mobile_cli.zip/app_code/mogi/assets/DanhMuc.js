import moment from 'moment';

var _ = require('lodash');
import log from '../lib/logUtil';
var danhMuc = {};

danhMuc.BAT_KY = "Bất kỳ";
danhMuc.BIG =9999999;
danhMuc.CHUA_XAC_DINH = "Chưa xác định";
danhMuc.THOA_THUAN = "Thỏa thuận";
danhMuc.TIN_CHO_DUYET = "Chờ duyệt";
danhMuc.KHONG_RO = "Không rõ";
danhMuc.VND = "₫";
danhMuc.NGHIN = "nghìn";
danhMuc.TRIEU = "triệu";
danhMuc.TY = "tỷ";

danhMuc.infoTypeCode = [1];

danhMuc.blacklistDuAnWebsites = [
    'http://batdongsan.com.vn',
    'https://batdongsan.com.vn'
];

var {BAT_KY, BIG, THOA_THUAN, CHUA_XAC_DINH} = danhMuc;

danhMuc.sellStepValues = [-1, 0, 500, 800, 1000, 2000, 3000, 5000, 7000, 10000, 20000, 30000]; //trieu

danhMuc.rentStepValues = [-1, 0, 1, 3, 5, 10, 40, 70, 100]; //by month

danhMuc.dienTichStepValues = [-1, 0, 30, 50, 80, 100, 150, 200, 250, 300, 500];

danhMuc.userQuestion1 = {
    'buyTrue' : 'Lần đầu mua nhà',
    'buyFalse' : 'Đã mua nhà trước đây'
};

danhMuc.userQuestion2 = {
    'zeroToThree' : '0 - 3 tháng',
    'threeToSix' : '3 - 6 tháng',
    'sixToYear' : '6 - 12 tháng',
    'timeOverYear' : '12+ tháng',
    'timeToUnlimit' : 'Tôi chưa biết'
};

danhMuc.userQuestion3 = {
    'canHoChungCu' : 'Căn hộ chung cư',
    'loaiNhaRieng' : 'Nhà riêng',
    'loaiBietThu' : 'Biệt thự, liền kề',
    'loaiMatPho' : 'Nhà mặt phố'
};

danhMuc.hiddenAdsUser = {
    'currentAds' : 'Tin hiện tại',
    'adsFromUser' : 'Tin cùng người đăng'
};

danhMuc.contactSaleState = {
    1 : 'Khách nét',
    2 : 'Khách mới',
    3 : 'Không mua nữa',
    4 : 'Đã mua',
};

danhMuc.contactTextLevel = {
    'Khách nét' : 'rgba(49,207,100,1)',
    'Khách mới' : 'rgba(56,151,241,1)',
    'Không mua nữa' : 'rgba(237,28,36,1)',
    'Đã mua' : 'rgba(169,183,200,1)',
    'Yêu thích' : 'rgba(255,207,86,1)'
};

danhMuc.eventFilter = {
    'today' : 'Hôm nay',
    '1day' : 'Ngày mai',
    '7day' : '7 ngày tiếp theo',
    '30day' : '30 ngày tiếp theo',
    'distance' : 'Chọn khoảng thời gian'
};

danhMuc.contactType = {
    1 : 'Khách hàng',    
    2 : 'Môi giới',
    3 : 'Nhà đầu tư',
}
danhMuc.reasonHiddenAds = {
    'currentAds': {
        'firstReason' : 'Nhà không có thật',
        'secondReason' : 'Nhà đã bán hoặc cho thuê',
        'thirdReason' : 'Nhà bị trùng lặp',
        'otherReason' : 'Khác'
    },
    'adsFromUser': {
        'firstReason' : 'Người dùng đăng tin trùng lặp',
        'secondReason' : 'Người dùng đăng tin sai sự thật',
        'otherReason' : 'Khác'
    }
};

danhMuc.reasonHidden = {
    0 : 'Nhà không có thật',
    1 : 'Nhà đã bán hoặc cho thuê',
    2 : 'Nhà bị trùng lặp',
    3 : 'Khác'
};

danhMuc.reasonHiddenKey = [
    0,
    1,
    2,
    3
];

danhMuc.loaiTin = {
    0 : "Bán",
    1  : "Cho Thuê"
};

danhMuc.loaiTinWTo = {
    0 : "Cần mua",
    1  : "Cần Thuê"
};

danhMuc.doUuTien = {
    0 : "Cao",
    1 : "Bình thường",
    2 : "Thấp"
};

danhMuc.levelWishlistColor = {
    'hot': 'rgba(255,81,81,1)',
    'warm' : 'rgba(255,207,86,1)',
    'inactive': 'rgba(169,183,200,1)'
};

danhMuc.LoaiNhaCanMua = {
    0 : BAT_KY,
    1  : "Cần mua căn hộ chung cư",
    2  : "Cần mua nhà riêng",
    3  : "Cần mua biệt thự, liền kề",
    4  : "Cần mua nhà mặt phố",
    5  : "Cần mua đất nền dự án",
    6  : "Cần mua đất",
    7  : "Cần mua trang trại, khu nghỉ dưỡng",
    8  : "Cần mua kho, nhà xưởng",
    99 : "Cần mua loại bất động sản khác"
}

danhMuc.LoaiNhaCanThue = {
    0 : BAT_KY,
    1 : "Cần thuê căn hộ chung cư",
    2 : "Cần thuê nhà riêng",
    3 : "Cần thuê nhà mặt phố",
    4 : "Cần thuê nhà trọ, phòng trọ",
    5 : "Cần thuê văn phòng",
    6 : "Cần thuê cửa hàng, ki-ốt",
    7 : "Cần thuê kho, nhà xưởng, đất",
    99: "Cần thuê loại bất động sản khác"
}

danhMuc.LoaiNhaDatBan = {
    0 : BAT_KY,
    1  : "Bán căn hộ chung cư",
    2  : "Bán nhà riêng",
    3  : "Bán biệt thự, liền kề",
    4  : "Bán nhà mặt phố",
    5  : "Bán đất nền dự án",
    6  : "Bán đất",
    7  : "Bán trang trại, khu nghỉ dưỡng",
    8  : "Bán kho, nhà xưởng",
    99 : "Bán loại bất động sản khác"
}

danhMuc.LoaiNhaDatThue = {
    0 : BAT_KY,
    1 : "Cho Thuê căn hộ chung cư",
    2 : "Cho Thuê nhà riêng",
    3 : "Cho Thuê nhà mặt phố",
    4 : "Cho Thuê nhà trọ, phòng trọ",
    5 : "Cho Thuê văn phòng",
    6 : "Cho Thuê cửa hàng, ki-ốt",
    7 : "Cho Thuê kho, nhà xưởng, đất",
    99: "Cho Thuê loại bất động sản khác"
}

danhMuc.dienTich = {
    0: 'Bất kỳ',
    1: 'Chưa xác định',
    2: '0 m² - 30 m²',
    3: '30 m² - 50 m²',
    4: '50 m² - 80 m²',
    5: '80 m² - 100 m²',
    6: '100 m² - 150 m²',
    7: '150 m² - 200 m²',
    8: '200 m² - 250 m²',
    9: '250 m² - 300 m²',
    10: '300 m² - 500 m²',
    11: '500 m² - Bất kỳ'
};

danhMuc.giaBan = {
    0: 'Bất kỳ',
    1: 'Thỏa thuận',
    2: '0 triệu - 500 triệu',
    3: '500 triệu - 800 triệu',
    4: '800 triệu - 1 tỷ',
    5: '1 tỷ - 2 tỷ',
    6: '2 tỷ - 3 tỷ',
    7: '3 tỷ - 5 tỷ',
    8: '5 tỷ - 7 tỷ',
    9: '7 tỷ - 10 tỷ',
    10: '10 tỷ - 20 tỷ',
    11: '20 tỷ - 30 tỷ',
    12: '30 tỷ - Bất kỳ'
};

danhMuc.hasImage = {
    0: 'Tin có ảnh',
    1: 'Tất cả tin rao'
};

danhMuc.excludeMoiGioi = {
    0: 'Bỏ tin đăng của môi giới đề xuất bởi Landber',
    1: 'Tất cả tin rao'
};

danhMuc.giaThue = {
    0: 'Bất kỳ',
    1: 'Thỏa thuận',
    2: '0 triệu - 1 triệu',
    3: '1 triệu - 3 triệu',
    4: '3 triệu - 5 triệu',
    5: '5 triệu - 10 triệu',
    6: '10 triệu - 40 triệu',
    7: '40 triệu - 70 triệu',
    8: '70 triệu - 100 triệu',
    9: '100 triệu - Bất kỳ'
};

danhMuc.LoaiNhaDatBanKey = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    99
];

danhMuc.LoaiNhaDatThueKey = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    99
];

danhMuc.LoaiNhaCanMuaKey = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    99
];

danhMuc.LoaiNhaCanThueKey = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    99
];

danhMuc.SoPhongNgu = {
    0: BAT_KY,
    1: "1+",
    2: "2+",
    3: "3+",
    4: "4+",
    5: "5+"
}

danhMuc.SoNgayAnTin = {
    1: '1 ngày',
    7: '7 ngày',
    30: '30 ngày',
    365: '365 ngày'
}


danhMuc.soNgayIndex = {
    0: "1",
    1: "7",
    2: "30",
    3: "365"
};

danhMuc.SoTang = {
    0: BAT_KY,
    1: "1+",
    2: "2+",
    3: "3+",
    4: "4+",
    5: "5+"
}

danhMuc.SoPhongTam = {
    0: BAT_KY,
    1: "1+",
    2: "2+",
    3: "3+",
    4: "4+",
    5: "5+"
}

danhMuc.AdsSoPhongNgu = {
    1: "1",
    2: "2",
    3: "3",
    4: "4",
    5: "5",
    6: "6",
    7: "7"
}

danhMuc.AdsSoTang = {
    1: "1",
    2: "2",
    3: "3",
    4: "4",
    5: "5",
    6: "6",
    7: "7"
}

danhMuc.AdsSoPhongTam = {
    1: "1",
    2: "2",
    3: "3",
    4: "4",
    5: "5",
    6: "6",
    7: "7"
}

danhMuc.RadiusInKm = {
    0.5: "0.5",
    1: "1",
    2: "2",
    3: "3",
    4: "4",
    5: "5"
}

danhMuc.RadiusInKmKey = [
    0.5,
    1,
    1.5,
    2,
    2.5,
    3,
    3.5,
    4,
    4.5,
    5
]

danhMuc.NgayDaDang = {
    0: BAT_KY,
    1: "1 ngày",
    3: "3 ngày",
    7: "7 ngày",
    14: "14 ngày",
    30: "30 ngày",
    90: "90 ngày"
}

danhMuc.NgayDaDangKey = [
    0,
    1,
    3,
    7,
    14,
    30,
    90
]

danhMuc.HuongNha = {
    0: BAT_KY,
    "-1" : CHUA_XAC_DINH,
    1: "Đông",
    2: "Tây",
    3: "Nam",
    4: "Bắc",
    5: "Đông-Bắc",
    6: "Tây-Bắc",
    7: "Đông-Nam",
    8: "Tây-Nam"
}

danhMuc.HuongNhaKey = [
    0,
    -1,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8
];

danhMuc.typeMainAvt = {
    'Sàn' : "users",
    'Bài viết' : "file",
    'Liên hệ' : "user"
}

danhMuc.GioiTinh = {
    'U': "Không rõ",
    'F': "Nữ",
    'M': "Nam"
};

danhMuc.GioiTinhKey = [
    'U',
    'F',
    'M'
];

danhMuc.MoiGioi = {
    'U': "Không xác định",
    'Y': "Môi Giới",
    'N': "Chính chủ"
};

danhMuc.MoiGioiKey = [
    'U',
    'Y',
    'N'
];

danhMuc.LoaiTin = {
    0: "Bán",
    1: "Cho thuê"
};

danhMuc.LoaiTinType = {
    'ban': 'Bán',
    'thue': 'Cho thuê'
};

danhMuc.LoaiTinWToType = {
    'mua': 'Cần mua',
    'thue': 'Cần thuê'
};

danhMuc.DoUuTienType = {
    'high': 'Cao',
    'medium': 'Bình thường',
    'low': 'Thấp'
};

danhMuc.MapText = {
    "Standard": "T.thường",
    "Satellite": "Vệ tinh",
    "Hybrid": "Hỗn hợp"
};

danhMuc.MapType = [
    "Standard",
    "Satellite",
    "Hybrid"
];


danhMuc.CHAT_MESSAGE_TYPE ={
    TEXT: 1,
    IMAGE:2,
    LOCATION:3,
    FILE: 4,
    SYSTEM: 5,
    VIDEO_CALL: 6,
    ADS: 7,
    WTO: 8,
};

danhMuc.DonViTien = {
    1: "Triệu",
    2: "Tỷ",
    3: "Trăm nghìn/m²",
    4: "Triệu/m²",
    5: THOA_THUAN
};

danhMuc.DonViTienKey = [
    1,
    2,
    3,
    4,
    5
];

danhMuc.AdsAlertUs = {
    1: "Nhà không có thật",
    2: "Nhà đã bán hoặc cho thuê",
    3: "Nhà bị trùng lặp",
    6: "Khác"
};

danhMuc.AdsAlertUsKey = [
    1,
    2,
    3,
    6
];

danhMuc.goiTin = [
    "7",
    "15",
    "30"
];

danhMuc.placeType = {
    TINH: "T",
    HUYEN: "H",
    XA: "X",
    DU_AN: "A",
    DUONG: "D",
    DIA_DIEM: "V"
};

danhMuc.phamViChat = {
    0  : "all",
    1  : "personal",
    2  : "group",
}

danhMuc.eventType = {
    1 : "Dẫn khách xem nhà",
    2 : "Gửi thông tin cho khách",
    3 : "Khác"
};

danhMuc.levelNotifyNote = {
    0 : "Cao",
    1 : "Bình thường",
    2 : "Thấp"
};

danhMuc.allCategoryName = {
    'cam-nang': 'Cẩm nang' ,
    'thi-truong': 'Thị trường' ,
    'tin-thi-truong': 'Tin thị trường' ,
    'phan-tich': 'Phân tích' ,
    'nhan-dinh': 'Nhận định' ,
    'chinh-sach': 'Chính sách' ,
    'quan-ly': 'Quản lý' ,
    'thong-tin-quy-hoach': 'Quy hoạch' ,
    'bat-dong-san-the-gioi': 'BĐS thế giới',
    'tai-chinh': 'Tài chính' ,
    'chung-khoan': 'Chứng khoán' ,
    'du-an': 'Dự án' ,
    'can-ho-chung-cu': 'Căn hộ chung cư' ,
    'biet-thu-lien-ke': 'Biệt thự liền kề' ,
    'trung-tam-thuong-mai': 'Trung tâm t.mại' ,
    'khu-du-lich-nghi-duong': 'Khu d.lịch nghỉ dưỡng',
    'cao-oc-van-phong': 'Cao ốc văn phòng' ,
    'du-an-khac': 'Dự án khác' ,
    'noi-ngoai-that': 'Nội ngoại thất' ,
    'phong-thuy': 'Phong thủy' ,
    'phong-thuy-voi-cuoc-song': 'Ph.thủy c.sống',
    'phong-thuy-nha-o': 'Ph.thuỷ nhà ở' ,
    'phong-thuy-van-phong': 'Ph.thuỷ văn phòng' ,
    'phong-thuy-theo-tuoi': 'Ph.thuỷ theo tuổi' ,
    'tu-vi-nam-2017': 'Tử vi năm 2017' ,
    'xay-dung-kien-truc': 'X.dựng - K.trúc' ,
    'xay-dung': 'Xây dựng' ,
    'kien-truc': 'Kiến trúc' ,
    'video': 'Video' ,
    'tai-lieu': 'Tài liệu' ,
    'tu-van-luat': 'Tư vấn luật' ,
    'tin-cho-thue': 'Tin cho thuê',
    'gioi-thieu': 'Giới thiệu',
    'nha-dat-ha-noi': 'Nhà đất Hà Nội',
    'chung-cu-gia-re-ho-chi-minh': 'Chung cư giá rẻ HCM'    
};

danhMuc.getPhamViChatValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.phamViChat);
}

danhMuc.getPhamViChatForDisplay = function(phamViChatKey){
    var value = danhMuc.phamViChat[phamViChatKey];

    if (!value)
        value = BAT_KY;

    return value;
};

danhMuc.getOrderKey = function (key) {
    return key.indexOf("DESC") !== -1 ? key.substring(0, key.length-4) :
        key.substring(0, key.length-3);
}

danhMuc.getOrderType = function (key) {
    return (key && key.indexOf("ASC") !== -1) ? "ASC" : "DESC";
}

danhMuc.getDateFromNow = function (days) {
    if (!days || days == '') {
        return undefined;
    }
    return moment().subtract(days, 'days').format('YYYYMMDD');
}

danhMuc.getDanhMucKeys = function (hashDanhMuc) {
    var result = [];
    for (var k in hashDanhMuc) {
        result.push(k);
    }
    return result;
}

danhMuc.getDanhMucValues = function (hashDanhMuc) {
    var result = [];
    for (var k in hashDanhMuc) {
        result.push(hashDanhMuc[k]);
    }
    return result;
}

danhMuc.getDanhMucHuongNhaValues = function () {
    var result = [];
    for (var i=0; i<danhMuc.HuongNhaKey.length; i++) {
        var k = danhMuc.HuongNhaKey[i];
        result.push(danhMuc.HuongNha[k]);
    }
    return result;
}

danhMuc.getGioiTinhValues = function () {
    var result = [];
    for (var i=0; i<danhMuc.GioiTinhKey.length; i++) {
        var k = danhMuc.GioiTinhKey[i];
        result.push(danhMuc.GioiTinh[k]);
    }
    return result;
}

danhMuc.getMoiGioiValues = function () {
    var result = [];
    for (var i=0; i<danhMuc.MoiGioiKey.length; i++) {
        var k = danhMuc.MoiGioiKey[i];
        result.push(danhMuc.MoiGioi[k]);
    }
    return result;
}


danhMuc.getLoaiNhaCanMuaValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.LoaiNhaCanMua);
}

danhMuc.getLoaiNhaCanThueValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.LoaiNhaCanThue);
}

danhMuc.getLoaiNhaDatBanValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.LoaiNhaDatBan);
}

danhMuc.getLoaiNhaDatThueValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.LoaiNhaDatThue);
}

danhMuc.getSoPhongNguValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.SoPhongNgu);
}

danhMuc.getSoNgayAnValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.SoNgayAnTin);
}

danhMuc.getSoTangValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.SoTang);
}

danhMuc.getSoPhongTamValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.SoPhongTam);
}

danhMuc.getAdsSoPhongNguValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.AdsSoPhongNgu);
}

danhMuc.getAdsSoTangValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.AdsSoTang);
}

danhMuc.getAdsSoPhongTamValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.AdsSoPhongTam);
}

danhMuc.getHuongNhaValues = function () {
    return danhMuc.getDanhMucHuongNhaValues();
}

danhMuc.getDonViTienValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.DonViTien);
}

danhMuc.getAdsAlertUsValues = function () {
    return danhMuc.getDanhMucValues(danhMuc.AdsAlertUs);
}

danhMuc.getRadiusInKmValues = function () {
    return ["0.5", "1", "2", "3", "4", "5"];
}

danhMuc.getNgayDaDangValues = function () {
    return danhMuc.NgayDaDangKey;
}

danhMuc.findLevelNotifyNoteValues = function(){
    return _.values(danhMuc.levelNotifyNote)
};

danhMuc.findEventTypeValues = function(){
    return _.values(danhMuc.eventType)
};

danhMuc.findLevelNotifyNoteKey = function(value){
    return danhMuc.findKey(danhMuc.levelNotifyNote, value);
};

danhMuc.findEventTypeKey = function(value){
    return danhMuc.findKey(danhMuc.eventType, value);
};

danhMuc.getLoaiNhaDatForDisplay = function(loaiTin, loaiNhaDatKey){
    var value = '';
    if (loaiTin == 'ban')
        value = danhMuc.LoaiNhaDatBan[loaiNhaDatKey];

    if (loaiTin == 'thue')
        value = danhMuc.LoaiNhaDatThue[loaiNhaDatKey];

    if (!value)
        value = BAT_KY;

    return value;
};

danhMuc.getLoaiNhaDatWToForDisplay = function(loaiTin, loaiNhaDatKey, editing){
    var value = '';
    if (loaiTin == 'mua')
        value = danhMuc.LoaiNhaCanMua[loaiNhaDatKey];

    if (loaiTin == 'thue')
        value = danhMuc.LoaiNhaCanThue[loaiNhaDatKey];

    // if (!loaiNhaDatKey && !editing) {
    //     if (loaiTin == 'mua') {
    //         value = 'Cần mua';
    //     }
    //     if (loaiTin == 'thue') {
    //         value = 'Cần thuê';
    //     }
    // }

    if (!value)
        value = BAT_KY;

    return value;
};

danhMuc.getHuongNhaForDisplay = function(huongNhaKey){
    var value = danhMuc.HuongNha[huongNhaKey];
    return value ? value : BAT_KY;
};

danhMuc.getGiaForDisplay = function (gia, donViTien) {
    if (!donViTien) {
        return '';
    }
    if (gia == -1)
        return 'Thỏa thuận';
    
    var value = '';
    if (!gia || donViTien == 5) {
        value = danhMuc.DonViTien[5];
    } else {
        value = gia + ' ' + danhMuc.DonViTien[donViTien].toLowerCase();
    }
    return value;
};

danhMuc.collectGiaDonViTien = function (gia, donViTien) {
    let giaItem = {};
    if (!donViTien) {
        return giaItem;
    }
    if (!gia || gia == -1 || donViTien == 5) {
        giaItem = {gia: gia, donViTien: 5};
    } else if ( gia >= 1000 && donViTien == 1) {
        giaItem = {gia: Number(gia/1000).toFixed(2), donViTien: 2};
    } else if ( gia >= 10 && donViTien == 3) {
        giaItem = {gia: Number(gia/10).toFixed(2), donViTien: 4};
    } else {
        giaItem = {gia: gia, donViTien: donViTien};
    }
    return giaItem;
};

danhMuc.calculateGia = function (gia, donViTien, dienTich) {
    if (!gia || donViTien == 1) {
        return gia;
    } else {
        if (donViTien == 5) {
            return null;
        }
        if (donViTien == 2) {
            return gia * 1000.0;
        }
        if (!dienTich) {
            return null;
        }
        if (donViTien == 3) {
            return (gia * dienTich) / 10.0;
        }
        if (donViTien == 4) {
            return gia * dienTich;
        }
    }
    return null;
};

danhMuc.calculateGia2 = function (gia, donViTien, dienTich) {
    let giaItem = {};
    if (!gia || donViTien == 1) {
        let giaM2 = dienTich && dienTich != -1 ? Number((gia/dienTich).toFixed(3)) : 0;
        giaItem = {gia: Number(gia), giaM2: giaM2};
    } else {
        if (donViTien == 5) {
            giaItem = {gia: null, giaM2: 0};
        }
        if (donViTien == 2) {
            let giaM2 = dienTich && dienTich != -1 ? Number(((gia * 1000.0)/dienTich).toFixed(3)) : 0;
            giaItem = {gia: gia * 1000.0, giaM2: giaM2};
        }
        if (donViTien == 3) {
            let giaVal = dienTich && dienTich != -1 ? (gia * dienTich) / 10.0 : null;
            let giaM2 = gia/10.0;
            giaItem = {gia: giaVal, giaM2: giaM2};
        }
        if (donViTien == 4) {
            let giaVal = dienTich && dienTich != -1 ? Number(gia * dienTich) : null;
            giaItem = {gia: giaVal, giaM2: Number(gia)};
        }
    }
    return giaItem;
};

danhMuc.getGiaAndDonViTien = function (giaChuan /* don vi TRIEU*/) {
    if (!giaChuan || giaChuan ==-1){
        return {gia: giaChuan, donViTien: 5};
    }

    if (giaChuan>=1000){
        return { gia: giaChuan/1000, donViTien: 2};
    }

    return {gia: giaChuan, donViTien: 1};
};

danhMuc.getGiaAndDonViTien2 = function (gia /* don vi TRIEU*/, giaM2 /* don vi TRIEU/M2*/) {
    if ((!gia || gia == -1) && (!giaM2 || giaM2 == -1)){
        return {gia: gia, donViTien: 5};
    }

    let giaItem = {};
    if (gia && gia != -1) {
        if (gia>=1000){
            giaItem = { gia: gia/1000, donViTien: 2};
        }
        else {
            giaItem = {gia: gia, donViTien: 1};
        }
    } else if (giaM2 && giaM2 != -1) {
        if (giaM2>=1){
            giaItem = { gia: giaM2, donViTien: 4};
        }
        else {
            giaItem = {gia: giaM2, donViTien: 3};
        }
    }

    return giaItem;
};

danhMuc.getDanhMucKeyByIndex = function (hashDanhMuc, index) {
    var find = '';
    var i = 0;
    for (var k in hashDanhMuc) {
        if (i == index) {
            find = k;
            break;
        }
        i++;
    }
    return find;
};

danhMuc.getTypeMainAvt = function (key) {
    return danhMuc.typeMainAvt[key];
};

danhMuc.getSoPhongByIndex = function (index) {
    return danhMuc.getDanhMucKeyByIndex(danhMuc.SoPhongNgu, index);
}

danhMuc.getSoTangByIndex = function (index) {
    return danhMuc.getDanhMucKeyByIndex(danhMuc.SoTang, index);
}

danhMuc.getSoPhongTamByIndex = function (index) {
    return danhMuc.getDanhMucKeyByIndex(danhMuc.SoPhongTam, index);
}

danhMuc.getAdsSoPhongByIndex = function (index) {
    return danhMuc.getDanhMucKeyByIndex(danhMuc.AdsSoPhongNgu, index);
}

danhMuc.getAdsSoTangByIndex = function (index) {
    return danhMuc.getDanhMucKeyByIndex(danhMuc.AdsSoTang, index);
}

danhMuc.getAdsSoPhongTamByIndex = function (index) {
    return danhMuc.getDanhMucKeyByIndex(danhMuc.AdsSoPhongTam, index);
}

danhMuc.getRadiusInKmByIndex = function(index) {
    return danhMuc.RadiusInKmKey[index];
}

danhMuc.getSoNgayAnTinIndex = function(index) {
    return danhMuc.soNgayIndex[index];
}

danhMuc.getLoaiTinValue = function (key) {
    return danhMuc.LoaiTin[key];
}

danhMuc.getLoaiTinTypeValue = function (key) {
    return danhMuc.LoaiTinType[key];
};

danhMuc.getDoUuTienTypeValue = function (key) {
    return danhMuc.DoUuTienType[key];
};

danhMuc.findLoaiTinValues = function(){
    return _.values(danhMuc.LoaiTinType)
};

danhMuc.getLoaiTinWToTypeValue = function (key) {
    return danhMuc.LoaiTinWToType[key];
};

danhMuc.findLoaiTinWToValues = function(){
    return _.values(danhMuc.LoaiTinWToType)
};

danhMuc.findDoUuTienValues = function(){
    return _.values(danhMuc.DoUuTienType)
};

danhMuc.findLoaiNhaDatBanValues = function(){
    return _.values(danhMuc.LoaiNhaDatBan)
};

danhMuc.findLoaiNhaDatThueValues = function(){
    return _.values(danhMuc.LoaiNhaDatThue)
};

danhMuc.findLoaiNhaCanMuaValues = function(){
    return _.values(danhMuc.LoaiNhaCanMua)
};

danhMuc.findLoaiNhaCanThueValues = function(){
    return _.values(danhMuc.LoaiNhaCanThue)
};

danhMuc.findLoaiDienTichValues = function(){
    return _.values(danhMuc.dienTich)
};


danhMuc.findGiaBanValues = function(){
    return _.values(danhMuc.giaBan)
};

danhMuc.finHasImageValues = function(){
    return _.values(danhMuc.hasImage)
}

danhMuc.findExcludeMoiGioiValues = function(){
    return _.values(danhMuc.excludeMoiGioi)
}

danhMuc.findGiaThueValues = function(){
    return _.values(danhMuc.giaThue)
};

danhMuc.getHiddenAdsValues = function() {
    return _.values(danhMuc.reasonHidden);
}

danhMuc.findHiddenAdsKey = function(value){
    return danhMuc.findKey(danhMuc.reasonHidden, value);
}

//eg: map=danhMuc.SoPhongTam, value = 1
danhMuc.getIdx = function(map, value) {
    let i = 0;
    for (var k in map) {
        if (k == value) {
            return i
        }
        i++;
    }

    return 0;//default
};

danhMuc.package = {
    goi: {
        1: {
            title: "Vị trí"
        },
        2: {
            title: "Logo"
        }
    },
    level: {
        1: "VIP Vàng",
        2: "VIP Bạc",
        3: "VIP Đồng",
        4: "Tin Thường"
    }, 
    length : {
        7: "7 ngày",
        15: "15 ngày",
        30: "30 ngày"
    },

    getLevel(option) {
        let found = null;
        for (let field in danhMuc.package.level) {
            if (danhMuc.package.level[field] == option) {
                found = Number(field);
            }
        }

        return found;
    },

    getLength(option) {
        let found = null;
        for (let field in danhMuc.package.length) {
            if (danhMuc.package.length[field] == option) {
                found = Number(field);
            }
        }

        return found;
    }
};

danhMuc.telco = {
  mobifone: "mobifone",
  viettel : "viettel",
  vinaphone : "vinaphone",
};

danhMuc.searchOrder = {
    '' : 'Mặc định',
    'ngayDangTinDESC' : 'Ngày đăng mới nhất',
    'giaASC' : 'Giá tăng dần',
    'giaDESC' : 'Giá giảm dần',
    'giaM2ASC' : 'Giá/m² tăng dần',
    'giaM2DESC' :'Giá/m² giảm dần',
    'dienTichASC' : 'Diện tích tăng dần',
    'dienTichDESC' : 'Diện tích giảm dần'
};

danhMuc.searchWToOrder = {
    '' : 'Mặc định',
    'ngayDangTinDESC' : 'Ngày đăng mới nhất'
};

danhMuc.contactOrder = {
    '' : 'Sắp xếp',    
    'nameASC' : 'A => Z',
    'nameDESC' : 'Z => A',    
    'dateDESC' : 'Mới nhất',
    'dateASC' : 'Cũ nhất'
};

danhMuc.groupOrder = {     
    'nameASC' : 'A => Z',
    'nameDESC' : 'Z => A',    
    'dateDESC' : 'Mới nhất',
    'dateASC' : 'Cũ nhất',
    'numberOfMem': 'Nhiều thành viên nhất'
};

danhMuc.contactOrderFieldMapping = {
    '' : 'nameKhongDau',    
    'nameASC' : 'nameKhongDau',
    'nameDESC' : 'nameKhongDau',    
    'dateDESC' : 'timeCreated',
    'dateASC' : 'timeCreated'
};

danhMuc.groupOrderFieldMapping = {
    '' : 'nameKhongDau',    
    'nameASC' : 'nameKhongDau',
    'nameDESC' : 'nameKhongDau',    
    'dateDESC' : 'timeModified',
    'dateASC' : 'timeModified',
    'numberOfMem' : 'countMember'
};

danhMuc.searchOrderSort = {
    '' : 'Sắp xếp',
    'ngayDangTinDESC' : 'Mới nhất',
    'giaASC' : 'Giá',
    'giaDESC' : 'Giá',
    'giaM2ASC' : 'Giá/m²',
    'giaM2DESC' :'Giá/m²',
    'dienTichASC' : 'Diện tích',
    'dienTichDESC' : 'Diện tích'
};

danhMuc.searchWToOrderSort = {
    '' : 'Sắp xếp',
    'ngayDangTinDESC' : 'Mới nhất'
};

danhMuc.orderTrangThaiTin = {
    0: 'Tất cả trạng thái',
    1: 'Tin đã được duyệt',
    2: 'Tin đang chờ duyệt',
    3: 'Tin bị từ chối',
    4: 'Tin đã hết hạn'
};

danhMuc.likeStatus = {    
    'like': 'Thích',
    'normal': 'Bình thường',
    'dislike': 'Không thích',    
};

danhMuc.likeBackground = {
    'like': 'rgba(237,20,91,1)',
    'normal': 'rgba(126,192,238,1)',
    'dislike': 'rgba(169,183,200,1)',
};

danhMuc.likeIcon = {
    'like': 'thumbs-up',
    'normal': 'arrows-h',
    'dislike': 'thumbs-down',
};


danhMuc.findKey = function(danhMucHash, value) {
    return _.findKey(danhMucHash, _.partial(_.isEqual, value))
};

danhMuc.getSearchOrderValues = function() {
    return _.values(danhMuc.searchOrder);
}

danhMuc.getSearchWToOrderValues = function() {
    return _.values(danhMuc.searchWToOrder);
}

danhMuc.getContactOrderValues = function() {
    return _.values(danhMuc.contactOrder);
}

danhMuc.getGroupOrderValues = function() {
    return _.values(danhMuc.groupOrder);
}

danhMuc.findSearchOrderKey = function(value){
    return danhMuc.findKey(danhMuc.searchOrder, value);
}

danhMuc.findContactOrderKey = function(value){
    return danhMuc.findKey(danhMuc.contactOrder, value);
}

danhMuc.findGroupOrderKey = function(value){
    return danhMuc.findKey(danhMuc.groupOrder, value);
}

danhMuc.getOrderTrangThaiTin = function() {
    return _.values(danhMuc.orderTrangThaiTin);
}

danhMuc.findTrangThaiTinKey = function(value){
    return danhMuc.findKey(danhMuc.orderTrangThaiTin, value);
}

danhMuc.loaiDuAn = {
    155	: "Căn hộ, Chung cư",
    156 : "Cao ốc văn phòng",
    157 : "Trung tâm thương mại",
    150 : "Khu đô thị mới",
    160 : "Khu phức hợp",
    148 : "Nhà ở xã hội",
    158 : "Khu nghỉ dưỡng, Sinh thái",
    159 : "Khu công nghiệp",
    161 : "Dự án khác",
    421 : "Biệt thự liền kề"
}

danhMuc.getLoaiDuAnValues = function(){
    return _.values(danhMuc.loaiDuAn)
}

danhMuc.finLoaiDuAnKey = function(value){
    return danhMuc.findKey(danhMuc.loaiDuAn, value);
}

danhMuc.USER_STATUS = {
    active: "active",
    inactive: "inactive"
}

danhMuc.VERIFY_TYPE = {
    postAds: "postAds",
    changePassword: "password",
    register: "register",
    profile: "profile"
}

danhMuc.STS = {
    SUCCESS : 0,
    FAILURE : 1
};

danhMuc.loaiTinFilter = {
    ban: 'ban',
    thue: 'thue',
    duAn: 'duAn',
    mua: 'mua'
}

danhMuc.groupType = {
    public: 'Công khai',
    private: 'Riêng tư'
}

danhMuc.groupStatus = {
    1: 'Chờ duyệt',
    2: 'Đã tham gia',
    3: 'Bị từ chối',
    4: 'Hết hạn',
    5: 'Đã xóa'
}

danhMuc.hashInboxType = {
    'all' : 0,    
    'spam' : 2,
    'personal': 0,
    'group': 0
} 

danhMuc.hashPhamViChat = {
    'all' : 0,
    'personal' : 1,
    'group' : 2,
    'spam': 0
} 

danhMuc.CHINH_CHU = 'Chính chủ';
danhMuc.BAN_GAP = 'Bán gấp';
danhMuc.THUE_GAP = 'Thuê gấp';

danhMuc.NOTIFICATION_TYPE = {
    inApp : 1,
    email : 2,
    sms : 3
};

danhMuc.NOTIFICATION_CATEGORY = {
    AdsPostApproval : 1,
    LandberNotification : 2,
    MarketingNews : 3,
    ListingAlert: 4,
    GroupApproval : 5,
    RequestJoinGroup : 6,
    ApproveJoinGroup: 7,
    CommentOnPost: 8,
    CommentReject: 9,
    StatusReject: 10,
    BlockUser: 11,
    SomeonePostedWtoPhuHop: 12,
    SomeonePostedAdsPhuHop: 13,
};

danhMuc.NOTIFICATION_STATUS = {
    new : 1,
    sent : 2,
    read : 3
};

danhMuc.KET_QUA_TRA_CUU_SO_DO = {
    CHUA_CAP_NHAT: 1,
    DA_CAP_NHAT: 2,
    DA_GUI: 3
};

danhMuc.contactSaleStateMap = {
    1: 'important',
    2: 'new',
    3: 'canceled',
    4: 'bought'
}

danhMuc.mainTextSearchHeader = {
    group: 'Sàn',
    contact: 'Liên hệ',
    wall: 'Bài viết'
}

danhMuc.hashDataTypeToTabHeader = {
    GroupWall: 'wall',
    Group: 'group',
    Contact: 'contact'
}

danhMuc.hashColorByAlphabet = {
    A: '#ed1e24',
    B: '#878342',
    C: '#69a255',
    D: '#9bca3c',
    E: '#71c055',
    F: '#40b8ea',
    G: '#436fb6',
    H: '#5b52a3',
    I: '#87519f',
    J: '#d1499b',
    K: '#ec197a',
    L: '#8ec975',
    M: '#ff4040',
    N: '#8ec975',
    O: '#91494b',
    P: '#ec197a',
    Q: '#d1499b',
    R: '#87519f',
    S: '#5b52a3',
    T: '#436fb6',
    U: '#40b8ea',
    V: '#71c055',
    W: '#9bca3c',
    X: '#69a255',
    Y: '#878342',
    Z: '#ed1e24',
}

danhMuc.sampleEvent = {
    'sample-contact': {
        content: 'Cùng Landber Agent trải nghiệm danh bạ quản lý khách hàng được thiết kế dành riêng cho nghề môi giới bất động sản',
        button1: 'Tìm hiểu thêm',
        button2: 'Tạo khách hàng'
    },
    'sample-ads': {
        content: 'Landber Agent không những cho phép bạn quản lý hiệu quả kho hàng của mình mà còn cho phép bạn đăng tin cực nhanh từ ứng dụng lên các trang bất động sản hàng đầu Việt Nam',
        button1: 'Tìm hiểu thêm',
        button2: 'Bắt đầu soạn'
    }
}

danhMuc.guideContact = {
    newGuide: 'Tăng hiệu quả tư vấn và tỷ lệ chốt sale bằng cách quản lý lịch sử giao dịch và ghi chú nhu cầu của khách hàng một cách dễ dàng!'
}

module.exports = danhMuc;


//import {LoaiNhaDatBan} from "danhMuc"...