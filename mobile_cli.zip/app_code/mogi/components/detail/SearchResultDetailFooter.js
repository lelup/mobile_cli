// Import some code we need
import React, {Component} from 'react';

import {View, Text, StyleSheet, AlertIOS } from 'react-native';

import TruliaIcon from '../TruliaIcon';

import RelandIcon from '../RelandIcon';

import gui from '../../lib/gui';

import Communications from 'react-native-communications';

import {Actions} from 'react-native-router-flux';

var Analytics = require('react-native-firebase-analytics');

import GiftedSpinner from 'react-native-gifted-spinner';

import utils from '../../lib/utils';

var {width, height} = utils.getDimensions();

// Create our component
var SearchResultDetailFooter = React.createClass({
  render: function() {
    const color = this.props.isLiked ? '#E50064' : 'rgba(255,255,255,0.8)';
    return <View style={myStyles.searchButton}>
      <View style={[myStyles.searchListButton, this.props.style]}>
          <TruliaIcon onPress={this.onCall} name="phone" color={'rgba(255,255,255,0.8)'} size={18}
                      mainProps={[myStyles.searchListButtonItem1, {width: width/2-3}]} textProps={myStyles.searchListButtonText1}
                      text={'Gọi điện'} />
          <View style={[myStyles.searchListButtonItem2, {width: width/2-3, marginRight: 2, flexDirection: 'row'}]}>
              {this.renderChatLoading()}
              <RelandIcon onPress={this.props.onChat} name="chat" color={'rgba(255,255,255,0.8)'} size={22}
                          mainProps={{flexDirection: 'row', backgroundColor: 'transparent'}}
                          textProps={[myStyles.searchListButtonText2,{paddingLeft: 0}]}
                          text={'Chat'} />
          </View>
      </View>
    </View>
  },
  onCall() {
      if (!this.props.mobile) {
          return;
      }
    Communications.phonecall(this.props.mobile, true);
      let deviceID = this.props.deviceID || undefined;
      let userID = this.props.userID || undefined;
      Analytics.logEvent('DETAIL_DIALING', {deviceID: deviceID, userID: userID, adsID: this.props.adsID, phone: this.props.mobile});
  },

  onLike() {
      if (!this.props.ads) {
          return;
      }
    if (!this.props.loggedIn) {
        //this.props.actions.onAuthFieldChange('activeRegisterLoginTab',0);
        Actions.NewLogin();
    } else {
        if (!this.props.isLiked) {
            this.props.likeAds(this.props.userID, this.props.ads.adsID, this.props.updateMessageProcessing)
        } else {
            this.props.unlikeAds(this.props.userID, this.props.ads.adsID, this.props.updateMessageProcessing)
        }
    }
  },

  renderChatLoading() {
    if(this.props.isChatLoading) {
        return (
            <View style={myStyles.loadingContent}>
                <GiftedSpinner color="white"/>
            </View>
        );
    }
  },

  renderLikeAdsLoading() {
    if(this.props.isLikeAdsLoading) {
        return (
            <View style={myStyles.loadingContent}>
                <GiftedSpinner color="white"/>
            </View>
        );
    }
  }

});

// Make this code available elsewhere
module.exports = SearchResultDetailFooter;


var myStyles = StyleSheet.create({
  searchListButtonItem1: {
      backgroundColor: '#fa4916',
      width: width/3-3,
      borderRadius: 5,
      borderColor: 'transparent',
      height: 38,
      marginLeft: 2,
      justifyContent: 'center'
  },
  searchListButtonItem2: {
      backgroundColor: '#f0a401',
      width: width/3-3,
      borderRadius: 5,
      borderColor: 'transparent',
      height: 38,
      marginLeft: 2,
      justifyContent: 'center',
      alignItems: 'center'
  },
  searchListButtonItem3: {
      backgroundColor: gui.mainColor,
      width: width/3-3,
      borderRadius: 5,
      borderColor: 'transparent',
      height: 38,
      marginLeft: 2,
      marginRight: 2,
      justifyContent: 'center',
      alignItems: 'center'
  },
  searchListButtonText1: {
      marginLeft: 5,
      alignItems: 'center',
      backgroundColor: 'transparent',
      color: 'white',
      fontFamily: gui.fontFamily,
      fontWeight: 'normal',
      fontSize: gui.normalFontSize
  },
  searchListButtonText2: {
      marginLeft: 5,
      alignItems: 'center',
      backgroundColor: 'transparent',
      color: 'white',
      fontFamily: gui.fontFamily,
      fontWeight: 'normal',
      fontSize: gui.normalFontSize
  },
  searchListButtonText3: {
      marginLeft: 5,
      alignItems: 'center',
      backgroundColor: 'transparent',
      color: 'white',
      fontFamily: gui.fontFamily,
      fontWeight: 'normal',
      fontSize: gui.normalFontSize
  },
  searchListButton: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      backgroundColor: 'transparent',
      width: width,
      borderTopColor: '#dcdcdc',
      borderTopWidth: 1,
      height: 44
  },
  searchButton: {
      alignItems: 'center',
      justifyContent: 'flex-start',
      backgroundColor: 'transparent'
  },
  loadingContent: {
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 5
  }
});
