import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';
import utils from '../../lib/utils';

import Icon from 'react-native-vector-icons/FontAwesome';

const {width} = utils.getDimensions();

export default class CheckDot extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';
        let mainStyle = selected ? 'wrapperSelected' : 'wrapper';
        let iconName =  selected ? 'dot-circle-o' : 'circle-o';
        let iconColor = selected ? gui.mainColor : '#acacac';

        return (
            <TouchableOpacity
                onPress={() => this.props.onPress(this.props.name)}>
                <View style={[styles.mainView, styles[mainStyle], this.props.mainProps]}>
                    <Icon name={iconName} size={18} color={iconColor} />
                    <Text style={[styles[myStyle], this.props.textProps]} >
                        {this.props.children}
                    </Text>
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    mainView: {
        flexDirection: 'row',
        justifyContent: 'center',
        margin: 5,
        width: width/2 - 25,
        height: 40
    },
    wrapper: {
        backgroundColor: 'transparent'
    },
    wrapperSelected: {
        backgroundColor: 'transparent'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 12,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: '#acacac',
        fontWeight : 'normal',
        marginLeft: 5
    },
    buttonTextSelected: {
        alignSelf:'center',
        fontSize: 12,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: '#000',
        fontWeight : 'normal',
        marginLeft: 5
    }
});