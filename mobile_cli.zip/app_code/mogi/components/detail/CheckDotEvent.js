import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import FullLine from '../line/FullLine';
import gui from '../../lib/gui';
import ScalableText from 'react-native-text';
import utils from '../../lib/utils';

import Icon from 'react-native-vector-icons/FontAwesome';

const {width} = utils.getDimensions();

export default class CheckDotEvent extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';
        let mainStyle = selected ? 'wrapperSelected' : 'wrapper';
        let iconName =  selected ? 'dot-circle-o' : 'circle-o';
        let iconColor = selected ? gui.mainAgentColor : gui.mainTextColor;

        return (
                <TouchableOpacity
                    onPress={() => this.props.onPress(this.props.name)}>
                    <View style={[styles.mainView, styles[mainStyle], this.props.mainProps]}>
                        <Icon name={iconName} size={13} color={iconColor} />
                        <Text style={styles[myStyle]} >
                            {this.props.children}
                        </Text>
                    </View>
                </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    mainView: {
        flexDirection: 'row',
        justifyContent: 'center',
        margin: 5,
        width: width,
        height: 41
    },
    wrapper: {
        backgroundColor: 'transparent'
    },
    wrapperSelected: {
        backgroundColor: 'transparent'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: gui.mainTextColor,
        fontWeight : 'normal',
        marginLeft: 6
    },
    buttonTextSelected: {
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: gui.mainAgentColor,
        fontWeight : 'normal',
        marginLeft: 6
    }
});