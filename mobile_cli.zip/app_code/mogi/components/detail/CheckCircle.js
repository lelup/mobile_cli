import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';
import utils from '../../lib/utils';

import Icon from 'react-native-vector-icons/FontAwesome';

const {width}= utils.getDimensions();

export default class CheckCircle extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';
        let mainStyle = selected ? 'wrapperSelected' : 'wrapper';
        let iconName =  selected ? 'circle' : 'circle';
        let iconColor = selected ? gui.mainColor : '#acacac';

        return (
            <TouchableOpacity
                onPress={() => this.props.onPress(this.props.name)}>
                <View style={[styles.mainView, styles[mainStyle], this.props.mainProps]}>
                    <Icon name={iconName} size={28} color={iconColor} />
                    <ScalableText style={styles[myStyle]} >
                        {this.props.children}
                    </ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    mainView: {
        flexGrow: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        margin: 5,
        width: 80,
    },
    wrapper: {
        backgroundColor: '#fff'
    },
    wrapperSelected: {
        backgroundColor: '#fff'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 13,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: '#acacac',
        fontWeight : '400',
        marginTop: 15
    },
    buttonTextSelected: {
        alignSelf:'center',
        fontSize: 13,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: '#000',
        fontWeight : '400',
        marginTop: 15
    }
});