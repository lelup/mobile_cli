import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    TextInput,
    Alert
} from 'react-native';

import {Actions} from 'react-native-router-flux';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import Button from 'react-native-button';
import ScalableText from 'react-native-text';
import dismissKeyboard from 'react-native-dismiss-keyboard';

import DanhMuc from "../../assets/DanhMuc"
import SegmentedControl from '../SegmentedControl';
import gui from '../../lib/gui';
import log from '../../lib/logUtil'
import FullLine from '../line/FullLine';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
const {width, height}= utils.getDimensions();

import CheckDot from './CheckDot';
//import CheckCircle from './CheckCircle';

import ReportApi from '../../lib/ReportRelandApi';

import GiftedSpinner from 'react-native-gifted-spinner';

class HideAds extends Component {
    constructor(props) {
        super(props);
        this.state = {
            typeAds: 'currentAds',
            //typeDate: '1Day',
            reasonHidden: '',
            userNoteReport: '',
            toggleState: false,
            soNgayAnSelectedIdx: -1,
            processing: false
        }
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBody()}
            </View>
        )
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                        Ẩn tin đăng
                    </Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _renderBody() {
        let hiddenTypeItems = [];
        let hiddenTypeKeys = Object.keys(DanhMuc.hiddenAdsUser);
        hiddenTypeKeys.forEach((hiddenKey) => {
            let hiddenType = DanhMuc.hiddenAdsUser[hiddenKey];
            let extStyle = hiddenKey == 'currentAds' ?
                            {justifyContent: 'flex-start', marginLeft: 0, width: width/2 - 28} :
                            {justifyContent: 'flex-end', paddingRight: 10, width: width/2 + 28};
            hiddenTypeItems.push(
                <CheckDot name={hiddenKey} key={hiddenKey}
                          onPress={this._onTypeAds.bind(this)}
                          selected={this.state.typeAds == hiddenKey}
                          mainProps={[styles.viewTypeAds, extStyle]}>{hiddenType}</CheckDot>
            );
        });

        let hiddenReasonItems = [];
        let reasonHiddenAds = DanhMuc.reasonHiddenAds[this.state.typeAds] || {};
        let hiddenReasonKeys = Object.keys(reasonHiddenAds);
        hiddenReasonKeys.forEach((reasonKey) => {
            let hiddenReason = reasonHiddenAds[reasonKey];
            hiddenReasonItems.push(
                <CheckDot name={reasonKey} key={reasonKey}
                          onPress={this._onTypeReason.bind(this)}
                          selected={this.state.reasonHidden == reasonKey}
                          mainProps={styles.viewTypeReason}>{hiddenReason}</CheckDot>
            );
        });

        return(
            <View style={{flex: 1}}>
                <KeyboardAwareScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="none"
                    ref='scroll'>
                    <View style={styles.viewBody}>
                        <View style={styles.viewTypeHide}>
                            {hiddenTypeItems}
                        </View>
                        <FullLine style={{marginLeft: 15, marginRight: 15}}/>
                        <View style={styles.viewChooseDay}>
                            {this._renderDayHide()}
                        </View>
                        <FullLine style={{marginLeft: 15, marginRight: 15}}/>
                        <View style={styles.viewChooseDay}>
                            <Text style={styles.textTimeHide}>Lý do bạn muốn ẩn tin</Text>
                            <View style={styles.viewReasonHide}>
                                {hiddenReasonItems}
                            </View>
                        </View>
                        <FullLine style={{marginLeft: 15, marginRight: 15, marginTop: 10}}/>
                        <View style={styles.viewNoteUser}>
                            <TextInput
                                ref="textInput"
                                secureTextEntry={false}
                                // autoCapitalize = {'words'}
                                autoCorrect={false}
                                placeholder='Nhập lý do ...'
                                placeholderTextColor='#e0e0e0'
                                textAlignVertical={'top'}
                                multiline = {true}
                                maxLength={500}
                                returnKeyType='next'
                                numberOfLines = {5}
                                style={styles.contentText}
                                value={this.state.userNoteReport}
                                onChangeText={(text) => this.onValueChange(text)}
                                onFocus={() => this._onGhiChuFocus()}
                                clearButtonMode="never"
                                selectTextOnFocus={true}
                            />
                        </View>
                    </View>
                </KeyboardAwareScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                  style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                      backgroundColor: gui.doneKeyButton }]}>Xong</Button> : null}
                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>
                {this._renderHideAds()}
            </View>
        );
    }

    _onGhiChuFocus() {
        this._onTypeReason('otherReason');
    }

    _renderDayHide() {

        return this._renderSegment("Số ngày ẩn tin", DanhMuc.getSoNgayAnValues(), this.state.soNgayAnSelectedIdx, this._onSoNgayAnChanged.bind(this));
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                              onChange={onChange} />
        );
    }

    _onSoNgayAnChanged(index) {
        this.setState({soNgayAnSelectedIdx: index});
    }

    _renderHideAds() {
        if (this.state.processing) {
            return (
                <View style={styles.viewButtonUpdate}>
                    <GiftedSpinner size="small" color="#8A8A8A"/>
                </View>
            );
        }
        return(
                <TouchableOpacity style={styles.viewButtonUpdate}
                                  onPress = {this._onPressHideAds.bind(this)}
                >
                    <Text style={styles.textUpdate}>Ẩn tin</Text>
                </TouchableOpacity>
        );
    }
    _validInputData() {
        if (this.state.soNgayAnSelectedIdx == -1) {
            Alert.alert(
                'Thông báo',
                'Bạn chưa chọn số ngày ẩn tin.',
                [
                    {text: 'Đóng', onPress: () => {}}
                ]
            );
            return false;
        }
        let reason = this._getReasonContent();
        if (!reason) {
            Alert.alert(
                'Thông báo',
                'Bạn chưa nhập lý do ẩn tin.',
                [
                    {text: 'Đóng', onPress: () => {}}
                ]
            );
            return false;
        }
        return true;
    }
    _onPressHideAds() {
        let ads = this.props.ads;
        if (!ads) {
            return;
        }
        if (!this._validInputData()) {
            return;
        }
        this.setState({processing: true});
        let hiddenDays = Number(DanhMuc.getSoNgayAnTinIndex(this.state.soNgayAnSelectedIdx));
        let {typeAds} = this.state;
        let params = {};
        params.userID = this.props.currentUserID;
        params.reason = this._getReasonContent();
        params.days = hiddenDays;
        if (typeAds == 'currentAds') {
            let adsID = ads.adsID || ads.id;
            params.hiddenAds = {adsID: adsID};
        } else {
            let dangBoi = ads.dangBoi;
            let userID = dangBoi && dangBoi.userID || undefined;
            let phone = dangBoi && dangBoi.phone || undefined;
            let email = dangBoi && dangBoi.email || undefined;
            params.hiddenUser = {userID: userID, phone: phone, email: email};
        }
        ReportApi.hideAds(params)
            .then(data => {
                if (data.status == 0) {
                    Actions.pop();
                    this.props.doFinalAction && this.props.doFinalAction(params,
                        {hiddenAds: data.hiddenAds, hiddenUser: data.hiddenUser});
                    this.setState({processing: false});
                    Alert.alert('Thông báo',
                        'Ẩn tin đăng thành công!',
                        [{
                            text: 'Đóng',
                            onPress: () => {}
                        }]);
                } else {
                    this.setState({processing: false});
                    Alert.alert("Thông báo", data.msg || 'Ẩn tin đăng không thành công!', [ { text: 'Đóng', onPress: () => {} } ]);
                }
            });
    }

    _getReasonContent() {
        let {reasonHidden, userNoteReport} = this.state;
        let reasonHiddenAds = DanhMuc.reasonHiddenAds[this.state.typeAds] || {};
        return reasonHidden == 'otherReason' ? userNoteReport.trim() : reasonHiddenAds[reasonHidden];
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState});
    }
    onValueChange(value) {
        this.setState({userNoteReport: value});
    }

    _onBackPress() {
        Actions.pop();
    }

    _onTypeAds(value) {
        this.setState({
            typeAds: value,
            reasonHidden: '',
            userNoteReport: ''
        });
        dismissKeyboard();
    }

    _onTypeDate(value) {
        this.setState({
            typeDate: value
        });
    }

    _onTypeReason(value) {
        if (value != 'otherReason') {
            this.setState({
                reasonHidden: value,
                userNoteReport: ''});
            dismissKeyboard();
        } else {
            this.refs.textInput && this.refs.textInput.focus();
            this.setState({
                reasonHidden: value
            });
        }
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewTypeHide: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 50,
        flexDirection: 'row'
    },
    viewChooseDay: {
        marginTop: 5,
        marginBottom: 5
    },
    viewDateHide: {
        justifyContent: 'space-around',
        alignItems: 'center',
        width: width,
        height: 100,
        flexDirection: 'row'
    },
    viewReasonHide: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        width: width,
        // height: 175,
        flexDirection: 'column',
        marginTop: 10,
        marginLeft: 15
    },
    viewTypeAds: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
        marginRight: 0,
        width: width/2 - 25,
        height: 50,
        paddingLeft: 20
    },
    viewTypeDate: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 0,
        width: 80,
        height: 100
    },
    viewHideLine: {
        height: 10,
        width: (width-320)/4,
        backgroundColor: '#acacac'
    },
    viewTypeReason: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        margin: 2,
        marginRight: 0,
        width: width - 15,
        height: 30
    },
    textTimeHide: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: '#000',
        fontWeight : 'normal',
        marginTop: 2,
        marginLeft: 15
    },
    contentText: {
        textAlign: 'left',
        alignItems: 'flex-end',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#000',
        marginLeft: 15,
        width: width - 30,
        paddingLeft: 5,
        paddingTop: 5,
        paddingRight: 5,
        marginRight: 10,
        height: 110
    },
    viewNoteUser: {
        marginTop: 0,
        marginBottom: 5,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    viewHideAdsButton: {
        position:'absolute',
        bottom: 0,
        backgroundColor: '#fff',
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 41
    },
    viewButtonUpdate: {
        position:'absolute',
        bottom: 0,
        backgroundColor: '#fa4917',
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 40
    },
    textUpdate:{
        fontSize: 17,
        color:'#fff',
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
});

export default HideAds;