import React, {
    Component,
} from 'react';
import {
    Text,
    View,
    ListView,
    TextInput,
    Animated,
    Platform,
    PixelRatio,
    Alert,
    ScrollView,
    TouchableOpacity
} from 'react-native';
import Camera from 'react-native-camera';

import Message from './Message';
import GiftedSpinner from 'react-native-gifted-spinner';
import moment from 'moment';
import { setLocale } from './Locale';
import deepEqual from 'deep-equal';
import Button from 'react-native-button';
import RelandIcon from '../RelandIcon';
import gui from '../../lib/gui';
import FullLine from '../line/FullLine';
import ChatMenu from '../chat/ChatMenu'

import PropTypes from 'prop-types';

import { Actions } from 'react-native-router-flux';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';

import * as Animatable from 'react-native-animatable';

import ScalableText from 'react-native-text';

import * as globalActions from '../../reducers/global/globalActions';

import utils from '../../lib/utils';
const {width, height} = utils.getDimensions();

const actions = [
  globalActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class GiftedMessenger extends Component {

  constructor(props) {
    super(props);

    this.onFooterLayout = this.onFooterLayout.bind(this);
    this.renderRow = this.renderRow.bind(this);
    this.renderLoadEarlierMessages = this.renderLoadEarlierMessages.bind(this);
    this.onLayout = this.onLayout.bind(this);
    this.renderFooter = this.renderFooter.bind(this);
    this.onChangeVisibleRows = this.onChangeVisibleRows.bind(this);
    this.onKeyboardWillShow = this.onKeyboardWillShow.bind(this);
    this.onKeyboardDidShow = this.onKeyboardDidShow.bind(this);
    this.onKeyboardWillHide = this.onKeyboardWillHide.bind(this);
    this.onKeyboardDidHide = this.onKeyboardDidHide.bind(this);
    this.onChangeText = this.onChangeText.bind(this);
    this.onSend = this.onSend.bind(this);

    this._firstDisplay = true;
    this._listHeight = 0;
    this._footerY = 0;
    this._scrollToBottomOnNextRender = false;
    this._scrollToPreviousPosition = false;
    this._visibleRows = { s1: {} };

    let textInputHeight = 44;
    if (!this.props.hideTextInput) {
      if (this.props.styles.hasOwnProperty('textInputContainer')) {
        textInputHeight = this.props.styles.textInputContainer.height || textInputHeight;
      }
    }

    this.listViewMaxHeight = this.props.maxHeight - 2 * textInputHeight;

    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => {
        if (r1.status !== r2.status) {
          return true;
        }
        return false;
      },
    });

    this.state = {
      dataSource: ds.cloneWithRows([]),
      text: props.text,
      disabled: true,
      height: new Animated.Value(this.listViewMaxHeight),
      appearAnim: new Animated.Value(0),
      dropdownSelection: '',
      isOpenHelpStream: !props.global.help.streamHelped
    };
  }

  componentWillMount() {
    this.styles = {
      container: {
        flex: 1,
        backgroundColor: '#FFF',
      },
      listView: {
        flex: 1
      },
      textInputContainer: {
        height: 44,
        //borderTopWidth: 1 / PixelRatio.get(),
        //borderColor: '#b2b2b2',
        flexDirection: 'row',
        paddingLeft: 8,
        paddingRight: 10,
        backgroundColor: '#ffffff'
      },
      textInput: {
        alignSelf: 'center',
        height: 33,
        width: 100,
        backgroundColor: 'white',
        flex: 1,
        padding: 0,
        margin: 0,
        fontSize: 15,
        paddingLeft: 8,
        borderRadius: 0
      },
      sendButton: {
        marginTop: 11,
        marginLeft: 10,
        fontSize: 17,
        fontWeight: '400'
      },
      date: {
        color: '#aaaaaa',
        fontSize: 11,
        textAlign: 'center',
        fontWeight: '400',
        marginBottom: 8,
        fontFamily: gui.fontFamily
      },
      link: {
        color: '#e0f4fc',
        textDecorationLine: 'underline'
      },
      linkLeft: {
        color: '#000'
      },
      linkRight: {
        color: '#000'
      },
      loadEarlierMessages: {
        height: 44,
        justifyContent: 'center',
        alignItems: 'center'
      },
      loadEarlierMessagesButton: {
        fontSize: 15
      },
      captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: 6,
        marginLeft: 10,
        marginRight: 20
      },
      locationIcon: {
          flexDirection: 'row',
          justifyContent: 'center',
          marginTop: 3,
          marginLeft: 10,
          marginRight: 20
      },
      menuTrigger: {
        flexDirection: 'row',
        paddingHorizontal: 0
      },
      contentChat: {
        backgroundColor: 'white',
        paddingHorizontal: 0,
        paddingTop: 0,
        paddingBottom: 0,
        height: 50,
        width: 50
      },
      contentText: {
        fontSize: 18
      },
      dropdown: {
        width: 300,
        borderColor: '#999',
        borderWidth: 1,
        padding: 0
      },
      dropdownOptions: {
        marginTop: 30,
        borderColor: '#ccc',
        borderWidth: 2,
        width: 300,
        height: 250,
        justifyContent: 'center',
        alignItems: 'center'
      },
      divider: {
        marginVertical: 4,
        marginHorizontal: 2,
        borderBottomWidth: 1,
        borderColor: 'lightgray'
      },
      viewIconChat: {
        flexDirection: 'row',
        marginLeft: 12,
        paddingBottom: 10,
        backgroundColor: 'transparent',
        alignItems: 'center'
      },
      viewHelpStream: {
          width: width,
          height: 118,
          backgroundColor: 'transparent',
          justifyContent: 'flex-end',
          alignItems: 'flex-start',
          paddingBottom:  32,
          paddingLeft: 15,
          borderRadius: 5,
          borderWidth: 0
      },
        viewModalTop:{
            width: 220,
            height: 69,
            justifyContent: 'flex-end',
            alignItems: 'center',
            backgroundColor: 'rgba(169, 168, 168, 0.01)',
            paddingTop: 10,
            marginLeft: 10
        },
        viewAnimatable:{
            width: 220,
            height: 60,
            backgroundColor: '#fff',
            borderRadius: 5,
            justifyContent: 'center',
            alignItems: 'center',
            paddingLeft: 6
        },
        textContent: {
            color: '#5f5f5f',
            fontSize: 13,
            fontFamily: gui.fontFamily,
            fontWeight: '400',
            textAlign: 'left'
        },
        triangle: {
            width: 0,
            height: 0,
            backgroundColor: 'transparent',
            borderStyle: 'solid',
            borderLeftWidth: 6,
            borderRightWidth: 6,
            borderBottomWidth: 9,
            borderLeftColor: 'transparent',
            borderRightColor: 'transparent',
            borderBottomColor: '#fff',
            transform: [
                {rotate: '180deg'}
            ],
            marginLeft: 103
        },
        viewIconClose: {
            height: 20,
            width: 20,
            borderRadius: 10,
            backgroundColor: '#b6b6b6',
            left: 106,
            justifyContent: 'flex-start',
            alignItems: 'flex-end',
            marginTop: -20
        }
    };

    Object.assign(this.styles, this.props.styles);

    if (this.props.dateLocale !== '')
      setLocale(this.props.dateLocale);
  }

  componentDidMount() {
    this.scrollResponder = this.refs.listView.getScrollResponder();

    if (this.props.messages.length > 0) {
      this.setMessages(this.props.messages);
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.typingMessage !== this.props.typingMessage) {
      if (this.isLastMessageVisible()) {
        this._scrollToBottomOnNextRender = true;
      }
    }

    if (nextProps.global.help.streamHelped !== this.props.global.help.streamHelped) {
        this.setState({isOpenHelpStream: !nextProps.global.help.streamHelped})
    }

    if (deepEqual(nextProps.messages, this.props.messages) === false) {
      let isAppended = null;
      if (nextProps.messages.length === this.props.messages.length) {
        // we assume that only a status has been changed
        if (this.isLastMessageVisible()) {
          isAppended = true; // will scroll to bottom
        } else {
          isAppended = null;
        }
      } else if (deepEqual(nextProps.messages[nextProps.messages.length - 1], this.props.messages[this.props.messages.length - 1]) === false) {
        // we assume the messages were appended
        isAppended = true;
      } else {
        // we assume the messages were prepended
        isAppended = false;
      }
      this.setMessages(nextProps.messages, isAppended);
    }

    let textInputHeight = 44;
    if (nextProps.styles.hasOwnProperty('textInputContainer')) {
      textInputHeight = nextProps.styles.textInputContainer.height || textInputHeight;
    }

    if (nextProps.maxHeight !== this.props.maxHeight) {
      this.listViewMaxHeight = nextProps.maxHeight;
      Animated.timing(this.state.height, {
        toValue: this.listViewMaxHeight,
        duration: 150,
      }).start();
    }

    if (nextProps.hideTextInput && !this.props.hideTextInput) {
      this.listViewMaxHeight += textInputHeight;

      this.setState({
        height: new Animated.Value(this.listViewMaxHeight),
      });
    } else if (!nextProps.hideTextInput && this.props.hideTextInput) {
      this.listViewMaxHeight -= textInputHeight;

      this.setState({
        height: new Animated.Value(this.listViewMaxHeight),
      });
    }
  }

  takePicture() {
    Camera.checkDeviceAuthorizationStatus().then(
        (e) => {
          if (e){
            Actions.PostAds({ owner: 'chat' });
          } else {
            Alert.alert("Thông báo", gui.INF_CameraAccess);
          }
        });

  }
  
  onSend() {
    this.myTextInput.clear();

    const message = {
      text: this.state.text.trim(),
      name: this.props.senderName,
      image: this.props.senderImage,
      position: 'right',
      date: new Date(),
    };
    if (this.props.onCustomSend) {
      this.props.onCustomSend(message);
    } else {
      this.onChangeText('');

      this.props.handleSend(message);
    }
  }

  onKeyboardWillHide() {
    Animated.timing(this.state.height, {
      toValue: this.listViewMaxHeight,
      duration: 150,
    }).start();
  }

  onKeyboardDidHide(e) {
    if (Platform.OS === 'android') {
      this.onKeyboardWillHide(e);
    }

    // TODO test in android
    //if (this.props.keyboardShouldPersistTaps === false) {
      if (this.isLastMessageVisible()) {
        this.scrollToBottom();
      }
    //}
  }

  onKeyboardWillShow(e) {
    Animated.timing(this.state.height, {
      toValue: this.listViewMaxHeight - e.endCoordinates.height,
      duration: 200,
    }).start();
  }

  onKeyboardDidShow(e) {
    if (Platform.OS === 'android') {
      this.onKeyboardWillShow(e);
    }

    setTimeout(() => {
      this.scrollToBottom();
    }, (Platform.OS === 'android' ? 200 : 100));
  }

  onLayout(event) {
    const layout = event.nativeEvent.layout;
    this._listHeight = layout.height;

    if (this._firstDisplay === true) {
      requestAnimationFrame(() => {
        this._firstDisplay = false;
        this.scrollToBottom(false);
      });
    }
  }

  onFooterLayout(event) {
    const layout = event.nativeEvent.layout;
    const oldFooterY = this._footerY;
    this._footerY = layout.y;

    if (this._scrollToBottomOnNextRender === true) {
      this._scrollToBottomOnNextRender = false;
      this.scrollToBottom();
    }

    if (this._scrollToPreviousPosition === true) {
      this._scrollToPreviousPosition = false;
      if (this.scrollResponder) {
        this.scrollResponder.scrollTo({
          y: this._footerY - oldFooterY,
          x: 0,
          animated: false,
        });
      }
    }
  }

  onChangeVisibleRows(visibleRows) {
    this._visibleRows = visibleRows;
  }

  onChangeText(text) {
    this.setState({
      text: text,
      disabled: text.trim().length <= 0
    });

    this.props.onChangeText(text);
  }

  getLastMessageUniqueId() {
    if (this.props.messages.length > 0) {
      return this.props.messages[this.props.messages.length - 1].uniqueId;
    }
    return null;
  }

  getPreviousMessage(message) {
    for (let i = 0; i < this.props.messages.length; i++) {
      if (message.uniqueId === this.props.messages[i].uniqueId) {
        if (this.props.messages[i - 1]) {
          return this.props.messages[i - 1];
        }
      }
    }
    return null;
  }

  getNextMessage(message) {
    for (let i = 0; i < this.props.messages.length; i++) {
      if (message.uniqueId === this.props.messages[i].uniqueId) {
        if (this.props.messages[i + 1]) {
          return this.props.messages[i + 1];
        }
      }
    }
    return null;
  }

  setMessages(messages, isAppended = null) {
    this.filterStatus(messages);

    const rows = {};
    const identities = [];
    for (let i = 0; i < messages.length; i++) {
      if (typeof messages[i].uniqueId === 'undefined') {
        console.warn('messages[' + i + '].uniqueId is missing');
      }
      rows[messages[i].uniqueId] = Object.assign({}, messages[i]);
      identities.push(messages[i].uniqueId);
    }

    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(rows, identities),
    });

    if (isAppended === true) {
      this._scrollToBottomOnNextRender = true;
    } else if (isAppended === false) {
      this._scrollToPreviousPosition = true;
    }
  }

  // Keep only the status of the last 'right' message
  filterStatus(messages) {
    let lastStatusIndex = 0;
    for (let i = 0; i < messages.length; i++) {
      if (messages[i].position === 'right') {
        lastStatusIndex = i;
      }
    }

    for (let i = 0; i < lastStatusIndex; i++) {
      if (messages[i].position === 'right') {
        if (messages[i].status !== 'ErrorButton') {
          delete messages[i].status;
        }
      }
    }
  }


  isLastMessageVisible() {
    return !!this._visibleRows.s1[this.getLastMessageUniqueId()];
  }

  scrollToBottom(animated = null) {
    if (this._listHeight && this._footerY && this._footerY > this._listHeight) {
      let scrollDistance = this._listHeight - this._footerY;
      if (this.props.typingMessage) {
        scrollDistance -= 44;
      }

      if (this.scrollResponder) {
        this.scrollResponder.scrollTo({
          y: -scrollDistance,
          x: 0,
          animated: typeof animated === 'boolean' ? animated : this.props.scrollAnimated,
        });
      }
    }
  }

  preLoadEarlierMessages() {
    this.props.onLoadEarlierMessages();
  }

  renderLoadEarlierMessages() {
    if (this.props.loadEarlierMessagesButton) {
      if (this.props.isLoadingEarlierMessages) {
        return (
            <View style={this.styles.loadEarlierMessages}>
              <GiftedSpinner size="large" />
            </View>
        );
      }
      return (
          <View style={this.styles.loadEarlierMessages}>
            <Button
                style={this.styles.loadEarlierMessagesButton}
                onPress={() => { this.preLoadEarlierMessages(); } }
            >
              {this.props.loadEarlierMessagesButtonText}
            </Button>
          </View>
      );
    }
    return (
        <View style={{ height: 10 }} />
    );
  }

  renderTypingMessage() {
    if (this.props.typingMessage) {
      return (
          <View
              style={{
            height: 44,
            justifyContent: 'center',
          }}
          >
            <Text
                style={{
              marginLeft: 10,
              marginRight: 10,
              color: '#aaaaaa',
            }}
            >
              {this.props.typingMessage}
            </Text>
          </View>
      );
    }
    return null;
  }

  renderFooter() {
    return (
        <View
            onLayout={this.onFooterLayout}
        >
          {this.renderTypingMessage()}
        </View>
    );
  }

  renderDate(rowData = {}) {
    let diffMessage = null;
    diffMessage = this.getPreviousMessage(rowData);
    let currentDate = new Date(rowData.date);

    if (this.props.renderCustomDate) {
      return this.props.renderCustomDate(rowData, diffMessage)
    }

    if (currentDate instanceof Date) {
      if (diffMessage === null) {
        return (
            <Text style={[this.styles.date]}>
              {moment(currentDate).calendar()}
            </Text>
        );
      } else if (new Date(diffMessage.date) instanceof Date) {
        const diff = moment(currentDate).diff(moment(new Date(diffMessage.date)), 'minutes');
        if (diff > 5) {
          return (
              <Text style={[this.styles.date]}>
                {moment(currentDate).calendar()}
              </Text>
          );
        }
      }
    }
    return null;
  }

  renderRow(rowData = {}) {
    let diffMessage = null;
    diffMessage = this.getPreviousMessage(rowData);

    return (
        <View>
          {this.renderDate(rowData)}
          <Message
              rowData={rowData}
              onErrorButtonPress={this.props.onErrorButtonPress}
              displayNames={this.props.displayNames}
              displayNamesInsideBubble={this.props.displayNamesInsideBubble}
              diffMessage={diffMessage}
              position={rowData.position}
              forceRenderImage={this.props.forceRenderImage}
              onImagePress={this.props.onImagePress}
              onMessageLongPress={this.props.onMessageLongPress}
              renderCustomText={this.props.renderCustomText}

              parseText={this.props.parseText}
              handlePhonePress={this.props.handlePhonePress}
              handleUrlPress={this.props.handleUrlPress}
              handleEmailPress={this.props.handleEmailPress}

              styles={this.styles}
          />
        </View>
    );
  }

  renderAnimatedView() {
    return (
        <Animated.View
            style={{
          height: this.state.height,
          justifyContent: 'flex-end',
        }}

        >
          <ListView
              ref="listView"
              dataSource={this.state.dataSource}
              renderRow={this.renderRow}
              //renderHeader={this.renderLoadEarlierMessages}
              enableEmptySections={true}
              onLayout={this.onLayout}
              renderFooter={this.renderFooter}
              onChangeVisibleRows={this.onChangeVisibleRows}
              style={this.styles.listView}

              // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
              onKeyboardWillShow={this.onKeyboardWillShow}
              onKeyboardDidShow={this.onKeyboardDidShow}
              // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
              onKeyboardWillHide={this.onKeyboardWillHide}
              onKeyboardDidHide={this.onKeyboardDidHide}
              // @issue keyboardShouldPersistTaps={false} + textInput focused = 2 taps are needed to trigger the ParsedText links
              //keyboardShouldPersistTaps={this.props.keyboardShouldPersistTaps}
              keyboardDismissMode={this.props.keyboardDismissMode}

              initialListSize={this.props.messages.length}
              pageSize={this.props.messages.length}

              {...this.props}
          />

        </Animated.View>
    );
  }

  setTextInputValue(text) {
    text = text || this.state.text
    this.setState({
      text,
      disabled: text.trim().length <= 0,
    });
  }
  _renderListChat() {
    
  }

  renderTextInput() {
    if (this.props.renderTextInput) {
      return this.props.renderTextInput({
        ...this.props,
        ...this.state,
        onSend:this.onSend,
        onChangeText:this.onChangeText
      });
    }
    if(this.props.hideTextInput === false) {
      return (
          <View style={{ flexDirection: 'column' }}>
            <View style={this.styles.textInputContainer}>
              {this.props.leftControlBar}
              <TextInput
                  ref={(e) => this.myTextInput = e}
                  style={this.styles.textInput}
                  placeholder={this.props.placeholder}
                  placeholderTextColor={this.props.placeholderTextColor}
                  onChangeText={this.onChangeText}
                  value={this.state.text}
                  autoFocus={this.props.autoFocus}
                  returnKeyType={this.props.submitOnReturn ? 'send' : 'default'}
                  onSubmitEditing={this.props.submitOnReturn ? this.onSend : () => { } }
                  enablesReturnKeyAutomatically={true}
                  blurOnSubmit={this.props.blurOnSubmit}
                  autoCorrect={false}
                  multiline={true}
              />
              <Button
                  style={this.styles.sendButton}
                  styleDisabled={this.styles.sendButtonDisabled}
                  onPress={this.onSend}
                  disabled={this.state.disabled}
              >
                {this.props.sendButtonText}
              </Button>
            </View>
            <View style={this.styles.viewIconChat}>
              <ChatMenu onPress={this._onPressTempMsg.bind(this)}/>

              <RelandIcon name="camera-o" color='#b8cbdb'
                          mainProps={this.styles.captureIcon}
                          size={22} textProps={{ paddingLeft: 0 }}
                          onPress={this.takePicture.bind(this)} />
              {this.props.showVideoCall ? <RelandIcon name="live-stream" color='#b8cbdb'
                          mainProps={this.styles.captureIcon}
                          size={22} textProps={{ paddingLeft: 0 }}
                          onPress={this.props.onLiveStream} /> : null}
              {/*<RelandIcon name="photos" color={gui.mainColor}
                          mainProps={this.styles.captureIcon}
                          size={22} textProps={{ paddingLeft: 0 }}
                          onPress={this.coming} />
               */}
              <RelandIcon name="location-o" color='#b8cbdb'
                          mainProps={this.styles.locationIcon}
                          size={26} textProps={{ paddingLeft: 0 }}
                          onPress={this.getLocation.bind(this)} />

            </View>

          </View>
      );
    }
    return null;
  }

  getLocation(){
    let location = this.props.location ? {lat: this.props.location.latitude, lon: this.props.location.longitude} : {};
    Actions.MMapView({onPress: this._onViTri.bind(this), location: location});
  }

  _onViTri(position){
    this.props.handleSendLocation(position);
  }

  _onPressTempMsg(msg){
    this.onChangeText(msg);
  }

    _renderVideoCallHelp() {
        let isOpenHelpStream = this.state.isOpenHelpStream && this.props.showVideoCall;
        return(
            <Modal isOpen={isOpenHelpStream}
                   onClosed={this._onCloseVideoCallHelp.bind(this)}
                   style={this.styles.viewHelpStream}
                   position={"bottom"}
                   swipeToClose={false}
                   backdropPressToClose={true}
                   animationDuration={0}
                   backdropColor={'#a9a8a8'}
                   backdropOpacity={0.4}

            >
                {this._renderVideoCallHelpContent()}
            </Modal>
        );
    }

    _onCloseVideoCallHelp() {
      if (!this.state.isOpenHelpStream) {
        return
      }
      this.props.actions.onHelpedModalChange('streamHelped', true);
      let {help} = this.props.global;
      let helped = utils.cloneRecord(help);
      helped.streamHelped = true;
      this.props.actions.updateLocalHelped(helped);
      this.setState({
          isOpenHelpStream: false
      });
    }

    _renderVideoCallHelpContent() {
        return(
            <TouchableOpacity style={this.styles.viewModalTop}
                              activeOpacity={0}
                              onPress={this._onCloseVideoCallHelp.bind(this)}
            >
              <Animatable.View
                  animation="fadeIn"
                  // direction="alternate"
              >
                <View style={this.styles.viewAnimatable}>
                  <TouchableOpacity style={this.styles.viewIconClose}
                                    activeOpacity={1}
                                    onPress={this._onCloseVideoCallHelp.bind(this)}
                  >
                    <RelandIcon name="close" color='#fff' mainProps={{ top: 6, marginRight: 5}}
                                size={8} textProps={{}}
                                noAction={true}
                    />
                  </TouchableOpacity>
                  <ScalableText style={this.styles.textContent}>
                    Nhấn vào đây để thực hiện cuộc gọi hình!
                  </ScalableText>
                </View>
                <View style={this.styles.triangle} />
              </Animatable.View>
            </TouchableOpacity>
        );
    }
  
  render() {
    return (
        <View style={this.styles.container}>
          {this.renderAnimatedView()}
          <FullLine />
          {this.renderTextInput()}
            {this._renderVideoCallHelp()}
        </View>
    );
  }
}

GiftedMessenger.defaultProps = {
  autoFocus: true,
  location: { },
  blurOnSubmit: false,
  dateLocale: '',
  displayNames: true,
  displayNamesInsideBubble: false,
  forceRenderImage: false,
  handleEmailPress: () => { },
  handlePhonePress: () => { },
  handleSend: () => { },
  handleSendLocation: () => { },
  handleUrlPress: () => { },
  hideTextInput: false,
  isLoadingEarlierMessages: false,
  keyboardDismissMode: 'interactive',
  //keyboardShouldPersistTaps: true,
  leftControlBar: null,
  loadEarlierMessagesButton: false,
  loadEarlierMessagesButtonText: 'Load earlier messages',
  maxHeight: height,
  messages: [],
  onChangeText: () => { },
  onErrorButtonPress: () => { },
  onImagePress: null,
  onLoadEarlierMessages: () => { },
  onMessageLongPress: () => { },
  parseText: false,
  placeholder: 'Nhập tin nhắn...',
  placeholderTextColor: '#5e6872',
  scrollAnimated: true,
  sendButtonText: 'Gửi',
  senderImage: null,
  senderName: 'Sender',
  styles: {},
  submitOnReturn: false,
  text: '',
  typingMessage: '',
  onLiveStream: () => { },
  showVideoCall: false
};

GiftedMessenger.propTypes = {
  autoFocus: PropTypes.bool,
  location: PropTypes.object,
  blurOnSubmit: PropTypes.bool,
  dateLocale: PropTypes.string,
  displayNames: PropTypes.bool,
  displayNamesInsideBubble: PropTypes.bool,
  forceRenderImage: PropTypes.bool,
  handleEmailPress: PropTypes.func,
  handlePhonePress: PropTypes.func,
  handleSend: PropTypes.func,
  handleSendLocation: PropTypes.func,
  handleUrlPress: PropTypes.func,
  hideTextInput: PropTypes.bool,
  isLoadingEarlierMessages: PropTypes.bool,
  keyboardDismissMode: PropTypes.string,
 // keyboardShouldPersistTaps: PropTypes.bool,
  leftControlBar: PropTypes.element,
  loadEarlierMessagesButton: PropTypes.bool,
  loadEarlierMessagesButtonText: PropTypes.string,
  maxHeight: PropTypes.number,
  messages: PropTypes.array,
  onChangeText: PropTypes.func,
  onCustomSend: PropTypes.func,
  onErrorButtonPress: PropTypes.func,
  onImagePress: PropTypes.func,
  onLoadEarlierMessages: PropTypes.func,
  onMessageLongPress: PropTypes.func,
  parseText: PropTypes.bool,
  placeholder: PropTypes.string,
  placeholderTextColor: PropTypes.string,
  renderCustomText: PropTypes.func,
  renderCustomDate: PropTypes.func,
  scrollAnimated: PropTypes.bool,
  sendButtonText: PropTypes.string,
  senderImage: PropTypes.object,
  senderName: PropTypes.string,
  styles: PropTypes.object,
  submitOnReturn: PropTypes.bool,
  typingMessage: PropTypes.string,
  onLiveStream: PropTypes.func,
  showVideoCall: PropTypes.bool
};


// module.exports = GiftedMessenger;

export default connect(mapStateToProps, mapDispatchToProps)(GiftedMessenger);