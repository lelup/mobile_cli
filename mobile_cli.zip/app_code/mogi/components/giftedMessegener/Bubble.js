import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

import ParsedText from 'react-native-parsed-text';

import PropTypes from 'prop-types';

const styles = StyleSheet.create({
  bubble: {
    borderRadius: 8,
    padding: 0
  },
  textChat: {
    color: '#000',
  },
  textLeft: {
    color: '#000',
  },
  textRight: {
    color: '#000',
  },
  textCenter: {
    textAlign: 'center',
  },
  bubbleLeft: {
    marginRight: 70,
    backgroundColor: '#f0f3f8',
    alignSelf: 'flex-start',
  },
  bubbleRight: {
    marginLeft: 70,
    backgroundColor: '#dcf4fe',
    alignSelf: 'flex-end',
  },
  bubbleCenter: {
    backgroundColor: '#007aff',
    alignSelf: 'center',
  },
  bubbleError: {
    backgroundColor: '#e01717',
  },
});

export default class Bubble extends React.Component {

  componentWillMount() {
    Object.assign(styles, this.props.styles);
  }

  renderText(text = '', position) {
    if (this.props.renderCustomText && this.props.renderCustomText(this.props) !==false) {
      return this.props.renderCustomText(this.props);
    }

    if (this.props.parseText === true) {
      return (
          <ParsedText
              style={[styles.textChat, (position === 'left' ? styles.textLeft : position === 'right' ? styles.textRight : styles.textCenter)]}
              parse={
            [
              {
                type: 'url',
                style: {
                  textDecorationLine: 'underline',
                },
                onPress: this.props.handleUrlPress,
              },
              {
                type: 'phone',
                style: {
                  textDecorationLine: 'underline',
                },
                onPress: this.props.handlePhonePress,
              },
              {
                type: 'email',
                style: {
                  textDecorationLine: 'underline',
                },
                onPress: this.props.handleEmailPress,
              },
            ]
          }
          >
            {text}
          </ParsedText>
      );
    }

    return (
        <Text style={[styles.textChat, (position === 'left' ? styles.textLeft : position === 'right' ? styles.textRight : styles.textCenter)]}>
          {text}
        </Text>
    );
  }

  render() {
    const flexStyle = {};
    const realLength = function(str) {
      return str.replace(/[^\x00-\xff]/g, "**").length; // [^\x00-\xff] - Matching non double byte character
    };
    if (this.props.text) {
      if (realLength(this.props.text) > 40) {
        flexStyle.flex = 1;
      }
    }

    return (
        <View style={[styles.bubble,
        (this.props.position === 'left' ? styles.bubbleLeft : this.props.position === 'right' ? styles.bubbleRight : styles.bubbleCenter),
        (this.props.status === 'ErrorButton' ? styles.bubbleError : null),
        flexStyle]}
        >
          {this.props.name}
          {this.renderText(this.props.text, this.props.position)}
        </View>
    );
  }
}

Bubble.propTypes = {
  position: PropTypes.oneOf(['left', 'right', 'center']),
  status: PropTypes.string,
  text: PropTypes.string,
  renderCustomText: PropTypes.func,
  styles: PropTypes.object,
  parseText: PropTypes.bool,
  name: PropTypes.element,
  handleUrlPress: PropTypes.func,
  handlePhonePress: PropTypes.func,
  handleEmailPress: PropTypes.func,
};
