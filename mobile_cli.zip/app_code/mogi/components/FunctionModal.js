'use strict';

import FontAwesomeLight from './font/FontAwesomeLight';
import Communications from 'react-native-communications';
let Analytics = require('react-native-firebase-analytics');

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import { Actions } from 'react-native-router-flux';

import * as globalActions from '../reducers/global/globalActions';
import * as meActions from '../reducers/me/meActions';
import * as chatActions from '../reducers/chat/chatActions';

import { Map } from 'immutable';

import React, { Component } from 'react';

import { View, Text, Image, StyleSheet, TouchableOpacity, Alert } from 'react-native'

import gui from '../lib/gui';
import utils from '../lib/utils';
import log from '../lib/logUtil';

let { width, height } = utils.getDimensions();

const actions = [
    globalActions,
    meActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state,
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class FunctionModal extends Component {
    constructor(props) {
        super();
        this.state = {
            items: props.items
        };
    }

    render() {

        if (!this.state.items) {
            return;
        }
        let items = [];
        this.state.items.forEach((e, index) => {
            let position = {};
            if (this.state.items.length > 1) {
                position = index == 0 ? styles.topButtonModal : (index == this.state.items.length - 1 ? styles.bottomButtonModal : styles.middleButtonModal)
            }
            if (index>0)
                items.push(
                    <View key={'breakline_' + index} style={styles.lineSpaceButton} />
                )
            items.push(                                
                <TouchableOpacity key={'item_' + index}
                    onPress={e._function.bind(this, this.props.data)}
                    style={[styles.viewButtonModal, position]}>
                    <Text style={styles.textMoreButton}>{e._text}</Text>
                </TouchableOpacity>   
                           
            )
        })

        return (
            <View style={styles.viewShowModal}>                
                    <View style={[styles.viewSwipeButton, {height: 52*this.state.items.length + (this.state.items.length-1)}]}>                        
                        {items}
                    </View>
                    <TouchableOpacity onPress={this.props.onCloseModal} style={styles.viewSwipeButton2}>
                        <Text style={[styles.textDelete, { color: gui.mainColor, fontWeight: '500', fontSize: 18 }]}>Hủy</Text>
                    </TouchableOpacity>
                
            </View>
        )
    }

    _onContentModal() { }
}

export default connect(mapStateToProps, mapDispatchToProps)(FunctionModal);

// Later on in your styles..
var styles = StyleSheet.create({
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        // flex : 1,
        width: width - 28,
        height: 'auto', 
        // backgroundColor: 'red',
        
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8, 
        marginBottom: 8,
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    topButtonModal: {
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0
    },
    middleButtonModal: {
        borderRadius: 0
    },
    bottomButtonModal: {
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    }
});

