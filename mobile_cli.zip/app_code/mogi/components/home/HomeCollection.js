'use strict';

import React, { Component } from 'react';
import { Text, StyleSheet, View, Image, TouchableOpacity, AlertIOS, Alert, ImageBackground } from 'react-native'

import gui from '../../lib/gui';
import log from '../../lib/logUtil';

import LinearGradient from 'react-native-linear-gradient';

import DanhMuc from '../../assets/DanhMuc';

import { Actions } from 'react-native-router-flux';

import MHeartIcon from '../MHeartIcon';

import GiftedSpinner from 'react-native-gifted-spinner';

import cfg from "../../cfg";

import CommonUtils from '../../lib/CommonUtils';

import ScalableText from 'react-native-text';

var Analytics = require('react-native-firebase-analytics');

const noCoverUrl = cfg.noCoverUrl;
import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();

var imageHeight = 143;


export default class HomeCollection extends Component {
  _onAdsPressed(ads) {
    if (ads.adsID && ads.adsID.length>0 && ads.adsID != "EMPTY")
      Actions.SearchResultDetail({ adsID: ads.adsID, source: 'server', imageDetail: ads.cover, owner: 'Home' });
  }

  _onSeeMore() {
    let {query} = this.props.collectionData;
    query.limit = this.props.maxAdsInMapView;
    query.pageNo = 1;
    query.isIncludeCountInResponse = true;
    this.props.onResetSearch();
    this.props.onSeeMoreCollectionChange(this.props.collectionData);
    this.props.changeLoadingExtSearchResult(true);
    Actions.SearchResultListExt();
    let userID = this.props.userID;
    Analytics.logEvent('HOME_SEEMORE', {userID: userID});
  }

  _renderAds(ads, flex) {
    if (ads) {
      return (
          <TouchableOpacity onPress={() => this._onAdsPressed(ads)} style={{ flex: flex }}>
            <ImageItem ads={ads} adsLikes={this.props.adsLikes} loggedIn={this.props.loggedIn}
                       likeAds={this.props.likeAds}
                       unlikeAds={this.props.unlikeAds} userID={this.props.userID}
                       loadHomeData={this.props.loadHomeData}
                       uploadingLikedAds={this.props.uploadingLikedAds}
                       updateLikeAdsProcessing={this.props.updateLikeAdsProcessing}
            />
          </TouchableOpacity>
      );
    } else {
      log.info("_renderAds null");

      return null
    }
  }

  render() {
    let {title1, title2, data, query} = this.props.collectionData;

    if (!data[0]) {
      return (
          <View>{null}</View>
      );
    }
    return (
        <View style={{flex:1, flexDirection: "column" }}>
          <View style={styles.titleContainer}>
            <Text style={styles.boldTitle}>BỘ SƯU TẬP</Text>
            <Text style={styles.categoryLabel}>{title1}</Text>
            <Text style={styles.arrowLabel}>{title2}</Text>
          </View>

          <View style={styles.rowItem}>
            {this._renderAds(data[0], 0.55)}
            <View style={styles.columnLine} />
            {this._renderAds(data[1], 0.45)}
          </View>

          <View style={styles.rowLine} />

          <View style={styles.rowItem}>
            {this._renderAds(data[2], 0.45)}
            <View style={styles.columnLine} />
            {this._renderAds(data[3], 0.55)}
          </View>

          <View style={styles.rowLine} />
          <View style={{ flex: 1 }}>
            {this._renderAds(data[4], 1)}
          </View>

          <TouchableOpacity style={{ backgroundColor: 'transparent' }} onPress={this._onSeeMore.bind(this)} >
            <View style={styles.moreDetail}>
              <Text style={styles.moreDetailButton}>Xem thêm</Text>
            </View>
          </TouchableOpacity>
        </View>
    )
  }
}


class ImageItem extends React.Component {
  constructor(props) {
    super(props);
    let {adsLikes, ads} = props;
    let initLikedState = (adsLikes && adsLikes.indexOf(ads.adsID) > -1);
    this.state = {
      uploadingLikedAds: props.uploadingLikedAds,
      initLikedState: initLikedState
    }
  }

  getShortedAddress(diaChi) {
    if (!diaChi) {
      return null;
    }
    var maxDiaChiLength = width*7/64;
    var index = diaChi.indexOf(',', maxDiaChiLength - 5);
    var length = 0;
    if (index !== -1 && index <= maxDiaChiLength) {
      length = index;
    } else {
      index = diaChi.indexOf(' ', maxDiaChiLength - 5);
      length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
    }
    let shortedAddress = diaChi.substring(0, length);
    if (shortedAddress.length < diaChi.length) {
      shortedAddress = shortedAddress + '...';
    }
    return shortedAddress;
  }

  render() {
    let {adsID, cover, giaFmt, gia, giaCuFmt, giaCu, khuVuc, diaChi, goiLogo} = this.props.ads;
    let shortedAddress = this.getShortedAddress(diaChi);
    if (!shortedAddress) {
      shortedAddress = khuVuc;
    }
    let giaCuText = giaCuFmt;
    let isGiamGia = giaCu && gia && gia < giaCu;
    let giaDaGiam = giaFmt;
    let detail = this.getMoreInfo(this.props.ads);

    let imageUri = { uri: cover };

    /*if (noCoverUrl == cover) {
     imageUri = require('../../assets/image/reland_house_large.jpg');
     }*/

    let bgSource = CommonUtils.getNoCoverImage();
    if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
      // imageUri = require('../../assets/image/no_cover_home.png');
      imageUri = null;
      bgSource = require('../../assets/image/no_cover_home.png');
    }

    let logoItem = null;
    if (goiLogo && goiLogo.length > 0) {
      goiLogo.sort((a, b) => a.startDateTime - b.startDateTime);
      let index = goiLogo.length - 1;
      let remainDays = utils.getRemainDay(goiLogo[index]);
      if (remainDays > 0 && goiLogo[index].text) {
        let bgColor = goiLogo.bgColor || gui.mainColor;
        logoItem = (
            <View style={[styles.logoContent, {backgroundColor: bgColor}]}>
              <ScalableText style={styles.logo}>
                {goiLogo[index].text.toUpperCase()}
              </ScalableText>
            </View>
        );
      }
    }

    return (
        <ImageBackground style={[styles.imgItem]} resizeMode={'cover'}
               source={imageUri} defaultSource={bgSource}>

          {this._returnGradient(adsID)}

          {this._renderHeartButton()}

          {this._renderGoiViTri()}
          {logoItem}

          <View style={styles.itemContent}>
            <View style={{ flexGrow: 1, paddingRight: 7 }}>
              <View style={{flexDirection: 'row'}}>
                {isGiamGia ?
                    <View style={{flexDirection: 'row'}}>
                      <Text style={styles.price} numberOfLines={1}>{giaDaGiam}</Text>
                      <Text style={[styles.price, {marginLeft: 10, textDecorationLine: 'line-through',
                                                color: '#C7C8CA'}]} numberOfLines={1}>{giaCuText}</Text>
                    </View> :
                    <Text style={styles.price} numberOfLines={1}>{giaDaGiam}</Text>
                }
              </View>
              <ScalableText style={styles.textInfo} numberOfLines={1}>{shortedAddress}</ScalableText>
              <ScalableText style={styles.textInfo}>{detail}</ScalableText>
            </View>
          </View>
        </ImageBackground>
    );
  }

  _renderGoiViTri() {
    let ads = this.props.ads;
    if (ads.goiViTri) {
      let remainDays = utils.getRemainDay(ads.goiViTri);
      let goiViTriIcon = utils.getGoiViTriIcon(ads.goiViTri);
      if (remainDays > 0 && goiViTriIcon) {
        return (
            <View style={styles.goiViTriView}>
              <Image style={styles.goiViTriIcon} source={goiViTriIcon} resizeMode={Image.resizeMode.cover} />
            </View>
        );
      }
    }
    return null;
  }

  _returnGradient(adsID) {
      if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
          return (
              null
          )
      } else {
          return (
              <LinearGradient colors={['transparent', 'rgba(58, 58, 58, 0.9)']}
                              style={styles.linearGradient2}>
              </LinearGradient>

          )
      }
  }

  _renderHeartButton() {
    let adsID = this.props.ads.adsID;
    if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
      return null;
    }
    let isLiked = this.isLiked();
    let color = isLiked ? '#E7E9EB' : 'white';
    let bgColor = isLiked ? '#EC1B77' : '#4A443F';
    let bgStyle = isLiked ? {} : { opacity: 0.55 };

    if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID) {
      return (
          <View style={styles.heartContent}>
            <View style={styles.heartButton2}>
              <GiftedSpinner size="small" color="white" />
            </View>
          </View>);
    } else {
      return (
          <View style={styles.heartContent}>
            <MHeartIcon onPress={() => this.onLike()} color={color} bgColor={bgColor} bgStyle={bgStyle}
                        mainProps={styles.heartButton} />
          </View>
      )
    }
  }

  getMoreInfo(ads) {
    var loaiTin = ads.loaiTin;
    var loaiNhaDat = ads.loaiNhaDat;
    var dienTich = '';
    if (ads.dienTichFmt && ads.dienTichFmt != 'Không rõ') {
      dienTich = ads.dienTichFmt;
    }
    var soPhongNgu = '';
    if (ads.soPhongNguFmt) {
      soPhongNgu = "   " + ads.soPhongNguFmt;
    }

    var soTang = '';
    if (ads.soTangFmt) {
      soTang = "   " + ads.soTangFmt;
    }
    var moreInfo = '';
    var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
    if (loaiNhaDat == loaiNhaDatKeys[1]) {
      moreInfo = dienTich + soPhongNgu;
    }
    else if (!loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[4])) ||
        loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[6]))) {
      moreInfo = dienTich + soTang;
    }
    else {
      moreInfo = dienTich;
    }
    return moreInfo;
  }

  isLiked() {
    const {adsLikes, ads} = this.props;
    return adsLikes && adsLikes.indexOf(ads.adsID) > -1;
  }

  onLike() {
    if (!this.props.loggedIn) {
      Actions.NewLogin({doFinalAction: this._doLike.bind(this)});
    } else {
      this._doLike();
    }
  }

  _doLike(){
    let adsID = this.props.ads.adsID;
    let userID = this.props.userID;
    if (!this.isLiked()) {
      Analytics.logEvent('HOME_LIKE', {adsID: adsID, userID: userID});
      this.props.likeAds(userID, adsID, this.props.updateLikeAdsProcessing);
    } else {
      Analytics.logEvent('HOME_UNLIKE', {adsID: adsID, userID: userID});
      this.props.unlikeAds(userID, adsID, this.props.updateLikeAdsProcessing);
    }
  }
}

var styles = StyleSheet.create({
  // fullWidthContainer: {
  //   flex: 1,
  //   alignItems: 'stretch',
  //   backgroundColor: 'white',
  // },
  // homeDetailInfo: {
  //   flex: 1,
  //   justifyContent: 'center',
  //   alignItems: 'stretch',
  //   backgroundColor: 'white',
  // },
  // scrollView: {
  //   flex: 1,
  //   marginBottom: 45
  // },
  // pageHeader: {
  //   alignItems: 'center',
  //   justifyContent: 'center',
  //   backgroundColor: gui.mainColor,
  //   height: 61
  // },
  search: {
    backgroundColor: gui.mainColor,
    height: 61
  },
  imgItem: {
    flexGrow: 1,
    height: imageHeight
  },
  column: {
    flexGrow: 1,
    alignItems: "center"
  },
  boldTitle: {
    fontFamily: gui.fontFamily,
    fontSize: 12,
    fontWeight: 'normal',
    backgroundColor: 'transparent',
    color: gui.mainColor
  },
  categoryLabel: {
    fontFamily: gui.fontFamily,
    fontSize: 17,
    fontWeight: '400',
    backgroundColor: 'transparent'
  },
  arrowLabel: {
    fontFamily: gui.fontFamily,
    fontSize: 12,
    backgroundColor: 'transparent',
    color: gui.arrowColor,
    fontWeight: 'normal'
  },
  rowItem: {
    flexDirection: "row",
  },
  moreDetail: {
    margin: 9,
    marginLeft: 25,
    marginRight: 25,
    marginBottom: 11,
    padding: 4,
    paddingBottom: 5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: gui.mainColor,
    borderRadius: 5,
    borderColor: 'transparent'
  },
  moreDetailButton: {
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15
  },
  linearGradient: {
    backgroundColor: "transparent"
  },
  logoContent: {
    position: 'absolute',
    top: imageHeight - 90,
    justifyContent: "center",
    backgroundColor: gui.mainColor,
    borderRadius: 5,
    marginLeft: 9,
    padding: 4,
    paddingLeft: 6,
    paddingRight: 6
  },
  logo: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily
  },
  goiViTriView: {
    position: 'absolute',
    backgroundColor: 'transparent',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    top: 10,
    left: 6,
    width: 40,
    height: 40
  },
  goiViTriIcon: {
    width: 29,
    height: 36
  },
  itemContent: {
    position: 'absolute',
    backgroundColor: 'transparent',
    flexDirection: 'row',
    justifyContent: 'space-between',
    top: imageHeight - 62,
  },
  price: {
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 10,
    color: 'white',
    paddingTop:1
  },
  textInfo: {
    marginTop:2,
    fontSize: 12,
    fontWeight: '300',
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 10,
    color: 'white'
  },
  // text2: {
  //   marginTop:2,
  //   fontSize: 10,
  //   fontWeight: '300',
  //   textAlign: 'left',
  //   backgroundColor: 'transparent',
  //   marginLeft: 10,
  //   color: 'white'
  // },
  heartContent: {
    position: 'absolute',
    backgroundColor: 'transparent',
    top: 8,
    right: 8,
    width:35,
    height:35,
    justifyContent:'center',
    alignItems:'center'
  },
  heartButton: {
    marginTop: 0,
    marginLeft: -10
  },
  heartButton2: {
    marginBottom: 5,
    marginLeft: 9
  },

  titleContainer: {
    height: 72,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 0,
    marginBottom: 2
    /*
     borderColor: 'red',
     borderWidth : 1,
     */
  },
  linearGradient2: {
    marginTop: imageHeight / 2,
    height: imageHeight / 2,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor: "transparent",
    flexGrow: 1
  },
  rowLine: {
    width: width,
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderColor: '#fff',
    borderTopWidth: 0.5
  },
  columnLine: {
    height: 143,
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderColor: '#fff',
    borderLeftWidth: 0.5
  }

});
