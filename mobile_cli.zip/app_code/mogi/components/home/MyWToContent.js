'use strict';

import React, { Component } from 'react';
import { Text, StyleSheet, View, Image, TouchableOpacity, TouchableHighlight, AlertIOS, Alert, ListView, ImageBackground } from 'react-native';

import {Actions} from 'react-native-router-flux';

import placeUtil from '../../lib/PlaceUtil';

import moment from 'moment';

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import DanhMuc from "../../assets/DanhMuc"

import utils from '../../lib/utils';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import CommonUtils from '../../lib/CommonUtils';

import LinearGradient from 'react-native-linear-gradient';

import MHeartIcon from '../MHeartIcon';

import GiftedSpinner from 'react-native-gifted-spinner';

import userApi from '../../lib/userApi';

import findApi from '../../lib/FindApi';

import RelandIcon from '../../components/RelandIcon';

var Analytics = require('react-native-firebase-analytics');

var { width, height } = utils.getDimensions();

var ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});

export default class MyWToContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            nhaPhuHop: {},
            showDangTinCanMua: true
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.search.myWToList !== this.props.search.myWToList) {
            this._loadNhaMoiGiamGia(nextProps.search.myWToList, 0);
        }
    }

    componentWillMount() {
        setTimeout(() => {this._fetchData()}, 300);
    }

    _fetchData() {
        let myWToList = this.props.search.myWToList;
        this._loadNhaMoiGiamGia(myWToList, 0);
    }

    _loadNhaMoiGiamGia(myWToList, index) {
        if (myWToList.length == 0) {
            return;
        }
        let myWTo = myWToList[index];
        let wto = myWTo.wto;
        let {loaiTin, content} = wto;

        let newLimit = gui.LIMIT_GIAM_GIA_ADS_LIST;
        let {giaTu, giaDen, dienTichTu, dienTichDen, loaiNhaDat, place, soPhongNgu, soPhongTam, huongNha} = content;
        let giaVal = undefined;
        let dienTichVal = undefined;

        if (giaTu > 0 || giaDen < DanhMuc.BIG) {
            giaVal = [giaTu, giaDen];
        }

        if (dienTichTu > 0 || dienTichDen < DanhMuc.BIG) {
            dienTichVal = [dienTichTu, dienTichDen];
        }

        let circle = place.circle && place.circle.radius ? place.circle : undefined;
        let polygon = place.polygon && place.polygon.length ? place.polygon : undefined;

        let searchFields = {
            loaiTin: loaiTin,
            loaiNhaDat: loaiNhaDat ? [loaiNhaDat] : undefined,
            diaChinh: {
                tinhKhongDau: place.codeTinh,
                huyenKhongDau: place.codeHuyen,
                xaKhongDau: place.codeXa,
                duAnKhongDau : place.codeDuAn,
                duongKhongDau : place.codeDuong,
                fullName: place.fullName
            },
            circle: circle,
            polygon: polygon,
            giaBETWEEN: giaVal,
            dienTichBETWEEN: dienTichVal,
            soPhongNguGREATER: soPhongNgu || undefined,
            soPhongTamGREATER: soPhongTam || undefined,
            huongNha: huongNha ? [huongNha] : undefined,
            limit : newLimit,
            pageNo : 1,
            isIncludeCountInResponse : false,
            updateLastSearch: false,
            isGiamGia: true,
            orderBy : {"name": "ngayDangTin", "type":"DESC"}
        };

        findApi.getItems(searchFields)
            .then((data) => {
                if (!data.errMsg && data.list) {
                    let nhaPhuHop = {...this.state.nhaPhuHop};
                    nhaPhuHop[wto.id] = data.list;
                    this.setState({
                        nhaPhuHop: nhaPhuHop
                    });
                    if (index < myWToList.length-1) {
                        this._loadNhaMoiGiamGia(myWToList, index+1)
                    }
                }
            });
    }

    render() {
        // if (this.props.search.loadingHomeData) {
        //     return (
        //         <View style={styles.myWToContent} />
        //     );
        // }
        let myWToList = this.props.search.myWToList;
        if (myWToList.length == 0) {
            return this.state.showDangTinCanMua ? this._renderDangTinCanMuaView() :
                <View style={styles.myWToContent} />;
        }
        let myWToItems = [];
        myWToList.map((myWTo) => {
            myWToItems.push(this._renderRow(myWTo));
        });

        return (
            <View style={styles.myWToContent}>
                {myWToItems}
            </View>
        );
    }

    _closeDangTinCanMuaModal() {
        this.setState({showDangTinCanMua: false});
    }

    _renderDangTinCanMuaView() {
        let imageSource = require('../../assets/image/tin_can_mua.png');
        let dangTinCanMuaGuide = 'Hãy đăng tin cần mua để mua được nhà có giá rẻ hơn từ những người đang cần bán gấp ';
        let xemThemLabel = '...Xem thêm';
        return (
            <View style={[styles.myWToContent, {marginTop: 0}]}>
                <View style={[styles.dangTinCanMuaTitle, {marginTop: 10}]}>
                    <View style={styles.dangTinCanMuaIconView}>
                        <Image style={styles.dangTinCanMuaIcon} resizeMode={Image.resizeMode.cover}
                               source={imageSource} defaultSource={imageSource} />
                    </View>
                    <View style={styles.dangTinCanMuaView}>
                        <TouchableHighlight
                            onPress={() => this._onWToIntroductionPress()}
                            style={{flex: 1}}
                            underlayColor="transparent"
                        >
                            <View>
                                <ScalableText style={styles.dangTinCanMuaText}>{dangTinCanMuaGuide}
                                    <ScalableText style={[styles.dangTinCanMuaText, {color: gui.mainColor, fontWeight: '400'}]}>
                                        {xemThemLabel}
                                    </ScalableText>
                                </ScalableText>
                            </View>
                        </TouchableHighlight>
                        <TouchableHighlight onPress={this._onDangTinTimMua.bind(this)} underlayColor="transparent">
                            <View style={styles.dangTinCanMuaButtonView}>
                                <ScalableText style={styles.dangTinCanMuaButtonText}>Đăng tin cần mua</ScalableText>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
                <View style={styles.separatedView} />
                <View style={styles.closeBtnView}>
                    <RelandIcon name={"close"} color={'#AFB0B3'} mainProps={styles.closeBtn}
                                size={10} onPress={this._closeDangTinCanMuaModal.bind(this)}>
                    </RelandIcon>
                </View>
            </View>
        );
    }

    _onWToIntroductionPress() {
        Actions.WToIntroduction();
    }

    _onDangTinTimMua() {
        this.props.onDangTinTimMuaPress && this.props.onDangTinTimMuaPress();
    }

    _getGiaText(wto) {
        let {content} = wto;
        let {giaTu, giaDen, loaiTin} = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _getDienTichText(wto) {
        let {content} = wto;
        let {dienTichTu, dienTichDen} = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    _getDiaChiFullname(place) {
        if (!place) {
            return '';
        }
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    _renderRow(myWTo) {
        let wto = myWTo.wto;
        let wtoID = wto.wtoID || wto.id;
        let wtsList = myWTo.wtsList || [];
        let nhaPhuHop = this.state.nhaPhuHop;
        let nhaMoiGiamGiaList = nhaPhuHop[wto.id] || [];
        if (wtsList.length == 0 && nhaMoiGiamGiaList.length == 0) {
            return null;
        }
        return (
            <View key={wtoID} style={styles.container}>
                <TouchableOpacity onPress={this._onChiTietTinCanMua.bind(this, wtoID)}>
                    <View style={styles.myWToContent}>
                        {this._renderDangBoi(wto)}
                        {this._renderChiTietWTo(wto)}
                    </View>
                </TouchableOpacity>
                {this._renderNhaCanBanGapNhanDuoc(myWTo)}
                {this._renderNhaMoiGiamGiaPhuHop(myWTo)}
                <View style={styles.separatedView} />
            </View>
        );
    }

    _renderNhaCanBanGapNhanDuoc(myWTo) {
        let wto = myWTo.wto;
        let wtsList = myWTo.wtsList;
        if (wtsList.length > gui.LIMIT_CAN_BAN_GAP_LIST) {
            wtsList = wtsList.slice(0, gui.LIMIT_CAN_BAN_GAP_LIST);
        }
        // let hashNhaCanBanGap = {};
        // let wtsList = myWTo.wtsList.filter(function (item) {
        //     let existed = hashNhaCanBanGap[item.adsID];
        //     if (!existed) {
        //         hashNhaCanBanGap[item.adsID] = true;
        //     }
        //     return !existed;
        // });
        if (wtsList.length == 0){
            return null;
        }
        let nhaCanBanGapTitle = wto.loaiTin == 0 ? 'Nhà cần bán gấp nhận được' :
            'Nhà cần cho thuê gấp nhận được';
        let nhaCanBanGapSubTitle = wto.loaiTin == 0 ? 'Tin bán của những người cần bán gấp gửi đến bạn' :
            'Tin thuê của những người cần cho thuê gấp gửi đến bạn';
        let xemThemText = 'Xem thêm >';
        return (
            <View style={styles.nhaCanBanGapView}>
                <FullLine style={{marginLeft: 10}} />
                <View style={styles.nhaCanBanGapTitleView}>
                    <View style={{flexDirection: 'row', justifyContent :'space-between'}}>
                        <ScalableText style={styles.nhaCanBanGapTitleText}>{nhaCanBanGapTitle}</ScalableText>
                        <TouchableHighlight onPress={this._onNhaCanBanGapXemThem.bind(this, myWTo.wtsList, wto )} underlayColor="transparent">
                            <View style={{paddingRight: 10}}>
                                <ScalableText style={styles.nhaCanBanGapXemThemText}>
                                    {xemThemText}
                                </ScalableText>
                            </View>
                        </TouchableHighlight>
                    </View>
                    <ScalableText style={styles.nhaCanBanGapSubTitleText}>{nhaCanBanGapSubTitle}</ScalableText>
                </View>
                {this._renderListNhaCanBanGapNhanDuoc(wtsList)}
            </View>
        )
    }

    _onNhaCanBanGapXemThem(wtsList, wto) {
        Actions.CanBanGapResultDetail({wtsList:wtsList, wto : wto});
        let wtoID = wto.wtoID || wto.id;
        Analytics.logEvent('HOME_WTS_SEEMORE', {wtoID: wtoID});
    }

    _renderListNhaCanBanGapNhanDuoc(wtsList) {
        return (
            <View style={styles.listNhaCanBanGapView}>
                <ListView style={styles.listNhaCanBanGapSubView}
                          horizontal={true}
                          enableEmptySections={true}
                          showsHorizontalScrollIndicator={false}
                          showsVerticalScrollIndicator={false}
                          dataSource={ds.cloneWithRows(wtsList)}
                          renderRow={this._renderNhaCanBanGapRow.bind(this)} />
                {this.renderLoadingView()}
            </View>
        )
    }

    renderLoadingView() {
        if (this.props.needToBuy.deleteWTSLoading) {
            return (
                <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                alignItems: 'center', justifyContent: 'center'}}>
                    <GiftedSpinner size='large' color='gray' />
                </View>
            )
        }
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.likeAds(this.props.global.currentUser.userID, adsID, this.props.updateLikeAdsProcessing);
            } else {
                this.props.unlikeAds(this.props.global.currentUser.userID, adsID, this.props.updateLikeAdsProcessing);
            }
        }
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }

    _renderNhaCanBanGapRow(wts) {
        let data = wts.ads;
        let adsID = wts.adsID;
        data.adsID = adsID;
        let isLiked = this.isLiked(adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let diaChi = data.place.diaChi;
        let shortedAddress = diaChi && diaChi.length>50 ? diaChi.substring(0,50) + "..." : diaChi;
        let giaGiam = wts && wts.giaGiam;
        let gia = utils.getPriceDisplay(data.gia, data.loaiTin);
        let giaDaGiam = giaGiam ? utils.getPriceDisplay(data.gia-giaGiam, data.loaiTin) : '';
        let giaText = 'Giá: ';
        let dienTichText = '';
        let dienTichFmt = utils.getDienTichDisplay(data.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNgu) {
            soPhongNgu = "   " + data.soPhongNgu + "pn";
        }

        let soTang = '';
        if (data.soTang) {
            soTang = "   " + data.soTang + "t";
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTichText, soPhongNgu, soTang);
        detail = detail.trim();
        return(
            <TouchableOpacity onPress={this._onChiTietNhaCanBanGapPress.bind(this, wts)} >
                <View style={{flex: 1}}>
                    <View style={[styles.eachViewKetQua, {width: width/2-15}]}>
                        <ImageBackground style={{width: width/2-15, height: 142, marginRight: 9}}
                               source={{uri: data.image.cover}}
                               resizeMode={'cover'}
                               defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                            style={styles.linearGradient2}>
                            </LinearGradient>
                            {/*<View style={styles.priceContent}>
                                <Text style={styles.priceText}>{giaText}</Text>
                            </View>*/}
                            <View style={styles.newAdsContent}>
                                <Text style={styles.newAdsText}>Mới</Text>
                            </View>
                            <View style={styles.deleteAdsContent}>
                                <RelandIcon name="close" color={'black'}
                                            mainProps={styles.captureIcon}
                                            size={10} textProps={{ paddingLeft: 0 }}
                                            onPress={this._onDeleteWTS.bind(this, wts.id)}
                                />
                            </View>
                            <View style={styles.heartContent}>
                                {this.props.search.uploadingLikedAds.uploading && this.props.search.uploadingLikedAds.adsID == data.adsID ?
                                    (<View style={styles.heartButton2}>
                                        <GiftedSpinner size="small" color="white"/>
                                    </View>)
                                    :
                                    (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                                 color={color} bgColor={bgColor}
                                                 bgStyle={bgStyle}
                                                 mainProps={styles.heartButton}/>)
                                }
                            </View>
                        </ImageBackground>
                    </View>
                    <View style={styles.viewTextContent}>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={styles.priceText} numberOfLines={1}>{giaText}</Text>
                            {giaGiam ?
                                <View style={{flexDirection: 'row'}}>
                                    <Text style={[styles.priceText, {marginLeft: 5}]} numberOfLines={1}>{giaDaGiam}</Text>
                                    <Text style={[styles.priceText, {marginLeft: 10, textDecorationLine: 'line-through',
                                                color: '#C7C8CA'}]} numberOfLines={1}>{gia}</Text>
                                </View> :
                                <Text style={[styles.priceText, {marginLeft: 5}]} numberOfLines={1}>{gia}</Text>
                            }
                        </View>
                        <Text style={styles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                        <Text style={styles.infoText}>{detail}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _onDeleteWTS(wtsID) {
        Alert.alert(
            'Thông báo',
            'Có phải bạn không muốn xem tin này?',
            [
                {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                {text: 'Đồng ý', onPress: () =>  {this._doDeleteWTS(wtsID)}}
            ],
        );
    }

    _doDeleteWTS(wtsID) {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.deleteWTS({userID: userID, wtsID: wtsID}, token).then(
            (res) => {
                if (res.status == 0) {
                    this.props.actions.loadMyWToData({userID: userID}, token);
                    Analytics.logEvent('HOME_DELETE_WTS', {wtsID: wtsID});
                } else {
                    Alert.alert('Thông báo', res.msg);
                }
            });
    }

    _onChiTietNhaCanBanGapPress(wts) {
        if (this.props.global.loggedIn) {
            this._showCanBanGapDetail(wts);
        } else {
            Actions.NewLogin({doFinalAction: () => this._showCanBanGapDetail(wts)});
        }
    }

    _showCanBanGapDetail(wts) {
        Actions.WToDetailFromHome({wts: wts});
        let wtsID = wts.wtsID || wts.id;
        Analytics.logEvent('HOME_WTS_DETAIL', {wtsID: wtsID});
    }

    _renderNhaMoiGiamGiaPhuHop(myWTo) {
        let wto = myWTo.wto;
        let nhaPhuHop = this.state.nhaPhuHop;
        let nhaMoiGiamGiaList = nhaPhuHop[wto.id] || [];
        if (nhaMoiGiamGiaList.length == 0){
            return null;
        }
        let nhaMoiGiamGiaTitle = 'Nhà mới giảm giá phù hợp';
        let nhaMoiGiamGiaSubTitle = 'Những nhà mới giảm giá phù hợp với tin cần mua';
        let xemThemText = 'Xem thêm >';
        return (
            <View style={styles.nhaMoiGiamGiaView}>
                <FullLine style={{marginLeft: 10}} />
                <View style={styles.nhaMoiGiamGiaTitleView}>
                    <View style={{flexDirection: 'row', justifyContent :'space-between'}}>
                        <ScalableText style={styles.nhaMoiGiamGiaTitleText}>{nhaMoiGiamGiaTitle}</ScalableText>
                        <TouchableHighlight onPress={this._onNhaMoiGiamGiaXemThem.bind(this, wto)} underlayColor="transparent">
                            <View style={{paddingRight: 10}}>
                                <ScalableText style={styles.nhaMoiGiamGiaXemThemText}>
                                    {xemThemText}
                                </ScalableText>
                            </View>
                        </TouchableHighlight>
                    </View>
                    <ScalableText style={styles.nhaMoiGiamGiaSubTitleText}>{nhaMoiGiamGiaSubTitle}</ScalableText>
                </View>
                {this._renderListNhaMoiGiamGiaPhuHop(nhaMoiGiamGiaList)}
            </View>
        )
    }

    _renderListNhaMoiGiamGiaPhuHop(nhaMoiGiamGiaList) {
        return (
            <View style={styles.listNhaMoiGiamGiaView}>
                <ListView style={styles.listNhaMoiGiamGiaSubView}
                          // horizontal={true}
                          enableEmptySections={true}
                          showsHorizontalScrollIndicator={false}
                          showsVerticalScrollIndicator={false}
                          dataSource={ds.cloneWithRows(this._nEveryRow(nhaMoiGiamGiaList, 2))}
                          renderRow={this._renderNhaMoiGiamGiaRow.bind(this)} />
            </View>
        )
    }

    _nEveryRow(data, n) {
        let result = [],
            temp = [];

        for (let i = 0; i < data.length; ++i) {
            if (i > 0 && i % n === 0) {
                result.push(temp);
                temp = [];
            }
            temp.push(data[i]);
        }

        if (temp.length > 0) {
            result.push(temp);
        }

        return result;
    }


    _renderNhaMoiGiamGiaRow(rowData) {
        let adsItems = [];
        rowData.forEach((ads) => adsItems.push(this._renderNhaMoiGiamGiaItem(ads)));
        return (
            <View style={{flexDirection: 'row', marginBottom: 15}}>
                {adsItems}
            </View>
        );
    }

    _renderNhaMoiGiamGiaItem(data) {
        let adsID = data.adsID || data.id;
        let isLiked = this.isLiked(adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let diaChi = data.diaChi;
        let shortedAddress = diaChi && diaChi.length>50 ? diaChi.substring(0,50) + "..." : diaChi;
        let giaCu = data.giaCuFmt || utils.getPriceDisplay(data.giaCu, data.loaiTin);
        let isGiamGia = data.giaCu && data.gia && data.gia < data.giaCu;
        let giaDaGiam = data.giaFmt || utils.getPriceDisplay(data.gia, data.loaiTin);
        let giaText = 'Giá: ';
        let dienTichText = '';
        let dienTichFmt = utils.getDienTichDisplay(data.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNgu) {
            soPhongNgu = "   " + data.soPhongNgu + "pn";
        }

        let soTang = '';
        if (data.soTang) {
            soTang = "   " + data.soTang + "t";
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTichText, soPhongNgu, soTang);
        detail = detail.trim();
        let uuid = new Date().getTime();
        return(
            <TouchableOpacity key={adsID + '_' + uuid} onPress={() => this._showNhaGiamGiaDetail(data)} >
                <View style={{flex: 1}}>
                    <View style={[styles.eachViewKetQua, {width: width/2-15}]}>
                        <ImageBackground style={{width: width/2-15, height: 142, marginRight: 9}}
                               source={{uri: data.image.cover}}
                               resizeMode={'cover'}
                               defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                            style={styles.linearGradient2}>
                            </LinearGradient>
                            {/*<View style={styles.priceContent}>
                                <Text style={styles.priceText}>{giaText}</Text>
                            </View>*/}
                            <View style={[styles.newAdsContent, {top: 10, bottom: undefined}]}>
                                <Text style={styles.newAdsText}>Mới</Text>
                            </View>
                            <TouchableOpacity style={styles.heartContent}
                                              onPress={() => this.onLike(data.adsID)}
                            >
                                {this.props.search.uploadingLikedAds.uploading && this.props.search.uploadingLikedAds.adsID == data.adsID ?
                                    (<View style={styles.heartButton2}>
                                        <GiftedSpinner size="small" color="white"/>
                                    </View>)
                                    :
                                    (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                                 color={color} bgColor={bgColor}
                                                 bgStyle={bgStyle}
                                                 mainProps={styles.heartButton}/>)
                                }
                            </TouchableOpacity>
                        </ImageBackground>
                    </View>
                    <View style={styles.viewTextContent}>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={styles.priceText} numberOfLines={1}>{giaText}</Text>
                            {isGiamGia ?
                                <View style={{flexDirection: 'row'}}>
                                    <Text style={[styles.priceText, {marginLeft: 5}]} numberOfLines={1}>{giaDaGiam}</Text>
                                    <Text style={[styles.priceText, {marginLeft: 10, textDecorationLine: 'line-through',
                                                color: '#C7C8CA'}]} numberOfLines={1}>{giaCu}</Text>
                                </View> :
                                <Text style={[styles.priceText, {marginLeft: 5}]} numberOfLines={1}>{giaDaGiam}</Text>
                            }
                        </View>
                        <Text style={styles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                        <Text style={styles.infoText}>{detail}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _showNhaGiamGiaDetail(data) {
        let adsID = data.adsID || data.id;
        Actions.SearchResultDetail({ adsID: adsID, source: 'server', imageDetail: data.image.cover });
        Analytics.logEvent('HOME_GIAMGIA_DETAIL', {adsID: adsID});
    }

    _onNhaMoiGiamGiaXemThem(wto) {
        this.props.actions.onResetGiamGiaList();
        Actions.NhaGiamGiaResultDetail({wto: wto});
        let wtoID = wto.wtoID || wto.id;
        Analytics.logEvent('HOME_GIAMGIA_SEEMORE', {wtoID: wtoID});
    }

    _renderDangBoi(wto) {
        let currentUser = this.props.global.currentUser;
        let userAvatar = currentUser && currentUser.avatar;
        let userFullname = currentUser && currentUser.fullName;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = userAvatar ? {uri: userAvatar} : defaultAvatar;
        let fullNameText = userFullname;
        let ngayDang = moment(wto.timeModified).format("HH:mm | DD/MM/YYYY");
        ngayDang = 'Tin đăng: ' + ngayDang;
        return (
            <View>
                <View style={styles.myWToRowContent}>
                    <View style={styles.avatarContent}>
                        <Image style={styles.avatarImage}
                               resizeMode={Image.resizeMode.cover}
                               source={avatarUri}
                               defaultSource={defaultAvatar}
                        />
                    </View>
                    <View style={styles.myWToRowInfo}>
                        <ScalableText style={styles.fullNameText}>{fullNameText}</ScalableText>
                        <ScalableText style={styles.ngayDangText}>{ngayDang}</ScalableText>
                    </View>
                </View>
                <FullLine style={{marginLeft: 10}} />
            </View>
        );
    }

    _renderChiTietWTo(wto) {
        let gia = this._getGiaText(wto);
        let content = wto.content;
        let {soTang, soPhongNgu, soPhongTam, huongNha, ghiChu} = content;
        let loaiTin = content.loaiTin;
        let loaiNhaDat = content.loaiNhaDat;
        // let title = wto.title;
        let loaiTinFmt = loaiTin == 0 ? 'mua' : 'thue';
        let title = DanhMuc.getLoaiNhaDatWToForDisplay(loaiTinFmt, loaiNhaDat);

        let dacDiemValues = [];
        let dienTichText = this._getDienTichText(wto);
        if (dienTichText) {
            dacDiemValues.push(dienTichText);
        }

        let soTangText = '';
        if (soTang) {
            soTangText = soTang + ' tầng';
            dacDiemValues.push(soTangText);
        }
        let soPhongTamText = '';
        if (soPhongTam) {
            soPhongTamText = soPhongTam + ' phòng tắm';
            dacDiemValues.push(soPhongTamText);
        }

        if (soPhongNgu) {
            dacDiemValues.push(soPhongNgu + ' phòng ngủ');
        }

        if (huongNha && huongNha != '-1') {
            dacDiemValues.push("Hướng " + DanhMuc.HuongNha[huongNha]);
        }

        let dacDiemItems = [];
        for (let i = 0; i<dacDiemValues.length; i = i+2) {
            let one = dacDiemValues[i];
            let other = '';
            if (i < dacDiemValues.length-1) {
                other = dacDiemValues[i+1];
            }
            let item = this.renderTwoNormalProps(one, other, {marginTop: 11}, {marginTop: 4, marginBottom: 4}, 'prop_' + i);
            dacDiemItems.push(item);
        }

        let diaChiFullname = this._getDiaChiFullname(content.place);
        let diaChi = diaChiFullname;
        let maxDiaChiLength = 100;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < diaChiFullname.length) {
            diaChi = diaChi + '...';
        }

        return (
            <View style={styles.chiTietView}>
                <View style={styles.chiTietSubView1}>
                    <Text style={[styles.chiTietTitleItem, {fontSize: 17}]}>{title}</Text>
                    <Text style={[styles.priceItem, {fontSize: 17}]}>{gia}</Text>
                    <ScalableText style={[styles.diaChiItem, {marginTop: 5, marginBottom: 10}]}>{diaChi}</ScalableText>
                    {dacDiemItems.length > 0 ? <FullLine style={{marginBottom: 4}} /> : null}
                    {dacDiemItems}
                </View>
                {ghiChu ?
                    <View style={styles.chiTietSubView2}>
                        <FullLine style={{marginTop: 4, marginBottom: 8}} />
                        <ScalableText style={styles.ghiChuItem}>{ghiChu}</ScalableText>
                    </View> : <View style={{marginBottom: 8}} /> }
            </View>
        );
    }

    renderTwoNormalProps(prop1, prop2, dotStyle, textStyle, key) {
        if (prop1 || prop2) {
            let dotIcon1Style = prop1 ? {} : {backgroundColor: 'transparent'};
            let dotIcon2Style = prop2 ? {} : {backgroundColor: 'transparent'};
            return (
                <View key={key} style={[styles.searchDetailRowAlign]}>
                    <View style={{flexDirection: 'row'}}>
                        <View style={[styles.dot2, dotIcon1Style, dotStyle]} />
                        <Text style={[styles.textHalfWidth, textStyle]}>
                            {prop1}
                        </Text>
                    </View>
                    <View style={{flexDirection: 'row', marginLeft: 10}}>
                        <View style={[styles.dot2, dotIcon2Style, dotStyle]} />
                        <Text style={[styles.textHalfWidth, textStyle]}>
                            {prop2}
                        </Text>
                    </View>
                </View>
            )
        }
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = dienTich + soTang;
        }
        else {
            moreInfo = dienTich;
        }
        return moreInfo;
    }

    _onChiTietTinCanMua(wtoID) {
        Actions.NeedToBuyDetail({wtoID: wtoID});
    }

}

var styles = StyleSheet.create({
    container: {
        flex: 1
    },
    myWToView: {
        flex: 1,
        marginTop: 10
    },
    myWToTitle: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: width-20,
        marginBottom: 10
    },
    myWToTitleText: {
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: 'bold',
        backgroundColor: 'transparent',
        marginLeft: 10
    },
    myWToXemThemText: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainColor,
        backgroundColor: 'transparent'
    },
    myWToContent: {
        flex: 1
    },
    myWToRowContent: {
        flex: 1,
        flexDirection: 'row'
    },
    avatarContent: {
        height: 80,
        width: 80,
        padding: 10
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    myWToRowInfo: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 10,
        paddingLeft: 0,
        paddingTop: 0
    },
    myWToLine1View: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: width-90
    },
    fullNameText: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    ngayDangText: {
        fontSize: 12,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    myWToInfoTitleText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    myWToInfoText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    chiTietView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 10,
        paddingRight: 10
    },
    chiTietSubView1: {
        flex: 1
    },
    chiTietSubView2: {
        flex: 1,
        paddingBottom: 15
    },
    chiTietTitleItem: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 5
    },
    ghiChuItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    priceItem: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#EB4221',
        fontFamily: gui.fontFamily,
        paddingTop: 5
    },
    diaChiItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#464648',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    nhaCanBanGapView: {
        flex: 1,
        flexDirection:"column"
    },
    nhaCanBanGapTitleView: {
        flexDirection : "column",
        backgroundColor: '#fff',
        paddingLeft: 10,
        paddingTop: 10
    },
    nhaCanBanGapTitleText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#2C2C2E'
    },
    nhaCanBanGapSubTitleText: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#464648'
    },
    nhaCanBanGapXemThemText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    listNhaCanBanGapView: {
        flex: 1,
        marginTop:6,
        marginLeft: 10,
        marginBottom: 10
    },
    listNhaCanBanGapSubView: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 20,
        marginBottom: 10
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: 142,
        height: 142,
        marginRight: 9
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 0,
        right: 8,
        width: 38,
        height: 38,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: 0,
        marginLeft: 10
    },
    viewTextContent: {
        flex: 1,
        paddingTop: 8
    },
    priceContent: {
        backgroundColor: '#EB4222',
        position: "absolute",
        top: 10,
        left: 10,
        padding: 2,
        borderRadius: 2
    },
    priceText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#EB4222'
    },
    newAdsContent: {
        backgroundColor: '#48B041',
        position: "absolute",
        bottom: 10,
        left: 10,
        padding: 2,
        paddingLeft: 5,
        paddingRight: 5,
        borderRadius: 5
    },
    newAdsText: {
        fontSize: 13,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#5C5D5F',
        width: 142
    },
    searchDetailRowAlign: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-around',
    },
    dot2 : {
        width: 5,
        height: 5,
        borderRadius: 2.5,
        marginTop: 11,
        marginLeft: 20,
        marginRight: 0,
        backgroundColor: '#C1C1C1'
    },
    textHalfWidth: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: 'black',
        marginTop: 3,
        marginBottom: 4,
        marginLeft: 5,
        marginRight: 10,
        width: width/2-20
    },
    nhaMoiGiamGiaView: {
        flex: 1,
        flexDirection:"column"
    },
    nhaMoiGiamGiaTitleView: {
        flexDirection : "column",
        backgroundColor: '#fff',
        paddingLeft: 10,
        paddingTop: 10
    },
    nhaMoiGiamGiaTitleText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#2C2C2E'
    },
    nhaMoiGiamGiaXemThemText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    nhaMoiGiamGiaSubTitleText: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#464648'
    },
    listNhaMoiGiamGiaView: {
        flex: 1,
        marginTop:6,
        marginLeft: 10,
        marginBottom: 5
    },
    listNhaMoiGiamGiaSubView: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 20
    },
    dangTinCanMuaTitle: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    dangTinCanMuaIconView: {
        width: 120,
        height: 120,
        padding: 10
    },
    dangTinCanMuaIcon: {
        width: 91,
        height: 100
    },
    dangTinCanMuaView: {
        flex: 1,
        flexDirection: 'column',
        marginRight: 25
    },
    dangTinCanMuaText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        color: '#2C2C2E',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    dangTinCanMuaButtonView: {
        flex: 1,
        borderRadius: 3,
        backgroundColor: '#1E94D6',
        padding: 5,
        marginTop: 20,
        marginBottom: 12,
        alignItems: 'center',
        justifyContent: 'center',
        width: 150
    },
    dangTinCanMuaButtonText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'center',
        color: '#fff',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    closeBtnView: {
        position: 'absolute',
        top: 5,
        // left: width - 40,
        right: 3
    },
    closeBtn: {
        flexDirection: 'row',
        backgroundColor: 'transparent',
        paddingLeft: 20,
        paddingBottom: 20,
        width: 40,
        height: 40
    },
    deleteAdsContent: {
        backgroundColor: 'white',
        position: "absolute",
        top: 10,
        left: 10,
        paddingLeft: 2,
        paddingRight: 2,
        borderRadius: 2
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    }
});