'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as historyActions from '../../reducers/history/historyActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import {
    Text, View, Image, ListView, StatusBar, RecyclerViewBackedScrollView,
    TouchableHighlight, StyleSheet, Alert, ActivityIndicator, TouchableOpacity, ImageBackground
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import MoreInfoHeader2 from '../searchList/MoreInfoHeader2';

import utils from '../../lib/utils';
const { width, height} = utils.getDimensions();

import cfg from "../../cfg";

const noCoverUrl = cfg.noCoverUrl;

import CommonUtils from '../../lib/CommonUtils';

import MMessage from '../message/MMessage';

import LinearGradient from 'react-native-linear-gradient';
import gui from "../../lib/gui";
import log from '../../lib/logUtil';
import MHeartIcon from '../MHeartIcon';
import ScalableText from 'react-native-text';
import DanhMuc from '../../assets/DanhMuc';
import GiftedSpinner from 'react-native-gifted-spinner';

import findApi from '../../lib/FindApi';

import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';

import NhaGiamGiaRow from './NhaGiamGiaRow';

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

const actions = [
    globalActions,
    searchActions,
    historyActions
];

const ds_nhaGiamGia = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});

const imageUriHome = require('../../assets/image/default_cover/no_cover_03.jpg');

class NhaGiamGiaResultDetail extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        this.state = {
            firstTime: true,
            likeAdsMessage: '',
            msgType: '',
            mounting: true,
            showMessage: false,
            msgSearchType: '',
            pageNo: 1,
            nextBtnPressed: false
        };

    }

    componentWillMount() {
        setTimeout(() => this.fetchData(() => {this._onShowMessage()}), 300);
    }

    componentDidMount() {
        this.reachBottom = false;
    }

    fetchData(successCallback) {
        let wto = this.props.wto;
        let {loaiTin, content} = wto;

        let newLimit = this.props.global.setting.maxAdsInMapView;
        let {giaTu, giaDen, dienTichTu, dienTichDen, loaiNhaDat, place, soPhongNgu, soPhongTam, huongNha} = content;
        let giaVal = undefined;
        let dienTichVal = undefined;

        if (giaTu > 0 || giaDen < DanhMuc.BIG) {
            giaVal = [giaTu, giaDen];
        }

        if (dienTichTu > 0 || dienTichDen < DanhMuc.BIG) {
            dienTichVal = [dienTichTu, dienTichDen];
        }

        let circle = place.circle && place.circle.radius ? place.circle : undefined;
        let polygon = place.polygon && place.polygon.length ? place.polygon : undefined;

        let searchFields = {
            loaiTin: loaiTin,
            loaiNhaDat: loaiNhaDat ? [loaiNhaDat] : undefined,
            diaChinh: {
                tinhKhongDau: place.codeTinh,
                huyenKhongDau: place.codeHuyen,
                xaKhongDau: place.codeXa,
                duAnKhongDau : place.codeDuAn,
                duongKhongDau : place.codeDuong,
                fullName: place.fullName
            },
            circle: circle,
            polygon: polygon,
            giaBETWEEN: giaVal,
            dienTichBETWEEN: dienTichVal,
            soPhongNguGREATER: soPhongNgu || undefined,
            soPhongTamGREATER: soPhongTam || undefined,
            huongNha: huongNha ? [huongNha] : undefined,
            limit : newLimit,
            pageNo : this.state.pageNo,
            isIncludeCountInResponse : true,
            updateLastSearch: false,
            isGiamGia: true,
            orderBy : {"name": "ngayDangTin", "type":"DESC"}
        };

        this.props.actions.findGiamGia(searchFields, successCallback, (error) =>
            Alert.alert('Thông báo',
                error,
                [{
                    text: 'Đóng',
                    onPress: () => { }
                }]));
    }

    _onShowMessage() {
        this.setState({showMessage: true, mounting: false});
        this._onSearchMsgAnimationStart();
    }

    _onSearchMsgAnimationStart() {
        this.setState({msgSearchType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgSearchType: 'fadeOutUp'})}, 4000);
    }

    _onSearchAnimationEnd() {
        if (this.state.msgSearchType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({msgSearchType: '', showMessage: false})}, 2000);
        }
    }

    _renderTotalResultView(){
        let myProps = this.props;
        let loading = myProps.search.loadingExtFromServer;
        let tinGiamGiaList = myProps.search.result.listGiamGia;
        let numberOfTinGiamGia = tinGiamGiaList.length;
        let totalCount = myProps.search.result.totalCountGiamGia || 0;
        let limit = myProps.global.setting.maxAdsInMapView;
        let errorMsg = myProps.search.result.errorMsg;
        let {showMessage, mounting, pageNo} = this.state;

        let totalPages = totalCount/ limit;
        let beginAdsIndex = (pageNo-1)*limit+1;
        let endAdsIndex = pageNo < totalPages ? pageNo*limit : (pageNo-1)*limit+numberOfTinGiamGia;
        if (totalCount < endAdsIndex) {
            totalCount = endAdsIndex;
        }
        let textValue = totalCount > limit ? 'Đang hiển thị từ ' + beginAdsIndex + "-" + endAdsIndex + ' / ' + totalCount + ' kết quả' :
        'Đang hiển thị ' + totalCount + ' kết quả';
        if (numberOfTinGiamGia == 0) {
            textValue = "";
        }

        if (errorMsg || numberOfTinGiamGia == 0) {
            return null;
        }
        else if(loading || mounting){
            return null;
        }

        if (showMessage && this.state.msgSearchType != '') {
            return (
                <MMessage barStyle="light-content"
                          animation={this.state.msgSearchType}
                          duration={500}
                          onAnimationEnd={this._onSearchAnimationEnd.bind(this)}
                          textValue={textValue}
                          mainStyle={{top: 64}}
                />
            );
        }
    }

    _renderLoadingView() {
        return (
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'flex-start', justifyContent: 'flex-start'}}>
                <ImageBackground style={myStyles.viewChildRow}
                       source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                >
                    <View style={[myStyles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                    <View style={[myStyles.viewLineLoaderRow, {marginBottom: 21}]} />
                </ImageBackground>
                <ImageBackground style={myStyles.viewChildRow}
                       source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                >
                    <View style={[myStyles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                    <View style={[myStyles.viewLineLoaderRow, {marginBottom: 21}]} />
                </ImageBackground>
                <ImageBackground style={myStyles.viewChildRow}
                       source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                >
                    <View style={[myStyles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                    <View style={[myStyles.viewLineLoaderRow, {marginBottom: 21}]} />
                </ImageBackground>
                <ImageBackground style={myStyles.viewChildRow}
                       source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                >
                    <View style={[myStyles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                    <View style={[myStyles.viewLineLoaderRow, {marginBottom: 21}]} />
                </ImageBackground>
            </View>
        );
    }

    render() {
        let title1 = 'Nhà mới giảm giá phù hợp';
        let myProps = this.props;
        let dataNhaGiamGia = myProps.search.result.listGiamGia;
        let loading = myProps.search.loadingExtFromServer;
        let loadingView = (this.state.mounting || loading) && (!dataNhaGiamGia || dataNhaGiamGia.length === 0);

        let ds = ds_nhaGiamGia.cloneWithRows(dataNhaGiamGia);

        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={myStyles.viewListBody}>
                    {loadingView ?
                        this._renderLoadingView()
                        :
                        <ListView ref={(listView) => { this._listView = listView; }}
                              style={{flex: 1}}
                              dataSource={ds}
                              renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0), (rowID == (ds._dataBlob.s1.length-1)))}
                              enableEmptySections={true}
                              onScroll={this.handleScroll.bind(this)}/>
                    }
                </View>
                {this._renderLikeAdsMessage()}
                {this._renderTotalResultView()}
                <View style={myStyles.search}>
                    <MoreInfoHeader2 title1={title1} //title2={title2}
                    />
                </View>
            </View>
        )
    }

    _scrollToTop() {
        let pageNo = this.state.pageNo;

        if (pageNo == 1 || !this.state.nextBtnPressed) {
            setTimeout(() => this._scrollTo(0), 100);
        } else {
            setTimeout(() => this._scrollTo(40), 100);
        }
    }

    _scrollTo(pos) {
        if (this._listView) {
            this._listView.scrollTo({y: pos});
        }
    }

    handleScroll(event: Object) {
        let pos = event.nativeEvent.contentOffset.y;
        this.reachBottom = pos > 100;
    }

    _renderRow (data, sectionID , rowID, isFirstRow, isLastRow){
        let myProps = this.props;
        let pageNo = this.state.pageNo;
        let totalCount = myProps.search.result.totalCountGiamGia || 0;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalPages = totalCount / limit;

        let showFirstLoading = pageNo > 2 || (!this.reachBottom && !this.state.mounting);
        let showFirstControl = pageNo > 1;
        let loading = myProps.search.loadingExtFromServer;
        let showLastControl = !loading && totalPages && pageNo < totalPages;

        return(
            <NhaGiamGiaRow ads={data}
                           isLiked={this.isLiked.bind(this)}
                           onLike={this.onLike.bind(this)}
                           {...this.props}
                           isFirstRow={isFirstRow}
                           showFirstControl={showFirstControl}
                           showFirstLoading={showFirstLoading}
                           isLastRow={isLastRow}
                           showLastControl={showLastControl}
                           loadPreviousPage={() => this.loadPreviousPage()}
                           loadNextPage={() => this.loadNextPage()}
                           getPagingTitle={this.getPagingTitle.bind(this)} />
        );
    }

    loadPreviousPage() {
        let myProps = this.props;
        let loading = myProps.search.loadingExtFromServer;
        if (loading) {
            return;
        }

        let pageNo = this.state.pageNo;

        if (pageNo > 1) {
            pageNo = pageNo-1;
            this.setState({nextBtnPressed: false, pageNo: pageNo});
            this.props.actions.onResetGiamGiaList();
            this.fetchData(() => {this._scrollToTop()});
        }
    }

    loadNextPage() {
        let myProps = this.props;
        let loading = myProps.search.loadingExtFromServer;
        if (loading) {
            return;
        }

        let pageNo = this.state.pageNo;
        let totalCount = myProps.search.result.totalCountGiamGia || 0;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalPages = totalCount / limit;

        if (totalPages && pageNo < totalPages) {
            pageNo = pageNo+1;
            this.setState({nextBtnPressed: true, pageNo: pageNo});
            this.props.actions.onResetGiamGiaList();
            this.fetchData(() => {this._scrollToTop()});
        }
    }

    getPagingTitle() {
        let myProps = this.props;
        let tinGiamGiaList = myProps.search.result.listGiamGia;
        let numberOfTinGiamGia = tinGiamGiaList.length;
        let totalCount = myProps.search.result.totalCountGiamGia || 0;
        let limit = myProps.global.setting.maxAdsInMapView;
        let pageNo = this.state.pageNo;
        let totalPages = totalCount/ limit;
        let beginAdsIndex = (pageNo-1)*limit+1;
        let endAdsIndex = pageNo < totalPages ? pageNo*limit : (pageNo-1)*limit+numberOfTinGiamGia;
        if (totalCount < endAdsIndex) {
            totalCount = endAdsIndex;
        }
        return (beginAdsIndex > 1 || totalCount > endAdsIndex) ? 'Đang hiển thị từ ' + beginAdsIndex + "-" + endAdsIndex + ' / ' + totalCount + ' kết quả' :
        'Đang hiển thị ' + totalCount + ' kết quả';
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            }
        }
    }

    _updateLikeAdsProcessing(likeAdsMessage) {
        this.setState({firstTime: false, likeAdsMessage: likeAdsMessage});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 2000);
    }

    _renderLikeAdsMessage() {
        let uploading = this.props.history.uploadingLikedAds.uploading;
        if (this.state.firstTime || uploading || this.state.msgType == '') {
            return null;
        }
        let textValue = this.state.likeAdsMessage;
        return (
            <MMessage mainStyle={{top: 64}}
                      barStyle="light-content"
                      animation={this.state.msgType}
                      duration={500}
                      onAnimationEnd={this._onAnimationEnd.bind(this)}
                      textValue={textValue}/>
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({msgType: ''})}, 2000);
        }
    }
}

const myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    search: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 64,
        flexDirection:'row',
        backgroundColor:'#1ea7de',
        borderBottomWidth:1,
        borderColor:'#1ea7de'
    },
    viewListBody: {
        marginTop: 0,
        position: 'absolute',
        top:64,
        width: width,
        height: height-64
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: width,
        height: 180,
    },
    listMoRong:{
        justifyContent:'center',
        width: width,
        height: 180,
    },
    linearGradient2: {
        marginTop: 71,
        height: 71,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent",
        flexGrow: 1
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 8,
        right: 8,
        width: 35,
        height: 35,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 10
    },
    viewTextContent: {
        paddingTop: 8,
        marginTop: -71,
        marginLeft: 12,
        height: 71,
        width: width
    },
    priceText: {
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#fff',
        paddingTop:1,
        fontFamily: gui.fontFamily
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    viewChildRow: {
        width: width,
        height: 181,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingLeft: 17,
        borderBottomWidth: 1,
        borderColor: '#eaebed'
    },
    viewLineLoaderRow: {
        height: 14,
        width: width/3,
        backgroundColor: 'rgba(234, 234, 234, 0.5)',
        marginBottom: 8
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NhaGiamGiaResultDetail);
