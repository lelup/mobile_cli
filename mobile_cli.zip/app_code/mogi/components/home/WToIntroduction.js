'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

const {width, height} = util.getDimensions();

class WToIntroduction extends React.Component {
    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                        Giới thiệu đăng tin cần mua
                    </ScalableText>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyBorrow()}
            </View>
        );
    }

    _renderBodyBorrow() {

        let aboutLine1 = 'Sau khi bạn đăng tin cần mua, landber sẽ chuyển nhu cầu này đến tất cả người bán phù hợp.';
        let aboutLine2 = 'Trong số những người bán phù hợp này, người cần bán gấp (đã đăng ký với Landber) sẽ gửi thông tin nhà đang bán và mức giá sẽ giảm thêm cho bạn (so với giá trong tin đăng).' ;
        let aboutLine3 = 'Từ những tin đăng nhận được , bạn lựa chọn ra tin phù hợp nhất để liên lạc lại (Gọi điện, chat, nhắn tin). Chỉ sau khi bạn liên lạc với người bán, họ mới có thông tin của bạn (Số điện thoại, email). Thông tin của bạn ( số điện thoại, email) sẽ được giữ bí mật với tất cả người dùng sử dụng landber.' ;
        let address1 = 'Địa chỉ liên hệ:';
        let address2 = 'Công ty CP Đầu tư Reway Group';
        let address3 = 'Trụ sở chính: ';
        let address4 = 'Tầng 8th Hapulico Center Building, Số 85 Vũ Trọng Phụng, Q. Thanh Xuân, Hà Nội.';
        let mailContact1 = 'Email : ';
        let mailContact2 = 'info@landber.com';
        let mailContact3 = ' | Hotline: ';
        let mailContact4 = '0961.004.691';

        return(
            <ScrollView style={{flex: 1}} contentContainerStyle={styles.viewBody}>
                <ScalableText style={styles.textAboutUs}>{aboutLine1}</ScalableText>
                <View style={styles.separatedView} />
                <ScalableText style={[styles.textAboutUs, {marginTop: 10}]}>{aboutLine2}</ScalableText>
                <View style={styles.separatedView} />
                <ScalableText style={[styles.textAboutUs, {marginTop: 10}]}>{aboutLine3}</ScalableText>
                <View style={[styles.separatedView, {height: 10, width: width, marginLeft: 0}]} />

                <ScalableText style={[styles.textAboutUs, {marginTop: 15}]}>{address1}</ScalableText>
                <ScalableText style={[styles.textAboutUs, {marginTop: 8, fontSize: 17, color: gui.mainColor, fontWeight: '500'}]}>
                    {address2}
                </ScalableText>
                <ScalableText style={[styles.textAboutUs, {marginTop: 5}]}>{address3}</ScalableText>
                <ScalableText style={[styles.textAboutUs, {marginTop: 5}]}>{address4}</ScalableText>
                <ScalableText style={[styles.textAboutUs, {marginTop: 5}]}>
                    {mailContact1}
                    <ScalableText style={[styles.textAboutUs, {color: gui.mainColor}]}>{mailContact2}</ScalableText>
                    {mailContact3}
                    <ScalableText style={[styles.textAboutUs, {color: '#ff0000'}]}>{mailContact4}</ScalableText>
                </ScalableText>
            </ScrollView>
        );
    }

}
export default WToIntroduction;

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 44
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 44
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingLeft: 0,
        paddingTop: 17,
        paddingRight: 6
    },
    textAboutUs: {
        fontFamily:gui.fontFamily,
        fontWeight: '400',
        textAlign:'left',
        color: '#3f3f3f',
        fontSize: 17,
        marginLeft: 12,
        marginBottom: 10
    },
    separatedView: {
        height: 0.5,
        width: width-24,
        marginLeft: 12,
        backgroundColor: '#F0F0F2'
    },
});