'use strict';

import React, { Component } from 'react';
import { Text, StyleSheet, View, Image, TouchableOpacity, AlertIOS, Alert, ImageBackground, ListView } from 'react-native'

import gui from '../../lib/gui';
import log from '../../lib/logUtil';
import  FullLine from '../line/FullLine';
import LinearGradient from 'react-native-linear-gradient';
import DanhMuc from '../../assets/DanhMuc';

import { Actions } from 'react-native-router-flux';

import MHeartIcon from '../MHeartIcon';

import GiftedSpinner from 'react-native-gifted-spinner';
import FontAwesomeLight from '../font/FontAwesomeLight';

import cfg from "../../cfg";

import CommonUtils from '../../lib/CommonUtils';

import ScalableText from 'react-native-text';
import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';

var Analytics = require('react-native-firebase-analytics');

const noCoverUrl = cfg.noCoverUrl;
import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

var imageHeight = 143;
const ds_listSourceAds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

export default class AgentHomeCollection extends Component {

  render() {
    let { title1, title2, groupImage, data, query } = this.props.collectionData;    
    if (!data[0]) {
      return (
        <View>{null}</View>
      );
    }
    let dataToRender = data;
    let imageEachInbox = { uri: groupImage };
    let defaultCover = require('../../assets/image/no_cover.jpg');
    if (!groupImage) {
      imageEachInbox = defaultCover;
    }
    return (
      <View style={{ flex: 1, flexDirection: "column", backgroundColor: '#fff' }}>

        {/* <View style={styles.titleContainer}>
          <View style={{ flexDirection: "row", justifyContent: 'flex-start', alignItems: 'center' }}>
            <TouchableOpacity style={styles.viewEachInboxChild}>
              <Image style={styles.myAvatarInbox}
                source={imageEachInbox}
              />
            </TouchableOpacity>
            <View style={styles.viewMainTitle}>
              <Text style={styles.categoryLabel} numberOfLines={1}>{title1}</Text>
            </View>
          </View>          
        </View> */}

        {this._renderListAdsInOneCollection(dataToRender)}

      </View>
    )
  }

  _renderListAdsInOneCollection(data) {
    return (
      <View style={{ marginTop: 0, marginBottom: 10 }}>
        <ListView contentContainerStyle={styles.listSource}
          horizontal={true}
          enableEmptySections={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}
          dataSource={ds_listSourceAds.cloneWithRows(data)}
          renderRow={this._renderRowAdsByGroup.bind(this)} />
      </View>
    )
  }

  _renderRowAdsByGroup(data) {
    // console.log('_renderRowAdsByGroup - one row', data)
    return (
      <TouchableOpacity style={styles.viewRowSourceAds}
        onPress={this._onPressRowSource.bind(this, data)}>
          {this._renderImageSource(data)}
          {this._renderInfoSource(data)}
          <FullLine style={{marginLeft: 9, marginRight: 9}} />
          {this._renderGiaFmt(data)}
          {this._renderRenderAddress(data)}
          {this._renderDetailSource(data)}
      </TouchableOpacity>
    )
  }

  _onPressRowSource(ads) {
    if (ads.adsID && ads.adsID.length > 0 && ads.adsID != "EMPTY")
      Actions.GroupAdsDetail({ adsID: ads.adsID, imageDetail: ads.cover });
  }

  _renderImageSource(data) {
    let priceSource = data.giaFmt;
    let itemsSourceUrl = data.cover;
    let imageMainPost = { uri: itemsSourceUrl };
    let defaultCover = require('../../assets/image/no_cover.jpg');
    return (
      <ImageBackground style={styles.imgRowItem}
        source={imageMainPost} defaultSource={defaultCover}>
        <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
          style={styles.linearGradientMain}>
          {this._renderLogoIcons(data)}
          {this._renderUserLogo(data)}
          {/*<View style={styles.viewPriceSource}>*/}
            {/*<Text style={styles.textPrice}>{priceSource}</Text>*/}
          {/*</View>*/}
        </LinearGradient>
      </ImageBackground>
    )
  }

    _renderUserLogo(data) {
        let logoItems = [];

        let index = 0;

        if (data.banGap) {
            let marginLeft = index == 0 ? 0 : 8;
            let banGapText = data.loaiTin ? DanhMuc.THUE_GAP : DanhMuc.BAN_GAP;
            logoItems.push(
                <View key={'logoBanGap'}
                      style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                  <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                  >{banGapText}</Text>
                </View>
            );
            index++;
        }


        if (data.chinhChuDangTin) {
            let marginLeft = index == 0 ? 0 : 8;
            logoItems.push(
                <View key={'logoChinhChuDangTin'}
                      style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                  <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                  >{DanhMuc.CHINH_CHU}</Text>
                </View>
            );
            index++;
        }

        return (
            <View style={styles.viewUserLogo}>
                {logoItems}
            </View>
        );
    }

  _renderLogoIcons(data) {
    let logoSource = utils.getGoiViTriIcon(data.goiViTri);

    // let iconHeart = require('../../assets/image/group/farourite_white.png');
    // let iconDelete = require('../../assets/image/group/close_white.png');
    let defaultCover = require('../../assets/image/no_cover.jpg');

    // let isLiked = this.isLiked(data);
    // let color = isLiked ? '#E7E9EB' : 'white';
    // let bgColor = isLiked ? '#EC1B77' : '#4A443F';
    // let bgStyle = isLiked ? {} : { opacity: 0.55 };

    if (logoSource)
      return (
        <View style={styles.viewIconsSource}>
          {/* <TouchableOpacity style={styles.viewLogo}>
            <Image
              resizeMode={"cover"}
              source={logoSource}
              defaultSource={defaultCover}
              style={styles.iconLogo} />
          </TouchableOpacity> */}
          <TouchableOpacity style={styles.viewHeartIcon}>
            {/* <Image
              resizeMode={"cover"}
              source={iconHeart}
              defaultSource={defaultCover}
              style={styles.iconHeart} /> */}
            {/*<MHeartIcon onPress={this.onLike.bind(this, data)} color={color} bgColor={bgColor} bgStyle={bgStyle}
              mainProps={styles.heartButton} />*/}
            {this._renderHeartButton(data)}
          </TouchableOpacity>
          {/* <TouchableOpacity style={styles.viewDeleteIcon}>
            <Image
              resizeMode={"cover"}
              source={iconDelete}
              defaultSource={defaultCover}
              style={styles.iconDelete} />
          </TouchableOpacity> */}

        </View>
      );
    else
      return (
        <View style={styles.viewIconsSource}>
          <TouchableOpacity style={styles.viewHeartIcon}>
            {/* <Image
              resizeMode={"cover"}
              source={iconHeart}
              defaultSource={defaultCover}
              style={styles.iconHeart} /> */}
              {/*<MHeartIcon onPress={this.onLike.bind(this, data)} color={color} bgColor={bgColor} bgStyle={bgStyle}
              mainProps={styles.heartButton} />*/}
              {this._renderHeartButton(data)}
          </TouchableOpacity>
          {/* <TouchableOpacity style={styles.viewDeleteIcon}>
            <Image
              resizeMode={"cover"}
              source={iconDelete}
              defaultSource={defaultCover}
              style={styles.iconDelete} />
          </TouchableOpacity> */}

        </View>
      )
  }

  _renderHeartButton(data) {
      let adsID = data.adsID;
      if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
          return null;
      }
      let isLiked = this.isLiked(data);
      let color = isLiked ? '#E7E9EB' : 'white';
      let bgColor = isLiked ? '#EC1B77' : '#4A443F';
      let bgStyle = isLiked ? {} : { opacity: 0.55 };

      if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID) {
          return (
              <View style={styles.heartButton2}>
                <GiftedSpinner size="small" color="white" />
              </View>
          )
      } else {
          return (
              <MHeartIcon onPress={this.onLike.bind(this, data)} color={color} bgColor={bgColor} bgStyle={bgStyle}
                          mainProps={styles.heartButton} />
          )
      }
  }

    _renderGiaFmt(data) {
       let gia = data.giaFmt;
        let giaFmt = `Giá: ${gia}`;
        return(
           <View style={styles.viewPriceSource}>
            <Text style={styles.textPrice}>{giaFmt}</Text>
          </View>
        )

    }

  _renderInfoSource(data) {
    let textInfo = data.title || (data.place ? utils.getTitleAdsDetail(data) : '');
    return (
      <View style={styles.viewInfoSource}>
        <Text style={styles.textInfo2} numberOfLines={2}>{textInfo}</Text>
      </View>
    )
  }

  _renderDetailSource(data) {
    let areaValue = data.dienTichFmt;
    let bedroomValue = data.soPhongNgu;
    let bathroomValue = data.soPhongTam;
    return (
      <View style={styles.viewDetailPost}>
        {this._renderDienTich(areaValue)}
        {this._renderPhongNgu(bedroomValue)}
        {this._renderPhongTam(bathroomValue)}
      </View>
    )
  }

  // why bed and bad icon always right detail?
  _renderPhongNgu(bedroomValue) {
    if (bedroomValue) 
      return (
        <View style={{ marginLeft: 15, height: 16, alignItems: 'center', flexDirection: 'row', justifyContent: 'flex-start' }}>
          <FontAwesomeLight name="bed" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
          <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
        </View>
      )
    else return (<View></View>)
  }

  _renderPhongTam(bathroomValue) {
    if (bathroomValue) 
      return (
        <View style={{ marginLeft: 12, height: 16, alignItems: 'center', flexDirection: 'row', justifyContent: 'flex-start' }}>
          <FontAwesomeLight noAction={true}
              name="bath" color={gui.textPostAds}
              mainProps={{ marginTop: 10 }}
              size={15} />
            <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
        </View>
      )
    else return (<View></View>)
  }


  _renderDienTich(areaValue) {
    if (areaValue && areaValue != DanhMuc.KHONG_RO)
      return (
        <View style={styles.viewAreaValue}>
                <FontAwesomeLight name='expand' color={gui.textPostAds} size={15}
                  mainProps={{ paddingLeft: 0, paddingRight: 0, marginTop: 11 }}
                  noAction={true}
                />
                <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
        </View>
      )
    else 
      return (<View></View>)
  }

  _renderRenderAddress(data) {
    let addressRow = data.place ? data.place.diaChi : '';
    return (
      <View style={styles.viewAddressRow}>
        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
        <Text style={[styles.textAllService, { fontSize: 15, marginLeft: 8, color: gui.textPostAds }]} numberOfLines={1}>{addressRow}</Text>
      </View>
    );
  }

  isLiked(data) {
    const { adsLikes } = this.props;    
    return adsLikes && adsLikes.indexOf(data.adsID) > -1;
  }

  onLike(data) {
    if (!this.props.loggedIn) {
      Actions.NewLogin({ doFinalAction: this._doLike.bind(this, data) });
    } else {
      this._doLike(data);
    }
  }

  _doLike(data) {
    console.log('running here _doLike ...')
    let adsID = data.adsID;
    let userID = this.props.userID;
    if (!this.isLiked(data)) {
      Analytics.logEvent('HOME_LIKE', { adsID: adsID, userID: userID });
      this.props.likeAds(userID, adsID, this.props.updateLikeAdsProcessing);
    } else {
      Analytics.logEvent('HOME_UNLIKE', { adsID: adsID, userID: userID });
      this.props.unlikeAds(userID, adsID, this.props.updateLikeAdsProcessing);
    }
  }
}

class ImageItem extends React.Component {
  constructor(props) {
    super(props);
    let { adsLikes, ads } = props;
    let initLikedState = (adsLikes && adsLikes.indexOf(ads.adsID) > -1);
    this.state = {
      uploadingLikedAds: props.uploadingLikedAds,
      initLikedState: initLikedState
    }
  }

  getShortedAddress(diaChi) {
    if (!diaChi) {
      return null;
    }
    var maxDiaChiLength = width * 7 / 64;
    var index = diaChi.indexOf(',', maxDiaChiLength - 5);
    var length = 0;
    if (index !== -1 && index <= maxDiaChiLength) {
      length = index;
    } else {
      index = diaChi.indexOf(' ', maxDiaChiLength - 5);
      length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
    }
    let shortedAddress = diaChi.substring(0, length);
    if (shortedAddress.length < diaChi.length) {
      shortedAddress = shortedAddress + '...';
    }
    return shortedAddress;
  }

  render() {
    let { adsID, cover, giaFmt, gia, giaCuFmt, giaCu, khuVuc, place, goiLogo } = this.props.ads;
    let shortedAddress = this.getShortedAddress(place.diaChi);
    if (!shortedAddress) {
      shortedAddress = khuVuc;
    }
    let giaCuText = giaCuFmt;
    let isGiamGia = giaCu && gia && gia < giaCu;
    let giaDaGiam = giaFmt;
    let detail = this.getMoreInfo(this.props.ads);

    let imageUri = { uri: cover };

    /*if (noCoverUrl == cover) {
     imageUri = require('../../assets/image/reland_house_large.jpg');
     }*/

    let bgSource = CommonUtils.getNoCoverImage();
    if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
      // imageUri = require('../../assets/image/no_cover_home.png');
      imageUri = null;
      bgSource = require('../../assets/image/no_cover_home.png');
    }

    let logoItem = null;
    if (goiLogo && goiLogo.length > 0) {
      goiLogo.sort((a, b) => a.startDateTime - b.startDateTime);
      let index = goiLogo.length - 1;
      let remainDays = utils.getRemainDay(goiLogo[index]);
      if (remainDays > 0 && goiLogo[index].text) {
        let bgColor = goiLogo.bgColor || gui.mainColor;
        logoItem = (
          <View style={[styles.logoContent, { backgroundColor: bgColor }]}>
            <ScalableText style={styles.logo}>
              {goiLogo[index].text.toUpperCase()}
            </ScalableText>
          </View>
        );
      }
    }

    return (
      <ImageBackground style={[styles.imgItem]} resizeMode={'cover'}
        source={imageUri} defaultSource={bgSource}>

        {this._returnGradient(adsID)}

        {this._renderHeartButton()}

        {this._renderGoiViTri()}
        {logoItem}

        <View style={styles.itemContent}>
          <View style={{ flexGrow: 1, paddingRight: 7 }}>
            <View style={{ flexDirection: 'row' }}>
              {isGiamGia ?
                <View style={{ flexDirection: 'row' }}>
                  <Text style={styles.price} numberOfLines={1}>{giaDaGiam}</Text>
                  <Text style={[styles.price, {
                    marginLeft: 10, textDecorationLine: 'line-through',
                    color: '#C7C8CA'
                  }]} numberOfLines={1}>{giaCuText}</Text>
                </View> :
                <Text style={styles.price} numberOfLines={1}>{giaDaGiam}</Text>
              }
            </View>
            <ScalableText style={styles.textInfo} numberOfLines={1}>{shortedAddress}</ScalableText>
            <ScalableText style={styles.textInfo}>{detail}</ScalableText>
          </View>
        </View>
      </ImageBackground>
    );
  }

  _renderGoiViTri() {
    let ads = this.props.ads;
    if (ads.goiViTri) {
      let remainDays = utils.getRemainDay(ads.goiViTri);
      let goiViTriIcon = utils.getGoiViTriIcon(ads.goiViTri);
      if (remainDays > 0 && goiViTriIcon) {
        return (
          <View style={styles.goiViTriView}>
            <Image style={styles.goiViTriIcon} source={goiViTriIcon} resizeMode={Image.resizeMode.cover} />
          </View>
        );
      }
    }
    return null;
  }

  _returnGradient(adsID) {
    if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
      return (
        null
      )
    } else {
      return (
        <LinearGradient colors={['transparent', 'rgba(58, 58, 58, 0.9)']}
          style={styles.linearGradient2}>
        </LinearGradient>

      )
    }
  }

  // _renderHeartButton() {
  //   let adsID = this.props.ads.adsID;
  //   if (!adsID || adsID.length == 0 || adsID == 'EMPTY') {
  //     return null;
  //   }
  //   let isLiked = this.isLiked();
  //   let color = isLiked ? '#E7E9EB' : 'white';
  //   let bgColor = isLiked ? '#EC1B77' : '#4A443F';
  //   let bgStyle = isLiked ? {} : { opacity: 0.55 };

  //   if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID) {
  //     return (
  //       <View style={styles.heartContent}>
  //         <View style={styles.heartButton2}>
  //           <GiftedSpinner size="small" color="white" />
  //         </View>
  //       </View>);
  //   } else {
  //     return (
  //       <View style={styles.heartContent}>
  //         <MHeartIcon onPress={() => this.onLike()} color={color} bgColor={bgColor} bgStyle={bgStyle}
  //           mainProps={styles.heartButton} />
  //       </View>
  //     )
  //   }
  // }

  getMoreInfo(ads) {
    var loaiTin = ads.loaiTin;
    var loaiNhaDat = ads.loaiNhaDat;
    var dienTich = '';
    if (ads.dienTichFmt && ads.dienTichFmt != 'Không rõ') {
      dienTich = ads.dienTichFmt;
    }
    var soPhongNgu = '';
    if (ads.soPhongNguFmt) {
      soPhongNgu = "   " + ads.soPhongNguFmt;
    }

    var soTang = '';
    if (ads.soTangFmt) {
      soTang = "   " + ads.soTangFmt;
    }
    var moreInfo = '';
    var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
    if (loaiNhaDat == loaiNhaDatKeys[1]) {
      moreInfo = dienTich + soPhongNgu;
    }
    else if (!loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
      || (loaiNhaDat == loaiNhaDatKeys[3])
      || (loaiNhaDat == loaiNhaDatKeys[4])) ||
      loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[6]))) {
      moreInfo = dienTich + soTang;
    }
    else {
      moreInfo = dienTich;
    }
    return moreInfo;
  }

  
}

const styles = StyleSheet.create({
  search: {
    backgroundColor: gui.mainColor,
    height: 61
  },
  imgItem: {
    flexGrow: 1,
    height: imageHeight
  },
  column: {
    flexGrow: 1,
    alignItems: "center"
  },
  
  categoryLabel: {
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: gui.mainTextColor,
    fontSize: 20,
    marginLeft: 8
  },
  arrowLabel: {
    fontFamily: gui.fontFamily,
    fontSize: 12,
    backgroundColor: 'transparent',
    color: gui.arrowColor,
    fontWeight: 'normal',
    marginLeft: 32,
    marginTop: 2
  },
  rowItem: {
    flexDirection: "row",
  },
  moreDetail: {
    margin: 9,
    marginLeft: 25,
    marginRight: 25,
    marginBottom: 11,
    padding: 4,
    paddingBottom: 5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: gui.mainColor,
    borderRadius: 5,
    borderColor: 'transparent'
  },
  moreDetailButton: {
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15
  },
  linearGradient: {
    backgroundColor: "transparent"
  },
  logoContent: {
    position: 'absolute',
    top: imageHeight - 90,
    justifyContent: "center",
    backgroundColor: gui.mainColor,
    borderRadius: 5,
    marginLeft: 9,
    padding: 4,
    paddingLeft: 6,
    paddingRight: 6
  },
  logo: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily
  },
  goiViTriView: {
    position: 'absolute',
    backgroundColor: 'transparent',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    top: 10,
    left: 6,
    width: 40,
    height: 40
  },
  goiViTriIcon: {
    width: 29,
    height: 36
  },
  itemContent: {
    position: 'absolute',
    backgroundColor: 'transparent',
    flexDirection: 'row',
    justifyContent: 'space-between',
    top: imageHeight - 62,
  },
  price: {
    fontSize: 15,
    fontWeight: '500',
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 10,
    color: 'white',
    paddingTop: 1
  },
  textInfo: {
    marginTop: 2,
    fontSize: 12,
    fontWeight: '300',
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 10,
    color: 'white'
  },
  // text2: {
  //   marginTop:2,
  //   fontSize: 10,
  //   fontWeight: '300',
  //   textAlign: 'left',
  //   backgroundColor: 'transparent',
  //   marginLeft: 10,
  //   color: 'white'
  // },
  heartContent: {
    width: 35,
    height: 35,
    justifyContent: 'center',
    alignItems: 'center'
  },
  heartButton: {
    marginTop: 0,
    marginLeft: -10
  },
  heartButton2: {
    marginBottom: 5,
    marginLeft: 9
  },

  titleContainer: {
    marginLeft: 16,
    height: 60,
    alignItems: 'flex-start',
    justifyContent: 'center',
    padding: 0,
    marginBottom: 2
  },
  linearGradient2: {
    marginTop: imageHeight / 2,
    height: imageHeight / 2,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor: "transparent",
    flexGrow: 1
  },
  rowLine: {
    width: width,
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderColor: '#fff',
    borderTopWidth: 0.5
  },
  columnLine: {
    height: 143,
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderColor: '#fff',
    borderLeftWidth: 0.5
  },
  viewRowSourceAds: {
    height: 234,
    width: 234,
    marginLeft: 16,
    borderWidth: 1,
    borderColor: gui.groupBackground,
    backgroundColor: '#fff'
  },
  imgRowItem: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 232,
    height: 100,
    alignSelf: 'auto'
  },
  linearGradientMain: {
    width: 234,
    height: 100,
    marginTop: 0,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor: "transparent"
  },
  viewIconsSource: {
    height: 21,
    width: 234, // how responsive on each device
    position: 'absolute',
    top: 11,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-end'
  },
  iconLogo: {
    height: 19, // source not square shape
    width: 16
  },
  viewLogo: {
    position: 'absolute',
    left: 16
  },
  viewPriceSource: {
      width: 234 - 2,
      height: 28,
      paddingLeft: 9,
      justifyContent: 'flex-end'

  },
  textPrice: {
    fontFamily: gui.fontFamily,
    fontSize: 17,
    fontWeight: '500',
    color: gui.textPostAds
  },
  viewInfoSource: {
    height: 54,
    width: 234,
    paddingLeft: 9,
    paddingRight: 9,
    justifyContent: 'center'
  },
  textInfo2: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    fontWeight: 'normal',
    color: gui.textAgentSolid
  },
  viewDeleteIcon: {
    position: 'absolute',
    right: 13
  },
  iconDelete: {
    height: 14,
    width: 14,
    marginBottom: 2
  },
  iconHeart: {
    height: 17,
    width: 18
  },
  viewHeartIcon: {
    position: 'absolute',
    right: 18
  },
  viewDetailPost: {
    height: 16,
    width: 234 - 22,
    marginLeft: 11,
    marginRight: 11,
    marginTop: 6,
    flexDirection: 'row',
    alignItems: 'center'
  },
  textMainUser: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    color: gui.textPostAds,
    fontWeight: 'normal',
    marginLeft: 8
  },
  viewAreaValue: {
    height: 16,
    width: (234 - 22) / 2,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  viewAddressRow: {
    height: 17,
    width: 234 - 19,
    marginLeft: 9,
    marginRight: 9,
    marginTop: 3,
    flexDirection: 'row',
    alignItems: 'center'
  },
  textAllService: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    fontWeight: 'normal',
    color: gui.colorMainBlur
  },
  myAvatarInbox: {
    height: 24,
    width: 24,
    borderRadius: 12
  },
  viewEachInboxChild: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center'
  },
  viewMainTitle: {
      width: width - 56,
      height: 24,
      justifyContent: 'center'
  },
  viewUserLogo: {
      position: 'absolute',
      left: 10,
      bottom: 10,
      height: 24,
      // width: width - 42,
      backgroundColor: 'transparent',
      flexDirection: 'row'
  },
  viewEachLogo: {
      paddingHorizontal: 9,
      paddingVertical: 2,
      backgroundColor: 'rgba(255,255,255,0.9)',
      borderRadius: 2,
      opacity: 0.85
  },
  textSearch: {
      fontFamily: gui.fontFamily,
      fontSize: 15,
      color: gui.colorMainBlur,
      fontWeight: 'normal'
  }
});
