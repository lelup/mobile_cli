'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ListView} from 'react-native';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as searchActions from '../../reducers/search/searchActions';

import {Map} from 'immutable';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import utils from "../../lib/utils";

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

import placeUtil from '../../lib/PlaceUtil';

import moment from 'moment';

import DanhMuc from "../../assets/DanhMuc";

import log from '../../lib/logUtil';

import RelandIcon from '../../components/RelandIcon';

import MMessage from '../../components/message/MMessage';

import GiftedSpinner from 'react-native-gifted-spinner';

import CanMuaRow from './CanMuaRow';

import CommonUtils from '../../lib/CommonUtils';

const {width, height} = utils.getDimensions();

const imageUriHome = require('../../assets/image/default_cover/no_cover_03.jpg');

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

const actions = [
    searchActions
];

const ds_tinCanMua = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});

class CanMuaResultDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            mounting: true,
            showMessage: false,
            msgSearchType: '',
            pageNo: 1,
            nextBtnPressed: false
        }
    }

    componentWillMount() {
        setTimeout(() => this.fetchData(() => {this._onShowMessage()}), 300);
    }

    componentDidMount() {
        this.reachBottom = false;
    }

    fetchData(successCallback) {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        let newLimit = this._getMaxRows();
        let params = {
            userID: userID,
            limit: newLimit,
            pageNo: this.state.pageNo,
            isIncludeCountInResponse: true
        };
        this.props.actions.findCanMua(params, token, successCallback, (error) =>
            Alert.alert('Thông báo',
                error,
                [{
                    text: 'Đóng',
                    onPress: () => { }
                }]));
    }

    _onShowMessage() {
        this.setState({showMessage: true, mounting: false});
        this._onSearchMsgAnimationStart();
    }

    _onSearchMsgAnimationStart() {
        this.setState({msgSearchType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgSearchType: 'fadeOutUp'})}, 4000);
    }

    _onSearchAnimationEnd() {
        if (this.state.msgSearchType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({msgSearchType: '', showMessage: false})}, 2000);
        }
    }

    _renderTotalResultView(){
        let myProps = this.props;
        let loading = myProps.search.loadingExtFromServer;
        let tinCanMuaList = myProps.search.result.listCanMua;
        let numberOfTinCanMua = tinCanMuaList.length;
        let totalCount = myProps.search.result.totalCountCanMua || 0;
        let limit = this._getMaxRows();
        let errorMsg = myProps.search.result.errorMsg;
        let {showMessage, mounting, pageNo} = this.state;

        let totalPages = totalCount/ limit;
        let beginAdsIndex = (pageNo-1)*limit+1;
        let endAdsIndex = pageNo < totalPages ? pageNo*limit : (pageNo-1)*limit+numberOfTinCanMua;
        if (totalCount < endAdsIndex) {
            totalCount = endAdsIndex;
        }
        let textValue = totalCount > limit ? 'Đang hiển thị từ ' + beginAdsIndex + "-" + endAdsIndex + ' / ' + totalCount + ' kết quả' :
        'Đang hiển thị ' + totalCount + ' kết quả';
        if (numberOfTinCanMua == 0) {
            textValue = "";
        }

        if (errorMsg || numberOfTinCanMua == 0) {
            return null;
        }
        else if(loading || mounting){
            return null;
        }

        if (showMessage && this.state.msgSearchType != '') {
            return (
                <MMessage barStyle="light-content"
                          animation={this.state.msgSearchType}
                          duration={500}
                          onAnimationEnd={this._onSearchAnimationEnd.bind(this)}
                          textValue={textValue}
                          mainStyle={{top: 64}}
                />
            );
        }
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 15}]}>
                        Tin cần mua
                    </ScalableText>
                </View>
                <View style={styles.viewEdit}>
                </View>
                <FullLine/>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderBodyContent()}
                {this._renderTotalResultView()}
                {this._renderHeaderAds()}
            </View>
        );
    }

    _renderLoadingView() {
        return (
            <View style={[styles.viewBody, {alignItems: 'flex-start', justifyContent: 'flex-start'}]}>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
                <View style={styles.viewChildContent}>
                    <View style={styles.viewRowContent}
                    >
                        <View style={[styles.viewLineLoaderRow, {width: 60, height: 60, borderRadius: 5,
                                        marginLeft: 10, marginTop: 14 }]} />
                        <View style={styles.viewChildRow}>
                            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]} />
                        </View>
                    </View>
                </View>
            </View>
        );
    }

    _renderBodyContent() {
        let myProps = this.props;
        let tinCanMuaList = myProps.search.result.listCanMua;
        let loading = myProps.search.loadingExtFromServer;
        if ((this.state.mounting || loading) && tinCanMuaList.length === 0) {
            return this._renderLoadingView();
        }
        let ds = ds_tinCanMua.cloneWithRows(tinCanMuaList);
        return(
            <View style={styles.viewBody}>
                <ListView ref={(listView) => { this._listView = listView; }}
                          style={{ flex: 1}}
                          enableEmptySections={true}
                          dataSource={ds}
                          renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0), (rowID == (ds._dataBlob.s1.length-1)))}
                          onScroll={this.handleScroll.bind(this)}/>
            </View>
        );
    }

    _scrollToTop() {
        let pageNo = this.state.pageNo;

        if (pageNo == 1 || !this.state.nextBtnPressed) {
            setTimeout(() => this._scrollTo(0), 100);
        } else {
            setTimeout(() => this._scrollTo(40), 100);
        }
    }

    _scrollTo(pos) {
        if (this._listView) {
            this._listView.scrollTo({y: pos});
        }
    }

    handleScroll(event: Object) {
        let pos = event.nativeEvent.contentOffset.y;
        this.reachBottom = pos > 100;
    }

    _renderRow (wto, sectionID , rowID, isFirstRow, isLastRow) {

        let myProps = this.props;
        let pageNo = this.state.pageNo;
        let totalCount = myProps.search.result.totalCountCanMua || 0;
        let limit = this._getMaxRows();
        let totalPages = totalCount / limit;

        let showFirstLoading = pageNo > 2 || (!this.reachBottom && !this.state.mounting);
        let showFirstControl = pageNo > 1;
        let loading = myProps.search.loadingExtFromServer;
        let showLastControl = !loading && totalPages && pageNo < totalPages;

        return (
            <CanMuaRow wto={wto}
               {...this.props}
               isFirstRow={isFirstRow}
               showFirstControl={showFirstControl}
               showFirstLoading={showFirstLoading}
               isLastRow={isLastRow}
               showLastControl={showLastControl}
               loadPreviousPage={() => this.loadPreviousPage()}
               loadNextPage={() => this.loadNextPage()}
               getPagingTitle={this.getPagingTitle.bind(this)} />
        );
    }

    loadPreviousPage() {
        let myProps = this.props;
        let loading = myProps.search.loadingExtFromServer;
        if (loading) {
            return;
        }

        let pageNo = this.state.pageNo;

        if (pageNo > 1) {
            pageNo = pageNo-1;
            this.setState({nextBtnPressed: false, pageNo: pageNo});
            this.props.actions.onResetCanMuaList();
            this.fetchData(() => {this._scrollToTop()});
        }
    }

    loadNextPage() {
        let myProps = this.props;
        let loading = myProps.search.loadingExtFromServer;
        if (loading) {
            return;
        }

        let pageNo = this.state.pageNo;
        let totalCount = myProps.search.result.totalCountCanMua || 0;
        let limit = this._getMaxRows();
        let totalPages = totalCount / limit;

        if (totalPages && pageNo < totalPages) {
            pageNo = pageNo+1;
            this.setState({nextBtnPressed: true, pageNo: pageNo});
            this.props.actions.onResetCanMuaList();
            this.fetchData(() => {this._scrollToTop()});
        }
    }

    _getMaxRows() {
        return this.props.global.setting.maxAdsInMapView;
    }

    getPagingTitle() {
        let myProps = this.props;
        let tinCanMuaList = myProps.search.result.listCanMua;
        let numberOfTinCanMua = tinCanMuaList.length;
        let totalCount = myProps.search.result.totalCountCanMua || 0;
        let limit = this._getMaxRows();
        let pageNo = this.state.pageNo;
        let totalPages = totalCount/ limit;
        let beginAdsIndex = (pageNo-1)*limit+1;
        let endAdsIndex = pageNo < totalPages ? pageNo*limit : (pageNo-1)*limit+numberOfTinCanMua;
        if (totalCount < endAdsIndex) {
            totalCount = endAdsIndex;
        }
        return (beginAdsIndex > 1 || totalCount > endAdsIndex) ? 'Đang hiển thị từ ' + beginAdsIndex + "-" + endAdsIndex + ' / ' + totalCount + ' kết quả' :
        'Đang hiển thị ' + totalCount + ' kết quả';
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(CanMuaResultDetail);

const styles = StyleSheet.create({
    pageHeader: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 64,
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        height: height-64,
        backgroundColor: '#fff'
    },

    tinCanMuaRowContent: {
        flex: 1,
        width: width,
        height: 88,
        flexDirection: 'row'
    },
    avatarContent: {
        height: 80,
        width: 80,
        padding: 10
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    tinCanMuaRowInfo: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 10,
        paddingLeft: 0,
        paddingTop: 0
    },
    tinCanMuaLine1View: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: width-90
    },
    tinCanMuaLine1Text: {
        fontSize: 11,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoTitleText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    viewChildContent: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        borderBottomWidth: 10,
        borderColor: 'rgba(234, 234, 234, 0.5)'
    },
    viewRowContent: {
        width: width,
        height: 88,
        flexDirection: 'row'
    },
    viewChildRow: {
        width: width,
        height: 88,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingLeft: 17
    },
    viewLineLoaderRow: {
        height: 14,
        width: width/3,
        backgroundColor: 'rgba(234, 234, 234, 0.5)',
        marginBottom: 8
    }
});