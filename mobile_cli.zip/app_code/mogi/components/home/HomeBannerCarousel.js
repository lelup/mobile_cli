'use strict';

import React, { Component } from 'react';
import { Text, StyleSheet, View, Image, TouchableOpacity, TouchableHighlight, AlertIOS, Alert, ListView } from 'react-native';

import Carousel from 'react-native-looped-carousel';

import utils from '../../lib/utils';

import cfg from "../../cfg";

import gui from '../../lib/gui';
import CommonUtils from '../../lib/CommonUtils';

const noCoverUrl = cfg.noCoverUrl;

const imgHeight = 180;

const { width, height } = utils.getDimensions();

export default class HomeBannerCarousel extends Component {
    render() {
            let imageItems = [];
            let imageUri = require('../../assets/image/reland_house_large.jpg');
            let imageUri2 = require('../../assets/image/default_cover/no_cover_03.jpg');
            return (
                <View style={styles.container}>
                    <View style={{flex: 1}} onLayout={this._onLayoutDidChange}>
                        <Carousel
                            delay={2000}
                            style={styles.container}
                            bullets={true}
                            bulletStyle={styles.bulletDot}
                            chosenBulletStyle={styles.chosenDot}
                            autoplay
                            onAnimateNextPage={(p) => {
                                //console.log(p)
                            }}
                        >
                            <View style={[styles.banner, {backgroundColor: '#BADA55'}]}>
                                <TouchableHighlight onPress={() => console.log('===> get banner')} underlayColor="transparent" >
                                        <Image style={styles.imgItem}
                                                source={imageUri} defaultSource={CommonUtils.getNoCoverImage()} />
                                </TouchableHighlight>
                            </View>
                            <View style={[styles.banner, {backgroundColor: 'red'}]}>
                                <TouchableHighlight onPress={() => console.log('===> get banner')} underlayColor="transparent" >
                                    <Image style={styles.imgItem}
                                           source={imageUri2} defaultSource={CommonUtils.getNoCoverImage()} />
                                </TouchableHighlight>
                            </View>
                            <View style={[styles.banner, {backgroundColor: 'blue'}]}>
                                <TouchableHighlight onPress={() => console.log('===> get banner')} underlayColor="transparent" >
                                    <Image style={styles.imgItem}
                                           source={imageUri} defaultSource={CommonUtils.getNoCoverImage()} />
                                </TouchableHighlight>
                            </View>
                            <View style={[styles.banner, {backgroundColor: 'red'}]}>
                                <TouchableHighlight onPress={() => console.log('===> get banner')} underlayColor="transparent" >
                                    <Image style={styles.imgItem}
                                           source={imageUri2} defaultSource={CommonUtils.getNoCoverImage()} />
                                </TouchableHighlight>
                            </View>
                            <View style={[styles.banner, {backgroundColor: 'blue'}]}>
                                <TouchableHighlight onPress={() => console.log('===> get banner')} underlayColor="transparent" >
                                    <Image style={styles.imgItem}
                                           source={imageUri} defaultSource={CommonUtils.getNoCoverImage()} />
                                </TouchableHighlight>
                            </View>
                        </Carousel>
                    </View>
                </View>
            );
        }
    }

const styles = StyleSheet.create({
    container: {
      width: width,
      height: 180
    },
    banner: {
        flex: 1,
        width: null,
        height: 180,
    },
    imgItem: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: imgHeight,
        alignSelf: 'auto'
    },
    bulletDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: '#c7c7c7',
        opacity: 0.7
    },
    chosenDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: gui.mainColor,
        opacity: 0.9
    }
});