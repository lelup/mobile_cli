'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as historyActions from '../../reducers/history/historyActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import {
    Text, View, Image, ListView, StatusBar, RecyclerViewBackedScrollView,
    TouchableHighlight, StyleSheet, Alert, ActivityIndicator, TouchableOpacity, ImageBackground
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import MoreInfoHeader2 from '../searchList/MoreInfoHeader2';

import utils from '../../lib/utils';
const { width, height} = utils.getDimensions();

import cfg from "../../cfg";

const noCoverUrl = cfg.noCoverUrl;

import CommonUtils from '../../lib/CommonUtils';

import MMessage from '../message/MMessage';

import LinearGradient from 'react-native-linear-gradient';
import util from "../../lib/utils";
import gui from "../../lib/gui";
import MHeartIcon from '../MHeartIcon';
import ScalableText from 'react-native-text';
import DanhMuc from '../../assets/DanhMuc';
import GiftedSpinner from 'react-native-gifted-spinner';

var Analytics = require('react-native-firebase-analytics');

import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

const actions = [
    globalActions,
    searchActions,
    historyActions
];

const ds_nhaCanBanGap = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});

class CanBanGapResultDetail extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        let data = this.props.wtsList;
        this.state = {
            dataCanBanGap: data,
            firstTime: true,
            likeAdsMessage: '',
            msgType: '',
            showMessage: false,
            msgSearchType: ''
        };

    }

    componentDidMount() {
        this._onShowMessage();
    }

    _onShowMessage() {
        this.setState({showMessage: true});
        this._onSearchMsgAnimationStart();
    }

    _onSearchMsgAnimationStart() {
        this.setState({msgSearchType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgSearchType: 'fadeOutUp'})}, 4000);
    }

    _onSearchAnimationEnd() {
        if (this.state.msgSearchType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({msgSearchType: '', showMessage: false})}, 2000);
        }
    }

    _renderTotalResultView(){
        let {dataCanBanGap, showMessage} = this.state;
        let numberOfTin = dataCanBanGap.length;

        let textValue = 'Đang hiển thị ' + numberOfTin + ' kết quả';
        if (numberOfTin == 0) {
            return null;
        }

        if (showMessage && this.state.msgSearchType != '') {
            return (
                <MMessage barStyle="light-content"
                          animation={this.state.msgSearchType}
                          duration={500}
                          onAnimationEnd={this._onSearchAnimationEnd.bind(this)}
                          textValue={textValue}
                          mainStyle={{top: 64}}
                />
            );
        }
    }

    render() {
        let dataWto = this.props.wto;
        let title1 = dataWto.loaiTin == 0 ? 'Nhà cần bán gấp nhận được' :
            'Nhà cần cho thuê nhận được';
        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={myStyles.viewListBody}>
                    <ListView style={{flex: 1}}
                              dataSource={ds_nhaCanBanGap.cloneWithRows(this.state.dataCanBanGap)}
                              renderRow={this._renderRow.bind(this)}/>
                </View>
                {this._renderLikeAdsMessage()}
                {this._renderTotalResultView()}
                <View style={myStyles.search}>
                    <MoreInfoHeader2 title1={title1} //title2={title2}
                    />
                </View>
            </View>
        )
    }

    _renderRow (wts, sectionID , rowID){
        let data = wts.ads;
        let adsID = wts.adsID;
        data.adsID = adsID;
        let isLiked = this.isLiked(adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let diaChi = data.place.diaChi;
        let shortedAddress = diaChi && diaChi.length>55 ? diaChi.substring(0,55) + "..." : diaChi;
        let giaGiam = wts && wts.giaGiam;
        let gia = utils.getPriceDisplay(data.gia, data.loaiTin);
        let giaDaGiam = giaGiam ? utils.getPriceDisplay(data.gia-giaGiam, data.loaiTin) : '';
        let giaText = 'Giá: ';
        let dienTichText = '';
        let dienTichFmt = utils.getDienTichDisplay(data.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNgu) {
            soPhongNgu = "   " + data.soPhongNgu + "p.ngủ";
        }

        let soTang = '';
        if (data.soTang) {
            soTang = "   " + data.soTang + "tầng";
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTichText, soPhongNgu, soTang);
        detail = detail.trim();
        return(
            <TouchableOpacity onPress={this._onChiTietNhaCanBanGapPress.bind(this, wts)} >
                <View style={{flex: 1}}>
                    <View style={myStyles.eachViewKetQua}>
                        <ImageBackground style={{width: width, height: 180}}
                               source={{uri: data.image.cover}}
                               resizeMode={'cover'}
                               defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                            style={myStyles.linearGradient2}>
                            </LinearGradient>

                            <TouchableOpacity style={myStyles.heartContent}
                                              onPress={() => this.onLike(data.adsID)}
                            >
                                {this.props.history.uploadingLikedAds.uploading && this.props.history.uploadingLikedAds.adsID == data.adsID ?
                                    (<View style={myStyles.heartButton2}>
                                        <GiftedSpinner size="small" color="white"/>
                                    </View>)
                                    :
                                    (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                                 color={color} bgColor={bgColor}
                                                 bgStyle={bgStyle}
                                                 mainProps={myStyles.heartButton}/>)
                                }
                            </TouchableOpacity>
                        </ImageBackground>
                    </View>
                    <View style={myStyles.viewTextContent}>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={myStyles.priceText} numberOfLines={1}>{giaText}</Text>
                            {giaGiam ?
                                <View style={{flexDirection: 'row'}}>
                                    <Text style={[myStyles.priceText, {marginLeft: 5}]} numberOfLines={1}>{giaDaGiam}</Text>
                                    <Text style={[myStyles.priceText, {marginLeft: 10, textDecorationLine: 'line-through',
                                        color: '#C7C8CA'}]} numberOfLines={1}>{gia}</Text>
                                </View> :
                                <Text style={[myStyles.priceText, {marginLeft: 5}]} numberOfLines={1}>{gia}</Text>
                            }
                        </View>
                        <Text style={myStyles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                        <Text style={myStyles.infoText}>{detail}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _onChiTietNhaCanBanGapPress(wts) {
        if (this.props.global.loggedIn) {
            this._showCanBanGapDetail(wts);
        } else {
            Actions.NewLogin({doFinalAction: () => this._showCanBanGapDetail(wts)});
        }
    }

    _showCanBanGapDetail(wts) {
        Actions.WToDetailFromHome({wts: wts});
        let wtsID = wts.wtsID || wts.id;
        Analytics.logEvent('SEEMORE_WTS_DETAIL', {wtsID: wtsID});
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            }
        }
    }

    _updateLikeAdsProcessing(likeAdsMessage) {
        this.setState({firstTime: false, likeAdsMessage: likeAdsMessage});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 2000);
    }

    _renderLikeAdsMessage() {
        let uploading = this.props.history.uploadingLikedAds.uploading;
        if (this.state.firstTime || uploading || this.state.msgType == '') {
            return null;
        }
        let textValue = this.state.likeAdsMessage;
        return (
            <MMessage mainStyle={{top: 64}}
                      barStyle="light-content"
                      animation={this.state.msgType}
                      duration={500}
                      onAnimationEnd={this._onAnimationEnd.bind(this)}
                      textValue={textValue}/>
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({msgType: ''})}, 2000);
        }
    }
}

const myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    search: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 64,
        flexDirection:'row',
        backgroundColor:'#1ea7de',
        borderBottomWidth:1,
        borderColor:'#1ea7de'
    },
    viewListBody: {
        marginTop: 0,
        position: 'absolute',
        top:64,
        width: width,
        height: height-64
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: width,
        height: 180,
    },
    listMoRong:{
        justifyContent:'center',
        width: width,
        height: 180,
    },
    linearGradient2: {
        marginTop: 71,
        height: 71,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent",
        flexGrow: 1
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 8,
        right: 8,
        width: 38,
        height: 38,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -8
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 8
    },
    viewTextContent: {
        paddingTop: 8,
        marginTop: -71,
        marginLeft: 12,
        height: 71,
        width: width
    },
    priceText: {
        fontSize: 17,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#fff',
        paddingTop:1,
        fontFamily: gui.fontFamily
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#fff',
        fontFamily: gui.fontFamily
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(CanBanGapResultDetail);
