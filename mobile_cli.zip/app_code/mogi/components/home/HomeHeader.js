// Import some code we need
import React, {Component} from 'react';

import {View, Image, Text, StyleSheet, TouchableOpacity, InteractionManager} from 'react-native';

import {Actions} from 'react-native-router-flux';

import TruliaIcon from '../TruliaIcon';

import RelandIcon from '../RelandIcon';

import gui from '../../lib/gui';

import utils from '../../lib/utils';

var {width} = utils.getDimensions();

// Create our component
var HomeHeader = React.createClass({
    render: function() {
        let logoIcon = require('../../assets/image/logo.png');
        let locationIcon = require('../../assets/image/location.png');
        return (
            <View style={mStyles.pageHeader}>
                <View style={mStyles.searchButton}>
                    {/*<TruliaIcon onPress={() => this.handleSearchButton()}
                                name="search" color="white" size={20}
                                mainProps={{paddingLeft: 18, paddingRight: 21}}
                    >
                    </TruliaIcon>
                    */}
                </View>

                <View style={mStyles.home}>
                    <Image
                        style={mStyles.logoIcon}
                        resizeMode={Image.resizeMode.cover}
                        source={logoIcon}
                    />
                </View>
                <View style={mStyles.home}>
                    {/*<RelandIcon
                        name="location-alt" color="white" size={26} onPress={() => this._onMapView()}
                        mainProps={{marginTop: 15, paddingLeft: 18, paddingRight: 21}}
                    >
                    </RelandIcon>*/}
                    {/*<TouchableOpacity onPress={() => this._onMapView()} underlayColor="transparent">
                     <Image
                     style={mStyles.locationIcon}
                     resizeMode={Image.resizeMode.cover}
                     source={locationIcon}
                     />
                     </TouchableOpacity>*/}
                </View>
            </View>
        );
    },

    _onMapView: function() {
        Actions.SearchResultMap({type: "reset"});
    },

    handleSearchButton: function(){
        if (!this.props.listAds || this.props.listAds.length === 0) {
            this.props.search();
        }
        InteractionManager.runAfterInteractions(() => {
            if (this.props.searchViewType == 'map') {
                Actions.SearchResultMap({type: "reset"});
            } else {
                Actions.SearchResultList({type: "reset"});
            }
        });
    }
});

// Make this code available elsewhere
module.exports = HomeHeader;

var mStyles = StyleSheet.create({
    searchButton: {
        paddingTop: 20,
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        width: width/3
    },
    locationIcon: {
        height: 27,
        width: 16,
        marginTop: 0,
        marginLeft: 18,
        paddingRight: 16
    },
    logoIcon: {
        height: 21,
        width: 87,
        marginTop: 0,
        marginLeft: 19,
        marginRight: 16
    },
    home: {
        paddingTop: 16,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        width: width/3
    },
    pageHeader: {
        top: 0,
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64
    }
});
