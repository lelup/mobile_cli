'use strict';

import React from 'react';
import { Image, StyleSheet, Text, View , TouchableHighlight, TouchableOpacity, ListView} from 'react-native';
import {Actions} from 'react-native-router-flux';
import DanhMuc from '../../assets/DanhMuc';
import gui from "../../lib/gui";

import CommonUtils from '../../lib/CommonUtils';

import MHeartIcon from '../MHeartIcon';
import LinearGradient from 'react-native-linear-gradient';

import GiftedSpinner from 'react-native-gifted-spinner';

import moment from 'moment';

import placeUtil from '../../lib/PlaceUtil';

import ScalableText from 'react-native-text'

var Analytics = require('react-native-firebase-analytics');

import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();


class CanMuaRow extends React.Component {
    render() {
        let wto = this.props.wto;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = wto.avatar ? {uri: wto.avatar} : defaultAvatar;
        let fullNameText = wto.fullName || 'Ẩn Danh';
        let ngayDang = moment(wto.timeModified).format("DD/MM/YYYY  HH:mm");
        let gia = this._getGiaText(wto);
        let content = wto.content;
        let loaiTin = content.loaiTin;
        let loaiNhaDat = content.loaiNhaDat;
        let loaiTinFmt = loaiTin == 0 ? 'mua' : 'thue';
        let title = wto.title || DanhMuc.getLoaiNhaDatWToForDisplay(loaiTinFmt, loaiNhaDat);
        let dienTich = this._getDienTichText(wto);
        let soPhongNgu = '';
        if (content.soPhongNgu) {
            soPhongNgu = "   " + content.soPhongNgu + "pn";
        }
        let soTang = '';
        if (content.soTang) {
            soTang = "   " + content.soTang + "t";
        }
        let diaChiFullname = this._getDiaChiFullname(content.place);
        let diaChi = diaChiFullname;
        let maxDiaChiLength = 30;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < diaChiFullname.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);
        if (moreInfo) {
            moreInfo = ' · ' + moreInfo;
        }

        let wtoID = wto.wtoID || wto.id;

        let firstControl = null;
        let lastControl = null;
        let {showFirstControl, isFirstRow, showLastControl, isLastRow, showFirstLoading} = this.props;

        if (isFirstRow) {
            if (this.props.loading) {
                if (showFirstLoading) {
                    firstControl = <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                        <GiftedSpinner size="small"/>
                    </View>;
                }
            } else {
                if (showFirstControl) {
                    firstControl =
                        <View>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <TouchableHighlight onPress={this.props.loadPreviousPage} underlayColor="transparent">
                                    <View style={{flexDirection: 'column'}}>
                                        <Text style={styles.rowControl}>Nhấn vào đây để quay lại trang trước</Text>
                                        <Text style={styles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </View>;
                } else if (this.props.getDieuKienLoc) {
                    let searchText = 'Điều kiện lọc: ' + this.props.getDieuKienLoc();
                    firstControl =
                        <View>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <View>
                                    <Text style={styles.pagingTitle}>{searchText}</Text>
                                </View>
                            </View>
                        </View>
                    ;
                }
            }
        }
        if (showLastControl && isLastRow) {
            lastControl =
                <View>
                    <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                        <TouchableHighlight onPress={this.props.loadNextPage} underlayColor="transparent">
                            <View style={{flexDirection: 'column'}}>
                                <Text style={styles.rowControl}>Nhấn vào đây để đi đến trang sau</Text>
                                <Text style={styles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
            ;
        }

        let sentWToHash = this.props.search.sentWToHash;
        let hasSent = sentWToHash[wtoID];

        return(
            <View key={wtoID} style={{flexDirection: 'column', overflow: 'hidden'}}>
                {firstControl}
                <TouchableOpacity onPress={this._onChiTietTinCanMua.bind(this, wtoID)}>
                    <View>
                        <View style={styles.tinCanMuaRowContent}>
                            <View style={styles.avatarContent}>
                                <Image style={styles.avatarImage}
                                       resizeMode={Image.resizeMode.cover}
                                       source={avatarUri}
                                       defaultSource={defaultAvatar}
                                />
                            </View>
                            <View style={styles.tinCanMuaRowInfo}>
                                <View style={styles.tinCanMuaLine1View}>
                                    <ScalableText style={styles.tinCanMuaLine1Text}>{fullNameText}</ScalableText>
                                    <ScalableText style={styles.tinCanMuaLine1Text}>{ngayDang}</ScalableText>
                                </View>
                                <Text style={[styles.tinCanMuaInfoTitleText, {fontSize: 17}]}>{title}</Text>
                                <Text style={[styles.tinCanMuaInfoText, {fontSize: 17}]}>{gia}</Text>
                                <ScalableText style={styles.tinCanMuaLine1Text}>{diaChi}{moreInfo}</ScalableText>
                            </View>
                            {hasSent ?
                                <View style={styles.sentAdsContent}>
                                    <Text style={styles.sentAdsText}>Đã gửi</Text>
                                </View> : null
                            }
                        </View>
                        <View style={styles.separatedView} />
                    </View>
                </TouchableOpacity>
                {lastControl}
            </View>
        );
    }

    _getGiaText(wto) {
        let {content} = wto;
        let {giaTu, giaDen, loaiTin} = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return '<= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return '>= ' + giaTuFmt;
        }
        return giaTuFmt + ' - ' + giaDenFmt;
    }

    _getDienTichText(wto) {
        let {content} = wto;
        let {dienTichTu, dienTichDen} = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    _getDiaChiFullname(place) {
        if (!place) {
            return '';
        }
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }


    _onChiTietTinCanMua(wtoID) {
        Actions.NeedToBuyDetail({wtoID: wtoID});
        Analytics.logEvent('SEEMORE_WTO_DETAIL', {wtoID: wtoID});
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = dienTich + soTang;
        }
        else {
            moreInfo = dienTich;
        }
        return moreInfo;
    }
}

const styles = StyleSheet.create({
    tinCanMuaRowContent: {
        flex: 1,
        width: width,
        height: 88,
        flexDirection: 'row'
    },
    avatarContent: {
        height: 80,
        width: 80,
        padding: 10
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    tinCanMuaRowInfo: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 10,
        paddingLeft: 0,
        paddingTop: 0
    },
    tinCanMuaLine1View: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: width-90
    },
    tinCanMuaLine1Text: {
        fontSize: 11,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoTitleText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    rowControl: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: gui.mainColor
    },
    pagingTitle: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'gray'
    },
    sentAdsContent: {
        backgroundColor: '#48B041',
        position: "absolute",
        top: 40,
        right: 10,
        padding: 2,
        paddingLeft: 5,
        paddingRight: 5,
        borderRadius: 5
    },
    sentAdsText: {
        fontSize: 13,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    }
});

module.exports = CanMuaRow;
