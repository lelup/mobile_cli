'use strict';

import React, { Component } from 'react';
import { Text, StyleSheet, View, Image, TouchableOpacity, TouchableHighlight, AlertIOS, Alert, ListView } from 'react-native';

import {Actions} from 'react-native-router-flux';

import placeUtil from '../../lib/PlaceUtil';

import moment from 'moment';

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import DanhMuc from "../../assets/DanhMuc"

import utils from '../../lib/utils';

import gui from '../../lib/gui';

import RelandIcon from '../../components/RelandIcon';

import log from '../../lib/logUtil';

var Analytics = require('react-native-firebase-analytics');

var { width, height } = utils.getDimensions();

export default class TinCanMuaContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showDangTinCanMua: true
        }
    }
    render() {
        // if (this.props.search.loadingHomeData) {
        //     return (
        //         <View style={styles.tinCanMuaView} />
        //     );
        // }
        let tinCanMuaList = this.props.search.tinCanMuaList;
        if (tinCanMuaList.length == 0) {
            // return this.state.showDangTinCanMua ? this._renderDangTinCanMuaView() :
            //     <View style={styles.tinCanMuaView} />;
            return <View style={styles.tinCanMuaView} />;
        }
        let xemThemText = 'Xem thêm >';
        return (
            <View style={styles.tinCanMuaView}>
                <View style={styles.tinCanMuaTitle}>
                    <ScalableText style={styles.tinCanMuaTitleText}>
                        NGƯỜI CẦN MUA PHÙ HỢP
                    </ScalableText>
                    <TouchableHighlight onPress={this._onXemThem.bind(this)} underlayColor="transparent">
                        <View style={{paddingRight: 10}}>
                            <ScalableText style={styles.tinCanMuaXemThemText}>
                                {xemThemText}
                            </ScalableText>
                        </View>
                    </TouchableHighlight>
                </View>
                {this._renderTinCanMuaListView()}
            </View>
        );
    }

    _closeDangTinCanMuaModal() {
        this.setState({showDangTinCanMua: false});
    }

    _renderDangTinCanMuaView() {
        let imageSource = require('../../assets/image/tin_can_mua.png');
        let dangTinCanMuaLine1 = 'Mua nhà từ những';
        let dangTinCanMuaLine2 = 'người đang cần bán gấp';
        let dangTinCanMuaLine3 = 'sẽ nhanh hơn và có giá tốt hơn.';
        return (
            <View style={[styles.tinCanMuaView, {marginTop: 0}]}>
                <View style={[styles.tinCanMuaTitle, {marginTop: 10}]}>
                    <View style={styles.tinCanMuaIconView}>
                        <Image style={styles.tinCanMuaIcon} resizeMode={Image.resizeMode.cover}
                               source={imageSource} defaultSource={imageSource} />
                    </View>
                    <View style={styles.dangTinCanMuaView}>
                        <ScalableText style={styles.dangTinCanMuaText}>{dangTinCanMuaLine1}</ScalableText>
                        <ScalableText style={styles.dangTinCanMuaText}>{dangTinCanMuaLine2}</ScalableText>
                        <ScalableText style={styles.dangTinCanMuaText}>{dangTinCanMuaLine3}</ScalableText>
                        <TouchableHighlight onPress={this._onDangTinTimMua.bind(this)} underlayColor="transparent">
                            <View style={styles.dangTinCanMuaButtonView}>
                                <ScalableText style={styles.dangTinCanMuaButtonText}>Đăng tin cần mua</ScalableText>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
                <View style={styles.separatedView} />
                <View style={styles.closeBtnView}>
                    <RelandIcon name={"close"} color={'#AFB0B3'} mainProps={styles.closeBtn}
                                size={10} onPress={this._closeDangTinCanMuaModal.bind(this)}>
                    </RelandIcon>
                </View>
            </View>
        );
    }

    _onDangTinTimMua() {
        this.props.onDangTinTimMuaPress && this.props.onDangTinTimMuaPress();
    }

    _renderTinCanMuaListView() {
        let tinCanMuaList = this.props.search.tinCanMuaList;

        let tinCanMuaItems = [];
        let length = tinCanMuaList.length > gui.LIMIT_TIN_CAN_MUA_LIST ? gui.LIMIT_TIN_CAN_MUA_LIST : tinCanMuaList.length;
        for (let i=0; i<length; i++) {
            tinCanMuaItems.push(this._renderTinCanMuaRow(tinCanMuaList, i));
        }
        return (
            <View style={styles.tinCanMuaContent}>
                {tinCanMuaItems}
            </View>
        )
    }

    _getGiaText(wto) {
        let {content} = wto;
        let {giaTu, giaDen, loaiTin} = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return '<= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return '>= ' + giaTuFmt;
        }
        return giaTuFmt + ' - ' + giaDenFmt;
    }

    _getDienTichText(wto) {
        let {content} = wto;
        let {dienTichTu, dienTichDen} = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    _getDiaChiFullname(place) {
        if (!place) {
            return '';
        }
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    _renderTinCanMuaRow(tinCanMuaList, wtoIndex) {
        let wto = tinCanMuaList[wtoIndex];
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = wto.avatar ? {uri: wto.avatar} : defaultAvatar;
        let fullNameText = wto.fullName || 'Ẩn Danh';
        let ngayDang = moment(wto.timeModified).format("DD/MM/YYYY  HH:mm");
        let gia = this._getGiaText(wto);
        let content = wto.content;
        let loaiTin = content.loaiTin;
        let loaiNhaDat = content.loaiNhaDat;
        let loaiTinFmt = loaiTin == 0 ? 'mua' : 'thue';
        let title = wto.title || DanhMuc.getLoaiNhaDatWToForDisplay(loaiTinFmt, loaiNhaDat);
        let dienTich = this._getDienTichText(wto);
        let soPhongNgu = '';
        if (content.soPhongNgu) {
            soPhongNgu = "   " + content.soPhongNgu + "pn";
        }
        let soTang = '';
        if (content.soTang) {
            soTang = "   " + content.soTang + "t";
        }
        let diaChiFullname = this._getDiaChiFullname(content.place);
        let diaChi = diaChiFullname;
        let maxDiaChiLength = 30;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < diaChiFullname.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);
        if (moreInfo) {
            moreInfo = ' · ' + moreInfo;
        }

        let wtoID = wto.wtoID || wto.id;

        let sentWToHash = this.props.search.sentWToHash;
        let hasSent = sentWToHash[wtoID];

        return (
            <TouchableOpacity key={wtoID} onPress={this._onChiTietTinCanMua.bind(this, wtoID)}>
                <View>
                    <View style={styles.tinCanMuaRowContent}>
                        <View style={styles.avatarContent}>
                            <Image style={styles.avatarImage}
                                   resizeMode={Image.resizeMode.cover}
                                   source={avatarUri}
                                   defaultSource={defaultAvatar}
                            />
                        </View>
                        <View style={styles.tinCanMuaRowInfo}>
                            <View style={styles.tinCanMuaLine1View}>
                                <ScalableText style={styles.tinCanMuaLine1Text}>{fullNameText}</ScalableText>
                                <ScalableText style={styles.tinCanMuaLine1Text}>{ngayDang}</ScalableText>
                            </View>
                            <Text style={[styles.tinCanMuaInfoTitleText, {fontSize: 17}]}>{title}</Text>
                            <Text style={[styles.tinCanMuaInfoText, {fontSize: 17}]}>{gia}</Text>
                            <ScalableText style={styles.tinCanMuaLine1Text}>{diaChi}{moreInfo}</ScalableText>
                        </View>
                        {hasSent ?
                            <View style={styles.sentAdsContent}>
                                <Text style={styles.sentAdsText}>Đã gửi</Text>
                            </View> : null
                        }
                    </View>
                    {wtoIndex == tinCanMuaList.length-1 ? <View style={styles.separatedView} />
                                                       : <FullLine style={{marginLeft: 10}} />}
                </View>
            </TouchableOpacity>
        );
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = dienTich + soTang;
        }
        else {
            moreInfo = dienTich;
        }
        return moreInfo;
    }

    _onXemThem() {
        this.props.actions.onResetCanMuaList();
        Actions.CanMuaResultDetail();
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('HOME_WTO_SEEMORE', {userID: userID});
    }

    _onChiTietTinCanMua(wtoID) {
        Actions.NeedToBuyDetail({wtoID: wtoID});
        Analytics.logEvent('HOME_WTO_DETAIL', {wtoID: wtoID});
    }

}

var styles = StyleSheet.create({
    tinCanMuaView: {
        flex: 1,
        marginTop: 10
    },
    tinCanMuaTitle: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    tinCanMuaTitleText: {
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: 'bold',
        backgroundColor: 'transparent',
        marginLeft: 10
    },
    tinCanMuaXemThemText: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainColor,
        backgroundColor: 'transparent'
    },
    tinCanMuaContent: {
        flex: 1
    },
    tinCanMuaRowContent: {
        flex: 1,
        flexDirection: 'row'
    },
    avatarContent: {
        height: 80,
        width: 80,
        padding: 10
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    tinCanMuaRowInfo: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 10,
        paddingLeft: 0,
        paddingTop: 0
    },
    tinCanMuaLine1View: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: width-90
    },
    tinCanMuaLine1Text: {
        fontSize: 11,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoTitleText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    tinCanMuaIconView: {
        width: 120,
        height: 120,
        padding: 10
    },
    tinCanMuaIcon: {
        width: 91,
        height: 100
    },
    dangTinCanMuaView: {
        flex: 1,
        flexDirection: 'column'
    },
    dangTinCanMuaText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        color: '#2C2C2E',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    dangTinCanMuaButtonView: {
        flex: 1,
        borderRadius: 3,
        backgroundColor: '#1E94D6',
        padding: 5,
        marginTop: 20,
        marginBottom: 12,
        alignItems: 'center',
        justifyContent: 'center',
        width: 150
    },
    dangTinCanMuaButtonText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'center',
        color: '#fff',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    closeBtnView: {
        position: 'absolute',
        top: 5,
        // left: width - 40,
        right: 3
    },
    closeBtn: {
        flexDirection: 'row',
        backgroundColor: 'transparent',
        paddingLeft: 20,
        paddingBottom: 20,
        width: 40,
        height: 40
    },
    sentAdsContent: {
        backgroundColor: '#48B041',
        position: "absolute",
        top: 40,
        right: 10,
        padding: 2,
        paddingLeft: 5,
        paddingRight: 5,
        borderRadius: 5
    },
    sentAdsText: {
        fontSize: 13,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    }
});