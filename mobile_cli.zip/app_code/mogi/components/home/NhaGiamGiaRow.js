'use strict';

import React from 'react';
import { Image, StyleSheet, Text, View , TouchableHighlight, TouchableOpacity, ListView, ImageBackground} from 'react-native';
import {Actions} from 'react-native-router-flux';
import DanhMuc from '../../assets/DanhMuc';
import gui from "../../lib/gui";

import CommonUtils from '../../lib/CommonUtils';

import MHeartIcon from '../MHeartIcon';
import LinearGradient from 'react-native-linear-gradient';

import GiftedSpinner from 'react-native-gifted-spinner';

var Analytics = require('react-native-firebase-analytics');

import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();


class NhaGiamGiaRow extends React.Component {
    render() {
        let data = this.props.ads;
        let adsID = data.adsID || data.id;
        let isLiked = this.props.isLiked(adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let shortedAddress = data.diaChi && data.diaChi.length>55 ? data.diaChi.substring(0,55) + "..." : data.diaChi;
        let giaCu = data.giaCuFmt || utils.getPriceDisplay(data.giaCu, data.loaiTin);
        let isGiamGia = data.giaCu && data.gia && data.gia < data.giaCu;
        let giaDaGiam = data.giaFmt || utils.getPriceDisplay(data.gia, data.loaiTin);
        let dienTich = '';
        if (data.dienTichFmt && data.dienTichFmt != 'Không rõ') {
            dienTich = data.dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNguFmt) {
            soPhongNgu = "   " + data.soPhongNguFmt;
        }

        let soTang = '';
        if (data.soTangFmt) {
            soTang = "   " + data.soTangFmt;
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTich, soPhongNgu, soTang);

        let firstControl = null;
        let lastControl = null;
        let {showFirstControl, isFirstRow, showLastControl, isLastRow, showFirstLoading} = this.props;

        if (isFirstRow) {
            if (this.props.loading) {
                if (showFirstLoading) {
                    firstControl = <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                        <GiftedSpinner size="small"/>
                    </View>;
                }
            } else {
                if (showFirstControl) {
                    firstControl =
                        <View>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <TouchableHighlight onPress={this.props.loadPreviousPage} underlayColor="transparent">
                                    <View style={{flexDirection: 'column'}}>
                                        <Text style={myStyles.rowControl}>Nhấn vào đây để quay lại trang trước</Text>
                                        <Text style={myStyles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </View>;
                } else if (this.props.getDieuKienLoc) {
                    let searchText = 'Điều kiện lọc: ' + this.props.getDieuKienLoc();
                    firstControl =
                        <View>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <View>
                                    <Text style={myStyles.pagingTitle}>{searchText}</Text>
                                </View>
                            </View>
                        </View>
                    ;
                }
            }
        }
        if (showLastControl && isLastRow) {
            lastControl =
                <View>
                    <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                        <TouchableHighlight onPress={this.props.loadNextPage} underlayColor="transparent">
                            <View style={{flexDirection: 'column'}}>
                                <Text style={myStyles.rowControl}>Nhấn vào đây để đi đến trang sau</Text>
                                <Text style={myStyles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
            ;
        }
        return(
            <View key={adsID} style={{flexDirection: 'column', overflow: 'hidden'}}>
                {firstControl}
                <TouchableOpacity style={myStyles.eachViewKetQua}  onPress={() => this._showNhaGiamGiaDetail(data)} >
                    <ImageBackground style={{width: width, height: 180}}
                           source={{uri: data.image.cover}}
                           resizeMode={'cover'}
                           defaultSource={CommonUtils.getNoCoverImage()}
                    >
                        <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                        style={myStyles.linearGradient2}>
                        </LinearGradient>
                        <TouchableOpacity style={myStyles.heartContent}
                                          onPress={() => this.props.onLike(adsID)}>
                            {this.props.history.uploadingLikedAds.uploading && this.props.history.uploadingLikedAds.adsID == adsID ?
                                (<View style={myStyles.heartButton2}>
                                    <GiftedSpinner size="small" color="white"/>
                                </View>)
                                :
                                (<MHeartIcon onPress={() => this.props.onLike(adsID)}
                                             color={color} bgColor={bgColor}
                                             bgStyle={bgStyle}
                                             mainProps={myStyles.heartButton}/>)
                            }
                        </TouchableOpacity>
                        <View style={myStyles.viewTextContent}>
                            <View style={{flexDirection: 'row'}}>
                                {isGiamGia ?
                                    <View style={{flexDirection: 'row'}}>
                                        <Text style={myStyles.priceText} numberOfLines={1}>{giaDaGiam}</Text>
                                        <Text style={[myStyles.priceText, {marginLeft: 10, textDecorationLine: 'line-through',
                                                color: '#C7C8CA'}]} numberOfLines={1}>{giaCu}</Text>
                                    </View> :
                                    <Text style={myStyles.priceText} numberOfLines={1}>{giaDaGiam}</Text>
                                }
                            </View>
                            <Text style={myStyles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                            <Text style={myStyles.infoText}>{detail}</Text>
                        </View>
                    </ImageBackground>
                </TouchableOpacity>
                {lastControl}
            </View>
        );
    }

    _showNhaGiamGiaDetail(data) {
        let adsID = data.adsID || data.id;
        Actions.SearchResultDetail({adsID: adsID, source: 'server', imageDetail: data.image.cover});
        Analytics.logEvent('SEEMORE_GIAMGIA_DETAIL', {adsID: adsID});
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }
}

const myStyles = StyleSheet.create({
    eachViewKetQua:{
        justifyContent:'center',
        width: width,
        height: 180,
    },
    linearGradient2: {
        marginTop: 71,
        height: 71,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent",
        flexGrow: 1
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 8,
        right: 8,
        width: 38,
        height: 38,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -8
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 8
    },
    viewTextContent: {
        paddingTop: 8,
        marginTop: -71,
        marginLeft: 12,
        height: 71,
        width: width
    },
    priceText: {
        fontSize: 17,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#fff',
        paddingTop:1,
        fontFamily: gui.fontFamily
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    rowControl: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: gui.mainColor
    },
    pagingTitle: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'gray'
    }
});

module.exports = NhaGiamGiaRow;
