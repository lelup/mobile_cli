import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    ListView,
    ScrollView,
    TouchableOpacity,
    TextInput,
    Keyboard,
    ImageBackground,
    TouchableHighlight,
    RefreshControl,
    FlatList,
    StatusBar,
    Alert,
    ActivityIndicator
} from 'react-native';

var Analytics = require('react-native-firebase-analytics');
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Actions } from 'react-native-router-flux';
import GiftedSpinner from "../GiftedSpinner";
import LinearGradient from 'react-native-linear-gradient';
import RelandIcon from '../RelandIcon';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import DanhMuc from '../../assets/DanhMuc';
import ImagePreview from '../group/ImagePreview';
import UserModal from '../UserModal';
import apiUtils from '../../lib/ApiUtils';
import userApi from '../../lib/userApi';

import MMessage from '../message/MMessage';
import FunctionModal from '../FunctionModal';
import OfflineBar from '../line/OfflineBar';
import NewsList from '../group/NewsList'

import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import LineFacebook from '../line/LineFacebook';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
let imageGroup = 188;
import gui from '../../lib/gui';
import HomeAgentCollection from '../home/AgentHomeCollection';
import moment from 'moment';
import Modal from 'react-native-modalbox';
var Contacts = require('react-native-contacts');

import Toast, { DURATION } from '../toast/Toast';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as eventActions from '../../reducers/event/eventActions';
import * as meActions from '../../reducers/me/meActions';


import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import ViewMoreText from '../ViewMoreText';

import VersionCheck from 'react-native-version-check';
import RangeUtils from "../../lib/RangeUtils";

// START: iOS Only
VersionCheck.setAppID('1303128474');                    // Your App ID for App Store URL
VersionCheck.setAppName('landber-agent-moi-gioi-bds');
const ds_listInboxChat = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

const ASPECT_RATIO = width / (height - 188);
const LATITUDE = 15.91246021276861;
const LONGITUDE = 105.7527299557314;
const LATITUDE_DELTA = 15.43258937437489;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

const actions = [
    globalActions,
    registerActions,
    searchActions,
    postAdsActions,
    needToBuyActions,
    groupActions,
    inboxActions,
    chatActions,
    adsMgmtActions,
    groupSearchActions,
    groupContactActions,
    eventActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let dataNews = [
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Chính chủ Kim Văn Kim Lũ cho thuê gấp trong tháng 9',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà riêng tại Phố Yên Hoa, Phường Yên Phụ, Quận Tây Hồ, Hà Nội, giá 5.6 tỷ',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/23991349/4e5e0cbe_original.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà TimeCity giá 4.5 tỷ, liên hệ ngay để có giá tốt hơn, phone: 0900882222',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà biệt thự liền kề Quận Tây Hồ, Hà Nội, giá 9.2 tỷ',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà biệt thự liền kề Quận Tây Hồ, Hà Nội, giá 9.2 tỷ',
        'timeStamp': 1496912814
    },
]

class NewHomeAgent extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        let dataService = [
            { 'imgService': 'https://instagram.fhan2-1.fna.fbcdn.net/t51.2885-15/s640x640/sh0.08/e35/21826971_269717303540426_1539794729653239808_n.jpg' },
            { 'imgService': 'https://instagram.fhan2-1.fna.fbcdn.net/t51.2885-15/sh0.08/e35/p640x640/22344621_367456847044751_7804261163755110400_n.jpg' },
            { 'imgService': 'https://instagram.fhan2-1.fna.fbcdn.net/t51.2885-15/s640x640/sh0.08/e35/21224769_1443219562434183_2162945336992071680_n.jpg' },
            { 'imgService': 'https://a0.muscache.com/im/pictures/23991349/4e5e0cbe_original.jpg?aki_policy=x_large' }
        ];
        let dataSourceAds = [
            {
                'itemsSourceUrl': 'https://instagram.fhan2-1.fna.fbcdn.net/t51.2885-15/sh0.08/e35/p640x640/22344167_481430075574641_5533914435745218560_n.jpg',
                'priceSource': '12 triệu',
                'textInfo': 'Chính chủ Kim Văn Kim Lũ cho thuê gấp trong tháng 9',
                'areaValue': '30m2',
                'bedroomValue': '1',
                'bathroomValue': '2',
                'addressRow': 'Phường Thanh Xuân Trung, Quận Tha…'
            },
            {
                'itemsSourceUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
                'priceSource': '3 tỷ',
                'textInfo': 'Bán nhà riêng tại Phố Yên Hoa, Phường Yên Phụ, Quận Tây Hồ, Hà Nội, giá 5.6 tỷ',
                'areaValue': '80m2',
                'bedroomValue': '3',
                'bathroomValue': '2',
                'addressRow': 'Phố Yên Hoa, Phường Yên Phụ, Quận Tây Hồ, Hà Nội'
            }
        ];
        this.state = {
            loading: false,
            value: '',
            tabType: 'home',
            dataService: dataService,
            dataSourceAds: dataSourceAds,
            // dataInboxNoti: dataInboxNoti,
            agentCollections: props.search.agentCollections,
            eventList: props.event.eventList,
            adsContact: true,
            adsPost: true,
            adsCongViec: true,
            adsGroup: true,
            isOpenNewModal: false,
            newFeedList: props.group.newFeedList,
            pickedRow: {},
            isOpenFunctionModal: false,
            listHomeInbox: props.inbox.listHomeInbox,
            pageNo: 1,
            feedPageNo: props.group.feedPageNo,
            loaded: false,
            isModalContent: false,
            dataContent: null,
            modalGroupName: null,
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null,
            isNeedUpdate: false,
            newsList: props.group.newsList,
            newsPageNo: props.group.newsPageNo,
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.search.agentCollections !== this.props.search.agentCollections) {
            this.setState({ agentCollections: nextProps.search.agentCollections })
        }

        if (nextProps.event.eventList !== this.props.event.eventList) {
            this.setState({ eventList: nextProps.event.eventList })
        }

        if (nextProps.group.newFeedList !== this.props.group.newFeedList) {
            this.setState({ newFeedList: nextProps.group.newFeedList })
        }

        if (nextProps.inbox.listHomeInbox !== this.props.inbox.listHomeInbox) {
            this.setState({ listHomeInbox: nextProps.inbox.listHomeInbox })
        }
        // if (nextProps.global.help.homeFilterHelped !== this.props.global.help.homeFilterHelped
        //       || nextProps.global.help.homeHelped !== this.props.global.help.homeHelped) {
        //     let isOpenHelpSearch = !nextProps.global.help.homeFilterHelped;
        //     let isOpenHelpDinhGia = !isOpenHelpSearch && !nextProps.global.help.homeHelped;
        //     this.setState({isOpenHelpSearch: isOpenHelpSearch,
        //         isOpenHelpDinhGia: isOpenHelpDinhGia});
        // }
    }

    componentWillMount() {
        setTimeout(() => this.fetchData(), 300);
        VersionCheck.needUpdate()
            .then(res => {
                if (res.isNeeded) {
                    this.setState({
                        isNeedUpdate: true
                    })
                }
            });
    }

    fetchData_old = async () => {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.onGroupFieldChange("feedPageNo", 1)
        await this.props.actions.getRelatedGroup({ userID: userID }, token, () => {
            this._loadNewFeed();
        },
            (error) => {
                log.info(' server respond error: =====>>>>> getRelatedGroup', error);
                // this._updateMessageProcessingNetInfo(error,'rgba(250,73,22,0.7)', '#fff');
            }
        );
    }

    fetchData = async () => {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.onGroupFieldChange("feedPageNo", 1)
        this._loadNews();

        await this.props.actions.getRelatedGroup({ userID: userID }, token, () => {
        },
            (error) => {
                log.info(' server respond error: =====>>>>> getRelatedGroup', error);
            }
        );
    }

    componentDidMount() {
        let userID = this.props.global.currentUser.userID || undefined;
        // this._loadNewFeed(userID);
    }

    // _loadNewFeed(userID) {
    //     if (!userID) {
    //         return;
    //     }    
    //     let dto = {
    //         'userID': userID,
    //         'limit': 5,
    //         'pageNo': 1,
    //         'textSearch': ''
    //     }
    //     this.props.actions.newFeedWall(dto
    //         , (res) => {
    //             // log.info(' server respond data: =====>>>>> ', res.data);
    //         }
    //         , (error) => {
    //             log.info(' server respond error: =====>>>>> ', error);
    //         }
    //     );
    // }

    async _loadNews() {
        await this.props.actions.loadNews({
            'limit': 20,
            'page': 1
        }
            , (res) => {
                log.info(' server respond data: =====>>>>> ', res.data);
            }
            , (error) => {
                log.info(' server respond error: =====>>>>> ', error);
            }
        );
    }

    async _loadNewFeed() {
        let userID = this.props.global.currentUser.userID || undefined;

        await this.props.actions.newFeedWall({
            'userID': userID,
            'limit': 5,
            'pageNo': 1,
            'textSearch': ''
        }
            , (res) => {
                log.info(' server respond data: =====>>>>> ', res.data);
            }
            , (error) => {
                log.info(' server respond error: =====>>>>> ', error);
            }
        );
        await this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
    }

    // _updateMessageProcessingNetInfo(textMessage, bgColor, textColor) {
    //     this.setState({textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor});
    //     this._onMsgAnimationStartNetInfo();
    // }
    //
    // _onMsgAnimationStartNetInfo() {
    //     this.setState({msgType: 'fadeInDown'});
    //     clearTimeout(this.msgTimer);
    //     this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
    // }
    //
    // _renderMessageItemNetInfo() {
    //     let textValue = this.state.textMessage;
    //     if (textValue == '' || this.state.msgType == '') {
    //         return null;
    //     }
    //     return (
    //         <MMessage mainStyle={{top: 0}}
    //                   hideStatus={this.state.msgType == 'fadeInDown'}
    //                   animation={this.state.msgType}
    //                   duration={500}
    //                   onAnimationEnd={this._onAnimationEndInfo.bind(this)}
    //                   textValue={textValue}
    //                   bgColor={this.state.msgBgColor}
    //                   textColor={this.state.msgTextColor}/>
    //     );
    // }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeader()}
                {/*{this._renderTabSelected()}*/}
                {this._renderEachContent()}
                {this._renderContactModal()}
                {this._openFunctionModal()}
                {this.props.group.showImagePreview ? this._renderImagePreviewModal(this.state.pickedRow) : null}
                {this.loadingFeed()}

                {this._openModalDetail()}
                {this._renderMessageItem()}
                {/*{this._renderMessageItemNetInfo()}*/}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                    style={{ marginLeft: 15, marginRight: 15 }}
                />

            </View>
        );
    }

    _openModalDetail() {
        return (
            <Modal isOpen={this.state.isModalContent}
                onClosed={this.outModalDetail.bind(this)}
                style={styles.viewModalDetail}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                <UserModal groupName={this.state.modalGroupName}
                    data={this.state.dataContent}
                    onClosePress={this.outModalContent.bind(this)} />
                {/*{this.renderContent()}*/}
            </Modal>
        );
    }

    outModalDetail() {
        this.setState({
            isModalContent: false,
            dataContent: null,
            modalGroupName: null
        })
    }
    outModalContent() {
        this.setState({
            isModalContent: false
        })
    }

    onDetailContent(data, modalGroupName) {
        this.setState({
            isModalContent: true,
            dataContent: data,
            modalGroupName: modalGroupName
        })
    }

    loadingFeed() {
        if (this.props.group.loadingFeed || this.props.group.loadingContact) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' />
            </View>)
        }
    }

    _renderEachContent() {
        return (
            <View style={styles.viewHomeContent}>
                {/*{this._renderHomeMain()}*/}
                {this._renderListGroupWall()}
            </View>
        )
    }

    _renderHomeMain() {
        let collections = this.props.search.agentCollections;
        let { adsContact, adsPost, adsCongViec, adsGroup } = this.state;
        return (
            <View
                //automaticallyAdjustContentInsets={false}
                vertical={true}
                style={{ marginBottom: 0 }}
            // style={{flex: 1, backgroundColor: gui.groupBackground}}
            >
                {/*{this._renderListInbox()}*/}
                {/*<View style={styles.viewAllAds}>*/}
                {/*{adsContact ? this._renderAdsContact() : null}*/}
                {/*{adsPost ? this._renderAdsPost() : null}*/}
                {/*{adsCongViec ? this._renderAdsCongViec() : null}*/}
                {/*</View>*/}

                {/*/!*this._renderHomeButton()*!/*/}
                {/*{this._renderToDoList()}*/}

                {/*/!* {this._renderTextService()} *!/*/}
                {/*/!* {this._renderListService()} *!/*/}

                {/*/!* {this._renderTextSource()} *!/*/}
                {/*/!* {this._renderListSource()} *!/*/}
                {/*{this._renderSourceGroupText(collections)}*/}
                {/*{this.renderCollections(collections)}*/}
                {/*/!* {this._renderNewFeed()} *!/*/}
                {this._renderListGroupWall()}
            </View>
        )
    }

    // _renderNewFeed() {
    //     return (
    //         <View style={styles.scrollView}>
    //             {this._renderListGroupWall()}
    //         </View>
    //     )
    // }

    _renderListGroupWall() {
        // log.info('_renderListGroupWall *** ', this.props.group.newFeedList)
        return (
            <View style={{ flex: 1, backgroundColor: '#fff' }}>
                {/* <FlatList
                    refreshControl={
                        <RefreshControl
                            refreshing={false}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                    ref={(ref) => this.scrollView = ref}
                    data={this.props.group.newFeedList}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRowGroupWall(data.item)}
                    ListHeaderComponent={this._renderHeaderContent()}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.listContent}
                    contentContainerStyle={{ paddingBottom: 0 }}
                    onEndReachedThreshold={0}
                    onEndReached={() => this.loadNextPage()}
                    ListFooterComponent={() =>
                        this.state.loaded
                            ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
                            : null}
                /> */}
                <FlatList
                    data={this.props.group.newsList}
                    keyExtractor={(items, index) => "list" + index}
                    renderItem={(data) => this._renderRowNews(data.item)}
                    ListHeaderComponent={this._renderHeaderContent()}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListNews}
                    contentContainerStyle={{ paddingBottom: 0 }}
                    onEndReachedThreshold={0}
                    onEndReached={() => this.loadNextPage()}
                    ListFooterComponent={() =>
                        this.state.loaded
                            ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
                            : null}
                />
            </View>
        );

        // return this._renderHeaderContent();
    }

    _renderHeaderContent() {
        let collections = this.props.search.agentCollections;
        let { adsContact, adsPost, adsCongViec, adsGroup } = this.state;
        return (
            <ScrollView
                automaticallyAdjustContentInsets={false}
                showsVerticalScrollIndicator={false}
                vertical={true}
                style={{ width: width, height: 'auto', backgroundColor: '#fff' }}>
                {/* {this._renderListInbox()}   bachtv: rao render inbox*/}
                {/* <View style={styles.viewAllAds}>
                    {adsContact ? this._renderAdsContact() : null}
                    {adsPost ? this._renderAdsPost() : null}
                    {adsCongViec ? this._renderAdsCongViec() : null}                    
                </View> */}
                {this._renderToDoList()}

                {/*this._renderSourceGroupText(collections, 0)*/}
                {/*this.renderCollections(collections, 0)*/}

                {/*this._renderSourceGroupText(collections, 1)*/}
                {/*this.renderCollections(collections, 1)*/}
                {/*this._renderGroupWallHeader()*/}

                <View style={styles.toDoTitle}>

                    <Text style={[styles.textGuide]}>Tin tức mới nhất</Text>
                    <TouchableHighlight
                        onPress={this._onNewList.bind(this)}
                        underlayColor='transparent'
                        style={styles.touchAddTodo}
                    >
                        <Text style={[styles.themCongViecText, { color: gui.mainAgentColor }]}>Xem tất cả</Text>
                    </TouchableHighlight>
                </View>
                <FullLine />

            </ScrollView>
        )
    }
    _renderGroupWallHeader() {
        if (this.props.group.newFeedList && this.props.group.newFeedList.length > 0)
            return (
                <View>
                    <View style={[styles.sourceGroupView, { height: 52, width: width }]}>
                        <Text style={styles.textGuide}>Tin tức mới từ các sàn</Text>
                        <Text style={styles.textNote}>
                            Cập nhật tin tức mới nhất từ các sàn mà bạn tham gia
                        </Text>
                    </View>
                    <FullLine />
                </View>
            )

        return (
            <View>
                <View style={[styles.sourceGroupView, { height: 52, width: width }]}>
                    <Text style={styles.textGuide}>Tin tức mới từ các sàn</Text>
                    <Text style={styles.textNote}>
                        Cập nhật tin tức mới nhất từ các sàn mà bạn tham gia
                    </Text>
                </View>
                <FullLine />
                <View style={[{ marginTop: 5, paddingLeft: 8, paddingRight: 8, justifyContent: 'center', backgroundColor: '#fff', width: width }]}>
                    <Text style={{ fontFamily: gui.fontFamily, textAlign: 'justify', fontSize: 15, color: '#51698D' }}>
                        Tìm sàn môi giới bất động sản phù hợp và đăng ký tham gia ngay để nhận tin tức, nguồn hàng mới nhất từ các sàn. Hoặc tạo sàn môi giới để xây dựng team 'chất' của bạn.
                    </Text>
                </View>
                <View style={{ height: 50, width: width, marginTop: 5, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                    <TouchableOpacity style={[{
                        marginRight: 5,
                        paddingVertical: 7,
                        paddingHorizontal: 5,
                        borderWidth: 1,
                        borderColor: gui.mainAgentColor,
                        borderRadius: 2,
                        justifyContent: 'center',
                        alignItems: 'center'
                    }]}
                        onPress={this._onPressGroupSearch.bind(this)}
                    >
                        <Text style={styles.textButtonAds}> Tìm sàn </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[{
                        marginLeft: 5,
                        paddingVertical: 7,
                        paddingHorizontal: 5,
                        borderWidth: 1,
                        borderColor: gui.mainAgentColor,
                        borderRadius: 2,
                        justifyContent: 'center',
                        alignItems: 'center'
                    }]}
                        onPress={this._onPressGroupCreator.bind(this)}
                    >
                        <Text style={styles.textButtonAds}> Tạo sàn </Text>
                    </TouchableOpacity>

                </View>
            </View>
        );
    }

    _renderNews() {
        return (
            <View>
                <View style={styles.toDoTitle}>

                    <Text style={[styles.textGuide]}>Tin tức</Text>
                    <TouchableHighlight
                        onPress={this._onNewList.bind(this)}
                        underlayColor='transparent'
                        style={styles.touchAddTodo}
                    >
                        <Text style={[styles.themCongViecText, { color: gui.mainAgentColor }]}>Xem tất cả</Text>
                    </TouchableHighlight>
                </View>
                <FullLine />
                <FlatList
                    data={this.props.group.newsList}
                    keyExtractor={(items, index) => "list" + index}
                    renderItem={(data) => this._renderRowNews(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListNews}
                    onEndReachedThreshold={0}
                    onEndReached={() => this.loadNextPage()}
                    ListFooterComponent={() =>
                        this.state.loaded
                            ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
                            : null}
                />
            </View>
        )
    }

    _renderRowNews(data) {
        // console.log('_renderRowNews data to render **************', data)
        let imgUrl = data && data.image;
        let sourceNewsUrl = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!sourceNewsUrl) {
            sourceNewsUrl = require('../../assets/image/no_cover.jpg');
        }
        let category = DanhMuc.allCategoryName[data.parent_cate || data.cate];
        let newsTitle = data.title;
        let timeStamp = data.createdtime //moment(data.timeStamp).format('DD/MM/YY, h:mm');
        return (
            <TouchableOpacity style={styles.viewRowNews}
                onPress={this.onRowPress.bind(this, data)}
            >
                <Image
                    resizeMode={"cover"}
                    source={sourceNewsUrl}
                    defaultSource={defaultCover}
                    style={styles.newsCover}
                />
                <View style={styles.itemsContent}>
                    <View style={styles.viewTextTitle}>
                        <Text style={[styles.textTitle, { fontSize: 16 }]} numberOfLines={3}>{newsTitle}</Text>
                    </View>
                    <View style={styles.viewTimeStamp}>
                        <View style={styles.sourceNews}>
                            {/* <FontAwesomeLight name="user-alt"
                                              size={14}
                                              color={gui.textShare}
                                              noAction={true}
                                              iconOnly={true}
                                              mainProps={{marginBottom: 4}}/> */}
                            <Text style={[styles.textTime, { marginLeft: 0 }]}>{category}</Text>
                        </View>
                        <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                            <FontAwesomeLight name="clock"
                                size={13}
                                color={gui.textShare}
                                noAction={true}
                                iconOnly={true}
                                mainProps={{ marginBottom: 3 }} />
                            <Text style={styles.textTime}>{timeStamp}</Text>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    onRowPress(newsData) {
        console.log('on click chi tiet news ***', newsData)
        let eventDto = {
            scene: "NewHomeAgent",
            parentScene: undefined,  //truyen owner neu co            
            componentType: "listItem",
            component: "Chi tiết tin tức",
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,
            customData: {url: newsData.url}
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });

        Actions.NewsDetail({ data: newsData });

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_NEWS_DETAIL', { deviceID: deviceID, userID: userID });
    }

    _onNewList() {
        Actions.NewsList({owner: 'NewHomeAgent'});

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_NEWS_ALL', { deviceID: deviceID, userID: userID });
    }

    _onPressGroupSearch() {
        Actions.GroupSearch();
    }

    _onPressGroupCreator() {
        this._onRefreshGroup();
        Actions.Group();
    }

    _onRefreshGroup() {
        this.props.actions.onGroupFieldChange('groupID', null);
        this.props.actions.onGroupFieldChange('name', '');
        this.props.actions.onGroupFieldChange('groupType', 'public');
        this.props.actions.onGroupFieldChange('chiTiet', '');
        this.props.actions.onGroupFieldChange('photos', []);
        this.props.actions.onGroupFieldChange('allDiaChinh', []);
    }

    _renderRowGroupWall(value, isFirstRow, isLastRow) {
        let data = value;
        if (isFirstRow) {
            return data;
        }
        if (data.adsList && data.adsList.length > 0 && (data.adsList[0].id || data.adsList[0].adsID))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderAdsImagePost(data)}
                    {this._renderDetailPost(data)}
                    <LineFacebook />
                </View>
            );
        if (data.wtoList && data.wtoList.length > 0 && (data.wtoList[0].id))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderWtoPost(data)}
                    {this._renderCommentCount(data)}
                    <LineFacebook />
                </View>
            );
        if (data.image && data.image.length > 0)
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderSimpleImagePost(data)}
                    {this._renderCommentCount(data)}
                    <LineFacebook />
                </View>
            );
        return (
            <View style={styles.viewListMyGroup}>
                {this._renderRowTopContent(data)}
                {this._renderCommentCount(data)}
                <LineFacebook />
            </View>
        );
    }

    _renderWtoPost(data) {
        // log.info('===========> groupwal2 _renderRowWto',status);

        if (data.wtoList && data.wtoList.length > 0) {
            data = data.wtoList[0];
        }

        return (
            <View style={styles.viewAdsWto}>
                <TouchableOpacity style={styles.viewRowPostWto} onPress={() => this._onPressWto(data)}>
                    {this._renderDetailWtoPost(data)}
                </TouchableOpacity>
            </View>
        )
    }

    _onPressWto(data) {
        if (!data.phone) {
            this.props.actions.getUserInfo(data.userID)
                .then(res => {
                    if (res.status != 0) {
                        Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                    } else {

                        if (res.userInfo) {
                            data.phone = res.userInfo.phone
                            data.email = res.userInfo.email
                            data.fullName = res.userInfo.fullName
                            data.avatar = res.userInfo.avatar
                        }

                        Actions.AgentWtoDetail({ data: data });
                    }
                });
        } else Actions.AgentWtoDetail({ data: data });
    }

    _renderDetailWtoPost(data) {
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))
        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;

        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;

        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        let diaChiFullName = data.content.place.fullName || ' ';
        return (
            <View style={[styles.viewDetailPost3, { height: 'auto' }]}>
                <View style={styles.viewTieuDe}>
                    <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                        <Text style={styles.textTypePost}>{priority}</Text>
                    </View>
                    <View style={styles.viewTextTieuDe}>
                        <Text style={styles.textTieuDe} numberOfLines={1}>{diaChiFullname}</Text>
                    </View>
                </View>
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { fontWeight: '500' }]} numberOfLines={1}>{giaNha}</Text>
                </View>
                <View style={[styles.viewLabel, { marginTop: 6 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 48 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { color: gui.textPostCommon }]}>{diaChiFullName}</Text>
                    </View>
                </View>
                {
                    detailItems && detailItems.length > 0 ?
                        <View style={[styles.viewPercentDraft, { flexDirection: 'row' }]}>
                            {detailItems}
                        </View> : null
                }
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { color: '#898989' }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                </View>
            </View>
        );
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="compass" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser2, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }
    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostAds} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser2, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="bath" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser2, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser2, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    loadNextPage = () => {
        let currentPageNo = this.state.newsPageNo;
        let totalPages = this.props.group.totalNewsCount / 20;
        if (totalPages && currentPageNo < totalPages) {
            this.props.actions.onGroupFieldChange("newsPageNo", currentPageNo + 1)
            this.setState(state => ({ newsPageNo: state.newsPageNo + 1 }), () => this.getNextNews());
        }
        // this.getNextNews()
    };

    getNextNews = () => {
        this.setState({ loaded: true });

        this.props.actions.loadNews({
            'limit': 20,
            'page': this.state.newsPageNo
        }
            , (res) => {
                log.info(' server respond data: =====>>>>> ', res.data);
                // this.refreshFeed(res.data)
            }
            , (error) => {
                this.setState({
                    loaded: true
                });
            }
        );
    }

    refreshFeed(data) {
        this.setState({
            'newFeedList': [...this.props.group.newFeedList, ...data],
            loaded: false
        });

    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _renderImagePreviewModal(data) {
        if (!data)
            return null;

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image) {
            for (let i = 0; i < data.image.length; i++) {
                imageUrl = data.image[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }

        let userID = null;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        return (
            <ImagePreview images={imageDataItems}
                closeModal={() => this.props.actions.onGroupFieldChange('showImagePreview', false)} ads={data} userID={userID}
                loggedIn={this.props.global.loggedIn}
            />
        );
    }

    _onFunctionButtonPress(data) {
        this.setState({ isOpenFunctionModal: true, selectedPost: data });
    }

    _outFunctionModal() {
        this.setState({
            isOpenFunctionModal: false
        });
    }

    _openFunctionModal() {
        let currentUser = this.props.global.currentUser;
        let selectedPost = this.state.selectedPost;
        let modalHeight = selectedPost && selectedPost.userID == currentUser.userID ? 229 : 169;
        return (
            <Modal isOpen={this.state.isOpenFunctionModal}
                onClosed={this._outFunctionModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto', bottom: 50 }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderFunctionContent()}
            </Modal>
        );
    }

    _renderFunctionContent() {
        let selectedPost = this.state.selectedPost;
        let items = [];
        let currentUser = this.props.global.currentUser;
        let textModal1 = 'Xóa bài viết và giữ chia sẻ BĐS trên kho hàng';
        let textModal2 = 'Xóa bài viết và BĐS khỏi kho hàng';
        let isAdmin = this.isAdminOfGroup();
        if (selectedPost && selectedPost.userID == currentUser.userID) {
            if (selectedPost.ads.length > 0) {
                // mainItems = <View style={[styles.viewSwipeButton, { height: 154 }]}>
                //     <TouchableOpacity onPress={this._onEditPostPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                //         <Text style={[styles.textMoreButton, { fontSize: 15 }]}>Sửa bài viết</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     <TouchableOpacity onPress={this._onDeletePostPress.bind(this, true)} style={[styles.viewButtonModal, styles.modalButton1]}>
                //         <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal1}</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, styles.modalButton2]}>
                //         <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal2}</Text>
                //     </TouchableOpacity>
                // </View>
                items.push({ _text: 'Sửa bài viết', _function: () => this._onEditPostPress() })
                items.push({ _text: textModal1, _function: () => this._onDeletePostPress(true) })
                items.push({ _text: textModal2, _function: () => this._onDeletePostPress(false) })
            }
            else {
                // mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>
                //     <TouchableOpacity onPress={this._onEditPostPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                //         <Text style={styles.textMoreButton}>Sửa bài</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                //         <Text style={styles.textMoreButton}>Xóa bài</Text>
                //     </TouchableOpacity>
                // </View>
                items.push({ _text: 'Sửa bài', _function: () => this._onEditPostPress() })
                items.push({ _text: 'Xóa bài', _function: () => this._onDeletePostPress(false) })
            }
        } else {
            if (selectedPost && isAdmin == true) { //la admin
                // mainItems = <View style={[styles.viewSwipeButton, { height: 55 }]}>
                //     <TouchableOpacity onPress={this.onChat.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                //         <Text style={styles.textMoreButton}>Chat với người đăng</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     {selectedPost.ads.length > 0
                //         ?
                //         (
                //             <View>
                //                 <TouchableOpacity onPress={this._onDeletePostPress.bind(this, true)} style={[styles.viewButtonModal, styles.modalButton1]}>
                //                     <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal1}</Text>
                //                 </TouchableOpacity>
                //                 <FullLine />
                //                 <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, styles.modalButton2]}>
                //                     <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal2}</Text>
                //                 </TouchableOpacity>
                //             </View>)
                //         :
                //         <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, styles.modalButton2]}>
                //             <Text style={styles.textMoreButton}>Xóa bài</Text>
                //         </TouchableOpacity>
                //     }
                // </View>
                items.push({ _text: 'Chat với người đăng', _function: () => this.onChat() })
                if (selectedPost.ads.length > 0) {
                    items.push({ _text: textModal1, _function: () => this._onDeletePostPress(true) })
                    items.push({ _text: textModal2, _function: () => this._onDeletePostPress(false) })
                } else {
                    items.push({ _text: 'Xóa bài', _function: () => this._onDeletePostPress(false) })
                }
            } else {
                // mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>
                //     <TouchableOpacity onPress={this.onChat.bind(this)} style={[styles.viewButtonModal]}>
                //         <Text style={styles.textMoreButton}>Chat với người đăng</Text>
                //     </TouchableOpacity>
                // </View>
                items.push({ _text: 'Chat với người đăng', _function: () => this.onChat(true) })
            }
        }

        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outFunctionModal.bind(this)} />
        )
    }

    isAdminOfGroup() {
        let selectedPost = this.state.selectedPost;
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let userID = this.props.global.currentUser.userID;
        let listSanCuaBan = listRelatedGroup.filter((one) => {
            return one.createdBy == userID && one.joinStatus == 2 && selectedPost && one.groupID == selectedPost.groupID
        }) || [];

        return selectedPost && listSanCuaBan.length > 0
    }

    _onEditPostPress() {
        let selectedPost = this.state.selectedPost;

        if (!selectedPost) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let images = []
        if (selectedPost.image && selectedPost.image.length > 0)
            selectedPost.image.forEach((e) => {
                images.push({ uri: e })
            })

        let wallContent = {
            postID: selectedPost.id,
            postContent: selectedPost.content,
            postWallPhotos: images,
            postWallAds: selectedPost.adsList ? selectedPost.adsList[0] : (selectedPost.wtoList ? selectedPost.wtoList[0] : {})
        }
        let groupData = { name: selectedPost.groupName }
        Actions.GroupPostAds({ owner: 'NewHomeAgent', groupData: groupData, groupID: selectedPost.groupID, wallContent: wallContent });
        this._outFunctionModal();
    }

    _onDeletePostPress(keepShareAds) {
        let selectedPost = this.state.selectedPost;
        if (!selectedPost) {
            return;
        }
        let alertMsg = selectedPost.ads.length > 0
            ? (keepShareAds ? 'Bạn muốn xoá bài viết và giữ chia sẻ BĐS trên kho hàng?' : 'Bạn muốn xoá bài viết và BĐS khỏi kho hàng?')
            : 'Bạn muốn xoá bài viết'
        Alert.alert('Thông báo', alertMsg,
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let postID = selectedPost.id;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.deletePost({ postID: postID, keepShareAds: keepShareAds }, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            }
                            else {
                                setTimeout(() => Alert.alert("Thông báo", "Xoá bài viết thành công.", [{
                                    text: 'Đóng', onPress: () => {
                                        this.props.actions.onGroupFieldChange("feedPageNo", 1)
                                        let dto = {
                                            'userID': this.props.global.currentUser.userID,
                                            'limit': 5,
                                            'pageNo': 1,
                                            'textSearch': ''
                                        }
                                        this.props.actions.newFeedWall(dto
                                            , (res) => {
                                            }
                                            , (error) => {
                                                log.info('_loadNewFeed server respond error: =====>>>>> ', error);
                                            }
                                        );

                                    }
                                }]), 300);
                            }
                        });
                    this._outFunctionModal();
                }
            }
            ]);
    }

    onChat() {
        this._outFunctionModal();
        let data = this.state.selectedPost
        let partner = data.userID ? { userID: data.userID } : undefined;
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');

        if (!partner) {
            Alert.alert("Thông báo", 'Có lỗi xảy ra. Không thể bắt đầu trò chuyện.', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle, onGroupInbox: (value) => this._loadGroupInbox(value) });
                this.setState({
                    isloadingPressRow: false
                })
            });
    }

    _renderRowTopContent(data) {
        // log.info('NewHomeAgent _renderRowTopContent ********', data)
        let userAvatar = { uri: data.avatar };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!data.avatar) {
            userAvatar = defaultAvatar;
        }
        let textPromote = data.content || '';
        let nameMainUser = data.fullName || '';
        let groupName = data.groupName || '';

        let timePost = utils.getDiffTime(data.timeModified) || '';

        return (
            <View style={styles.viewRowTopContent}>
                <View style={styles.viewMainUser}>
                    <Image
                        resizeMode={"cover"}
                        source={userAvatar}
                        defaultSource={defaultCover}
                        style={[styles.mainUserAvatar, { marginTop: 2 }]} />
                    <View style={{ width: width - 100, height: 24, marginLeft: 8, marginBottom: 8 }}>
                        <View style={{ flexDirection: 'row', width: width - 220, alignItems: 'center', justifyContent: 'flex-start' }}>
                            <TouchableOpacity onPress={this.onDetailContent.bind(this, data, groupName)}>
                                <Text numberOfLines={1} style={[styles.textMainUser, { fontSize: 15, marginLeft: 0, color: gui.textAgentSolid }]}>{nameMainUser}</Text>
                            </TouchableOpacity>
                            <MaterialIcons style={{ marginLeft: 4, marginRight: 4 }} name="play-arrow" size={14} color={gui.mainTextColor} />
                            <TouchableOpacity onPress={this._onGroupPress.bind(this, data)}>
                                <Text numberOfLines={1} style={[styles.textMainUser, { fontSize: 15, marginLeft: 0, color: gui.textAgentSolid }]}>{groupName}</Text>
                            </TouchableOpacity>
                        </View>
                        <Text style={[styles.textMainMinute, { fontSize: 12 }]}>{timePost}</Text>
                    </View>
                    <TouchableOpacity
                        onPress={this._onFunctionButtonPress.bind(this, data)}
                        style={styles.viewIconBubble}>
                        <FontAwesomeLight name="ellipsis-h" size={32} color={gui.moreColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>
                </View>
                <TouchableOpacity onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textSearch, { marginTop: 16, color: gui.textAgentSolid }]}>{textPromote}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _renderAdsImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let adsCoverPhoto = { uri: ads.image ? ads.image.cover : '' };
        if (!ads.image || !ads.image.cover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <View style={styles.imageContentRow}>
                {/*<View style={styles.viewBorderTopAds}>*/}
                {/*<View style={styles.viewBorderTopImage} />*/}
                {/*</View>*/}
                <ImageBackground style={[styles.imgItem2, { height: gui.ADS_IMAGE_RATIO * width }]}
                    resizeMode={"cover"}
                    source={adsCoverPhoto} defaultSource={defaultCover}>
                    <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}>
                        <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                            style={styles.linearGradientMain2}>
                            {this._renderUserLogo(data)}
                            {/*{this._renderNamePrice(data)}*/}
                        </LinearGradient>
                    </TouchableOpacity>
                </ImageBackground>
                {/*<View style={[styles.lineDangNhap, { marginTop: 8, marginLeft: 8 }]} />*/}
                {/*<View style={styles.lineBorderVertical} />*/}
            </View>
        )
    }

    _renderUserLogo(data) {
        let ads;
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let logoItems = [];
        let index = 0;

        if (ads && ads.banGap) {
            let marginLeft = index == 0 ? 0 : 8;
            let banGapText = ads.loaiTin ? DanhMuc.THUE_GAP : DanhMuc.BAN_GAP;
            logoItems.push(
                <View key={'logoBanGap'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{banGapText}</Text>
                </View>
            );
            index++;
        }


        if (ads && ads.chinhChuDangTin) {
            let marginLeft = index == 0 ? 0 : 8;
            logoItems.push(
                <View key={'logoChinhChuDangTin'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{DanhMuc.CHINH_CHU}</Text>
                </View>
            );
            index++;
        }

        return (
            <View style={styles.viewUserLogo}>
                {logoItems}
            </View>
        );
    }

    _renderGiaFmt(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        let giaFmt = `Giá: ${priceValue}`;
        return (
            <View style={styles.viewGiaFmt}>
                <Text style={styles.textPriceFmt}>{giaFmt}</Text>
            </View>
        );
    }

    _onPressAdsRow(ads) {
        Actions.GroupAdsDetail({ adsID: ads.id || ads.adsID, imageDetail: ads.image.cover, owner: 'NewHomeAgent' });
    }

    _onGroupPress(data) {
        this.props.actions.getGroupDetail({ 'groupID': data.groupID }, (res) => {
            let groupData = res.data || [];
            this.props.actions.onGroupFieldChange("pageNo", 1);
            this.props.actions.onGroupFieldChange("textSearch", '');
            this.props.actions.getNextWall(
                {
                    'groupID': [data.groupID],
                    'limit': this.props.group.limit,
                    'pageNo': 1,
                    'textSearch': '',
                }
                , (res) => {
                    StatusBar.setBarStyle('default');
                    Actions.GroupWall2({ owner: 'MyAlert', groupData: groupData, groupID: data.groupID });
                }
                , (error) => {
                })
        });
    }

    _renderSimpleImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let imageCover = {};
        if (data.image && data.image.length > 0) {
            imageCover = data.image[0];
        }
        let adsCoverPhoto = { uri: imageCover };
        if (!imageCover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <View style={[styles.imageContentRow, { height: 'auto' }]}>
                <TouchableOpacity
                    onPress={this._onImagePreviewPressed.bind(this, data)}
                    underlayColor="transparent" >
                    <View>
                        <ImageBackground style={[styles.imgItem2, { height: gui.ADS_IMAGE_RATIO * width }]}
                            resizeMode={"cover"}
                            source={adsCoverPhoto} defaultSource={defaultCover}>
                            <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                                style={styles.linearGradientMain2}>
                            </LinearGradient>
                            {this._renderTotalPhoto(data)}
                        </ImageBackground>
                    </View>
                </TouchableOpacity>
                {/*<FullLine style={{marginTop: 8, marginLeft: 8, marginRight: 8}}/>*/}
            </View>
        )
    }

    _renderTotalPhoto(data) {
        if (!data) {
            return null;
        }

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image) {
            for (let i = 0; i < data.image.length; i++) {
                imageUrl = data.image[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }
        let total = imageDataItems.length;
        return (
            <View style={{
                position: 'absolute',
                bottom: 20,
                left: 16
            }}>
                <RelandIcon name="camera-o" color="#fff"
                    iconProps={{ style: styles.pagingIcon }} size={16}
                    textProps={styles.pagingText}
                    mainProps={styles.pagingView}
                    text={(total) + ' ảnh'}
                >
                </RelandIcon>
            </View>
        );
    }

    _onImagePreviewPressed(data) {
        if (!data.image) {
            return;
        }
        if (this.props.group.showImagePreview) {
            return;
        }
        this.props.actions.onGroupFieldChange('showImagePreview', true);
        this.setState({
            pickedRow: data
        });
    }

    _renderDetailPost(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let areaValue = utils.getDienTichDisplay(ads.dienTich);
        let bedroomValue = ads.soPhongNgu;
        let bathroomValue = ads.soPhongTam;
        let huongNha = ads.huongNha ? DanhMuc.HuongNha[ads.huongNha] : '';
        let addressValue = '';
        let textMotionValue = '';
        if (ads.place) {
            addressValue = ads.place.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail(ads);
        } else {

            addressValue = ads.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail2(ads);
        }
        let timePostValue = ads.ngayDangTin ? utils.formatDate(ads.ngayDangTin) : '';
        let commentCount = data.commentCount || 0;
        let commentValue = commentCount + ' Bình luận';

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }

        if (!!huongNha) {
            detailItems.push(this._renderHuongNha(huongNha, (detailItems.length == 0) ? 0 : 12));
        }

        return (
            <View style={styles.viewAdsBorderCover}>
                <View style={styles.viewBorderCover}>
                    <TouchableOpacity
                        onPress={this._onPressAdsRow.bind(this, ads)}
                        style={styles.viewTopDetail}
                    >
                        <View style={styles.viewMainTextPost}>
                            <Text style={[styles.textMainPost, { color: gui.textAgentSolid }]} numberOfLines={2}>{textMotionValue}</Text>
                            <Text style={[styles.textTimePost, { color: gui.textComment, marginTop: 2 }]} numberOfLines={1}>{timePostValue}</Text>
                        </View>
                        <View style={[styles.lineDangNhap, { width: width - 32 }]} />
                        {this._renderGiaFmt(data)}
                        <View style={styles.viewTextAddress}>
                            <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
                            <Text style={[styles.textMainMinute, { marginLeft: 8, color: gui.textPostAds, fontSize: 15 }]} numberOfLines={1}>{addressValue}</Text>
                        </View>
                        {detailItems && detailItems.length > 0 ? <View style={styles.viewContentSource}>
                            {detailItems}
                        </View> : null}
                    </TouchableOpacity>
                    {/*<View style={[styles.lineDangNhap, {width: width - 32}]} />*/}
                </View>
                <View style={[styles.lineDangNhap, { width: width - 16, marginTop: 8 }]} />
                <TouchableOpacity style={[styles.viewLikeComment, { width: width }]} onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textMainUser, { fontWeight: 'normal', color: gui.textComment }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{commentValue}</Text>
                    <View style={{ flexDirection: 'row' }}>
                        <FontAwesomeLight name="comment-alt" size={16} color={gui.textPostCommon} noAction={true} iconOnly={true} mainProps={{ marginTop: 3 }} />
                        <Text style={[styles.textMainUser, { color: gui.textPostCommon }]}>Bình luận</Text>
                    </View>
                </TouchableOpacity>
                {this._renderLastComment(data)}
            </View>
        )
    }

    _renderCommentCount(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let commentCount = data.commentCount || 0;
        let commentValue = commentCount + ' Bình luận';
        let viewsValue = data.viewsValue;

        return (
            <View style={styles.viewDetailPostComment}>
                <View style={styles.lineDangNhap} />
                <TouchableOpacity style={[styles.viewLikeComment]}
                    onPress={() => this._onPressComment(data)}
                >
                    <Text style={[styles.textMainUser, { fontWeight: 'normal', color: gui.textComment }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >
                        {commentValue}
                    </Text>
                    <View style={{ flexDirection: 'row' }}>
                        <FontAwesomeLight name="comment-alt" size={16} color={'rgba(70,70,70,1)'} noAction={true} iconOnly={true} mainProps={{ marginTop: 3 }} />
                        <Text style={styles.textMainUser}>Bình luận</Text>
                    </View>
                </TouchableOpacity>
                {this._renderLastComment(data)}
            </View>
        )
    }

    _renderLastComment(data) {
        let lastComment = data.lastComment;
        if (lastComment && lastComment.content) {
            let imageUserComment
            if (lastComment.createdByAvatar)
                imageUserComment = { uri: lastComment.createdByAvatar };
            else {
                imageUserComment = require('../../assets/image/register_avatar_icon.png');
            }
            let defaultCover = require('../../assets/image/register_avatar_icon.png');

            let nameUser = lastComment.createdByName ? lastComment.createdByName : '';
            let commentContent = lastComment.content ? lastComment.content : '';

            return (
                <View style={styles.viewLastComment}>
                    <View style={styles.lineDangNhap} />
                    <TouchableOpacity style={styles.viewRowComment}
                        onPress={() => this._onPressComment(data)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageUserComment}
                            defaultSource={defaultCover}
                            style={styles.mainUserAvatar} />
                        <View style={styles.viewContentComment}>
                            <Text style={[styles.nameUserComment, { color: gui.textAgentSolid }]} numberOfLines={1}>{nameUser}</Text>
                            <Text style={styles.textContentChat} numberOfLines={1}>{commentContent}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }
        else return (<View></View>)
    }

    _renderLastComment2(data) {
        let lastComment = data.lastComment;
        if (lastComment && lastComment.content) {
            let imageUserComment
            if (lastComment.createdByAvatar)
                imageUserComment = { uri: lastComment.createdByAvatar };
            else {
                imageUserComment = require('../../assets/image/register_avatar_icon.png');
            }
            let defaultCover = require('../../assets/image/register_avatar_icon.png');

            let nameUser = lastComment.createdByName ? lastComment.createdByName : '';
            let commentContent = lastComment.content ? lastComment.content : '';

            return (
                <View style={[styles.viewLastComment, { width: width - 18 }]}>
                    <View style={[styles.lineDangNhap, { width: width - 32 }]} />
                    <TouchableOpacity style={[styles.viewRowComment, { width: width - 18 }]}
                        onPress={() => this._onPressComment(data)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageUserComment}
                            defaultSource={defaultCover}
                            style={styles.mainUserAvatar} />
                        <View style={styles.viewContentComment2}>
                            <Text style={[styles.nameUserComment, { color: gui.textAgentSolid }]} numberOfLines={1}>{nameUser}</Text>
                            <Text style={styles.textContentChat} numberOfLines={1}>{commentContent}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }
        else return (<View></View>)
    }

    _onPressComment(data) {
        this.props.actions.onGroupFieldChange('watchingWallID', data.id)
        Actions.GroupComment({ parentContent: data, groupID: data.groupID, groupWallID: data.id, owner: 'NewHomeAgent' });
    }

    _renderAdsContact() {
        let { contactList, loadingContact } = this.props.groupContact;
        if (this.props.search.loadingAgentHomeData ||
            this.props.global.help.initialContact ||
            loadingContact ||
            contactList && contactList.length > 0) {
            return null;
        }

        let titleAds = 'Danh bạ khách hàng';
        let contentAds = 'Bạn không nhớ được nhu cầu về BĐS của khách hàng hay có bao nhiêu khách hàng phù hợp với danh sách BĐS của bạn. Bạn gặp khó khăn trong việc phân loại khách hàng tiềm năng, quản lý lịch sử giao dịch với khách hàng. Hãy nhập danh bạ ngay để việc quản lý trở nên dễ dàng hơn.';
        let contentButton = 'Thêm khách hàng';
        return (
            <View style={styles.viewAdsHome}>
                <View style={styles.viewAdsContent}>
                    <View style={styles.viewTitleAds}>
                        <View style={styles.viewCloseButton} />
                        <View style={styles.titleAdsContent}>
                            <Text style={styles.textTitleAds}>{titleAds}</Text>
                        </View>
                        <TouchableOpacity style={styles.viewCloseButton}
                            onPress={this.onAdsContactClose.bind(this)}
                        >
                            <FontAwesomeLight name="times" size={20} color={'#B7B7B7'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewMoreAds}>
                        <ViewMoreText longText={contentAds}
                            textProps={{ color: '#51698D' }}
                            expanded={false}
                            maxLength={130}
                            width={width - 52}>
                        </ViewMoreText>
                    </View>
                    <View style={styles.viewIconButton}>
                        <Image
                            source={require('../../assets/image/artBoard3.png')}
                            style={styles.imageAds1}
                            resizeMode={"cover"}
                        />
                        <TouchableOpacity style={[styles.touchButtonAds, { paddingHorizontal: 5 }]}
                            onPress={this._onPressAdsContact.bind(this)}
                        >
                            <Text style={styles.textButtonAds}> {contentButton} </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    _renderAdsPost() {
        let { listAdsDraft, listAdsPosted, loadingAds } = this.props.adsMgmt;
        if (this.props.search.loadingAgentHomeData ||
            this.props.global.help.initialPost ||
            loadingAds ||
            listAdsDraft && listAdsDraft.length > 0 ||
            listAdsPosted && listAdsPosted.length > 0) {
            return null;
        }

        let titleAds = 'Đăng tin bán/cho thuê';
        let contentAds = 'Chỉ mất chưa đến 5 phút bạn có thể đăng được 1 tin bán/cho thuê lên Landber Agent, tin đăng hoàn toàn miễn phí. Dễ dàng chia sẻ BĐS của bạn trong các sàn Môi giới mà bạn tham gia.';
        let contentButton = 'Đăng tin ngay';
        return (
            <View style={styles.viewAdsHome}>
                <View style={styles.viewAdsContent}>
                    <View style={styles.viewTitleAds}>
                        <View style={styles.viewCloseButton} />
                        <View style={styles.titleAdsContent}>
                            <Text style={styles.textTitleAds}>{titleAds}</Text>
                        </View>
                        <TouchableOpacity style={styles.viewCloseButton}
                            onPress={this.onAdsPostClose.bind(this)}
                        >
                            <FontAwesomeLight name="times" size={20} color={'#B7B7B7'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewMoreAds}>
                        <ViewMoreText longText={contentAds}
                            textProps={{ color: '#51698D' }}
                            expanded={false}
                            maxLength={130}
                            width={width - 52}>
                        </ViewMoreText>
                    </View>
                    <View style={styles.viewIconButton}>
                        <Image
                            source={require('../../assets/image/artBoard1.png')}
                            style={styles.imageAds2}
                            resizeMode={"cover"}
                        />
                        <TouchableOpacity style={[styles.touchButtonAds, { marginLeft: 31 }]}
                            onPress={this._onPressAdsPost.bind(this)}
                        >
                            <Text style={styles.textButtonAds}> {contentButton} </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    _renderAdsCongViec() {
        if (this.props.search.loadingAgentHomeData ||
            this.props.global.help.initialEvent) {
            return null;
        }

        let found = this.state.eventList.find((one) => {
            return one.status != 2; //Done
        });

        if (found) {
            return null;
        }

        let titleAds = 'Danh sách công việc';
        let contentAds = 'Bạn quá bận rộn và hay quên lịch hẹn với khách? Hãy nhập danh sách công việc để hệ thống tự động nhắc bạn.';
        let contentButton = 'Thêm công việc';
        return (
            <View style={styles.viewAdsHome}>
                <View style={[styles.viewAdsContent, { marginBottom: 10 }]}>
                    <View style={styles.viewTitleAds}>
                        <View style={styles.viewCloseButton} />
                        <View style={styles.titleAdsContent}>
                            <Text style={styles.textTitleAds}>{titleAds}</Text>
                        </View>
                        <TouchableOpacity style={styles.viewCloseButton}
                            onPress={this.onAdsCongViecClose.bind(this)}
                        >
                            <FontAwesomeLight name="times" size={20} color={'#B7B7B7'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewMoreAds}>
                        <ViewMoreText longText={contentAds}
                            textProps={{ color: '#51698D' }}
                            expanded={false}
                            maxLength={130}
                            width={width - 52}>
                        </ViewMoreText>
                    </View>
                    <View style={styles.viewIconButton}>
                        <Image
                            source={require('../../assets/image/artBoard2.png')}
                            style={styles.imageAds3}
                            resizeMode={"cover"}
                        />
                        <TouchableOpacity style={[styles.touchButtonAds, { marginLeft: 48 }]}
                            onPress={this._onCreateEvent.bind(this)}
                        >
                            <Text style={styles.textButtonAds}>{contentButton}</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    _renderAdsGroup() {
        if (this.props.search.loadingAgentHomeData ||
            this.props.global.help.initialGroup) {
            return null;
        }

        let found = this.props.group.searchResult.listRelatedGroup && this.props.group.searchResult.listRelatedGroup.length > 0

        if (found) {
            return null;
        }

        let titleAds = 'Sàn bất động sản';
        let contentAds = 'Hãy khởi tạo sàn BĐS của bạn hoặc tham gia các sàn BĐS đang hoạt động để kết nối với các môi giới khác';
        let contentButton = 'Bắt đầu ngay';
        return (
            <View style={styles.viewAdsHome}>
                <View style={[styles.viewAdsContent, { marginBottom: 10 }]}>
                    <View style={styles.viewTitleAds}>
                        <View style={styles.viewCloseButton} />
                        <View style={styles.titleAdsContent}>
                            <Text style={styles.textTitleAds}>{titleAds}</Text>
                        </View>
                        <TouchableOpacity style={styles.viewCloseButton}
                            onPress={this.onAdsGroupClose.bind(this)}
                        >
                            <FontAwesomeLight name="times" size={20} color={'#B7B7B7'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewMoreAds}>
                        <ViewMoreText longText={contentAds}
                            textProps={{ color: '#51698D' }}
                            expanded={false}
                            maxLength={130}
                            width={width - 52}>
                        </ViewMoreText>
                    </View>
                    <View style={styles.viewIconButton}>
                        <Image
                            source={require('../../assets/image/artBoard2.png')}
                            style={styles.imageAds3}
                            resizeMode={"cover"}
                        />
                        <TouchableOpacity style={[styles.touchButtonAds, { marginLeft: 48 }]}
                            onPress={this._onPressAdsGroup.bind(this)}
                        >
                            <Text style={styles.textButtonAds}>{contentButton}</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    onAdsContactClose() {
        this.setState({
            adsContact: false
        })
    }

    onAdsPostClose() {
        this.setState({
            adsPost: false
        })
    }

    onAdsCongViecClose() {
        this.setState({
            adsCongViec: false
        })
    }

    onAdsGroupClose() {
        this.setState({
            adsGroup: false
        })
    }

    _onAddContact() {
        this._outNewModal();

        this._onRefreshNewContact();

        this._onSaveInitialContact();

        Actions.ModifyContact({ owner: 'NewHomeAgent', text: '', request: (value) => this._request(value) });
    }

    _renderContactModal() {
        let modalHeight = 169;
        return (
            <Modal isOpen={this.state.isOpenNewModal}
                onClosed={this._outNewModal.bind(this)}
                style={[styles.viewModalStyle, { height: modalHeight }]}
                position={"bottom"}
                swipeToClose={false}
            >
                {this._renderNewModalContent()}
            </Modal>
        );

    }

    _renderNewModalContent() {
        let mainItems = <View style={styles.viewSwipeButton}>
            <TouchableOpacity onPress={this._onAddContact.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                <Text style={styles.textMoreButton}>Nhập mới</Text>
            </TouchableOpacity>
            <View style={styles.lineSpaceButton} />
            <TouchableOpacity onPress={this._onImportFromDevice.bind(this)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                <Text style={styles.textMoreButton}>Chọn từ danh bạ</Text>
            </TouchableOpacity>
        </View>;

        return (
            <View style={styles.viewShowModal}>
                {mainItems}
            </View>
        )
    }

    _onImportFromDevice() {
        this._outNewModal();
        Contacts.requestPermission((err, permission) => {

            Contacts.getAll((err, contacts) => {
                if (err === 'denied') {
                    // error
                } else {
                    contacts = contacts.filter((e) => { return e.phoneNumbers && e.phoneNumbers.length > 0 })
                    this.props.actions.getAllContact(
                        { 'userID': this.props.global.currentUser.userID, 'orderBy': 'nameASC' }
                        , (res) => {
                            let contactList = res.data;
                            // console.log('bachtv contactList ****************', contactList)
                            contacts.forEach(e => {
                                e.checked = false;
                                e.canInvite = true;

                                let contactInReducer = this.props.groupContact.allDeviceContactList.filter((f) => { return f.recordID == e.recordID })

                                if (contactInReducer && contactInReducer.length > 0) {
                                    e.canInvite = contactInReducer[0].canInvite
                                }

                                let contactPhone = e.phoneNumbers && e.phoneNumbers.length > 0 ? e.phoneNumbers[0].number.trim() : '';
                                contactPhone = contactPhone.replace(/\D/g, '')
                                if (contactPhone.startsWith('84'))
                                    contactPhone = '0' + contactPhone.slice(2, contactPhone.length);

                                let existedInDanhBa = contactList.filter((f) => { return f.contactPhone == contactPhone })
                                if (existedInDanhBa && existedInDanhBa.length > 0)
                                    e.canInvite = false;

                            })

                            // this.setState({ 'deviceContactList': contacts })
                            this.props.actions.onGroupContactFieldChange('allDeviceContactList', contacts)
                            this.props.actions.onGroupContactFieldChange('filteredDeviceContactList', contacts)
                            Actions.ContactImport({ text: '', request: (value) => this._request(value) });
                        }
                        , (error) => {
                            console.log('get All Contact server respond data: =====>>>>>', error)
                            contacts.forEach(e => {
                                e.checked = false;
                                e.canInvite = true;

                                let contactInReducer = this.props.groupContact.allDeviceContactList.filter((f) => { return f.recordID == e.recordID })

                                if (contactInReducer && contactInReducer.length > 0) {
                                    e.canInvite = contactInReducer[0].canInvite
                                }

                                let contactPhone = e.phoneNumbers && e.phoneNumbers.length > 0 ? e.phoneNumbers[0].number.trim() : '';
                                contactPhone = contactPhone.replace(/\D/g, '')
                                if (contactPhone.startsWith('84'))
                                    contactPhone = '0' + contactPhone.slice(2, contactPhone.length);

                            })

                            // this.setState({ 'deviceContactList': contacts })
                            this.props.actions.onGroupContactFieldChange('allDeviceContactList', contacts)
                            this.props.actions.onGroupContactFieldChange('filteredDeviceContactList', contacts)
                            Actions.ContactImport({ text: '', request: (value) => this._request(value) });
                        });

                }
            })

        })
    }

    _request(text) {
        // this.props.actions.onGroupContactFieldChange('contactList', [])
        this.props.actions.getAllContact(
            {
                'userID': this.props.global.currentUser.userID,
                'orderBy': this.props.group.orderBy
            }
            , (res) => {
            }
            , (error) => {
                log.info('server respond error: =====>>>>>', error)
            });
    }

    _onPressAdsContact() {
        this.setState({ isOpenNewModal: true });
    }

    _outNewModal() {
        this.setState({ isOpenNewModal: false });
    }

    _onSaveInitialContact() {
        // local storage initialContact
        this.props.actions.onHelpedModalChange('initialContact', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialContact = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _onRefreshNewContact() {
        this.props.actions.onGroupContactFieldChange('contactID', null);
        this.props.actions.onGroupContactFieldChange('contactName', '');
        this.props.actions.onGroupContactFieldChange('contactPhone', '');
        this.props.actions.onGroupContactFieldChange('contactEmail', '');
        this.props.actions.onGroupContactFieldChange('contactType', 1);
        this.props.actions.onGroupContactFieldChange('contactSaleState', 2);
        this.props.actions.onGroupContactFieldChange('contactPhotos', []);
        this.props.actions.onGroupContactFieldChange('recordID', null);
        this.props.actions.onGroupContactFieldChange('listContactNhucau', []);
    }

    _onPressAdsPost() {
        this.props.actions.onPostAdsFieldChange('photos', []);
        this.props.actions.onPostAdsFieldChange('imageIndex', 0);
        this.props.actions.onPostAdsFieldChange('pickMode', 'new');
        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        this.props.actions.onPostAdsFieldChange('dienTich', null);
        this.props.actions.onPostAdsFieldChange('matTien', null);
        this.props.actions.onPostAdsFieldChange('namXayDung', null);
        this.props.actions.onPostAdsFieldChange('soPhongNguSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soPhongNguText', '');
        this.props.actions.onPostAdsFieldChange('soNhaTamSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soNhaTamText', '');
        this.props.actions.onPostAdsFieldChange('soTangSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soTangText', '');
        this.props.actions.onPostAdsFieldChange("place", {
            duAn: '',
            duAnFullName: '',
            placeId: "ChIJKQqAE44ANTERDbkQYkF-mAI",
            diaChiChiTiet: '',
            diaChi: '',
            diaChinh: {
                tinh: '',
                huyen: '',
                xa: '',
                duAn: '',
                duong: '',
                tinhKhongDau: '',
                huyenKhongDau: '',
                xaKhongDau: '',
                codeTinh: '',
                codeHuyen: '',
                codeXa: '',
                codeDuAn: '',
                codeDuong: ''
            },
            geo: { lat: '', lon: '' }
        });
        let { currentUser } = this.props.global;
        let lienHe = {
            tenLienLac: currentUser.fullName,
            showTenLienLac: true,
            phone: currentUser.phone,
            showPhone: true,
            email: currentUser.email,
            showEmail: true
        };
        this.props.actions.onPostAdsFieldChange("lienHe", lienHe);
        this.props.actions.onPostAdsFieldChange('dangBoi', {
            userID: undefined,
            email: null,
            phone: null,
            name: null
        });
        this.props.actions.onPostAdsFieldChange('huongNha', null);
        this.props.actions.onPostAdsFieldChange('duongTruocNha', null);
        this.props.actions.onPostAdsFieldChange('nhaMoiXay', null);
        this.props.actions.onPostAdsFieldChange('nhaLoGoc', null);
        this.props.actions.onPostAdsFieldChange('otoDoCua', null);
        this.props.actions.onPostAdsFieldChange('nhaKinhDoanhDuoc', null);
        this.props.actions.onPostAdsFieldChange('noiThatDayDu', null);
        this.props.actions.onPostAdsFieldChange('chinhChuDangTin', null);
        this.props.actions.onPostAdsFieldChange('gia', null);
        this.props.actions.onPostAdsFieldChange('donViTien', 0);
        this.props.actions.onPostAdsFieldChange('chiTiet', '');
        this.props.actions.onPostAdsFieldChange('maSo', null);
        this.props.actions.onPostAdsFieldChange('error', '');
        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', null);
        this.props.actions.onPostAdsFieldChange('selectedDuAn', null);
        this.props.actions.onPostAdsFieldChange('duAnList', null);
        this.props.actions.onPostAdsFieldChange('serviceOrder', undefined);
        this.props.actions.onPostAdsFieldChange('id', null);
        this.props.actions.onPostAdsFieldChange('banGap', false);
        this.props.actions.onPostAdsFieldChange('title', undefined);
        this.props.actions.onPostAdsFieldChange('groupID', undefined);

        this._onSaveInitialPost();
        Actions.NewPostAdsDetail({ owner: 'NewHomeAgent' });
    }    

    _onSaveInitialPost() {
        // local storage initialPost
        this.props.actions.onHelpedModalChange('initialPost', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialPost = true;
        this.props.actions.updateLocalHelped(helped);
    }

    // _onPressAdsCongViec() {
    //     // this.props.actions.onGroupFieldChange('eventList', []);
    //     this.props.actions.getAllCalendarEvent(
    //         {
    //             'userID': this.props.global.currentUser.userID,
    //             'startDateTimeFrom': this.props.event.startDateTimeFrom,
    //             'startDateTimeTo': this.props.event.startDateTimeTo
    //         }
    //         , (res) => {
    //             // log.info('server respond data: =====>>>>>', res)
    //         }
    //         , (error) => {
    //             log.info('server respond data: =====>>>>>', error)
    //         });
    //     Actions.CalendarEvent({ owner: 'NewHomeAgent', isOpenMoreCalendarModal: false, selectedEvent: null });
    // }

    _onPressAdsGroup() {
        // this.selectedIndex = 3;
        StatusBar.setBarStyle('default');
        this.props.actions.onGroupFieldChange('showImagePreview', false);
        //query collection san goi y theo dia chinh/du an 

        let payload = { userID: this.props.global.currentUser.userID }
        this.props.actions.suggestGroupCollection(payload, () => { });
        Actions.GroupMgmt2();
    }

    _renderSourceGroupText(collections, loaiTin) {
        let sourceText = loaiTin == 0 ? 'Nguồn hàng bán từ các sàn' : 'Nguồn hàng cho thuê từ các sàn';
        let isShowTitle = false;
        collections.forEach((collection) => {
            if (collection.data && collection.data.length > 0) {
                let filtered = collection.data.filter((e) => { return e.loaiTin == loaiTin })
                if (filtered.length > 0)
                    isShowTitle = true;
            }
        })
        if (isShowTitle) {
            return (
                <View style={{ height: 44, width: width, backgroundColor: '#fff' }}>
                    <View style={styles.sourceGroupView}>
                        <Text style={styles.textGuide}>{sourceText}</Text>
                    </View>
                    <FullLine style={{ marginBottom: 12 }} />
                </View>
            )
        } else return null;
    }

    _loadLastSearchFilter(loaiTin) {

        let region = {
            latitude: LATITUDE,
            longitude: LONGITUDE,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA
        };
        let viewport = apiUtils.getViewport(region);
        this.props.actions.onGroupSearchFieldChange("viewport", viewport);
        this.props.actions.onGroupSearchFieldChange("diaChinhViewport", viewport);
        this.props.actions.onGroupSearchFieldChange("center", {});

        let diaChinh = {
            fullName: gui.TAT_CA_KHU_VUC
        };

        this.props.actions.onGroupSearchFieldChange("diaChinh", diaChinh);

        this.props.actions.onGroupSearchFieldChange("circle", {});
        this.props.actions.onGroupCircleChange({});
        this.props.actions.onGroupSearchFieldChange("polygon", []);
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("loaiTin", loaiTin == 0 ? 'ban' : 'thue');
        let defaultBan = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onGroupSearchFieldChange("ban", defaultBan);
        this.props.actions.onGroupSearchFieldChange("thue", defaultThue);
        this.props.actions.onGroupSearchFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onGroupSearchFieldChange("radiusInKmSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("huongNha", 0);
        this.props.actions.onGroupSearchFieldChange("ngayDaDang", '');
        this.props.actions.onGroupSearchFieldChange("hasImage", true);
        this.props.actions.onGroupSearchFieldChange("excludeMoiGioi", false);
        this.props.actions.onGroupSearchFieldChange("isFakeGeo", undefined);
        // }
    }

    _onShowMoreAds(loaiTin) {
        this._loadLastSearchFilter(loaiTin);
        Actions.AllGroupFilterResult();
    }

    _renderLoadingView() {
        return (
            <View>
                {this._renderEachLoading()}
                {/*{this._renderEachLoading()}*/}
                {/*{this._renderEachLoading()}*/}
            </View>
        )
    }

    _renderEachLoading() {
        return (
            <View>
                <View style={[styles.viewLineLoader1, { marginTop: 20 }]}></View>
                <View style={[styles.viewLineLoader1, { marginTop: 5, height: 10, width: 68 }]}></View>
                <View style={styles.parentLoading}>
                    <View style={styles.mainChildLoading}>
                        <View style={[styles.viewLineLoader1, { marginTop: 0, marginLeft: 0, height: 113, width: 234 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 15, marginLeft: 0, height: 19, width: 180 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 11, marginLeft: 0, height: 15, width: 234 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 6, marginLeft: 0, height: 15, width: 234 }]}></View>
                    </View>
                    <View style={styles.mainChildLoading}>
                        <View style={[styles.viewLineLoader1, { marginTop: 0, marginLeft: 0, height: 113, width: 234 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 15, marginLeft: 0, height: 19, width: 180 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 11, marginLeft: 0, height: 15, width: 234 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 6, marginLeft: 0, height: 15, width: 234 }]}></View>
                    </View>
                </View>
            </View>
        )
    }

    _renderHeader() {
        let numberInbox = 0;

        if (this.state.listHomeInbox) {
            let allGroupInboxDS = this.state.listHomeInbox.filter((one) => {
                let valid = one.content != undefined && (!one.spamStatus || (one.spamStatus != 1 && one.spamStatus != 2));
                return valid && !!one.numOfUnreadMessage;
            }) || [];
            numberInbox = allGroupInboxDS.length;
        }
        return (
            <View>
                <TouchableOpacity style={styles.viewHeader}>
                    <TouchableOpacity style={styles.viewIconProfile}
                        onPress={this.onPressChat.bind(this)}
                    >
                        <FontAwesomeLight name="comment-dots" size={24} color={gui.mainColor} noAction={true} iconOnly={true} />
                        {numberInbox ?
                            <View style={styles.numberOfMessage2}>
                                <Text style={styles.numberInbox}>{numberInbox}</Text>
                            </View>
                            : null
                        }
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.viewHeaderContent}
                        onPress={this._onGroupSearchPress.bind(this)}
                        accessible={true} >
                        <View>
                            <View style={styles.touchMainSearch}>
                                <View style={styles.iconSearch}>
                                    <FontAwesomeLight name="search" size={15} color={gui.colorMainBlur} noAction={true} iconOnly={true} />
                                </View>
                                <View style={styles.viewInputSearch}
                                    onStartShouldSetResponder={(evt) => false}
                                    onMoveShouldSetResponder={(evt) => false}
                                    pointerEvents="none">
                                    <Text style={[styles.textSearch, { fontSize: 15, color: gui.colorMainBlur, marginLeft: 6 }]}>Tìm kiếm</Text>
                                </View>
                            </View>
                        </View>

                        {/*<Image style={{ height: 36, width: 36, borderBottomRightRadius: 5 }} source={betaSource} defaultSource={betaSource} />*/}
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.viewIconProfile}
                        onPress={this.onPressMyAlert.bind(this)}
                    >
                        <FontAwesomeLight name="bell" size={23} color={gui.mainColor} noAction={true} iconOnly={true} />
                        {this.props.me.pushMessage == 1 ?
                            (<View style={styles.notification}>
                            </View>)
                            : null
                        }
                    </TouchableOpacity>
                </TouchableOpacity>
                <FullLine />
            </View>
        )
    }

    onPressMyAlert() {
        Actions.MyAlert();
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_NOTIFICATION', { deviceID: deviceID, userID: userID });
    }

    onPressChat() {
        Actions.GroupInbox();
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_INBOX', { deviceID: deviceID, userID: userID });
    }

    _onContactPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.getAllContact(
                        { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
                        , (res) => {
                        }
                        , (error) => {
                            log.info('server respond error: =====>>>>>', error)
                        });
                    Actions.Contact({ owner: 'NewHomeAgent' });
                }
            });
        } else {
            this.props.actions.getAllContact(
                { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
                , (res) => {
                }
                , (error) => {
                    log.info('server respond error: =====>>>>>', error)
                });
            Actions.Contact({ owner: 'NewHomeAgent' });
        }
    }

    onPressProfile() {
        Actions.MyProfile()
    }

    _onGroupSearchPress() {
        // Actions.GroupSearch({ owner: 'NewHomeAgent' });

        if (!this.props.group.searchResult.listRelatedGroup || this.props.group.searchResult.listRelatedGroup.length == 0) {
            let userID = this.props.global.currentUser.userID || undefined;
            let token = this.props.global.currentUser.token || undefined;
            this.props.actions.getRelatedGroup({ userID: userID }, token, () => { });
        }

        Actions.MainAutoComplete({ owner: 'NewHomeAgent' });
        // Actions.ChatAutoComplete({ owner: 'NewHomeAgent' });

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_SEARCH', { deviceID: deviceID, userID: userID });
    }

    _renderToDoList() {
        if (this.props.global.loggedIn) {
            let data = this.state.eventList.filter((one) => {
                let valid = one.status != 2; //Done                
                return valid;
            }) || [];   

            // if (!this.props.global.help.initialEvent && data.length == 0) {
            //     return null;
            // }

            // log.info('_renderToDoList data to render', data);
            return (
                <View style={styles.toDoView}>
                    <View>
                        <View style={styles.toDoTitle}>

                            <Text style={[styles.textGuide]}>Công việc hôm nay</Text>
                            <TouchableHighlight
                                onPress={this._onCreateEvent.bind(this)}
                                underlayColor='transparent'
                                style={styles.touchAddTodo}
                            >
                                <Text style={[styles.themCongViecText, { color: gui.mainAgentColor }]}>+ Thêm công việc</Text>
                            </TouchableHighlight>
                        </View>
                        <FullLine />
                    </View>

                    <View style={styles.toDoContent}>
                        <FlatList
                            refreshControl={
                                <RefreshControl
                                    refreshing={false}
                                    onRefresh={this._onRefresh.bind(this)}
                                />
                            }
                            data={data}
                            showsVerticalScrollIndicator={false}
                            keyExtractor={(item, index) => "list" + index}
                            renderItem={(item) => this._renderRowToDo(item)}
                            removeClippedSubviews={false}
                            enableEmptySections
                        />
                    </View>
                    {this._renderViewAllToDo(data)}
                    <LineFacebook />
                </View>
            )
        }
    }

    _renderViewAllToDo(data) {
        if (data.length == 0) {
            return (
                <View style={styles.viewNoTodo}>
                    <Text style={styles.explainText}>Không có công việc ngày hôm nay</Text>
                </View>
            )
        }
        return (
            <TouchableOpacity style={styles.viewMoreTodo}
                onPress={this._onSeeAll.bind(this, null)}
                underlayColor='transparent'
            >
                <Text style={styles.themCongViecText}>Xem thêm</Text>
                <Ionicons name={"ios-arrow-round-forward-outline"}
                    color={gui.mainColor}
                    size={20}
                    style={{ marginLeft: 6, marginTop: 2 }} />
            </TouchableOpacity>
        )
    }

    _renderViewAllCollection(data, loaiTin) {
        if (!data || data[0].data.length == 0) {
            return null
        }
        return (
            <TouchableOpacity style={styles.viewMoreTodo}
                onPress={this._onShowMoreAds.bind(this, loaiTin)}
                underlayColor='transparent'
            >
                <Text style={styles.themCongViecText}>Xem tất cả</Text>
                <Ionicons name={"ios-arrow-round-forward-outline"}
                    color={gui.mainColor}
                    size={20}
                    style={{ marginLeft: 6, marginTop: 2 }} />
            </TouchableOpacity>
        )
    }

    _onSeeAll(data) {
        if (data)
            Actions.CalendarEvent({ owner: 'NewHomeAgent', isOpenMoreCalendarModal: true, selectedEvent: data });
        else
            Actions.CalendarEvent({ owner: 'NewHomeAgent', isOpenMoreCalendarModal: false, selectedEvent: null });

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_CALENDAR_EVENT_DETAIL', { deviceID: deviceID, userID: userID });
    }

    _onRefresh() { }

    _getLevelColor(level) {
        if (level == 0) {
            return 'rgba(255,94,91,1)';
        } else if (level == 1) {
            return 'rgba(120,188,97,1)';
        } else if (level == 2) {
            return 'rgba(82,97,115,0.2)';
        } else return 'rgba(82,97,115,0.2)';
    }

    _renderRowToDo(value, sectionID, rowID) {
        // log.info('data to render =====>>>>>', data)
        let data = value.item;
        let content = '';
        let button1 = '';
        let button2 = '';
        let source_contact = require('../../assets/image/home_guide_contact.png');
        let source_like_ads = require('../../assets/image/home_guide_save.png');
        let guide_source = data.dataType == 'sample-contact' ? source_contact : (data.dataType == 'sample-ads' ? source_like_ads : null);
        if (data.dataType) {
            content = DanhMuc.sampleEvent[data.dataType].content;
            button1 = DanhMuc.sampleEvent[data.dataType].button1;
            button2 = DanhMuc.sampleEvent[data.dataType].button2
        }

        let widthTodo = data.dataType ? width - 32 - 36 : width - 32 - 36 - 45
        return (
            <View style={{ flex: 1 }}>
                <TouchableOpacity onPress={data.dataType ? null : this._onSeeAll.bind(this, data)}>
                    <View style={styles.viewToDoRow}>

                        <TouchableOpacity style={[styles.dotView]}
                            onPress={this._onMarkEventIsDonePress.bind(this, data)}
                        ></TouchableOpacity>

                        <View style={{ width: widthTodo, height: 'auto' }}>
                            {guide_source ?
                                <Image
                                    source={guide_source}
                                    resizeMode={"cover"}
                                    style={styles.imageSample}
                                />
                                : null
                            }

                            <View style={{ width: widthTodo, height: 'auto', justifyContent: 'center' }}>
                                <Text style={styles.toDoTitleText} numberOfLines={2}>{data.title}</Text>
                            </View>

                            {content ?
                                <View style={{ width: widthTodo, height: 'auto', justifyContent: 'center', marginTop: 12 }}>
                                    <Text style={styles.toDoContentText}>{content}</Text>
                                </View>
                                : null}

                            {data.dataType
                                ? <View style={{ marginLeft: 8, flexDirection: 'row', width: widthTodo, height: 'auto', justifyContent: 'space-between', marginTop: 12 }}>
                                    {data.dataType == 'sample-contact' ?
                                        <TouchableOpacity onPress={this.onTimHieuThemContact.bind(this)} style={[styles.buttonView, { backgroundColor: 'rgba(235,235,235,1)', }]}>
                                            <Text style={[styles.buttonText, { color: 'rgba(35,35,35,1)' }]}>{button1}</Text>
                                        </TouchableOpacity>
                                        : <TouchableOpacity onPress={this.onTimHieuThemAds.bind(this)} style={[styles.buttonView, { backgroundColor: 'rgba(235,235,235,1)', }]}>
                                            <Text style={[styles.buttonText, { color: 'rgba(35,35,35,1)' }]}>{button1}</Text>
                                        </TouchableOpacity>
                                    }
                                    {data.dataType == 'sample-contact' ?
                                        <TouchableOpacity style={styles.buttonView}
                                            onPress={this._onPressAdsContact.bind(this)}
                                        >
                                            <Text style={styles.buttonText}>{button2}</Text>
                                        </TouchableOpacity>
                                        :
                                        <TouchableOpacity style={styles.buttonView}
                                            onPress={this._onPressAdsPost.bind(this)}
                                        >
                                            <Text style={styles.buttonText}>{button2}</Text>
                                        </TouchableOpacity>
                                    }
                                </View>
                                : null}
                        </View>

                        {!data.dataType ? <View style={styles.timeTodo}>
                            <Text style={styles.toDoDateText}>{utils.showChatTimeTodo(data.startDate)}</Text>
                        </View> : null}

                    </View>
                </TouchableOpacity>
                <FullLine style={{ marginLeft: 16, marginRight: 16 }} />
            </View>
        );
    }

    onTimHieuThemContact() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.getAllContact(
                        { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
                        , (res) => {
                        }
                        , (error) => {
                            log.info('server respond error: =====>>>>>', error)
                        });
                    Actions.Contact2({ owner: 'NewHomeAgent' });
                }
            });
        } else {
            this.props.actions.getAllContact(
                { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
                , (res) => {
                }
                , (error) => {
                    log.info('server respond error: =====>>>>>', error)
                });
            Actions.Contact2({ owner: 'NewHomeAgent' });
        }
    }

    onTimHieuThemAds() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    Actions.NewAgentPost();
                }
            });
        } else {
            Actions.NewAgentPost();
        }
    }

    _onMarkEventIsDonePress(data) {
        if (!data) {
            return;
        }
        let eventDto = {};
        eventDto.status = 2;// done
        eventDto.eventID = data.id;
        eventDto.title = data.title
        eventDto.userID = data.userID
        eventDto.personContact = data.personContact
        eventDto.adsID = data.adsID
        eventDto.startDate = data.startDate
        eventDto.endDate = data.endDate
        eventDto.alarms = data.alarms
        eventDto.recurrenceRule = data.recurrenceRule
        eventDto.level = data.level
        eventDto.allDay = data.allDay
        eventDto.eventIDInDevice = data.eventIDInDevice
        eventDto.eventType = data.eventType

        let token = this.props.global.currentUser.token;
        this.props.actions.saveCalendarEvent(eventDto, token)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);

                    setTimeout(() => {
                        // this.props.actions.onEventFieldChange('eventList', [])
                        let fromDate = new Date(moment(new Date()).subtract(7, 'days')).setHours(0, 0, 0, 0)
                        let toDate = new Date(moment(new Date())).setHours(23, 59, 59, 999)
                        this.props.actions.getAllCalendarEvent(
                            {
                                'userID': this.props.global.currentUser.userID,
                                'startDateTimeFrom': fromDate,
                                'startDateTimeTo': toDate
                            }
                            , (res) => {
                            }
                            , (error) => {
                                console.log('server respond data: =====>>>>>', error)
                            });

                    }, 200);
                }
            });
    }

    _onCreateEvent() {
        this.onLogEvent();

        Actions.MyTodoNotes({ owner: 'NewHomeAgent' });
        this._onRefreshNewEvent();

        this._onSaveInitialEvent();

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_HOME_ADD_CALENDAR_EVENT', { deviceID: deviceID, userID: userID });
    };

    onLogEvent() {
        let eventDto = {
            scene: "NewHomeAgent",
            parentScene: undefined,  //truyen owner neu co            
            componentType: "button",
            component: "Thêm công việc",
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onSaveInitialEvent() {
        // local storage initialEvent
        this.props.actions.onHelpedModalChange('initialEvent', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialEvent = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _onRefreshNewEvent() {

        this.props.actions.onGroupContactFieldChange('personContact', '');
        this.props.actions.onEventFieldChange('eventID', null);
        this.props.actions.onEventFieldChange('eventName', '');
        this.props.actions.onEventFieldChange('eventStartDate', moment(new Date()).toISOString());
        this.props.actions.onEventFieldChange('eventEndDate', moment(new Date()).toISOString());
        this.props.actions.onEventFieldChange('eventAllDay', false);
        this.props.actions.onEventFieldChange('eventRepeat', false);
        this.props.actions.onEventFieldChange('eventAlarm', true);
        this.props.actions.onEventFieldChange('eventStatus', 1);
        this.props.actions.onEventFieldChange('eventLevel', 1);//normal
        this.props.actions.onEventFieldChange('eventType', '');//normal
        this.props.actions.onEventFieldChange('eventAds', null)
        this.props.actions.onEventFieldChange('eventIDInDevice', null);
    }

    _renderHomeButton() {
        let textGuide = 'Công cụ';
        let imageVay = require('../../assets/image/group/lai_vay.png');
        let imageDinhGia = require('../../assets/image/group/dinh_gia.png');
        let defaultCover = require('../../assets/image/no_cover.jpg');
        return (
            <View style={styles.viewHomeButton}>
                <Text style={styles.textGuide}>{textGuide}</Text>
                <View style={styles.viewTabGuide}>
                    <TouchableOpacity style={styles.viewEachButton}
                        onPress={this._onLaiVayPress.bind(this)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageVay}
                            defaultSource={defaultCover}
                            style={styles.homeImageVay} />
                        <View style={styles.viewTextButton}>
                            <Text style={styles.textLaiVay}>Tính lãi vay</Text>
                            <Text style={styles.textMore}>trả góp</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButton, { marginLeft: 8 }]}
                        onPress={this._onDinhGiaPress.bind(this)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageDinhGia}
                            defaultSource={defaultCover}
                            style={styles.homeImageVay} />
                        <View style={styles.viewTextButton}>
                            <Text style={styles.textLaiVay}>Định giá nhà</Text>
                            <Text style={styles.textMore}>theo khu vực</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }
    _onLaiVayPress() {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('HOME_TIENVAY', { deviceID: deviceID, userID: userID });
        Actions.VayUocTinh3();
        //Actions.NewDetailContact();
        // Actions.ContactRespond();
        // Actions.ContactNhuCau();
    }

    _onDinhGiaPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction: this._doDinhGia.bind(this) });
        } else {
            this._doDinhGia();
        }
    }

    _doDinhGia() {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('HOME_DINHGIA', { deviceID: deviceID, userID: userID });
        Actions.DinhGiaOption();
    }

    _renderTextService() {
        let textInfoService = 'Dịch vụ Landber';
        return (
            <View style={styles.viewInfoService}>
                <Text style={styles.textGuide}>{textInfoService}</Text>
                <TouchableOpacity style={styles.touchTextAll}>
                    <Text style={styles.textAllService}>Tất cả</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _renderTextSource() {
        let textSource = 'Nguồn hàng của Landber';
        return (
            <View style={styles.viewInfoService}>
                <Text style={styles.textGuide}>{textSource}</Text>
                <TouchableOpacity style={styles.touchTextAll}>
                    <Text style={styles.textAllService}>Tất cả</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _renderListInbox() {
        if (this.props.inbox.loadingGroupInbox) {
            return (
                <View style={[styles.viewListInbox, { alignItems: 'center' }]}>
                    <GiftedSpinner />
                </View>)
        }
        else {
            let index = -1;
            let allGroupInboxDS = this.state.listHomeInbox.filter((one) => {
                let valid = one.content != undefined && (!one.spamStatus || (one.spamStatus != 1 && one.spamStatus != 2));
                if (valid) {
                    index++;
                }
                return valid && index < 8;
            }) || [];
            if (allGroupInboxDS.length == 0) return null;
            return (
                <View>
                    <View style={[styles.toDoTitle, { backgroundColor: '#fff', height: 32, alignItems: 'flex-end' }]}>

                        <Text style={[styles.textGuide]}>Chat</Text>

                    </View>
                    <View style={[styles.viewListInbox, { height: 72, alignItems: 'flex-start' }]}>
                        <ListView contentContainerStyle={styles.viewListInbox}
                            horizontal={true}
                            enableEmptySections={true}
                            showsHorizontalScrollIndicator={false}
                            showsVerticalScrollIndicator={false}
                            dataSource={ds_listInboxChat.cloneWithRows(allGroupInboxDS)}
                            renderRow={(rowData, sectionID, rowID) => this._renderRowInboxNoti(rowData, sectionID, rowID)} />
                        <LineFacebook />
                    </View>
                </View>
            )
        }
    }

    // _renderListService() {
    //     return (
    //         <View style={{ marginTop: 19, marginLeft: 18 }}>
    //             <ListView contentContainerStyle={styles.listService}
    //                 horizontal={true}
    //                 enableEmptySections={true}
    //                 showsHorizontalScrollIndicator={false}
    //                 showsVerticalScrollIndicator={false}
    //                 dataSource={ds_listService.cloneWithRows(this.state.dataService)}
    //                 renderRow={this._renderRowService.bind(this)} />
    //         </View>
    //     );
    // }

    _renderRowInboxNoti(data, sectionID, rowID) {
        let marginLeftInbox = data && rowID && rowID == 0 ? 16 : 8;
        let currentUser = this.props.global.currentUser;
        let imgUrl = "";
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let nameDefault = "";
        let nameColor;
        if (!data.groupType || data.groupType == 1) {// ca nhan
            // log.info ('loggin _renderRowInbox, data.partners: ', data.partners)
            data.partners && data.partners.forEach((partner) => {
                if (partner.userID != currentUser.userID) {
                    imgUrl = partner.avatar;
                    nameDefault = utils.geDefaultName(partner.fullName);
                }
            })
        } else { //2: san moi gioi
            imgUrl = data.groupImage;
            nameDefault = utils.geDefaultName(data.groupName);
            nameColor = utils.getNameColor(nameDefault);
        }
        let imageEachInbox = imgUrl ? { uri: imgUrl } : defaultAvatar;
        let numberInbox = data.numOfUnreadMessage;
        // if (data.allMsg1Page) {
        //     let allMsg1Page = data.allMsg1Page.filter((one) => {
        //         return one.fromUserID != currentUser.userID;
        //     });
        //     numberInbox = allMsg1Page.length;
        // }
        return (

            <TouchableOpacity style={[styles.viewEachInboxChild, { marginLeft: marginLeftInbox }]}
                onPress={() => this._onRowInboxClick(data)}>
                {imgUrl && imgUrl.length > 0 ? (<Image style={styles.myAvatarInbox}
                    source={imageEachInbox}
                    defaultSource={defaultCover}
                />) : (
                        <View style={[styles.dotViewDefault, { backgroundColor: '#eeedf0' }]}>
                            <Text style={[styles.textSort, { color: nameColor, fontSize: 17, fontWeight: '600' }]}>{nameDefault}</Text>
                        </View>
                    )
                }
                {numberInbox ?
                    <View style={styles.numberOfMessage}>
                        <Text style={styles.numberInbox}>{numberInbox}</Text>
                    </View>
                    : null
                }
                {!!data && data.groupType == 2 ? this._renderGroupIcon() : null}
            </TouchableOpacity>

        );
    }

    _renderGroupIcon() {
        return (
            <View style={styles.iconGroup}>
                <View style={styles.detailIconGroup}>
                    <FontAwesomeLight name="users" size={8} color={'#fff'} noAction={true} iconOnly={true} />
                </View>
            </View>
        )
    }

    _onRowInboxClick(rowData) {
        let chatGroupDto = {
            chatGroupID: rowData.chatGroupID,
            chatGroupName: rowData.groupName,
            chatGroupImage: rowData.groupImage,
            chatGroupType: rowData.groupType
        }

        let currentUser = this.props.global.currentUser;
        let chatTitle = "";
        if (!rowData.groupType || rowData.groupType == 1) {// ca nhan
            rowData.partners && rowData.partners.forEach((partner) => {
                if (partner.userID != currentUser.userID)
                    chatTitle = partner.fullName;
            })
        } else { //2: san moi gioi
            chatTitle = rowData.groupName ? rowData.groupName : "";
        }
        this.props.actions.onChatFieldChange('currentGroupChatPageNo', 1);
        let dto = { userID: currentUser.userID, limit: this.props.chat.chatMessageLimit, pageNo: 1, chatGroupID: chatGroupDto.chatGroupID };

        this.props.actions.startGroupChat(currentUser, dto,
            chatGroupDto).then((e) => {
                Actions.GroupChat({ chatTitle: chatTitle, isSpam: false, onGroupInbox: (value) => this._loadGroupInbox(value) });
            });
    }

    _loadGroupInbox(userID) {
        const dto = {
            userID: userID,
            limit: 25,
            pageNo: 1,
            phamViChat: 1 //1: ca nhan, 2: group, 0 : all
        };
        this.props.actions.onRefreshHomeInbox(dto);
    }

    _renderRowService(data) {
        let imgUrl = data.imgService;
        let imageService = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imgUrl) {
            imageService = defaultCover;
        }
        return (
            <View style={styles.viewRowService}>
                <Image
                    resizeMode={"cover"}
                    source={imageService}
                    defaultSource={defaultCover}
                    style={styles.imageService} />
            </View>
        )
    }

    // _renderListSource() {
    //     return (
    //         <View style={{ marginTop: 16 }}>
    //             <ListView contentContainerStyle={styles.listSource}
    //                 horizontal={true}
    //                 enableEmptySections={true}
    //                 showsHorizontalScrollIndicator={false}
    //                 showsVerticalScrollIndicator={false}
    //                 dataSource={ds_listSourceAds.cloneWithRows(this.state.dataSourceAds)}
    //                 renderRow={this._renderRowAdsByGroup.bind(this)} />
    //         </View>
    //     )
    // }

    existedInArray(item, array) {
        let result = false;
        array.forEach((e) => {
            if (item.title1.slice(0, item.title1.length - 2) == e.title1.slice(0, e.title1.length - 2))
                result = true;
        })
        return result;
    }

    renderCollections(collections, loaiTin) {
        let adsLikes = [];
        let userID = null;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            adsLikes = currentUser && currentUser.adsLikes;
            userID = currentUser && currentUser.userID;
        }

        if (this.props.search.loadingAgentHomeData) {
            return this._renderLoadingView();
        }

        //merge tin ban va thue trong 1 group
        let mergeCollections = [];

        collections.forEach((e) => {
            if (e.query.loaiTin == loaiTin) {
                let mergeItem = {}; Object.assign(mergeItem, e);
                mergeCollections.push(mergeItem)
            }
            // if (e.query.loaiTin == 1) {
            //     let updateCollections = mergeCollections.filter((f) => { return f.title1 == e.title1 });
            //     let updateItem = updateCollections[0];
            //     updateItem.data = [...new Set([...updateItem.data, ...e.data])];

            //     let newMerge = mergeCollections.filter((f) => { return f.title1 != e.title1 })
            //     mergeCollections = [updateItem, ...newMerge];
            // }
        })

        //sort by newest
        mergeCollections.forEach((e) => {
            e.data.sort((a, b) => b.ngayDangTin - a.ngayDangTin)
        });
        // log.info('mergeCollections ***************', mergeCollections)
        return mergeCollections.map(e => {
            return (
                <View key={e.title1}>
                    <HomeAgentCollection key={e.title1} collectionData={e}
                        onSeeMoreCollectionChange={this.props.actions.onSeeMoreCollectionChange}
                        changeLoadingExtSearchResult={this.props.actions.changeLoadingExtSearchResult}
                        searchFromHome={this.props.actions.searchFromHome}
                        onResetSearch={() => this.onResetSearch()}
                        adsLikes={adsLikes} loggedIn={this.props.global.loggedIn}
                        likeAds={this.props.actions.likeAds}
                        unlikeAds={this.props.actions.unlikeAds} userID={userID}
                        updateLikeAdsProcessing={this._updateLikeAdsProcessing.bind(this)}
                        uploadingLikedAds={this.props.search.uploadingLikedAds}
                        maxAdsInMapView={this.props.global.setting.maxAdsInMapView} />
                    <FullLine style={{ marginLeft: 16, marginRight: 16 }} />
                    {this._renderViewAllCollection(mergeCollections, loaiTin)}
                    <LineFacebook />
                </View>)
        });
    }

    _updateLikeAdsProcessing(likeAdsMessage) {
        this._updateMessageProcessing(likeAdsMessage, '#166CA5', '#fff');
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    _renderMessageItem() {
        let textValue = this.state.textMessage;
        if (textValue == '' || this.state.msgType == '') {
            return null;
        }
        return (
            <MMessage mainStyle={{ top: 0 }}
                hideStatus={this.state.msgType == 'fadeInDown'}
                animation={this.state.msgType}
                duration={500}
                onAnimationEnd={this._onAnimationEnd.bind(this)}
                textValue={textValue}
                bgColor={this.state.msgBgColor}
                textColor={this.state.msgTextColor} />
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => { this.setState({ textMessage: '', msgType: '' }) }, 2000);
        }
    }

    onResetSearch() {
        this.props.actions.onResetAdsExtList();
    }

    _onMyAvatarPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                }
            });
        } else {
            let currentUser = this.props.global.currentUser;
            this.props.actions.profile(currentUser.userID, currentUser.token).then(
                (res) => {
                    if (res.success) {
                        Actions.Profile();
                    } else {
                        Alert.alert('Thông báo', 'Tải thông tin cá nhân không thành công.');
                    }
                }
            );
        }
    }

    _onPressRowSource() {
        log.info('=========> _onPressRowSource');
    }

    _onTabSanChange(value) {
        this.setState({
            tabType: value
        });
    }
    onChangeText(value) {
        this.setState({
            value: value
        })
    }

    _onSubmitSearch() {
        Keyboard.dismiss();
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeader: {
        width: width,
        marginTop: gui.marginTopAgent, //8
        height: 48,
        backgroundColor: '#fff',
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 1
    },
    viewHeaderContent: {
        // width: width - 99,
        height: 36,
        flex: 1,
        backgroundColor: gui.groupBackground,
        borderRadius: 5,
        flexDirection: 'row',
        alignItems: 'center',
        // marginRight: 8
    },
    viewIconProfile: {
        height: 30,
        width: 46,
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchMainSearch: {
        // width: width - 137,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    iconSearch: {
        width: 30,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginLeft: 15
    },
    viewInputSearch: {
        // width: width - 98,
        // flex: 1,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        //backgroundColor:'#fff',
        // width: width - 94,
        flex: 1,
        height: 30,
        paddingLeft: 6,
        color: gui.mainTextColor
    },
    viewTabSelect: {
        height: 39,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row',
        marginTop: 17,
        marginBottom: 4
    },
    viewHomeContent: {
        backgroundColor: '#fff',
        height: height - 116,
        width: width
    },
    viewCalendarContent: {
        backgroundColor: 'skyblue',
        height: height - 190,
        width: width
    },
    viewAdsSourceContent: {
        backgroundColor: 'yellow',
        height: height - 190,
        width: width
    },
    viewHomeButton: {
        width: width,
        height: 120,
        paddingLeft: 16,
        paddingRight: 16,
        paddingTop: 16,
        backgroundColor: gui.groupBackground
    },
    textGuide: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: 'rgba(35,35,35,1)',
        fontSize: 17
    },
    viewTabGuide: {
        width: width - 32,
        height: 56,
        flexDirection: 'row',
        marginTop: 12
    },
    viewEachButton: {
        width: (width - 40) / 2,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: gui.groupBackground,
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.15,
        shadowRadius: 2,
    },
    homeImageVay: {
        height: 26,
        width: 26
    },
    viewTextButton: {
        marginLeft: 19
    },
    textLaiVay: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    textMore: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    viewInfoService: {
        height: 32,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        marginTop: 24,
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        flexDirection: 'row'
    },
    textAllService: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.colorMainBlur
    },
    touchTextAll: {
        position: 'absolute',
        right: 0
    },
    listService: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    listSource: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    listInboxNoti: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        flex: 1
    },
    viewRowService: {
        height: 105,
        width: 200,
        marginRight: 8
    },
    imageService: {
        height: 105,
        width: 200
    },
    viewRowSourceAds: {
        height: 226,
        width: 234,
        marginLeft: 16,
        borderWidth: 1,
        borderColor: gui.groupBackground,
    },
    imgItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 232,
        height: 113,
        alignSelf: 'auto'
    },
    linearGradientMain: {
        width: 234,
        height: 113,
        marginTop: 0,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewIconsSource: {
        height: 21,
        width: 234, // how responsive on each device
        position: 'absolute',
        top: 11,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-end'
    },
    iconLogo: {
        height: 19, // source not square shape
        width: 16
    },
    viewLogo: {
        position: 'absolute',
        left: 16
    },
    viewDeleteIcon: {
        position: 'absolute',
        right: 13
    },
    iconDelete: {
        height: 14,
        width: 14,
        marginBottom: 2
    },
    iconHeart: {
        height: 17,
        width: 18
    },
    viewHeartIcon: {
        position: 'absolute',
        right: 42
    },
    viewPriceSource: {
        position: 'absolute',
        left: 8,
        bottom: 4
    },
    textPrice: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: '#fff'
    },
    textNote: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        textAlign: 'justify',
        color: gui.colorMainBlur
    },
    viewInfoSource: {
        height: 40,
        width: 234,
        paddingLeft: 9,
        paddingRight: 9,
        marginTop: 9
    },
    textInfo: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    viewDetailPost: {
        height: 16,
        width: 234 - 22,
        marginLeft: 11,
        marginRight: 11,
        marginTop: 15,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 8
    },
    viewAreaValue: {
        height: 16,
        width: (234 - 22) / 2,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewAddressRow: {
        height: 16,
        width: 234 - 19,
        marginLeft: 9,
        marginRight: 9,
        marginTop: 7
    },
    viewListInbox: {
        height: 64,
        width: gui.screenWidth,
        backgroundColor: '#fff',
        justifyContent: 'center'
    },
    viewMyAvatar: {
        width: 64,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewMyAvatarInbox: {
        width: 63,
        height: 48,
        justifyContent: 'center',
        alignItems: 'center',
        borderRightWidth: 1,
        borderColor: '#dcdcdc'
    },
    myAvatarInbox: {
        height: 48,
        width: 48,
        borderRadius: 24
    },
    dotViewDefault: {
        height: 48,
        width: 48,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textSort: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewEachInboxChild: {
        width: 48,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 8
    },
    numberOfMessage: {
        height: 16,
        width: 16,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 8,
        right: 0,
        backgroundColor: '#ff0000'
    },
    numberOfMessage2: {
        height: 16,
        width: 16,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 0,
        // left: 0,
        right: 12,
        backgroundColor: '#ff0000'
    },
    iconGroup: {
        height: 20,
        width: 20,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        bottom: 8,
        right: 0,
        backgroundColor: '#fff'
    },
    detailIconGroup: {
        height: 18,
        width: 18,
        borderRadius: 9,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    numberInbox: {
        fontSize: 8,
        color: '#fff',
        backgroundColor: 'transparent'
    },
    toDoView: {
        width: width,
        height: 'auto',
        justifyContent: 'center',
        alignItems: 'center'
    },
    toDoTitle: {
        width: width,
        height: 44,// 63
        paddingLeft: 12,
        paddingRight: 12,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    toDoContent: {
        width: width,
        height: 'auto',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    themCongViecText: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainAgentColor
    },
    explainText: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainAgentColor
    },
    toDoTitleText: {
        textAlign: 'left',
        marginLeft: 8,
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: 'rgba(35,35,35,1)'
    },
    toDoContentText: {
        width: width - 32 - 36,
        textAlign: 'left',
        marginLeft: 8,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: 'rgba(35,35,35,1)', //'#526173'
    },
    buttonText: {
        // marginLeft: 8,
        // marginTop: 9,
        alignSelf: 'center',
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        // backgroundColor: 'transparent',
        color: '#fff'
    },
    toDoDateText: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '400',
        color: gui.textPostAds
    },
    timeTodo: {
        width: 45,
        height: 'auto',
        alignItems: 'flex-end',
        position: 'absolute',
        right: 0
    },
    viewToDoRow: {
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        marginTop: 16,
        marginBottom: 16,
        width: width - 32,
        // paddingLeft: 16,
        // paddingRight: 16,
        height: 'auto',
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    dotView: {
        backgroundColor: 'transparent',
        // marginRight: 8,
        // marginTop: 6,
        width: 24,
        borderRadius: 4,
        borderWidth: 2,
        borderColor: 'rgba(56,151,241,1)',
        height: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonView: {
        backgroundColor: 'rgba(56,151,241,1)',
        width: (width - 68 - 12) / 2,
        borderRadius: 4,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewLineLoader1: {
        height: 20,
        width: width * 3 / 4,
        backgroundColor: 'rgba(234, 235, 237, 0.75)',
        marginLeft: 15
    },
    mainChildLoading: {
        height: 210,
        width: 234,
        marginLeft: 19
    },
    parentLoading: {
        width: width,
        height: 210,
        marginTop: 19,
        flexDirection: 'row'
    },
    viewMoreTodo: {
        height: 44,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewNoTodo: {
        height: 44,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    touchAddTodo: {
        position: 'absolute',
        right: 12
    },
    sourceGroupView: {
        height: 44,
        width: width - 88,
        paddingLeft: 8,
        justifyContent: 'center',
        backgroundColor: '#fff'
    },
    touchXemThem: {
        height: 44,
        width: 88,
        paddingRight: 8,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewMoreText: {
        height: 44,
        width: width,
        flexDirection: 'row',
        alignItems: 'center'
    },
    sourceGroupText: {
        color: gui.colorMainBlur,
        fontSize: 12,
        fontFamily: gui.fontFamily
    },
    iconContact: {
        height: 42,
        width: 42,
        justifyContent: 'center',
        alignItems: 'center',
        borderLeftWidth: 1,
        borderColor: '#dcdcdc'
    },
    viewAdsHome: {
        height: 'auto',
        width: width,
        backgroundColor: gui.groupBackground,
        paddingLeft: 16,
        paddingRight: 16,
        paddingBottom: 4
    },
    viewAdsContent: {
        height: 'auto',
        width: width - 32,
        marginTop: 10,
        // paddingBottom: 13,
        paddingTop: 13,
        backgroundColor: '#fff',
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.1,
        shadowRadius: 2
    },
    viewTitleAds: {
        height: 18,
        width: width - 32,
        flexDirection: 'row'
    },
    viewMoreAds: {
        marginTop: 13,
        marginBottom: 17,
        width: width - 32,
        paddingLeft: 10,
        paddingRight: 10
    },
    viewIconButton: {
        height: 60,
        width: width - 32,
        marginBottom: 23,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    titleAdsContent: {
        height: 18,
        width: width - 92,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewCloseButton: {
        height: 18,
        width: 30,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 13
    },
    textTitleAds: {
        color: '#2C394C',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    imageAds1: {
        height: 60,
        width: 54
    },
    imageAds2: {
        height: 62,
        width: 87
    },
    imageAds3: {
        height: 65,
        width: 74
    },
    touchButtonAds: {
        marginLeft: 67,
        paddingVertical: 7,
        paddingHorizontal: 19,
        borderWidth: 1,
        borderColor: gui.mainAgentColor,
        borderRadius: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textButtonAds: {
        color: gui.mainAgentColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewAllAds: {
        height: 'auto',
        width: width,
        backgroundColor: gui.groupBackground
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        // width: width - 28,
        // marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center',
        // marginBottom: 50
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    listContent: {
        flex: 1
    },
    viewListMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        //marginTop: 6, //8,
        backgroundColor: gui.groupBackground
    },
    viewRowTopContent: {
        paddingTop: 16,
        paddingBottom: 12,
        paddingLeft: 8,
        paddingRight: 8,
        backgroundColor: '#fff',
        width: width,
        height: 'auto'
    },
    viewMainUser: {
        height: 26, // 24
        width: width - 16, // 48
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    mainUserAvatar: {
        // height: 24,
        // width: 24,
        // borderRadius: 12
        height: 36,
        width: 36,
        borderRadius: 18
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        marginLeft: 0
    },
    viewIconBubble: {
        position: 'absolute',
        right: 0,
        top: -12,
        width: 40,
        height: 30,
        alignItems: 'flex-end'
    },
    viewUserLogo: {
        position: 'absolute',
        left: 17,
        bottom: 17,
        height: 24,
        // width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 16, //23
        bottom: 13,
        height: 32,
        width: width - 46,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent'
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    imageContentRow: {
        width: width,
        height: gui.ADS_IMAGE_RATIO * width,
        backgroundColor: '#fff'
    },
    viewBorderTopAds: {
        height: 9,
        width: width,
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewBorderTopImage: {
        height: 8,
        width: width - 16,
        borderWidth: 1,
        borderBottomWidth: 0,
        borderColor: 'rgba(211,211,211,0.5)'
    },
    lineBorderVertical: {
        width: width - 16,
        height: 8
    },
    imgItem2: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 16,
        height: imageGroup,
        alignSelf: 'auto',
        marginLeft: 8,
        marginRight: 8
    },
    linearGradientMain2: {
        marginTop: 0,
        height: gui.ADS_IMAGE_RATIO * width,
        width: width - 16,
        marginLeft: 0,
        marginRight: 0,
        backgroundColor: "transparent"
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: '#fff',
        fontWeight: '500'
    },
    viewAdsBorderCover: {
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewBorderCover: {
        width: width - 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        height: 'auto',
        borderWidth: 1,
        borderColor: 'rgba(211,211,211,0.5)',
        borderTopWidth: 0,
        paddingBottom: 8
    },
    viewDetailPostComment: {
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        height: 'auto'
    },
    viewTopDetail: {
        width: width - 18,
        height: 'auto',
        backgroundColor: '#fff',
        alignItems: 'center',
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 18,
        paddingLeft: 8, //16
        paddingRight: 8,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
    },
    textMainPost: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    lineDangNhap: {
        backgroundColor: 'rgba(211,211,211,0.5)',
        height: 1,
        width: width - 16
        // marginLeft: 8,
        // marginRight: 8
    },
    viewContentSource: {
        // height: 36,
        marginTop: 4,
        marginBottom: 4,
        width: width - 18, // 12?
        paddingLeft: 8,
        paddingRight: 8,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTextAddress: {
        // height: 28,
        width: width - 18,
        paddingLeft: 8,
        paddingRight: 8,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 2
    },
    textTimePost: {
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewLikeComment: {
        height: 39,
        width: width,
        // paddingLeft: 8,
        paddingRight: 8,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 3,
        bottom: 32
    },
    viewLastComment: {
        height: 61,
        width: width,
        alignItems: 'center'
    },
    viewRowComment: {
        height: 60,
        width: width,
        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 8,
        flexDirection: 'row',
        marginBottom: 4
    },
    viewContentComment2: {
        justifyContent: 'center',
        marginLeft: 8,
        backgroundColor: '#f0f1f3',
        width: width - 16 - 24 - 8 - 12 - 18,
        height: 48,
        borderRadius: 12,
        paddingHorizontal: 8,
        paddingVertical: 8
    },
    viewContentComment: {
        justifyContent: 'center',
        marginLeft: 8,
        backgroundColor: '#f0f1f3',
        width: width - 16 - 24 - 8 - 12,
        height: 48,
        borderRadius: 12,
        paddingHorizontal: 8,
        paddingVertical: 8
    },
    nameUserComment: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
    },
    textContentChat: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
    },
    scrollView: {
        flexGrow: 1,
        // position: 'absolute',
        height: height - 44,
        top: 44 + gui.marginTopAgent
    },
    pagingText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#fff',
        marginRight: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingIcon: {
        borderRadius: 0,
        marginLeft: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingView: {
        flexDirection: 'row',
        backgroundColor: '#5b5c61',
        borderRadius: 5,
        opacity: 0.75
    },
    viewModalStyle2: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    resultContainer: {
        position: 'absolute',
        top: height / 2 - 20,
        left: width / 2 - 20,
        width: 40,
        height: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewDetailPost3: {
        height: 'auto',
        width: width - 32 - 16,
        justifyContent: 'center',
        backgroundColor: '#fff',
        paddingLeft: 8
    },
    viewTieuDe: {
        flexDirection: 'row',
        width: width - 32 - 16,
        alignItems: 'center',
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
        marginLeft: 9
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textPostAds,
    },
    viewTextTieuDe: {
        height: 24,
        width: width - 62 - 32 - 16,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textMainUser2: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        fontWeight: 'normal',
        marginLeft: 0, //8
    },
    viewRowPostNormalWto: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff'
    },
    viewRowPostWto: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingRight: 8,
        paddingTop: 6,
        paddingBottom: 3,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        width: width - 16,
        height: 'auto',
        //marginTop: 8,
        marginBottom: 8,
        marginLeft: 8,
        marginRight: 8
    },
    viewAdsWto: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff',
    },
    modalButton1: {
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
        alignItems: 'center',
        // paddingLeft: 12
    },
    modalButton2: {
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        alignItems: 'center',
        // paddingLeft: 12
    },
    viewModalDetail: {
        justifyContent: 'flex-start',
        height: 'auto',
        backgroundColor: 'transparent',
        alignItems: 'center',
    },
    notification: {
        position: 'absolute',
        backgroundColor: '#ff0000',
        top: 2,
        right: 6,
        alignSelf: 'auto',
        width: 6,
        height: 6,
        borderRadius: 3,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewGiaFmt: {
        width: width - 18,
        height: 28,
        paddingLeft: 8,
        justifyContent: 'flex-end',
    },
    textPriceFmt: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.textPostAds
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        width: width - 32 - 16,
        height: 20,
        backgroundColor: '#fff'
    },
    viewListNews: {
        flex: 1
    },
    viewRowNews: {
        height: 80,
        width: width - 24,
        marginTop: 16,
        marginBottom: 4,
        marginLeft: 12,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    newsCover: {
        height: 80,
        width: 104
    },
    itemsContent: {
        height: 80,
        width: width - 136 + 8
    },
    viewTextTitle: {
        height: 60,
        width: width - 136 + 8,
        paddingLeft: 12
    },
    textTitle: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    viewTimeStamp: {
        flexDirection: 'row',
        height: 20,
        width: width - 136 + 8,
        paddingLeft: 12,
        alignItems: 'flex-end',
        justifyContent: 'space-between'
    },
    sourceNews: {
        flexDirection: 'row',
        height: 20,
        width: 100,
        alignItems: 'flex-end'
    },
    textTime: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        color: gui.textShare,
        fontWeight: '300',
        marginLeft: 5
    },
    imageSample: {
        width: width - 32 - 36,
        height: 120,
        borderRadius: 5,
        marginBottom: 16,
        marginLeft: 8
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NewHomeAgent);