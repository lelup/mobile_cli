import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';

export default class TabHome extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';

        return (
            <View style={styles.wrapper}>
                <TouchableOpacity
                    onPress={() => this.props.onPress(this.props.name)}>
                    <ScalableText style={styles[myStyle]} >
                        {this.props.children}
                    </ScalableText>
                </TouchableOpacity>
                <View style = {[styles.lineunder, {borderBottomWidth:selected ? 4:0 }]}  />
            </View>
        );
    }
}


const styles = StyleSheet.create({
    lineunder: {
        flexGrow: 1,
        borderBottomColor: gui.mainAgentColor,
        borderStyle: "solid",
        height: 4,
        marginLeft: 5,
        marginRight: 5
    },

    wrapper: {
        flexGrow: 1,
        flexDirection: 'column',
        justifyContent: 'center'

    },
    buttonText: {
        flexGrow: 1,
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 10,
        color: gui.colorMainBlur,
        fontWeight : 'normal'
    },
    buttonTextSelected: {
        flexGrow: 1,
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 10,
        color: gui.mainAgentColor,
        fontWeight : 'normal'
    }
});