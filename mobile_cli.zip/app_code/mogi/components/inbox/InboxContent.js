import React, {Component} from 'react';

import moment from 'moment';

import {
    StyleSheet,
    Text,
    View,
    Image, ListView,
    TouchableOpacity,
    TextInput, Alert, ScrollView, TouchableHighlight

} from 'react-native';

import gui from '../../lib/gui';
import log from '../../lib/logUtil';
import {Actions} from 'react-native-router-flux';
import utils from '../../lib/utils';
var {width,height} = utils.getDimensions();
import ScalableText from 'react-native-text';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';

import { SwipeListView } from 'react-native-swipe-list-view';
import GiftedSpinner from 'react-native-gifted-spinner';

let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
let defaultCover =  require('../../assets/image/no_cover.jpg');
let dataRow;

const actions = [
  globalActions,
  authActions,
  chatActions,
  inboxActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class InboxContent extends React.Component {
  constructor(props) {
    super(props);
    this.state= {
        isloadingChat: false,
        isloadingPressRow: true
    };
  }

  coming() {
    log.info('InboxContent - Comming soon ...');
  }

  onDelete(row) {
     // dataRow = row;
     //  this.setState({
     //      isloadingChat: true
     //  });
    Alert.alert('Thông báo', 'Bạn có muốn xóa đoạn hội thoại này không?',
        [ {text: 'Hủy' , onPress: () => log.info('Cancel Pressed!')},
          {text: 'Đồng ý', onPress: () => this.doDelete(row)}
        ]);
  }

  doDelete(row){
       dataRow = row;
      this.setState({
          isloadingChat: true
      });
    let {relatedToAds, partner} = row;
    this.props.actions.leaveConversation(this.props.global.currentUser.userID,
        partner,
        relatedToAds).then((e) => {
      if (e.status!=0){
        Alert.alert("Thông báo", e.error);
      } else {
        this._swipeListView.safeCloseOpenRow();
      }

    });
  }

  onRowClick(row) {
    this.props.pressRowChat(row);
    let {relatedToAds, partner} = row;
    this.props.actions.startChat(this.props.global.currentUser,
        partner,
        relatedToAds). then ((e) => {
            Actions.Chat();
             this.props.endPressRow(row);
    });

  }

  renderRow(row, sectionID, rowID) {
    // let avatar = row.partner.avatar ? {uri: row.partner.avatar} : defaultAvatar;
    let relatedToAds = row.relatedToAds;
    const {giaFmt, loaiNhaDatFmt, diaChinhFullName} = relatedToAds;
    let adsInboxTitle = `${giaFmt} - ${loaiNhaDatFmt} - ${diaChinhFullName}`;

    let dt = moment(row.date).format("DD/MM   HH:mm");
    dt = dt.replace("/", " tháng ");

    let fontWeight = row.numOfUnreadMessage >0 ? '600' : '400';

    return (
        <TouchableHighlight onPress={() => this.onRowClick(row)}
                          style={styles.rowFront}
                          underlayColor="rgba(30,30,30,0.8)"
        >
          <View style={[styles.rowContainer, {marginLeft: 0, paddingLeft:8}]}>
            <AvatarItem avatar={row.partner.avatar} numOfUnreadMessage={row.numOfUnreadMessage}/>
            <View style={styles.rightContainer}>
              <View style={styles.nameAndDateTime}>
                <Text style={styles.name}>{row.partner.fullName}</Text>
                <Text style={styles.dateTime}>{dt}</Text>
              </View>

              <View style={styles.rightRow2}>
                <View style={styles.titleAndLastMsg}>
                  <Text numberOfLines={1} style={styles.title}>{relatedToAds ? adsInboxTitle:"<Không tựa đề>"}</Text>
                  <Text style={[styles.content, {fontWeight: fontWeight}]} numberOfLines={1}>{row.content||"Nội dung tin nhắn cuối cùng"}</Text>
                </View>
                <Image
                    resizeMode = {"cover"}
                    source={{uri: relatedToAds.cover}}
                    defaultSource={defaultCover}
                    style={styles.adsCover}/>
              </View>
            </View>
          </View>
        </TouchableHighlight>
    );
  }

  render() {
    log.info("InboxContent.render");
    return (
          <ScrollView style={styles.wrapper}>
            <SwipeListView
                ref={ref => this._swipeListView = ref}
                enableEmptySections={true}
                dataSource={this.props.inbox.allInboxDS}
                renderRow={this.renderRow.bind(this)}
                style={styles.listView}
                renderHiddenRow={ data => (
                <View style={styles.rowBack}>
                  <TouchableOpacity onPress = { () => this.onDelete(data)}
                                    style = {styles.viewDeleteInbox}
                  >
                      { JSON.stringify(data) == JSON.stringify(dataRow) ? <View><GiftedSpinner color="#fff"/></View> :
                        <Text style={styles.saveText}>Xóa</Text>
                      }
                  </TouchableOpacity>
                  {/*<TouchableOpacity onPress = { () => this.onDelete(data)} >
                    <View style={styles.viewSaveInbox}>
                      <Text style={styles.saveText}>Lưu</Text>
                    </View>
                  </TouchableOpacity>
                  */}
                </View>
            )}
                disableRightSwipe={true}
                rightOpenValue={-65}
            />
              {this._renderFooterInbox()}
          </ScrollView>
    );
  }

    _renderFooterInbox(){
      return(
          <View style={styles.viewFooter}>

              {this.props.inbox.allInboxDS && this.props.inbox.allInboxDS.getRowCount() > 0 ?
                  <View>
                    <Text style={styles.textFooter}>Tất cả đã được hiển thị</Text>
                    <Text style={[styles.textFooter,{fontWeight: '400', fontSize: 13, marginTop: 0}]}>Vuốt sang trái để xoá tin chat</Text>
                  </View>
                  :
                  <Text style={styles.textFooter}>Bạn chưa có tin chat nào</Text>
              }
          </View>
      );
    }
}

class AvatarItem extends React.Component{
  constructor(props){
    super(props);
  }

  render() {
    return (
        <View style={styles.viewContentItems}>
          <Image
              resizeMode = {"cover"}
              source={this.props.avatar ? {uri: this.props.avatar} : defaultAvatar}
              defaultSource={defaultAvatar}
              style={styles.thumbnail} />
          {this._renderNumOfUnreadMessage()}
        </View>
    )
  }

  _renderNumOfUnreadMessage(){
    if (this.props.numOfUnreadMessage && this.props.numOfUnreadMessage >0 ){
      return (
          <View style={styles.notification}>
            <Text style={styles.notificationText}>
              {this.props.numOfUnreadMessage}
            </Text>
          </View>
      )
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(InboxContent);


var styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 55
  },

  saveText : {
    fontSize: 17,
    fontFamily: gui.fontFamily,
    color: "white",
    textAlign:'center',
    fontWeight:'500'
  },
  viewSaveInbox:{
    right:0,
    width:65,
    backgroundColor:gui.mainColor,
    height:70,
    alignItems: 'center',
    justifyContent:'center'
  },
  viewDeleteInbox:{
    right:0,
    width:65,
    backgroundColor:'#f43838',
    height:72,
    alignItems: 'center',
    justifyContent:'center'
  },
  text: {
    flexGrow: 1,
    alignSelf:'center',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: gui.mainColor,
    fontWeight : 'normal',
    top: 9,
  },

  rowFront :{
    //flexGrow: 1,
    height: 72,
    width: width
  },

  rowContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderColor: '#dcdcdc',
    paddingTop: 0
  },
  rightContainer: {
    flexGrow: 1
  },
  name: {
    fontSize: 12,
    color: 'gray',
    flexGrow: 1,
  },
  dateTime: {
    fontSize: 12,
    color: 'gray',
    fontFamily: gui.fontFamily,
    marginRight: 18
  },
  title: {
    fontSize: 13,
    textAlign: 'left',
    fontFamily: gui.fontFamily,
    fontWeight: '600'
  },
  content: {
    fontSize: 13,
    textAlign: 'left',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  viewContentItems: {
    justifyContent:'center',
    alignItems:'center',
    borderRadius: 20,
  },
  thumbnail: {
    paddingLeft: 5,
    width: 40,
    height: 40,
    marginRight: 5,
    borderRadius: 20

  },
  notification: {
    position: 'absolute',
    backgroundColor: '#ff0000',
    top: 1,
    right: 1,
    alignSelf: 'auto',
    width: 18,
    height: 18,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center'
  },
  notificationText: {
    fontSize: 10,
    fontFamily: gui.fontFamily,
    fontWeight: "400",
    color: '#fff',
    textAlign: 'center',
    backgroundColor: 'transparent'
  },
  listView: {
    paddingTop: 0,
    backgroundColor: 'white',
    borderColor: '#e6e6e6',
    borderBottomWidth: 0,
  },
  nameAndDateTime : {
    flexGrow: 1,
    flexDirection: 'row',
    paddingLeft: 0,
    marginTop: 8
  },

  rightRow2 : {
    flexDirection: 'row',
    marginBottom: 2
  },
  titleAndLastMsg : {
      flex: 1,
      flexDirection: 'column'
  },
  adsCover : {
    width: 40,
    height: 40,
    marginLeft: 18,
    marginRight: 18,
    marginTop: 2,
    marginBottom: 4
  },
  bottomText : {
    fontSize: 17,
    textAlign: 'center',
    fontFamily: gui.fontFamily,
    fontWeight: '400',
    color: '#606060',
    marginTop:10
  },
  rowBack: {
    alignItems: 'center',
    backgroundColor: '#fff',
    flexGrow: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingLeft: 0,
  },
    viewFooter:{
        marginTop: 20,
        width: width,
        height: 50,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textFooter:{
        fontSize: 17,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'

    }

});