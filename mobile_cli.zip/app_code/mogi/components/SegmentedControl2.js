import React, {Component} from 'react';
import {View, Text, StyleSheet, SegmentedControlIOS, TextInput} from 'react-native';

import gui from '../lib/gui';
import SegmentedControlTab from './SegmentedControlTab2';
import utils from '../lib/utils';

var {width, height} = utils.getDimensions();

// Create our component
class SegmentedControl2 extends Component{
    render() {
        return (
            <View style={[myStyles.searchFilterAttributeExt, {flexDirection: "column"}]}>
                <View style={{paddingBottom: 4, paddingTop: 3}}>
                    <Text style={myStyles.searchAttributeLabel}>
                        {this.props.label}
                    </Text>
                </View>
                <View style={{paddingLeft: 0, paddingRight: 6, paddingBottom: 9, flexDirection: "row"}}>
                    <SegmentedControlTab
                        values={this.props.values}
                        selectedIndex={this.props.selectedIndexAttribute}
                        onTabPress={this.props.onChange}
                        tabStyle ={myStyles.tabStyle}
                        tabTextStyle={myStyles.tabTextStyle}
                        activeTabStyle={{backgroundColor: gui.mainColor}}
                        activeTabTextStyle={myStyles.activeTabTextStyle}
                        tabsContainerStyle={myStyles.tabsContainerStyle}
                    />

                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={myStyles.input}
                        placeholder={this.props.placeholder}
                        placeholderTextColor={gui.mainColor}
                        value={this.props.textValue}
                        onChangeText={(text) => this.props.onTextChange(this.props.textField, text)}
                    />
                </View>
            </View>
        );
    }
}

// Later on in your styles..
var myStyles = StyleSheet.create({
    searchFilterAttributeExt: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingTop: 5,
        paddingLeft: 0,
        paddingBottom: 8,
        borderTopWidth: 1,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchAttributeLabel: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: 'black'
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        paddingRight: 10,
        marginLeft:10,
        height: 28,
        borderColor: gui.mainColor,
        borderWidth: 1,
        borderRadius: 5,
        width: 68,
        textAlign: 'right',
        alignSelf: 'center'
    },
    tabStyle: {
        backgroundColor: '#fff',
        // borderWidth: 1,
        borderColor:gui.mainColor,
        paddingVertical: 5,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        // marginLeft:-2
    },
    tabTextStyle: {
        color:gui.mainColor,
        fontWeight: '400',
        fontFamily:gui.fontFamily,
        fontSize: 15
    },
    activeTabTextStyle: {
        color: '#fff',
        fontWeight: '400',
        fontFamily:gui.fontFamily,
        fontSize: 15
    },
    tabsContainerStyle: {
        alignItems:'center',
        backgroundColor:'transparent',
        height:28,
        width: width-117,
        marginLeft:5,
        marginTop:2
    }
});

// Make this code available elsewhere
export default SegmentedControl2;
