import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    Image,
    ListView,
    StyleSheet,
    ScrollView,
    Linking,
    FlatList,
    Alert,
    TextInput
} from 'react-native';

import ScalableText from 'react-native-text';
import OfflineBar from '../line/OfflineBar';
import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import log from '../../lib/logUtil';
import cfg from '../../cfg';
import SelectMultiBox from './SelectMultiBox';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import CheckDot from '../detail/CheckDot';

import GiftedSpinner from 'react-native-gifted-spinner';

let {width, height} = util.getDimensions();

class PostOnWebsites extends Component {
    constructor(props) {
        super(props);
        // let topFilter = DanhMuc.websiteFilter[0];
        // let sites = [...props.sites];
        // sites.sort((a, b) => {
        //     let nameA=a.toLowerCase(), nameB=b.toLowerCase();
        //     if (nameA < nameB)
        //         return -1;
        //     if (nameA > nameB)
        //         return 1;
        //     return 0;
        // } );
        this.state = {
            loading: false,
            // isOpenModalSapxep: false,
            // isOpenModalFilter: false,
            // orderByKey: 'linkASC',
            // topFilter: topFilter
            couponCode: props.couponCode || ''
        }
    }

    render() {
        return(
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBody()}
                {/*this._openModalSapxep()*/}
                {/*this._openModalFilter()*/}
                {this._renderLoadingView()}
            </View>
        );
    }

    _renderLoadingView() {
        if (this.state.loading) {
            return (
                <View style={styles.loadingContent}>
                    <GiftedSpinner size="large" color={'#d3d3d3'} />
                </View>
            )
        }
    }

    _onContentModal() {
        this.setState({
            isOpenModalSapxep: false,
            isOpenModalFilter: false
        });
    }

    _onModalSapXep() {
        this.setState({isOpenModalSapxep: true});
    }

    _onModalFilter() {
        this.setState({isOpenModalFilter: true});
    }

    // _openModalSapxep() {
    //     return (
    //         <Modal isOpen={this.state.isOpenModalSapxep}
    //                onClosed={this._onContentModal.bind(this)}
    //                style={styles.viewModalStyle}
    //                position={"center"}
    //                swipeToClose={false}
    //                backdropPressToClose={false}
    //         >
    //             {this._renderSapXepContent()}
    //         </Modal>
    //     );
    //
    // }

    // _renderSapXepContent() {
    //     return (
    //         <View style={styles.viewDetailModal}>
    //             <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
    //                 {this._renderTextSapxep()}
    //                 {this._renderTextCancel()}
    //             </View>
    //             {
    //                 DanhMuc.getWebsiteOrderValues().map((e) => {
    //                     let orderByKey = this.state.orderByKey || '';
    //                     let orderByValue = DanhMuc.websiteOrder[orderByKey];
    //                     let checked = e == orderByValue;
    //                     return (
    //                         <TouchableOpacity style={styles.touchModalSapxep}
    //                                           key={e}
    //                                           onPress={() => this._onChooseWebsiteOrder(e)}>
    //                             <Text style={styles.textSapxep}>{e}</Text>
    //                             <View style={styles.viewTickSapxep}>
    //                                 {
    //                                     checked ?
    //                                         <TruliaIcon
    //                                             name="check" color={gui.mainColor} size={20}
    //                                             mainProps={styles.viewCheckIcon}
    //                                         /> : null
    //                                 }
    //
    //                             </View>
    //                         </TouchableOpacity>
    //                     )
    //                 })
    //             }
    //         </View>
    //     )
    // }

    //_onChooseWebsiteOrder(websiteOrderValue) {
    //    let newOrderBy = DanhMuc.findWebsiteOrderKey(websiteOrderValue);
    //    let sites = [...this.props.sites];
    //    if (newOrderBy == 'linkASC') {
    //        sites.sort((a, b) => {
    //            let nameA=a.toLowerCase(), nameB=b.toLowerCase();
    //            if (nameA < nameB)
    //                return -1;
    //            if (nameA > nameB)
    //                return 1;
    //            return 0;
    //        } );
    //    } else {
    //        sites.sort((a, b) => {
    //            let nameA=a.toLowerCase(), nameB=b.toLowerCase();
    //            if (nameA < nameB)
    //                return 1;
    //            if (nameA > nameB)
    //                return -1;
    //            return 0;
    //        } );
    //    }
    //    this.setState({
    //        sites: sites.slice(0, this.state.topFilter), isOpenModalSapxep: false, orderByKey: newOrderBy
    //    });
    //}

    _renderTextSapxep() {
        return (
            <View style={styles.viewSortModal}>
                <Text style={[styles.textSapxep, {fontWeight: '500', fontSize: 16}]}>Sắp xếp</Text>
            </View>
        );
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                              onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, {color: gui.mainColor, fontSize: 16}]}>Huỷ</Text>
            </TouchableOpacity>
        );

    }

    // _openModalFilter() {
    //     return (
    //         <Modal isOpen={this.state.isOpenModalFilter}
    //                onClosed={this._onContentModal.bind(this)}
    //                style={styles.viewModalStyle}
    //                position={"center"}
    //                swipeToClose={false}
    //                backdropPressToClose={false}
    //         >
    //             {this._renderFilterContent()}
    //         </Modal>
    //     );
    //
    // }

    // _renderFilterContent() {
    //     return (
    //         <View style={styles.viewDetailModal}>
    //             <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
    //                 {this._renderTextFilter()}
    //                 {this._renderTextCancel()}
    //             </View>
    //             {
    //                 DanhMuc.websiteFilter.map((e) => {
    //                     let topFilter = this.state.topFilter;
    //                     let checked = e == topFilter;
    //                     return (
    //                         <TouchableOpacity style={styles.touchModalSapxep}
    //                                           key={e}
    //                                           onPress={() => this._onChooseWebsiteFilter(e)}>
    //                             <Text style={styles.textSapxep}>{e}</Text>
    //                             <View style={styles.viewTickSapxep}>
    //                                 {
    //                                     checked ?
    //                                         <TruliaIcon
    //                                             name="check" color={gui.mainColor} size={20}
    //                                             mainProps={styles.viewCheckIcon}
    //                                         /> : null
    //                                 }
    //
    //                             </View>
    //                         </TouchableOpacity>
    //                     )
    //                 })
    //             }
    //         </View>
    //     )
    // }

    // _onChooseWebsiteFilter(topFilterValue) {
    //     let topFilter = Number(topFilterValue);
    //     let sites = this.props.sites.slice(0, topFilter);
    //     this.setState({
    //         sites: sites, isOpenModalFilter: false, topFilter: topFilter
    //     });
    // }

    // _renderTextFilter() {
    //     return (
    //         <View style={styles.viewSortModal}>
    //             <Text style={[styles.textSapxep, {fontWeight: '500', fontSize: 16}]}>Top</Text>
    //         </View>
    //     );
    // }

    _renderHeaderAds() {
        let title = this.props.hasPostAdsToOtherWebsite ? 'Cập nhật tin trên nhiều websites' : 'Đăng tin trên nhiều websites';
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: 'bold', fontSize: 14}]}>
                        {title}
                    </ScalableText>
                </View>
                <View style={styles.viewEdit} />
            </View>
        );
    }

    _renderBody() {
        return(
            <View style={styles.viewBody}>
                {/*this.renderSortTab()*/}
                {/*<View style={styles.viewLineHard}/>*/}
                {this.renderBottomTab()}
                {this.renderSites()}
            </View>
        );
    }

    renderPackageTab() {
        let {postToWebsitesServices, selectedWebsitesServiceIndex} = this.props;
        let selectedPackage = postToWebsitesServices[selectedWebsitesServiceIndex];
        let selectedPackageCode = selectedPackage ? selectedPackage.code : '';
        let packageItems = [];
        let isSelectedAll = this.props.isSelectedAll;
        postToWebsitesServices.forEach((one) => {
            packageItems.push(
                <CheckDot name={one.code} key={one.code}
                          onPress={this._onPackagePress.bind(this)}
                          disabled={!isSelectedAll}
                          selected={isSelectedAll && selectedPackageCode == one.code}
                          mainProps={styles.viewPackageTab}>{one.name + ' (' + util.addCommas(one.fees[0].price) + ' VNĐ)'}</CheckDot>
            );
        });
        let checkTextColor = isSelectedAll ? gui.mainColor : gui.mainTextColor;
        return (
            <View style={{flex: 0, marginTop: 15, marginBottom: 15}}>
                <Text style={[styles.textCheckAll, {width: width-58, color: checkTextColor, marginLeft: 15, marginBottom: 10}]}>
                    Gói đăng tin trên Landber
                </Text>
                {packageItems}
            </View>
        );
    }

    _onPackagePress(value) {
        let {postToWebsitesServices, isSelectedAll} = this.props;
        if (isSelectedAll) {
            let index = this._getPackageIndexByCode(value);
            let selectedPackage = postToWebsitesServices[index];
            let isLackMoney = this.props.isLackMoney(selectedPackage);
            if (isLackMoney) {
                Alert.alert(
                    'Thông báo',
                    'Tài khoản chính của bạn không đủ để sử dụng gói dịch vụ này',
                    [
                        {text: 'Đóng', onPress: () =>  { }},
                    ]
                );
            } else {
                this.setState({loading: true});
                this.props.resetSelectedSites();
                setTimeout(() => {
                    this.props.onPackagePress(index);
                    this.setState({loading: false});
                }, 300);
            }
        }
    }

    _getPackageIndexByCode(code) {
        let {postToWebsitesServices} = this.props;
        let index = -1;
        for (let i=0; i<postToWebsitesServices.length; i++) {
            let one = postToWebsitesServices[i];
            if (one.code == code) {
                index = i;
                break;
            }
        }
        return index;
    }

    // renderSortTab() {
    //     let textSapXep = 'Sắp xếp: ';
    //     let textTop = 'Top: ';
    //     let textNumberTop = this.state.topFilter;
    //     let orderByKey = this.state.orderByKey || '';
    //     let textTangDan = DanhMuc.websiteOrder[orderByKey];
    //
    //     return(
    //         <View style={styles.viewSortTab}>
    //             <View style={styles.viewSortAlphabet}>
    //                 <Text style={styles.textSort}>{textSapXep}</Text>
    //                 <TouchableOpacity style={styles.touchableSort} onPress={this._onModalSapXep.bind(this)}>
    //                     <Text style={[styles.textSort, {color: gui.mainColor}]}>{textTangDan}</Text>
    //                     <Icon name="sort-desc" size={17} color={gui.mainColor} style={{marginLeft: 2, marginBottom: 6 }} />
    //                 </TouchableOpacity>
    //             </View>
    //             <View style={styles.lineTabSort}/>
    //             <View style={[styles.viewSortAlphabet, {width: width/2 - 1}]}>
    //                 <Text style={styles.textSort}>{textTop}</Text>
    //                 <TouchableOpacity style={styles.touchableSort} onPress={this._onModalFilter.bind(this)}>
    //                     <Text style={[styles.textSort, {color: gui.mainColor}]}>{textNumberTop}</Text>
    //                     <Icon name="sort-desc" size={17} color={gui.mainColor} style={{marginLeft: 2, marginBottom: 6 }} />
    //                 </TouchableOpacity>
    //             </View>
    //         </View>
    //     )
    // }

    _getNumberOfWebs() {
        let {sites} = this.props;
        return sites ? sites.length : 0;
    }

    _isLackMoney() {
        let {postToWebsitesServices, selectedWebsitesServiceIndex} = this.props;
        if (selectedWebsitesServiceIndex < 0) {
            return false;
        }
        let postToWebsitesService = postToWebsitesServices[selectedWebsitesServiceIndex];
        return this.props.isLackMoney(postToWebsitesService);
    }

    renderBottomTab() {
        let imageAlert = require('../../assets/image/post_webs/icon-04.png');
        let isSelectedAll = this.props.isSelectedAll;
        let imageCheck = isSelectedAll? require('../../assets/image/post_webs/icon-03.png') : require('../../assets/image/post_webs/icon-02.png');
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let imageHelp = require('../../assets/image/post_webs/icon-05.png');
        let numberOfWebs = this._getNumberOfWebs();
        let textPricePost = `Tổng số ${numberOfWebs} websites`;
        let warningItems = null;
        let isLackMoney = this._isLackMoney();
        if (isLackMoney) {
            let warningMsg = 'Tài khoản chính của bạn không đủ, cần nạp thêm tiền để sử dụng dịch vụ này, nhấn Tiếp tục để đăng tin';
            warningItems = <View>
                <FullLine/>
                <ScalableText style={styles.textWarning}>{warningMsg}</ScalableText>
            </View>;
        }
        let checkAll = isSelectedAll ? 'Bỏ chọn tất cả' : 'Chọn tất cả';
        let textNext = 'Tiếp tục';
        let textBaoGia = 'Báo giá';

        let mainButtons = (
            <View style={styles.viewNextStep}>
                {/*<TouchableOpacity style={styles.viewBaoGia} onPress={this._onHelpMenuPressed.bind(this)}>
                 <Text style={[styles.textCheckAll, {color: gui.mainColor, marginRight: 2}]}>{textBaoGia}</Text>
                 <Image
                 resizeMode={"cover"}
                 source={imageHelp}
                 defaultSource={imageHelp}
                 style={styles.imageHelp} />
                 </TouchableOpacity>*/}
                <TouchableOpacity style={[styles.viewButtonNext, {backgroundColor: '#f36523'}]}
                                  onPress={this._onNextPress.bind(this)}>
                    <Text style={styles.textNextButton}>{textNext}</Text>
                </TouchableOpacity>
            </View>
        );
        if (this.props.postAds.uploading || this.props.me.isUpdatingProfile) {
            mainButtons = (
                <View style={styles.viewNextStep}>
                    {/*<View style={styles.viewBaoGia}>
                     <Text style={[styles.textCheckAll, {color: gui.mainColor, marginRight: 2}]}>{textBaoGia}</Text>
                     <Image
                     resizeMode={"cover"}
                     source={imageHelp}
                     defaultSource={imageHelp}
                     style={styles.imageHelp} />
                     </View>*/}
                    <View style={[styles.viewButtonNext, {backgroundColor: 'transparent', alignItems: 'flex-end'}]}>
                        <GiftedSpinner color="#8A8A8A" />
                    </View>
                </View>
            );
        }

        return(
            <View style={styles.viewBottomTab}>
                <FullLine/>
                <View style={[styles.viewTotalChoose, {paddingLeft: 15}]}>
                    <Image
                        resizeMode={"cover"}
                        source={imageAlert}
                        defaultSource={imageAlert}
                        style={styles.imageAlert} />
                    <Text style={styles.textPriceTotal}>
                        {textPricePost}
                    </Text>
                </View>
                {warningItems}
                <FullLine/>
                <View style={[styles.viewTotalChoose, {height: 53}]}>
                    {/*<View style={styles.viewCheckAll} >
                     <TouchableOpacity style={[styles.viewButtonNext, {backgroundColor: '#526173'}]}
                     onPress={this._onBackPress.bind(this)}>
                     <ScalableText style={styles.textNextButton}>Quay lại</ScalableText>
                     </TouchableOpacity>
                     </View>*/}
                    {/*<TouchableOpacity style={styles.viewCheckAll}
                     onPress={this.onSelectAll.bind(this)}
                     >
                     <Image
                     resizeMode={"cover"}
                     source={imageCheck}
                     defaultSource={defaultCover}
                     style={styles.imageAlert} />
                     <Text style={styles.textCheckAll}>{checkAll}</Text>
                     </TouchableOpacity>*/}
                    {mainButtons}
                </View>
            </View>
        );
    }

    _onNextPress() {
        this.props.onWebsiteDone(this.state.couponCode);
    }

    _onHelpMenuPressed() {
        let link = cfg.serverUrl + "/bao-gia";
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }

    renderSites() {
        let isLackMoney = this._isLackMoney();
        let actionLabel = this.props.hasPostAdsToOtherWebsite ? 'cập nhật tin' : 'đăng tin';
        let checkLabel = 'Đồng ý ' + actionLabel + ' trên nhiều websites';
        let isSelectedAll = this.props.isSelectedAll;
        let imageCheck = isSelectedAll ? require('../../assets/image/post_webs/icon-03.png') : require('../../assets/image/post_webs/icon-02.png');
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let checkTextColor = isSelectedAll ? gui.mainColor : gui.mainTextColor;
        return(
            <ScrollView style={{flex: 1, marginBottom: isLackMoney ? 130 : 90}}
                        ref={(scrollView) => { this._scrollView = scrollView; }}
                        automaticallyAdjustContentInsets={false}
                        onLayout={event => {
                            this._scrollViewHeight = event.nativeEvent.layout.y
                        }}
                        vertical={true}
            >
                <TouchableOpacity style={styles.viewCheckAll}
                                  onPress={this.onSelectAll.bind(this)}
                                  disabled={isLackMoney}
                >
                    <Image
                        resizeMode={"cover"}
                        source={imageCheck}
                        defaultSource={defaultCover}
                        style={[styles.imageAlert, {width: isSelectedAll ? 18 : 16}]} />
                    <Text style={[styles.textCheckAll, {width: width-58, color: checkTextColor}]}>
                        {checkLabel}
                        {/*<Text style={[styles.textPriceTotal, {color: 'red', fontWeight: 'bold'}]}>{priceValue}</Text>*/}
                    </Text>
                </TouchableOpacity>
                <FullLine/>
                {this.renderPackageTab()}
                {this.renderCouponCode()}
                <FullLine/>
                <Text style={[styles.textCheckAll, {width: width-58, color: checkTextColor, marginLeft: 15, marginTop: 15, marginBottom: 10}]}>
                    Danh sách websites
                </Text>
                <SelectMultiBox
                    items={this.props.sites}
                    selectedItems={this.props.selectedSites}
                    selectedLabelStyle={{color: gui.mainColor}}
                    selectedRowStyle={{backgroundColor: '#f6f6f6'}}
                    rowStyle={{paddingLeft: 25, paddingTop: 5, paddingBottom: 5, borderBottomWidth: 0}}
                    selectedCheckboxStyle={{width: 19}}
                    onSelectionsChange={this.onSelectionsChange.bind(this)} />
            </ScrollView>
        )
    }

    renderCouponCode() {
        let isSelectedAll = this.props.isSelectedAll;
        let labelColor = isSelectedAll ? gui.mainColor : gui.mainTextColor;
        let couponLabel = 'Nhập mã khuyến mại đăng tin nhiều website:';
        let couponPlaceholder = 'Mã khuyến mại';
        return (
            <View style={{marginBottom: 15}}>
                <Text style={[styles.couponLabel, {color: labelColor}]} >{couponLabel}</Text>
                <TextInput style={styles.couponInput}
                           placeholder={couponPlaceholder}
                           placeholderTextColor={gui.arrowColor}
                           value={this.state.couponCode}
                           onChangeText={(text) => this.setState({couponCode: text})}
                           maxLength={6}
                           autoCorrect={false}
                           autoCapitalize={'characters'}
                           returnKeyType='done'
                           onSubmitEditing={() => dismissKeyboard()}
                           editable={isSelectedAll}
                           onFocus={() => this._onCouponCodeFocus()}
                />
            </View>
        );
    }

    _onCouponCodeFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + height/4;
            this._scrollView.scrollTo({y: scrollTo});
        }
    }

    onSelectionsChange = (selectedSites) => {
        this.props.onSelectionsChange(selectedSites);
    };

    onSelectAll() {
        this.props.onSelectAll();
        this.setState({couponCode: ''});
    }

    _onBackPress() {
        this.props.onWebsiteBack();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 50
    },
    viewEdit: {
        paddingTop: 15,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 50
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewBottomTab: {
        // height: 85,
        width: width,
        backgroundColor: '#fff',
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0
    },
    viewTotalChoose: {
        height: 35,
        width: width,
        flexDirection: 'row',
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    imageAlert: {
        height: 16,
        width: 18
    },
    textPriceTotal: {
        fontSize: 13,
        fontWeight: 'normal',
        color: 'black',
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    textWarning: {
        fontSize: 13,
        fontWeight: '500',
        color: 'red',
        fontFamily: gui.fontFamily,
        marginLeft: 10,
        marginRight: 10
    },
    viewCheckAll: {
        height: 53,
        // width: width/2,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 15
    },
    textCheckAll: {
        fontSize: 14,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    textSort: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewNextStep: {
        height: 53,
        width: width,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingRight: 10
    },
    viewButtonNext: {
        paddingVertical: 5,
        paddingHorizontal: 8,
        backgroundColor: '#f36523',
        borderRadius: 5,
        // width: 70
    },
    textNextButton: {
        fontSize: 14,
        fontWeight: 'normal',
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    imageHelp: {
        height: 12,
        width: 12,
        marginRight: 8
    },
    viewBaoGia: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexDirection: 'row',
        height: 53,
        width: 80
    },
    viewSortTab: {
        height: 38,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewSortAlphabet: {
        height: 45,
        width: width/2,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchableSort: {
        flexDirection: 'row',
        marginLeft: 3,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewLineHard: {
        width: width,
        height: 7,
        backgroundColor: '#f6f6f6',
    },
    lineTabSort: {
        height: 30,
        width: 1,
        backgroundColor: '#f6f6f6',
        opacity: 0.9
    },
    viewModalStyle : {
        justifyContent: 'center',
        height: 120,
        width: width - 120,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor:'#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep:{
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    textSapxep: {
        fontSize: 16,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewPackageTab: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width - 30,
        paddingLeft: 20,
        height: 30
    },
    loadingContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    couponLabel: {
        fontSize: 14,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        paddingLeft: 15
    },
    couponInput: {
        fontSize: 14,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        width: 200,
        height: 38,
        borderWidth: 1,
        borderColor: 'lightgray',
        borderRadius: 5,
        padding: 5,
        marginLeft: 20,
        marginTop: 5,
        marginBottom: 5
    }
});

export default PostOnWebsites;