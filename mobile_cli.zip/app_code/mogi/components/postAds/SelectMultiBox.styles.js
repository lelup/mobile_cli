import { StyleSheet } from 'react-native';
import gui from '../../lib/gui';

export default StyleSheet.create({
    row: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        padding: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f6f6f6',
        backgroundColor: '#fff'
    },
    checkbox: {
        width: 16,
        height: 16,
        marginRight: 5
    },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    }
})