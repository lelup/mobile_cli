'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as groupActions from '../../reducers/group/groupActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import {
    Text, View, ListView, Image, ScrollView
    , TextInput, StyleSheet, RecyclerViewBackedScrollView
    , TouchableHighlight, StatusBar, Alert, TouchableOpacity
    , FlatList
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import gui from '../../lib/gui';

import utils from '../../lib/utils';

import CheckBox from '../group/CheckBox';
import FullLine from '../line/FullLine';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
var {width, height} = utils.getDimensions();

const TAT_CA = 'Tất cả';

const actions = [
    globalActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state,
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class PostAdsJoinedGroup extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        const ds = new ListView.DataSource({
            rowHasChanged: function rowHasChanged(r1, r2) {
                return r1 !== r2;
            }
        });

        let groupList = this._initSelectedGroup(props);

        this.state = {
            isCheckAll: false,
            dataSource: ds.cloneWithRows(groupList),
            groupList: groupList
        };
    }

    _getGroupList(data, userID) {
        let groupList = [];
        if (!data || data.length == 0) {
            return groupList;
        }
        let listRelatedGroup = data.filter((one) => {
                return one.createdBy == userID || one.joinStatus == 2
            }) || [];
        groupList = groupList.concat(listRelatedGroup);
        return groupList;
    }

    _initSelectedGroup(props) {
        let userID = props.global.currentUser.userID;
        let groupList = this._getGroupList(props.group.searchResult.listRelatedGroup, userID);
        let selectedGroupID = props.groupID;
        if (selectedGroupID && selectedGroupID.length > 0) {
            let hashGroupID = {};
            selectedGroupID.forEach((one) => {
                hashGroupID[one] = true;
            });
            groupList.forEach((one) => {
                if (hashGroupID[one.groupID]) {
                    one.checked = true;
                } else {
                    one.checked = false;
                }
            })
        } else {
            groupList.forEach((one) => {
                one.checked = false;
            })
        }
        return groupList;
    }

    _getGroupListID() {
        let groupList = this.state.groupList ? this.state.groupList.filter((e) => e.checked) : [];
        let groupIDs = []
        groupList.forEach((e) => {
            groupIDs.push(e.groupID)
        })
        return groupIDs;
    }

    render() {
        let title = 'Chọn sàn';
        return (
            <View style={styles.container}>
                {this._renderMainContent()}
                {this._renderButtons()}
                <View style={styles.pageHeader}>
                    <TouchableOpacity style={styles.viewBackIcon}
                                      onPress={this._onBackPress.bind(this)}>
                        <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} style={{ marginLeft: 0 }} />
                    </TouchableOpacity>
                    <View style={styles.pageHeaderWrapper}>
                        <Text style={styles.titleText}>{title}</Text>
                    </View>
                    <View style={styles.viewHuy} >
                    </View>
                </View>
            </View>
        );
    }

    _renderButtons() {
        let textCheckAll = !this.state.isCheckAll ? 'Chọn tất cả các sàn' : 'Bỏ chọn tất cả';
        return (
            <View style={styles.viewBottomContent}>
                <FullLine />
                <View style={styles.viewButtons}>
                    <TouchableOpacity style={styles.viewCheckAll}
                                      onPress={this.onCheckAll.bind(this)}
                    >
                        <CheckBox
                            selected={this.state.isCheckAll}
                            onPress={this.onCheckAll.bind(this)} />
                        <Text style={[styles.textNormal, { color: gui.mainColor, marginLeft: 8 }]}>{textCheckAll}</Text>
                    </TouchableOpacity>
                    <View style={styles.viewCheckAll}>
                        <TouchableOpacity
                            onPress={this._onDone.bind(this)}
                            style={styles.viewTouchSelectGroup}>
                            <Text style={[styles.textNormal, { color: '#fff' }]}>Chọn</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    onCheckAll() {
        let currentList = this.state.groupList;
        let oldCheckAllState = this.state.isCheckAll;
        this.setState({
            isCheckAll: !oldCheckAllState
        }, () => {
        });

        currentList.map((e) => {
            e.checked = !oldCheckAllState;
        });

        this.setState({ groupList: currentList });
    }

    _renderMainContent() {
        return (
            <ScrollView
                keyboardShouldPersistTaps="always"
                keyboardDismissMode="on-drag"
                style={styles.viewBody}>
                <FlatList
                    data={this.state.groupList}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(item) => this._renderRow(item.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={{ flex: 1 }}
                    contentContainerStyle={{ paddingBottom: 50 }}
                />
            </ScrollView>
        );
    }

    _renderRow(data) {
        let imgUrl = data.image;
        let groupName = data.name;
        let fullNameChuSan = data.fullNameChuSan;
        let imagePost = { uri: imgUrl };
        if (!imgUrl) {
            imagePost = require('../../assets/image/no_cover.jpg');
        }
        let defaultCover = require('../../assets/image/no_cover.jpg');
        return (
            <View style={styles.groupRowView}>
                <View style={styles.viewChildGroup}>
                    <View style={styles.viewCheckBox}>
                        <CheckBox
                            selected={data.checked}
                            onPress={this._onPressCheckBox.bind(this, data)} />
                    </View>
                    <View style={styles.viewGroupDetail}>
                        <Image
                            source={imagePost}
                            defaultSource={defaultCover}
                            resizeMode={"cover"}
                            style={styles.viewAvatar}
                        />
                        <View style={styles.viewContentRow}>
                            <Text style={[styles.textNormal, { color: gui.textAgentSolid }]}>{groupName}</Text>
                            <Text style={[styles.textNormal, { color: 'rgba(173,172,173,1)', fontWeight: 'normal', fontSize: 13 }]}>Chủ sàn: {fullNameChuSan}</Text>
                        </View>
                    </View>
                </View>
                <FullLine style={{ marginLeft: 50 }} />
            </View>
        )
    }

    _onPressCheckBox(data) {
        let currentList = this.state.groupList;
        currentList.map((e) => {
            if (e.groupID == data.groupID)
                e.checked = !e.checked;
        })
        this.setState({ groupList: currentList });
    }

    _onDone() {
        let selectedGroupIDs = this._getGroupListID();
        if (selectedGroupIDs.length == 0) {
            let msg = 'Bạn chưa chọn các sàn để đăng tin!';
            Alert.alert("Thông báo", msg, [ { text: 'Đóng', onPress: () => {} } ]);
            return;
        }
        this.props.onPress(selectedGroupIDs);
    }

    _onBackPress() {
        Actions.pop();
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(PostAdsJoinedGroup);



// Later on in your styles..
var styles = StyleSheet.create({
    container: {
        paddingTop: 0,
        backgroundColor: "white",
        flex: 1
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width,
        height: 64,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(82,97,115,0.05)'
    },
    viewBackIcon: {
        height: 38,
        width: 38,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        marginLeft: 16,
        marginTop: 5
    },
    pageHeaderWrapper: {
        position: 'absolute',
        left: 60,
        right: 60,
        top: 28,
        height: 36
    },
    backButton: {
        marginTop: 28
    },
    groupTitleView: {
        marginTop: 10,
        marginBottom: 10,
        marginLeft: 16,
        marginRight: 16
    },
    groupTitleText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight : 'bold',
        color: 'rgba(82,97,115,0.5)',
        textAlign: 'left'
    },
    groupListView: {
        flex: 1
    },
    groupMainView: {
        flexDirection: 'row',
        paddingTop: 17,
        paddingLeft: 17,
        paddingRight: 17,
        paddingBottom: 10
    },
    lineView: {
        borderTopWidth: 1,
        height:1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    labelText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    adminAvatar: {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 8
    },
    titleText: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600',
        textAlign: 'center',
        color: '#526173'
    },
    viewHuy:{
        position: 'absolute',
        right: 0,
        width: 90,
        backgroundColor: 'transparent',
        alignItems: 'center',
        top: 28,
        height: 36
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff',
        marginTop: 64
    },
    groupRowView: {
        width: width,
        height: 54
    },
    viewChildGroup: {
        width: width,
        height: 53,
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewCheckBox: {
        height: 53,
        width: 50,
        paddingLeft: 16,
        justifyContent: 'center'
    },
    viewGroupDetail: {
        height: 53,
        width: width - 50,
        //paddingLeft: 16,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewAvatar: {
        height: 36,
        width: 36,
        borderRadius: 18
    },
    viewContentRow: {
        height: 53,
        width: width - 50 - 36,
        justifyContent: 'center',
        paddingLeft: 8
    },
    textNormal: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: "rgba(112,112,112,1)",
        fontWeight: 'normal'
    },
    viewButtons: {
        height: 49,
        width: width,
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    viewCheckAll: {
        paddingLeft: 16,
        width: width / 2,
        height: 49,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTouchSelectGroup: {
        width: width / 2 - 32,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: gui.mainColor
    },
    viewBottomContent: {
        position: 'absolute',
        bottom: 0,
        width: width,
        height: 50
    },
});

