'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as meActions from '../../reducers/me/meActions';

import React, { Component } from 'react';

import {
    Text, View, StyleSheet, StatusBar, TextInput, Image, UIManager, ImageBackground,
    ScrollView, Picker, TouchableHighlight, TouchableOpacity, Alert, KeyboardAvoidingView
} from 'react-native';

import { Map } from 'immutable';
import { Actions, ActionConst } from 'react-native-router-flux';
import Button from 'react-native-button';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";

import TruliaIcon from '../TruliaIcon';
import FunctionModal from '../FunctionModal'

import RelandIcon from '../RelandIcon';

import DanhMuc from '../../assets/DanhMuc';

import LikeTabButton from '../LikeTabButton';

import SegmentedControl from '../SegmentedControl2';

import Toast, {DURATION} from '../toast/Toast';

import ImageResizer from 'react-native-image-resizer';

import Modal from 'react-native-modalbox';

import PickerExt2 from '../picker/PickerExt2';

import placeUtil from '../../lib/PlaceUtil';

import utils from '../../lib/utils';

import GiftedSpinner from 'react-native-gifted-spinner';

import moment from 'moment';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import ScalableText from 'react-native-text';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import cfg from "../../cfg";

import FullLine from '../line/FullLine'

import Camera from 'react-native-camera';

import PackageUpdater from './PostAdsPackageUpdater';

const Permissions = require('react-native-permissions');

var Intercom = require('react-native-intercom');

var rootUrl = `${cfg.serverUrl}`;

var { width, height } = utils.getDimensions();


const actions = [
    globalActions,
    postAdsActions,
    adsMgmtActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var count = 0;
var uploadFiles = [];
var errorMessage = '';

class NPostAdsDetail extends Component {

    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        errorMessage = this.props.postAds.error;

        let adsID = props.postAds.id;

        let diaChiChiTiet = props.postAds.place ? props.postAds.place.diaChiChiTiet : '';

        let noiDungChiTiet = props.postAds.chiTiet;

        let geo = props.postAds.place.geo;
        
        let diaChinhFullName = placeUtil.getDiaChinhFullName(props.postAds.place);
        let diaChiDuAn = diaChinhFullName;

        let {selectedDuAn} = this.props.postAds;
        let placeType = DanhMuc.placeType.DIA_DIEM;
        if (selectedDuAn && selectedDuAn.placeName) {
            placeType = DanhMuc.placeType.DU_AN;
            let {huyen, tinh} = props.postAds.place.diaChinh;
            diaChiDuAn = selectedDuAn.placeName + ', ' + huyen + ', ' + tinh;
        }

        this.state = {
            uploadUrls: [],
            chiTietExpanded: true,
            toggleState: false,
            editGia: false,
            showNamXayDung: false,
            initNamXayDung: '',
            inputNamXayDung: '',
            namXayDung: null,
            diaChinhFullName: diaChinhFullName,
            geo: geo,
            placeType: placeType,
            diaChiDuAn: diaChiDuAn,
            diaChiChiTiet: diaChiChiTiet,
            noiDungChiTiet: noiDungChiTiet,
            adsID: adsID,
            showMoreContent: false,
            deletedPhoto: null,
            onCancelling: false,
            photos: props.postAds.photos,
            isOpenImagePicker: false,
            goiVipActived: false,
            allServices: []
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.postAds.photos !== this.props.postAds.photos) {
            this.setState({photos: nextProps.postAds.photos});
            let place = nextProps.postAds.place;
            if (!place || !place.geo || !place.geo.lat || !place.geo.lon) {
                this.getAdsLocation(nextProps.postAds.photos);
            }
        }
    }

    componentWillMount() {
        let { place, photos, lienHe} = this.props.postAds;
        let adsID = this.props.postAds.id;
        let {currentUser} = this.props.global;

        if (!adsID || adsID.length <= 0) {
            let lienHe = {
                tenLienLac: currentUser.fullName,
                showTenLienLac: true,
                phone: currentUser.phone,
                showPhone: true,
                email: currentUser.email,
                showEmail: true
            };
            this.props.actions.onPostAdsFieldChange("lienHe", lienHe);
        }

        if (place && place.geo && place.geo.lat && place.geo.lon)
            return;

        this.getAdsLocation(photos);

        this.props.actions.findAllService(). then( e => {
            if (e.status ==0 ){
                let allViTriService = e.services.filter( (e) => {
                    return e.category == "Vị trí"
                }).sort((a, b) => b.level - a.level);
                this.setState({allServices: allViTriService});
            }
        });
    }

    getAdsLocation(photos) {
        if (photos) {
            for (let i = 0; i < photos.length; i++) {
                if (photos[i].location && photos[i].location.longitude && photos[i].location.latitude) {
                    //let {place} = this.props.postAds;
                    let geo = {
                        "lat": photos[i].location.latitude,
                        "lon": photos[i].location.longitude
                    };
                    //place.geo = geo;
                    //this.props.actions.onPostAdsFieldChange("place", place);
                    this.setState({geo: geo});
                    return;
                }
            }
        }

        this.getCurrentLocation();
    }

    getCurrentLocation() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                // let {place} = this.props.postAds;
                let geo = {
                    "lat": position.coords.latitude,
                    "lon": position.coords.longitude
                };
                // place.geo = geo;
                // this.props.actions.onPostAdsFieldChange("place", place);
                this.setState({geo: geo});
            },
            (error) => {
            },
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    }
    // _scrollToInput(reactNode: any) {
    //     this.refs.scroll.scrollToFocusedInput(reactNode)
    //     this.refs.scroll.scrollToPosition(0, 0, true)
    // }

    render() {
        if (this.state.goiVipActived) {
            return (
                <PackageUpdater {...this.props} allServices={this.state.allServices}
                                                onPackageApply={this._onPackageApply.bind(this)}
                                                onPackageCancel={this._onPackageCancel.bind(this)}/>
            );
        } else {
            return this.renderMainView();
        }
    }
    renderMainView() {
        let {toggleState} = this.state;
        let scrollHeight = toggleState ? height - 290 : height - 74;

        return (
            <View style={{ flex: 1, backgroundColor: 'white' }}>
                <View style={{ paddingTop: 25, backgroundColor: gui.mainColor }} />
                <KeyboardAwareScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="on-drag"
                    ref='scroll'>
                    <View myStyles={myStyles.container}>

                        <ScrollView
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="on-drag"
                            ref={(scrollView) => { this._scrollView = scrollView; } }
                            automaticallyAdjustContentInsets={false}
                            vertical={true}
                            //onScroll={this.handleScroll.bind(this)}
                            //scrollEventThrottle={1}
                        >
                            <View>
                                {this._renderPhoto()}

                                {this._renderLoaiTin()}

                                <FullLine />
                                <View style={myStyles.categoryTitle}>
                                    <Text style={myStyles.categoryText}>
                                        ĐẶC ĐIỂM
                                    </Text>
                                </View>
                                <FullLine />

                                {this._renderLoaiNha()}
                                <FullLine style={{marginLeft:17}} />
                                <Toast
                                    ref="toastTop"
                                    position='top'
                                    positionValue={100}
                                    fadeInDuration={850}
                                    fadeOutDuration={1400}
                                    opacity={0.56}
                                    textStyle={{color:'#fff'}}
                                />
                                {this._renderDienTich()}

                                {this._renderPhongNgu()}

                                {this._renderPhongTam()}

                                {this._renderSoTang()}

                                <FullLine />
                                {this._renderCategoryTitle('VỊ TRÍ')}
                                <FullLine />
                                {this._renderBanDo()}
                                <FullLine style={{marginLeft:17}} />
                                {this._renderDiaChi()}
                                {/*<FullLine style={{marginLeft:17}} />*/}
                                {/*this._renderDuAn()*/}
                                <FullLine style={{marginLeft:17}} />
                                {this._renderHuongNha()}

                                <FullLine />
                                {this._renderCategoryTitle('GIÁ VÀ LIÊN HỆ')}
                                <FullLine />
                                {this._renderGia()}
                                <FullLine style={{marginLeft:17}} />
                                {this._renderLienHe()}

                                <FullLine />
                                {this._renderCategoryTitle('THÔNG TIN CHI TIẾT')}
                                <FullLine />
                                {this._renderChiTiet()}

                                <FullLine />
                                {this._renderMoreButton()}

                                {this._renderCategoryTitle('')}
                                <FullLine />
                                {this._renderResetButton()}
                                <FullLine />


                                <Text style={[myStyles.label, { marginTop: 9, marginLeft: 15, color: 'red' }]}>
                                    {this.props.postAds.error}</Text>
                                <Text style={{color:'white'}}>
                                    {this.state.deletedPhoto}</Text>
                            </View>
                            <View style={myStyles.addViewBottom}></View>
                        </ScrollView>

                    </View>
                </KeyboardAwareScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                  style={[myStyles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                      backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

                {this._renderButtonNav()}
                {this._renderLoadingView()}
                {this._openImagePicker()}
            </View>
        )
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _renderCategoryTitle(title) {
        return (
            <View style={[myStyles.categoryTitle, myStyles.headerSeparator]}>
                <Text style={myStyles.categoryText}>
                    {title}
                </Text>
            </View>
        );
    }

    _renderPhoto() {
        let {photos} = this.state;
        if (!photos) {
            photos = [];
        }
        let numOfPhoto = photos.length;
        let indexArr = [];
        for (let i = 0; i <= photos.length; i++) {
            if (i < 20) {
                indexArr.push(i)
            }
        }

        return (
            <View>
                <View style={[myStyles.mimgList, { marginTop: 10, marginBottom: 5, paddingLeft: 17, paddingRight: 15 }]} >
                    {indexArr.map((e) => { if (e < 4) return this._renderPhotoItem(e) })}
                </View>
                <View style={[myStyles.mimgList, { marginTop: numOfPhoto >= 4 ? 5 : 0, marginBottom: numOfPhoto >= 4 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                    {indexArr.map((e) => { if (e >= 4 && e<8) return this._renderPhotoItem(e) })}
                </View>
                <View style={[myStyles.mimgList, { marginTop: numOfPhoto >= 8 ? 5 : 0, marginBottom: numOfPhoto >= 8 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                    {indexArr.map((e) => { if (e >= 8 && e< 12)  return this._renderPhotoItem(e) })}
                </View>
                <View style={[myStyles.mimgList, { marginTop: numOfPhoto >= 12 ? 5 : 0, marginBottom: numOfPhoto >= 12 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                    {indexArr.map((e) => { if (e >= 12 && e< 16)  return this._renderPhotoItem(e) })}
                </View>
                <View style={[myStyles.mimgList, { marginTop: numOfPhoto >= 16 ? 5 : 0, marginBottom: numOfPhoto >= 16 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                    {indexArr.map((e) => { if (e >= 16 && e< 20)  return this._renderPhotoItem(e) })}
                </View>
            </View>
        );
    }

    _openImagePicker() {
        return (
            <Modal isOpen={this.state.isOpenImagePicker}
                   onClosed={this._outModalImagePicker.bind(this)}
                   style={ [styles.viewModalStyle, {height:'auto'}] }
                   position={"bottom"}
                   swipeToClose={false}
                   animationDuration={200}
            >
                {this._renderModalImagePicker()}
            </Modal>
        );
    }

    _outModalImagePicker() {
        this.setState({
            isOpenImagePicker: false
        });
    }

    _openModalImagePicker() {
        dismissKeyboard();
        this.setState({isOpenImagePicker: true});
    }

    _renderModalImagePicker() {
        let items = [
            { _text: 'Máy ảnh', _function: () => this.onCamera() },
            { _text: 'Bộ sưu tập', _function: () => this.onCameraRollView() },        
          ]
          return (
            <FunctionModal
              // data={data}
              items={items}
              onCloseModal={this._outModalImagePicker.bind(this)} />
          )
    }

    onCamera() {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {
                if (e){
                    Permissions.requestPermission('photo')
                    .then(response => {
                        if (response == 'authorized') {
                            Actions.PostAds2({onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner});
                        } else {
                        Alert.alert("Thông báo", gui.INF_PhotoAccess);
                        }
                    }); 
                    
                } else {
                    Alert.alert("Thông báo", gui.INF_CameraAccess);
                }
            });
    }

    onCameraRollView() {
        Permissions.requestPermission('photo')
            .then(response => {
                if (response == 'authorized') {
                    Actions.CameraRollView2({onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner});
                } else {
                    Alert.alert("Thông báo", gui.INF_PhotoAccess);
                }
            });
    }

    _renderPhotoItem(imageIndex){
        let {photos} = this.state;
        if (!photos) {
            photos = [];
        }
        let photo = photos[imageIndex];

        return (
            <ImageItem  imageIndex={imageIndex}
                        key={imageIndex}
                        photo={photo}
                        onTakePhoto={this.onTakePhoto.bind(this)}
                        onDeletePhoto={this.onDeletePhoto.bind(this)}/>
        )
     }

    /*_renderPhotoItem(imageIndex) {
        let {photos} = this.props.postAds;
        let photo = photos[imageIndex];

        if (photo && photo.uri) {
            return (
                <TouchableHighlight key={imageIndex}
                                    disabled = {this.isUploading()}
                                    onPress={() => this.onTakePhoto(`${imageIndex}`)} >
                    <Image style={myStyles.imgItem} source={photo} />
                </TouchableHighlight>
            );
        } else {
            return (
                <TouchableHighlight key={imageIndex}
                                    disabled = {this.isUploading()}
                                    onPress={() => this.onTakePhoto(`${imageIndex}`)} >
                    <View style={[myStyles.imgItem, { borderStyle: 'dashed', borderColor: gui.mainColor }]}>
                        <RelandIcon name="plus" color={gui.mainColor}
                                    mainProps={myStyles.captureIcon}
                                    size={22} textProps={{ paddingLeft: 0 }}
                                    onPress={() => this.onTakePhoto(`${imageIndex}`)} />
                    </View>
                </TouchableHighlight>
            );
        }
    }
    */

    _renderCoverPhoto() {
        let imageIndex = 0;
        let {photos} = this.props.postAds;
        let photo = photos[imageIndex];

        if (photo && photo.uri) {
            return (
                <TouchableHighlight onPress={() => this.onTakePhoto(`${imageIndex}`)} >
                    <Image style={myStyles.imgItem} source={photo} />
                </TouchableHighlight>
            );
        } else {
            return (
                <TouchableHighlight onPress={() => this.onTakePhoto(`${imageIndex}`)} >
                    <View style={[myStyles.imgItem, { borderStyle: 'dashed', borderColor: gui.mainColor }]}>
                        <RelandIcon name="plus" color={gui.mainColor}
                                    mainProps={myStyles.captureIcon}
                                    size={22} textProps={{ paddingLeft: 0 }}
                                    onPress={() => this.onTakePhoto(`${imageIndex}`)} />
                    </View>
                </TouchableHighlight>
            );
        }
    }

    _renderLoaiTin() {
        return (
            <View style={{ flexDirection: 'row' }}>
                <View style={{ flex: 1, flexDirection: 'row', paddingLeft: 5, paddingRight: 5 }}>
                    <LikeTabButton name={'ban'}
                                   onPress={(loaiTin) => {
                                        this.onValueChange('loaiTin', loaiTin);
                                        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
                                     }
                                   }
                                   selected={this.props.postAds.loaiTin === 'ban'}>BÁN</LikeTabButton>
                    <LikeTabButton name={'thue'}
                                   onPress={(loaiTin) => {
                                        this.onValueChange('loaiTin', loaiTin);
                                        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
                                     }
                                   }
                                   selected={this.props.postAds.loaiTin === 'thue'}>CHO THUÊ</LikeTabButton>
                </View>
            </View>
        );
    }

    _renderLoaiNha() {
        return (
            <View style={[{ paddingTop: 9, marginBottom: 5 }, myStyles.headerSeparator]}>
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onLoaiNhaPressed()}>
                    <View style={myStyles.imgList}>
                        <Text style={myStyles.label}>
                            Loại nhà
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <ScalableText style={myStyles.grayLabel}> {this._getLoaiNhaValue()} </ScalableText>
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderDienTich() {
        return (
            <View style={[myStyles.imgList, myStyles.headerSeparator, { marginLeft: 17, paddingLeft: 0 }]} >
                <Text style={myStyles.label}>Diện tích (m²)</Text>
                <TextInput
                    secureTextEntry={false}
                    keyboardType={'numeric'}
                    style={myStyles.input}
                    value={this.props.postAds.dienTich && Number(this.props.postAds.dienTich) >= 0 ?
                                this.props.postAds.dienTich.toString() : ''}
                    onChangeText={(text) => this._onNumberValueChange("dienTich", text)}
                />
            </View>
        );
    }

    _renderMatTien() {
        let {loaiNhaDat} = this.props.postAds;

        if (loaiNhaDat && [2,3,4,5,6,7,8,99].indexOf(loaiNhaDat)>=0) {
            return (
                <View style={[myStyles.imgList, myStyles.headerSeparator, { marginLeft: 17, paddingLeft: 0 }]}>
                    <Text style={myStyles.label}>Mặt tiền (m)</Text>
                    <TextInput ref="matTien"
                               secureTextEntry={false}
                               keyboardType={'numeric'}
                               style={myStyles.input}
                               value={this.props.postAds.matTien ? this.props.postAds.matTien.toString() : ''}
                               onChangeText={(text) => this._onNumberValueChange("matTien", text)}
                    />
                </View>
            );
        } else
            return;

    }

    _renderNamXayDung() {
        return (
            <View>
                {this._renderLineXayDung()}
                <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                    <TouchableOpacity onPress={() => this._onNamXayDungPressed()}
                                        disabled={this.isUploading()}>
                        <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                            <Text style={myStyles.label}>
                                Năm xây dựng
                            </Text>
                            <View style={myStyles.arrowIcon}>
                                <Text style={myStyles.grayLabel}> {this._getNamXayDungValue()} </Text>
                                <TruliaIcon name={"arrow-down"}
                                            onPress={() => this._onNamXayDungPressed()}
                                            color={gui.arrowColor} size={18} />
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>
                {this._renderNamXayDungPicker()}
            </View>
        );
    }

    _renderLineXayDung() {
        let {loaiNhaDat} = this.props.postAds;
        if (loaiNhaDat && [2,3,4,5,6,7,8,99].indexOf(loaiNhaDat)>=0){
            return <FullLine style={{marginLeft:17}} />
        } else return;
    }

    _renderPhongNgu() {
        let {loaiNhaDat} = this.props.postAds;

        if (loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0){
            return this._renderSegment(
                "Số phòng ngủ",
                DanhMuc.getAdsSoPhongNguValues(),
                this.props.postAds.soPhongNguSelectedIdx,
                this._onSegmentChanged.bind(this, 'soPhongNguSelectedIdx'),
                this.props.postAds.soPhongNguText, "soPhongNguText",
                (key, value) => this._onSegmentTextChanged(key, value));
        } else
            return;


    }

    _renderPhongTam() {
        let {loaiNhaDat} = this.props.postAds;

        if (loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0) {
            return this._renderSegment(
                "Số phòng tắm",
                DanhMuc.getAdsSoPhongTamValues(),
                this.props.postAds.soNhaTamSelectedIdx,
                this._onSegmentChanged.bind(this, 'soNhaTamSelectedIdx'),
                this.props.postAds.soNhaTamText, "soNhaTamText",
                (key, value) => this._onSegmentTextChanged(key, value));
        } else
            return;
    }

    _renderSoTang() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;

        if ((loaiNhaDat && [2,3,4].indexOf(loaiNhaDat)>=0 && loaiTin=='ban')
             || (loaiNhaDat && [2,3,4,5,6].indexOf(loaiNhaDat)>=0 && loaiTin=='thue')
            ) {
            return this._renderSegment(
                "Số tầng",
                DanhMuc.getAdsSoTangValues(),
                this.props.postAds.soTangSelectedIdx,
                this._onSegmentChanged.bind(this, 'soTangSelectedIdx'),
                this.props.postAds.soTangText, "soTangText",
                (key, value) => this._onSegmentTextChanged(key, value));
        } else
            return;
    }

    _renderBanDo() {
        return (
            <View style={[{ paddingTop: 9, marginBottom: 7 }, myStyles.headerSeparator]}>
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onBanDoPressed()}>
                    <View style={myStyles.imgList} >
                        <Text style={myStyles.label}>
                            Địa điểm/Dự án
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            { this.props.postAds.loadingDiaChinh ?
                                (
                                    <View style={{paddingLeft: 10}}>
                                        <GiftedSpinner size="small" color="#8A8A8A"/>
                                    </View>
                                )
                                : <ScalableText style={myStyles.grayLabel}> {this._getBanDoValue()} </ScalableText>
                            }
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderDiaChi() {
        return (
            <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                {
                    this.isUploading() ?
                        <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                            <Text style={myStyles.label}>
                                Địa chỉ
                            </Text>
                            <View style={myStyles.arrowIcon}>
                                <ScalableText style={myStyles.grayLabel}> {this._getDiaChiValue()} </ScalableText>
                                <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                            </View>
                        </View> :
                        <TouchableOpacity
                            onPress={() => this._onDiaChiPressed()}>
                            <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                                <Text style={myStyles.label}>
                                    Địa chỉ
                                </Text>
                                <View style={myStyles.arrowIcon}>
                                    <ScalableText style={myStyles.grayLabel}> {this._getDiaChiValue()} </ScalableText>
                                    <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                                </View>
                            </View>
                        </TouchableOpacity>
                }
            </View>
        );
    }

    _renderDuAn() {
        return (
            <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                    <Text style={myStyles.label}>
                        Thuộc dự án
                    </Text>
                    <View style={myStyles.arrowIcon}>
                        <ScalableText style={[myStyles.grayLabel, {paddingRight: 10}]}> {this._getDuAnValue()} </ScalableText>
                    </View>
                </View>
            </View>
        );
        /*return (
            <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onDuAnPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                        <Text style={myStyles.label}>
                            Thuộc dự án
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <ScalableText style={myStyles.grayLabel}> {this._getDuAnValue()} </ScalableText>
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );*/
    }

    _renderHuongNha() {
        return (
            <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onHuongNhaPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                        <Text style={myStyles.label}>
                            Hướng nhà
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <ScalableText style={myStyles.grayLabel}> {this._getHuongNhaValue()} </ScalableText>
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderDuongTruocNha() {
        let {loaiNhaDat} = this.props.postAds;

        if (loaiNhaDat && [2,3,4,5,6,7,8,99].indexOf(loaiNhaDat)>=0) {
            return (
                <View>
                    <FullLine style={{marginLeft:17}} />
                    <View style={[myStyles.imgList, myStyles.headerSeparator, { marginLeft: 17, paddingLeft: 0 }]}>
                        <Text style={myStyles.label}>Đường trước nhà (m)</Text>
                        <TextInput
                        ref='duongTruocNha'
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={myStyles.input}
                        value={this.props.postAds.duongTruocNha ? this.props.postAds.duongTruocNha.toString() : ''}
                        onChangeText={(text) => this._onNumberValueChange("duongTruocNha", text)}
                        />
                    </View>
                </View>
            );
        } else
            return;
    }

    _renderMoreButton() {
        if (this.state.showMoreContent) {
            return (
                <View>
                    {this._renderCategoryTitle('THÔNG TIN KHÁC')}
                    <FullLine/>

                    {this._renderMatTien()}

                    {this._renderDuongTruocNha()}

                    {this._renderNamXayDung()}

                    {this._renderNhaMoiXay()}

                    {this._renderNhaLoGoc()}

                    {this._renderOtoDoCua()}

                    {this._renderNhaKinhDoanhDuoc()}

                    {this._renderNoiThatDayDu()}

                    {this._renderChinhChuDangTin()}
                    <FullLine />
                </View>
            )
        } else {
            return (
                <View>
                    {this._renderCategoryTitle('')}
                    <FullLine/>
                    <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, paddingLeft: 0 }]} >
                        <TouchableOpacity
                            disabled = {this.isUploading()}
                            onPress={() => this._onMoreButtonPressed()}>
                            <View style={[myStyles.imgList, { justifyContent: 'center' }]} >
                                <Text style={[myStyles.label, { color: gui.mainColor }]}>
                                    Mở rộng
                                </Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <FullLine/>
                </View>
            );
        }
    }
    _renderResetButton() {
        return (
            <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 15, paddingLeft: 0 }]} >
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onResetButtonPressed()}>
                    <View style={[myStyles.imgList, { justifyContent: 'center' }]} >
                        <Text style={[myStyles.label, { color: '#ff0000' }]}>
                            Thiết lập lại
                        </Text>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderNhaMoiXay() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;

        if  ( (loaiTin=='ban' && loaiNhaDat && [1,2,3,4,7,8].indexOf(loaiNhaDat)>=0)
              || loaiTin=='thue'
            ){
            return (
                <View>
                    <FullLine style={{marginLeft:17}} />
                    <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, paddingLeft: 0 }]}>
                        <TouchableOpacity
                            disabled={this.isUploading()}
                            onPress={() => this._onNhaXayMoiPressed()}>
                            <View style={[myStyles.imgList]}>
                                <Text style={myStyles.label}>
                                    Nhà mới xây
                                </Text>
                                <View style={myStyles.arrowIcon}>
                                    <TruliaIcon name={"check"}
                                                onPress={() => this._onNhaXayMoiPressed()}
                                                color={this.props.postAds.nhaMoiXay ? gui.mainColor : gui.arrowColor}
                                                size={18}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            );
        } else
            return;
    }

    _renderNhaLoGoc() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;

        if  ((loaiTin=='ban' && loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0)
              || (loaiTin=='thue' && loaiNhaDat && [1,2,3,4,5,6].indexOf(loaiNhaDat)>=0)
            ){
            return (
                <View>
                    <FullLine style={{marginLeft:17}} />
                    <View
                        style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]}>
                        <TouchableOpacity
                        disabled={this.isUploading()}
                        onPress={() => this._onNhaLoGocPressed()}>
                        <View style={[myStyles.imgList, { paddingLeft: 0 }]}>
                            <Text style={myStyles.label}>
                                Nhà lô góc
                            </Text>
                            <View style={myStyles.arrowIcon}>
                                <TruliaIcon name={"check"}
                                            onPress={() => this._onNhaLoGocPressed()}
                                            color={this.props.postAds.nhaLoGoc ? gui.mainColor : gui.arrowColor}
                                            size={18}/>
                            </View>
                        </View>
                    </TouchableOpacity>
                    </View>
                </View>
            );
        } else
            return;
    }

    _renderOtoDoCua() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;

        if  ((loaiTin=='ban' && loaiNhaDat && [2,3,4,5,6,7,8,99].indexOf(loaiNhaDat)>=0)
             || (loaiTin=='thue' && loaiNhaDat && [2,3,4,5,6,7,99].indexOf(loaiNhaDat)>=0)
            ) {
            return (
                <View>
                    <FullLine style={{marginLeft:17}} />
                    <View
                        style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]}>
                        <TouchableOpacity
                        disabled={this.isUploading()}
                        onPress={() => this._onOtoDoCuaPressed()}>
                        <View style={[myStyles.imgList, { paddingLeft: 0 }]}>
                            <Text style={myStyles.label}>
                                Ôtô đỗ cửa
                            </Text>
                            <View style={myStyles.arrowIcon}>
                                <TruliaIcon name={"check"}
                                            onPress={() => this._onOtoDoCuaPressed()}
                                            color={this.props.postAds.otoDoCua ? gui.mainColor : gui.arrowColor}
                                            size={18}/>
                            </View>
                        </View>
                        </TouchableOpacity>
                    </View>
                </View>
            );
        } else
            return;
    }

    _renderNhaKinhDoanhDuoc() {
        return (
            <View>
                <FullLine style={{marginLeft:17}} />
                <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                    <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onNhaKinhDoanhDuocPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                        <Text style={myStyles.label}>
                            Nhà kinh doanh được
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <TruliaIcon name={"check"}
                                        onPress={() => this._onNhaKinhDoanhDuocPressed()}
                                        color={this.props.postAds.nhaKinhDoanhDuoc ? gui.mainColor : gui.arrowColor} size={18} />
                        </View>
                    </View>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
    _renderNoiThatDayDu() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;

        if  ((loaiTin=='ban' && loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0)
            || (loaiTin=='thue' && loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0)
        ) {
            return (
                <View>
                    <FullLine style={{marginLeft:17}} />
                    <View
                        style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]}>
                        <TouchableOpacity
                        disabled={this.isUploading()}
                        onPress={() => this._onNoiThatDayDuPressed()}>
                        <View style={[myStyles.imgList, { paddingLeft: 0 }]}>
                            <Text style={myStyles.label}>
                                Nội thất đầy đủ
                            </Text>
                            <View style={myStyles.arrowIcon}>
                                <TruliaIcon name={"check"}
                                            onPress={() => this._onNoiThatDayDuPressed()}
                                            color={this.props.postAds.noiThatDayDu ? gui.mainColor : gui.arrowColor}
                                            size={18}/>
                            </View>
                        </View>
                        </TouchableOpacity>
                    </View>
                </View>
            );
        } else
            return;
    }
    _renderChinhChuDangTin() {
        return (
            <View>
                <FullLine style={{marginLeft:17}} />
                <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                    <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onChinhChuDangTinPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                        <Text style={myStyles.label}>
                            Chính chủ đăng tin
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <TruliaIcon name={"check"}
                                        onPress={() => this._onChinhChuDangTinPressed()}
                                        color={this.props.postAds.chinhChuDangTin ? gui.mainColor : gui.arrowColor} size={18} />
                        </View>
                    </View>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    // _renderGia() {
    //     return (
    //         <View style={[myStyles.imgList, myStyles.headerSeparator]} >
    //             <Text style={myStyles.label}>Giá (triệu)</Text>
    //             <TextInput
    //                 secureTextEntry={false}
    //                 keyboardType={'numeric'}
    //                 style={myStyles.input}
    //                 value={this.props.postAds.gia ? this.props.postAds.gia.toString() : ''}
    //                 onChangeText={(text) => this.onValueChange("gia", text)}
    //                 onFocus={() => this.setState({ editGia: true })}
    //             />
    //         </View>
    //     );
    // }

    _renderLienHe() {
        return (
            <View style={[myStyles.headerSeparator, { paddingTop: 9, marginBottom: 7, marginLeft: 17, paddingLeft: 0 }]} >
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onLienHePressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]} >
                        <Text style={myStyles.label}>
                            Liên hệ
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <ScalableText style={myStyles.grayLabel}> {this._getLienHeValue()} </ScalableText>
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderChiTiet() {
        return (
            <View style={[{ paddingTop: 9, marginBottom: 7 }, myStyles.headerSeparator]} >
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onChiTietPressed()}>
                    <View style={myStyles.imgList} >
                        <Text style={myStyles.label}>
                            Chi tiết
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <ScalableText style={myStyles.grayLabel}> {this._getChiTietValue()} </ScalableText>
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }
    _renderButtonNav() {
        return (
            <View style={myStyles.searchButton}>
                <View style={myStyles.searchListButton}>
                    <Button onPress={this.onCancel.bind(this)} disabled = {this.isUploading()}
                            style={myStyles.buttonText}>Hủy</Button>
                    {this._renderPostAdsButton()}
                </View>
            </View>
        );
    }

    _renderPostAdsButton(){
        if (this.props.postAds.uploading || this.props.me.isUpdatingProfile) {
            return (
                <View style={{marginLeft: 17, marginRight: 17, marginTop: 10, marginBottom: 10,}}>
                    <GiftedSpinner color="white" />
                </View>
            )
        } else {
            return (
                <View>
                    <Button onPress={this.onPostAds.bind(this)}
                            disabled={this.isUploading()}
                            style={myStyles.buttonText}>{this.state.adsID ? 'Cập nhật' : 'Tiếp tục'}</Button>
                </View>
            )
        }
    }

    _renderNamXayDungPicker() {
        let {showNamXayDung, initNamXayDung, inputNamXayDung} = this.state;
        if (showNamXayDung) {
            let pickerRange = this._initDanhMucNam(100);
            let inputPlaceholder = '';
            let onTextChange = this._onNamXayDungInputChange.bind(this);
            let onTextFocus = this._onScrollNamXayDung.bind(this);
            let pickerSelectedValue = initNamXayDung;
            let onPickerValueChange = this._onNamXayDungChanged.bind(this);
            let val2Display = this._namXayDungVal2Display.bind(this);
            let onPress = this._onPressNamXayDungHandle.bind(this);
            let inputLabel = '';
            return <PickerExt2 pickerRange={pickerRange} val2Display={val2Display} inputPlaceholder={inputPlaceholder}
                               inputValue={String(inputNamXayDung || '')} onTextChange={onTextChange} onTextFocus={onTextFocus}
                               pickerSelectedValue={pickerSelectedValue} onPickerValueChange={onPickerValueChange}
                               onPress={onPress} inputLabel={inputLabel} />
        }
    }

    _renderLoadingView() {
        if (this.state.onCancelling || this.props.postAds.uploading) {
            return (<View style={myStyles.resultContainer}>
                <View style={myStyles.loadingContent}>
                    <GiftedSpinner size="large" color={'#d3d3d3'} />
                </View>
            </View>)
        }
    }

    _initDanhMucNam(numberOfYear) {
        let latestYear = parseInt(moment().format("YYYY"), 10);
        let yearRange = []

        for (let i = latestYear; i > latestYear - numberOfYear; i--) {
            yearRange.push(i.toString());
        }
        yearRange.unshift('Bất kỳ');
        return yearRange;
    }

    _onNamXayDungInputChange(value) {
        value = (isNaN(parseInt(value))) ? undefined : value;
        this.onValueChange('namXayDung', value);
        this.setState({ inputNamXayDung: value });
    }

    _onScrollNamXayDung() {
        if (this._scrollView) {
            let scrollTo = height / 2 - 238;
            this._scrollView.scrollTo({ y: scrollTo });
        }
    }

    _onNamXayDungChanged(pickedValue) {
        let value = pickedValue;
        value = (isNaN(parseInt(value))) ? undefined : value;
        this.onValueChange('namXayDung', value);
        this.setState({ initNamXayDung: value, inputNamXayDung: value });
    }

    _namXayDungVal2Display(namXayDung) {
        return namXayDung;
    }

    _onNamXayDungPressed() {
        let {showNamXayDung} = this.state;
        this.setState({ showNamXayDung: !showNamXayDung });
        /*if (!showNamXayDung) {
         this._onScrollNamXayDung();
         }*/
    }

    _onPressNamXayDungHandle() {
        let {showNamXayDung} = this.state;
        this.setState({ showNamXayDung: !showNamXayDung });
        if (!showNamXayDung) {
            this._onScrollNamXayDung();
        }
    }

    _getNamXayDungValue() {
        let {namXayDung} = this.props.postAds;
        return namXayDung || '';
    }

    _onResetButtonPressed() {
        this.setState({ showMoreContent: false });
        this.onRefreshPostAds(true);
    }

    _onMoreButtonPressed() {
        this.setState({ showMoreContent: true });
    }

    _onLoaiNhaPressed() {
        dismissKeyboard();
        Actions.PropertyTypes({ func: 'postAds' });
    }

    _onHuongNhaPressed() {
        dismissKeyboard();
        Actions.MHuongNha({ func: 'postAds' });
    }

    _onDuAnPressed() {
        dismissKeyboard();
        Actions.DuAn();
    }

    _getLoaiNhaValue() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;
        return DanhMuc.getLoaiNhaDatForDisplay(loaiTin, loaiNhaDat);
    }

    _getLoaiNhaValue() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;
        return DanhMuc.getLoaiNhaDatForDisplay(loaiTin, loaiNhaDat);
    }

    _getHuongNhaValue() {
        let {huongNha} = this.props.postAds;
        return DanhMuc.getHuongNhaForDisplay(huongNha);
    }

    _getDuAnValue() {
        let {selectedDuAn} = this.props.postAds;
        return selectedDuAn ? selectedDuAn.placeName : '';
    }

    _onNhaXayMoiPressed() {
        let nhaMoiXay = this.props.postAds.nhaMoiXay;
        this.props.actions.onPostAdsFieldChange('nhaMoiXay', !nhaMoiXay);
    }

    _onNhaLoGocPressed() {
        let nhaLoGoc = this.props.postAds.nhaLoGoc;
        this.props.actions.onPostAdsFieldChange('nhaLoGoc', !nhaLoGoc);
    }

    _onOtoDoCuaPressed() {
        let otoDoCua = this.props.postAds.otoDoCua;
        this.props.actions.onPostAdsFieldChange('otoDoCua', !otoDoCua);
    }

    _onNhaKinhDoanhDuocPressed() {
        let nhaKinhDoanhDuoc = this.props.postAds.nhaKinhDoanhDuoc;
        this.props.actions.onPostAdsFieldChange('nhaKinhDoanhDuoc', !nhaKinhDoanhDuoc);
    }

    _onNoiThatDayDuPressed() {
        let noiThatDayDu = this.props.postAds.noiThatDayDu;
        this.props.actions.onPostAdsFieldChange('noiThatDayDu', !noiThatDayDu);
    }

    _onChinhChuDangTinPressed() {
        let chinhChuDangTin = this.props.postAds.chinhChuDangTin;
        this.props.actions.onPostAdsFieldChange('chinhChuDangTin', !chinhChuDangTin);
    }

    _onBanDoPressed() {
        dismissKeyboard();
        //let {geo} = this.props.postAds.place;
        let {geo, placeType, diaChiDuAn} = this.state;
        let {selectedDuAn, selectedDiaChinh} = this.props.postAds;
        Actions.PostAdsMapView({ showSuggestionPosition: true, onPress: this._onDiaChinhSelected.bind(this), location: geo,
            diaChi: diaChiDuAn, placeType: placeType, duAn: selectedDuAn, diaChinhInfo: selectedDiaChinh});
    }

    _onDiaChinhSelected(position) {
        if (!position.diaChinhInfo) {
            // let location = position.location;
            // findApi.getGeocoding(location.lat, location.lon, (data) => this._getDiaChinhContent(data, position));
            let diaChinhDuAn = {
                tinh: position.duAn && position.duAn.tinhName,
                codeTinh: position.duAn && position.duAn.tinh,
                huyen: position.duAn && position.duAn.huyenName,
                codeHuyen: position.duAn && position.duAn.huyen,
                xa: position.duAn && position.duAn.xaName,
                codeXa: position.duAn && position.duAn.xa
            };
            this._updateDiaChinhContent(position, diaChinhDuAn);
        } else {
            this._updateDiaChinhContent(position, position.diaChinhInfo);
        }
    }

    // _getDiaChinhContent(data, position) {
    //     let tinhName = position.duAn && position.duAn.tinhName;
    //     let huyenName = position.duAn && position.duAn.huyenName;
    //     let diaChinhDuAn = {tinh: tinhName, huyen: huyenName};
    //     let diaChinh = placeUtil.parseDiaChinh(data, diaChinhDuAn);
    //     this._updateDiaChinhContent(position, diaChinh);
    // }

    _updateDiaChinhContent(position, diaChinh) {
        let diaChi = position.diaChi;
        let {place} = this.props.postAds;
        place.geo = position.location;
        place.diaChinh.tinh = diaChinh.tinh;
        place.diaChinh.huyen = diaChinh.huyen;
        place.diaChinh.xa = diaChinh.xa;
        
        this.props.actions.onPostAdsFieldChange('selectedDuAn', position.duAn);

        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', diaChinh);

        this.props.actions.onPostAdsFieldChange('place', place);
        //
        // let {tinh, huyen, xa} = diaChinh;
        // diaChinh.tinhKhongDau = utils.locDau(tinh);
        // diaChinh.huyenKhongDau = utils.locDau(huyen);
        // diaChinh.xaKhongDau = utils.locDau(xa);
        //
        // var placeType = 'T';
        // if (diaChinh.huyenKhongDau)
        //     placeType = 'H';
        // if (diaChinh.xaKhongDau)
        //     placeType = 'X';
        //
        // var diaChinhDto = {
        //     tinhKhongDau: diaChinh.tinhKhongDau || undefined,
        //     huyenKhongDau: diaChinh.huyenKhongDau || undefined,
        //     xaKhongDau: diaChinh.xaKhongDau || undefined,
        //     placeType: placeType
        // }
        //
        // this.props.actions.getDiaChinhFromGoogleData(diaChinhDto);

        let diaChinhFullName = placeUtil.getDiaChinhFullName(place);

        this.setState({ diaChinhFullName: diaChinhFullName, diaChiDuAn: diaChi,
            geo: place.geo, placeType: position.placeType });

    }

    _getBanDoValue() {
        if (!this.state.diaChinhFullName || this.state.diaChinhFullName.length <= 0 ||
            this.state.diaChinhFullName == "Chọn dự án, địa điểm") {
            return "Chọn dự án, địa điểm";
        } else {
            let diaChinhFullName = '';
            let geo = this.state.geo;
            if (geo && !isNaN(geo.lat)) {
                diaChinhFullName = geo.lat.toFixed(6) + ', ' + geo.lon.toFixed(6);
            }
            if (this.state.placeType != DanhMuc.placeType.DIA_DIEM) {
                let {selectedDuAn} = this.props.postAds;
                diaChinhFullName = selectedDuAn ? selectedDuAn.placeName : '';
            }

            if (this.state.diaChinhFullName.length > 30) {
                diaChinhFullName = diaChinhFullName.substring(0, 30) + '...';
            }
            return diaChinhFullName;
        }
    }

    _onNumberValueChange(stateName, text) {
        if (text === '' || text === '.' || text === ',') {
            text = '';
        }
        let value = utils.interestNumeric(text);
        if(utils.countDot(value, '\\.') >= 2){
            this.refs.toastTop && this.refs.toastTop.show('Bạn nhập không đúng định dạng số!',DURATION.LENGTH_SHORT);
            return;
        }
        this.onValueChange(stateName, value);
    }

    _onDiaChiPressed() {
        dismissKeyboard();
        Actions.PostAdsAddress({ diaChinhFullName: this.state.diaChinhFullName, onComplete: this._onDiaChiChosed.bind(this) });
    }

    _onLienHePressed() {
        dismissKeyboard();
        Actions.PostAdsLienHe();
    }

    _onDiaChiChosed(diaChiChiTiet){
        this.setState({diaChiChiTiet: diaChiChiTiet});
    }

    _getDiaChiValue() {
        let diaChinhFullName = this.state.diaChinhFullName;
        let diaChiChiTiet = this.state.diaChiChiTiet;
        let {selectedDuAn, selectedDiaChinh} = this.props.postAds;
        //
        // if (!diaChiChiTiet || diaChiChiTiet.length <= 0)
        //     return '';

        if (selectedDuAn && selectedDuAn.placeName) {
            diaChiChiTiet = diaChiChiTiet ? selectedDuAn.placeName + ', ' + diaChiChiTiet : selectedDuAn.placeName;
        }

        if (selectedDiaChinh && selectedDiaChinh.duong) {
            diaChiChiTiet = diaChiChiTiet ? diaChiChiTiet + ', ' + selectedDiaChinh.duong : selectedDiaChinh.duong;
        }

        if (diaChinhFullName && diaChinhFullName != "Chọn dự án, địa điểm") {
            diaChiChiTiet = diaChiChiTiet ? diaChiChiTiet + ', ' + diaChinhFullName : diaChinhFullName;
        }

        if (diaChiChiTiet.length > 30) {
            diaChiChiTiet = diaChiChiTiet.substring(0, 30) + '...';
        }

        return diaChiChiTiet;
    }

    _getLienHeValue() {
        let {lienHe} = this.props.postAds;

        if (!lienHe)
            return '';

        let lienHeTxt = '';
        if (lienHe.showTenLienLac && lienHe.tenLienLac && lienHe.tenLienLac.length > 0)
            lienHeTxt = lienHeTxt == '' ? lienHe.tenLienLac : lienHeTxt + lienHe.tenLienLac;
        if (lienHe.showPhone && lienHe.phone && lienHe.phone.length > 0)
            lienHeTxt = lienHeTxt == '' ? lienHe.phone : lienHeTxt + "-" + lienHe.phone;
        if (lienHe.showEmail && lienHe.email && lienHe.email.length > 0)
            lienHeTxt = lienHeTxt == '' ? lienHe.email : lienHeTxt + "-" + lienHe.email;

        let result = lienHeTxt.substring(0, 30) + '...';

        return result;
    }


    _renderGia() {
        return (
            <View style={[{ paddingTop: 9, marginBottom: 5 }, myStyles.headerSeparator]}>
                <TouchableOpacity
                    disabled = {this.isUploading()}
                    onPress={() => this._onGiaPressed()}>
                    <View style={myStyles.imgList}>
                        <Text style={myStyles.label}>
                            Giá
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <ScalableText style={myStyles.grayLabel}> {this._getGiaValue()} </ScalableText>
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }


    _onGiaPressed() {
        let {loaiTin} = this.props.postAds;
        dismissKeyboard();
        this.setState({ editGia: true });
        Actions.PostAdsPrice({ loaiTin: loaiTin});
    }

    _getGiaValue() {
        let {gia, donViTien} = this.props.postAds;
        if (!gia) {
            return "";
        }
        let giaItem = DanhMuc.collectGiaDonViTien(gia, donViTien);
        this.onValueChange('gia', giaItem.gia);
        this.onValueChange('donViTien', giaItem.donViTien);
        return DanhMuc.getGiaForDisplay(giaItem.gia, giaItem.donViTien);
    }

    _onSegmentTextChanged(key, val) {
        let maxValue = 7;

        this.onValueChange(key, val);
        if (isNaN(val) || val == '') {
            val = (maxValue + 1).toString();
        }
        let value = Number(val) > maxValue ? -1 : Number(val) - 1;
        if (key == 'soTangText') {
            this.onValueChange('soTangSelectedIdx', value);
        }
        else if (key == 'soPhongNguText') {
            this.onValueChange('soPhongNguSelectedIdx', value);
        }
        else {
            this.onValueChange('soNhaTamSelectedIdx', value);
        }
    }

    _onSegmentChanged(key, index) {
        //let index = index.nativeEvent.selectedSegmentIndex;
        this.onValueChange(key, index);
        let value = '';
        if (key == 'soTangSelectedIdx') {
            value = DanhMuc.getAdsSoTangByIndex(index);
            this.onValueChange('soTangText', value);
        }
        else if (key == 'soPhongNguSelectedIdx') {
            value = DanhMuc.getAdsSoPhongByIndex(index);
            this.onValueChange('soPhongNguText', value);
        }
        else {
            value = DanhMuc.getAdsSoPhongTamByIndex(index);
            this.onValueChange('soNhaTamText', value);
        }
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange, textValue, textField, onTextChange) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                              onChange={onChange}
                              textValue={textValue ? textValue.toString() : ''}
                              textField={textField}
                              onTextChange={onTextChange} placeholder={"Khác"} />
        );
    }

    _onChiTietPressed() {
        dismissKeyboard();
        Actions.PostAdsTitle({onComplete: this._onChiTietClosed.bind(this)});
    }

    _onChiTietClosed(noiDungChiTiet) {
        this.setState({noiDungChiTiet: noiDungChiTiet});
    }

    _getChiTietValue() {
        // let {chiTiet} = this.props.postAds;
        let chiTiet = this.state.noiDungChiTiet;
        if (!chiTiet) {
            return '';
        }

        let index = chiTiet.indexOf('\n');
        let val = index >= 0 ? chiTiet.substring(0, index) : chiTiet;
        if (val.length > 30) {
            return val.substring(0, 30) + '...';
        } else if (val.length != chiTiet.length) {
            return val + '...';
        }
        return chiTiet;

    }

    onValueChange(key: string, value: string) {
        this.props.actions.onPostAdsFieldChange(key, value);
    }

    onPostAds() {
        let {photos, place} = this.props.postAds;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < photos.length; i++) {
            let filepath = photos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath,  index: i, needUpload: filepath.indexOf('http') != 0});
        }
        if (!this.isValidInputData()) {
            Alert.alert('Thông báo', errorMessage, [{text: 'Đóng', onPress: () => {}}]);
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            return;
        }

        let diaChiFullname = this._getDiaChiValue();
        if (!diaChiFullname) {
            errorMessage = 'Bạn chưa nhập thông tin địa chỉ!';
            Alert.alert('Thông báo', errorMessage, [{text: 'Đóng', onPress: () => {}}]);
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            return;
        }
        // if (!place.diaChi || place.diaChi.trim() == '') {
        //     Alert.alert(
        //         'Thông báo',
        //         'Bạn chưa nhập số nhà, ngõ, ngách. \nBạn có muốn tiếp tục đăng tin?',
        //         [
        //             {text: 'Hủy', onPress: () => {}, style: 'cancel'},
        //             {text: 'Đồng ý', onPress: () =>  {this.onPostAdsChecked()}},
        //         ],
        //     );
        // } else
        if (!this.props.postAds.id) {
            let currentUser = this.props.global.currentUser;
            this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
                (res) => {
                    if (res.status == 0) {
                        this._upgradeAds();
                    } else {
                        Alert.alert('Thông báo', res.msg, [{text: 'Đóng', onPress: () => {}}]);
                    }
                }
            );
        } else {
            this.onPostAdsChecked();
        }
    }

    _upgradeAds() {
        this.props.actions.changeSelectedPackage('goiViTri');
        this.props.actions.changePackageField('adsID', null);
        this.props.actions.changePackageField('ads', null);
        this.setState({goiVipActived: true});
    }

    _onPackageCancel() {
        this.setState({goiVipActived: false});
    }

    _onPackageApply() {
        let service = this.state.allServices.filter( (e) => {
            return e.name == this.props.adsMgmt.package.goiViTri.levelName;
        });

        let fee = service[0].fees.filter( (e) => {
            return e.soLanSuDung == this.props.adsMgmt.package.goiViTri.length;
        });

        let serviceOrder = { userID: this.props.global.currentUser.userID,
            workstation:
            { name: this.props.global.deviceInfo.deviceModel,
                workstationID: this.props.global.deviceInfo.deviceID,
                appType: 'app' },
            price: { discount: fee[0].discount,
                price: fee[0].price,
                soLanSuDung: fee[0].soLanSuDung,
                type: fee[0].type},
            service: { id: service[0].id,
                name: service[0].name,
                level: service[0].level,
                //days: fee[0].soLanSuDung,
                packageType: 1} };

        this.props.actions.onPostAdsFieldChange('serviceOrder', serviceOrder);
        this.setState({goiVipActived: false});

        this.onPostAdsChecked();
    }

    onPostAdsChecked () {
        let {photos} = this.props.postAds;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < photos.length; i++) {
            let filepath = photos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath,  index: i, needUpload: filepath.indexOf('http') != 0});
        }

        this.props.actions.onPostAdsFieldChange("uploading", true);

        let countUpdateFiles = this.countNeedUploadFiles();
        if (!countUpdateFiles) {
            this.onSaveAds();
            return;
        }

        count = 0;
        const userID = this.props.global.currentUser.userID;
        for (let i = 0; i < uploadFiles.length; i++) {
            if (errorMessage != '') {
                Alert.alert('Thông báo', errorMessage);
                this.props.actions.onPostAdsFieldChange('error', errorMessage);
                return;
            }
            let needUpload = uploadFiles[i].needUpload;
            if (!needUpload) {
                continue;
            }
            let index = uploadFiles[i].index;
            let filepath = uploadFiles[i].filepath;
            ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let filename = 'Ads_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadAdsImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this));
            }).catch((err) => {
                this.props.actions.onPostAdsFieldChange("uploading", false);
                log.error(err);
            });
        }
    }

    isValidLoaiTin() {
        let {loaiTin, loaiNhaDat} = this.props.postAds;
        if (loaiNhaDat == '' || loaiNhaDat === 0) {
            return false;
        }
        let dmLoaiNhatDatKeys = loaiTin=='ban' ? DanhMuc.LoaiNhaDatBanKey : DanhMuc.LoaiNhaDatThueKey;
        let found = dmLoaiNhatDatKeys.filter((item) => item == loaiNhaDat);
        return found && found.length > 0;
    }

    isValidInputData() {
        let errors = '';
        if (uploadFiles.length === 0) {
            errors += ' (ảnh)';
        }
        let {loaiNhaDat, place, gia, dienTich, matTien
            , soTangText, soPhongNguText, soNhaTamText} = this.props.postAds;
        let geo = place && place.geo;

        if (!this.isValidLoaiTin()) {
            errors += ' (loại nhà)';
        }

        if (!geo || !geo.lat || isNaN(geo.lat)
            || !geo.lon || isNaN(geo.lon)) {
            errors += ' (địa điểm/dự án)';
        }
        // if (!place.diaChi || place.diaChi.trim() == '') {
        //     errors += ' (địa chỉ)';
        // }
        if (!gia) {
            errors += ' (giá)';
        }
        // if (!dienTich) {
        //     errors += ' (diện tích)';
        // }
        if (errors != '') {
            errorMessage = 'Bạn chưa chọn' + errors + '!';
            return false;
        }
        if (gia && isNaN(gia)) {
            errors += ' (giá)';
        }

        if (dienTich && ((!isNaN(dienTich) && Number(dienTich)<=0  && Number(dienTich) != -1) || isNaN(dienTich))) {
            errors += ' (diện tích)';
        }
        if (matTien && isNaN(matTien)) {
            errors += ' (mặt tiền)';
        }
        if (soTangText && isNaN(soTangText)) {
            errors += ' (số tầng)';
        }
        if (soPhongNguText && isNaN(soPhongNguText)) {
            errors += ' (số phòng ngủ)';
        }
        if (soNhaTamText && isNaN(soNhaTamText)) {
            errors += ' (số phòng tắm)';
        }
        if (errors != '') {
            errorMessage = 'Sai kiểu giá trị:' + errors + '!';
            return false;
        }
        return true;
    }

    uploadCallBack = function (err, result, index) {
        let data = result && result.data ? result.data : '';
        if (err || data == '') {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            this.props.actions.onPostAdsFieldChange("uploading", false);
            return;
        }
        try {
            let {success, file} = JSON.parse(data);
            if (success) {
                let {url} = file;
                this.state.uploadUrls.push({index: index, url: url});
                count++;
                if (count == this.countNeedUploadFiles()) {
                    this.onSaveAds();
                }
            } else {
                errorMessage = 'Upload ảnh không thành công!';
                this.props.actions.onPostAdsFieldChange('error', errorMessage);
                this.props.actions.onPostAdsFieldChange("uploading", false);
            }
        } catch (error) {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            this.props.actions.onPostAdsFieldChange("uploading", false);
        }
    }

    countNeedUploadFiles() {
        let count = 0;
        for (let i = 0; i < uploadFiles.length; i++) {
            let file = uploadFiles[i];
            if (file.needUpload) {
                count++;
            }
        }
        return count;
    }

    onSaveAds() {
        let {uploadUrls} = this.state;
        let {id, maSo, loaiTin, loaiNhaDat, gia, donViTien, dienTich, matTien, namXayDung,
            soTangText, soPhongNguText, soNhaTamText, chiTiet, huongNha, duongTruocNha,
            place, selectedDiaChinh, selectedDuAn, lienHe, photos,
            nhaMoiXay, nhaLoGoc, otoDoCua, nhaKinhDoanhDuoc, noiThatDayDu, chinhChuDangTin, serviceOrder} = this.props.postAds;

        let imageUrls = [];
        for (let i = 0; i < photos.length; i++) {
            let photo = photos[i];
            imageUrls.push(photo.uri);
        }
        for (let i = 0; i < uploadUrls.length; i++) {
            let uploadUrl = uploadUrls[i];
            let index = uploadUrl.index;
            if (index >= 0) {
                imageUrls[index] = uploadUrl.url;
            }
        }
        let image = { cover: '', images: [] };
        if (imageUrls.length > 0) {
            image.cover = imageUrls[0];
            // imageUrls.shift();
            image.images = imageUrls;
        }

        let loaiTinVal = (loaiTin === 'ban') ? 0 : 1;

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let dangBoi = {
            "email": currentUser.email,
            "name": currentUser.fullName,
            "phone": currentUser.phone,
            "userID": currentUser.userID
        };

        // remove lienHe if no information
        if (lienHe
            && (!lienHe.tenLienLac || lienHe.tenLienLac.length <= 0)
            && (!lienHe.phone || lienHe.phone.length <= 0)
            && (!lienHe.email || lienHe.phone.length <= 0))
            lienHe = undefined;

        //remove placeId
        place.placeId = undefined;
        place.diaChiFullName = undefined;
        place.duAn = undefined;
        place.duAnFullName = undefined;

        let diaChi = '';
        if (selectedDuAn && selectedDuAn.placeName) {
            diaChi = place.diaChiChiTiet ? selectedDuAn.placeName + ", " + place.diaChiChiTiet : selectedDuAn.placeName;
        } else {
            diaChi = place.diaChiChiTiet;
        }
        if (selectedDiaChinh && selectedDiaChinh.duong) {
            diaChi = diaChi ? diaChi + ", " + selectedDiaChinh.duong : selectedDiaChinh.duong;
        }
        diaChi = diaChi ? diaChi + ", " + this.state.diaChinhFullName : this.state.diaChinhFullName;
        place.diaChi = diaChi;

        if (selectedDiaChinh) {
            place.diaChinh.codeTinh = selectedDiaChinh.codeTinh || undefined;
            place.diaChinh.codeHuyen = selectedDiaChinh.codeHuyen || undefined;
            place.diaChinh.codeXa = selectedDiaChinh.codeXa || undefined;
            place.diaChinh.codeDuong = selectedDiaChinh.codeDuong || undefined;
            place.diaChinh.tinh = selectedDiaChinh.tinh || undefined;
            place.diaChinh.huyen = selectedDiaChinh.huyen || undefined;
            place.diaChinh.xa = selectedDiaChinh.xa || undefined;
            place.diaChinh.duong = selectedDiaChinh.duong || undefined;
            place.diaChinh.tinhKhongDau = undefined;
            place.diaChinh.huyenKhongDau = undefined;
            place.diaChinh.xaKhongDau = undefined;
        }

        if (selectedDuAn) {
            place.diaChinh.codeDuAn = selectedDuAn.duAn || undefined;
            place.diaChinh.duAn = selectedDuAn.placeName || undefined;
        } else {
            place.diaChinh.codeDuAn = undefined;
            place.diaChinh.duAn = undefined;
        }

        let phongNgu = soPhongNguText != '' && !isNaN(soPhongNguText) ? Number(soPhongNguText) : undefined;
        let soTang = soTangText != '' && !isNaN(soTangText) ? Number(soTangText) : undefined;
        let phongTam = soNhaTamText != '' && !isNaN(soNhaTamText) ? Number(soNhaTamText) : undefined;
        let giaItem = DanhMuc.calculateGia2(gia, donViTien, dienTich);

        let ngayDangTin = moment().format('YYYYMMDD');

        let adsDto = {
            "id": id || undefined,
            "maSo": maSo || undefined,
            "image": image,
            "loaiTin": loaiTinVal,
            "loaiNhaDat": loaiNhaDat,
            "dienTich": dienTich || -1,
            "matTien": matTien || undefined,
            "namXayDung": namXayDung || undefined,
            "soPhongNgu": phongNgu,
            "soPhongTam": phongTam,
            "soTang": soTang,
            "place": place,
            "huongNha": huongNha || -1,
            "duongTruocNha": duongTruocNha && !isNaN(duongTruocNha) ? Number(duongTruocNha) : undefined,
            "nhaMoiXay": nhaMoiXay,
            "nhaLoGoc": nhaLoGoc,
            "otoDoCua": otoDoCua,
            "nhaKinhDoanhDuoc": nhaKinhDoanhDuoc,
            "noiThatDayDu": noiThatDayDu,
            "chinhChuDangTin": chinhChuDangTin,
            "chiTiet": chiTiet || undefined,
            "gia": giaItem.gia || -1,
            "giaM2": giaItem.giaM2 || -1,
            "ngayDangTin": ngayDangTin || undefined,
            "lienHe": lienHe,
            "dangBoi": dangBoi,
            "serviceOrder": serviceOrder || undefined
        };

        this.props.actions.postAds(adsDto, token)
            .then(res => {
                this.setState({
                    loading: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [ { text: 'Đóng', onPress: () => {} } ]);
                } else {
                    this.onRegisterIntercomUser();
                    setTimeout(() => {
                        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
                    }, 300);
                    this.props.actions.onAdsMgmtFieldChange('activeTab', loaiTinVal == 0 ? 0 : 1);
                    Actions.popTo('root');
                    Actions.AdsMgmt();
                    let adsID = this.state.adsID;
                    if (adsID && adsID.length > 0) {
                        setTimeout(() => Alert.alert("Thông báo", "Thay đổi thành công."), 1000);
                    } else {
                        setTimeout(() => Alert.alert(
                            "Thông báo",
                            "Xác nhận tin đã đăng thành công và đang chờ duyệt trước khi được đưa lên landber.",
                            [ { text: 'Đóng', onPress: () => {} } ]), 1000);
                    }
                }
            });
    }

    onRegisterIntercomUser() {
        try {
            let userID = this.props.global.currentUser.userID || undefined;
            let email = this.props.global.currentUser.email || undefined;
            let phone = this.props.global.currentUser.phone || undefined;
            let name = this.props.global.currentUser.username || undefined;
            let fullName = this.props.global.currentUser.fullName || undefined;
            if (fullName) {
                name = fullName;
            }
            let avatar = this.props.global.currentUser.avatar || undefined;
            Intercom.reset().then(() => {
                Intercom.registerIdentifiedUser({ userId: userID })
                    .then(() => {
                        log.info('registerIdentifiedUser done');

                        return Intercom.updateUser({
                                email: email,
                                phone: phone,
                                name: name,
                                avatar: { type: 'avatar', image_url: avatar }
                            });
                    })
                    .catch((err) => {
                        log.error('registerIdentifiedUser ERROR', err);
                    });
            });
        } catch (error) {
            log.warn('========== onRegisterIntercomUser ERROR', error);
        }
    }

    postAdsCallBack(adsID) {
        // Actions.SearchResultDetail({adsID: adsID, source: 'local'});
        this.onRefreshPostAds();
        Actions.Home();
    }

    isUploading(){
        return this.props.postAds.uploading || this.props.postAds.loadingDiaChinh;
    }

    onRefreshPostAds(keepAdsID) {
        // this.props.actions.onResetState();
        this.props.actions.onPostAdsFieldChange('photos', []);
        this.props.actions.onPostAdsFieldChange('imageIndex', 0);
        this.props.actions.onPostAdsFieldChange('pickMode', 'new');
        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        this.props.actions.onPostAdsFieldChange('dienTich', null);
        this.props.actions.onPostAdsFieldChange('matTien', null);
        this.props.actions.onPostAdsFieldChange('namXayDung', null);
        this.props.actions.onPostAdsFieldChange('soPhongNguSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soPhongNguText', '');
        this.props.actions.onPostAdsFieldChange('soNhaTamSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soNhaTamText', '');
        this.props.actions.onPostAdsFieldChange('soTangSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soTangText', '');
        this.onValueChange("place", {
            duAn: '',
            duAnFullName: '',
            placeId: "ChIJKQqAE44ANTERDbkQYkF-mAI",
            diaChiChiTiet: '',
            diaChi: '',
            diaChinh: {
                tinh: '',
                huyen: '',
                xa: '',
                duAn: '',
                duong: '',
                tinhKhongDau: '',
                huyenKhongDau: '',
                xaKhongDau: '',
                codeTinh: '',
                codeHuyen: '',
                codeXa: '',
                codeDuAn: '',
                codeDuong: ''
            },
            geo: { lat: '', lon: '' }
        });
        let {currentUser} = this.props.global;
        let lienHe = {
            tenLienLac: currentUser.fullName,
            showTenLienLac: true,
            phone: currentUser.phone,
            showPhone: true,
            email: currentUser.email,
            showEmail: true
        };
        this.props.actions.onPostAdsFieldChange("lienHe", lienHe);
        this.props.actions.onPostAdsFieldChange('dangBoi', {
                userID: undefined,
                email: null,
                phone: null,
                name: null
            });
        this.props.actions.onPostAdsFieldChange('huongNha', null);
        this.props.actions.onPostAdsFieldChange('duongTruocNha', null);
        this.props.actions.onPostAdsFieldChange('nhaMoiXay', null);
        this.props.actions.onPostAdsFieldChange('nhaLoGoc', null);
        this.props.actions.onPostAdsFieldChange('otoDoCua', null);
        this.props.actions.onPostAdsFieldChange('nhaKinhDoanhDuoc', null);
        this.props.actions.onPostAdsFieldChange('noiThatDayDu', null);
        this.props.actions.onPostAdsFieldChange('chinhChuDangTin', null);
        this.props.actions.onPostAdsFieldChange('gia', null);
        this.props.actions.onPostAdsFieldChange('donViTien', 0);
        this.props.actions.onPostAdsFieldChange('chiTiet', '');

        let maSo = keepAdsID ? this.props.postAds.maSo : null;
        this.props.actions.onPostAdsFieldChange('maSo', maSo);
        
        this.props.actions.onPostAdsFieldChange('error', '');
        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', null);
        this.props.actions.onPostAdsFieldChange('selectedDuAn', null);
        this.props.actions.onPostAdsFieldChange('duAnList', null);
        this.props.actions.onPostAdsFieldChange('serviceOrder', undefined);

        let adsID = keepAdsID ? this.props.postAds.id : null;
        this.props.actions.onPostAdsFieldChange('id', adsID);

        this.state = {
            ...this.state,
            adsID: adsID,
            uploadUrls: [],
            chiTietExpanded: true,
            toggleState: false,
            editGia: false,
            showNamXayDung: false,
            initNamXayDung: '',
            inputNamXayDung: '',
            namXayDung: null,
            diaChinhFullName: '',
            geo: null,
            placeType: DanhMuc.placeType.DIA_DIEM,
            diaChiDuAn: 'Chọn dự án, địa điểm',
            diaChiChiTiet: '',
            noiDungChiTiet: '',
            showMoreContent: false,
            deletedPhoto: null,
            onCancelling: false,
            photos: []
        }
    }

    onCancel() {
        let isUpdateAds = this.state.adsID && this.state.adsID.length > 0 ;
        this.setState({onCancelling: true});
        Alert.alert('Thông báo', isUpdateAds ? 'Bạn muốn ngừng sửa tin ?': 'Bạn muốn ngừng đăng tin ?',
            [   { text: 'Hủy', onPress: () => {
                                                    log.info('PostAdsDetail - Cancel Pressed!');
                                                    this.setState({onCancelling: false});
                                                }
                },
                {
                    text: 'Đồng ý', onPress: () => {

                        try {
                            if (isUpdateAds || this.props.owner == 'AdsMgmt') {
                                // back to AdsMgmt if update Ads
                                Actions.popTo('root');
                                Actions.AdsMgmt();
                            } else if (this.props.owner == 'NewPostAds') {
                                Actions.popTo('root');
                                Actions.NewPostAds();
                            } else {
                                Actions.Home({ type: 'reset' });
                            }
                        } catch (error){
                            log.info("PostAdsDetail - Cancel Pressed error");
                            this.setState({onCancelling: false});
                        }
                    }
                }
            ]);
    }

    onTakePhoto(imageIndex) {
        this.props.actions.onPostAdsFieldChange('imageIndex', imageIndex);
        // Actions.PostAds();
        this._openModalImagePicker();
    }

    onDeletePhoto(imageIndex){
        let {photos} = this.state;
        photos.splice(imageIndex, 1);
        this.setState({deletedPhoto: imageIndex});
        this.props.actions.onPostAdsFieldChange('photos', photos);
    }
}

class ImageItem extends React.Component {
    constructor(props) {
        super(props);
    }

    _onPhotoPressed(){
        this.props.onTakePhoto(`${this.props.imageIndex}`);
    }

    _onDeletePhoto(){
        this.props.onDeletePhoto(`${this.props.imageIndex}`);
    }

    _renderCoverTitle(){
        if (this.props.imageIndex ==0)
        return (
            <View style={myStyles.coverContent}>
                <Text style={myStyles.coverText}>
                Ảnh bìa
                </Text>
            </View>
        )
    }

    _renderDeleteButton(){
        if (this.props.imageIndex !=0)
            return (
                <TouchableOpacity
                    style={myStyles.deleteContent}
                    onPress={this._onDeletePhoto.bind(this)} >

                    <View style={myStyles.deleteButton}>
                        <RelandIcon name="close" color={'black'}
                                    mainProps={myStyles.captureIcon}
                                    size={10} textProps={{ paddingLeft: 0 }}
                                    noAction={true}
                        />
                    </View>
                </TouchableOpacity>
            )
    }

    render() {
        log.info("PostAdsDetail.render ");
        let photo = this.props.photo;

        if (photo && photo.uri) {
            return (
                <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
                    <ImageBackground style={myStyles.imgItem} source={photo} >
                        {this._renderDeleteButton()}
                        {this._renderCoverTitle()}
                    </ImageBackground>
                </TouchableOpacity>
            );
        } else {
            return (
                <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
                    <View style={[myStyles.imgItem, { borderStyle: 'dashed', borderColor: gui.mainColor, borderWidth:1 }]}>
                        <RelandIcon name="plus" color={gui.mainColor}
                                    mainProps={myStyles.captureIcon}
                                    size={22} textProps={{ paddingLeft: 0 }}
                                    noAction={true}
                                    />
                        {this._renderCoverTitle()}
                    </View>
                </TouchableOpacity>
            );
        }

    }
}

/**
 * ## Styles
 */
var myStyles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    arrowIcon: {
        flexDirection: "row",
        alignItems: "flex-end",
        paddingRight: 4
    },
    headerSeparator: {
        marginTop: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    imgList: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: 17,
        paddingRight: 10,
        backgroundColor: 'white'
    },
    mimgList: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        paddingLeft: 12,
        paddingRight: 10,
        backgroundColor: 'white'
    },
    imgItem: {
        width: (width - 50) / 4,
        height: (width - 50) / 4,
        backgroundColor: "white",
        justifyContent: 'center',
        borderWidth: 0,
        marginLeft: 5,
        borderColor: gui.separatorLine,
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        padding: 4,
        paddingRight: 10,
        height: 30,
        borderColor: 'lightgray',
        borderWidth: 1,
        borderRadius: 5,
        margin: 5,
        width: 80,
        textAlign: 'right',
        alignSelf: 'center'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily
    },
    grayLabel: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#BBBBBB',
        paddingRight: 3
    },
    button: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: 'transparent',
        margin: 15
    },
    buttonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchListButton: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: gui.mainColor,
        height: 44
    },
    searchButton: {
        alignItems: 'center',
        justifyContent: 'flex-end',
        position: 'absolute',
        bottom: 0

    },
    categoryTitle: {
        flexDirection: "row",
        justifyContent: 'space-between',
        paddingRight: 8,
        paddingLeft: 17,
        paddingTop: 8,
        paddingBottom: 8,
        // borderTopWidth: 0,
        // borderTopColor: '#f8f8f8',
        backgroundColor: '#f8f8f8'
    },
    categoryText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent: 'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    scrollView: {
        backgroundColor: 'white'
    },
    picker: {
        margin: 5,
        width: 200
    },
    picker2: {
        margin: 5,
        marginLeft: 20,
        marginRight: 15,
        width: width - 35
    },
    loadingContent: {
        position: 'absolute',
        top: -23,
        left: width / 2 - 19,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: height / 2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    deleteContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.5,
        top: 2,
        right: 2,
        alignSelf: 'auto'
    },
    deleteButton: {
        alignItems: 'center'
    },
    coverContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.8,
        bottom: 2,
        left: 2,
        alignSelf: 'auto'
    },
    coverText: {
        alignItems: 'center',
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    addViewBottom:{
        height:30,
        width:width,
        backgroundColor:'#fff'
    },
    viewModalStyle : {
        justifyContent: 'flex-start',
        height: 180,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal:{
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton:{
        backgroundColor: 'transparent',
        height: 106,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal:{
        height: 52,
        width: width -28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textDelete:{
        color:'#f43838',
        fontSize:17,
        fontFamily:gui.fontFamily,
        fontWeight:'400'
    },
    lineSpaceButton:{
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewSwipeButton2:{
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },

});

export default connect(mapStateToProps, mapDispatchToProps)(NPostAdsDetail);

