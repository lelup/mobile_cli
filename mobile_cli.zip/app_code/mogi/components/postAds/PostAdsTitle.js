'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import React, {Component} from 'react';

import { Text, View, StyleSheet, TextInput, StatusBar, TouchableOpacity } from 'react-native'

import KeyboardSpacer from 'react-native-keyboard-spacer';

import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();

import TruliaIcon from '../TruliaIcon';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const actions = [
    globalActions,
    postAdsActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}



class PostAdsTitle extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        var {chiTiet} = this.props.postAds;

        this.state = {
            toggleState: false,
            chiTiet: chiTiet
        }
    }

    render() {
        var chiTietHolder = 'Mô tả những gì bạn muốn bán (cho thuê).\r\nVí dụ: Địa chỉ, diện tích, giá, hướng nhà...';
        var headerTitle = "Mô tả";
        var {toggleState, chiTiet} = this.state;
        var inputHeight = toggleState ? height-336 : height-110;
        return (
            <View style={myStyles.container}>
                <View style={myStyles.search}>
                    <View style={myStyles.customPageHeader}>
                        {/*<TruliaIcon onPress={this._onBack.bind(this)}
                                    name="arrow-left" color={gui.mainTextColor} size={26}
                                    mainProps={myStyles.backButton} text={this.props.backTitle}
                                    textProps={myStyles.backButtonText} >
                        </TruliaIcon>*/}
                        <TouchableOpacity style={myStyles.backButton}
                                          onPress={this._onBack.bind(this)}
                        >
                            <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} />
                        </TouchableOpacity>
                        <View style={myStyles.customPageTitle}>
                            <Text style={myStyles.customPageTitleText}>
                                {headerTitle}
                            </Text>
                        </View>
                        <TouchableOpacity style={myStyles.viewHuy}
                                          onPress={this._onXongDiaChi.bind(this)}
                        >
                            <Text style={[myStyles.customPageTitleText, {fontWeight: '400', fontSize: 15, color: gui.mainColor, marginTop: 3}]}>
                                Xong
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={myStyles.headerSeparator} />
                <View style={{marginTop: 5, marginLeft: 15, marginRight: 15}}>
                    <TextInput
                        secureTextEntry={false}
                        multiline={true}
                        autoFocus={true}
                        autoCorrect={false}
                        style={[myStyles.input, {height: inputHeight}]}
                        placeholder={chiTietHolder}
                        value={chiTiet}
                        onChangeText={(text) => this.onValueChange(text)}
                    />
                </View>
                <KeyboardSpacer onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>
            </View>
        )
    }


    _onXongDiaChi(){
        let {chiTiet} = this.state;
        this.props.onComplete(chiTiet);
        this.props.actions.onPostAdsFieldChange("chiTiet", chiTiet);
        Actions.pop();
    }

    onKeyboardToggle(toggleState) {
        this.setState({toggleState: toggleState});
    }

    onValueChange(value) {
        this.setState({chiTiet : value});
    }

    _onBack() {
        Actions.pop();
    }


}

/**
 * ## Styles
 */
var myStyles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    headerSeparator: {
        marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#fff',
        height: 64
    },
    customPageTitle: {
        left:50,
        right:50,
        marginTop: 28,
        marginBottom: 10,
        position: 'absolute'
    },
    viewHuy:{
        position: 'absolute',
        right: 0,
        width: 60,
        backgroundColor: 'transparent',
        alignItems: 'center',
        marginTop: 28
    },
    customPageTitleText: {
        color: gui.mainTextColor,
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: gui.mainTextColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    search: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: '#8A8A8A'
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        padding: 4,
        borderColor: '#EFEFEF',
        borderWidth: 0,
        borderRadius: 5,
        margin: 5,
        width: width - 30,
        alignSelf: 'center'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(PostAdsTitle);

