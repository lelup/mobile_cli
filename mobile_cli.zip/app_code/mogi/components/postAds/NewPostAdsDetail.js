import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    ImageBackground,
    Alert,
    ScrollView,
    TextInput,
    Switch,
    StatusBar,
    Animated,
    Platform,
    TouchableWithoutFeedback,
    Keyboard
} from 'react-native';

import Camera from 'react-native-camera';
const Permissions = require('react-native-permissions');
import OfflineBar from '../line/OfflineBar';
import CheckDot from '../detail/CheckDot';
import ImageResizer from 'react-native-image-resizer';
var Intercom = require('react-native-intercom');
import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Modal from 'react-native-modalbox';
import GiftedSpinner from 'react-native-gifted-spinner';
import moment from 'moment';
import userApi from '../../lib/userApi';
let { width, height } = utils.getDimensions();
import placeUtil from '../../lib/PlaceUtil';
import utils from '../../lib/utils';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import FullLine from '../line/FullLine';
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import TextInputAuto from './TextInputAuto';
import DanhMuc from '../../assets/DanhMuc';
import Toast, { DURATION } from '../toast/Toast';
import SegmentedControl3 from '../SegmentedControl3';
import cfg from "../../cfg";
import FunctionModal from '../FunctionModal';
import KeyboardSpacer from 'react-native-keyboard-spacer';

import PackageUpdater from './PostAdsPackageUpdater';

import PostOnWebsites from './PostOnWebsites';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupActions from '../../reducers/group/groupActions';

const actions = [
    globalActions,
    postAdsActions,
    adsMgmtActions,
    meActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let count = 0;
let uploadFiles = [];
let errorMessage = '';

class NewPostAdsDetail extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');

        log.info('NewPostAdsDetail constructor', props.postAds)
        errorMessage = this.props.postAds.error;
        this.onSeeGuidePost = this.onSeeGuidePost.bind(this)
        let adsID = props.postAds.id;

        let diaChiChiTiet = props.postAds.place ? props.postAds.place.diaChiChiTiet : '';

        let noiDungChiTiet = props.postAds.chiTiet;

        let geo = props.postAds.place.geo;

        let diaChinhFullName = placeUtil.getDiaChinhFullName(props.postAds.place);
        let diaChiDuAn = diaChinhFullName;

        let { selectedDuAn } = this.props.postAds;
        let placeType = DanhMuc.placeType.DIA_DIEM;
        if (selectedDuAn && selectedDuAn.placeName) {
            placeType = DanhMuc.placeType.DU_AN;
            let { huyen, tinh } = props.postAds.place.diaChinh;
            diaChiDuAn = selectedDuAn.placeName + ', ' + huyen + ', ' + tinh;
        }

        let { loaiTin } = props.postAds;

        let selectedGroup = this._initSelectedGroup(props, props.postAds.groupID);

        this._firstDisplay = true;
        this._listHeight = 0;
        this._contentHeight = 0;
        this._scrollToBottomOnNextRender = false;
        this._scrollToPreviousPosition = false;
        this.listViewMaxHeight = height - 112;

        this.state = {
            namePostLine: false,
            banGapValue: true,
            newLoaiTin: null,
            //====
            uploadUrls: [],
            thumbnailUrl: null,
            chiTietExpanded: true,
            toggleState: false,
            editGia: false,
            showNamXayDung: false,
            initNamXayDung: '',
            inputNamXayDung: '',
            namXayDung: null,
            diaChinhFullName: diaChinhFullName,
            geo: geo,
            placeType: placeType,
            diaChiDuAn: diaChiDuAn,
            diaChiChiTiet: diaChiChiTiet,
            noiDungChiTiet: noiDungChiTiet,
            adsID: adsID,
            showMoreContent: false,
            deletedPhoto: null,
            onCancelling: false,
            photos: props.postAds.photos,
            isOpenImagePicker: false,
            goiVipActived: false,
            websiteActived: false,
            allServices: [],
            modalChonNoiDang: false,
            sites: [],
            postToWebsitesServices: [{ fees: [{ price: 0 }] }],
            selectedSites: [],
            selectedWebsitesServiceIndex: 0,
            isSelectedAll: false,
            selectedGroup: selectedGroup,
            showAllGroup: false,
            height: new Animated.Value(this.listViewMaxHeight),
            isNamXayDungFocus: false,
            isDienTichFocus: false,
            postAdsModal: false,
            loaiTin: loaiTin,
            postToLandber: false
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.postAds.photos !== this.props.postAds.photos) {
            this.setState({ photos: nextProps.postAds.photos });
            let place = nextProps.postAds.place;
            if (!place || !place.geo || !place.geo.lat || !place.geo.lon) {
                this.getAdsLocation(nextProps.postAds.photos);
            }
        }
        if (nextProps.postAds.groupID !== this.props.postAds.groupID) {
            let selectedGroup = this._initSelectedGroup(nextProps, nextProps.postAds.groupID);
            this.setState({ selectedGroup: selectedGroup });
        }

        if (nextProps.postAds.loaiTin !== this.props.postAds.loaiTin) {
            this.setState({ loaiTin: nextProps.postAds.loaiTin });
        }
    }

    componentWillMount() {
        let { place, photos, lienHe } = this.props.postAds;
        let adsID = this.props.postAds.id;
        let { currentUser } = this.props.global;

        if (!adsID || adsID.length <= 0) {
            let lienHe = {
                tenLienLac: currentUser.fullName,
                showTenLienLac: true,
                phone: currentUser.phone,
                showPhone: true,
                email: currentUser.email,
                showEmail: true
            };
            this.props.actions.onPostAdsFieldChange("lienHe", lienHe);
        }

        // this.props.actions.findAllService(). then( e => {
        //     if (e.status ==0 ){
        //         let allViTriService = e.services.filter( (e) => {
        //             return e.category == "Vị trí"
        //         }).sort((a, b) => b.level - a.level);
        //         this.setState({allServices: allViTriService});
        //         this._getAllWebsiteService(allViTriService);
        //     }
        // });

        this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
        // this.props.actions.onHideChatIconChange(true);

        if (place && place.geo && place.geo.lat && place.geo.lon)
            return;

        this.getAdsLocation(photos);
    }

    componentDidMount() {
        this.scrollResponder = this._scrollView.getScrollResponder();
        // this.validatePostAds();
    }

    _getAllWebsiteService(allViTriService) {
        this.props.actions.findAllWebsiteService().then(e => {
            // log.info('=======service', e);
            if (e.status == 0 && e.services && e.services.length > 0) {
                let services = e.services;
                let selectedIndex = 0;
                let sites = services[selectedIndex].sites;
                let isLackMoney = this._isLackServiceMoney(allViTriService, services[selectedIndex]);
                let hasPostAdsToOtherWebsite = this.props.hasPostAdsToOtherWebsite;
                let selectedSites = isLackMoney || hasPostAdsToOtherWebsite ? [] : sites;
                let isSelectedAll = !isLackMoney && !hasPostAdsToOtherWebsite;
                this.setState({ sites: sites, selectedSites: selectedSites, isSelectedAll: isSelectedAll, postToWebsitesServices: services, selectedWebsitesServiceIndex: selectedIndex });
            }
        });
    }

    _isLackServiceMoney(allServices, postToWebsitesService) {
        let { main, bonus } = this.props.global.currentUser.account;
        let postToWebsitesServiceFee = postToWebsitesService ? postToWebsitesService.fees[0].price : 0;
        let serviceFee = allServices && allServices.length > 0 ? allServices[0].fees[0].price : 0;
        let oldAdsID = this.state.adsID;
        let active = this.props.active;
        let minFee = oldAdsID && oldAdsID.length > 0 && active ? postToWebsitesServiceFee : postToWebsitesServiceFee + serviceFee;
        return main < postToWebsitesServiceFee || main + bonus < minFee;
    }

    _isLackMoney(postToWebsitesService) {
        let { allServices } = this.state;
        return this._isLackServiceMoney(allServices, postToWebsitesService);
    }

    _setSelectedWebsitesService(value) {
        this.setState({ selectedWebsitesServiceIndex: value });
    }

    validatePostAds(callback) {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.onPostAdsFieldChange("uploading", true);
        this.props.actions.validatePostAds({ userID: userID }, token).then(
            (res) => {
                this.props.actions.onPostAdsFieldChange("uploading", false);
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    callback && callback();
                }
            });
    }

    getAdsLocation(photos) {
        if (photos) {
            for (let i = 0; i < photos.length; i++) {
                if (photos[i].location && photos[i].location.longitude && photos[i].location.latitude) {
                    let geo = {
                        "lat": photos[i].location.latitude,
                        "lon": photos[i].location.longitude
                    };
                    this.setState({ geo: geo });
                    return;
                }
            }
        }

        this.getCurrentLocation();
    }

    getCurrentLocation() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                let geo = {
                    "lat": position.coords.latitude,
                    "lon": position.coords.longitude
                };
                this.setState({ geo: geo });
            },
            (error) => {
            },
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    }

    render() {
        let { allServices, postToWebsitesServices, selectedWebsitesServiceIndex,
            goiVipActived, websiteActived } = this.state;
        if (goiVipActived) {
            let postToWebsitesFee = selectedWebsitesServiceIndex >= 0 ?
                postToWebsitesServices[selectedWebsitesServiceIndex].fees[0].price : 0;
            return (
                <PackageUpdater {...this.props} allServices={allServices}
                    postToWebsitesFee={postToWebsitesFee}
                    onPackageApply={this._onPackageApply.bind(this)}
                    onPackageCancel={this._onSelectWebsite.bind(this)} />
            );
        }
        if (websiteActived) {
            let { postAdsToOtherWebsite } = this.props.postAds;
            let couponCode = postAdsToOtherWebsite &&
                postAdsToOtherWebsite.service && postAdsToOtherWebsite.service.couponCode || '';
            return (
                <PostOnWebsites {...this.props} onWebsiteDone={this._preUpdatePackage.bind(this)}
                    onWebsiteBack={this._onWebsiteBack.bind(this)}
                    isLackMoney={this._isLackMoney.bind(this)}
                    sites={this.state.sites}
                    selectedSites={this.state.selectedSites}
                    isSelectedAll={this.state.isSelectedAll}
                    postToWebsitesServices={this.state.postToWebsitesServices}
                    selectedWebsitesServiceIndex={this.state.selectedWebsitesServiceIndex}
                    setSelectedWebsitesService={this._setSelectedWebsitesService.bind(this)}
                    onSelectionsChange={this._onSelectionsChange.bind(this)}
                    onSelectAll={this._onSelectAll.bind(this)}
                    onPackagePress={this._onPackagePress.bind(this)}
                    resetSelectedSites={this._resetSelectedSites.bind(this)}
                    couponCode={couponCode}

                />
            );
        }
        return this.renderMainView();
    }

    _resetSelectedSites() {
        this.setState({ selectedSites: [] });
    }

    _onPackagePress(index) {
        let { postToWebsitesServices, isSelectedAll } = this.state;
        if (isSelectedAll) {
            let selectedPackage = postToWebsitesServices[index];
            let sites = [...selectedPackage.sites];
            this.setState({ selectedWebsitesServiceIndex: index, sites: sites, selectedSites: sites });
        }
    }

    _onSelectAll() {
        let isSelectedAll = this.state.isSelectedAll;
        if (this.props.hasPostAdsToOtherWebsite && !isSelectedAll) {
            Alert.alert(
                'Thông báo',
                'Tin này đã đăng ký đăng trên nhiều websites ở lần đăng tin trước. Bạn có muốn đăng lại trên nhiều websites, '
                + 'tài khoản chính của bạn sẽ bị trừ tiền',
                [
                    { text: 'Hủy', onPress: () => { }, style: 'cancel' },
                    { text: 'Đồng ý', onPress: () => { this._doSelectAll() } },
                ],
            );
        } else {
            this._doSelectAll();
        }
    }

    _doSelectAll() {
        let { postToWebsitesServices, selectedWebsitesServiceIndex, sites, selectedSites, isSelectedAll } = this.state;
        let newSites = sites;
        let newSelectedSites = sites;
        let selectedPackageIndex = selectedWebsitesServiceIndex;
        if (isSelectedAll) {
            selectedPackageIndex = -1;
            newSites = [...postToWebsitesServices[0].sites];
            newSelectedSites = [];
        } else if (selectedPackageIndex == -1) {
            selectedPackageIndex = 0;
            newSites = [...postToWebsitesServices[0].sites];
            newSelectedSites = [...postToWebsitesServices[0].sites];
        }
        // let totalPrice = isSelectedAll ? 0 : util.addCommas(this.props.fee);
        this.setState({
            selectedWebsitesServiceIndex: selectedPackageIndex,
            selectedSites: newSelectedSites,
            sites: newSites,
            isSelectedAll: !isSelectedAll
            // numberOfWebs: selectedSites.length, totalPrice: totalPrice
        });
    }

    _onSelectionsChange(selectedSites) {
        // let totalPrice = util.addCommas(selectedSites.length*2000);
        // this.setState({selectedSites: selectedSites, numberOfWebs: selectedSites.length, totalPrice: totalPrice});
    }

    renderMainView() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderButton()}
                <FullLine />

                {this.renderContentAgentPost()}

                {this._openImagePicker()}
                {this._renderLoadingView()}
                {this._openModalNoiDang()}
            </View>
        );
    }

    renderContentAgentPost() {
        return (
            <View style={{ flex: 1 }}>
                {this._renderBody()}
                {this._renderBottomTab()}

                {this.renderModalPostAds()}
                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={45}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    }

    renderModalPostAds() {
        return (
            <Modal isOpen={this.state.postAdsModal}
                onClosed={this.outModalPostAds.bind(this)}
                style={styles.viewModalShareAds}
                position={"top"}
                entry={"top"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this.renderModalPostAdsContent()}
            </Modal>
        )
    }

    outModalPostAds() {
        this.setState({
            postAdsModal: false
        })
    }

    renderModalPostAdsContent() {
        return (
            <View style={styles.viewShareAds}>
                <View style={styles.viewTriangle}></View>
                <TouchableOpacity style={styles.viewShareTopContent}
                    onPress={this.onAdsMuaPress.bind(this)}
                >
                    <View style={styles.checkAds}>
                        <CheckDot name={'ban'}
                            onPress={this.onAdsMuaPress.bind(this)}
                            selected={this.state.loaiTin == 'ban'}
                            mainProps={styles.viewSaleState}></CheckDot>
                    </View>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15, marginLeft: 4 }]}>Đăng tin bán</Text>
                </TouchableOpacity>
                <View style={styles.lineStyles} />
                <TouchableOpacity style={styles.viewShareBottomContent}
                    onPress={this.onAdsThuePress.bind(this)}
                >
                    <View style={styles.checkAds}>
                        <CheckDot name={'thue'}
                            onPress={this.onAdsThuePress.bind(this)}
                            selected={this.state.loaiTin == 'thue'}
                            mainProps={styles.viewSaleState}></CheckDot>
                    </View>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15, marginLeft: 4 }]}>Đăng tin cho thuê</Text>
                </TouchableOpacity>
            </View>
        )
    }

    onAdsMuaPress() {
        this.setState({
            postAdsModal: false
        })

        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        this.props.actions.onPostAdsFieldChange('loaiTin', 'ban');
        this.props.actions.onPostAdsFieldChange('gia', null);
        this.props.actions.onPostAdsFieldChange('donViTien', 0);
    }

    onAdsThuePress() {
        this.setState({
            postAdsModal: false
        })

        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        this.props.actions.onPostAdsFieldChange('loaiTin', 'thue');
        this.props.actions.onPostAdsFieldChange('gia', null);
        this.props.actions.onPostAdsFieldChange('donViTien', 0);
    }

    onPostAdsChangeValue() {
        log.info('==========> unShareValue')
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _openModalNoiDang() {
        return (
            <Modal isOpen={this.state.modalChonNoiDang}
                onClosed={this._outContentModal.bind(this)}
                style={styles.viewLoaiTinStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
                animationDuration={200}
            >
                {this._renderNoiDangContent()}
            </Modal>
        );
    }

    _outContentModal() {
        this.setState({
            modalChonNoiDang: false
        });
        this.props.actions.onPostAdsFieldChange("uploading", false);
    }

    _renderNoiDangContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Nơi đăng tin</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>
                <TouchableOpacity style={styles.touchModalSapxep}
                    onPress={() => { this._onGroupAgentPost() }}>
                    <Text style={styles.textSapxep}>Chọn sàn đăng tin</Text>
                    <View style={styles.viewTickSapxep}>
                        <TruliaIcon
                            name="arrow-right" color={'#dcdcdc'} size={20}
                            mainProps={styles.viewCheckIcon}
                        />
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.touchModalSapxep}
                    onPress={() => { this._onLandberPost() }}>
                    <Text style={styles.textSapxep}>Đăng tin lên Landber</Text>
                    <View style={styles.viewTickSapxep}>
                        <TruliaIcon
                            name="arrow-right" color={'#dcdcdc'} size={20}
                            mainProps={styles.viewCheckIcon}
                        />
                    </View>
                </TouchableOpacity>

            </View>
        )
    }


    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._outContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );

    }

    _renderHeaderButton() {
        let uploading = this.isUploading();
        let { loaiTin } = this.props.postAds;
        let loaiTinText = loaiTin === 'ban' ? 'Đăng tin bán' : 'Đăng tin cho thuê';
        let iconHeader = !this.state.postAdsModal ? 'chevron-down' : 'chevron-up'
        return (
            <View style={styles.viewHeaderButton}>
                {/*<TouchableOpacity style={styles.viewBackIcon}
                 onPress={this._onBackButton.bind(this)}>
                 <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} style={{ marginLeft: 0 }} />
                 </TouchableOpacity>*/}
                <TouchableOpacity style={styles.viewBackIcon}
                    onPress={this._onBackButton.bind(this)}
                >
                    <Text style={styles.textSavePost}>Hủy</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.viewTextLabel}
                    onPress={this._onPressLoaiTinChange.bind(this)}
                >
                    <View style={styles.viewSubLabel}>
                        <Text style={[styles.textSavePost, { color: gui.mainTextColor2, marginTop: 5 }]}>{loaiTinText}</Text>
                        <View style={{ marginLeft: 2 }}>
                            <MaterialCommunityIcons name={iconHeader} size={26} color={gui.mainTextColor} />
                        </View>
                    </View>
                </TouchableOpacity>

                {/*uploading ?
                    <View style={styles.viewTextSave}>
                        <Text style={styles.textSavePost}>Lưu</Text>
                    </View> :
                    <TouchableOpacity style={styles.viewTextSave}
                                      onPress={this._onPressSavePost.bind(this)}
                    >
                        <Text style={styles.textSavePost}>Lưu</Text>
                    </TouchableOpacity>*/
                }
            </View>
        );
    }

    _renderLoaiTinDang() {
        let { loaiTin } = this.props.postAds;
        let loaiTinText = loaiTin === 'ban' ? 'BÁN' : 'CHO THUÊ';
        let textSwitchPress = loaiTin === 'ban' ? 'Chuyển sang tin Cho Thuê' : 'Chuyển sang tin Bán';
        return (
            <View style={styles.viewLoaiTinDang}>
                <View style={styles.loaiTinContent}>
                    <Text style={styles.textLoaiTin}>{loaiTinText}</Text>
                </View>
                <TouchableOpacity style={styles.viewChangeLoaiTin}
                    onPress={this._onPressLoaiTinChange.bind(this)}
                >
                    <RelandIcon name="resend" color={gui.mainAgentColor}
                        mainProps={{ marginRight: 6, marginTop: 12 }}
                        size={20} textProps={{ paddingLeft: 0 }}
                        noAction={true}
                    />
                    <Text style={styles.textChange}>{textSwitchPress}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _onPressLoaiTinChange() {
        let { loaiTin } = this.props.postAds;

        this.setState({
            postAdsModal: true
        });
        // let newLoaiTin = loaiTin === 'ban' ?  'thue' : 'ban';
        // this._onPostAdsValueChange('loaiTin', newLoaiTin);
        // this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        // this.props.actions.onPostAdsFieldChange('gia', null);
        // this.props.actions.onPostAdsFieldChange('donViTien', 0);

    }

    _renderBody() {
        let { loaiTin } = this.props.postAds;
        let priceTitle = loaiTin === 'ban' ? 'Giá bán' : 'Giá cho thuê';
        let guideContent = this.props.global.help.initialPostAgent;
        return (
            <View style={{ flex: 1 }}>
                <Animated.View
                    style={{
                        height: this.state.height,
                        justifyContent: 'flex-end',
                    }}

                >

                    <ScrollView
                        automaticallyAdjustContentInsets={false}
                        showsVerticalScrollIndicator={false}
                        vertical={true}
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        ref={(scrollView) => { this._scrollView = scrollView; }}
                        onLayout={this.onLayout.bind(this)}
                        onContentSizeChange={this.onContentSizeChange.bind(this)}
                        // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
                        onKeyboardWillShow={this.onKeyboardWillShow.bind(this)}
                        onKeyboardDidShow={this.onKeyboardDidShow.bind(this)}
                        // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
                        onKeyboardWillHide={this.onKeyboardWillHide.bind(this)}
                        onKeyboardDidHide={this.onKeyboardDidHide.bind(this)}
                        style={styles.viewBody}>
                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                            style={{ flex: 1 }}
                        >
                            <View style={{ flex: 1 }}>
                                {/*this._renderChonSan()*/}
                                {/*<FullLine style={[styles.lineStyle, {width: width}]}/>*/}
                                {!guideContent ? this.renderGuideAgentPost() : null}
                                {this._renderNamePost()}
                                {this._renderImagePost()}

                                {this._renderBasicInfo('THÔNG TIN CƠ BẢN')}
                                {this._renderGiaDetail()}
                                {this._renderKieuNha()}
                                {this._renderDuAn()}
                                {this._renderDiaChi()}
                                <FullLine style={[styles.lineStyle, { width: width }]} />
                                {this._renderPropSeparator()}
                                <FullLine style={[styles.lineStyle, { width: width }]} />
                                {this._renderKetNoiCungCau()}
                                {this._renderBanGap()}
                                {this._renderChinhChu()}

                                {this._renderBasicInfo('THÔNG TIN CHI TIẾT')}
                                {this._renderDienTich()}
                                {this._renderHuongNha()}
                                {this._renderLienHe()}
                                {this._renderMoTa()}

                                {this._renderMoreInfo()}

                                {/*this._renderPostToLandber()*/}

                                {/*{this._renderSamePrice()}*/}
                            </View>
                        </TouchableWithoutFeedback>
                    </ScrollView>

                </Animated.View>
            </View>
        )
    }

    renderGuideAgentPost() {
        let guideImg = require('../../assets/image/guide_agent_post.png');
        let guideTitle = 'Giúp bạn đăng tin nhanh hơn';
        let guideContent = 'Chúng tôi đã phát triển công cụ đăng tin trên web desktop. \n'
            + 'Hãy truy cập website app.landberagent.com để đăng tin nhanh hơn';
        return (
            <View style={styles.viewGuideAgentPost}>
                <View style={styles.viewImageGuide}>
                    <Image
                        source={guideImg}
                        style={styles.imageGuideStyle}
                        resizeMode={'cover'}
                    />
                </View>
                <View style={styles.guidePostContent}>
                    <Text style={[styles.textChange, { color: gui.textPostAds, fontSize: 17 }]}>{guideTitle}</Text>
                    <Text style={[styles.textChange, { color: gui.textPostAds, fontWeight: 'normal', marginTop: 7 }]}>{guideContent}</Text>
                </View>
                <TouchableOpacity style={styles.viewPressSee}
                    onPress={this.onSeeGuidePost}
                >
                    <FontAwesomeLight name="times"
                        size={19}
                        color={gui.textShare}
                        noAction={true}
                        iconOnly={true}
                    />
                </TouchableOpacity>
            </View>
        )
    }

    onSeeGuidePost() {
        // local storage initialPostAgent
        this.props.actions.onHelpedModalChange('initialPostAgent', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialPostAgent = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _renderPostToLandber() {
        let optionText = 'Đăng lên Landber';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textKieuNha}>{optionText}</Text>
                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this.onPostToLandberChange()}
                            value={this.state.postToLandber}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    onPostToLandberChange() {
        this.setState({ postToLandber: !this.state.postToLandber });
    }

    onContentSizeChange(contentWidth, contentHeight) {
        this._contentHeight = contentHeight;
    }

    onLayout(event) {
        const layout = event.nativeEvent.layout;
        this._listHeight = layout.height;

        if (this._firstDisplay === true) {
            requestAnimationFrame(() => {
                this._firstDisplay = false;
                // this.scrollToBottom(false);
            });
        }
    }

    onKeyboardWillHide() {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight,
            duration: 150,
        }).start();
    }

    onKeyboardDidHide(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillHide(e);
        }

        // TODO test in android
        //if (this.props.keyboardShouldPersistTaps === false) {
        //     this.scrollToBottom();
        //}
    }

    onKeyboardWillShow(e) {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight - e.endCoordinates.height,
            duration: 200,
        }).start();
    }

    onKeyboardDidShow(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillShow(e);
        }

        setTimeout(() => {
            this.scrollToBottom();
        }, (Platform.OS === 'android' ? 200 : 100));
    }

    scrollToBottom(animated = null) {
        if (this.state.namePostLine ||
            !this.state.isNamXayDungFocus && !this.state.isDienTichFocus) {
            return;
        }
        if (this._listHeight && this._contentHeight && this._contentHeight > this._listHeight) {
            let scrollDistance = this._listHeight - this._contentHeight;
            if (!this.state.isNamXayDungFocus) {
                scrollDistance += 230;
            }

            if (this.scrollResponder && this.scrollResponder.scrollTo != undefined) {
                this.scrollResponder.scrollTo({
                    y: -scrollDistance,
                    x: 0,
                    animated: typeof animated === 'boolean' ? animated : true
                });
                // this.scrollView.scrollToEnd({animated: typeof animated === 'boolean' ? animated : true});
            }
        }
    }

    _renderPropSeparator() {
        return (
            <View style={{ height: 8, width: width, backgroundColor: '#F8F8F8' }} />
        )
    }

    _renderChonSan() {
        let daChonItems = [];
        let { selectedGroup, showAllGroup } = this.state;
        let index = 0;
        let groupList = selectedGroup;
        if (!showAllGroup) {
            groupList = selectedGroup.slice(0, 3);
        }
        groupList.forEach((one) => {
            let imgUrl = one.image;
            let imagePost = { uri: imgUrl };
            if (!imgUrl) {
                imagePost = require('../../assets/image/no_cover.jpg');
            }
            let defaultCover = require('../../assets/image/no_cover.jpg');
            daChonItems.push(<View key={index} style={styles.chonSanSubView}>
                <View style={styles.viewGroupDetail}>
                    <Image
                        source={imagePost}
                        defaultSource={defaultCover}
                        resizeMode={"cover"}
                        style={styles.viewAvatar}
                    />
                    <Text style={styles.chonSanText}>{one.name}</Text>
                </View>
                <View style={{ height: 53, justifyContent: 'center' }}>
                    <FontAwesomeLight name="times" color={'#363636'}
                        size={15}
                        onPress={this._onBoChonSanPress.bind(this, index)}
                        iconOnly={true}
                    />
                </View>
            </View>);
            index++;
        });

        let textColor = gui.mainAgentColor;
        let showAllGroupLabel = showAllGroup ? 'Thu gọn' : 'Tất cả sàn đã chọn';
        let showAllGroupIcon = showAllGroup ? 'chevron-up' : 'chevron-down';
        return (
            <View style={styles.viewChonSan}>
                <TouchableOpacity style={[styles.viewKieuNha, {
                    marginLeft: 16,
                    marginRight: 16,
                    marginBottom: 0
                }]}
                    onPress={this._onChonSan.bind(this)}
                    disabled={this.isUploading()}>
                    <Text style={styles.textKieuNha}>Chọn sàn đăng tin</Text>
                    <View style={styles.touchChonSan}>
                        <FontAwesomeLight name="plus" size={12} color={textColor} noAction={true} iconOnly={true} />
                        <Text style={[styles.textResult, { color: textColor, fontWeight: '300', marginLeft: 4 }]}>Thêm sàn</Text>
                    </View>
                </TouchableOpacity>
                <View style={[styles.daChonSubView, { marginBottom: 16 }]}>
                    {daChonItems}
                </View>
                {selectedGroup.length <= 3 ? null :
                    <TouchableOpacity style={[styles.viewMoreInfo, { marginTop: 0, marginBottom: 16 }]}
                        onPress={() => this.setState({ showAllGroup: !showAllGroup })}>
                        <Text style={styles.textMoreInfo}>{showAllGroupLabel}</Text>
                        <Icon name={showAllGroupIcon} color={gui.mainAgentColor} size={15} style={{ marginLeft: 5 }} />
                    </TouchableOpacity>
                }
            </View>
        );
    }

    _onBoChonSanPress(index) {
        let selectedGroup = this.state.selectedGroup;
        let selectedGroupID = selectedGroup[index] ? selectedGroup[index].groupID : '';
        let selectedGroupIDs = this.props.postAds.groupID || [];
        selectedGroupIDs = selectedGroupIDs.filter((one) => {
            return one != selectedGroupID
        });
        this.props.actions.onPostAdsFieldChange('groupID', selectedGroupIDs);
        selectedGroup = [...selectedGroup.slice(0, index), ...selectedGroup.slice(index + 1)];
        this.setState({
            selectedGroup: selectedGroup
        });
    }

    _getListGroup(props) {
        let listRelatedGroup = props.group.searchResult.listRelatedGroup;
        let userID = props.global.currentUser.userID;
        if (!listRelatedGroup || listRelatedGroup.length == 0) {
            return [];
        }
        return listRelatedGroup.filter((one) => {
            return one.createdBy == userID || one.joinStatus == 2
        }) || [];
    }

    _initSelectedGroup(props, groupID) {
        let selectedGroupID = groupID;
        if (props.groupID && !selectedGroupID) {
            selectedGroupID = [props.groupID];
        }
        let selectedGroup = [];
        if (selectedGroupID && selectedGroupID.length > 0) {
            let hashGroupID = {};
            selectedGroupID.forEach((one) => {
                hashGroupID[one] = true;
            });
            let listGroup = this._getListGroup(props);
            listGroup.filter((one) => {
                if (hashGroupID[one.groupID]) {
                    selectedGroup.push(one);
                }
            })
        }
        return selectedGroup;
    }

    _onChonSan() {
        let groupID = this.props.postAds.groupID;
        if (this.props.groupID && !groupID) {
            groupID = [this.props.groupID];
        }
        Actions.PostAdsJoinedGroup({
            groupID: groupID, onPress: this._doAfterChonSan.bind(this)
        });
    }

    _doAfterChonSan(selectedGroupIDs) {
        this.props.actions.onPostAdsFieldChange('groupID', selectedGroupIDs);
        let selectedGroup = this._initSelectedGroup(this.props, selectedGroupIDs);
        this.setState({ selectedGroup: selectedGroup });
        Actions.pop();
    }

    _renderImagePost() {
        let { photos } = this.state;
        if (!photos) {
            photos = [];
        }
        let indexArr = [];
        for (let i = -1; i < photos.length; i++) {
            if (i < 20) {
                indexArr.push(i)
            }
        }

        return (
            <View style={[styles.mimgList, styles.viewImagePost]}>
                <ScrollView horizontal={true}
                    showsHorizontalScrollIndicator={false}>
                    {indexArr.map((e) => { if (e < 20) return this._renderPhotoItem(e) })}
                </ScrollView>
            </View>
        )
    }

    _renderNamePost() {
        let borderColor = this.state.namePostLine ? gui.mainTextColor : 'lightgray';
        let border = this.state.namePostLine ? 1 : 0.5;
        let { title } = this.props.postAds;
        let titleLength = title && title.length || 0;
        let textLength = `${titleLength}/99`;
        return (
            <View style={[styles.viewNamePost, { width: width - 16, marginTop: 8, marginRight: 0 }]}>
                {/*<Text style={styles.textBaiDang}>Tên bài đăng</Text>*/}
                <View style={[styles.viewInputPost, { marginTop: 0 }]}>
                    <TextInputAuto
                        onBlur={() => this.onBlurNamePost()}
                        onFocus={() => this.onFocusNamePost()}
                        placeholder="Tiêu đề bài đăng..."
                        keyboardType="twitter"
                        placeholderTextColor={gui.colorMainBlur2}
                        style={styles.viewTextInput}
                        autoFocus={false}
                        autoCorrect={false}
                        underlineColorAndroid='rgba(0,0,0,0)'
                        onChangeText={(value) => this._onNamePostChange(value)}
                        value={this.props.postAds.title}
                        maxLength={99}
                    />
                    <View style={{ position: 'absolute', right: 0, width: 30, height: 12, alignItems: 'flex-end' }}>
                        <Text style={[styles.tieuDeLength, { textAlign: 'right' }]}>{textLength}</Text>
                    </View>
                </View>
                <FullLine style={[styles.lineStyle, { marginTop: 11, borderColor: borderColor, borderTopWidth: border, width: width - 16 }]} />
            </View>
        );
    }

    onFocusNamePost() {
        this.setState({
            namePostLine: true
        })
    }

    onBlurNamePost() {
        this.setState({
            namePostLine: false
        })
    }

    _onNamePostChange(value) {
        this.props.actions.onPostAdsFieldChange('title', value);
    }

    _renderPhotoItem(imageIndex) {
        let { photos } = this.state;
        if (!photos) {
            photos = [];
        }
        let photo = photos[imageIndex];

        return (
            <ImageItem imageIndex={imageIndex}
                key={imageIndex}
                photo={photo}
                onTakePhoto={this.onTakePhoto.bind(this)}
                onDeletePhoto={this.onDeletePhoto.bind(this)} />
        )
    }

    onTakePhoto(imageIndex) {
        this.props.actions.onPostAdsFieldChange('imageIndex', imageIndex);
        this._openModalImagePicker();
    }

    onDeletePhoto(imageIndex) {
        let { photos } = this.state;
        photos.splice(imageIndex, 1);
        this.setState({ deletedPhoto: imageIndex });
        this.props.actions.onPostAdsFieldChange('photos', photos);
    }

    _openImagePicker() {
        return (
            <Modal isOpen={this.state.isOpenImagePicker}
                onClosed={this._outModalImagePicker.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderModalImagePicker()}
            </Modal>
        );
    }

    _renderModalImagePicker() {
        let items = [
            { _text: 'Máy ảnh', _function: () => this.onCamera() },
            { _text: 'Bộ sưu tập', _function: () => this.onCameraRollView() },
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outModalImagePicker.bind(this)} />
        )
    }

    onCamera() {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {
                if (e) {
                    Permissions.requestPermission('photo')
                        .then(response => {
                            if (response == 'authorized') {
                                Actions.PostAds2({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
                            } else {
                                Alert.alert("Thông báo", gui.INF_PhotoAccess);
                            }
                        });
                } else {
                    Alert.alert("Thông báo", gui.INF_CameraAccess);
                }
            });
    }

    onCameraRollView() {
        Permissions.requestPermission('photo')
            .then(response => {
                if (response == 'authorized') {
                    Actions.CameraRollView2({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
                } else {
                    Alert.alert("Thông báo", gui.INF_PhotoAccess);
                }
            });
    }

    _openModalImagePicker() {
        dismissKeyboard();
        this.setState({ isOpenImagePicker: true });
    }

    _outModalImagePicker() {
        this.setState({
            isOpenImagePicker: false
        });
    }

    _renderBasicInfo(value) {
        return (
            <View style={styles.viewTextBasic}>
                <FullLine style={[styles.lineStyle, { width: width }]} />
                <Text style={[styles.textLoaiTin, {
                    fontSize: 13,
                    marginLeft: 16, marginRight: 16, marginTop: 10, marginBottom: 12
                }]}>{value}</Text>
                <FullLine style={[styles.lineStyle, { width: width }]} />
            </View>
        );
    }

    _renderKieuNha() {
        let textLoaiNha = this._getLoaiNhaValue();
        let textColor = textLoaiNha == 'Bất kỳ' ? gui.colorMainBlur : gui.mainTextColor;
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onLoaiNhaPressed()}>
                    <View style={styles.viewTitleGroup}>
                        <Text style={styles.textKieuNha}>Kiểu nhà</Text>
                        <Text style={[styles.label, { color: '#ff0000', fontSize: 15 }]}>*</Text>
                    </View>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textResult, { width: width - 130, color: textColor, textAlign: 'right', marginRight: 8 }]} numberOfLines={1}>{textLoaiNha}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderDuAn() {
        let textDuAn = this._getBanDoValue();
        let textColor = textDuAn == 'Chọn dự án, địa điểm' ? gui.colorMainBlur : gui.mainTextColor;
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onBanDoPressed()}>
                    <View style={styles.viewTitleGroup}>
                        <Text style={styles.textKieuNha}>Địa điểm/Dự án</Text>
                        <Text style={[styles.label, { color: '#ff0000', fontSize: 15 }]}>*</Text>
                    </View>
                    <View style={styles.touchKieuNha}>
                        {this.props.postAds.loadingDiaChinh ?
                            (
                                <View style={{ paddingLeft: 10, marginRight: 8 }}>
                                    <GiftedSpinner size="small" color="#8A8A8A" />
                                </View>
                            )
                            :
                            <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{textDuAn}</Text>
                        }
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderDiaChi() {
        let textDiaChi = this._getDiaChiValue();
        let textDuAn = this._getBanDoValue();
        if (textDuAn == 'Chọn dự án, địa điểm') {
            textDiaChi = 'Số nhà, tên đường' + textDiaChi;
        }
        let textColor = textDiaChi == 'Số nhà, tên đường' ? gui.colorMainBlur : gui.mainTextColor;
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onDiaChiPressed()}>
                    <Text style={styles.textKieuNha}>Địa chỉ</Text>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{textDiaChi}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    //
    // _renderMiniMap() {
    //     return(
    //         <View style={styles.viewMiniMap}></View>
    //     )
    // }

    _renderDienTich() {
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textKieuNha}>Diện tích (m²)</Text>
                    <TouchableOpacity style={styles.touchKieuNha}>
                        <TextInput
                            secureTextEntry={false}
                            keyboardType={'numeric'}
                            style={styles.dienTichInput}
                            placeholderTextColor={gui.colorMainBlur}
                            placeholder={'Nhập diện tích'}
                            value={this.props.postAds.dienTich && Number(this.props.postAds.dienTich) >= 0 ?
                                this.props.postAds.dienTich.toString() : ''}
                            onChangeText={(text) => this._onNumberValueChange("dienTich", text)}
                            onFocus={() => this._onDienTichFocus()}
                            onBlur={() => this._onDienTichBlur()}
                            maxLength={6}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _onDienTichFocus() {
        this.setState({ isDienTichFocus: true });
    }

    _onDienTichBlur() {
        this.setState({ isDienTichFocus: false });
    }

    _renderPhongNgu() {
        let { loaiNhaDat } = this.props.postAds;

        if (loaiNhaDat && [1, 2, 3, 4].indexOf(loaiNhaDat) >= 0) {
            return this._renderSegment(
                "Số phòng ngủ",
                DanhMuc.getAdsSoPhongNguValues(),
                this.props.postAds.soPhongNguSelectedIdx,
                this._onSegmentChanged.bind(this, 'soPhongNguSelectedIdx'),
                this.props.postAds.soPhongNguText, "soPhongNguText",
                (key, value) => this._onSegmentTextChanged(key, value));
        } else
            return;
    }

    _renderPhongTam() {
        let { loaiNhaDat } = this.props.postAds;

        if (loaiNhaDat && [1, 2, 3, 4].indexOf(loaiNhaDat) >= 0) {
            return this._renderSegment(
                "Số phòng tắm",
                DanhMuc.getAdsSoPhongTamValues(),
                this.props.postAds.soNhaTamSelectedIdx,
                this._onSegmentChanged.bind(this, 'soNhaTamSelectedIdx'),
                this.props.postAds.soNhaTamText, "soNhaTamText",
                (key, value) => this._onSegmentTextChanged(key, value));
        } else
            return;
    }

    _renderSoTang() {
        let { loaiTin, loaiNhaDat } = this.props.postAds;

        if ((loaiNhaDat && [2, 3, 4].indexOf(loaiNhaDat) >= 0 && loaiTin == 'ban')
            || (loaiNhaDat && [2, 3, 4, 5, 6].indexOf(loaiNhaDat) >= 0 && loaiTin == 'thue')
        ) {
            return this._renderSegment(
                "Số tầng",
                DanhMuc.getAdsSoTangValues(),
                this.props.postAds.soTangSelectedIdx,
                this._onSegmentChanged.bind(this, 'soTangSelectedIdx'),
                this.props.postAds.soTangText, "soTangText",
                (key, value) => this._onSegmentTextChanged(key, value));
        } else
            return;
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange, textValue, textField, onTextChange) {
        return (
            <SegmentedControl3 label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                onChange={onChange}
                textValue={textValue ? textValue.toString() : ''}
                textField={textField}
                onTextChange={onTextChange} placeholder={"Khác"}
                lineStyle={{ width: width - 16 }} />
        );
    }

    _onSegmentChanged(key, index) {
        this._onPostAdsValueChange(key, index);
        let value = '';
        if (key == 'soTangSelectedIdx') {
            value = DanhMuc.getAdsSoTangByIndex(index);
            this._onPostAdsValueChange('soTangText', value);
        }
        else if (key == 'soPhongNguSelectedIdx') {
            value = DanhMuc.getAdsSoPhongByIndex(index);
            this._onPostAdsValueChange('soPhongNguText', value);
        }
        else {
            value = DanhMuc.getAdsSoPhongTamByIndex(index);
            this._onPostAdsValueChange('soNhaTamText', value);
        }
    }

    _onSegmentTextChanged(key, val) {
        let maxValue = 7;

        this._onPostAdsValueChange(key, val);
        if (isNaN(val) || val == '') {
            val = (maxValue + 1).toString();
        }
        let value = Number(val) > maxValue ? -1 : Number(val) - 1;
        if (key == 'soTangText') {
            this._onPostAdsValueChange('soTangSelectedIdx', value);
        }
        else if (key == 'soPhongNguText') {
            this._onPostAdsValueChange('soPhongNguSelectedIdx', value);
        }
        else {
            this._onPostAdsValueChange('soNhaTamSelectedIdx', value);
        }
    }

    _renderMoTa() {
        let textMota = this._getChiTietValue();
        let textColor = textMota == 'Nhập mô tả' ? gui.colorMainBlur : gui.mainTextColor;
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onChiTietPressed()}>
                    <Text style={styles.textKieuNha}>Mô tả</Text>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{this._getChiTietValue()}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderLienHe() {
        let textMota = this._getChiTietValue();
        let textColor = textMota == 'Nhập mô tả' ? gui.colorMainBlur : gui.mainTextColor;
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onLienHePressed()}>
                    <Text style={styles.textKieuNha}>Liên hệ</Text>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{this._getLienHeValue()}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderMoreInfo() {
        let moreInfoLabel = this.state.showMoreContent ? 'Thu gọn' : 'Đặc điểm khác';
        let moreInfoIcon = this.state.showMoreContent ? 'chevron-up' : 'chevron-down';
        return (
            <View>
                {this.state.showMoreContent ? this._renderInfoExpand() : null}
                <TouchableOpacity style={styles.viewMoreInfo}
                    onPress={() => this._onMoreButtonPressed()}>
                    <Text style={styles.textMoreInfo}>{moreInfoLabel}</Text>
                    <Icon name={moreInfoIcon} color={gui.mainAgentColor} size={15} style={{ marginLeft: 5 }} />
                </TouchableOpacity>
            </View>
        );
    }

    _renderLoadingView() {
        if (this.isUploading()) {
            return (<View style={styles.resultContainer}>
                <View style={styles.loadingContent}>
                    <GiftedSpinner size="large" />
                </View>
            </View>)
        }
    }

    _renderInfoExpand() {
        return (
            <View>
                {this._renderPhongNgu()}
                {this._renderPhongTam()}
                {this._renderSoTang()}
                {this._renderNamXayDung()}
            </View>
        );
    }

    _renderHuongNha() {
        let textHuongNha = this._getHuongNhaValue();
        let textColor = textHuongNha == 'Bất kỳ' ? gui.colorMainBlur : gui.mainTextColor;
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onHuongNhaPressed()}>
                    <Text style={styles.textKieuNha}>Hướng nhà</Text>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{this._getHuongNhaValue()}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderNamXayDung() {
        return (
            <View style={[styles.viewEachInfo, { height: 'auto' }]}>
                <View style={styles.viewKieuNha}
                    disabled={this.isUploading()}>
                    <Text style={styles.textKieuNha}>Năm xây dựng</Text>
                    <TouchableOpacity style={styles.touchKieuNha}>
                        <TextInput
                            secureTextEntry={false}
                            keyboardType={'numeric'}
                            style={styles.dienTichInput}
                            placeholderTextColor={gui.colorMainBlur}
                            placeholder={'Nhập năm xây'}
                            value={this.props.postAds.namXayDung && Number(this.props.postAds.namXayDung) >= 0 ?
                                this.props.postAds.namXayDung.toString() : ''}
                            onChangeText={(text) => this._onNumberXayDungChange("namXayDung", text)}
                            onFocus={() => this._onNamXayDungFocus()}
                            onBlur={() => this._onNamXayDungBlur()}
                            maxLength={4}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _onNamXayDungFocus() {
        this.setState({ isNamXayDungFocus: true });
    }

    _onNamXayDungBlur() {
        this.setState({ isNamXayDungFocus: false });
    }

    _renderKetNoiCungCau() {
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textKieuNha}>Kết nối cung cầu</Text>
                    <TouchableOpacity style={styles.viewInfoMatching}>
                        <FontAwesomeSolid
                            name="info-circle"
                            size={15}
                            color={gui.textShare}
                            noAction={true}
                            iconOnly={true}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._onKetNoiCungCauChange()}
                            value={this.props.postAds.ketNoiCungCau ? true : false}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderChinhChu() {
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textKieuNha}>Chính chủ</Text>
                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._onChinhChuChange()}
                            value={this.props.postAds.chinhChuDangTin ? true : false}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _onChinhChuChange() {
        let { chinhChuDangTin } = this.props.postAds;
        this.props.actions.onPostAdsFieldChange('chinhChuDangTin', !chinhChuDangTin);
    }

    _onKetNoiCungCauChange() {
        let { ketNoiCungCau } = this.props.postAds;
        this.props.actions.onPostAdsFieldChange('ketNoiCungCau', !ketNoiCungCau);
    }

    _renderBanGap() {
        let { loaiTin } = this.props.postAds;
        let banGapText = loaiTin === 'ban' ? 'Bán gấp' : 'Thuê gấp';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textKieuNha}>{banGapText}</Text>
                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._onBanGapChange()}
                            value={this.props.postAds.banGap}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _onBanGapChange() {
        let { banGap } = this.props.postAds;
        this.props.actions.onPostAdsFieldChange('banGap', !banGap);
    }

    _renderGiaDetail() {
        let textGia = this._getGiaValue();
        let textColor = textGia == 'Nhập giá' ? gui.colorMainBlur : gui.mainTextColor;
        let giaBanText = 'Giá';
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    disabled={this.isUploading()}
                    onPress={() => this._onGiaPressed()}>
                    <View style={styles.viewTitleGroup}>
                        <Text style={styles.textKieuNha}>{giaBanText}</Text>
                        <Text style={[styles.label, { color: '#ff0000', fontSize: 15 }]}>*</Text>
                    </View>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{this._getGiaValue()}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _onGiaPressed() {
        let { loaiTin } = this.props.postAds;
        dismissKeyboard();
        this.setState({ editGia: true });
        Actions.PostAdsPrice({ loaiTin: loaiTin });
    }

    _getGiaValue() {
        let { gia, donViTien } = this.props.postAds;
        if (!gia) {
            return "Nhập giá";
        }
        let giaItem = DanhMuc.collectGiaDonViTien(gia, donViTien);
        this._onPostAdsValueChange('gia', giaItem.gia);
        this._onPostAdsValueChange('donViTien', giaItem.donViTien);
        return DanhMuc.getGiaForDisplay(giaItem.gia, giaItem.donViTien);
    }

    _renderSamePrice() {
        let textSamePrice = 'Những căn nhà tương tự tại khu vực của bạn hiện có giá bán trung bình là 30 triệu đồng/m2';
        return (
            <View style={styles.viewSamePrice}>
                <Text style={styles.textSamePrice}>{textSamePrice}</Text>
            </View>
        );
    }

    _renderBottomTab() {
        let uploading = this.isUploading();
        if (uploading) {
            return (
                <View style={styles.viewButtonTab}>
                    <View style={styles.viewTextPreview}>
                        <Text style={styles.textPreview}>Xem trước</Text>
                    </View>
                    <View style={styles.viewPostAdsButton}>
                        <View style={styles.postAdsButton}>
                            {this._getTextDangBai()}
                        </View>
                    </View>
                    <View style={styles.bottomLine}>
                        <FullLine style={{ width: width }} />
                    </View>
                </View>
            );
        }
        return (
            <View style={styles.viewButtonTab}>
                <View style={styles.viewTextPreview}>
                    <TouchableOpacity onPress={this._onPressPreview.bind(this)}>
                        <Text style={styles.textPreview}>Xem trước</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.viewPostAdsButton}>
                    <TouchableOpacity style={styles.postAdsButton}
                        onPress={() => this._onPostAdsAgent(this)}>
                        {this._getTextDangBai()}
                    </TouchableOpacity>
                </View>
                <View style={styles.bottomLine}>
                    <FullLine style={{ width: width }} />
                </View>
            </View>
        );
    }

    _onPressPreview() {
        let { uploadUrls } = this.state;
        let { id, maSo, loaiTin, loaiNhaDat, gia, donViTien, dienTich, matTien, namXayDung,
            soTangText, soPhongNguText, soNhaTamText, chiTiet, huongNha, duongTruocNha,
            place, selectedDiaChinh, selectedDuAn, lienHe, photos,
            nhaMoiXay, nhaLoGoc, otoDoCua, nhaKinhDoanhDuoc, noiThatDayDu, chinhChuDangTin, ketNoiCungCau, title, banGap } = this.props.postAds;

        let imageUrls = [];
        for (let i = 0; i < photos.length; i++) {
            let photo = photos[i];
            imageUrls.push(photo.uri);
        }
        for (let i = 0; i < uploadUrls.length; i++) {
            let uploadUrl = uploadUrls[i];
            let index = uploadUrl.index;
            if (index >= 0) {
                imageUrls[index] = uploadUrl.url;
            }
        }
        let image = { cover: '', images: [] };
        if (imageUrls.length > 0) {
            image.cover = imageUrls[0];
            image.images = imageUrls;
        }

        let loaiTinVal = (loaiTin === 'ban') ? 0 : 1;

        let currentUser = this.props.global.currentUser;
        let dangBoi = {
            "email": currentUser.email,
            "name": currentUser.fullName,
            "phone": currentUser.phone,
            "userID": currentUser.userID
        };

        // remove lienHe if no information
        if (lienHe
            && (!lienHe.tenLienLac || lienHe.tenLienLac.length <= 0)
            && (!lienHe.phone || lienHe.phone.length <= 0)
            && (!lienHe.email || lienHe.phone.length <= 0))
            lienHe = undefined;

        //remove placeId
        place.placeId = undefined;
        place.diaChiFullName = undefined;
        place.duAn = undefined;
        place.duAnFullName = undefined;

        let diaChi = '';
        if (selectedDuAn && selectedDuAn.placeName) {
            diaChi = place.diaChiChiTiet ? selectedDuAn.placeName + ", " + place.diaChiChiTiet : selectedDuAn.placeName;
        } else {
            diaChi = place.diaChiChiTiet;
        }
        if (selectedDiaChinh && selectedDiaChinh.duong) {
            diaChi = diaChi ? diaChi + ", " + selectedDiaChinh.duong : selectedDiaChinh.duong;
        }
        diaChi = diaChi ? diaChi + ", " + this.state.diaChinhFullName : this.state.diaChinhFullName;
        place.diaChi = diaChi;
        place.diaChiKhongDau = diaChi ? utils.locDauV2(utils.standardlizeName(diaChi)) : ''

        if (selectedDiaChinh) {
            place.diaChinh.codeTinh = selectedDiaChinh.codeTinh || undefined;
            place.diaChinh.codeHuyen = selectedDiaChinh.codeHuyen || undefined;
            place.diaChinh.codeXa = selectedDiaChinh.codeXa || undefined;
            place.diaChinh.codeDuong = selectedDiaChinh.codeDuong || undefined;
            place.diaChinh.tinh = selectedDiaChinh.tinh || undefined;
            place.diaChinh.huyen = selectedDiaChinh.huyen || undefined;
            place.diaChinh.xa = selectedDiaChinh.xa || undefined;
            place.diaChinh.duong = selectedDiaChinh.duong || undefined;
            place.diaChinh.tinhKhongDau = undefined;
            place.diaChinh.huyenKhongDau = undefined;
            place.diaChinh.xaKhongDau = undefined;
        }

        let giaItem = DanhMuc.calculateGia2(gia, donViTien, dienTich);

        if (selectedDuAn) {
            place.diaChinh.codeDuAn = selectedDuAn.duAn || undefined;
            place.diaChinh.duAn = selectedDuAn.placeName || undefined;
        } else {
            place.diaChinh.codeDuAn = undefined;
            place.diaChinh.duAn = undefined;
        }
        let ngayDangTin = moment().format('YYYYMMDD');

        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < photos.length; i++) {
            let filepath = photos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }
        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            return;
        }
        let titleStandardlized = title ? utils.standardlizeName(title) : '';
        let data = {
            "chiTiet": chiTiet,
            "title": title,
            "titleKhongDau": utils.locDauV2(titleStandardlized) || undefined,
            "chinhChuDangTin": chinhChuDangTin || undefined,
            "dangBoi": dangBoi,
            "dienTich": dienTich || -1,
            "gia": giaItem.gia || -1,
            "giaM2": giaItem.giaM2 || -1,
            "id": id,
            "image": image,
            "lienHe": lienHe,
            "loaiNhaDat": loaiNhaDat,
            "loaiTin": loaiTinVal,
            "maSo": maSo,
            "namXayDung": namXayDung,
            "ngayDangTin": ngayDangTin || undefined,
            "nhaKinhDoanhDuoc": nhaKinhDoanhDuoc || undefined,
            "nhaLoGoc": nhaLoGoc || undefined,
            "nhaMoiXay": nhaMoiXay || undefined,
            "noiThatDayDu": noiThatDayDu || undefined,
            "otoDoCua": otoDoCua || undefined,
            "place": place,
            "soPhongNgu": soPhongNguText,
            "soPhongTam": soNhaTamText,
            "soTang": soTangText,
            "source": "reway",
            "status": 5,
            "timeModified": ngayDangTin,
            "type": "Ads",
            "banGap": banGap || undefined,
            "huongNha": huongNha || -1,
            "matTien": matTien || undefined,
            "duongTruocNha": duongTruocNha && !isNaN(duongTruocNha) ? Number(duongTruocNha) : undefined,
        };
        Actions.PostAdsPreview({ data: data });
    }

    _getTextDangBai() {
        // let textContent = this.state.postToLandber ? 'Tiếp tục' : 'Đăng tin';
        let textContent = this.props.postAds.id ? 'Cập nhật' : "Lưu kho hàng";
        return (
            <Text style={[styles.textPreview, { fontWeight: '500', color: '#fff' }]}>{textContent}</Text>
        )
    }

    _onBanDoPressed() {
        dismissKeyboard();
        let { geo, placeType, diaChiDuAn } = this.state;
        let { selectedDuAn, selectedDiaChinh } = this.props.postAds;
        Actions.PostAdsMapView({
            showSuggestionPosition: true, onPress: this._onDiaChinhSelected.bind(this), location: geo,
            diaChi: diaChiDuAn, placeType: placeType, duAn: selectedDuAn, diaChinhInfo: selectedDiaChinh
        });
    }

    _onDiaChinhSelected(position) {
        if (!position.diaChinhInfo) {
            let diaChinhDuAn = {
                tinh: position.duAn && position.duAn.tinhName,
                codeTinh: position.duAn && position.duAn.tinh,
                huyen: position.duAn && position.duAn.huyenName,
                codeHuyen: position.duAn && position.duAn.huyen,
                xa: position.duAn && position.duAn.xaName,
                codeXa: position.duAn && position.duAn.xa
            };
            this._updateDiaChinhContent(position, diaChinhDuAn);
        } else {
            this._updateDiaChinhContent(position, position.diaChinhInfo);
        }
    }

    _updateDiaChinhContent(position, diaChinh) {
        let diaChi = position.diaChi;
        let { place } = this.props.postAds;
        place.geo = position.location;
        place.diaChinh.tinh = diaChinh.tinh;
        place.diaChinh.huyen = diaChinh.huyen;
        place.diaChinh.xa = diaChinh.xa;

        this.props.actions.onPostAdsFieldChange('selectedDuAn', position.duAn);

        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', diaChinh);

        this.props.actions.onPostAdsFieldChange('place', place);
        let diaChinhFullName = placeUtil.getDiaChinhFullName(place);

        this.setState({
            diaChinhFullName: diaChinhFullName, diaChiDuAn: diaChi,
            geo: place.geo, placeType: position.placeType
        });

    }

    _getBanDoValue() {
        if (!this.state.diaChinhFullName || this.state.diaChinhFullName.length <= 0 ||
            this.state.diaChinhFullName == "Chọn dự án, địa điểm") {
            return "Chọn dự án, địa điểm";
        } else {
            let diaChinhFullName = '';
            let geo = this.state.geo;
            if (geo && !isNaN(geo.lat)) {
                diaChinhFullName = geo.lat.toFixed(6) + ', ' + geo.lon.toFixed(6);
            }
            if (this.state.placeType != DanhMuc.placeType.DIA_DIEM) {
                let { selectedDuAn } = this.props.postAds;
                diaChinhFullName = selectedDuAn ? selectedDuAn.placeName : '';
            }

            if (this.state.diaChinhFullName.length > 30) {
                diaChinhFullName = diaChinhFullName.substring(0, 30) + '...';
            }
            return diaChinhFullName;
        }
    }

    //diaChinhFullName = parseFloat(geo.lat).toFixed(6) + ', ' + parseFloat(geo.lon).toFixed(6);

    _onMoreButtonPressed() {
        this.setState({ showMoreContent: !this.state.showMoreContent });
    }

    _onDiaChiPressed() {
        dismissKeyboard();
        Actions.PostAdsAddress({ diaChinhFullName: this.state.diaChinhFullName, onComplete: this._onDiaChiChosed.bind(this) });
    }

    _onDiaChiChosed(diaChiChiTiet) {
        this.setState({ diaChiChiTiet: diaChiChiTiet });
    }


    _getDiaChiValue() {
        let diaChinhFullName = this.state.diaChinhFullName;
        let diaChiChiTiet = this.state.diaChiChiTiet;
        let { selectedDuAn, selectedDiaChinh } = this.props.postAds;

        if (selectedDuAn && selectedDuAn.placeName) {
            diaChiChiTiet = diaChiChiTiet ? selectedDuAn.placeName + ', ' + diaChiChiTiet : selectedDuAn.placeName;
        }

        if (selectedDiaChinh && selectedDiaChinh.duong) {
            diaChiChiTiet = diaChiChiTiet ? diaChiChiTiet + ', ' + selectedDiaChinh.duong : selectedDiaChinh.duong;
        }

        if (diaChinhFullName && diaChinhFullName != "Chọn dự án, địa điểm") {
            diaChiChiTiet = diaChiChiTiet ? diaChiChiTiet + ', ' + diaChinhFullName : diaChinhFullName;
        }

        if (diaChiChiTiet.length > 26) {
            diaChiChiTiet = diaChiChiTiet.substring(0, 26) + '...';
        }

        return diaChiChiTiet;
    }



    _onBackButton() {
        let isUpdateAds = this.state.adsID && this.state.adsID.length > 0;
        this.setState({ onCancelling: true });
        Alert.alert('Thông báo', isUpdateAds ? 'Bạn muốn ngừng sửa tin ?' : 'Bạn muốn ngừng đăng tin ?',
            [{
                text: 'Hủy', onPress: () => {
                    log.info('PostAdsDetail - Cancel Pressed!');
                    this.setState({ onCancelling: false });
                }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    this.onRefreshPostAds(true);
                    // this.props.actions.onHideChatIconChange(false);
                    try {
                        if (isUpdateAds || this.props.owner == 'NewAgentPost') {
                            console.log('=================> NewAgentPost')
                            Actions.popTo('root');
                            Actions.NewAgentPost();
                        } else if (this.props.owner == 'GroupFilterResult') {
                            Actions.pop();
                        } else if (this.props.owner == 'AdsMgmt') {
                            Actions.popTo('root');
                            Actions.AdsMgmt();
                        } else {
                            Actions.Home({ type: 'reset' });
                        }
                    } catch (error) {
                        log.info("PostAdsDetail - Cancel Pressed error");
                        this.setState({ onCancelling: false });
                    }
                }
            }
            ]);
    }

    onRefreshPostAds(keepAdsID) {
        let { currentUser } = this.props.global;
        let adsID = keepAdsID ? this.props.postAds.id : null;

        let payload = {
            photos: [],
            imageIndex: 0,
            pickMode: 'new',
            loaiNhaDat: '',
            dienTich: null,
            matTien: null,
            namXayDung: null,
            soPhongNguSelectedIdx: -1,
            soPhongNguText: '',
            soNhaTamSelectedIdx: -1,
            soNhaTamText: '',
            soTangSelectedIdx: -1,
            soTangText: '',
            place: {
                duAn: '',
                duAnFullName: '',
                placeId: "ChIJKQqAE44ANTERDbkQYkF-mAI",
                diaChiChiTiet: '',
                diaChi: '',
                diaChinh: {
                    tinh: '',
                    huyen: '',
                    xa: '',
                    duAn: '',
                    duong: '',
                    tinhKhongDau: '',
                    huyenKhongDau: '',
                    xaKhongDau: '',
                    codeTinh: '',
                    codeHuyen: '',
                    codeXa: '',
                    codeDuAn: '',
                    codeDuong: ''
                },
                geo: { lat: '', lon: '' }
            },
            lienHe: {
                tenLienLac: currentUser.fullName,
                showTenLienLac: true,
                phone: currentUser.phone,
                showPhone: true,
                email: currentUser.email,
                showEmail: true
            },
            dangBoi: {
                userID: undefined,
                email: null,
                phone: null,
                name: null
            },
            huongNha: null,
            duongTruocNha: null,
            nhaMoiXay: null,
            nhaLoGoc: null,
            otoDoCua: null,
            nhaKinhDoanhDuoc: null,
            noiThatDayDu: null,
            chinhChuDangTin: null,
            gia: null,
            donViTien: 0,
            chiTiet: '',
            maSo: keepAdsID ? this.props.postAds.maSo : null,
            error: '',
            selectedDiaChinh: null,
            selectedDuAn: null,
            duAnList: null,
            serviceOrder: undefined,
            banGap: false,
            title: undefined,
            postAdsToOtherWebsite: undefined,
            groupID: undefined,
            landberInfo: undefined,
            adsID: adsID
        };

        this.props.actions.onPostAdsAllFieldChange(payload);
        this.state = {
            ...this.state,
            adsID: adsID,
            uploadUrls: [],
            chiTietExpanded: true,
            toggleState: false,
            editGia: false,
            showNamXayDung: false,
            initNamXayDung: '',
            inputNamXayDung: '',
            namXayDung: null,
            diaChinhFullName: '',
            geo: null,
            placeType: DanhMuc.placeType.DIA_DIEM,
            diaChiDuAn: 'Không thuộc dự án nào',
            diaChiChiTiet: '',
            noiDungChiTiet: '',
            showMoreContent: false,
            deletedPhoto: null,
            onCancelling: false,
            photos: []
        }
    }

    onRefreshPostAds_old(keepAdsID) {
        this.props.actions.onPostAdsFieldChange('photos', []);
        this.props.actions.onPostAdsFieldChange('imageIndex', 0);
        this.props.actions.onPostAdsFieldChange('pickMode', 'new');
        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        this.props.actions.onPostAdsFieldChange('dienTich', null);
        this.props.actions.onPostAdsFieldChange('matTien', null);
        this.props.actions.onPostAdsFieldChange('namXayDung', null);
        this.props.actions.onPostAdsFieldChange('soPhongNguSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soPhongNguText', '');
        this.props.actions.onPostAdsFieldChange('soNhaTamSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soNhaTamText', '');
        this.props.actions.onPostAdsFieldChange('soTangSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soTangText', '');
        this._onPostAdsValueChange("place", {
            duAn: '',
            duAnFullName: '',
            placeId: "ChIJKQqAE44ANTERDbkQYkF-mAI",
            diaChiChiTiet: '',
            diaChi: '',
            diaChinh: {
                tinh: '',
                huyen: '',
                xa: '',
                duAn: '',
                duong: '',
                tinhKhongDau: '',
                huyenKhongDau: '',
                xaKhongDau: '',
                codeTinh: '',
                codeHuyen: '',
                codeXa: '',
                codeDuAn: '',
                codeDuong: ''
            },
            geo: { lat: '', lon: '' }
        });
        let { currentUser } = this.props.global;
        let lienHe = {
            tenLienLac: currentUser.fullName,
            showTenLienLac: true,
            phone: currentUser.phone,
            showPhone: true,
            email: currentUser.email,
            showEmail: true
        };
        this.props.actions.onPostAdsFieldChange("lienHe", lienHe);
        this.props.actions.onPostAdsFieldChange('dangBoi', {
            userID: undefined,
            email: null,
            phone: null,
            name: null
        });
        this.props.actions.onPostAdsFieldChange('huongNha', null);
        this.props.actions.onPostAdsFieldChange('duongTruocNha', null);
        this.props.actions.onPostAdsFieldChange('nhaMoiXay', null);
        this.props.actions.onPostAdsFieldChange('nhaLoGoc', null);
        this.props.actions.onPostAdsFieldChange('otoDoCua', null);
        this.props.actions.onPostAdsFieldChange('nhaKinhDoanhDuoc', null);
        this.props.actions.onPostAdsFieldChange('noiThatDayDu', null);
        this.props.actions.onPostAdsFieldChange('chinhChuDangTin', null);
        this.props.actions.onPostAdsFieldChange('gia', null);
        this.props.actions.onPostAdsFieldChange('donViTien', 0);
        this.props.actions.onPostAdsFieldChange('chiTiet', '');

        let maSo = keepAdsID ? this.props.postAds.maSo : null;
        this.props.actions.onPostAdsFieldChange('maSo', maSo);

        this.props.actions.onPostAdsFieldChange('error', '');
        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', null);
        this.props.actions.onPostAdsFieldChange('selectedDuAn', null);
        this.props.actions.onPostAdsFieldChange('duAnList', null);
        this.props.actions.onPostAdsFieldChange('serviceOrder', undefined);
        this.props.actions.onPostAdsFieldChange('banGap', false);
        this.props.actions.onPostAdsFieldChange('title', undefined);
        this.props.actions.onPostAdsFieldChange('postAdsToOtherWebsite', undefined);
        this.props.actions.onPostAdsFieldChange('groupID', undefined);

        let adsID = keepAdsID ? this.props.postAds.id : null;
        this.props.actions.onPostAdsFieldChange('id', adsID);

        this.state = {
            ...this.state,
            adsID: adsID,
            uploadUrls: [],
            chiTietExpanded: true,
            toggleState: false,
            editGia: false,
            showNamXayDung: false,
            initNamXayDung: '',
            inputNamXayDung: '',
            namXayDung: null,
            diaChinhFullName: '',
            geo: null,
            placeType: DanhMuc.placeType.DIA_DIEM,
            diaChiDuAn: 'Không thuộc dự án nào',
            diaChiChiTiet: '',
            noiDungChiTiet: '',
            showMoreContent: false,
            deletedPhoto: null,
            onCancelling: false,
            photos: []
        }
    }

    _onLienHePressed() {
        dismissKeyboard();
        Actions.PostAdsLienHe();
    }

    _getLienHeValue() {
        let { lienHe } = this.props.postAds;

        if (!lienHe)
            return '';

        let lienHeTxt = '';
        if (lienHe.showTenLienLac && lienHe.tenLienLac && lienHe.tenLienLac.length > 0)
            lienHeTxt = lienHeTxt == '' ? lienHe.tenLienLac : lienHeTxt + lienHe.tenLienLac;
        if (lienHe.showPhone && lienHe.phone && lienHe.phone.length > 0)
            lienHeTxt = lienHeTxt == '' ? lienHe.phone : lienHeTxt + "-" + lienHe.phone;
        if (lienHe.showEmail && lienHe.email && lienHe.email.length > 0)
            lienHeTxt = lienHeTxt == '' ? lienHe.email : lienHeTxt + "-" + lienHe.email;

        let result = lienHeTxt.substring(0, 23) + '...';

        return result;
    }

    _onChiTietPressed() {
        dismissKeyboard();
        Actions.PostAdsTitle({ onComplete: this._onChiTietClosed.bind(this) });
    }

    _onChiTietClosed(noiDungChiTiet) {
        this.setState({ noiDungChiTiet: noiDungChiTiet });
    }

    _getChiTietValue() {
        let chiTiet = this.state.noiDungChiTiet;
        if (!chiTiet) {
            return 'Nhập mô tả';
        }

        let index = chiTiet.indexOf('\n');
        let val = index >= 0 ? chiTiet.substring(0, index) : chiTiet;
        if (val.length > 26) {
            return val.substring(0, 26) + '...';
        } else if (val.length != chiTiet.length) {
            return val + '...';
        }
        return chiTiet;

    }

    _onNumberValueChange(stateName, text) {
        if (text === '' || text === '.' || text === ',') {
            text = '';
        }
        let value = utils.interestNumeric(text);
        if (utils.countDot(value, '\\.') >= 2) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn nhập không đúng định dạng số!', DURATION.LENGTH_SHORT);
            return;
        }
        this._onPostAdsValueChange(stateName, value);
    }

    _onNumberXayDungChange(stateName, text) {
        if (text === '' || text === '.' || text === ',') {
            text = '';
        }
        let value = utils.interestNumeric(text);
        if (utils.countDot(value, '\\.') >= 2) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn nhập không đúng định dạng số!', DURATION.LENGTH_SHORT);
            return;
        }
        if (Number(value) > new Date().getFullYear() + 1) {
            this.refs.toastTop && this.refs.toastTop.show('Năm xây dựng không đủ điều kiện để đăng tin!', DURATION.LENGTH_SHORT);
            return;
        }
        this._onPostAdsValueChange(stateName, value);
    }

    _onPostAdsValueChange(key: string, value: string) {
        this.props.actions.onPostAdsFieldChange(key, value);
    }

    isUploading() {
        return this.props.postAds.uploading || this.props.postAds.loadingDiaChinh
            || this.state.onCancelling || this.props.me.isUpdatingProfile;
    }

    _getLoaiNhaValue() {
        let { loaiTin, loaiNhaDat } = this.props.postAds;
        return DanhMuc.getLoaiNhaDatForDisplay(loaiTin, loaiNhaDat);
    }

    _onLoaiNhaPressed() {
        dismissKeyboard();
        Actions.PropertyTypes({ func: 'postAds' });
    }

    _onHuongNhaPressed() {
        dismissKeyboard();
        Actions.MHuongNha({ func: 'postAds' });
    }

    _getHuongNhaValue() {
        let { huongNha } = this.props.postAds;
        return DanhMuc.getHuongNhaForDisplay(huongNha);
    }

    // _onPressSavePost() {
    //     let {photos} = this.props.postAds;
    //     errorMessage = '';
    //     uploadFiles = [];
    //     for (let i = 0; i < photos.length; i++) {
    //         let filepath = photos[i].uri;
    //         if (filepath == '') {
    //             continue;
    //         }
    //         uploadFiles.push({ filepath: filepath,  index: i, needUpload: filepath.indexOf('http') != 0});
    //     }
    //     if (!this.isValidInputData()) {
    //         this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
    //         this.props.actions.onPostAdsFieldChange('error', errorMessage);
    //         return;
    //     }

    //     let diaChiFullname = this._getDiaChiValue();
    //     if (!diaChiFullname) {
    //         errorMessage = 'Bạn chưa nhập thông tin địa chỉ!';
    //         Alert.alert('Thông báo', errorMessage, [{text: 'Đóng', onPress: () => {}}]);
    //         this.props.actions.onPostAdsFieldChange('error', errorMessage);
    //         return;
    //     }
    //     this.onSaveAdsChecked();
    // }

    onSaveAdsChecked() {
        let { photos } = this.props.postAds;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < photos.length; i++) {
            let filepath = photos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }

        this.props.actions.onPostAdsFieldChange("uploading", true);

        let countUpdateFiles = this.countNeedUploadFiles();
        if (!countUpdateFiles) {
            this.onSaveDraftAdsTypeAgent();
            return;
        }

        count = 0;
        const userID = this.props.global.currentUser.userID;

        //upload thumbnail image                            
        if (uploadFiles && uploadFiles.length > 0) {
            let indexThumbnail = uploadFiles[0].index;
            let filepathThumbnail = uploadFiles[0].filepath;
            //bachtv: always reupload thumbnail - Need review later if impact performance.
            // if (uploadFiles[0].needUpload) {
            ImageResizer.createResizedImage(filepathThumbnail, cfg.adsThumbWidth, cfg.adsThumbHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let thumbnailFilename = 'Ads_Thumbnail_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadAdsImage(indexThumbnail, thumbnailFilename, resizedImageUri, this.uploadDraftCallBack.bind(this), 'thumbnail');
            }).catch((err) => {
                this.props.actions.onPostAdsFieldChange("uploading", false);
                log.error(err);
            });
            // } else {
            //     //no need reupload, created a dummy data for calling callback
            //     let ms = moment().toDate().getTime();
            //     let data = JSON.stringify({
            //         "success": true,
            //         "file": {
            //             "name": 'Ads_Thumbnail_' + userID + '_' + ms + filepathThumbnail.substring(filepathThumbnail.lastIndexOf('.')),
            //             "url": filepathThumbnail
            //         }
            //     })                
            //     this.uploadDraftCallBack(null, {data: data}, 0, 'thumbnail')
            // }
        }


        for (let i = 0; i < uploadFiles.length; i++) {
            if (errorMessage != '') {
                Alert.alert('Thông báo', errorMessage);
                this.props.actions.onPostAdsFieldChange('error', errorMessage);
                return;
            }
            let needUpload = uploadFiles[i].needUpload;
            if (!needUpload) {
                continue;
            }
            let index = uploadFiles[i].index;
            let filepath = uploadFiles[i].filepath;

            ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let filename = 'Ads_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadAdsImage(index, filename, resizedImageUri, this.uploadDraftCallBack.bind(this), 'normal');
            }).catch((err) => {
                this.props.actions.onPostAdsFieldChange("uploading", false);
                log.error(err);
            });
        }
    }

    uploadDraftCallBack = function (err, result, index, type) {
        console.log('uploadDraftCallBack *** result ***', result)
        let data = result && result.data ? result.data : '';
        if (err || data == '') {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            this.props.actions.onPostAdsFieldChange("uploading", false);
            return;
        }
        try {
            let { success, file } = JSON.parse(data);
            if (success) {
                let { url } = file;

                if (type == 'normal')
                    this.state.uploadUrls.push({ index: index, url: url });
                if (type == 'thumbnail')
                    this.state.thumbnailUrl = { index: index, url: url }

                count++;

                if (count == this.countNeedUploadFiles()) {
                    this.onSaveDraftAdsTypeAgent();
                }
            } else {
                errorMessage = 'Upload ảnh không thành công!';
                this.props.actions.onPostAdsFieldChange('error', errorMessage);
                this.props.actions.onPostAdsFieldChange("uploading", false);
            }
        } catch (error) {
            errorMessage = 'Upload ảnh không thành công 3!';
            console.log(error)
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            this.props.actions.onPostAdsFieldChange("uploading", false);
        }
    };

    onSaveDraftAdsTypeAgent() {
        let { uploadUrls, thumbnailUrl } = this.state;
        let { id, maSo, loaiTin, loaiNhaDat, gia, donViTien, dienTich, matTien, namXayDung,
            soTangText, soPhongNguText, soNhaTamText, chiTiet, huongNha, duongTruocNha,
            place, selectedDiaChinh, selectedDuAn, lienHe, photos,
            nhaMoiXay, nhaLoGoc, otoDoCua, nhaKinhDoanhDuoc, noiThatDayDu, chinhChuDangTin, title, banGap, landberInfo, ketNoiCungCau } = this.props.postAds;


        let imageUrls = [];
        // console.log(' onSaveDraftAdsTypeAgent *************uploadUrls', uploadUrls)
        // console.log(' onSaveDraftAdsTypeAgent *************photos', photos)
        for (let i = 0; i < photos.length; i++) {
            let photo = photos[i];
            imageUrls.push(photo.uri);
        }
        for (let i = 0; i < uploadUrls.length; i++) {
            let uploadUrl = uploadUrls[i];
            let index = uploadUrl.index;
            if (index >= 0) {
                photos[index] = { uri: uploadUrl.url };
                imageUrls[index] = uploadUrl.url;
            }
        }
        if (uploadUrls.length > 0) {
            this.props.actions.onPostAdsFieldChange('photos', [...photos]);
        }
        let image = { cover: '', images: [] };
        if (imageUrls.length > 0) {
            image.cover = thumbnailUrl ? thumbnailUrl.url : imageUrls[0];
            // imageUrls.shift();
            image.images = imageUrls;
        }

        console.log('onSaveDraftAdsTypeAgent **** image: ', image)

        let loaiTinVal = (loaiTin === 'ban') ? 0 : 1;

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let dangBoi = {
            "email": currentUser.email,
            "name": currentUser.fullName,
            "phone": currentUser.phone,
            "userID": currentUser.userID,
            "fullName": currentUser.fullName,
            "avatar": currentUser.avatar
        };

        // remove lienHe if no information
        if (lienHe
            && (!lienHe.tenLienLac || lienHe.tenLienLac.length <= 0)
            && (!lienHe.phone || lienHe.phone.length <= 0)
            && (!lienHe.email || lienHe.phone.length <= 0))
            lienHe = undefined;

        //remove placeId
        place.placeId = undefined;
        place.diaChiFullName = undefined;
        place.duAn = undefined;
        place.duAnFullName = undefined;

        let diaChi = '';
        if (selectedDuAn && selectedDuAn.placeName) {
            diaChi = place.diaChiChiTiet ? selectedDuAn.placeName + ", " + place.diaChiChiTiet : selectedDuAn.placeName;
        } else {
            diaChi = place.diaChiChiTiet;
        }
        if (selectedDiaChinh && selectedDiaChinh.duong) {
            diaChi = diaChi ? diaChi + ", " + selectedDiaChinh.duong : selectedDiaChinh.duong;
        }
        diaChi = diaChi ? diaChi + ", " + this.state.diaChinhFullName : this.state.diaChinhFullName;
        place.diaChi = diaChi;
        place.diaChiKhongDau = utils.locDauV2(utils.standardlizeName(diaChi))

        if (selectedDiaChinh) {
            place.diaChinh.codeTinh = selectedDiaChinh.codeTinh || undefined;
            place.diaChinh.codeHuyen = selectedDiaChinh.codeHuyen || undefined;
            place.diaChinh.codeXa = selectedDiaChinh.codeXa || undefined;
            place.diaChinh.codeDuong = selectedDiaChinh.codeDuong || undefined;
            place.diaChinh.tinh = selectedDiaChinh.tinh || undefined;
            place.diaChinh.huyen = selectedDiaChinh.huyen || undefined;
            place.diaChinh.xa = selectedDiaChinh.xa || undefined;
            place.diaChinh.duong = selectedDiaChinh.duong || undefined;
            place.diaChinh.tinhKhongDau = undefined;
            place.diaChinh.huyenKhongDau = undefined;
            place.diaChinh.xaKhongDau = undefined;
        }

        if (selectedDuAn) {
            place.diaChinh.codeDuAn = selectedDuAn.duAn || undefined;
            place.diaChinh.duAn = selectedDuAn.placeName || undefined;
        } else {
            place.diaChinh.codeDuAn = undefined;
            place.diaChinh.duAn = undefined;
        }

        let phongNgu = soPhongNguText != '' && !isNaN(soPhongNguText) ? Number(soPhongNguText) : undefined;
        let soTang = soTangText != '' && !isNaN(soTangText) ? Number(soTangText) : undefined;
        let phongTam = soNhaTamText != '' && !isNaN(soNhaTamText) ? Number(soNhaTamText) : undefined;
        let giaItem = DanhMuc.calculateGia2(gia, donViTien, dienTich);

        let ngayDangTin = moment().format('YYYYMMDD');
        let titleStandardlized = title ? utils.standardlizeName(title) : '';

        let adsDto = {
            "title": title || undefined,
            "titleKhongDau": titleStandardlized ? utils.locDauV2(titleStandardlized) : undefined,
            "id": id || undefined,
            "maSo": maSo || undefined,
            "image": image,
            "loaiTin": loaiTinVal,
            "loaiNhaDat": loaiNhaDat,
            "dienTich": dienTich || -1,
            "matTien": matTien || undefined,
            "namXayDung": namXayDung || undefined,
            "soPhongNgu": phongNgu,
            "soPhongTam": phongTam,
            "soTang": soTang,
            "place": place,
            "huongNha": huongNha || undefined,
            "duongTruocNha": duongTruocNha && !isNaN(duongTruocNha) ? Number(duongTruocNha) : undefined,
            "nhaMoiXay": nhaMoiXay || undefined,
            "nhaLoGoc": nhaLoGoc || undefined,
            "otoDoCua": otoDoCua || undefined,
            "nhaKinhDoanhDuoc": nhaKinhDoanhDuoc || undefined,
            "noiThatDayDu": noiThatDayDu || undefined,
            "chinhChuDangTin": chinhChuDangTin || undefined,
            "ketNoiCungCau": ketNoiCungCau || undefined,
            "chiTiet": chiTiet || undefined,
            "gia": giaItem.gia || -1,
            "giaM2": giaItem.giaM2 || -1,
            "ngayDangTin": ngayDangTin || undefined,
            "lienHe": lienHe,
            "dangBoi": dangBoi,
            "banGap": banGap || undefined,
            "landberInfo": landberInfo || undefined,
        };
        // console.log('adsDto to call saveAds *************', adsDto)
        this.props.actions.saveAds(adsDto, this.props.global.currentUser, token)
            .then(res => {
                this.setState({
                    loading: false
                });
                if (res.status != 0) {
                    let msg = res.msg || "Lưu tin không thành công!";
                    this.refs.toastTop && this.refs.toastTop.show(msg, DURATION.LENGTH_LONG);
                } else {
                    this.props.actions.onPostAdsFieldChange('id', res.adsID);
                    this.props.actions.onPostAdsFieldChange('inboxType', 'ads');
                    this.props.actions.onGroupFieldChange('textSearchAds', '');
                    this.props.actions.loadMySellRentList(this.props.global.currentUser.userID).then(res => {
                        if (res.status==0) {
                            this.props.onSetCungCauState && this.props.onSetCungCauState(res.data)
                        }
                    });
                    this.refs.toastTop && this.refs.toastTop.show("Lưu tin thành công!", DURATION.LENGTH_LONG);
                    setTimeout(() => {
                        this.props.actions.onHideChatIconChange(false);
                        if (this.props.owner == 'NewAgentPost' || this.props.owner == 'NewHomeAgent' || this.props.owner == 'GroupFilterResult') {
                            Actions.popTo('root');
                            this.props.actions.onPostAdsFieldChange('inboxType', 'ads');
                            Actions.NewAgentPost();
                        } else if (this.props.owner == 'AdsMgmt') {
                            Actions.popTo('root');
                            Actions.AdsMgmt();
                        } else {
                            Actions.Home({ type: 'reset' });
                        }
                    }, 300);
                }
            });
    }

    _hasJoinedGroup() {
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let userID = this.props.global.currentUser.userID;
        if (!listRelatedGroup || listRelatedGroup.length == 0) {
            return false;
        }
        let adsJoinedGroups = listRelatedGroup.filter((one) => {
            return one.createdBy == userID || one.joinStatus == 2
        });
        return adsJoinedGroups && adsJoinedGroups.length > 0;
    }

    prePostAds() {
        this.validatePostAds(this.onPostAds.bind(this));
    }

    // post ads action press
    _onPostAdsAgent() {
        let { loaiTin } = this.props.postAds;
        let titleEvent = loaiTin === 'ban' ? 'Lưu tin bán' : 'Lưu tin cho thuê';
        this.onLogEvent(titleEvent);
        // if (!this._hasJoinedGroup()) {
        //     errorMessage = 'Bạn chưa tham gia sàn nào, để đăng bài bạn cần tham gia tối thiểu một sàn!';
        //     this.refs.toastTop && this.refs.toastTop.show(errorMessage, 6000);
        //     this.props.actions.onPostAdsFieldChange('error', errorMessage);
        //     return;
        // }
        // if (!this._hasSelectedGroup()) {
        //     errorMessage = 'Bạn chưa chọn các sàn để đăng tin!';
        //     this.refs.toastTop && this.refs.toastTop.show(errorMessage, 3000);
        //     this.props.actions.onPostAdsFieldChange('error', errorMessage);
        //     return;
        // }

        let { photos } = this.props.postAds;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < photos.length; i++) {
            let filepath = photos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }
        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, 3000);
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            return;
        }

        let diaChiFullname = this._getDiaChiValue();
        if (!diaChiFullname) {
            errorMessage = 'Bạn chưa nhập thông tin địa chỉ!';
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            return;
        }
        // this.setState({
        //     modalChonNoiDang: true
        // });
        // let groupID = this.props.postAds.groupID;
        // if (this.props.groupID && !groupID) {
        //     groupID = [this.props.groupID];
        // }
        // Actions.PostAdsJoinedGroup({
        //     groupID: groupID, onPress: this._doSuggestGroupFinal.bind(this)
        // });

        // if (this.state.postToLandber) {
        //     this._preSelectWesite();
        // } else {
        //     this.onPostAdsChecked();
        // }

        if (!this._hasSelectedGroup()) {
            this.onSaveAdsChecked();
        } else {
            this.onPostAdsChecked();
        }
    }

    onLogEvent(title) {
        let eventDto = {
            scene: "NewPostAdsDetail",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,
            customData: this.props.postAds.id ? {adsID: this.props.postAds.id} : undefined
        };
        log.info('will call log event with payload **************', eventDto)
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _hasSelectedGroup() {
        // return this.state.selectedGroup.length > 0;
        let groupID = this.props.postAds.groupID;
        return groupID && groupID.length > 0;
    }

    _preSelectWesite() {
        let currentUser = this.props.global.currentUser;
        this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
            (res) => {
                if (res.status == 0) {
                    this._onSelectWebsite();
                } else {
                    Alert.alert('Thông báo', res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                }
            }
        );
    }

    _preUpdatePackage(couponCode) {
        let usePostAdsToOtherWebsite = this.state.isSelectedAll;
        if (usePostAdsToOtherWebsite) {
            let { postToWebsitesServices, selectedWebsitesServiceIndex, sites } = this.state;
            let service = postToWebsitesServices[selectedWebsitesServiceIndex];

            if (couponCode && couponCode.length > 0) {
                let couponDto = {
                    serviceType: 1,
                    couponCode: couponCode,
                    serviceID: service.id
                }

                this._verifyCouponCode(couponDto, this._doAfterVerifyCouponPostToSites.bind(this, couponCode));
            } else {
                this._doUpdatePostToSites();
            }
        } else {
            this.props.actions.onPostAdsFieldChange('postAdsToOtherWebsite', undefined);
            this._chonGoiViTri();
        }
    }

    _doAfterVerifyCouponPostToSites(couponCode, res) {
        if (res.status !== 0) {
            let msg = res.msg + '. Bạn có tiếp tục đăng tin?';
            Alert.alert('Thông báo', msg,
                [{
                    text: 'Huỷ', onPress: () => { }
                },
                {
                    text: 'Đồng ý', onPress: () => {
                        this._doUpdatePostToSites();
                    }
                }
                ]);
        } else {
            let msg = res.msg + '. Bạn chắc chắn sử dụng mã khuyến mại này?';
            Alert.alert('Thông báo', msg,
                [{
                    text: 'Huỷ', onPress: () => { }
                },
                {
                    text: 'Đồng ý', onPress: () => {
                        this._doUpdatePostToSites(couponCode);
                    }
                }
                ]);
        }
    }

    _doUpdatePostToSites(couponCode) {
        let { postToWebsitesServices, selectedWebsitesServiceIndex, sites } = this.state;
        let service = postToWebsitesServices[selectedWebsitesServiceIndex];

        let fee = service.fees[0];

        let postAdsToOtherWebsite = {
            userID: this.props.global.currentUser.userID,
            workstation:
            {
                name: this.props.global.deviceInfo.deviceModel,
                workstationID: this.props.global.deviceInfo.deviceID,
                appType: 'app'
            },
            price: {
                discount: fee.discount,
                price: fee.price,
                soLanSuDung: fee.soLanSuDung,
                type: fee.type
            },
            service: {
                id: service.id,
                name: service.name,
                level: service.level,
                //days: fee[0].soLanSuDung,
                packageType: 1,
                couponCode: couponCode || undefined
            },
            sites: sites
        };

        this.props.actions.onPostAdsFieldChange('postAdsToOtherWebsite', postAdsToOtherWebsite);
        this._chonGoiViTri();
    }

    _chonGoiViTri() {
        if (!this.props.postAds.id || !this.props.active) {
            let currentUser = this.props.global.currentUser;
            this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
                (res) => {
                    if (res.status == 0) {
                        this._onUpdatePackage();
                    } else {
                        Alert.alert('Thông báo', res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                    }
                }
            );
        } else {
            this.setState({ goiVipActived: false, websiteActived: false, selectedPostToWebsite: true });
            this.onPostAdsChecked();
        }
    }

    _verifyCouponCode(couponDto, callback) {
        let currentUser = this.props.global.currentUser;
        this.props.actions.checkCouponHieuLuc(couponDto, currentUser.token).then(
            (res) => {
                callback(res);
            });
    }

    _onUpdatePackage() {
        this.props.actions.changeSelectedPackage('goiViTri');
        this.props.actions.changePackageField('adsID', null);
        this.props.actions.changePackageField('ads', null);
        this.setState({ goiVipActived: true, websiteActived: false, selectedPostToWebsite: true });
    }

    _onSelectWebsite() {
        this.setState({ goiVipActived: false, websiteActived: true });
    }

    _onWebsiteBack() {
        this.setState({ goiVipActived: false, websiteActived: false, selectedPostToWebsite: true });
    }

    _onPackageApply(couponCode) {
        let service = this.state.allServices.filter((e) => {
            return e.name == this.props.adsMgmt.package.goiViTri.levelName;
        });

        if (couponCode && couponCode.length > 0) {
            let couponDto = {
                serviceType: 1,
                couponCode: couponCode,
                serviceID: service[0].id
            }

            this._verifyCouponCode(couponDto, this._doAfterVerifyCouponVip.bind(this, couponCode));
        } else {
            this._doOrderService();
        }
    }

    _doOrderService(couponCode) {
        let service = this.state.allServices.filter((e) => {
            return e.name == this.props.adsMgmt.package.goiViTri.levelName;
        });

        let fee = service[0].fees.filter((e) => {
            return e.soLanSuDung == this.props.adsMgmt.package.goiViTri.length;
        });

        let serviceOrder = {
            userID: this.props.global.currentUser.userID,
            workstation:
            {
                name: this.props.global.deviceInfo.deviceModel,
                workstationID: this.props.global.deviceInfo.deviceID,
                appType: 'app'
            },
            price: {
                discount: fee[0].discount,
                price: fee[0].price,
                soLanSuDung: fee[0].soLanSuDung,
                type: fee[0].type
            },
            service: {
                id: service[0].id,
                name: service[0].name,
                level: service[0].level,
                //days: fee[0].soLanSuDung,
                packageType: 1,
                couponCode: couponCode || undefined
            }
        };

        this.props.actions.onPostAdsFieldChange('serviceOrder', serviceOrder);
        this.setState({ goiVipActived: false });

        this.onPostAdsChecked();
    }

    _doAfterVerifyCouponVip(couponCode, res) {
        if (res.status !== 0) {
            let msg = res.msg + '. Bạn có tiếp tục đăng tin?';
            Alert.alert('Thông báo', msg,
                [{
                    text: 'Huỷ', onPress: () => { }
                },
                {
                    text: 'Đồng ý', onPress: () => {
                        this._doOrderService();
                    }
                }
                ]);
        } else {
            let msg = res.msg + '. Bạn chắc chắn sử dụng mã khuyến mại này?';
            Alert.alert('Thông báo', msg,
                [{
                    text: 'Huỷ', onPress: () => { }
                },
                {
                    text: 'Đồng ý', onPress: () => {
                        this._doOrderService(couponCode);
                    }
                }
                ]);
        }
    }

    onPostAdsChecked() {
        let { photos } = this.props.postAds;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < photos.length; i++) {
            let filepath = photos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }

        this.props.actions.onPostAdsFieldChange("uploading", true);

        let countUpdateFiles = this.countNeedUploadFiles();
        if (!countUpdateFiles) {
            this.onSaveAdsTypeAgent();
            return;
        }

        count = 0;
        const userID = this.props.global.currentUser.userID;

        //upload thumbnail image                            
        if (uploadFiles && uploadFiles.length > 0) {
            let indexThumbnail = uploadFiles[0].index;
            let filepathThumbnail = uploadFiles[0].filepath;
            //bachtv: always reupload thumbnail - Need review later if impact performance.
            // if (uploadFiles[0].needUpload) {
            ImageResizer.createResizedImage(filepathThumbnail, cfg.adsThumbWidth, cfg.adsThumbHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let thumbnailFilename = 'Ads_Thumbnail_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadAdsImage(indexThumbnail, thumbnailFilename, resizedImageUri, this.uploadCallBack.bind(this), 'thumbnail');
            }).catch((err) => {
                this.props.actions.onPostAdsFieldChange("uploading", false);
                log.error(err);
            });
            // } else {
            //     //no need reupload, created a dummy data for calling callback
            //     let ms = moment().toDate().getTime();
            //     let data = JSON.stringify({
            //         "success": true,
            //         "file": {
            //             "name": 'Ads_Thumbnail_' + userID + '_' + ms + filepathThumbnail.substring(filepathThumbnail.lastIndexOf('.')),
            //             "url": filepathThumbnail
            //         }
            //     })                
            //     this.uploadDraftCallBack(null, {data: data}, 0, 'thumbnail')
            // }
        }

        for (let i = 0; i < uploadFiles.length; i++) {
            if (errorMessage != '') {
                Alert.alert('Thông báo', errorMessage);
                this.props.actions.onPostAdsFieldChange('error', errorMessage);
                return;
            }
            let needUpload = uploadFiles[i].needUpload;
            if (!needUpload) {
                continue;
            }
            let index = uploadFiles[i].index;
            let filepath = uploadFiles[i].filepath;

            //upload full image
            ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let filename = 'Ads_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadAdsImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this), 'normal');
            }).catch((err) => {
                this.props.actions.onPostAdsFieldChange("uploading", false);
                log.error(err);
            });
        }
    }

    _doSuggestGroupFinal(selectedGroupIDs) {
        this.props.actions.onPostAdsFieldChange('groupID', selectedGroupIDs);
        // let allServices = this.state.allServices;
        // let service = allServices && allServices.length > 0 ? allServices[0] : undefined;
        // if (service) {
        //     let fee = service.fees[service.fees.length-1];
        //
        //     let serviceOrder = { userID: this.props.global.currentUser.userID,
        //         workstation:
        //         { name: this.props.global.deviceInfo.deviceModel,
        //             workstationID: this.props.global.deviceInfo.deviceID,
        //             appType: 'app' },
        //         price: { discount: fee.discount,
        //             price: fee.price,
        //             soLanSuDung: fee.soLanSuDung,
        //             type: fee.type},
        //         service: { id: service.id,
        //             name: service.name,
        //             level: service.level,
        //             //days: fee[0].soLanSuDung,
        //             packageType: 1} };
        //
        //     this.props.actions.onPostAdsFieldChange('serviceOrder', serviceOrder);
        // }

        setTimeout(() => {
            this.onPostAdsChecked();
            Actions.pop();
        }, 1000);
    }

    _onGroupAgentPost() {
        Actions.PostAdsJoinedGroup({
            onPress: this._doSuggestGroupFinal.bind(this)
        });
        this._outContentModal();
    }

    _onLandberPost() {
        this._preSelectWesite();
        this._outContentModal();
    }

    onSaveAdsTypeAgent() {
        let { uploadUrls, thumbnailUrl } = this.state;
        let { id, maSo, loaiTin, loaiNhaDat, gia, donViTien, dienTich, matTien, namXayDung,
            soTangText, soPhongNguText, soNhaTamText, chiTiet, huongNha, duongTruocNha,
            place, selectedDiaChinh, selectedDuAn, lienHe, photos,
            nhaMoiXay, nhaLoGoc, otoDoCua, nhaKinhDoanhDuoc, noiThatDayDu, chinhChuDangTin, serviceOrder, title,
            banGap, groupID, landberInfo, ketNoiCungCau } = this.props.postAds;

        let imageUrls = [];
        for (let i = 0; i < photos.length; i++) {
            let photo = photos[i];
            imageUrls.push(photo.uri);
        }
        for (let i = 0; i < uploadUrls.length; i++) {
            let uploadUrl = uploadUrls[i];
            let index = uploadUrl.index;
            if (index >= 0) {
                imageUrls[index] = uploadUrl.url;
            }
        }
        let image = { cover: '', images: [] };
        if (imageUrls.length > 0) {
            image.cover = thumbnailUrl ? thumbnailUrl.url : imageUrls[0];
            // imageUrls.shift();
            image.images = imageUrls;
        }

        console.log('onSaveAdsTypeAgent ****** image: ', image)

        let loaiTinVal = (loaiTin === 'ban') ? 0 : 1;

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let dangBoi = {
            "email": currentUser.email,
            "name": currentUser.fullName,
            "phone": currentUser.phone,
            "userID": currentUser.userID,
            "fullName": currentUser.fullName,
            "avatar": currentUser.avatar
        };

        // remove lienHe if no information
        if (lienHe
            && (!lienHe.tenLienLac || lienHe.tenLienLac.length <= 0)
            && (!lienHe.phone || lienHe.phone.length <= 0)
            && (!lienHe.email || lienHe.phone.length <= 0))
            lienHe = undefined;

        //remove placeId
        place.placeId = undefined;
        place.diaChiFullName = undefined;
        place.duAn = undefined;
        place.duAnFullName = undefined;

        let diaChi = '';
        if (selectedDuAn && selectedDuAn.placeName) {
            diaChi = place.diaChiChiTiet ? selectedDuAn.placeName + ", " + place.diaChiChiTiet : selectedDuAn.placeName;
        } else {
            diaChi = place.diaChiChiTiet;
        }
        if (selectedDiaChinh && selectedDiaChinh.duong) {
            diaChi = diaChi ? diaChi + ", " + selectedDiaChinh.duong : selectedDiaChinh.duong;
        }
        diaChi = diaChi ? diaChi + ", " + this.state.diaChinhFullName : this.state.diaChinhFullName;
        place.diaChi = diaChi;
        place.diaChiKhongDau = diaChi ? utils.locDauV2(utils.standardlizeName(diaChi)) : ''

        if (selectedDiaChinh) {
            place.diaChinh.codeTinh = selectedDiaChinh.codeTinh || undefined;
            place.diaChinh.codeHuyen = selectedDiaChinh.codeHuyen || undefined;
            place.diaChinh.codeXa = selectedDiaChinh.codeXa || undefined;
            place.diaChinh.codeDuong = selectedDiaChinh.codeDuong || undefined;
            place.diaChinh.tinh = selectedDiaChinh.tinh || undefined;
            place.diaChinh.huyen = selectedDiaChinh.huyen || undefined;
            place.diaChinh.xa = selectedDiaChinh.xa || undefined;
            place.diaChinh.duong = selectedDiaChinh.duong || undefined;
            place.diaChinh.tinhKhongDau = undefined;
            place.diaChinh.huyenKhongDau = undefined;
            place.diaChinh.xaKhongDau = undefined;
        }

        if (selectedDuAn) {
            place.diaChinh.codeDuAn = selectedDuAn.duAn || undefined;
            place.diaChinh.duAn = selectedDuAn.placeName || undefined;
        } else {
            place.diaChinh.codeDuAn = undefined;
            place.diaChinh.duAn = undefined;
        }

        let phongNgu = soPhongNguText != '' && !isNaN(soPhongNguText) ? Number(soPhongNguText) : undefined;
        let soTang = soTangText != '' && !isNaN(soTangText) ? Number(soTangText) : undefined;
        let phongTam = soNhaTamText != '' && !isNaN(soNhaTamText) ? Number(soNhaTamText) : undefined;
        let giaItem = DanhMuc.calculateGia2(gia, donViTien, dienTich);

        let ngayDangTin = moment().format('YYYYMMDD');
        let titleStandardlized = title ? utils.standardlizeName(title) : '';
        let adsDto = {
            "title": title || undefined,
            "titleKhongDau": titleStandardlized ? utils.locDauV2(titleStandardlized) : undefined,
            "id": id || undefined,
            "maSo": maSo || undefined,
            "image": image,
            "loaiTin": loaiTinVal,
            "loaiNhaDat": loaiNhaDat,
            "dienTich": dienTich || -1,
            "matTien": matTien || undefined,
            "namXayDung": namXayDung || undefined,
            "soPhongNgu": phongNgu,
            "soPhongTam": phongTam,
            "soTang": soTang,
            "place": place,
            "huongNha": huongNha || undefined,
            "duongTruocNha": duongTruocNha && !isNaN(duongTruocNha) ? Number(duongTruocNha) : undefined,
            "nhaMoiXay": nhaMoiXay || undefined,
            "nhaLoGoc": nhaLoGoc || undefined,
            "otoDoCua": otoDoCua || undefined,
            "nhaKinhDoanhDuoc": nhaKinhDoanhDuoc || undefined,
            "noiThatDayDu": noiThatDayDu || undefined,
            "chinhChuDangTin": chinhChuDangTin || undefined,
            "ketNoiCungCau": ketNoiCungCau || undefined,
            "chiTiet": chiTiet || undefined,
            "gia": giaItem.gia || -1,
            "giaM2": giaItem.giaM2 || -1,
            "ngayDangTin": ngayDangTin || undefined,
            "lienHe": lienHe,
            "dangBoi": dangBoi,
            "banGap": banGap || undefined,
            "serviceOrder": id ? undefined : serviceOrder || undefined,
            "groupID": groupID || (this.props.groupID ? [this.props.groupID] : undefined),
            "landberInfo": landberInfo || undefined,
        };

        this.props.actions.postAds(adsDto, this.props.global.currentUser, token)
            .then(res => {
                this.setState({
                    loading: false
                });
                if (res.status != 0) {
                    this.refs.toastTop && this.refs.toastTop.show(res.msg, DURATION.LENGTH_LONG);
                } else {
                    this.onRegisterIntercomUser();
                    let oldAdsID = adsDto.id;
                    if (oldAdsID && serviceOrder) {
                        this.onUpgradePackage(adsDto, serviceOrder);
                    } else {
                        let newAdsID = res.adsID;
                        this.onPostAdsToOtherWebsite(newAdsID);
                    }
                }
            });
    }

    uploadCallBack = function (err, result, index, type) {
        let data = result && result.data ? result.data : '';
        if (err || data == '') {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            this.props.actions.onPostAdsFieldChange("uploading", false);
            return;
        }
        try {
            let { success, file } = JSON.parse(data);
            if (success) {
                let { url } = file;

                if (type == 'normal')
                    this.state.uploadUrls.push({ index: index, url: url });
                if (type == 'thumbnail')
                    this.state.thumbnailUrl = { index: index, url: url }

                count++;
                if (count == this.countNeedUploadFiles()) {
                    this.onSaveAdsTypeAgent();
                }
            } else {
                errorMessage = 'Upload ảnh không thành công!';
                this.props.actions.onPostAdsFieldChange('error', errorMessage);
                this.props.actions.onPostAdsFieldChange("uploading", false);
            }
        } catch (error) {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onPostAdsFieldChange('error', errorMessage);
            this.props.actions.onPostAdsFieldChange("uploading", false);
        }
    };

    doAfterPostAds() {
        let { loaiTin } = this.props.postAds;
        this.props.actions.onGroupFieldChange('textSearchAds', '');
        this.props.actions.onPostAdsFieldChange('inboxType', 'ads');
        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID).then(res => {
            if (res.status==0) {
                this.props.onSetCungCauState && this.props.onSetCungCauState(res.data)
            }
        });
        // this.props.actions.onAdsMgmtFieldChange('activeTab', (loaiTin === 'ban') ? 0 : 1);
        let oldAdsID = this.state.adsID;
        if (oldAdsID && oldAdsID.length > 0) {
            this.refs.toastTop && this.refs.toastTop.show("Thay đổi thành công!", DURATION.LENGTH_LONG);
        } else {
            this.refs.toastTop && this.refs.toastTop.show("Xác nhận tin đã đăng thành công!", DURATION.LENGTH_LONG);
        }
        setTimeout(() => {
            this.props.actions.onHideChatIconChange(false);
            Actions.popTo('root');
            if (this.props.owner == 'NewAgentPost' || this.props.owner == 'NewHomeAgent' || this.props.owner == 'GroupFilterResult') {
                Actions.NewAgentPost();
            } else if (this.props.owner == 'AdsMgmt') {
                Actions.AdsMgmt();
            }
        }, 1000);
    }

    onUpgradePackage(adsDto, serviceOrder) {
        let id = adsDto.id;
        if (!id || !serviceOrder) {
            return;
        }
        serviceOrder.ads = {
            id: id,
            cover: adsDto.image.cover
        };

        this.props.actions.orderService(serviceOrder, this.props.global.currentUser.token).then((e) => {
            if (e.status != 0) {
                this.setState({
                    loading: false
                });
                Alert.alert("Thông báo", e.msg, [{ text: 'Đóng', onPress: () => { } }]);
                this.doAfterPostAds();
            } else {
                this.onPostAdsToOtherWebsite(id);
            }

        });

    }

    onPostAdsToOtherWebsite(adsID) {
        let { postAdsToOtherWebsite } = this.props.postAds;
        if (postAdsToOtherWebsite) {
            postAdsToOtherWebsite.adsID = adsID;
            let currentUser = this.props.global.currentUser;
            let token = currentUser.token;
            this.props.actions.postAdsToOtherWebsite(postAdsToOtherWebsite, token)
                .then(res => {
                    this.setState({
                        loading: false
                    });
                    if (res.status != 0) {
                        Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                    }
                    this.doAfterPostAds();
                });
        } else {
            this.setState({
                loading: false
            });
            this.doAfterPostAds();
        }
    }

    onRegisterIntercomUser() {
        try {
            let userID = this.props.global.currentUser.userID || undefined;
            let email = this.props.global.currentUser.email || undefined;
            let phone = this.props.global.currentUser.phone || undefined;
            let name = this.props.global.currentUser.username || undefined;
            let fullName = this.props.global.currentUser.fullName || undefined;
            if (fullName) {
                name = fullName;
            }
            let avatar = this.props.global.currentUser.avatar || undefined;
            Intercom.reset().then(() => {
                Intercom.registerIdentifiedUser({ userId: userID })
                    .then(() => {
                        log.info('registerIdentifiedUser done');

                        return Intercom.updateUser({
                            email: email,
                            phone: phone,
                            name: name,
                            avatar: { type: 'avatar', image_url: avatar }
                        });
                    })
                    .catch((err) => {
                        log.error('registerIdentifiedUser ERROR', err);
                    });
            });
        } catch (error) {
            log.warn('========== onRegisterIntercomUser ERROR', error);
        }
    }

    countNeedUploadFiles() {
        let count = 0;
        for (let i = 0; i < uploadFiles.length; i++) {
            let file = uploadFiles[i];
            if (file.needUpload) {
                count++;
            }
        }
        //bachtv: need count 1 more for thumbnail image which used for cover        
        if (count > 0)
            count++;

        return count;
    }

    isValidInputData() {
        let { place, gia, dienTich, matTien
            , soTangText, soPhongNguText, soNhaTamText, title } = this.props.postAds;
        if (title && title.trim().length > 0) {
            if (title.trim().length < 30) {
                errorMessage = 'Kích thước tiêu đề tối thiểu là 30 ký tự!';
                return false;
            }
            if (title.trim().length > 99) {
                errorMessage = 'Kích thước tiêu đề tối đa là 99 ký tự!';
                return false;
            }
        }
        let errors = '';
        if (uploadFiles.length === 0) {
            errors += ' (ảnh)';
        }
        let geo = place && place.geo;

        if (!this.isValidLoaiTin()) {
            errors += ' (loại nhà)';
        }

        if (!geo || !geo.lat || isNaN(geo.lat)
            || !geo.lon || isNaN(geo.lon)) {
            errors += ' (địa điểm/dự án)';
        }
        if (!gia) {
            errors += ' (giá)';
        }
        if (errors != '') {
            errorMessage = 'Bạn chưa chọn' + errors + '!';
            return false;
        }
        if (gia && isNaN(gia)) {
            errors += ' (giá)';
        }

        if (dienTich && ((!isNaN(dienTich) && Number(dienTich) <= 0 && Number(dienTich) != -1) || isNaN(dienTich))) {
            errors += ' (diện tích)';
        }
        if (matTien && isNaN(matTien)) {
            errors += ' (mặt tiền)';
        }
        if (soTangText && isNaN(soTangText)) {
            errors += ' (số tầng)';
        }
        if (soPhongNguText && isNaN(soPhongNguText)) {
            errors += ' (số phòng ngủ)';
        }
        if (soNhaTamText && isNaN(soNhaTamText)) {
            errors += ' (số phòng tắm)';
        }
        if (errors != '') {
            errorMessage = 'Sai kiểu giá trị:' + errors + '!';
            return false;
        }
        return true;
    }

    isValidLoaiTin() {
        let { loaiTin, loaiNhaDat } = this.props.postAds;
        if (loaiNhaDat == '' || loaiNhaDat === 0) {
            return false;
        }
        let dmLoaiNhatDatKeys = loaiTin == 'ban' ? DanhMuc.LoaiNhaDatBanKey : DanhMuc.LoaiNhaDatThueKey;
        let found = dmLoaiNhatDatKeys.filter((item) => item == loaiNhaDat);
        return found && found.length > 0;
    }

}


class ImageItem extends React.Component {
    constructor(props) {
        super(props);
    }

    _onPhotoPressed() {
        this.props.onTakePhoto(`${this.props.imageIndex}`);
    }

    _onDeletePhoto() {
        this.props.onDeletePhoto(`${this.props.imageIndex}`);
    }

    _renderCoverTitle() {
        if (this.props.imageIndex == 0)
            return (
                <View style={styles.coverContent}>
                    <Text style={styles.coverText}>
                        Ảnh bìa
                    </Text>
                </View>
            )
    }

    _renderDeleteButton() {
        if (this.props.imageIndex != 0)
            return (
                <TouchableOpacity
                    style={styles.deleteContent}
                    onPress={this._onDeletePhoto.bind(this)} >

                    <View style={styles.deleteButton}>
                        <FontAwesomeLight name="times" color={'#fff'}
                            size={12}
                            noAction={true}
                            iconOnly={true}
                        />
                    </View>
                </TouchableOpacity>
            )
    }

    _renderImageLabel() {
        return (
            <View style={styles.imageLabelContent}>
                <Text style={styles.imageLabelText}>
                    Thêm ảnh
                </Text>
            </View>
        )
    }

    render() {
        log.info("PostAdsDetail.render ");
        let photo = this.props.photo;

        if (photo && photo.uri) {
            return (
                <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
                    <ImageBackground style={styles.imgItem} source={photo} >
                        {this._renderDeleteButton()}
                        {this._renderCoverTitle()}
                    </ImageBackground>
                </TouchableOpacity>
            );
        } else {
            return (
                <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
                    <View style={[styles.imgItem, { justifyContent: 'flex-end' }]}>
                        {/*<RelandIcon name="plus" color={'#3897F1'}*/}
                        {/*mainProps={styles.captureIcon}*/}
                        {/*size={36} textProps={{ paddingLeft: 0 }}*/}
                        {/*noAction={true}*/}
                        {/*/>*/}
                        {/*this._renderCoverTitle()*/}
                        <FontAwesomeLight name="plus" size={36} color={'#3897F1'} noAction={true} iconOnly={true} />
                        {this._renderImageLabel()}
                    </View>
                </TouchableOpacity>
            );
        }

    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderButton: {
        height: 50,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 20 // style for iOs status bar
    },
    viewBackIcon: {
        // height: 38,
        // width: 38,
        // justifyContent: 'flex-end',
        // alignItems: 'flex-start'
        position: 'absolute',
        top: 14,
        left: 0
    },
    viewTextLabel: {
        marginTop: 0,
        marginLeft: 44,
        marginRight: 44,
        width: width - 120,
        alignItems: 'center',
        justifyContent: 'flex-start'
    },
    viewSubLabel: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    textSavePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainAgentColor
    },
    viewTextSave: {
        position: 'absolute',
        top: 14,
        right: 0
    },
    viewLoaiTinDang: {
        height: 38,
        width: width - 32,
        flexDirection: 'row',
        marginLeft: 16,
        marginRight: 16,
        marginTop: 20,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    loaiTinContent: {
        height: 38,
        width: 'auto',
        justifyContent: 'center',
        alignItems: 'flex-start',
        position: 'absolute',
        left: 0
    },
    viewChangeLoaiTin: {
        height: 38,
        width: 'auto',
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        position: 'absolute',
        right: 0
    },
    textLoaiTin: {
        fontFamily: gui.fontFamily,
        fontSize: 22,
        fontWeight: '500',
        color: gui.mainTextColor,
        justifyContent: 'flex-end'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff',
        // marginBottom: 20
    },
    viewImagePost: {
        // height: 160,
        width: width,
        paddingLeft: 8,
        flexDirection: 'row',
        backgroundColor: '#fff',
        alignItems: 'flex-end',
        marginTop: 12,
        marginBottom: 12,
        paddingRight: 15,
        // paddingLeft: 17,
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 180,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center',
        zIndex: 1
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 106,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    textDelete: {
        color: '#f43838',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    mimgList: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        paddingLeft: 12,
        paddingRight: 10,
        backgroundColor: 'white'
    },
    coverContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.8,
        bottom: 2,
        left: 2,
        alignSelf: 'auto',
        paddingHorizontal: 2
    },
    coverText: {
        alignItems: 'center',
        fontFamily: gui.fontFamily,
        fontSize: 13
    },
    deleteContent: {
        position: 'absolute',
        opacity: 0.9,
        top: 4,
        right: 4,
        alignSelf: 'auto'
    },
    deleteButton: {
        backgroundColor: '#363636',
        justifyContent: 'center',
        alignItems: 'center',
        width: 20,
        height: 20,
        borderRadius: 10
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    imgItem: {
        width: 92, //(width - 50) / 4,
        height: 92, //(width - 50) / 4,
        backgroundColor: '#D8ECFF',
        justifyContent: 'center',
        borderWidth: 1,
        marginLeft: 5,
        borderColor: '#3897F1',
        borderStyle: 'dashed'
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    viewNamePost: {
        marginTop: 31,
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginRight: 16
    },
    textBaiDang: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    viewInputPost: {
        width: width - 32,
        height: 'auto',
        marginTop: 18,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotStyle: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: gui.dotColor,
        position: 'absolute',
        right: 8
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 20,
        backgroundColor: '#fff',
        width: width - 70,
        //paddingLeft: 16,
        color: gui.mainTextColor,
    },
    viewTextBasic: {
        flex: 1,
        backgroundColor: '#F8F8F8'
        // height: 32,
        // width: width,
        // marginTop: 33,
        // marginLeft: 16,
        // marginRight: 16,
    },
    viewButtonTab: {
        height: 49,
        width: width,
        // position: 'absolute',
        // bottom: 0,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewTextPreview: {
        height: 49,
        width: width / 2,
        paddingLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPostAdsButton: {
        height: 49,
        width: width / 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textPreview: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainAgentColor
    },
    postAdsButton: {
        height: 40,
        width: 158,
        borderRadius: 20,
        backgroundColor: gui.mainAgentColor,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewKieuNha: {
        // height: 41,
        width: width - 32,
        flexDirection: 'row',
        marginTop: 16,
        marginBottom: 16,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewEachInfo: {
        height: 55,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    textKieuNha: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    touchKieuNha: {
        position: 'absolute',
        right: 0,
        flexDirection: 'row'
    },
    textResult: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.colorMainBlur
    },
    viewMiniMap: {
        height: 184,
        width: width - 32,
        marginRight: 16,
        marginLeft: 16,
        marginTop: 15,
        backgroundColor: 'skyblue'
    },
    viewMoreInfo: {
        height: 17,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        marginTop: 23,
        marginBottom: 22,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textMoreInfo: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: '500',
        color: gui.mainAgentColor
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        marginBottom: 6
    },
    viewSamePrice: {
        height: 41,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        marginTop: 10
    },
    textSamePrice: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.colorMainBlur
    },
    textChange: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.mainAgentColor
    },
    resultContainer: {
        position: 'absolute',
        top: height / 2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    loadingContent: {
        position: 'absolute',
        top: -23,
        left: width / 2 - 15,
        alignItems: 'center',
        justifyContent: 'center'
    },
    dienTichInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 30,
        borderColor: gui.mainTextColor,
        width: width / 2,
        textAlign: 'right',
        alignSelf: 'center',
        fontWeight: '500',
        color: gui.mainTextColor
    },
    tieuDeLength: {
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        fontSize: 11,
        color: gui.mainAgentColor,
    },
    viewLoaiTinStyle: {
        justifyContent: 'center',
        height: 120,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    textSapxep: {
        fontSize: 17,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewTitleGroup: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily
    },
    viewChonSan: {
        flex: 1,
        backgroundColor: gui.groupBackground2
    },
    touchChonSan: {
        position: 'absolute',
        right: 0,
        flexDirection: 'row',
        alignItems: 'center'
    },
    imageLabelContent: {
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 8
    },
    imageLabelText: {
        marginTop: 6,
        fontFamily: gui.fontFamily,
        fontSize: 13,
        color: '#3897F1'
    },
    bottomLine: {
        position: 'absolute',
        top: 0
    },
    daChonSubView: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginLeft: 16,
        marginRight: 16,
        flexWrap: 'wrap',
        flex: 1
    },
    chonSanSubView: {
        width: width - 32,
        flexDirection: 'row',
        // padding: 7,
        marginTop: 8,
        justifyContent: 'flex-start',
        backgroundColor: 'transparent'
    },
    chonSanText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#464646',
        textAlign: 'left',
        width: width - 85,
        marginLeft: 5
    },
    viewAvatar: {
        height: 36,
        width: 36,
        borderRadius: 18
    },
    viewGroupDetail: {
        height: 53,
        width: width - 44,
        //paddingLeft: 16,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewShareAds: {
        width: width - 16,
        marginLeft: 8,
        marginRight: 8,
        height: 102,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewModalShareAds: {
        height: 102,
        width: width,
        backgroundColor: 'transparent'
    },
    viewShareTopContent: {
        width: width - 16,
        height: 44,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 12,
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        backgroundColor: '#fff'
    },
    viewShareBottomContent: {
        width: width - 16,
        height: 44,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 12,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
        backgroundColor: '#fff'
    },
    lineStyles: {
        width: width - 16,
        height: 1,
        backgroundColor: 'rgba(211,211,211,0.5)'
    },
    viewTriangle: {
        width: 0,
        height: 0,
        borderLeftWidth: 6,
        borderRightWidth: 6,
        borderBottomWidth: 12,
        borderStyle: 'solid',
        backgroundColor: 'transparent',
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderBottomColor: '#fff'
    },
    checkAds: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        marginLeft: 0
    },
    viewSaleState: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        paddingTop: 12
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewGuideAgentPost: {
        height: 110,
        width: width,
        flexDirection: 'row',
        backgroundColor: 'rgba(248,248,248,1)',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewImageGuide: {
        height: 110,
        width: 88,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imageGuideStyle: {
        height: 65,
        width: 55
    },
    guidePostContent: {
        width: width - 88,
        paddingRight: 16,
        justifyContent: 'center',
        height: 110,
    },
    viewPressSee: {
        height: 25,
        width: 25,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 6,
        right: 8
    },
    viewInfoMatching: {
        height: 'auto',
        width: 20,
        marginRight: 5,
        justifyContent: 'center',
        alignItems: 'center'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(NewPostAdsDetail);