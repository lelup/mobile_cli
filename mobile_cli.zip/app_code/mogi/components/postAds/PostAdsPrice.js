'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import {Map} from 'immutable';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import React, {Component} from 'react';

import {View, ScrollView, Text, TextInput, StyleSheet, Alert, TouchableOpacity} from 'react-native'

import {Actions} from 'react-native-router-flux';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import Button from 'react-native-button';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import DanhMuc from '../../assets/DanhMuc';

import MultipleChoice from '../MultipleChoice';

import TruliaIcon from '../TruliaIcon';

import FullLine from '../line/FullLine';

import gui from '../../lib/gui';
import log from '../../lib/logUtil';

import utils from '../../lib/utils';
import Toast, {DURATION} from '../toast/Toast';

/**
 * ## Redux boilerplate
 */
const actions = [
    globalActions,
    postAdsActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class PostAdsPrice extends Component {
    constructor(props) {
        super(props);
        let {gia} = props.postAds;
        let donViTienVal = this.getDonViTienVal();
        this.state = {
            gia: (gia && gia != -1) ? gia.toString() : '',
            donViTien: donViTienVal,
            toggleState: false
        };
    }

    getDonViTien() {
        return this.props.postAds.donViTien;
    }

    onUpdateGia(donViTien) {
        let gia = donViTien == 5 ? -1 : this.state.gia;
        this.props.actions.onPostAdsFieldChange("gia", gia);
        this.props.actions.onPostAdsFieldChange("donViTien", donViTien);
    }

    _renderGiaDetail () {
        let titleValue;
        let titleUnit;
        let donViTien = this.getKeyByValue(DanhMuc.getDonViTienValues(), this.state.donViTien);
        let price = DanhMuc.DonViTien[donViTien] || '';
        if (this.state.gia >= 0 && this.state.gia >= 1000 && price == "Triệu") {
            titleValue = `${utils.convertPriceTwoDot(this.state.gia)}`;
            titleUnit = 'Tỷ';
            return titleValue + " " + titleUnit;
        }

        if(this.state.gia >= 0 && this.state.gia >= 10 && price == "Trăm nghìn/m²") {
            titleValue = `${utils.convertPriceTen(this.state.gia)}`;
            titleUnit = "Triệu/m²";
            return titleValue + " " + titleUnit;
        }

        return `${this.state.gia} ${price}`;
    }

    onCheckValue (donViTien) {
        let loaiTin = this.props.loaiTin;
        let gia = donViTien == 5 ? -1 : this.state.gia;
        if(loaiTin == 'thue' && donViTien == 2 && gia >= 1 ) {
            Alert.alert(
                'Thông báo',
                `Bạn có chắc giá thuê là ${gia} ${DanhMuc.DonViTien[donViTien]}`,
                [
                    {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                    {text: 'Đồng ý', onPress: () =>  Actions.pop()},
                ],
            );
        } else if (loaiTin == 'thue' && donViTien == 1 && gia < 0.5 ) {
            Alert.alert(
                'Thông báo',
                `Bạn có chắc giá thuê là ${gia} ${DanhMuc.DonViTien[donViTien]}`,
                [
                    {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                    {text: 'Đồng ý', onPress: () =>  Actions.pop()},
                ],
            );
        } else if(loaiTin == 'ban' && donViTien == 2 && gia >= 500 ) {
            Alert.alert(
                'Thông báo',
                `Bạn có chắc giá bán là ${gia} ${DanhMuc.DonViTien[donViTien]}`,
                [
                    {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                    {text: 'Đồng ý', onPress: () =>  Actions.pop()},
                ],
            );
        } else if(loaiTin == 'ban' && donViTien == 1 && gia < 50 ) {
            Alert.alert(
                'Thông báo',
                `Bạn có chắc giá bán là ${gia} ${DanhMuc.DonViTien[donViTien]}`,
                [
                    {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                    {text: 'Đồng ý', onPress: () =>  Actions.pop()},
                ],
            );
        } else  Actions.pop();
    }

    getDonViTienVal() {
        let donViTien = this.getDonViTien();
        let donViTienValues = DanhMuc.getDonViTienValues();
        let donViTienVal = this.getValueByKey(donViTienValues, donViTien);
        // if (!donViTienVal) {
        //     donViTienVal = donViTienValues[0];
        // }
        return donViTienVal;
    }

    render() {
        let priceHolder = 'Nhập giá tiền';
        let headerTitle = "Giá tiền";
        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={myStyles.customPageHeader}>
                    {/*<TruliaIcon onPress={this._onBack.bind(this)}*/}
                                {/*name="arrow-left" color={gui.mainColor} size={26}*/}
                                {/*mainProps={myStyles.backButton} text={this.props.backTitle}*/}
                                {/*textProps={myStyles.backButtonText} >*/}
                    {/*</TruliaIcon>*/}
                    <TouchableOpacity style={myStyles.viewBackIcon}
                                      onPress={this._onBack.bind(this)}>
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} style={{ marginLeft: 16 }} />
                    </TouchableOpacity>
                    <View style={myStyles.customPageTitle}>
                        <Text style={[myStyles.customPageTitleText, {color: gui.textAgentSolid}]}>
                            {headerTitle}
                        </Text>
                    </View>
                    <TouchableOpacity style={myStyles.viewDonePress}
                                      onPress={this._onXong.bind(this)}
                    >
                        <Text style={[myStyles.customPageTitleText, {fontWeight: '500', fontSize: 15, color: gui.mainColor}]}>
                            Xong
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={myStyles.optionSeparator}>
                    <Text style={myStyles.label}>GIÁ HIỂN THỊ: {this._renderGiaDetail()}</Text>
                </View>
                <FullLine />
                <View style={[myStyles.optionSeparator, {backgroundColor: 'white'}]}>
                    <TextInput
                        ref={(input) => this._giaInput = input}
                        secureTextEntry={false}
                        autoFocus={true}
                        keyboardType={'numeric'}
                        style={myStyles.input}
                        value={this.state.gia}
                        placeholder={priceHolder}
                        onChangeText={(text) => {
                            this.onValueChange("gia", text);
                            if (text && this.state.donViTien == DanhMuc.DonViTien[5]) {
                                this.setState({donViTien: ''});
                            }
                        }} />
                </View>
                <FullLine />
                <View style={myStyles.optionSeparator}>
                    <Text style={myStyles.label}>ĐƠN VỊ</Text>
                </View>
                <FullLine />
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={100}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
                <View style={myStyles.optionSeparator} />
                <ScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode={'none'}
                    automaticallyAdjustContentInsets={true}
                    vertical={true}
                >
                    <MultipleChoice
                        options={DanhMuc.getDonViTienValues()}
                        style={myStyles.choiceList}
                        selectedOptions={[this.state.donViTien]}
                        maxSelectedOptions={1}
                        onSelection={(option)=>this._onApply(option)}
                    />
                </ScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                  style={[myStyles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                      backgroundColor: gui.doneKeyButton }]}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState});
    }

    onValueChange(key, value) {
        if (value === '' || value === '.' || value === ',') {
            value = '';
        }
        let valueNumber = utils.interestNumeric(value);
        if(utils.countDot(valueNumber, '\\.') >= 2){
            this.refs.toastTop && this.refs.toastTop.show('Bạn nhập không đúng định dạng số!',DURATION.LENGTH_SHORT);
            return;
        }
        let newState = {};
        newState[key] = valueNumber.replace(',','.');
        this.setState(newState);
    }

    _onBack() {
        Actions.pop();
    }

    _onApply(option) {
        var donViTien = this.getKeyByValue(DanhMuc.getDonViTienValues(), option);
        this.state.donViTien = option;
        if (!this.isValidInputData()) {
            this.setState({donViTien: option});
            return;
        }
        this.onUpdateGia(donViTien);
        if (this.state.gia || option == DanhMuc.DonViTien[5]) {
            // Actions.pop();
        }
        this.setState({donViTien: option});
    }
    _onXong(){
        if (!this.isValidInputData()) {
            return;
        }
        let donViTien = this.getKeyByValue(DanhMuc.getDonViTienValues(), this.state.donViTien);
        this.onUpdateGia(donViTien);
        this.onCheckValue(donViTien);
    }


    isValidInputData() {
        var {gia, donViTien} = this.state;
        if (donViTien && donViTien != DanhMuc.DonViTien[5] && !gia) {
            Alert.alert(
                'Thông báo',
                'Bạn chưa nhập giá!',
                [{ text: 'Đóng', onPress: () => {
                        this._giaInput && this._giaInput.focus();
                    }
                }]
            );
            return false;
        }
        if (gia && isNaN(gia)) {
            Alert.alert(
                'Thông báo',
                'Bạn nhập sai kiểu giá!',
                [{
                    text: 'Đóng', onPress: () => { }
                }]
            );
            return false;
        }
        if (!donViTien) {
            Alert.alert(
                'Thông báo',
                'Bạn chưa chọn đơn vị tiền!',
                [{
                    text: 'Đóng', onPress: () => { }
                }]
            );
            return false;
        }
        return true;
    }

    getValueByKey(values, key) {
        var value = '';
        for (var i = 0; i < DanhMuc.DonViTienKey.length; i++) {
            var loaiKey = DanhMuc.DonViTienKey[i];
            if (key === loaiKey) {
                value = values[i];
                break;
            }
        }
        //console.log(value);
        return value;
    }

    getKeyByValue(values, value) {
        var key = '';
        for (var i = 0; i < values.length; i++) {
            var oneValue = values[i];
            if (value === oneValue) {
                key = DanhMuc.DonViTienKey[i];
                break;
            }
        }
        //console.log(key);
        return key;
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(PostAdsPrice);



// Later on in your styles..
var myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    choiceList: {
        paddingTop: 10,
        paddingLeft: 26,
        paddingRight: 0
    },
    searchButton: {
        alignItems: 'stretch',
        justifyContent: 'flex-end'
    },
    searchButtonWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 44
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    optionSeparator: {
        borderTopWidth: 0,
        backgroundColor: '#F6F6F6',
        paddingLeft: 10,
        paddingRight: 10
    },
    paddingSeparator: {
        padding: 10,
        paddingTop: 13,
        paddingBottom: 14
    },
    label: {
        marginLeft: 15,
        marginRight: 15,
        marginTop: 9,
        marginBottom: 9,
        color: '#A7A7A7',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        paddingLeft: 10,
        paddingRight: 10,
        width: utils.getDimensions().width-30,
        height: 30,
        margin: 5,
        textAlign: 'left',
        alignSelf: 'center',
        paddingVertical: 0
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#fff',
        height: 60
    },
    customPageTitle: {
        left:36,
        right:36,
        marginTop: 31,
        marginBottom: 10,
        position: 'absolute'
    },
    customPageTitleText: {
        color: gui.mainColor,
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: 'white',
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    viewDonePress:{
        position: 'absolute',
        right: 8,
        width: 60,
        backgroundColor: 'transparent',
        alignItems: 'center',
        marginTop: 31
    },
    viewBackIcon: {
        height: 38,
        width: 38,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        marginTop: gui.marginTopAgent
    },
});

