import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ListView,
    ScrollView,
    Linking
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import ScalableText from 'react-native-text';
import { Actions } from 'react-native-router-flux';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import log from '../../lib/logUtil';
import cfg from '../../cfg';
import DanhMuc from '../../assets/DanhMuc';
import SelectSitesLink from './SelectSitesLink';
let {width, height} = util.getDimensions();

class ReviewWebPosted extends Component {
    constructor(props) {
        super(props);
        let {sites} = props.postAdsToOtherWebsite;
        this.state = {
            loading: false,
            sites: sites,
            selectedSites: sites
        }
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBody()}
            </View>
        )
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: 'bold', fontSize: 15}]}>
                        Các websites đã đăng
                    </ScalableText>
                </View>
                <View style={styles.viewEdit} />
            </View>
        );
    }

    _renderBody() {
        return(
            <View style={styles.viewBody}>
                {this.renderSites()}
            </View>
        )
    }

    renderSites() {
        return(
            <View style={{flex: 1}}>
                <SelectSitesLink
                    items={this.state.sites}
                    selectedItems={this.state.selectedSites}
                    selectedLabelStyle={{color: gui.mainColor}}
                    selectedRowStyle={{backgroundColor: '#f6f6f6'}}
                    selectedCheckboxStyle={{width: 19}}
                    rowStyle={{paddingLeft: 20, paddingTop: 5, paddingBottom: 5}}
                    onSelectionsChange={this.onSelectionsChange.bind(this)}
                    onPressLinkChange={(data) => this.onPressLinkChange(data)} />
            </View>
        )
    }

    onSelectionsChange() {
        log.info('==========> onSelectionsChange');
    }
    onPressLinkChange(data) {
        let link = data.value;
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }


    _onBackPress() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#dcdcdc'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 80,
        paddingRight: 21
    },
    viewEdit: {
        paddingTop: 15,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 80
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
});

export default ReviewWebPosted;