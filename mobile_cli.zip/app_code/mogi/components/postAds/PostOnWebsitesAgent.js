import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    Image,
    ListView,
    StyleSheet,
    ScrollView,
    Linking,
    FlatList,
    Alert,
    TextInput
} from 'react-native';

import ScalableText from 'react-native-text';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import log from '../../lib/logUtil';
import cfg from '../../cfg';
import SelectMultiBox from './SelectMultiBox';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import dismissKeyboard from 'react-native-dismiss-keyboard';

import CheckDot from '../detail/CheckDot';

import GiftedSpinner from 'react-native-gifted-spinner';

let {width, height} = util.getDimensions();

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';

const actions = [
    globalActions,
    adsMgmtActions,
    postAdsActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class PostOnWebsitesAgent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            couponCode: '',
            sites: [],
            postToWebsitesServices: [{fees: [{price: 0}]}],
            selectedSites: [],
            selectedWebsitesServiceIndex: 0,
            isSelectedAll: false,
        }
    }

    componentWillMount() {
        this._getAllWebsiteService();
    }

    _getAllWebsiteService() {
        this.props.actions.findAllWebsiteService().then( e => {
            // log.info('=======service', e);
            if (e.status == 0 && e.services && e.services.length > 0) {
                let services = e.services;
                let selectedIndex = 0;
                let sites = services[selectedIndex].sites;
                let isLackMoney = this._isLackServiceMoney(services[selectedIndex]);
                let hasPostAdsToOtherWebsite = this._hasPostAdsToOtherWebsite();
                let selectedSites = isLackMoney || hasPostAdsToOtherWebsite ? [] : sites;
                let isSelectedAll = !isLackMoney && !hasPostAdsToOtherWebsite;
                this.setState({sites: sites, selectedSites: selectedSites, isSelectedAll: isSelectedAll, postToWebsitesServices: services, selectedWebsitesServiceIndex: selectedIndex});
            }
        });
    }

    _isLackServiceMoney(postToWebsitesService) {
        let {main} = this.props.global.currentUser.account;
        let postToWebsitesServiceFee = postToWebsitesService ? postToWebsitesService.fees[0].price : 0;
        return main < postToWebsitesServiceFee;
    }

    _setSelectedWebsitesService(value) {
        this.setState({selectedWebsitesServiceIndex: value});
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBody()}
                {this._renderLoadingView()}
            </View>
        );
    }

    _renderLoadingView() {
        if (this.state.loading) {
            return (
                <View style={styles.loadingContent}>
                    <GiftedSpinner size="large" color={'#d3d3d3'} />
                </View>
            )
        }
    }

    _renderHeaderAds() {
        let title = this._hasPostAdsToOtherWebsite() ? 'Cập nhật tin trên nhiều websites' : 'Đăng tin trên nhiều websites';
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 14}]}>
                        {title}
                    </ScalableText>
                </View>
                <View style={styles.viewEdit} />
            </View>
        );
    }

    _renderBody() {
        return(
            <View style={styles.viewBody}>
                {this.renderBottomTab()}
                {this.renderSites()}
            </View>
        );
    }

    renderPackageTab() {
        let {postToWebsitesServices, selectedWebsitesServiceIndex, isSelectedAll} = this.state;
        let selectedPackage = postToWebsitesServices[selectedWebsitesServiceIndex];
        let selectedPackageCode = selectedPackage ? selectedPackage.code : '';
        let packageItems = [];
        let index = 0;
        postToWebsitesServices.forEach((one) => {
            packageItems.push(
                <CheckDot name={one.code} key={one.code + '_' + index}
                          onPress={this._onPackagePress.bind(this)}
                          disabled={!isSelectedAll}
                          selected={isSelectedAll && selectedPackageCode == one.code}
                          mainProps={styles.viewPackageTab}>{one.name + ' (' + util.addCommas(one.fees[0].price) + ' VNĐ)'}</CheckDot>
            );
            index++;
        });
        let checkTextColor = isSelectedAll ? gui.mainColor : gui.mainTextColor;
        return (
            <View style={{flex: 0, marginTop: 15, marginBottom: 15}}>
                <Text style={[styles.textCheckAll, {width: width-58, color: checkTextColor, marginLeft: 15, marginBottom: 10}]}>
                    Gói đăng tin trên Landber
                </Text>
                {packageItems}
            </View>
        );
    }

    _onPackagePress(value) {
        let {postToWebsitesServices, isSelectedAll} = this.state;
        if (isSelectedAll) {
            let index = this._getPackageIndexByCode(value);
            let selectedPackage = postToWebsitesServices[index];
            let isLackMoney = this._isLackServiceMoney(selectedPackage);
            if (isLackMoney) {
                Alert.alert(
                    'Thông báo',
                    'Tài khoản chính của bạn không đủ để sử dụng gói dịch vụ này',
                    [
                        {text: 'Đóng', onPress: () =>  { }},
                    ]
                );
            } else {
                this.setState({loading: true});
                this._resetSelectedSites();
                setTimeout(() => {
                    this._doPackagePress(index);
                    this.setState({loading: false});
                }, 300);
            }
        }
    }

    _resetSelectedSites() {
        this.setState({selectedSites: []});
    }

    _doPackagePress(index) {
        let {postToWebsitesServices, isSelectedAll} = this.state;
        if (isSelectedAll) {
            let selectedPackage = postToWebsitesServices[index];
            let sites = [...selectedPackage.sites];
            this.setState({selectedWebsitesServiceIndex: index, sites: sites, selectedSites: sites});
        }
    }

    _getPackageIndexByCode(code) {
        let {postToWebsitesServices} = this.state;
        let index = -1;
        for (let i=0; i<postToWebsitesServices.length; i++) {
            let one = postToWebsitesServices[i];
            if (one.code == code) {
                index = i;
                break;
            }
        }
        return index;
    }

    _getNumberOfWebs() {
        let {sites} = this.state;
        return sites ? sites.length : 0;
    }

    _isLackMoney() {
        let {postToWebsitesServices, selectedWebsitesServiceIndex} = this.state;
        if (selectedWebsitesServiceIndex < 0) {
            return false;
        }
        let postToWebsitesService = postToWebsitesServices[selectedWebsitesServiceIndex];
        return this._isLackServiceMoney(postToWebsitesService);
    }

    _hasPostAdsToOtherWebsite() {
        let ads = this.props.ads;
        return ads && ads.postAdsToOtherWebsite != undefined;
    }

    renderBottomTab() {
        let imageAlert = require('../../assets/image/post_webs/icon-04.png');
        let numberOfWebs = this._getNumberOfWebs();
        let textPricePost = `Tổng số ${numberOfWebs} websites`;
        let warningItems = null;
        let isLackMoney = this._isLackMoney();
        if (isLackMoney) {
            let warningMsg = 'Tài khoản chính của bạn không đủ, cần nạp thêm tiền để sử dụng dịch vụ này, nhấn Tiếp tục để đăng tin';
            warningItems = <View>
                <FullLine/>
                <ScalableText style={styles.textWarning}>{warningMsg}</ScalableText>
            </View>;
        }
        let textNext = 'Tiếp tục';
        let backgroundColor = this.state.isSelectedAll ? '#f36523' : '#C5C2BA';
        let mainButtons = (
            <View style={styles.viewNextStep}>
                <TouchableOpacity style={[styles.viewButtonNext, {backgroundColor: backgroundColor}]}
                                  onPress={this._onNextPress.bind(this)}
                                  disabled={!this.state.isSelectedAll}
                >
                    <Text style={styles.textNextButton}>{textNext}</Text>
                </TouchableOpacity>
            </View>
        );
        if (this.props.postAds.uploading || this.props.me.isUpdatingProfile || this.state.loading) {
            mainButtons = (
                <View style={styles.viewNextStep}>
                    <View style={[styles.viewButtonNext, {backgroundColor: 'transparent', alignItems: 'flex-end'}]}>
                        <GiftedSpinner color="#8A8A8A" />
                    </View>
                </View>
            );
        }

        return(
            <View style={styles.viewBottomTab}>
                <FullLine/>
                <View style={[styles.viewTotalChoose, {paddingLeft: 15}]}>
                    <Image
                        resizeMode={"cover"}
                        source={imageAlert}
                        defaultSource={imageAlert}
                        style={styles.imageAlert} />
                    <Text style={styles.textPriceTotal}>
                        {textPricePost}
                    </Text>
                </View>
                {warningItems}
                <FullLine/>
                <View style={[styles.viewTotalChoose, {height: 53}]}>
                    {mainButtons}
                </View>
            </View>
        );
    }

    _onNextPress() {
        let couponCode = this.state.couponCode;
        let usePostAdsToOtherWebsite = this.state.isSelectedAll;
        if (usePostAdsToOtherWebsite) {
            let {postToWebsitesServices, selectedWebsitesServiceIndex} = this.state;
            let service = postToWebsitesServices[selectedWebsitesServiceIndex];

            if (couponCode && couponCode.length > 0) {
                let couponDto = {
                    serviceType: 1,
                    couponCode: couponCode,
                    serviceID: service.id
                }

                this._verifyCouponCode(couponDto, this._doAfterVerifyCouponPostToSites.bind(this, couponCode));
            } else {
                this._doUpdatePostToSites();
            }
        }
    }

    _verifyCouponCode(couponDto, callback) {
        let currentUser = this.props.global.currentUser;
        this.props.actions.checkCouponHieuLuc(couponDto, currentUser.token).then(
            (res) => {
                callback(res);
            });
    }

    _doAfterVerifyCouponPostToSites(couponCode, res) {
        if (res.status !== 0) {
            let msg = res.msg + '. Bạn có tiếp tục đăng tin?';
            Alert.alert('Thông báo', msg,
                [   { text: 'Huỷ', onPress: () => { }
                },
                    {
                        text: 'Đồng ý', onPress: () => {
                        this._doUpdatePostToSites();
                    }
                    }
                ]);
        } else {
            let msg = res.msg + '. Bạn chắc chắn sử dụng mã khuyến mại này?';
            Alert.alert('Thông báo', msg,
                [   { text: 'Huỷ', onPress: () => { }
                },
                    {
                        text: 'Đồng ý', onPress: () => {
                        this._doUpdatePostToSites(couponCode);
                    }
                    }
                ]);
        }
    }

    _doUpdatePostToSites(couponCode) {
        let {postToWebsitesServices, selectedWebsitesServiceIndex, sites} = this.state;
        let service = postToWebsitesServices[selectedWebsitesServiceIndex];

        let fee = service.fees[0];

        let postAdsToOtherWebsite = { userID: this.props.global.currentUser.userID,
            workstation:
                { name: this.props.global.deviceInfo.deviceModel,
                    workstationID: this.props.global.deviceInfo.deviceID,
                    appType: 'app' },
            price: { discount: fee.discount,
                price: fee.price,
                soLanSuDung: fee.soLanSuDung,
                type: fee.type},
            service: { id: service.id,
                name: service.name,
                level: service.level,
                //days: fee[0].soLanSuDung,
                packageType: 1,
                couponCode: couponCode || undefined
            },
            sites: sites };

        this._onPostAdsToOtherWebsite(postAdsToOtherWebsite);
    }

    _onPostAdsToOtherWebsite(postAdsToOtherWebsite) {
        let ads = this.props.ads;
        let adsID = ads.adsID || ads.id;
        if (postAdsToOtherWebsite) {
            postAdsToOtherWebsite.adsID = adsID;
            let currentUser = this.props.global.currentUser;
            let token = currentUser.token;

            this.setState({loading: true})

            this.props.actions.postAdsToOtherWebsite(postAdsToOtherWebsite, token)
                .then(res => {
                    this.setState({
                        loading: false
                    });
                    if (res.status != 0) {
                        Alert.alert("Thông báo", res.msg, [ { text: 'Đóng', onPress: () => {} } ]);
                    } else {
                        this._doAfterPostAds();
                    }
                });
        }
    }

    _doAfterPostAds() {
        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        Alert.alert("Thông báo", "Thay đổi thành công!", [ { text: 'Đóng', onPress: () => {
            Actions.pop();
            Actions.pop();
        } } ]);
    }

    renderSites() {
        let isLackMoney = this._isLackMoney();
        let actionLabel = this._hasPostAdsToOtherWebsite() ? 'cập nhật tin' : 'đăng tin';
        let checkLabel = 'Đồng ý ' + actionLabel + ' trên nhiều websites';
        let isSelectedAll = this.state.isSelectedAll;
        let imageCheck = isSelectedAll ? require('../../assets/image/post_webs/icon-03.png') : require('../../assets/image/post_webs/icon-02.png');
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let checkTextColor = isSelectedAll ? gui.mainColor : gui.mainTextColor;
        return(
            <ScrollView style={{flex: 1, marginBottom: isLackMoney ? 130 : 90}}
                        ref={(scrollView) => { this._scrollView = scrollView; }}
                        automaticallyAdjustContentInsets={false}
                        showsVerticalScrollIndicator={false}
                        onLayout={event => {
                            this._scrollViewHeight = event.nativeEvent.layout.y
                        }}
                        vertical={true}
            >
                <TouchableOpacity style={styles.viewCheckAll}
                                  onPress={this._onSelectAll.bind(this)}
                                  disabled={isLackMoney}
                >
                    <Image
                        resizeMode={"cover"}
                        source={imageCheck}
                        defaultSource={defaultCover}
                        style={[styles.imageAlert, {width: isSelectedAll ? 18 : 16}]} />
                    <Text style={[styles.textCheckAll, {width: width-58, color: checkTextColor}]}>
                        {checkLabel}
                        {/*<Text style={[styles.textPriceTotal, {color: 'red', fontWeight: 'bold'}]}>{priceValue}</Text>*/}
                    </Text>
                </TouchableOpacity>
                <FullLine/>
                {this.renderPackageTab()}
                {this.renderCouponCode()}
                <FullLine/>
                <Text style={[styles.textCheckAll, {width: width-58, color: checkTextColor, marginLeft: 15, marginTop: 15, marginBottom: 10}]}>
                    Danh sách websites
                </Text>
                <SelectMultiBox
                    items={this.state.sites}
                    selectedItems={this.state.selectedSites}
                    selectedLabelStyle={{color: gui.mainColor}}
                    selectedRowStyle={{backgroundColor: '#f6f6f6'}}
                    rowStyle={{paddingLeft: 25, paddingTop: 5, paddingBottom: 5, borderBottomWidth: 0}}
                    selectedCheckboxStyle={{width: 19}}
                    onSelectionsChange={this._onSelectionsChange.bind(this)} />
            </ScrollView>
        )
    }

    renderCouponCode() {
        let isSelectedAll = this.props.isSelectedAll;
        let labelColor = isSelectedAll ? gui.mainColor : gui.mainTextColor;
        let couponLabel = 'Nhập mã khuyến mại đăng tin nhiều website:';
        let couponPlaceholder = 'Mã khuyến mại';
        return (
            <View style={{marginBottom: 15}}>
                <Text style={[styles.couponLabel, {color: labelColor}]} >{couponLabel}</Text>
                <TextInput style={styles.couponInput}
                           placeholder={couponPlaceholder}
                           placeholderTextColor={gui.arrowColor}
                           value={this.state.couponCode}
                           onChangeText={(text) => this.setState({couponCode: text})}
                           maxLength={6}
                           autoCorrect={false}
                           autoCapitalize={'characters'}
                           returnKeyType='done'
                           onSubmitEditing={() => dismissKeyboard()}
                           editable={isSelectedAll}
                           onFocus={() => this._onCouponCodeFocus()}
                />
            </View>
        );
    }

    _onCouponCodeFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + height/4;
            this._scrollView.scrollTo({y: scrollTo});
        }
    }

    _onSelectionsChange = (selectedSites) => {
        // let totalPrice = util.addCommas(selectedSites.length*2000);
        // this.setState({selectedSites: selectedSites, numberOfWebs: selectedSites.length, totalPrice: totalPrice});
    };

    _onSelectAll() {
        let isSelectedAll = this.state.isSelectedAll;
        if (this._hasPostAdsToOtherWebsite() && !isSelectedAll) {
            Alert.alert(
                'Thông báo',
                'Tin này đã đăng ký đăng trên nhiều websites ở lần đăng tin trước. Bạn có muốn đăng lại trên nhiều websites, '
                + 'tài khoản chính của bạn sẽ bị trừ tiền',
                [
                    {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                    {text: 'Đồng ý', onPress: () =>  {this._doSelectAll()}},
                ],
            );
        } else {
            this._doSelectAll();
        }
    }

    _doSelectAll() {
        let {postToWebsitesServices, selectedWebsitesServiceIndex, sites, isSelectedAll} = this.state;
        let newSites = sites;
        let newSelectedSites = sites;
        let selectedPackageIndex = selectedWebsitesServiceIndex;
        if (isSelectedAll) {
            selectedPackageIndex = -1;
            newSites = [...postToWebsitesServices[0].sites];
            newSelectedSites = [];
        } else if (selectedPackageIndex == -1) {
            selectedPackageIndex = 0;
            newSites = [...postToWebsitesServices[0].sites];
            newSelectedSites = [...postToWebsitesServices[0].sites];
        }
        this.setState({
            selectedWebsitesServiceIndex: selectedPackageIndex,
            selectedSites: newSelectedSites,
            sites: newSites,
            isSelectedAll: !isSelectedAll,
            couponCode: ''
        });
    }

    _onBackPress() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 50
    },
    viewEdit: {
        paddingTop: 15,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 50
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewBottomTab: {
        // height: 85,
        width: width,
        backgroundColor: '#fff',
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0
    },
    viewTotalChoose: {
        height: 35,
        width: width,
        flexDirection: 'row',
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    imageAlert: {
        height: 16,
        width: 18
    },
    textPriceTotal: {
        fontSize: 13,
        fontWeight: 'normal',
        color: 'black',
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    textWarning: {
        fontSize: 13,
        fontWeight: '500',
        color: 'red',
        fontFamily: gui.fontFamily,
        marginLeft: 10,
        marginRight: 10
    },
    viewCheckAll: {
        height: 53,
        // width: width/2,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 15
    },
    textCheckAll: {
        fontSize: 14,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    textSort: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewNextStep: {
        height: 53,
        width: width,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingRight: 10
    },
    viewButtonNext: {
        paddingVertical: 5,
        paddingHorizontal: 8,
        backgroundColor: '#f36523',
        borderRadius: 5,
        // width: 70
    },
    textNextButton: {
        fontSize: 14,
        fontWeight: 'normal',
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    imageHelp: {
        height: 12,
        width: 12,
        marginRight: 8
    },
    viewBaoGia: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexDirection: 'row',
        height: 53,
        width: 80
    },
    viewSortTab: {
        height: 38,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewSortAlphabet: {
        height: 45,
        width: width/2,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchableSort: {
        flexDirection: 'row',
        marginLeft: 3,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewLineHard: {
        width: width,
        height: 7,
        backgroundColor: '#f6f6f6',
    },
    lineTabSort: {
        height: 30,
        width: 1,
        backgroundColor: '#f6f6f6',
        opacity: 0.9
    },
    viewModalStyle : {
        justifyContent: 'center',
        height: 120,
        width: width - 120,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor:'#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep:{
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    textSapxep: {
        fontSize: 16,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewPackageTab: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width - 30,
        paddingLeft: 20,
        height: 30
    },
    loadingContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    couponLabel: {
        fontSize: 14,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        paddingLeft: 15
    },
    couponInput: {
        fontSize: 14,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        width: 200,
        height: 38,
        borderWidth: 1,
        borderColor: 'lightgray',
        borderRadius: 5,
        padding: 5,
        marginLeft: 20,
        marginTop: 5,
        marginBottom: 5
    }
});

export default  connect(mapStateToProps, mapDispatchToProps)(PostOnWebsitesAgent);