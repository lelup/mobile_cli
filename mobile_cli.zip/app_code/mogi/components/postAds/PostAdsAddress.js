'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import React, {Component} from 'react';

import { Text, View, StyleSheet, TextInput, StatusBar, TouchableOpacity, Alert } from 'react-native'

import TruliaIcon from '../TruliaIcon';

import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import placeUtil from "../../lib/PlaceUtil";
import utils from "../../lib/utils";
import danhMuc from "../../assets/DanhMuc";
import ScalableText from 'react-native-text';
import FullLine from '../line/FullLine';
import GiftedSpinner from 'react-native-gifted-spinner';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const actions = [
  globalActions,
  postAdsActions
];

function mapStateToProps(state) {
  return {
      ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
          .merge(...actions)
          .filter(value => typeof value === 'function')
          .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}



class PostAdsAddress extends Component {
  constructor(props) {
      super(props);
      StatusBar.setBarStyle('default');
      let {selectedDiaChinh, place} = this.props.postAds;

      this.state = {
          diaChiChiTiet: place.diaChiChiTiet,
          selectedDiaChinh: selectedDiaChinh
      };
  }

  render() {
    let ghiChuDuongPho = 'Ví dụ: Nhà số 09, ngách 12, ngõ 68';
    let ghiChuXaPhuong = 'Thông tin này được lấy từ vị trí bạn chọn trên bản đồ.\r\nNếu chưa đúng, bạn hãy quay lại phần bản đồ và chọn lại vị trí nhà.';
    let headerTitle = "Địa chỉ";
    return (
			<View style={myStyles.container}>
                <View style={myStyles.search}>
                    <View style={myStyles.customPageHeader}>
                        {/*<TruliaIcon onPress={this._onBack.bind(this)}
                                    name="arrow-left" color={gui.mainTextColor} size={26}
                                    mainProps={myStyles.backButton} text={this.props.backTitle}
                                    textProps={myStyles.backButtonText} >
                        </TruliaIcon>*/}

                        <TouchableOpacity style={myStyles.viewPlusPost}
                                          onPress={this._onBack.bind(this)}
                        >
                            <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                        </TouchableOpacity>

                        <View style={myStyles.customPageTitle}>
                            <Text style={myStyles.customPageTitleText}>
                                {headerTitle}
                            </Text>
                        </View>
                        <TouchableOpacity style={myStyles.viewHuy}
                                          onPress={this._onApply.bind(this)}
                        >
                            <Text style={[myStyles.customPageTitleText, {fontSize: 15, fontWeight: '400', marginTop: 2, color: gui.mainColor}]}>
                                Xong
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>


                <View style={myStyles.content}>
                    {this._renderTinh()}
                    <FullLine />
                    {this._renderHuyen()}
                    <FullLine />
                    {this._renderXa()}
                    <FullLine />
                    {this._renderDuong()}
                    <FullLine />
                    <Text style={myStyles.label}>SỐ NHÀ, NGÕ, NGÁCH</Text>
                    <TextInput
                        secureTextEntry={false}
                        autoFocus={true}
                        autoCorrect={false}
                        style={myStyles.input}
                        returnKeyType='done'
                        value={this.state.diaChiChiTiet}
                        onChangeText={(text) => this.onDiaChiChiTietChange(text)}
                    />
                    <ScalableText style={myStyles.label2}>{ghiChuDuongPho}</ScalableText>
                    <Text style={[myStyles.detailAddress, {marginTop : 10}]}>ĐỊA CHỈ HIỂN THỊ: </Text>
                    <Text style={[myStyles.detailAddress, {color: gui.mainColor, marginLeft: 15, marginTop : 3}]}>
                        {this.getFmtDiaChi()}
                    </Text>

                    {/*<Text style={[myStyles.label, {marginTop: 20}]}>PHƯỜNG, QUẬN, THÀNH PHỐ</Text>
                    <TextInput
                        editable={false}
                        returnKeyType='done'
                        secureTextEntry={false}
                        style={[myStyles.input, {color: '#8A8A8A'}]}
                        value={this.props.diaChinhFullName}
                    />
                    <ScalableText style={myStyles.label2}>{ghiChuXaPhuong}</ScalableText>
                    */}
                </View>
			</View>
		)
	}

    _renderTinh() {
        return (
            <View style={myStyles.item} >
                <Text style={myStyles.label}>
                    TỈNH
                </Text>
                <View style={myStyles.arrowIcon}>
                    <ScalableText style={myStyles.grayLabel}> {this._getTinhValue()} </ScalableText>
                </View>
            </View>
        );
    }

    _renderHuyen() {
        return (
            <View style={myStyles.item} >
                <Text style={myStyles.label}>
                    HUYỆN
                </Text>
                <View style={myStyles.arrowIcon}>
                    <ScalableText style={myStyles.grayLabel}> {this._getHuyenValue()} </ScalableText>
                </View>
            </View>
        );
    }

    _renderXa() {
        return (
            <View style={myStyles.item} >
                <Text style={myStyles.label}>
                    XÃ
                </Text>
                <View style={myStyles.arrowIcon}>
                    <ScalableText style={myStyles.grayLabel}> {this._getXaValue()} </ScalableText>
                </View>
            </View>
        );
    }

    _renderDuong() {
        return (
                <TouchableOpacity
                    onPress={() => this._onDuongPressed()}>
                    <View style={myStyles.item} >
                        <Text style={myStyles.label}>
                            ĐƯỜNG
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            { this.props.postAds.loadingDiaChinh ?
                                (
                                    <View style={{paddingLeft: 10}}>
                                        <GiftedSpinner size="small" color="#8A8A8A"/>
                                    </View>
                                )
                                : <ScalableText style={myStyles.grayLabel}> {this._getDuongValue()} </ScalableText>
                            }
                            <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
        );
    }

    _getTinhValue(){
        return this.state.selectedDiaChinh ? this.state.selectedDiaChinh.tinh||"" : "";
    }

    _getHuyenValue(){
        return this.state.selectedDiaChinh ?  this.state.selectedDiaChinh.huyen||"" : "";
    }

    _getXaValue(){
        return this.state.selectedDiaChinh ? this.state.selectedDiaChinh.xa || "" : "";
    }

    _onDuongPressed(){
        let {selectedDiaChinh} = this.props.postAds;

        if (!selectedDiaChinh || !selectedDiaChinh.tinh){
            StatusBar.setBarStyle('default');
            Actions.DiaChinhList({placeType: danhMuc.placeType.DUONG});
            return;
        }

        let {codeTinh, codeHuyen} = selectedDiaChinh;

        let diaChinhDto = {
            codeTinh: codeTinh,
            codeHuyen: codeHuyen,
            placeType: danhMuc.placeType.DUONG
        };
        this.props.actions.getDiaChinhByCondition(diaChinhDto). then(
            (e) => {
                StatusBar.setBarStyle('default');
                if (e && e.status === 0 && e.predictions){
                    Actions.DiaChinhList(
                        {   placeType: danhMuc.placeType.DUONG,
                            diaChinhList: e.predictions,
                            onApply: this._setDuong.bind(this),
                            message: 'Không có thông tin đường của quận/huyện đã chọn'
                        }
                    );
                } else {
                    Actions.DiaChinhList({placeType: danhMuc.placeType.DUONG, message: 'Không có thông tin đường của quận/huyện đã chọn'});
                }
            }
        );
    }

    _setDuong(duongPlace){
        let {selectedDiaChinh} = this.props.postAds;
        selectedDiaChinh.duong = duongPlace.duong;
        selectedDiaChinh.codeDuong = duongPlace.codeDuong;
        this.props.actions.onPostAdsFieldChange("selectedDiaChinh", selectedDiaChinh);
        this.setState({selectedDiaChinh: selectedDiaChinh});
    }

    _getDuongValue(){
        return this.state.selectedDiaChinh ?  this.state.selectedDiaChinh.duong || "chọn đường" : "chọn đường";
    }

    _onApply() {
        let {selectedDiaChinh} = this.props.postAds;

        if ((!selectedDiaChinh || !selectedDiaChinh.tinh) &&
            (!this.state.diaChiChiTiet || this.state.diaChiChiTiet.trim() == '')) {
            Alert.alert('Thông báo', 'Bạn chưa nhập thông tin địa chỉ!');
            return;
        }
        var {place} = this.props.postAds;

        let diaChiChiTiet= this.state.diaChiChiTiet || '' ;
        let xaPhuong= this.state.xaPhuong || '' ;

        place.diaChiChiTiet = diaChiChiTiet;

        if (xaPhuong){
            if (diaChiChiTiet){
                place.diaChi = diaChiChiTiet + ','  + xaPhuong;
            } else {
                place.diaChi = xaPhuong;
            }
        } else {
            place.diaChi = diaChiChiTiet
        }

        this.props.onComplete(diaChiChiTiet);

        this.props.actions.onPostAdsFieldChange("place", place);

        StatusBar.setBarStyle('default');
        Actions.pop();
    }

  _onBack() {
      StatusBar.setBarStyle('default');
        Actions.pop();
  }

  onDiaChiChiTietChange(value) {
      this.setState({diaChiChiTiet : value});
  }
    getFmtDiaChi(){
        let {selectedDuAn} = this.props.postAds;
        let diaChi = this.state.diaChiChiTiet ? this.state.diaChiChiTiet : "";

        if (selectedDuAn && selectedDuAn.placeName) {
            diaChi = diaChi ? selectedDuAn.placeName + ', ' + diaChi : selectedDuAn.placeName;
        }

        if (this.state.selectedDiaChinh && this.state.selectedDiaChinh.duong) {
            diaChi = diaChi ? diaChi + ', ' + this.state.selectedDiaChinh.duong : this.state.selectedDiaChinh.duong;
        }

        if (this.state.selectedDiaChinh && this.state.selectedDiaChinh.xa) {
            diaChi = diaChi ? diaChi + ', ' + this.state.selectedDiaChinh.xa : this.state.selectedDiaChinh.xa;
        }

        if (this.state.selectedDiaChinh && this.state.selectedDiaChinh.huyen) {
            diaChi = diaChi ? diaChi + ', ' + this.state.selectedDiaChinh.huyen : this.state.selectedDiaChinh.huyen;
        }

        if (this.state.selectedDiaChinh && this.state.selectedDiaChinh.tinh) {
            diaChi = diaChi ? diaChi + ', ' + this.state.selectedDiaChinh.tinh : this.state.selectedDiaChinh.tinh;
        }
        return diaChi;
    }
}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: '#F6F6F6'
    },

    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#fff',
        height: 60
    },
    content: {
        marginLeft: 15,
        marginRight: 5
    },
    customPageTitle: {
        left:36,
        right:36,
        marginTop: 31,
        marginBottom: 10,
        position: 'absolute'
    },
    viewHuy:{
      position: 'absolute',
        right: 0,
        width: 60,
        backgroundColor: 'transparent',
        alignItems: 'center',
        marginTop: 31
    },
    customPageTitleText: {
        color: gui.textAgentSolid,
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: gui.mainTextColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    search: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: '#8A8A8A'
    },
    label2: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#A9A9A9'
    },
    input: {
        paddingLeft: 10,
        paddingRight: 10,
        height: 35,
        borderColor: '#EFEFEF',
        borderWidth: 1,
        borderLeftWidth: 0,
        borderRightWidth: 0,
        width: utils.getDimensions().width - 30,
        alignSelf: 'center',
        backgroundColor: "white"
    },
    item: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: 10,
        marginBottom: 10,
        paddingLeft: 0,
        paddingRight: 10,
        backgroundColor: '#F6F6F6'
    },
    grayLabel: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#BBBBBB',
        paddingRight: 3
    },
    arrowIcon: {
        flexDirection: "row",
        alignItems: "flex-end",
        paddingRight: 4
    },
    detailAddress: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#BBBBBB',
        paddingRight: 6,
        fontWeight: '400'
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        // paddingRight: 21,
        marginTop: 22,
        marginLeft: 16
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(PostAdsAddress);

