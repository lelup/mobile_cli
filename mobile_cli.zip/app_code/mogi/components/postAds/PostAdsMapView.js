'use strict';

import React, {Component} from 'react';

import { Text, View, StyleSheet, Navigator, TouchableOpacity,
    TouchableHighlight, StatusBar, Image, Alert } from 'react-native'

import {Actions} from 'react-native-router-flux';
import MapView from 'react-native-maps';
import Button from 'react-native-button';

import CommonHeader from '../CommonHeader2';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import danhMuc from '../../assets/DanhMuc';

import findApi from '../../lib/FindApi';
import apiUtil from '../../lib/ApiUtils';

import placeUtil from '../../lib/PlaceUtil';

import RelandIcon from '../RelandIcon';

import ScalableText from 'react-native-text';

import LocationMarker from '../marker/LocationMarker';

import MMessage from '../message/MMessage';

import GiftedSpinner from 'react-native-gifted-spinner';

import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const ASPECT_RATIO = width / (height-110);
const LATITUDE = 20.95389909999999;
const LONGITUDE = 105.75490945;
const LATITUDE_DELTA = 0.00856620000177733;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

/**
 * ## Redux boilerplate
 */

class PostAdsMapView extends Component {

  constructor(props) {
    log.info("Call PostAdsMapView.constructor");
    super(props);
    StatusBar.setBarStyle('default');

    var location = props.location;
    var region ={};
    if (!location || !location.lat ||location.lat == '') {
      region.latitude = LATITUDE;
      region.longitude = LONGITUDE;
    } else{
      region.latitude = location.lat;
      region.longitude = location.lon;
    }
    region.latitudeDelta = LATITUDE_DELTA;
    region.longitudeDelta = LONGITUDE_DELTA;

    let headerText = props.placeType == danhMuc.placeType.DIA_DIEM ? "Địa điểm" : "Dự án";
    if (props.diaChi == "Chọn dự án, địa điểm") {
      headerText = "Nhấn để chọn vị trí";
    }

    this.state = {
      textMessage: '',
      msgType: '',
      isFirstLoad: true,
      showSuggestionPosition: props.showSuggestionPosition || false,
      mapRegion: region,
      position: props.diaChi == "Chọn dự án, địa điểm" ? null : region,
      firstRegion: region,
      firstDuAn: props.duAn,
      firstDiaChinhInfo: props.diaChinhInfo,
      firstDiaChi: props.diaChi,
      firstPlaceType: props.placeType,
      enableRegionChange: false,
      diaChi: props.diaChi == "Chọn dự án, địa điểm" ? "Nhập Địa điểm hoặc Dự án" : props.diaChi,
      mapType: "standard",
      mapName: "Satellite",
      enableMap: true,
      placeType: props.placeType,
      duAn: props.duAn,
      diaChinhInfo: props.diaChinhInfo,
      headerText: headerText,
      geoFinding: false
    }
  }

  _updateMessageProcessing(textMessage) {
    this.setState({textMessage: textMessage});
    this._onMsgAnimationStart();
  }

  _onMsgAnimationStart() {
    this.setState({msgType: 'fadeInDown'});
    clearTimeout(this.msgTimer);
    this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
  }

  _renderMessageItem() {
    let textValue = this.state.textMessage;
    if (textValue == '' || this.state.msgType == '') {
      return null;
    }
    return (
        <MMessage mainStyle={{top: 64}}
                  barStyle="default"
                  animation={this.state.msgType}
                  duration={500}
                  onAnimationEnd={this._onAnimationEnd.bind(this)}
                  textValue={textValue}
                  bgColor={'#fa4916'}
                  textColor={'white'}/>
    );
  }

  _onAnimationEnd() {
    if (this.state.msgType === 'slideOutUp') {
      clearTimeout(this.msgTimer);
      this.msgTimer = setTimeout(() => {this.setState({textMessage: '', msgType: ''})}, 2000);
    }
  }

  componentDidMount() {
    this.setState({enableRegionChange: true});
  }

  render() {
    log.info("Call PostAdsMapView.render");

    return (
        <View style={styles.fullWidthContainer}>

          <View style={styles.map}>
            <MapView
                initialRegion={this.state.mapRegion}
                region={this.state.mapRegion}
                style={styles.mapView}
                mapType={this.state.mapType}
                scrollEnabled = {this.state.enableMap}
                zoomEnabled = {this.state.enableMap}
                rotateEnabled = {this.state.enableMap}
                onRegionChange={this._onRegionChange.bind(this)}
                onRegionChangeComplete={this._onRegionChangeComplete.bind(this)}
                onPress={this._onSelectPlace.bind(this)}
                onLongPress={this._onSelectPlace.bind(this)}
            >
              {this.state.position ? <MapView.Marker coordinate={this.state.position} pointerEvents="none">
                <LocationMarker/>
              </MapView.Marker> : null
              }
            </MapView>

            {this._renderGooglePlaceAutoComplete()}

            {/*<View style={styles.positionIcon} pointerEvents="none">
              <Image style={styles.googleMarker}
                     resizeMode={Image.resizeMode.contain}
                     source={require('../../assets/image/google-marker.png')} />
            </View>*/}

            {this._renderButtonOnMap()}

            <View style={styles.mapButtonContainer}>
                {
                  this.state.geoFinding ?
                    <View style={styles.searchListButton}>
                      <Text style={styles.buttonText}>Hủy</Text>
                      <View style={{marginRight: 25, marginTop: 12}}>
                        <GiftedSpinner color="white" />
                      </View>
                    </View> :
                    <View style={styles.searchListButton}>
                      <Button onPress={this._onCancel.bind(this)}
                              style={styles.buttonText}>Hủy</Button>
                      <Button onPress={this._onApply.bind(this)}
                            style={styles.buttonText}>Chọn</Button>
                    </View>
                }
            </View>
          </View>

          {this._renderMessageItem()}

          <View style={styles.search}>
            <CommonHeader headerTitle={this.state.headerText} />
            <View style={styles.headerSeparator} />
          </View>

        </View>
    )
  }

  _renderGooglePlaceAutoComplete(){
    return (
        <TouchableHighlight
            onPress={this._onPress.bind(this)}
            style={styles.touchSearch}
            underlayColor="rgba(30,30,30,0.4)"
        >
          <View style={styles.searchTextContainer}>
            <View style={styles.viewIconSearch}>
              <RelandIcon name="search" color={'#1d1d1d'} mainProps={{ top: 8, marginLeft: 6 }}
                          size={18} textProps={{}}
              />
            </View>
            <View style={styles.viewSearch}>
              <ScalableText style={styles.searchTextBottom}>
                {this._getdiaChi()}
              </ScalableText>
            </View>
          </View>
        </TouchableHighlight>
    );
  }

  _getdiaChi() {
    var diaChi = this.state.diaChi;

    if (!diaChi || diaChi.length <= 0)
      return 'Nhập Địa điểm hoặc Dự án';

    if (diaChi.length > 40) {
      diaChi = diaChi.substring(0, 40) + '...';
    }

    return diaChi;
  }

  _onPress(){
    log.info("PostAdsMapView._onPress");
    Actions.PostAdsGoogleAutoComplete(
        {
          onSuggestionPressed: (location)=>this._collectSuggestionInfo(location)
        });
  }

  _collectSuggestionInfo(location){

    var region = apiUtil.getRegionByViewport(location.viewport);
    region.latitudeDelta = LATITUDE_DELTA;
    region.longitudeDelta = LONGITUDE_DELTA;

    if (location.placeType == danhMuc.placeType.DU_AN){
      this.setState(
          { diaChi: location.fullName,
            placeType: location.placeType,
            duAn: location,
            diaChinhInfo: undefined,
            headerText: "Dự án",
            position: region,
            mapRegion: region
          });
    } else if (location.placeType == danhMuc.placeType.DIA_DIEM){
      this.setState(
          { enableMap: true,
            diaChi: location.fullName,
            placeType: location.placeType,
            headerText: "Địa điểm",
            duAn: undefined,
            diaChinhInfo: location.diaDiemInfo,
            position: region,
            mapRegion: region
          });
    }
  }

  _renderButtonOnMap(){
    return (
        <View style={styles.inMapButtonContainer}>
          {this._renderSuggestionPositionButton()}
          {this._renderCurrentPositionButton()}
        </View>
    );
  }
  _renderCurrentPositionButton() {
    return (
        <View >
          <TouchableOpacity onPress={this._onCurrentLocationPress.bind(this)} >
            <View style={[styles.bubble, styles.button, {marginTop: 10}]}>
              <RelandIcon name="direction" color='black' mainProps={{flexDirection: 'row'}}
                          size={20} textProps={{paddingLeft: 0}}
                          noAction={true}></RelandIcon>
            </View>
          </TouchableOpacity>
        </View>
    );
  }

  _renderSuggestionPositionButton() {
    if (!this.props.showSuggestionPosition)
      return;

    return (
        <View >
          <TouchableOpacity onPress={this._onSuggestionLocationPress.bind(this)} >
            <View style={[styles.bubble, styles.button, {flexDirection: 'column'}]}>
              <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                <RelandIcon name="plus" color={'black'}
                            mainProps={{flexDirection: 'row'}}
                            size={22} textProps={{paddingLeft: 0}}
                            noAction={true}></RelandIcon>
                <Text style={[styles.positionSuggetionIconText, {color: 'black'}]}>Gợi ý</Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
    );
  }

  _onCurrentLocationPress() {
    navigator.geolocation.getCurrentPosition(
        (position) => {
          var region = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA
          };
          this.setState(
              { position: region,
                mapRegion: region,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Địa điểm",
                geoFinding: true
              });
          this._getPlaceByLocation(region.latitude, region.longitude, this._loadDiaChinhContent.bind(this));
          // findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this),
          //     () => {this.setState({geoFinding: false})});
        },
        (error) => {
          this._updateMessageProcessing(gui.ERR_LocationNotOn);
        },
        {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
    );
  }

  _onSuggestionLocationPress() {
    let {firstRegion, firstDuAn, firstDiaChinhInfo, firstDiaChi, firstPlaceType} = this.state;
    if (firstDiaChi != "Chọn dự án, địa điểm") {
      let placeType = firstPlaceType;
      let headerText = firstPlaceType == danhMuc.placeType.DIA_DIEM ? "Địa điểm" : "Dự án";
      this.setState({diaChi: firstDiaChi, position: firstRegion, mapRegion: firstRegion,
          duAn: firstDuAn, diaChinhInfo: firstDiaChinhInfo, placeType: placeType, headerText: headerText});
    } else {
      this.setState({position: firstRegion, mapRegion: firstRegion, geoFinding: true});
      this._getPlaceByLocation(firstRegion.latitude, firstRegion.longitude, this._loadDiaChinhContent.bind(this));
      // findApi.getGeocoding(firstRegion.latitude, firstRegion.longitude, this._getDiaChinhContent.bind(this),
      //     () => {this.setState({geoFinding: false})});
    }
  }

  _getPlaceByLocation(lat, lon, callback) {
    findApi.getPlaceByLocation(lat, lon).then((res) => {
      if (res.success) {
        callback(res.result);
      } else {
        this.setState({geoFinding: false});
      }
    });
  }

  _loadDiaChinhContent(data){
    if (!data) {
      this.setState({geoFinding: false});
      return;
    }
    let diaChinh = {
      codeTinh: data.codeTinh,
      codeHuyen: data.codeHuyen,
      codeXa: data.codeXa,
      tinh: data.tinh,
      huyen: data.huyen,
      xa: data.xa
    };

    this.setState(
        { diaChi: data.fullName,
          placeType: danhMuc.placeType.DIA_DIEM,
          duAn: undefined,
          headerText: "Địa điểm",
          diaChinhInfo: diaChinh,
          geoFinding: false
        });
  }

  _onSelectPlace(event) {
    let coordinate = event.nativeEvent.coordinate;
    let region = {
      ...this.state.mapRegion,
      latitude: coordinate.latitude,
      longitude: coordinate.longitude
    };
    this.setState({position: region, headerText: "Địa điểm"});
    if (this.state.placeType == danhMuc.placeType.DIA_DIEM
        || (this.state.placeType == danhMuc.placeType.DU_AN && !this.state.isFirstLoad)){
      this.setState({geoFinding: true});
      this._getPlaceByLocation(region.latitude, region.longitude, this._loadDiaChinhContent.bind(this));
      // findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this),
      //     () => {this.setState({geoFinding: false})});
    }
  }

  _onRegionChange(region) {
    if (!this.state.enableRegionChange) {
      return;
    }
    this.setState({mapRegion: region});
  }

  _onRegionChangeComplete(region) {
    if (!this.state.enableRegionChange) {
      return;
    }
    this.setState({mapRegion: region});
    //
    // if (this.state.placeType == danhMuc.placeType.DIA_DIEM
    //     || (this.state.placeType == danhMuc.placeType.DU_AN && !this.state.isFirstLoad)) {
    //   findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
    // }

    this.setState({
      isFirstLoad: false
    })
  }

  _onApply() {
    let {position, diaChi, placeType, duAn, diaChinhInfo} = this.state;
    if (!position || diaChi == "Nhập Địa điểm hoặc Dự án") {
      Alert.alert(
          'Thông báo',
          gui.INF_MapViewSelection
      );
      return;
    }

    this.setState({geoFinding: true});

    var location = {
      lat: position.latitude,
      lon: position.longitude
    }

    let data = {
      location: location,
      diaChi: diaChi,
      placeType: placeType,
      duAn: duAn,
      diaChinhInfo: diaChinhInfo
    };

    if (placeType == danhMuc.placeType.DIA_DIEM
        && (!diaChinhInfo || !diaChinhInfo.codeTinh || !diaChinhInfo.codeHuyen)) {
      this._getPlaceByLocation(position.latitude, position.longitude, (res) => {
        if (res) {
          data.diaChinhInfo = {
            codeTinh: res.codeTinh,
            codeHuyen: res.codeHuyen,
            codeXa: res.codeXa,
            tinh: res.tinh,
            huyen: res.huyen,
            xa: res.xa
          };
          data.diaChi = res.fullName;
        }
        this._onLoadDiaChinhSuccess(data);
      });
    } else {
      this._onLoadDiaChinhSuccess(data);
    }

  }

  _onLoadDiaChinhSuccess(data) {
    this.props.onPress(data);
    Actions.pop();
  }

  _getDiaChinhContent(data){
    let diaChinh = placeUtil.parseDiaChinh(data);

    let {tinh, huyen, xa, diaDiem} = diaChinh;

    let fullName = tinh;
    if (huyen && huyen!=''){
      fullName = huyen + ', ' + fullName;
    }

    if (xa && xa!=''){
      fullName = xa + ', ' + fullName;
    }

    if (diaDiem && diaDiem.length >0){
      fullName = diaDiem + ', ' + fullName;
    }

    this.setState(
        { diaChi: fullName,
          placeType: danhMuc.placeType.DIA_DIEM,
          duAn: undefined,
          headerText: "Địa điểm",
          diaChinhInfo: diaChinh,
          geoFinding: false
        });
  }

  _onCancel() {
    Actions.pop();
  }
}

// Later on in your styles..
var styles = StyleSheet.create({
  headerSeparator: {
    // marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: gui.separatorLine
  },
  fullWidthContainer: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: 'white',
  },
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  searchListButtonText: {
    marginLeft: 15,
    marginRight: 15,
    marginTop: 0,
    marginBottom: 0,
    flexDirection: 'column',
  },
  map: {
    position: 'absolute',
    top: 64,
    left: 0,
    right: 0,
    bottom: 0
  },
  mapView: {
    flex: 1,
    marginTop: 0,
    marginBottom: 0
  },
  googleMarker: {
    height: 40,
    width: 40,
    marginBottom: 40,
    backgroundColor: 'transparent'
  },
  title: {
    top:0,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
    backgroundColor: 'white'
  },
  search: {
    position: 'absolute',
    top:0,
    left: 0,
    right: 0,
    height: 64,
    backgroundColor: 'white',
    alignItems: 'stretch',
    justifyContent: 'flex-start'
  },
  mapIcon: {
    color: 'white',
    textAlign: 'center'
  },
  text: {
    color: 'white'
  },
  mapButtonContainer: {
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    width: width,
    backgroundColor: 'transparent'
  },
  buttonText: {
    marginLeft: 17,
    marginRight: 17,
    marginTop: 10,
    marginBottom: 10,
    color: 'white',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight : 'normal'
  },
  searchListButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width,
    backgroundColor: gui.mainColor,
    height: 44
  },
  searchTextContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 28,
    width: width
  },
  searchText: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    textAlign: 'center',
    paddingLeft:2,
    paddingRight: 2,
    backgroundColor:'transparent'
  },
  positionIcon: {
    position: 'absolute',
    top: (height-60-25-60)/2,
    left: width/2 - 10,
    justifyContent: 'center',
    borderColor: gui.mainColor,
    backgroundColor: 'transparent'
  },
  inMapButtonContainer: {
    position: 'absolute',
    bottom: 80,
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginVertical: 5,
    marginBottom: 0,
    backgroundColor: 'transparent',
  },
  bubble: {
    backgroundColor: gui.mainColor,
    paddingHorizontal: 5,
    paddingVertical: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#C5C2BA',
    alignItems: 'center',
    justifyContent: 'center'
  },
  button: {
    width: 43,
    height: 38,
    paddingVertical: 5,
    alignItems: 'center',
    marginVertical: 5,
    backgroundColor: 'white',
    opacity: 0.9,
    marginLeft: 15
  },
  positionSuggetionIconText: {
    fontSize: 9,
    fontFamily: gui.fontFamily,
    fontWeight : 'normal',
    textAlign: 'center',
    backgroundColor:'transparent'
  },
  touchSearch:{
    position: 'absolute',
    top: 15,
    borderRadius:4,
    paddingLeft:0,
    marginLeft:15,
    marginRight:15,
    marginTop: 5,
    height:30,
    width:width - 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderWidth:1,
    borderColor:'lightgray',
    opacity: 0.9,
  },
  viewSearch:{
    width:width-65,
    height:28,
    right:20,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
    backgroundColor:'transparent',
  },
  searchTextBottom: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    textAlign: 'left',
    paddingTop:5,
    backgroundColor:'transparent',
    fontWeight:'400',
    width:width-65,
    height:28,
    color:'#1d1d1d'
  },
  viewIconSearch: {
    height: 28,
    width: 28,
    backgroundColor: 'transparent',
    left: 20,
    justifyContent: 'center',
    alignItems: 'flex-start'
  }
});

export default PostAdsMapView;