import React, {Component} from 'react';
import {
    View,
    ScrollView,
    Image,
    PanResponder,
    Animated,
    InteractionManager
} from 'react-native';

import utils from '../lib/utils';

var {
    height: deviceHeight,
    width: deviceWidth
} = utils.getDimensions();

var _scrollView: ScrollView;

export default class MPhotoView extends Component {

    constructor(props) {
        super(props);
        this.state ={
            scale: 1,
            zoomLastDistance: null,
            zoomCurrentDistance: 0,
            lastTouchStartTime: 0,
            lastClickTime: 0,
            isDoubleClickScale: false
        }
    }

    componentWillMount() {
        this._panResponder = PanResponder.create({
            onStartShouldSetPanResponder: (evt, gestureState) => true,
            onStartShouldSetPanResponderCapture: (evt, gestureState) => true,
            onMoveShouldSetPanResponder: (evt, gestureState) => true,
            onMoveShouldSetPanResponderCapture: (evt, gestureState) => true,
            onPanResponderTerminationRequest: (evt, gestureState) => false,

            onPanResponderGrant: (evt, gestureState) => {
                this.state.zoomLastDistance = null;
                this.state.lastTouchStartTime = new Date().getTime();
                this.state.isDoubleClickScale = false;

                if (evt.nativeEvent.changedTouches.length <= 1) {
                    if (new Date().getTime() - this.state.lastClickTime < 300) {
                        this.state.lastClickTime = 0;

                        this.state.isDoubleClickScale = true;
                        if (this.state.scale > 1 || this.state.scale < 1) {
                            this.state.scale = 1
                        } else {
                            this.state.scale = 2
                        }
                        _scrollView && _scrollView.setNativeProps({
                            zoomScale: this.state.scale
                        });
                        this.setState({scale: this.state.scale});
                        InteractionManager.runAfterInteractions(() => {
                            _scrollView && _scrollView.scrollTo({x: deviceWidth/2, y: deviceHeight/2});
                        });
                    } else {
                        this.state.lastClickTime = new Date().getTime();
                    }
                }
            },

            onPanResponderMove: (evt, gestureState) => {
                if (evt.nativeEvent.changedTouches.length > 1) {
                    let minX: number;
                    let maxX: number;
                    if (evt.nativeEvent.changedTouches[0].locationX > evt.nativeEvent.changedTouches[1].locationX) {
                        minX = evt.nativeEvent.changedTouches[1].pageX;
                        maxX = evt.nativeEvent.changedTouches[0].pageX;
                    } else {
                        minX = evt.nativeEvent.changedTouches[0].pageX;
                        maxX = evt.nativeEvent.changedTouches[1].pageX;
                    }

                    let minY: number;
                    let maxY: number;
                    if (evt.nativeEvent.changedTouches[0].locationY > evt.nativeEvent.changedTouches[1].locationY) {
                        minY = evt.nativeEvent.changedTouches[1].pageY;
                        maxY = evt.nativeEvent.changedTouches[0].pageY;
                    } else {
                        minY = evt.nativeEvent.changedTouches[0].pageY;
                        maxY = evt.nativeEvent.changedTouches[1].pageY;
                    }

                    const widthDistance = maxX - minX;
                    const heightDistance = maxY - minY;
                    const diagonalDistance = Math.sqrt(widthDistance * widthDistance + heightDistance * heightDistance);
                    this.state.zoomCurrentDistance = Number(diagonalDistance.toFixed(1));

                    if (this.state.zoomLastDistance !== null) {
                        let distanceDiff = (this.state.zoomCurrentDistance - this.state.zoomLastDistance) / 200;
                        let zoom = this.state.scale + distanceDiff;

                        if (zoom < 0.6) {
                            zoom = 0.6
                        }
                        if (zoom > this.props.maximumZoomScale) {
                            zoom = this.props.maximumZoomScale
                        }

                        this.state.scale = zoom;
                    }
                    this.state.zoomLastDistance = this.state.zoomCurrentDistance;
                }
            },
            onPanResponderRelease: (evt, gestureState) => {
                if (this.state.isDoubleClickScale) {
                    return
                }

                if (this.state.scale < this.props.minimumZoomScale) {
                    this.state.scale = this.props.minimumZoomScale
                }
            }
        });
    }

    render() {
        return (
            <ScrollView ref={(scrollView) => { _scrollView = scrollView; }}
                contentContainerStyle={{ alignItems:'center', justifyContent:'center' }}
                centerContent={true}
                maximumZoomScale={this.props.maximumZoomScale}
                minimumZoomScale={this.props.minimumZoomScale}
                zoomScale={this.state.scale}>

                <Animated.View
                    {...this._panResponder.panHandlers}>
                    <Image {...this.props}/>
                </Animated.View>

            </ScrollView>
        );
    }
}
