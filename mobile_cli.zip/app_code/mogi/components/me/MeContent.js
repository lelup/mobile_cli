'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as authActions from '../../reducers/auth/authActions';


import {Map} from 'immutable';

import React, {Component} from 'react';
import TruliaIcon from '../../components/TruliaIcon'

import FullLine from '../../components/line/FullLine'

import {
    Text, View, Image, StatusBar, StyleSheet, Alert, ScrollView, TouchableOpacity
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import ScalableText from 'react-native-text';

import gui from '../../lib/gui';

import LineWithIcon from "./LineWithIcon";

import log from '../../lib/logUtil';

import utils from '../../lib/utils';
var {width} = utils.getDimensions();

const actions = [
  globalActions,
  meActions,
  authActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class MeContent extends Component {
  constructor(props) {
    super(props);
    StatusBar.setBarStyle('light-content');
  }

  _onProfile() {
    if (!this.props.global.loggedIn) {
      Actions.NewLogin();
    } else {
      let currentUser = this.props.global.currentUser;
      this.props.actions.profile(currentUser.userID, currentUser.token).then(
          (res) => {
            if (res.success) {
              Actions.Profile();
            } else {
              Alert.alert('Thông báo', 'Tải thông tin cá nhân không thành công.');
            }
          }
      );
    }
  }

  _onLogout() {
    if (!this.props.global.loggedIn) {
      Actions.NewLogin();
    } else {
      this.props.actions.logout(this.props.global.currentUser);
    }
  }

  _onTopup() {
    Actions.Topup();
  }

  _onSetting(){
    Actions.Setting();
  }
  
  render() {
    let avatarUri = this.props.global.currentUser.avatar ? {uri: this.props.global.currentUser.avatar} :
        require('../../assets/image/register_avatar_icon.png');
    return (
        <ScrollView style={styles.fullWidthContainer}>
          <TouchableOpacity onPress={this._onProfile.bind(this)}>
            <View style={styles.settingLine}>
              <Image
                  style={styles.avatarIcon}
                  resizeMode={Image.resizeMode.cover}
                  source={avatarUri}
              />

              <View style={styles.profileLabel}>
                <ScalableText style={styles.lineLabel}>
                  {this.props.global.currentUser.fullName||''}
                </ScalableText>
                <ScalableText style={styles.lineSmall}>
                  {this.props.global.currentUser.phone||''}
                </ScalableText>
                <ScalableText style={styles.lineSmall}>
                  {this.props.global.currentUser.email||''}
                </ScalableText>
              </View>

              <View style={styles.rightIcon}>
                <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
              </View>
            </View>
          </TouchableOpacity>
          <FullLine />

          <View style={styles.boxSeparator}><Text/></View>
          <FullLine />

          {/*
          <LineWithIcon iconSource = {require('../../assets/image/me/me_napTien.png')}
                        textStyle = {{color: 'gray'}}
                        title = "Nạp tiền" />
          <FullLine  style={{marginLeft:63}}/>
          */}
          <LineWithIcon iconSource = {require('../../assets/image/me/me_lichSu.png')}
                        textStyle = {{color: 'gray'}}
                        title = "Lịch sử giao dịch" />
          <FullLine />
          <View style={styles.boxSeparator}><Text/></View>
          <FullLine />

          {/*<LineWithIcon iconSource = {require('../../assets/image/me/me_goiDv.png')}
           title = "Thông tin các gói dịch vụ" />*/}

          <LineWithIcon iconSource = {require('../../assets/image/me/me_goiDv.png')}
                        textStyle = {{color: 'gray'}}
                        title = "Thông tin các gói dịch vụ" />
          <FullLine />
          <View style={styles.boxSeparator}><Text/></View>
          <FullLine />

          <LineWithIcon iconSource = {require('../../assets/image/me/me_help.png')}
                        textStyle = {{color: 'gray'}}
                        title = "Trợ giúp" />
          <FullLine  style={{marginLeft:63}}/>
          <LineWithIcon iconSource = {require('../../assets/image/me/me_setting.png')}
                        onPress={this._onSetting}
                        title = "Cài đặt" />
          <FullLine />
          <View style={styles.boxSeparator}><Text/></View>
          <FullLine />

          <TouchableOpacity onPress={this._onLogout.bind(this)}>
            <View style={styles.logoutLine}>
              <ScalableText style={styles.logoutText}>{this.props.global.loggedIn ? "Đăng xuất" : "Đăng nhập"}</ScalableText>
            </View>
          </TouchableOpacity>
          <FullLine />
          <View style={styles.viewLogOut} />
        </ScrollView>
    )
  }

  coming() {
    Alert.alert("Coming soon...");
  }
}

var styles = StyleSheet.create({
  fullWidthContainer: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },

  settingLine: {
    flexDirection : "row",
    flex: 1,
    paddingTop: 15,
    paddingLeft: 17,
    paddingRight: 19,
    paddingBottom: 13,
    borderTopWidth: 1,
    borderTopColor: gui.separatorLine,
    alignItems:'center',
    backgroundColor : 'white'
  },

  logoutLine : {
    flexDirection : "row",
    flex: 1,
    paddingLeft: 17,
    paddingRight: 19,
    justifyContent:'center',
    backgroundColor : 'white',
    alignItems: 'center',
    height: 45,
    borderBottomWidth: 0,
    borderColor: gui.separatorLine,
  },

  profileLabel : {
    paddingLeft : 16
  },

  lineLabel : {
    fontSize: 17,
    fontFamily: gui.fontFamily,
    color: 'black',
    fontWeight: 'normal',

  },

  logoutText : {
    fontSize: 17,
    fontFamily: gui.fontFamily,
    color: 'red',
    fontWeight: 'normal',

  },


  lineSmall : {
    fontSize: 12,
    fontFamily: gui.fontFamily,
    color: 'gray',
    fontWeight: 'normal',

  },

  avatarIcon : {
    height: 60,
    width: 60,
    borderRadius: 30
  },

  rightIcon : {
    right : 1,
    flex : 1,
    alignItems:"flex-end"
  },
  boxSeparator : {
    height: 36,
    borderTopWidth: 0,
    borderBottomWidth: 0,
    borderColor: gui.separatorLine
  },

  lineSeparator : {
    height: 0,
    borderTopWidth: 0,
    borderColor: gui.separatorLine,
    marginLeft: 63
  },
  viewLogOut: {
    width:width,
    height:10,
    backgroundColor:'#f8f8f8'
  }

});

export default connect(mapStateToProps, mapDispatchToProps)(MeContent);
