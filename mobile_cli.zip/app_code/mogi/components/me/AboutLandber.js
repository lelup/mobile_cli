'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import {Map} from 'immutable';


import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import Communications from '../detail/MCommunications';
import ScalableText from 'react-native-text'
var Analytics = require('react-native-firebase-analytics');
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Actions} from 'react-native-router-flux';

const {width, height} = util.getDimensions();

const actions = [
    globalActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}


class AboutLandber extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    componentDidMount() {
        setTimeout(() => this.setState({loading: false}), 300);
    }

    _renderHeaderAds() {
        return (
            <View>
                <View style={styles.pageHeader}>
                    <TouchableOpacity
                        onPress={() => this._onBackPress()}
                        style={styles.searchButton}
                        activeOpacity={0}
                        disabled={this.state.loading}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                    </TouchableOpacity>
                    <View style={styles.viewEditHome}>
                        <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                            Giới thiệu
                        </Text>
                    </View>
                    <View
                        style={styles.viewEdit}>
                    </View>
                </View>
                <FullLine/>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                {this._renderBodyBorrow()}
            </View>
        );
    }

    _renderBodyBorrow() {

        let aboutLine1 = 'Landber Agent là nền tảng ứng dụng công nghệ hỗ trợ các nhà môi giới, sàn giao dịch bất động sản xây dựng và quản lý cộng đồng của mình. Với những tính năng ưu việt và duy nhất hứa hẹn mang đến những trải nghiệm tuyệt vời cho nhà môi giới.';
        let aboutLine2 = 'Các tính năng nổi bật:' ;
        let aboutLine3 = 'Xây dựng và quản lý các sàn môi giới bất động sản. Dễ dàng chia sẻ và trao đổi thông tin trên tường của sàn môi giới. Dễ dàng trao đổi với mạng lưới bạn bè qua hệ thống chat, video call, sms, call, email.';
        let aboutLine4 = 'Quản lý danh bạ, phân loại khách hàng và lịch sử giao dịch với khách hàng (đã dẫn đi xem nhà nào, ...). Quản lý nguồn hàng cá nhân với những tính năng tìm kiếm được thừa kế từ ứng dụng đã rất thành công Landber. Quản lý danh sách công việc và lập lịch làm việc.';
        let aboutLine41 = 'Dễ dàng bán hàng thông qua kết nối với Landber - Kênh thông tin bất động sản của chúng tôi. Thừa hưởng các tiện ích từ ứng dụng Landber: định giá bất động sản, tính toán lãi vay, đăng ký vay.';
        let aboutLine5 = 'Giao diện đơn giản, thân thiện, dễ dàng sử dụng. Tích hợp nhiều tính năng hỗ trợ trải nghiệm người dùng' ;
        let address1 = 'Địa chỉ liên hệ:';
        let address2 = 'Công ty CP Đầu tư Reway Group';
        let address3 = 'CS1: Tầng 27 - Tòa nhà Handico, đường Phạm Hùng, Nam Từ Liêm, Hà Nội';
        let address4 = 'CS2: Tầng 6 - Tòa nhà Sacombank, đường Lê Đức Thọ, Nam Từ Liêm, Hà Nội';
        let mailContact1 = 'Email : ';
        let mailContact2 = 'support@landber.com';
        let mailContact3 = ' | Hotline: ';
        let mailContact4 = '0961.004.691';

        return(
            <ScrollView style={{flex: 1}} contentContainerStyle={styles.viewBody}>
                <Text style={styles.textAboutUs}>{aboutLine1}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{aboutLine2}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{aboutLine3}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{aboutLine4}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{aboutLine41}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{aboutLine5}</Text>

                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{address1}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 8, fontSize: 17, color: gui.mainColor, fontWeight: '500'}]}>
                    {address2}
                </Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{address3}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>{address4}</Text>
                <Text style={[styles.textAboutUs, {marginTop: 5}]}>
                    {mailContact1}
                    <Text style={[styles.textAboutUs, {color: gui.mainColor}]}
                          onPress={this.onEmailPress.bind(this)}
                    >{mailContact2}</Text>
                    {mailContact3}
                    <Text style={[styles.textAboutUs, {color: '#ff0000'}]}
                          onPress={this.onCallPress.bind(this)}
                    >{mailContact4}</Text>
                </Text>
            </ScrollView>
        );
    }

    onCallPress() {
        Communications.phonecall("0961004691", true);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('CALL_SUPPORT', {deviceID: deviceID, userID: userID, phone: "0961004691"});
    }

    onEmailPress() {
        let bodyText = ``;

        let subject = `Tôi đang cần trợ giúp`;

        Communications.email(['support@landber.com'], null, null, subject, bodyText);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('SENDMAIL_SUPPORT', {deviceID: deviceID, userID: userID});
    }

}
export default connect(mapStateToProps, mapDispatchToProps)(AboutLandber);

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width,
        paddingTop: 3
    },
    searchButton: {
        paddingTop: 22,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textPostAds,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingLeft: 6,
        paddingTop: 17,
        paddingRight: 6,
        paddingBottom: 15
    },
    textAboutUs: {
        fontFamily:gui.fontFamily,
        fontWeight: '400',
        textAlign:'left',
        color: '#3f3f3f',
        fontSize: 15,
        marginLeft: 6
    }
});