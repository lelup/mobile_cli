'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ListView, ImageBackground, FlatList} from 'react-native';

import * as meActions from '../../reducers/me/meActions';
import {Map} from 'immutable';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import gui from "../../lib/gui";
import cfg from "../../cfg";
import DanhMuc from '../../assets/DanhMuc';
import log from '../../lib/logUtil';

import {Actions} from 'react-native-router-flux';

import LinearGradient from 'react-native-linear-gradient';

import GiftedSpinner from 'react-native-gifted-spinner';

import ScalableText from 'react-native-text';

import moment from 'moment';

import LikeTabButton from '../LikeTabButton';

import Toast, {DURATION} from '../toast/Toast';

import utils from '../../lib/utils';
const {width, height} = utils.getDimensions();

const imgHeight = 166;

const actions = [
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let dsTinBan = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
let dsTinChoThue = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

class AdsSended extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loaiTin: 'tinBan'
        }
    }
    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>Tin đã gửi</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }
    _onBackPress(){
        Actions.popTo("root");
        // Actions.MMeContent();
        Actions.MyProfile();
    }
    render() {

        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                {this._renderTabSelected()}
                <FullLine/>
                {this._renderRowView()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.8}
                    textStyle={{color:'#fff'}}
                />
            </View>
        );
    }

    _onLoaiTinChange(value) {
        this.setState({
            loaiTin: value
        });
    }

    _renderTabSelected() {
        return(
            <View style={styles.viewTabSelect}>
                <LikeTabButton name={'tinBan'}
                               onPress={this._onLoaiTinChange.bind(this)}
                               selected={this.state.loaiTin == 'tinBan'}>BÁN</LikeTabButton>
                <LikeTabButton name={'tinChoThue'}
                               onPress={this._onLoaiTinChange.bind(this)}
                               selected={this.state.loaiTin == 'tinChoThue'}>CHO THUÊ</LikeTabButton>
            </View>
        );
    }

    _renderRowView() {
        if (this.state.loaiTin == 'tinBan') {
            let dataAdsSend = this.props.me.serviceMyWTS.myListSend;
            let dataSend = dataAdsSend.sort((a, b) => b.timeModified - a.timeModified);
                return (
                    <View style={{flex: 1}}>
                        <FlatList
                            style={{width: width, height: height-157}}
                            // contentContainerStyle={{flex: 1}}
                            data={dataSend}
                            keyExtractor={(item, index) => "list" + index}
                            renderItem={(item) => this._renderRowAdsSend(item)}
                            ListFooterComponent={this._renderFooterdsListSend.bind(this)}
                        />
                        {/*{this._renderLoadingView()}*/}
                    </View>
                );
        }
        else if (this.state.loaiTin == 'tinChoThue') {
            let dataAdsLease = this.props.me.serviceMyWTS.myListLease;
            let dataLease = dataAdsLease.sort((a, b) => b.timeModified - a.timeModified);
                return (
                    <View style={{flex: 1}}>
                        <ListView
                            style={{width: width, height: height-157}}
                            enableEmptySections = {true}
                            dataSource={dsTinChoThue.cloneWithRows(dataLease)}
                            renderRow={this._renderRowAdsLease.bind(this)}
                            // contentContainerStyle={styles.viewListContainer}
                            renderFooter={this._renderFooterdsListLease.bind(this)}
                        />
                        {/*{this._renderLoadingView()}*/}
                    </View>
                );
            }
    }

    _renderFooterdsListSend () {
        let sendUp = this.props.me.serviceMyWTS.myListSend;
        return(
            <View style={styles.viewFooter}>
                { !sendUp || sendUp.length <= 0 ?
                    <Text style={styles.textFooter}>Bạn chưa gửi tin cần mua nào.</Text> : null
                }
            </View>
        );
    }

    _renderFooterdsListLease () {
        let leaseUp = this.props.me.serviceMyWTS.myListLease;
        return(
            <View style={styles.viewFooter}>
                { !leaseUp || leaseUp.length <= 0 ?
                    <Text style={styles.textFooter}>Bạn chưa gửi tin cần thuê nào.</Text> : null
                }
            </View>
        );
    }

    _renderRowAdsSend(value) {
        if(!value) {
            return
        }
        let data = value.item;
        log.info('=============> data _renderRowAdsSend', data);
        return(
            <View style={styles.rowNangCap}>
                {this._renderImage(data)}
                {this._renderNewButton(data)}
                {this.renderGoiViTri(data)}
            </View>
        );
    }

    _renderRowAdsLease(data) {
        return(
            <View style={styles.rowNangCap}>
                {this._renderImage(data)}
                {this._renderNewButton(data)}
                {this.renderGoiViTri(data)}
            </View>
        );
    }

    renderGoiViTri(data) {
        let ads = data.ads;
        if (ads && ads.goiViTri) {
            let remainDays = utils.getRemainDay(ads.goiViTri);
            let goiViTriIcon = utils.getGoiViTriIcon(ads.goiViTri);
            if (remainDays > 0 && goiViTriIcon) {
                return (
                    <View style={styles.goiViTriView}>
                        <Image style={styles.goiViTriIcon} source={goiViTriIcon} resizeMode={Image.resizeMode.cover} />
                    </View>
                );
            }
        }
        return null;
    }

    _renderImage (data) {
        let wto = data.wto;
        let dt = moment(data.timeModified).format("HH:mm - DD/MM/YYYY");
        dt = dt.replace("/", " tháng ");

        let image =  data.ads.image.cover ? {uri: `${data.ads.image.cover}`}
            : {uri: `${cfg.noCoverUrl}`};
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');

        let avatarUri = data.toUser.avatar ? {uri: data.toUser.avatar} : defaultAvatar;
        let userName = data.toUser.fullName ? data.toUser.fullName : '';
        let name = wto.content.loaiTin == 0 ? 'mua' : 'thuê';
        let removeAds = wto.status == 5 ? `Tin cần ${name} đã bị xóa` : '';
        return (
            <View style={styles.slide}>
                <TouchableOpacity
                    onPress={this._onChiTietNhaCanBanGapPress.bind(this, data.id, data)}>
                    <ImageBackground style={styles.thumb} source={image}>
                        <LinearGradient colors={['rgba(50, 50, 50, 0.6)', 'rgba(50, 50, 50, 0.6)']}
                                        style={styles.linearGradient2}>
                        </LinearGradient>
                        <View style={styles.viewAvatar}>
                            <Image style={styles.avatarUserReceive}
                                   resizeMode={Image.resizeMode.cover}
                                   source={avatarUri}
                                   defaultSource={defaultAvatar}
                            />
                            <View style={styles.viewNguoiNhan}>
                                <ScalableText style={styles.textNguoiNhan}>Người nhận : {userName}</ScalableText>
                                <ScalableText style={[styles.textNguoiNhan, {fontSize: 12, fontWeight: '400'}]}>Thời gian: {dt}</ScalableText>
                                { removeAds.length > 0 ? (<ScalableText style={[styles.textNguoiNhan, {fontSize: 12, fontWeight: '400'}]}>{removeAds}</ScalableText> ) : null }
                            </View>
                        </View>
                    </ImageBackground>
                </TouchableOpacity>
            </View>
        );
    }

    _renderNewButton(rowData) {
        let data = rowData.ads;
        let diaChi = data.place.diaChi;
        let shortedAddress = diaChi && diaChi.length>60 ? diaChi.substring(0,60) + "..." : diaChi;
        let giaGiam = rowData.giaGiam ? rowData.giaGiam : '';
        let gia = utils.getPriceDisplay(data.gia, data.loaiTin);
        let giaDaGiam = giaGiam ? utils.getPriceDisplay(data.gia-giaGiam, data.loaiTin) : '';
        let giaText = 'Giá: ';
        let dienTichText = '';
        let dienTichFmt = utils.getDienTichDisplay(data.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNgu) {
            soPhongNgu = "   " + data.soPhongNgu + "p.ngủ";
        }

        let soTang = '';
        if (data.soTang) {
            soTang = "   " + data.soTang + "tầng";
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTichText, soPhongNgu, soTang);
        detail = detail.trim();

        let iconSendAgain = require('../../assets/image/send_again.png');

        return (
            <View style={styles.viewNewButton}>
                <TouchableOpacity
                    onPress={this._onChiTietNhaCanBanGapPress.bind(this, rowData.id, rowData)}>
                    <View style={styles.viewTextContent}>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={styles.priceText} numberOfLines={1}>{giaText}</Text>
                            {giaGiam ?
                                <View style={{flexDirection: 'row'}}>
                                    <Text style={[styles.priceText, {marginLeft: 5}]} numberOfLines={1}>{giaDaGiam}</Text>
                                    <Text style={[styles.priceText, {marginLeft: 10, textDecorationLine: 'line-through',
                                        color: '#C7C8CA'}]} numberOfLines={1}>{gia}</Text>
                                </View> :
                                <Text style={[styles.priceText, {marginLeft: 5}]} numberOfLines={1}>{gia}</Text>
                            }
                        </View>
                        <Text style={styles.infoText} numberOfLines={1}>{shortedAddress}  {detail}</Text>
                    </View>
                </TouchableOpacity>
                <View style={[styles.headerSeparate, {marginLeft: 17, marginRight: 17, width: width - 34}]}></View>
                <View style={styles.viewDetailButton}>
                    <TouchableOpacity style={styles.viewEachButton}
                                      onPress={this.onSendButton.bind(this, rowData)}
                    >
                        <RelandIcon name="resend" size={18} color="#403f42"
                                    iconProps={{marginRight: 0}}
                                    mainProps={{flexDirection: 'row'}}
                                    textProps={{paddingLeft: 0}}
                                    noAction={true}

                        />
                        {/*<Image style={styles.sendAgainIcon} source={iconSendAgain}/>*/}
                        <Text style={styles.textEachButton}>
                            Gửi lại
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.viewBottomNeedPost}></View>
            </View>
        );
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = dienTich + soTang;
        }
        else {
            moreInfo = dienTich;
        }
        return moreInfo;
    }

    _onChiTietNhaCanBanGapPress(wtsID, data) {
        Actions.WtoDetailFromMe({wtsID: wtsID, data:data});
    }

    onSendButton (data) {
        let wto = data.wto;

        let ads = data.ads;
        let status = ads && ads.status;

        if (status != 2) {
            return  this.refs.toastTop && this.refs.toastTop.show('Tin của bạn chưa được duyệt! Bạn không thể gửi lại tin này.', 2000)
        }

        if(!wto || !wto.content ) {
            return;
        }
        status = wto.status;
        let name = wto.content.loaiTin == 0 ? 'mua' : 'thuê';
        if (status == 5 ) {
            return  this.refs.toastTop && this.refs.toastTop.show(`Tin cần ${name} đã bị xóa! Bạn không thể gửi lại tin này.`, 2000)
        }
        Actions.WToAdsSendFromMe({wts: data});
    }

    _renderLoadingView() {
        if (this.props.me.loadingMyWts) {
            return (<View style={styles.resultContainer}>
                <View style={styles.loadingContent}>
                    <GiftedSpinner color="white" />
                </View>
            </View>)
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(AdsSended);

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewRowStyle:{
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 62,
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    avatar:{
        height: 50,
        width: 50

    },
    viewTextCenter:{
        width: width/2,
        height: 62,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginLeft :10
    },
    textCenter:{
        fontWeight: '500',
        fontSize: 17,
        color: '#000'
    },
    textCenterBottom: {
        fontWeight: '300',
        fontSize: 12,
        color: 'gray',
        marginTop: 5
    },
    viewLeft: {
        width : width/2 - 90,
        height: 35,
        borderRadius: 15,
        backgroundColor: gui.mainColor,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    coinLeft: {
        color: '#fff',
        fontWeight: '700',
        fontSize: 15,
        marginLeft: 5,
        marginBottom: 2
    },
    viewTabSelect: {
        height: 44,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row'
    },
    viewRowAvatar: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingRight: 18
    },
    viewListContainer: {
        paddingBottom: 50
    },
    textFooter:{
        fontSize: 17,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'
    },
    viewFooter:{
        marginTop: 20,
        width: width,
        height: 46,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    rowNangCap: {
        height: 259,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "#fff"
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    thumb: {
        justifyContent: 'flex-end',
        alignItems: 'stretch',
        height: imgHeight,
        width: width,
        alignSelf: 'auto',
        right: 0
    },
    linearGradient2: {
        marginTop: 0,
        height: imgHeight,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewNewButton: {
        width: width,
        height: 93,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'column'
    },
    viewTextContent: {
        width: width,
        height: 49,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        paddingLeft: 17
    },
    price: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily
    },
    text: {
        fontSize: 13,
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily,
        marginTop: 2,
        fontWeight: '300'
    },
    headerSeparate: {
        borderTopWidth: 0.5,
        height:1,
        width: width,
        borderColor: "#d3d3d3"
    },
    viewDetailButton: {
        width: width,
        height: 33,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewEachButton: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row',
        width: width,
        height: 33
    },
    viewBottomNeedPost: {
        backgroundColor: '#dadee1',
        height: 10,
        width: width,
    },
    textEachButton: {
        color : "#403f42",
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight : '500',
        marginLeft: 8
    },
    resultContainer: {
        position: 'absolute',
        top: height/2 - 100,
        width: width,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    loadingContent: {
        position: 'absolute',
        left: width/2 - 19,
        alignItems: 'center',
        justifyContent: 'center'
    },
    priceText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#EB4222',
        fontFamily: gui.mainFamily
    },
    infoText: {
        marginTop:2,
        fontSize: 13,
        fontWeight: '400',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#5C5D5F',
        fontFamily: gui.mainFamily
    },
    viewAvatar: {
        marginLeft: 17,
        marginBottom: 10,
        justifyContent: 'center',
        alignItems:'flex-start',
        backgroundColor: 'transparent',
        width: width-17,
        height: 60,
        position: 'absolute',
        top: imgHeight - 70,
        flexDirection:'row',
        flex: 1
    },
    viewNguoiNhan: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'flex-start',
        width: width - 77,
        height: 60,
        marginLeft: 8
    },
    avatarUserReceive: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    textNguoiNhan: {
        fontSize: 13,
        fontWeight: '500',
        textAlign: 'left',
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    sendAgainIcon: {
        width: 18,
        height: 18
    },
    goiViTriView: {
        position: 'absolute',
        backgroundColor: 'transparent',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        top: 10,
        left: 10,
        width: 40,
        height: 40
    },
    goiViTriIcon: {
        width: 29,
        height: 36
    }
});