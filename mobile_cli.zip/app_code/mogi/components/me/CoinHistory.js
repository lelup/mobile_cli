'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, TouchableHighlight, ListView, FlatList, ScrollView} from 'react-native';

import * as meActions from '../../reducers/me/meActions';
import * as globalActions from '../../reducers/global/globalActions';
import {Map} from 'immutable';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import DanhMuc from "../../assets/DanhMuc";

import GiftedSpinner from 'react-native-gifted-spinner';

import {Actions} from 'react-native-router-flux';

import moment from 'moment';

import LikeTabButton from '../LikeTabButton';

import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();
import OfflineBar from '../line/OfflineBar';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const actions = [
    meActions,
    globalActions
];

// let coin_1 = require('../../assets/image/coin_1.png');
// let coin_2 = require('../../assets/image/coin_2.png');
// let coin_3 = require('../../assets/image/coin_3.png');
// let coin_4 = require('../../assets/image/coin_4.png');
// let textContent = [
//     'Bạn sẽ nhận được',
//     '80.000 VNĐ trong ví Landber',
//     '400.000 VNĐ trong ví Landber',
//     '900.000 VNĐ trong ví Landber',
//     '1.900.000 VNĐ trong ví Landber'
// ];


function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

// let hisTopUPDs = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
// let hisOrderDs = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

class CoinHistory extends React.Component {
    constructor(props) {
        super(props);
        // const data = [
        //     { 'tienNap': '500.000', 'tienCong' : '250.000', 'nhaCungCap': 'VIETTEL'},
        //     { 'tienNap': '300.000', 'tienCong' : '300.000', 'nhaCungCap': 'VIETTEL'},
        //     { 'tienNap': '300.000', 'tienCong' : '300.000', 'nhaCungCap': 'MOBIFONE'},
        //     { 'tienNap': '200.000', 'tienCong' : '100.000', 'nhaCungCap': 'MOBIFONE'}
        // ];
        // const dataCost = [
        //     {'coin' : require('../../assets/image/coin_4.png'), 'maTin': 'MT_0018', 'muaGoi' : 'VỊ TRÍ ĐẶC BIỆT', 'cost': '99.000'},
        //     {'coin' : require('../../assets/image/coin_4.png'), 'maTin': 'MT_0017', 'muaGoi' : 'VỊ TRÍ ĐẶC BIỆT', 'cost': '499.000'},
        //     {'coin' : require('../../assets/image/coin_4.png'), 'maTin': 'MT_0016', 'muaGoi' : 'VỊ TRÍ ĐẶC BIỆT', 'cost': '999.000'},
        //     {'coin' : require('../../assets/image/coin_4.png'), 'maTin': 'MT_0015', 'muaGoi' : 'VỊ TRÍ ĐẶC BIỆT', 'cost': '1.999.000'}
        // ];
        this.state = {
            loaiTin: 'napTien'
        }
    }
    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontSize: 17}]}>Lịch sử giao dịch</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }
    _onBackPress(){
        // Actions.popTo("root");
        // Actions.MMeContent();
        // Actions.MyProfile();
        Actions.pop();
    }
    render() {

        return (
            <View style={{flex: 1}}>
                <OfflineBar />
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderTabSelected()}
                <FullLine/>
                {this._renderRowView()}
            </View>
        );
    }

    _onLoaiTinChange(value) {
        this.setState({
            loaiTin: value
        });
    }

    _renderTabSelected() {
        return(
            <View style={styles.viewTabSelect}>
                <LikeTabButton name={'napTien'}
                               onPress={this._onLoaiTinChange.bind(this)}
                               selected={this.state.loaiTin == 'napTien'}>NẠP TIỀN</LikeTabButton>
                <LikeTabButton name={'nangCap'}
                               onPress={this._onLoaiTinChange.bind(this)}
                               selected={this.state.loaiTin == 'nangCap'}>NÂNG CẤP</LikeTabButton>
            </View>
        );
    }

    _renderRowView() {
        if (this.props.me.serviceTransHistory.loadingTransHistory) {
            return (
                <ScrollView contentContainerStyle={styles.viewNoneAlert}>
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                </ScrollView>
            )
        }
        if (this.state.loaiTin == 'napTien') {
            return (
                <View style={{flex: 1}}>
                    {this._renderListNapTien()}
                </View>
            );

        }
        else if (this.state.loaiTin == 'nangCap') {
            return (
                <View style={{flex: 1}}>
                    {this._renderListNangCap()}
                </View>
            );
        } else return null;
    }

    _renderImageLoading() {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        return (
            <View>
                <View style={styles.viewRowPost}>
                    <View style={[styles.viewLineLoader1,{ marginTop: 6, marginLeft: 0}]}></View>
                    <View style={[styles.viewLineLoader1,{ marginTop: 6, marginLeft: 0}]}></View>
                    <View style={[styles.viewLineLoader1,{ marginTop: 6, marginLeft: 0}]}></View>
                </View>
                <FullLine/>
            </View>
        );
    }

    _renderListNapTien() {
        let topup = this.props.me.serviceTransHistory.topup;
        let topupList = topup.sort((a, b) => b.dateTime - a.dateTime);
        // let dsUp = hisTopUPDs.cloneWithRows(data);
        return(
            // <ListView
            //     enableEmptySections = {true}
            //     dataSource={dsUp}
            //     renderRow={this._renderRowNapTien.bind(this)}
            //     contentContainerStyle={styles.viewListContainer}
            //     renderFooter={this._renderFooterdsUp.bind(this)}
            // />

            <FlatList
                data={topupList}
                keyExtractor={(item, index) => "list" + index}
                renderItem={(data) => this._renderRowNapTien(data.item, (data.index == 0), (data.index == (topupList.length-1)))}
                ListFooterComponent={this._renderFooterdsUp.bind(this)}
                removeClippedSubviews={false}
                enableEmptySections
                style={styles.viewListContainer}
            />
        );
    }

    _renderListNangCap() {
        let serviceOrder = this.props.me.serviceTransHistory.serviceOrder;
        let serviceOrderList = serviceOrder.sort((a, b) => b.dateTime - a.dateTime);
        // let dsOrder = hisOrderDs.cloneWithRows(data);
        return(
            // <ListView
            //     enableEmptySections = {true}
            //     dataSource={dsOrder}
            //     renderRow={this._renderRowNangCap.bind(this)}
            //     contentContainerStyle={styles.viewListContainer}
            //     renderFooter={this._renderFooterdsOrder.bind(this)}
            // />

            <FlatList
                data={serviceOrderList}
                keyExtractor={(item, index) => "list" + index}
                renderItem={(data) => this._renderRowNangCap(data.item, (data.index == 0), (data.index == (serviceOrderList.length-1)))}
                ListFooterComponent={this._renderFooterdsOrder.bind(this)}
                removeClippedSubviews={false}
                enableEmptySections
                style={styles.viewListContainer}
            />
        );
    }

    _renderFooterdsUp () {
        let myProps = this.props;
        let serviceTransHistory = myProps.me.serviceTransHistory;
        let pageNo = serviceTransHistory.topupPageNo;
        let topup = serviceTransHistory.topup;
        let totalCount = serviceTransHistory.topupTotalCount;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalPages = totalCount/ limit;
        if (!topup || topup.length <= 0) {
            return(
                <View style={styles.viewFooter}>
                    <Text style={styles.textFooter}>Bạn chưa thực hiện giao dịch nạp tiền.</Text>
                </View>
            );
        }
        if (totalPages && pageNo < totalPages) {
            return (
                <View style={styles.viewFooter} />
            );
        }
        return (
            <View style={[styles.viewFooter, {marginBottom: 50}]}>
                <Text style={styles.textFooter}>Tất cả đã được hiển thị</Text>
            </View>
        );
    }

    _renderFooterdsOrder () {
        let myProps = this.props;
        let serviceTransHistory = myProps.me.serviceTransHistory;
        let pageNo = serviceTransHistory.serviceOrderPageNo;
        let serviceOrder = serviceTransHistory.serviceOrder;
        let totalCount = serviceTransHistory.serviceOrderTotalCount;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalPages = totalCount/ limit;
        if (!serviceOrder || serviceOrder.length <= 0) {
            return (
                <View style={styles.viewFooter}>
                    <Text style={styles.textFooter}>Bạn chưa thực hiện giao dịch nâng cấp.</Text>
                </View>
            );
        }
        if (totalPages && pageNo < totalPages) {
            return (
                <View style={styles.viewFooter} />
            );
        }
        return (
            <View style={[styles.viewFooter, {marginBottom: 50}]}>
                <Text style={styles.textFooter}>Tất cả đã được hiển thị</Text>
            </View>
        );
    }

    _renderRowNapTien(data, isFirstRow, isLastRow) {
        let dt = moment(data.dateTime).format("DD/MM   HH:mm");
        dt = dt.replace("/", " tháng ");
        let mainNapTien = data.mainAmount ? data.mainAmount.toLocaleString() + " " + DanhMuc.VND : '0 ' + DanhMuc.VND;
        if (data.mainAmount && data.mainAmount > 0) {
            mainNapTien = '+' + mainNapTien;
        }
        let paymentType = data.payment.type ? data.payment.type : ' ';
        let paymentTypeFmt = data.payment.name || paymentType;
        let originAmount = data.originAmount || data.topupAmount || data.mainAmount;
        originAmount = originAmount ? originAmount.toLocaleString() + " " + DanhMuc.VND : '0 ' + DanhMuc.VND;
        let bonusAmount = data.bonusAmount ? data.bonusAmount.toLocaleString() + " " + DanhMuc.VND : '0 ' + DanhMuc.VND;
        if (data.bonusAmount && data.bonusAmount > 0) {
            bonusAmount = '+' + bonusAmount;
        }

        let firstControl = null;
        let lastControl = null;
        let myProps = this.props;
        let pageNo = myProps.me.serviceTransHistory.topupPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = myProps.me.serviceTransHistory.topupTotalCount;
        let totalPages = totalCount/ limit;
        let showFirstLoading = pageNo > 2;
        let showFirstControl = pageNo > 1;
        let loading = myProps.me.serviceTransHistory.loadingTransHistory;
        let showLastControl = !loading && totalPages && pageNo < totalPages;

        if (isFirstRow) {
            if (loading) {
                if (showFirstLoading) {
                    firstControl = <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center',
                        borderBottomWidth: 1, borderColor: '#dcdcdc'}}>
                        <GiftedSpinner size="small"/>
                    </View>;
                }
            } else {
                if (showFirstControl) {
                    firstControl =
                        <View style={{borderBottomWidth: 1, borderColor: '#dcdcdc'}}>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <TouchableHighlight onPress={this._loadPreviousPage.bind(this, true)} underlayColor="transparent">
                                    <View style={{flexDirection: 'column'}}>
                                        <Text style={styles.rowControl}>Nhấn vào đây để quay lại trang trước</Text>
                                        <Text style={styles.pagingTitle}>{this._getPagingTitle(true)}</Text>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </View>;
                } else {
                    firstControl =
                        <View style={{borderBottomWidth: 1, borderColor: '#dcdcdc'}}>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <Text style={styles.pagingTitle}>{this._getPagingTitle(true)}</Text>
                            </View>
                        </View>;
                }
            }
        }
        if (showLastControl && isLastRow) {
            lastControl =
                <View style={[styles.viewFooter, {marginTop: 0}]}>
                    <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                        <TouchableHighlight onPress={this._loadNextPage.bind(this, true)} underlayColor="transparent">
                            <View style={{flexDirection: 'column'}}>
                                <Text style={styles.rowControl}>Nhấn vào đây để đi đến trang sau</Text>
                                <Text style={styles.pagingTitle}>{this._getPagingTitle(true)}</Text>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
            ;
        }

        return(
            <View style={{backgroundColor: '#fff', flexDirection: 'column', overflow: 'hidden'}}>
                {firstControl}
                <View style={styles.rowNangCap}>
                    <Text style={styles.timeRow}>{dt}</Text>
                    <View style={[styles.viewBodyNangCap, {alignItems: 'flex-start'}]}>
                        <View style={styles.viewTienNap}>
                            <Text style={styles.textBody}>Tiền nạp</Text>
                            <Text style={styles.textBody}>TK chính</Text>
                            <Text style={styles.textBody}>TK khuyến mại</Text>
                            <Text style={styles.textBody}>Kênh</Text>
                        </View>
                        <View style={[styles.viewTienNap, {flex:1, alignItems: 'flex-end'}]}>
                            <Text style={[styles.textBody, {textAlign: 'right', marginRight: 17}]}>{originAmount}</Text>
                            <Text style={[styles.textBody, {textAlign: 'right', color: '#ff0000', marginRight: 17}]}>{mainNapTien} </Text>
                            <Text style={[styles.textBody, {textAlign: 'right', color: '#ff0000', marginRight: 17}]}>{bonusAmount} </Text>
                            <Text style={[styles.textBody, {color: gui.mainColor, marginRight: 17}]}>{paymentTypeFmt}</Text>
                        </View>
                    </View>
                    <FullLine />
                </View>
                {lastControl}
            </View>
        );
    }

    _getPagingTitle(isTopup) {
        let myProps = this.props;
        let serviceTransHistory = myProps.me.serviceTransHistory;
        let pageNo = isTopup ? serviceTransHistory.topupPageNo : serviceTransHistory.serviceOrderPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = isTopup ? serviceTransHistory.topupTotalCount : serviceTransHistory.serviceOrderTotalCount;
        let totalPages = totalCount/ limit;
        let numberOfNotify = isTopup ? serviceTransHistory.topup.length : serviceTransHistory.serviceOrder.length;

        let beginIndex = (pageNo-1)*limit+1;
        let endIndex = (pageNo-1)*limit+numberOfNotify;
        if (totalCount < endIndex) {
            totalCount = endIndex;
        }
        if (pageNo == totalPages) {
            totalCount = endIndex;
        }
        let title = (beginIndex > 1 || totalCount > endIndex) ? 'Đang hiển thị từ ' + beginIndex + "-" + endIndex + ' / ' + totalCount + ' kết quả' :
        'Đang hiển thị ' + numberOfNotify + ' kết quả';
        return title;
    }

    _loadPreviousPage(isTopup) {
        let myProps = this.props;
        let serviceTransHistory = myProps.me.serviceTransHistory;
        let pageNo = isTopup ? serviceTransHistory.topupPageNo : serviceTransHistory.serviceOrderPageNo;

        if (pageNo > 1) {
            pageNo = pageNo-1;
            let serviceListName = isTopup ? 'topup' : 'serviceOrder';
            let servicePageNoName = isTopup ? 'topupPageNo' : 'serviceOrderPageNo';
            let serviceTotalCountName = isTopup ? 'topupTotalCount' : 'serviceOrderTotalCount';
            myProps.actions.onServiceTransHistoryFieldChange(serviceListName, []);
            myProps.actions.onServiceTransHistoryFieldChange(serviceTotalCountName, 0);
            myProps.actions.onServiceTransHistoryFieldChange(servicePageNoName, pageNo);
            this._handleSearchAction(isTopup, pageNo);
        }
    }

    _loadNextPage(isTopup) {
        let myProps = this.props;
        let serviceTransHistory = myProps.me.serviceTransHistory;
        let pageNo = isTopup ? serviceTransHistory.topupPageNo : serviceTransHistory.serviceOrderPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = isTopup ? serviceTransHistory.topupTotalCount : serviceTransHistory.serviceOrderTotalCount;
        let totalPages = totalCount/ limit;

        if (totalPages && pageNo < totalPages) {
            pageNo = pageNo+1;
            let serviceListName = isTopup ? 'topup' : 'serviceOrder';
            let servicePageNoName = isTopup ? 'topupPageNo' : 'serviceOrderPageNo';
            let serviceTotalCountName = isTopup ? 'topupTotalCount' : 'serviceOrderTotalCount';
            myProps.actions.onServiceTransHistoryFieldChange(serviceListName, []);
            myProps.actions.onServiceTransHistoryFieldChange(serviceTotalCountName, 0);
            myProps.actions.onServiceTransHistoryFieldChange(servicePageNoName, pageNo);
            this._handleSearchAction(isTopup, pageNo);
        }
    }

    _handleSearchAction(isTopup, pageNo) {
        let myProps = this.props;
        let limit = myProps.global.setting.maxAdsInMapView;
        let userID = myProps.global.currentUser.userID;
        let token = myProps.global.currentUser.token;
        let dto = {
            userID: userID,
            pageNo: pageNo,
            limit: limit,
            isIncludeCountInResponse: true
        };
        this.props.actions.doPagingTopupLog(dto, isTopup, token);
    }

    _renderRowNangCap(data, isFirstRow, isLastRow) {
        let dt = moment(data.dateTime).format("DD/MM   HH:mm");
        dt = dt.replace("/", " tháng ");
        let hideMaTin = !data.ads || !data.ads.id;
        let serviceTypeLabel = data.price.type == 'lan' ? 'Số lần :' : 'Số ngày :';
        let serviceName = data.service && data.service.serviceName ? data.service.serviceName.toUpperCase() : ' ';
        let detailItems = [];
        let uuid = new Date().getTime();
        let index = 0;
        if (!hideMaTin) {
            detailItems.push(
                <View key={(index++) + '_' + uuid} style={[styles.viewBodyNangCap, {marginLeft: 0}]}>
                    <View style={styles.viewTienNap}>
                        <Text style={styles.textBody}>Mã tin :</Text>
                    </View>
                    <View style={[styles.viewTienNap, {flex:2}]}>
                        <Text style={styles.textBody}>{data.ads && data.ads.id || ' '}</Text>
                    </View>
                </View>
            );
        }
        detailItems.push(
            <View key={(index++) + '_' + uuid} style={[styles.viewBodyNangCap, {marginLeft: 0}]}>
                <View style={styles.viewTienNap}>
                    <Text style={styles.textBody}>Mua gói :</Text>
                </View>
                <View style={[styles.viewTienNap, {flex:2}]}>
                    <Text style={[styles.textBody, {color: gui.mainColor}]}>{serviceName}</Text>
                </View>
            </View>
        );
        detailItems.push(
            <View key={(index++) + '_' + uuid} style={[styles.viewBodyNangCap, {marginLeft: 0}]}>
                <View style={styles.viewTienNap}>
                    <Text style={styles.textBody}>{serviceTypeLabel}</Text>
                </View>
                <View style={[styles.viewTienNap, {flex:2}]}>
                    <Text style={styles.textBody}>{data.price.soLanSuDung || ' '}</Text>
                </View>
            </View>
        );
        detailItems.push(
            <View key={(index++) + '_' + uuid} style={[styles.viewBodyNangCap, {marginLeft: 0}]}>
                <View style={styles.viewTienNap}>
                    <Text style={styles.textBody}>Tổng tiền :</Text>
                </View>
                <View style={[styles.viewTienNap, {flex:2}]}>
                    <Text style={[styles.textBody, {color: '#ff0000'}]}>{data.price.price ? data.price.price.toLocaleString() + " " + DanhMuc.VND  : ' '}</Text>
                </View>
            </View>
        );
        let firstControl = null;
        let lastControl = null;
        let myProps = this.props;
        let pageNo = myProps.me.serviceTransHistory.serviceOrderPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = myProps.me.serviceTransHistory.serviceOrderTotalCount;
        let totalPages = totalCount/ limit;
        let showFirstLoading = pageNo > 2;
        let showFirstControl = pageNo > 1;
        let loading = myProps.me.serviceTransHistory.loadingTransHistory;
        let showLastControl = !loading && totalPages && pageNo < totalPages;

        if (isFirstRow) {
            if (loading) {
                if (showFirstLoading) {
                    firstControl = <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center',
                        borderBottomWidth: 1, borderColor: '#dcdcdc'}}>
                        <GiftedSpinner size="small"/>
                    </View>;
                }
            } else {
                if (showFirstControl) {
                    firstControl =
                        <View style={{borderBottomWidth: 1, borderColor: '#dcdcdc'}}>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <TouchableHighlight onPress={this._loadPreviousPage.bind(this, false)} underlayColor="transparent">
                                    <View style={{flexDirection: 'column'}}>
                                        <Text style={styles.rowControl}>Nhấn vào đây để quay lại trang trước</Text>
                                        <Text style={styles.pagingTitle}>{this._getPagingTitle(false)}</Text>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </View>;
                } else {
                    firstControl =
                        <View style={{borderBottomWidth: 1, borderColor: '#dcdcdc'}}>
                            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                                <Text style={styles.pagingTitle}>{this._getPagingTitle(false)}</Text>
                            </View>
                        </View>;
                }
            }
        }
        if (showLastControl && isLastRow) {
            lastControl =
                <View style={[styles.viewFooter, {marginTop: 0}]}>
                    <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                        <TouchableHighlight onPress={this._loadNextPage.bind(this, false)} underlayColor="transparent">
                            <View style={{flexDirection: 'column'}}>
                                <Text style={styles.rowControl}>Nhấn vào đây để đi đến trang sau</Text>
                                <Text style={styles.pagingTitle}>{this._getPagingTitle(false)}</Text>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
            ;
        }

        return(
            <View style={{backgroundColor: '#fff', flexDirection: 'column', overflow: 'hidden'}}>
                {firstControl}
                <View style={styles.rowNangCap}>
                    <Text style={styles.timeRow}>{dt}</Text>
                    <View style={[styles.viewBodyNangCap, {marginBottom: 8}]}>
                        <View style={{flex: 3, flexDirection: 'column'}}>
                            {detailItems}
                        </View>
                        <View style={[styles.viewAvatar]}>
                            <Image style={styles.avatar} source={{uri :data.ads && data.ads.cover}}/>
                        </View>
                    </View>
                    <FullLine />
                </View>
                {lastControl}
            </View>
        );
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(CoinHistory);

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewRowStyle:{
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 62,
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    avatar:{
        height: 50,
        width: 50

    },
    viewTextCenter:{
        width: width/2,
        height: 62,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginLeft :10
    },
    textCenter:{
        fontWeight: '500',
        fontSize: 16,
        color: '#000'
    },
    textCenterBottom: {
        fontWeight: '300',
        fontSize: 12,
        color: 'gray',
        marginTop: 5
    },
    viewLeft: {
        width : width/2 - 90,
        height: 35,
        borderRadius: 15,
        backgroundColor: gui.mainColor,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    coinLeft: {
        color: '#fff',
        fontWeight: '700',
        fontSize: 15,
        marginLeft: 5,
        marginBottom: 2
    },
    viewTabSelect: {
        height: 44,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row'
    },
    viewBodyNangCap: {
        flexDirection: 'row',
        // width: width-17,
        flex: 1,
        marginLeft: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    viewTextNangCap: {
        flex: 3,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textBody: {
        fontSize: 13,
        color: '#000',
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
    timeRow:{
        fontSize: 12,
        marginTop : 8,
        marginLeft: 17,
        color: 'rgba(0,0,0,0.4)',
        fontWeight: '300',
        fontFamily: gui.fontFamily
    },
    viewRowAvatar: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingRight: 18
    },
    rowNangCap: {
        flex: 1,
        // height: 100,
        width: width,
        flexDirection: 'column'
    },
    viewListContainer: {
        // paddingBottom: 50
    },
    viewTienNap:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'

    },
    viewAvatar: {
        flex:1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingRight: 10,
        paddingBottom: 22
    },
    textFooter:{
        fontSize: 16,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'
    },
    viewFooter:{
        marginTop: 20,
        width: width,
        height: 46,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    rowControl: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: gui.mainColor
    },
    pagingTitle: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'gray'
    },
    viewNoneAlert: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewRowPost: {
        width: width - 32,
        height: 112,
        justifyContent: 'center',
        backgroundColor: '#fff',
        marginLeft: 16,
        marginRight: 16
    },
    viewLineLoader1: {
        height: 15,
        width: width - 32,
        backgroundColor:'rgba(234, 235, 237, 0.75)',
    }

});