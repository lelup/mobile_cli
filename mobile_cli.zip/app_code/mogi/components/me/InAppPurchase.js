'use strict';

import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView} from 'react-native';
import FullLine from '../../components/line/FullLine'
import OfflineBar from '../../components/line/OfflineBar'
import TruliaIcon from '../../components/TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import log from '../../lib/logUtil';
import MChartView from '../MChartView';

import {Actions} from 'react-native-router-flux';

import { NativeModules } from 'react-native';
const { InAppUtils } = NativeModules;

const {width, height} = util.getDimensions();

const coins = [
    {logo: require('../../assets/image/coin_1.png'), userAccount:"85.000",    userPayment:"99.000",    iapPackage: "com.rwg.app.reland.99"},
    {logo: require('../../assets/image/coin_2.png'), userAccount:"425.000",   userPayment:"499.000",   iapPackage: "com.rwg.app.reland.499"},
    {logo: require('../../assets/image/coin_3.png'), userAccount:"850.000",   userPayment:"999.000",   iapPackage: "com.rwg.app.reland.999"},
    {logo: require('../../assets/image/coin_4.png'), userAccount:"1.700.000", userPayment:"1.999.000", iapPackage: "com.rwg.app.reland.1999"}
];

const products = [
    "com.rwg.app.reland.99",
    "com.rwg.app.reland.499",
    "com.rwg.app.reland.999",
    "com.rwg.app.reland.1999"
];

class InAppPurchase extends React.Component {
    constructor(props) {
        super(props);

        InAppUtils.loadProducts(products, (error, products) => {
            log.info("============== print products, ", products);
        });
    }

    _renderHeader() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity style={styles.searchButton}
                                  onPress={this._onBackPress}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>InAppPurchase</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _renderTaiKhoan(){
        let main = 150000;
        let bonus = 5000;

        let data = [];
        let pallete = [];

        if (main>0 ) {
            data.push({
                "name": "",
                "fillColor" : "#1396E0",
                "value": main
            });
            pallete.push(util.hexToRgb("#1396E0"));
        }

        if (bonus>0){
            data.push({
                "name": "",
                "fillColor" : "#DE6207",
                "value": bonus
            });
            pallete.push(util.hexToRgb("#DE6207"));
        }

        // var data = [{
        //     "name": "",
        //     "fillColor" : gui.mainColor,
        //     "value": 400
        // }, {
        //     "name": "",
        //     "fillColor" : "#DE6207",
        //     "value": 100
        // }];
        // var pallete = [
        //     util.hexToRgb(gui.mainColor), util.hexToRgb("#EA9409")
        // ];

        let options = {
            margin: {
                top: 1,
                left: 2,
                bottom: 1,
                right: 2
            },
            width: 126,
            height: 126,
            r: 46,
            R: 61,
            legendPosition: 'topLeft',
            animate: {
                type: 'oneByOne',
                duration: 200,
                fillTransition: 3
            },
            label: {
                fontFamily: gui.fontFamily,
                fontSize: gui.buttonFontSize,
                fontWeight: 'normal'
            }
        };
        let chartTitleBold = `${util.getPriceText(main + bonus)}`;
        let chartTitle = 'Tổng tài khoản';
        return (
            <View>
                <View style={styles.viewChartProfile}>
                    <View style={styles.viewChartBody}>
                        <MChartView
                            data={data}
                            options={options}
                            pallete={pallete}
                            chartTitle={chartTitle}
                            chartTitleBold={chartTitleBold}
                        />
                    </View>
                    <View style={{paddingLeft: 0, paddingTop:2}}>
                        {this._renderMoneyLine("Tài khoản chính", `${util.getPriceText(main)}`, gui.mainColor)}
                        {this._renderMoneyLine("Tài khoản phụ", `${util.getPriceText(bonus)}`, '#EA9409')}
                    </View>
                </View>
                <Text style={{fontSize: 5}} />
            </View>
        );
    }

    _onBackPress(){
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                <OfflineBar />
                {this._renderHeader()}
                {/*this._renderTaiKhoan()*/}
                <ScrollView style={[styles.viewScrollBody]}
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="none"
                            ref="_scrollview"
                >
                    {this._renderRowView()}
                    {this._renderContentGroupTitle('GHI CHÚ')}
                    {this._renderTextContent()}
                </ScrollView>
            </View>
        );
    }

    _renderRowView() {
        return(
            <View>
                <InAppPurchaseItem userAccount={coins[0].userAccount}
                                   userPayment={coins[0].userPayment}
                                   logo={coins[0].logo}
                                   iapPackage={coins[0].iapPackage}
                                   product={products[0]}
                />
                <InAppPurchaseItem userAccount={coins[1].userAccount}
                                   userPayment={coins[1].userPayment}
                                   logo={coins[1].logo}
                                   iapPackage={coins[1].iapPackage}
                                   product={products[1]}
                />
                <InAppPurchaseItem userAccount={coins[2].userAccount}
                                   userPayment={coins[2].userPayment}
                                   logo={coins[2].logo}
                                   iapPackage={coins[2].iapPackage}
                                   product={products[2]}
                />
                <InAppPurchaseItem userAccount={coins[3].userAccount}
                                   userPayment={coins[3].userPayment}
                                   logo={coins[3].logo}
                                   iapPackage={coins[3].iapPackage}
                                   product={products[3]}
                />
            </View>
        );
    }

    _renderTextContent () {
        let textHelp = [
            'Cổng thanh toán thu phí 30% trên số tiền bạn nạp.',
            'Landber sẽ hỗ trợ 15% số tiền.',
            'Ví dụ:',
            'Số tiền bạn nạp 99k.',
            'Thì số tiền ghi có trong tài khoản là 85k.',
            '(70k Landber nhận được từ cổng thanh toán, 15k Landber hỗ trợ thêm cho bạn)'
        ];
        return(
            <View style={styles.viewHelpContent}>
                <Text style={styles.textStyleHelp}>{textHelp[0]}</Text>
                <Text style={styles.textStyleHelp}>{textHelp[1]}</Text>
                <Text style={[styles.textStyleHelp, {marginTop: 7, marginBottom: 4}]}>{textHelp[2]}</Text>
                <Text style={[styles.textStyleHelp, {color: '#626262'}]}>{textHelp[3]}</Text>
                <Text style={[styles.textStyleHelp, {color: '#626262'}]}>{textHelp[4]}</Text>
                <Text style={[styles.textStyleHelp, {color: '#626262'}]}>{textHelp[5]}</Text>
            </View>
        );
    }

    _renderContentGroupTitle(title) {
        return (
            <View>
                <View style={styles.contentGroupTitle}>
                    <Text style={styles.contentGroupTitleText}>{title}</Text>
                </View>
                <FullLine />
            </View>
        );
    }

    _renderMoneyLine(label, value, dotColor) {
        return (
            <View style={{flexDirection:'row'}}>
                <View style={[styles.dot3, {borderColor: dotColor}]}>
                </View>
                <View style={{flexDirection:'column', marginTop: 8, marginBottom: 8}}>
                    <Text style={{fontSize: 13, fontFamily: gui.fontFamily, fontWeight: 'bold'}}>
                        {value}
                    </Text>
                    <Text style={{fontSize: 12, fontFamily: gui.fontFamily, color: '#9C9C9C'}}>
                        {label}
                    </Text>
                </View>
            </View>
        )
    }
}

class InAppPurchaseItem extends React.Component{
    render(){
        return (
            <View>
                <View style={styles.viewRowStyle}>
                    <Image style={styles.avatar} source={this.props.logo} />
                    <View style={styles.viewTextCenter}>
                        <Text style={styles.textCenter}>Bạn sẽ nhận được</Text>
                        <Text style={styles.textCenterBottom}>
                            {this.props.userAccount} VNĐ trong ví Landber
                        </Text>
                    </View>
                    <TouchableOpacity onPress={this._applyPurchase.bind(this)}>
                        <View style={styles.viewLeft}>
                            <Text style={[styles.textCenter, {color: '#fff', fontSize: 15}]}>đ</Text>
                            <Text  style={[styles.textCenterBottom,styles.coinLeft]}>{this.props.userPayment}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
                <FullLine style={{ marginLeft: 15 }} />
            </View>
        )
    }

    _applyPurchase(){
        InAppUtils.purchaseProduct(this.props.product, (error, response) => {
            if(response && response.productIdentifier) {
                Alert.alert('Purchase Successful', 'Your Transaction ID is ' + response.transactionIdentifier);
                //unlock store here.
            } else {
                Alert.alert('Purchase Fail', 'Invalid product, Error: ' + JSON.stringify(error));
            }
        });
    }
}

export default InAppPurchase;

const styles = StyleSheet.create({
    viewScrollBody: {
        backgroundColor: '#fff',
        paddingBottom: 43,
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewRowStyle:{
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 62,
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    avatar:{
        height: 40,
        width: 40,
        marginLeft: 10
    },
    viewTextCenter:{
        width: width/2,
        height: 62,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginLeft :10
    },
    textCenter:{
        fontWeight: '500',
        fontSize: 17,
        color: '#000'
    },
    textCenterBottom: {
        fontWeight: '300',
        fontSize: 13,
        color: 'gray',
        marginTop: 5
    },
    viewLeft: {
        width : 100,
        height: 35,
        borderRadius: 15,
        backgroundColor: gui.mainColor,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    coinLeft: {
        color: '#fff',
        fontWeight: '700',
        fontSize: 15,
        marginLeft: 5,
        marginBottom: 2
    },
    viewChartProfile: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor:'white',
        paddingTop: 16,
        paddingBottom: 16

    },
    viewChartBody: {
        paddingLeft: 13,
        paddingTop:2,
        width: width/2-25,
        alignItems: 'center',
        justifyContent: 'center'
    },
    dot3 : {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 14,
        marginTop: 18,
        backgroundColor: 'white',
        borderWidth: 3.5
    },
    contentGroupTitle: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingRight: 15,
        paddingLeft: 14,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8',
    },
    contentGroupTitleText: {
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: '#313131',
        justifyContent :'space-between',
        padding: 0,
        fontWeight:"300"
    },
    viewHelpContent: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 10,
        paddingLeft: 17,
        paddingBottom: 10,
        paddingRight: 8
    },
    textStyleHelp: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#4e4e4e',
    },
    viewRowMoney: {
        paddingTop: 16,
        paddingBottom: 16
    }
});
