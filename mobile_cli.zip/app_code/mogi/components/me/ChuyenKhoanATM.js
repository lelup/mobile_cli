'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ListView} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import OfflineBar from '../line/OfflineBar';
import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

import GiftedSpinner from 'react-native-gifted-spinner';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const {width, height} = util.getDimensions();

let ds_chuyenKhoan  = new ListView.DataSource({rowHasChanged:(r1,r2) => r1 !== r2 });

class ChuyenKhoanATM extends Component {
    constructor(props) {
        super(props);

        const dataCost = [
            {'image' : require('../../assets/image/bank_logo/logo_BIDV.png'), 'tenTaiKhoan': 'CTY CP ĐẦU TƯ REWAY GROUP', 'nganHang' : 'NH BIDV', 'soTaiKhoan': '12910000077241', 'chiNhanh' : 'Chi Nhánh Thanh Xuân'},
            {'image' : require('../../assets/image/bank_logo/logo_Vietcombank.png'), 'tenTaiKhoan': 'CTY CP ĐẦU TƯ REWAY GROUP', 'nganHang' : 'NH Vietcombank', 'soTaiKhoan': '0451000363160', 'chiNhanh' : 'Chi Nhánh Thanh Xuân'},
            {'image' : require('../../assets/image/bank_logo/logo_ACB.png'), 'tenTaiKhoan': 'CTY CP ĐẦU TƯ REWAY GROUP', 'nganHang' : 'NH ACB', 'soTaiKhoan': '214420459', 'chiNhanh' : 'Chi Nhánh Thanh Xuân'},
            {'image' : require('../../assets/image/bank_logo/logo_viettinbank.jpg'), 'tenTaiKhoan': 'CTY CP ĐẦU TƯ REWAY GROUP', 'nganHang' : 'NH VietinBank', 'soTaiKhoan': '102010002502726', 'chiNhanh' : 'Chi Nhánh Thanh Xuân'},
        ];

        this.state = {
            loading: true,
            dataChuyenKhoan: dataCost
        };
    }

    componentDidMount() {
        setTimeout(() => this.setState({loading: false}), 300);
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <OfflineBar />
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                    disabled={this.state.loading}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, { fontSize: 17}]}>
                        Chuyển khoản ATM
                    </Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        this.setState({loading: true});
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyBorrow()}
            </View>
        );
    }

    _renderLoadingView() {
        return (<View style={styles.viewBody}>
                <GiftedSpinner color="white" />
            </View>
        );
    }

    _renderBodyBorrow() {
        return(
            <View style={styles.viewBody}>
                <ScrollView style={[styles.viewScrollBody]}
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="none"
                            ref="_scrollview"
                >
                    {this._renderContentGroupTitle('HƯỚNG DẪN CHUYỂN TIỀN')}
                    {this._renderHelpSendMoney()}
                    {this._renderContentGroupTitle('CHI TIẾT KHUYẾN MẠI')}
                    {this._renderKhuyenMai()}
                    <FullLine />
                    {this._renderContentGroupTitle('DANH SÁCH CÁC TÀI KHOẢN')}
                    {this._renderListBankContent()}
                </ScrollView>
            </View>
        );
    }

    _renderKhuyenMai() {
        let logoIcon = require('../../assets/image/logo.png');
        return(
            <View style={styles.viewKhuyenMaiTotal}>
                <View style={styles.viewRowKhuyenMai}>
                    <View style = {[styles.viewEachRow, styles.lineFirstChild, {backgroundColor: '#fff'}]}>
                        <Image
                            style={styles.logoIcon}
                            resizeMode={Image.resizeMode.contain}
                            source={logoIcon}
                        />
                    </View>
                    <View style = {styles.viewEachRow}>
                        <ScalableText style={styles.textChild}>5%</ScalableText>
                    </View>
                    <View style = {styles.viewEachRow}>
                        <ScalableText style={styles.textChild}>10%</ScalableText>
                    </View>
                    <View style = {styles.viewEachRow}>
                        <ScalableText style={styles.textChild}>20%</ScalableText>
                    </View>
                    <View style = {styles.viewEachRow}>
                        <ScalableText style={styles.textChild}>30%</ScalableText>
                    </View>
                    <View style = {[styles.viewEachRow, { width: (width -32)/6 + 40}]}>
                        <ScalableText style={styles.textChild}>Số tiền nhận</ScalableText>
                    </View>
                </View>

                <View style={styles.viewRowKhuyenMai}>
                    <View style = {[styles.viewEachRow, styles.lineFirstChild, {backgroundColor: '#f48483'}]}>
                        <ScalableText style={[styles.textChild, {color: '#fff'}]}>300,000</ScalableText>
                    </View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}>
                        <TruliaIcon
                            name="check" color={'#37b44c'} size={20}
                            mainProps={styles.viewCheckIcon}
                        />
                    </View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}></View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}></View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}></View>
                    <View style = {[styles.viewEachRow, { width: (width -32)/6 + 40, backgroundColor: '#fff'}]}>
                        <ScalableText style={[styles.textChild,{color: '#000'}]}>315,000</ScalableText>
                    </View>
                </View>

                <View style={styles.viewRowKhuyenMai}>
                    <View style = {[styles.viewEachRow, styles.lineFirstChild, {backgroundColor: '#f06f6a'}]}>
                        <ScalableText style={[styles.textChild, {color: '#fff'}]}>1,000,000</ScalableText>
                    </View>
                    <View style = {styles.viewEachRow}></View>
                    <View style = {styles.viewEachRow}>
                        <TruliaIcon
                            name="check" color={'#37b44c'} size={20}
                            mainProps={styles.viewCheckIcon}
                        />
                    </View>
                    <View style = {styles.viewEachRow}></View>
                    <View style = {styles.viewEachRow}></View>
                    <View style = {[styles.viewEachRow, { width: (width -32)/6 + 40}]}>
                        <ScalableText style={[styles.textChild,{color: '#000'}]}>1,100,000</ScalableText>
                    </View>
                </View>

                <View style={styles.viewRowKhuyenMai}>
                    <View style = {[styles.viewEachRow, styles.lineFirstChild, {backgroundColor: '#eb5e54'}]}>
                        <ScalableText style={[styles.textChild, {color: '#fff'}]}>2,000,000</ScalableText>
                    </View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}></View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}></View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}>
                        <TruliaIcon
                            name="check" color={'#37b44c'} size={20}
                            mainProps={styles.viewCheckIcon}
                        />
                    </View>
                    <View style = {[styles.viewEachRow, {backgroundColor: '#fff'}]}></View>
                    <View style = {[styles.viewEachRow, { width: (width -32)/6 + 40, backgroundColor: '#fff'}]}>
                        <ScalableText style={[styles.textChild,{color: '#000'}]}>2,400,000</ScalableText>
                    </View>
                </View>

                <View style={[styles.viewRowKhuyenMai,{ borderBottomWidth: 1, borderTopWidth: 1, height: 37}]}>
                    <View style = {[styles.viewEachRow, styles.lineFirstChild, {backgroundColor: '#ec4d37'}]}>
                        <ScalableText style={[styles.textChild, {color: '#fff'}]}>5,000,000</ScalableText>
                    </View>
                    <View style = {styles.viewEachRow}></View>
                    <View style = {styles.viewEachRow}></View>
                    <View style = {styles.viewEachRow}></View>
                    <View style = {styles.viewEachRow}>
                        <TruliaIcon
                            name="check" color={'#37b44c'} size={20}
                            mainProps={styles.viewCheckIcon}
                        />
                    </View>
                    <View style = {[styles.viewEachRow, { width: (width -32)/6 + 40}]}>
                        <ScalableText style={[styles.textChild,{color: '#000'}]}>6,500,000</ScalableText>
                    </View>
                </View>
            </View>
        );
    }

    _renderHelpSendMoney () {
        let textHelp1 = 'Bạn có thể nạp tiền vào tài khoản của mình trên LandberAgent bằng cách chuyển tiền đến 1 trong các tài khoản ngân hàng của Reway Group bên dưới.';
        let textHelp2 = 'Nội dung chuyển khoản:';
        let textHelp3 =  'NAP AGENT ' + this.props.username;
        let textHelp4 = '* Khi nhận được tiền chúng tôi sẽ thông báo qua tính năng Chat của LandberAgent.';
        let textHelp5 = 'Hotline: 096 100 46 91';
        let textHelp6 = 'Email: info@landber.com';

        return(
            <View style={styles.viewHelpSendMoney}>
                <ScalableText style={styles.textStyleHelp}>{textHelp1}</ScalableText>
                <ScalableText style={[styles.textStyleHelp, {marginTop: 16, fontWeight: '600'}]}>{textHelp2}</ScalableText>
                <ScalableText style={[styles.textStyleHelp, {marginTop: 3, fontWeight: '600', color: gui.mainColor}]}>{textHelp3}</ScalableText>
                <ScalableText style={[styles.textStyleHelp, {marginTop: 16, fontStyle : 'italic', color: '#3a3a3a'}]}>{textHelp4}</ScalableText>
                <View style={styles.textHelpContact}>
                    <ScalableText style={[styles.textStyleHelp, {color: '#3b3b3d', marginTop: 16, fontWeight: '600'}]}>{textHelp5}</ScalableText>
                    <ScalableText style={[styles.textStyleHelp, {color: '#3b3b3d', marginLeft: 8, marginTop: 16, fontWeight: '600'}]}>{textHelp6}</ScalableText>
                </View>
            </View>
        );
    }

    _renderContentGroupTitle(title) {
        return (
            <View>
                <View style={styles.contentGroupTitle}>
                    <Text style={styles.contentGroupTitleText}>{title}</Text>
                </View>
                <FullLine />
            </View>
        );
    }

    _renderContentDetail(title, content, textStyle) {
        return (
            <View style={[styles.viewDetailRow, textStyle ]}>
                <Text style={[styles.textDetailTitle, textStyle]}>{title}</Text>
                <Text style={[styles.textDetailContent, textStyle]}>{content}</Text>
            </View>
        );
    }

    _renderListBankContent() {
        return(
            <View style={{flex: 1}}>
                <ListView
                    enableEmptySections = {true}
                    dataSource={ds_chuyenKhoan.cloneWithRows(this.state.dataChuyenKhoan)}
                    renderRow={this._renderRowBank.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                />
            </View>
        )
    }

    _renderRowBank(data) {
        return(
            <View>
                <View style={styles.viewLogoBank}>
                    <Image style={styles.logoStyle} source={data.image} resizeMode='contain' />
                </View>
                <View>
                    {this._renderContentDetail('Tên tài khoản:', data.tenTaiKhoan, {paddingTop: 0, paddingBottom: 0, marginTop: 1, marginBottom: 1})}
                    {this._renderContentDetail('Ngân hàng:', data.nganHang, {paddingTop: 0, paddingBottom: 0, marginTop: 1, marginBottom: 1})}
                    {this._renderContentDetail('Số tài khoản:', data.soTaiKhoan, {paddingTop: 0, paddingBottom: 0, marginTop: 1, marginBottom: 1})}
                    {this._renderContentDetail('Chi nhánh:', data.chiNhanh, {paddingTop: 0, paddingBottom: 0, marginTop: 1, marginBottom: 1})}
                </View>
                <FullLine style={{marginLeft: 17, marginTop: 5}}/>
            </View>
        );
    }

}
export default ChuyenKhoanATM;

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    contentGroupTitle: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingRight: 15,
        paddingLeft: 14,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8',
    },
    contentGroupTitleText: {
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: '#313131',
        justifyContent :'space-between',
        padding: 0,
        fontWeight:"300"
    },
    viewDetailRow: {
        flexDirection : "row",
        alignItems: 'flex-start',
        justifyContent: 'space-around',
        paddingTop: 10,
        paddingBottom: 10
    },
    textDetailTitle: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#000',
        marginLeft: 17,
        marginRight: 10,
        width: width/2 - 65
    },
    textDetailContent: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#000',
        marginLeft: 10,
        marginRight: 10,
        width: width/2 + 18
    },
    textNapTien: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#000',
        marginTop: 10,
        marginBottom: 10,
        marginLeft: 17,
    },
    viewListContainer: {
        paddingBottom: 50
    },
    viewLogoBank: {
        height: 60,
        width: width,
        marginLeft: width/2 - 38,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
    },
    logoStyle: {
        height: 50,
        width: 70
    },
    viewHelpSendMoney: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 15,
        paddingLeft: 17,
        paddingBottom: 15,
        paddingRight: 10
    },
    textStyleHelp: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#333333',
    },
    textHelpContact: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    viewKhuyenMaiTotal: {
        width: width,
        paddingTop: 10,
        paddingBottom: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor : '#fff'
    },
    viewRowKhuyenMai: {
        width: width - 32,
        height: 35,
        marginLeft: 17,
        marginRight: 15,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderTopWidth: 1,
        borderColor: '#cfd0d2'
    },
    viewEachRow: {
        width: (width -32)/6 - 15,
        height: 35,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f3f3f5',
        borderRightWidth: 1,
        borderColor: '#cfd0d2'
    },
    textChild: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: gui.mainColor,
    },
    lineFirstChild: {
        width: (width -32)/6 + 20,
        borderLeftWidth: 1,
        borderColor: '#cfd0d2'
    },
    viewCheckIcon: {
        width: 16,
        height: 22,
        marginBottom: 4
    },
    logoIcon: {
        height: 25,
        width: (width -32)/6 + 8,
        marginTop: 0
    }
});