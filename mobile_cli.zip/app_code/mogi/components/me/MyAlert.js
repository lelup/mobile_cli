import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    TouchableHighlight,
    ListView,
    ScrollView,
    Alert,
    StatusBar,
    ActivityIndicator,
    RefreshControl
} from 'react-native';

import { Actions } from 'react-native-router-flux';
import { Map } from 'immutable';
import moment from 'moment';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import GiftedSpinner from 'react-native-gifted-spinner';
import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';
import DanhMuc from '../../assets/DanhMuc';
import Toast, { DURATION } from '../toast/Toast';
import { LargeList } from "react-native-largelist";


import gui from '../../lib/gui';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import FullLine from '../line/FullLine';
let { width, height } = utils.getDimensions();
import OfflineBar from '../line/OfflineBar';

import userApi from '../../lib/userApi';
import * as meActions from '../../reducers/me/meActions';
import * as globalActions from '../../reducers/global/globalActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

const actions = [
    meActions,
    globalActions,
    groupActions,
    adsMgmtActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_listAlert = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

class MyAlert extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
        this.state = {
            isLoading: false,
            myNotifyList: props.me.myNotifyList
        }
    }

    componentDidMount() {
        let userID = this.props.global.currentUser.userID;
        let limit = this.props.global.setting.maxAdsInMapView;
        let dto = { userID: userID, limit: limit, pageNo: 1, isIncludeCountInResponse: true };
        this.props.actions.getMyNotify(dto);
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.me.myNotifyList !== nextProps.me.myNotifyList) {
            this.setState({ myNotifyList: nextProps.me.myNotifyList });
        }
    }

    _handleSearchAction(pageNo) {
        let userID = this.props.global.currentUser.userID;
        let limit = this.props.global.setting.maxAdsInMapView;
        let dto = { userID: userID, limit: limit, pageNo: pageNo, isIncludeCountInResponse: true };
        this.props.actions.getMyNotify(dto);
    }

    componentWillUnmount() {
        StatusBar.setBarStyle('dark-content');
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderAds()}
                <FullLine />
                {this._renderBodyAlert()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={100}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
                {/* {this._renderLoadingView()} */}
            </View>
        );

    }

    _renderLoadingView() {
        if (this.props.me.loadingMyNotify) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' />
            </View>)
        }
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={styles.textEdit}>Thông báo</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>

        );
    }

    _onBackPress() {
        // Actions.popTo("root");
        // Actions.MMeContent();
        // Actions.MyProfile();
        if (this.props.isFirstScene) {
            Actions.Home({ type: 'reset' });
        } else {
            Actions.pop();
        }
    }

    _renderBodyAlert() {
        let imageNoAlert = require('../../assets/image/none_alert.png');
        let myNotifyList = this.state.myNotifyList;
        let pageNo = this.props.me.myNotifyPageNo;
        let limit = this.props.global.setting.maxAdsInMapView;
        let totalCount = this.props.me.myNotifyTotalCount;
        let totalPages = totalCount / limit;
        let loading = this.props.me.loadingMyNotify;
        let showLastControl = !loading && totalPages && pageNo < totalPages;
        let textSmile = ' Hãy hoạt động!';
        if (!this.props.global.loggedIn) {
            return (
                <View style={[styles.viewNoneAlert, { justifyContent: 'center' }]}>
                    <Text style={styles.textNoneAlert}>Bạn hãy đăng nhập để nhận được thông báo</Text>
                </View>
            )
        }

        // if (myNotifyList.length == 0) {
        //     return (
        //         <View style={[styles.viewNoneAlert, { justifyContent: 'center' }]}>
        //             <Image
        //                 source={imageNoAlert}
        //                 resizeMode={"cover"}
        //                 style={styles.imageNoAlert}
        //             />
        //             <Text style={[styles.textNoneAds, {fontWeight: '500', marginTop: 23}]}>
        //                 Không có thông báo
        //             </Text>
        //             <Text style={styles.textNoneAds}>
        //                 {textSmile}
        //             </Text>
        //         </View>
        //     )
        // }
        if (this.props.me.loadingMyNotify && this.props.me.myNotifyPageNo == 1) {
            return (
                <ScrollView contentContainerStyle={styles.viewNoneAlert}
                    showsVerticalScrollIndicator={false}
                >
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                    {this._renderImageLoading()}
                </ScrollView>
            )
        }
        let data = ds_listAlert.cloneWithRows(myNotifyList);
        return (
            <View style={styles.viewBodyAlert}>
                {myNotifyList.length == 0 ? (
                    <View style={[styles.viewNoneAlert, { justifyContent: 'center' }]}>
                        <Image
                            source={imageNoAlert}
                            resizeMode={"cover"}
                            style={styles.imageNoAlert}
                        />
                        <Text style={[styles.textNoneAds, { fontWeight: '500', marginTop: 23 }]}>
                            Không có thông báo
                        </Text>
                        <Text style={styles.textNoneAds}>
                            {textSmile}
                        </Text>
                    </View>
                ) :
                    (<SwipeListView
                        ref={ref => this._swipeListView = ref}
                        enableEmptySections={true}
                        dataSource={data}
                        renderRow={(rowData, sectionID, rowID, rowMap) =>
                            (<SwipeRow
                                disableRightSwipe={true}
                                disableLeftSwipe={false}
                                rightOpenValue={-65}
                            >
                                <View style={[styles.rowBack, {
                                    alignItems: (rowID == 0) ? 'flex-end' : (rowID == (myNotifyList.length - 1)) ? 'flex-start' : 'center'
                                }]}>
                                    <TouchableOpacity onPress={() => {
                                        rowMap[`${sectionID}${rowID}`].closeRow();
                                        this._onDelete(rowData)
                                    }}
                                        style={styles.viewDeleteInbox}
                                    >
                                        {this.props.me.loadingDeleteMyNotify ?
                                            <View><GiftedSpinner color="#fff" /></View> : <Text style={styles.saveText}>Xóa</Text>
                                        }
                                    </TouchableOpacity>
                                </View>

                                {this._renderRowAlert(rowData, (rowID == 0), (rowID == (myNotifyList.length - 1)))}
                            </SwipeRow>
                            )}
                        style={styles.listView}
                        disableRightSwipe={true}
                        rightOpenValue={-65}
                        onEndReachedThreshold={0}
                        onEndReached={() => this._loadNextPage()}
                        refreshControl={
                            <RefreshControl
                                refreshing={false}
                                onRefresh={this._onRefresh.bind(this)}
                            />
                        }
                        renderFooter={() =>
                            this.props.me.loadingMyNotify
                                ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
                                : null}
                    />)
                }

                {/* {this._renderFooterAlert()} */}
            </View>
        )
    }

    _onRefresh() {
        this.props.actions.onMeFieldChange('myNotifyList', []);
        this.props.actions.onMeFieldChange('myNotifyTotalCount', 0);
        this.props.actions.onMeFieldChange('myNotifyPageNo', 1);
        let userID = this.props.global.currentUser.userID;
        let dto = { userID: userID, limit: 25, pageNo: 1, isIncludeCountInResponse: true };
        this.props.actions.getMyNotify(dto);
    }

    renderRight(section: number, row: number) {
        let myNotifyList = this.state.myNotifyList;
        let rowData = myNotifyList[row]
        return (
            <View style={[styles.rowBack, {
                alignItems: (row == 0) ? 'flex-end' : (row == (myNotifyList.length - 1)) ? 'flex-start' : 'center'
            }]}>
                <TouchableOpacity onPress={() => {
                    this._onDelete(rowData)
                }}
                    style={styles.viewDeleteInbox}
                >
                    {this.props.me.loadingDeleteMyNotify ?
                        <View><GiftedSpinner color="#fff" /></View> : <Text style={styles.saveText}>Xóa</Text>
                    }
                </TouchableOpacity>
            </View>
        )
    }

    _renderImageLoading() {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        return (
            <View>
                <View style={styles.viewRowPost}>
                    <View
                        style={styles.imagePost} />

                    <View style={styles.viewDetailPost}>
                        <View style={[styles.viewLineLoader1, { marginTop: 4, marginLeft: 0 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 4, marginLeft: 0 }]}></View>
                        <View style={[styles.viewLineLoader1, { marginTop: 4, marginLeft: 0 }]}></View>
                    </View>

                </View>
                <FullLine />
            </View>
        );
    }


    _renderFooterAlert() {
        let myProps = this.props;
        let pageNo = myProps.me.myNotifyPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = myProps.me.myNotifyTotalCount;
        let totalPages = totalCount / limit;
        if (totalPages && pageNo < totalPages) {
            return null;
        }
        return (
            <View style={styles.viewFooter}>
                {this.state.myNotifyList && this.state.myNotifyList.length > 0 ?
                    <View>
                        <Text style={styles.textFooter}>Tất cả đã được hiển thị</Text>
                        <Text style={[styles.textFooter, { fontWeight: '400', fontSize: 13, marginTop: 0 }]}>Vuốt sang trái để xoá thông báo</Text>
                    </View>
                    :
                    <Text style={[styles.textFooter, { marginTop: (height - 130) / 2 }]}>Bạn chưa có thông báo nào!</Text>
                }
            </View>
        );
    }

    _onDelete(data) {
        // log.info('===============> data', data);
        Alert.alert('Thông báo', 'Bạn có muốn xóa thông báo này không?',
            [{ text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
            { text: 'Đồng ý', onPress: () => this._doDeleteAlert(data) }
            ]);
    }

    _doDeleteAlert(row) {
        let id = row.id;
        let dto = {
            userID: this.props.global.currentUser.userID,
            id: id
        };
        let token = this.props.global.currentUser.token
        this.props.actions.deleteMyNotify(dto, token).then((e) => {
            if (e.status != 0) {
                Alert.alert("Thông báo", 'Xóa thông báo không thành công!');
            } else {
                // this._swipeListView.safeCloseOpenRow();                
                // setTimeout(() => {
                let newState = this.state.myNotifyList.filter((e) => { return e.id != id });
                this.setState({ myNotifyList: newState })
                // }, 1000);
            }

        });
    }
    //data, isFirstRow, isLastRow
    _renderRowAlert(data, isFirstRow, isLastRow) {

        if (!data)
            return null;

        let imgUrl = data.imgUrl;
        let imageUri = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageUri) {
            imageUri = require('../../assets/image/no_cover.jpg');
        }
        
        let header = data.header ? data.header : 'Thông báo:';
        let content = data.header ? data.header : 'Bạn vừa nhận 1 thông báo từ Landber Agent';
        let contentShort = content && content.length > 120 ? content.substring(0, 120) + "..." : content;
        let time = moment(data.dueDate).format("DD/MM/YYYY HH:mm");
        let typeAlert = data.category;
        let firstControl = null;
        let lastControl = null;
        let myProps = this.props;
        let pageNo = myProps.me.myNotifyPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = myProps.me.myNotifyTotalCount;
        let totalPages = totalCount / limit;
        let showFirstLoading = pageNo > 2;
        let showFirstControl = pageNo > 1;
        let loading = myProps.me.loadingMyNotify;
        let showLastControl = !loading && totalPages && pageNo < totalPages;
        let rowBackgroundColor = data.status == 3 ? '#fff' : 'rgba(241,247,255,1)'

        return (
            <View style={{ backgroundColor: rowBackgroundColor, flexDirection: 'column', overflow: 'hidden' }}>
                {firstControl}
                <TouchableHighlight style={styles.viewRowAlert}
                    onPress={() => this._onPressAlertDetail(typeAlert, data)}
                    underlayColor="rgba(220,220,220,1)"
                >
                    <View style={[styles.viewRowContent, {}]}>
                        
                        {typeAlert==DanhMuc.NOTIFICATION_CATEGORY.CommentReject 
                            || typeAlert==DanhMuc.NOTIFICATION_CATEGORY.StatusReject 
                            || typeAlert==DanhMuc.NOTIFICATION_CATEGORY.BlockUser
                        ? <View style={[styles.adsCover, { justifyContent:'center', alignItems:'center', backgroundColor: gui.mainColor }]}>
                                <Text style={[{alignSelf:'center', fontFamily: gui.fontFamily, color: '#fff', fontSize: 13, fontWeight: '600' }]}>Landber</Text>
                                <Text style={[{alignSelf:'center', fontFamily: gui.fontFamily, color: '#fff', fontSize: 13, fontWeight: '600' }]}>Admin</Text>
                            </View>
                        : <Image
                            resizeMode={"cover"}
                            source={imageUri}
                            defaultSource={defaultCover}
                            style={styles.adsCover} />
                        }
                        

                        <View style={styles.viewLeftContent}>

                            <View style={{ height: 'auto', flexWrap: 'wrap', flexDirection: 'row' }}>
                                {this._stringify(contentShort)}
                            </View>
                            {/* <Text style={styles.viewAlertContent} numberOfLines={2}>{contentShort}</Text> */}

                            {!data.processed && data.category == DanhMuc.NOTIFICATION_CATEGORY.RequestJoinGroup
                                ? <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start' }}>
                                    {this.state.loading == true
                                        ? <View style={styles.touchJoinGroup}>
                                            <Text style={styles.groupStatus}>Xác nhận</Text>
                                        </View>
                                        : <TouchableOpacity style={styles.touchJoinGroup}
                                            onPress={this._onApprovePress.bind(this, data, 2)}
                                        >
                                            <Text style={styles.groupStatus}>Xác nhận</Text>
                                        </TouchableOpacity>}

                                    {this.state.loading == true
                                        ? <View style={[styles.touchJoinGroup2, { marginLeft: 4 }]}>
                                            <Text style={[styles.groupStatus, { color: gui.textPostAds }]}>Từ chối</Text>
                                        </View>
                                        : <TouchableOpacity style={[styles.touchJoinGroup2, { marginLeft: 4 }]}
                                            onPress={this._onApprovePress.bind(this, data, 3)}
                                        >
                                            <Text style={[styles.groupStatus, { color: gui.textPostAds }]}>Từ chối</Text>
                                        </TouchableOpacity>}


                                    <Text style={[styles.viewAlertContent, { position: 'absolute', right: 0, marginTop: 3, fontStyle: 'italic', opacity: 0.65 }]}
                                        numberOfLines={1}>{utils.getDiffTime(data.dueDate)}</Text>
                                </View>
                                : <Text style={[styles.viewAlertContent, { marginTop: 3, fontStyle: 'italic', opacity: 0.65 }]}
                                    numberOfLines={1}>{time}</Text>}
                        </View>
                    </View>
                </TouchableHighlight>

            </View>
        )
    }

    _stringify(text) {
        if (!text) {
            return text;
        }

        let words = text.split(' ');
        let items = [];
        let index = 0;
        let totalLength = 0;

        let reachedMax = false;
        let showMoreText = "...";

        words.forEach((word) => {
            if (reachedMax)
                return;

            if (index > 0) {
                totalLength += 1
                items.push(
                    <Text key={index++} style={{ flexWrap: 'wrap', fontFamily: gui.fontFamily, color: gui.textPostAds }}>{' '}</Text>
                );
            }

            if (word.indexOf('<b>') > -1) {
                totalLength += word.length - 3
                if (totalLength < 70)
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontWeight: '500', fontFamily: gui.fontFamily, fontSize: 15, color: gui.textPostAds }}>{word.slice(3)}</Text>
                    );
                else {
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontWeight: '300', fontFamily: gui.fontFamily, fontSize: 15, color: gui.textPostAds }}>{showMoreText}</Text>
                    );
                    reachedMax = true;
                }
            }
            else {
                totalLength += word.length
                if (totalLength < 70)
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontWeight: '300', fontFamily: gui.fontFamily, fontSize: 15, color: gui.textPostAds }}>{word}</Text>
                    );
                else {
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontWeight: '300', fontFamily: gui.fontFamily, fontSize: 15, color: gui.textPostAds }}>{showMoreText}</Text>
                    );
                    reachedMax = true;
                }
            }
        });

        return items;
    }

    _onApprovePress(data, newStatus) {
        this.setState({
            loading: true
        });
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let approveJoinDto = {
            "approver": currentUser.userID || undefined, // chu san moi duoc duyet
            "newStatus": newStatus,
            "groupMemberID": data.groupMemberID || undefined,
            "member": data.member || undefined,
            "groupID": data.groupID,
            "groupName": data.groupName,
            "groupImage": data.imgUrl
        };

        this.props.actions.approve(approveJoinDto, token)
            .then(res => {

                this.props.actions.markNotificationReadAndProcessed({ id: data.id }, token);

                this.setState({
                    loading: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    if (newStatus == 2)
                        this.refs.toastTop && this.refs.toastTop.show(data.requesterName ? data.requesterName + ' đã được phê duyệt!' : data.phone + ' đã được phê duyệt!', DURATION.LENGTH_SHORT);
                    else if (newStatus == 3)
                        this.refs.toastTop && this.refs.toastTop.show(data.requesterName ? data.requesterName + ' đã bị từ chối!' : data.phone + 'đã bị từ chối!', DURATION.LENGTH_SHORT);
                    this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
                }
            });
    }

    _getPagingTitle() {
        let myProps = this.props;
        let pageNo = myProps.me.myNotifyPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = myProps.me.myNotifyTotalCount;
        let totalPages = totalCount / limit;
        let numberOfNotify = this.state.myNotifyList.length;

        let beginIndex = (pageNo - 1) * limit + 1;
        let endIndex = (pageNo - 1) * limit + numberOfNotify;
        if (totalCount < endIndex) {
            totalCount = endIndex;
        }
        if (pageNo == totalPages) {
            totalCount = endIndex;
        }
        let title = (beginIndex > 1 || totalCount > endIndex) ? 'Đang hiển thị từ ' + beginIndex + "-" + endIndex + ' / ' + totalCount + ' kết quả' :
            'Đang hiển thị ' + numberOfNotify + ' kết quả';
        return title;
    }

    _loadNextPage() {
        let myProps = this.props;
        let pageNo = myProps.me.myNotifyPageNo;
        let limit = myProps.global.setting.maxAdsInMapView;
        let totalCount = myProps.me.myNotifyTotalCount;
        let totalPages = totalCount / limit;

        if (totalPages && pageNo < totalPages) {
            pageNo = pageNo + 1;
            // myProps.actions.onMeFieldChange('myNotifyList', []);
            myProps.actions.onMeFieldChange('myNotifyTotalCount', 0);
            myProps.actions.onMeFieldChange('myNotifyPageNo', pageNo);
            this._handleSearchAction(pageNo);
        }
    }

    canAccessGroupWall(groupID) {

        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup

        let filtered = listRelatedGroup.filter((e) => { return e.groupID == groupID })
        if (!filtered || filtered.length == 0)
            return false
        if (filtered && filtered.length > 0 && filtered[0].joinStatus == 2)
            return true;
        return false;
    }


    onLogEvent(title) {
        let eventDto = {
            scene: "MyAlert",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onPressAlertDetail(type, data) {
        this.onLogEvent("Chi tiết thông báo");
        let id = data.id;
        let token = this.props.global.currentUser.token;
        if (type == 1) {
            Actions.AlertApproval({ data: data });
            this.props.actions.markNotificationRead({ id: id }, token);
        }
        if (type == 2 || type == 3 || type==DanhMuc.NOTIFICATION_CATEGORY.CommentReject || type==DanhMuc.NOTIFICATION_CATEGORY.StatusReject || type==DanhMuc.NOTIFICATION_CATEGORY.BlockUser) {
            Actions.AlertMarketing({ data: data });
            this.props.actions.markNotificationRead({ id: id }, token);
        }
        if (type == 5) {
            Actions.GroupApproval({ data: data });
            this.props.actions.markNotificationRead({ id: id }, token);
        }
        if (type == DanhMuc.NOTIFICATION_CATEGORY.SomeonePostedWtoPhuHop) {
            //query own wto data.wtoID
            this.props.actions.loadWtoByID(data.wtoID
                , (res) => {
                    log.info('will call detail  : server respond res: =====>>>>>', res.data, data)
                    // data.wtoList = []
                    let userDto = {
                        userID: data.senderID,
                        phone: data.senderPhone,                        
                        fullName: data.senderFullName
                    }
                    Actions.WtoPhuHopDetailAlert({ user: userDto, data: res.data[0], moiGioiMatching: data.ads });
                }
                , (error) => {
                    log.info('loadWtoByID : server respond error: =====>>>>>', error)                    
                });
            
        }
        if (type == DanhMuc.NOTIFICATION_CATEGORY.SomeonePostedAdsPhuHop) {
            //query own wto data.wtoID
            this.props.actions.loadAdsByID(data.adsID
                , (res) => {
                    log.info('will call detail  : server respond res: =====>>>>>', res.data, data)
                    // data.wtoList = []
                    let userDto = {
                        userID: data.senderID,
                        phone: data.senderPhone,                        
                        fullName: data.senderFullName
                    }
                    Actions.AdsPhuHopDetailAlert({ user: userDto, data: res.data[0], moiGioiMatching: data.wto });
                }
                , (error) => {
                    log.info('loadWtoByID : server respond error: =====>>>>>', error)                    
                });
            
        }
        if (type == DanhMuc.NOTIFICATION_CATEGORY.RequestJoinGroup) {
            this.setState({ isLoading: true });
            this.props.actions.getGroupDetail({ 'groupID': data.groupID }, (res) => {
                let groupData = res.data || [];
                // this.props.actions.onGroupFieldChange('requestList', [])
                setTimeout(() => {
                    this.props.actions.getPendingRequest(
                        { 'groupID': data.groupID }
                        , (res) => {
                            this.setState({ isLoading: false });
                            StatusBar.setBarStyle('light-content');
                            Actions.GroupRequest({ owner: 'MyAlert', groupData: groupData, groupID: data.groupID });
                        }
                        , (error) => {
                            this.setState({ isLoading: false });
                            StatusBar.setBarStyle('light-content');
                            Actions.GroupRequest({ owner: 'MyAlert', groupData: groupData, groupID: data.groupID });
                        });
                }, 300);

                this.props.actions.markNotificationRead({ id: id }, token);
            });
        }
        if (type == DanhMuc.NOTIFICATION_CATEGORY.ApproveJoinGroup) {
            if (!data.newStatus || data.newStatus == 2) {
                let userID = this.props.global.currentUser.userID
                let token = this.props.global.currentUser.token
                this.props.actions.getRelatedGroup({ userID: userID }, token, () => {
                    if (this.canAccessGroupWall(data.groupID)) {
                        this.setState({ isLoading: true });
                        this.props.actions.getGroupDetail({ 'groupID': data.groupID }, (res) => {
                            let groupData = res.data || [];
                            this.props.actions.onGroupFieldChange("pageNo", 1);
                            this.props.actions.onGroupFieldChange("textSearch", '');
                            this.props.actions.getNextWall(
                                {
                                    'groupID': [data.groupID],
                                    'limit': this.props.group.limit,
                                    'pageNo': 1,
                                    'textSearch': '',
                                }
                                , (res) => {
                                    this.setState({ isLoading: false });
                                    StatusBar.setBarStyle('default');

                                    Actions.GroupWall2({ owner: 'MyAlert', groupData: groupData, groupID: data.groupID });


                                }
                                , (error) => {
                                    this.setState({ isLoading: false });
                                })
                        });
                    }
                    else {
                        Alert.alert("Thông báo", 'Bạn không có quyền truy cập sàn này', [{ text: 'Đóng', onPress: () => { } }]);
                    }
                })

            }
            this.props.actions.markNotificationRead({ id: id }, token);
        }
        if (type == DanhMuc.NOTIFICATION_CATEGORY.CommentOnPost) {
            this.props.actions.getGroupWallByID({ 'groupWallID': data.groupWallID }, (res) => {
                let groupData = res.data[0] || [];
                // log.info('DanhMuc.NOTIFICATION_CATEGORY.CommentOnPost ****', groupData)
                this.props.actions.onGroupFieldChange('watchingWallID', groupData.id)
                Actions.GroupComment({ parentContent: groupData, groupID: groupData.groupID, groupWallID: groupData.id, owner: 'MyAlert' });

                this.props.actions.markNotificationRead({ id: id }, token);
            });
        }

    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 68,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEditHome: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit: {
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500',
        fontSize: 17
    },
    viewBodyAlert: {
        flex: 1,
        // width: width,
        // height:'auto',
        // flexDirection: 'column',
        // marginBottom: 50
    },
    textNotification: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontSize,
        color: gui.mainTextColor,
        fontWeight: '400'
    },
    viewNoneAlert: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start'
    },
    textNoneAlert: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontSize,
        color: gui.mainTextColor,
        fontWeight: '400'
    },
    viewRowAlert: {
        width: width,
        height: 83,
        borderBottomWidth: 1,
        borderColor: '#dcdcdc'
    },
    viewRowContent: {
        width: width,
        height: 82,
        flexDirection: 'row',
        backgroundColor: 'transparent',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewListContainer: {
        paddingBottom: 50
    },
    adsCover: {
        width: 60,
        height: 60,
        borderRadius: 30,
        marginLeft: 10,
    },
    viewLeftContent: {
        width: width - 84,
        height: 82,
        // paddingRight: 18,
        marginLeft: 8,
        paddingTop: 8,
        backgroundColor: 'transparent'
    },
    viewAlertHeader: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    viewAlertContent: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        color: gui.textPostAds,
        fontWeight: '400'
    },
    listView: {
        flex: 1,
        paddingTop: 0,
        backgroundColor: 'white',
        borderColor: '#e6e6e6',
        borderBottomWidth: 0,
    },
    rowBack: {
        alignItems: 'flex-end',
        backgroundColor: '#fff',
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingLeft: 0,
    },
    viewDeleteInbox: {
        right: 0,
        width: 65,
        backgroundColor: '#f43838',
        height: 82,
        alignItems: 'center',
        justifyContent: 'center'
    },
    saveText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: "white",
        textAlign: 'center',
        fontWeight: '500'
    },
    viewFooter: {
        marginTop: 20,
        width: width,
        height: 50,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textFooter: {
        fontSize: 17,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'
    },
    viewReadRow: {
        width: 34,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewDotAlert: {
        width: 12,
        height: 12,
        borderRadius: 6,
        marginTop: 20
    },
    viewArrowStyle: {
        paddingLeft: 0,
        paddingRight: 0,
        marginLeft: 10,
        marginRight: 10
    },
    viewRowPost: {
        width: width - 32,
        height: 82,
        alignItems: 'center',
        flexDirection: 'row',
        marginLeft: 16,
        marginRight: 16,
        backgroundColor: 'white'
    },
    imagePost: {
        height: 60,
        width: 60,
        // marginRight: 35,
        borderRadius: 30,
        backgroundColor: gui.groupBackground,
    },
    viewDetailPost: {
        height: 82,
        width: width - 80,
        justifyContent: 'center',
        backgroundColor: '#fff',
        marginLeft: 8
        // marginRight: 15
    },
    viewLineLoader1: {
        height: 15,
        width: width - 134,
        backgroundColor: gui.groupBackground,
    },
    rowControl: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: gui.mainColor
    },
    pagingTitle: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'gray'
    },
    touchJoinGroup: {
        // paddingVertical: 2,
        // paddingHorizontal: 5,
        marginTop: 4,
        borderRadius: 3,
        backgroundColor: gui.mainAgentColor,
        height: 22,
        width: 78,
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchJoinGroup2: {
        // paddingVertical: 2,
        // paddingHorizontal: 5,
        marginTop: 4,
        borderRadius: 3,
        borderColor: gui.textShare,
        borderWidth: 1,
        height: 22,
        width: 78,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    groupStatus: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#fff',
        textAlign: 'center'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: height / 2 - 20,
        left: width / 2 - 20,
        width: 40,
        height: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    imageNoAlert: {
        height: 90,
        width: 130
    },
    textNoneAds: {
        color: 'rgba(150,150,150,1)',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        alignSelf: 'center',
        textAlign: 'center'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(MyAlert);