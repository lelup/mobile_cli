'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';

import React, {Component} from 'react';

import {Text, View, StyleSheet, ScrollView, Alert,
    TextInput, StatusBar, Switch, TouchableOpacity, Linking, Platform } from 'react-native'

import TruliaIcon from '../TruliaIcon';

import {Map} from 'immutable';
import gui from "../../lib/gui";
import utils from '../../lib/utils';
import log from '../../lib/logUtil';

import FullLine from '../line/FullLine';
import OfflineBar from '../line/OfflineBar';

import {Actions} from 'react-native-router-flux';

import ScalableText from 'react-native-text';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import Button from 'react-native-button';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import VersionCheck from 'react-native-version-check';

VersionCheck.setAppID('1303128474');                    // Your App ID for App Store URL
VersionCheck.setAppName('landber-agent-moi-gioi-bds');

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const {width} = utils.getDimensions();

const actions = [
  globalActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}


class Setting extends Component {
  constructor(props) {
    super(props);
    this.state={
        toggleState: false,
        isNeedUpdate: false
    };
    StatusBar.setBarStyle('dark-content');

  }

  componentWillMount() {
      // let appVersion = this.props.global.deviceInfo.appVersion || undefined;
      // VersionCheck.getLatestVersion()
      //     .then(latestVersion => {
      //         if(latestVersion == appVersion) {
      //             this.setState({
      //                 isNeedUpdate: true
      //             })
      //         }
      //     });

      VersionCheck.needUpdate()
          .then(res => {
              if (res.isNeeded) {
                  this.setState({
                      isNeedUpdate: true
                  })
              }
          });
  }

  render() {
    return (

        <View style={style.container}>
            <OfflineBar />
          {this._renderHeader()}
          <ScrollView ref={(scrollView) => { this._scrollView = scrollView; }}
            >
          <View style = {{flexDirection: 'column', flex:1}}>

            {this._renderContentGroupTitle('KẾT QUẢ TÌM KIẾM')}
            <FullLine />

            {this._renderSoKetQuaTrenBanDo()}
            <FullLine style={{marginLeft:15}}/>

            {this._renderAutoLoadAds()}

              {this._renderContentGroupTitle(' ')}
              {this._renderVersion()}
              {this._renderContentGroupTitle(' ')}

              {this._renderAboutUs()}
          </View>
          </ScrollView>
            {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                              style={[style.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                  backgroundColor: gui.doneKeyButton }]}>Xong</Button> : null}

          <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

        </View>
    )
  }

  _onBack(){
    let maxAdsInMapView = this.props.global.setting.maxAdsInMapView;
    if (!maxAdsInMapView || maxAdsInMapView< 10 || maxAdsInMapView>50){
      Alert.alert('Thông báo', 'Số kết quả hiển thị trên bản đồ không đúng.');
      return;
    }
    this.props.actions.updateLocalSetting(this.props.global.setting);
    Actions.pop();
  }

  _renderHeader(){
    return (
        <View>
            <View style={style.headerContainer}>
                <TouchableOpacity style={style.viewPlusPost}
                                  onPress={this._onBack.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>

              <View style={style.headerTitle}>

                <Text style={style.headerTitleText}>
                    Cài đặt
                </Text>
              </View>
            </View>
            <FullLine/>
        </View>
    );
  }

  _renderContentGroupTitle(title){
    return (
      <View style={style.contentGroupTitle}>
        <Text style={style.contentGroupTitleText}>{title}</Text>
      </View>
    );
  }

  _renderSoKetQuaTrenBanDo(){
    return (
        <View style={style.rowContainer}>
          <View style={{flexDirection: 'column'}}>
            <ScalableText style={[style.contentLabel]}>
               Số kết quả hiển thị trên bản đồ
            </ScalableText>
            <ScalableText style={[style.noteLabel]}>
               Từ 10-50
            </ScalableText>
          </View>

          <TextInput
              secureTextEntry={false}
              autoCorrect = {false}
              keyboardType="numeric"
              style={[style.contentText]}
              value={this._getMaxAdsInMapView()}
              onChangeText={(text) => this.onValueChange("maxAdsInMapView", text)}
          />

        </View>
    );
  }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState});
    }

  _renderAutoLoadAds(){
     return (
         <View style={style.rowIconContainer}>
             <ScalableText style={[style.contentLabel]}>
                 Cập nhật kết quả khi bản đồ di chuyển
             </ScalableText>
             <View style={style.arrowIcon}>
                 <Switch
                     onValueChange={(value) => this.onValueChange('autoLoadAds', value)}
                     value={this._getAutoLoadAds()} />
             </View>
         </View>
        );
  }

    _renderVersion() {
        let appVersion = this.props.global.deviceInfo.appVersion || undefined;
        return (
            <View style={style.rowIconContainer}>
              <View style={{flex: 1}}>
                <ScalableText style={[style.contentLabel]}>
                  Phiên bản
                </ScalableText>
              </View>
              <View style={[style.arrowIcon, {marginRight: 15, flex: 1}]}>
                <Text style={style.textVersion}>{appVersion}</Text>
                  {this._renderUpdateVersion()}
              </View>
            </View>
        );
    }

    _renderUpdateVersion() {
      if(!this.state.isNeedUpdate) {
        return <ScalableText style={[style.textVersion, {marginLeft: 6}]}>(phiên bản mới nhất)</ScalableText>
      }
      return (
          <TouchableOpacity style={style.viewButtonUpdate}
                            onPress={this._upDatePress}
          >
              <ScalableText style={style.textUpdata}>Cập nhật</ScalableText>
          </TouchableOpacity>
      );
    }

    _upDatePress() {
        return Linking.openURL(VersionCheck.getStoreUrl());
    }

    _renderAboutUs () {
        return (
            <TouchableOpacity style={style.rowIconContainer}
                              onPress={this._onPressAboutUs}
            >
              <ScalableText style={[style.contentLabel]}>
                Giới thiệu Landber Agent
              </ScalableText>
              <View style={[style.arrowIcon, {marginRight: 15}]}>
                <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
              </View>
            </TouchableOpacity>
        );
    }


    _onPressAboutUs () {
      Actions.AboutLandber();
    }

  onMaxAdsInMapViewChange(field, text){
     this.onValueChange(field, Number(text));
  }

  onValueChange(field, value){
    this.props.actions.onSettingFieldChange(field, value);
  }

  _getMaxAdsInMapView(){
    let maxAdsInMapView = this.props.global.setting.maxAdsInMapView;
    return maxAdsInMapView ? maxAdsInMapView.toString() : '';
  }

  _getAutoLoadAds(){
    return this.props.global.setting.autoLoadAds;
  }
}

/**
 * ## Styles
 */
const style = StyleSheet.create({

  lineWithIconStyle : {
    borderTopColor: '#ebebeb',
    borderBottomColor: '#ebebeb',
    borderTopWidth: 1,
    borderBottomWidth: 1,
  },
  container: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'stretch',
    backgroundColor: 'transparent'
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    top: 0,
    height: 60
  },
  headerTitle: {
    left: 36,
    right: 36,
    marginTop: 30,
    marginBottom: 10,
    position: 'absolute'
  },
  headerTitleText: {
    color: gui.textPostAds,
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    textAlign: 'center'
  },
  changeButton: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    width: 80,
    right: 15,
    marginTop: 30,
    marginBottom: 10,
    position: 'absolute'
  },
  backButton: {
    marginTop: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    paddingLeft: 15,
    paddingRight: 15
  },
  backButtonText: {
    color: 'white',
    fontSize: gui.normalFontSize,
    fontFamily: gui.fontFamily,
    textAlign: 'left',
    marginLeft: 7
  },
  label: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    paddingRight: 5,
    color: '#8A8A8A'
  },
  normalFont: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: '#8A8A8A'
  },
  contentGroupTitle: {
    flexDirection : "row",
    justifyContent :'space-between',
    paddingRight: 15,
    paddingLeft: 15,
    paddingTop: 8,
    paddingBottom: 8,
    backgroundColor: '#f8f8f8'
  },
  contentGroupTitleText: {
    fontSize: 12,
    fontFamily: gui.fontFamily,
    color: '#606060',
    justifyContent :'space-between',
    padding: 0
  },
  line: {
    backgroundColor: 'lightgray',
    height: 1,
    marginLeft: 15
  },
  fullLine: {
    backgroundColor: 'lightgray',
    height: 1
  },
  rowContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'white',
    marginTop: 6,
    marginBottom: 6,
    paddingLeft: 15
  },
  contentLabel: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    justifyContent: 'center',
    fontSize: 17,
    fontFamily: gui.fontFamily,
    color: gui.mainTextColor,
    width: width-100
  },
  noteLabel: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    justifyContent: 'center',
    fontSize: 12,
    fontFamily: gui.fontFamily,
    color: 'gray',
    width: width-100,
    marginRight: 15
  },
  contentText: {
    textAlign: 'center',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: '#8A8A8A',
    marginLeft: 10,
    width: 50,
    height: 25,
    paddingLeft: 5,
    paddingRight: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: 'lightgray'
  },
  rowIconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    marginTop: 6,
    marginBottom: 6,
    paddingLeft: 15
  },
  arrowIcon: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: 'flex-end',
    marginRight: 10
  },
  textFullWidth: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 8,
    marginBottom: 7,
    marginLeft: 0,
    marginRight: 0,
  },
  dot3 : {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: 14,
    marginTop: 18,
    backgroundColor: 'white',
    borderWidth: 3.5
  },
  avatarIcon : {
    height: 60,
    width: 60,
    borderRadius: 30
  },
  searchButtonText2: {
      margin: 0,
      padding: 10,
      paddingRight: 17,
      color: 'white',
      fontSize: gui.buttonFontSize,
      fontFamily: gui.fontFamily,
      fontWeight : 'normal'
  },
    textVersion: {
        color: '#8A8A8A',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    viewButtonUpdate: {
        padding: 4,
        paddingLeft: 6,
        paddingRight: 6,
        backgroundColor: '#ff0000',
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 8,
        borderRadius: 5
    },
    textUpdata: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: '#fff',
        fontWeight: '400'
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        marginTop: 22,
        marginLeft: 16
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(Setting);

