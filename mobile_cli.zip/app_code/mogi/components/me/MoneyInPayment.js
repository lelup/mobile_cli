'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ListView, Linking} from 'react-native';

import FullLine from '../line/FullLine';
import OfflineBar from '../line/OfflineBar';
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import MChartView from '../MChartView';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';
import cfg from '../../cfg';
import Toast, {DURATION} from '../toast/Toast';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

import GiftedSpinner from 'react-native-gifted-spinner';

const {width, height} = util.getDimensions();

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const actions = [
    globalActions,
    meActions
];

let ds_napTien  = new ListView.DataSource({rowHasChanged:(r1,r2) => r1 !== r2 });

function mapStateToProps(state) {
    return {
        ...state
    };
}
function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();
    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MoneyInPayment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            main: props.global.currentUser.account.main,
            bonus: props.global.currentUser.account.bonus,
        };
    }

    componentDidMount() {
        setTimeout(() => this.setState({loading: false}), 300);
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.viewEdit}
                    activeOpacity={0}
                    disabled={this.state.loading}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontSize: 17}]}>
                        Thông tin tài khoản
                    </Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        this.setState({loading: true});
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                <OfflineBar />
                {this._renderHeaderAds()}
                {this._renderBodyBorrow()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                    style={{marginLeft: 17, marginRight: 17}}
                />
            </View>
        );
    }

    _renderLoadingView() {
        return (<View style={styles.viewBody}>
                <GiftedSpinner color="white" />
            </View>
        );
    }

    _renderBodyBorrow() {
        return(
            <View style={styles.viewBody}>
                <ScrollView style={[styles.viewScrollBody]}
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="none"
                            ref="_scrollview"
                >
                    {this._renderContentGroupTitle('SỐ DƯ TÀI KHOẢN')}
                    {this._renderThongTinTaiKhoan()}
                    {/*this._renderContentGroupTitle(' ')*/}
                    {/*this._renderTheCao()*/}
                    {/*this._renderContentGroupTitle(' ')*/}
                    {/*this._renderTinNhan()*/}
                    {this._renderContentGroupTitle(' ')}
                    {this._renderChuyenKhoan()}
                    <FullLine/>

                </ScrollView>
            </View>
        );
    }

    _renderThongTinTaiKhoan() {
        let main = this.state.main ? this.state.main : 0;
        let bonus = this.state.bonus ? this.state.bonus : 0;

        let data = [];
        let pallete = [];

        if (main>0 ) {
            data.push({
                "name": "",
                "fillColor" : gui.mainColor,
                "value": main
            });
            pallete.push(util.hexToRgb(gui.mainColor));
        }

        if (bonus>0){
            data.push({
                "name": "",
                "fillColor" : "#DE6207",
                "value": bonus
            });
            pallete.push(util.hexToRgb("#DE6207"));
        }

        let options = {
            margin: {
                top: 1,
                left: 2,
                bottom: 1,
                right: 2
            },
            width: 148,
            height: 148,
            r: 58,
            R: 73,
            legendPosition: 'topLeft',
            animate: {
                type: 'oneByOne',
                duration: 200,
                fillTransition: 3
            },
            label: {
                fontFamily: gui.fontFamily,
                fontSize: gui.buttonFontSize,
                fontWeight: 'normal'
            }
        };
        let chartTitleBold = `${util.getPriceText(main + bonus)}`;
        let chartTitle = 'Tổng tài khoản';
        return (
            <View>
                <View style={styles.viewChartProfile}>
                    <View style={styles.viewChartBody}>
                        <MChartView
                            data={data}
                            options={options}
                            pallete={pallete}
                            chartTitle={chartTitle}
                            chartTitleBold={chartTitleBold}
                        />
                    </View>
                    <View style={{paddingLeft: 0, paddingTop:2, marginLeft: 8}}>
                        {this._renderMoneyLine("Tài khoản chính", `${util.getPriceText(main)}`, gui.mainColor)}
                        {this._renderMoneyLine("Tài khoản phụ", `${util.getPriceText(bonus)}`, '#DE6207')}
                    </View>
                </View>
                <Text style={{fontSize: 5}} />
            </View>
        );
    }
    _renderMoneyLine(label, value, dotColor) {
        return (
            <View style={{flexDirection:'row'}}>
                <View style={[styles.dot3, {borderColor: dotColor}]}>
                </View>
                <View style={{flexDirection:'column', marginTop: 8, marginBottom: 8}}>
                    <Text style={{fontSize: 15, fontFamily: gui.fontFamily, fontWeight: 'bold'}}>
                        {value}
                    </Text>
                    <Text style={{fontSize: 12, fontFamily: gui.fontFamily, color: '#9C9C9C'}}>
                        {label}
                    </Text>
                </View>
            </View>
        )
    }

    _renderContentGroupTitle(title) {
        return (
            <View>
                <FullLine />
                <View style={styles.contentGroupTitle}>
                    <Text style={styles.contentGroupTitleText}>{title}</Text>
                </View>
                <FullLine />
            </View>
        );
    }

    _renderTheCao() {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onPressTheCao.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={styles.viewIcon}>
                        <RelandIcon name="mobile-dollar" color='#fff' mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 14}}
                                    size={22} textProps={{}}
                                    noAction={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <ScalableText style={styles.textDuAn}>Nạp tiền qua Thẻ cào, SMS, ATM/Visa</ScalableText>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _renderTinNhan () {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onPressTinNhan.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={[styles.viewIcon, {backgroundColor: '#ffa439'}]}>
                        <RelandIcon name="visa" color='#fff' mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 14}}
                                    size={22} textProps={{}}
                                    noAction={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <ScalableText style={styles.textDuAn}>In-App Purchase</ScalableText>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _renderChuyenKhoan () {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onPressChuyenKhoan.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={[styles.viewIcon, {backgroundColor: '#009edc'}]}>
                        <RelandIcon name="dollar-transfer" color='#fff' mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 14}}
                                    size={22} textProps={{}}
                                    noAction={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <Text style={styles.textDuAn}>Nạp tiền</Text>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _onPressTheCao() {
        let link = cfg.serverUrl + "/topup/1";
        log.info('============> link', link);
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
                setTimeout(() => {this._renderAfterPayment()}, 1000);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }

    _renderAfterPayment() {
        return Alert.alert('Thông báo', 'Để kiểm tra thông tin tài khoản, bạn hãy vào Tôi -> Cá nhân -> Thông tin tài khoản của bạn ở cuối danh sách');
    }

    _onPressTinNhan() {
        Actions.InAppPurchase();
    }

    _onPressChuyenKhoan () {
        Actions.ChuyenKhoanATM({username: this.props.global.currentUser.username});
    }

}
export default connect(mapStateToProps, mapDispatchToProps)(MoneyInPayment);

const styles = StyleSheet.create({
    viewScrollBody: {
        backgroundColor: '#fff',
        paddingBottom: 43,
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewChartProfile: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor:'white',
        paddingTop: 16,
        paddingBottom: 16

    },
    viewChartBody: {
        paddingLeft: 13,
        paddingTop:2,
        width: width/2,
        alignItems: 'center',
        justifyContent: 'center'
    },
    dot3 : {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 14,
        marginTop: 18,
        backgroundColor: 'white',
        borderWidth: 3.5
    },
    contentGroupTitle: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8',
    },
    contentGroupTitleText: {
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: '#313131',
        justifyContent :'space-between',
        padding: 0,
        fontWeight:"300"
    },
    viewDuAn: {
        width: width,
        height: 43,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    iconPosition: {
        width: 65,
        height: 43,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewIcon: {
        width: 30,
        height: 30,
        backgroundColor: '#ff4f3b',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5
    },
    viewTextCenter: {
        width: width - 105,
        height: 43,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    textDuAn: {
        fontSize: 15,
        color: '#000',
        fontWeight: '500',
        fontFamily:gui.fontFamily
    },
    viewArrow: {
        width: 40,
        height: 43,
        justifyContent: 'center',
        alignItems: 'center'
    },
});