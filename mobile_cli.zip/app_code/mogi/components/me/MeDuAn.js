import React, {Component} from  'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';

import {Actions} from 'react-native-router-flux';
import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();

import Modal from 'react-native-modalbox';
import ScalableText from 'react-native-text';

import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";

import * as Animatable from 'react-native-animatable';

class MeDuAn extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpenHelpSearch: true
        }
    }

    render() {
        return(
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                {/*{this._renderBodyDuAn()}*/}
                {this._renderHelpSearch()}
            </View>
        );

    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>Animatable</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _renderHelpSearch() {
        return(
            <Modal isOpen={this.state.isOpenHelpSearch}
                   onClosed={this._onCloseHelpSearch.bind(this)}
                   style={styles.viewHelpSearch}
                   position={"bottom"}
                   swipeToClose={false}
                   backdropPressToClose={true}
            >
                {this._renderHelpSearchContent()}
            </Modal>
        );
    }

    _onCloseHelpSearch() {
        this.setState({
            isOpenHelpSearch: false
        });
    }

    _renderHelpSearchContent() {
        return(
                <View style={styles.viewModalTop}>
                    <Animatable.View
                        animation="fadeIn"
                        //direction="alternate"
                    >
                        <View style={styles.viewAnimatable}>
                            <Text style={styles.textContent}>Nhấn vào đây</Text>
                            <Text style={styles.textContent}>để bắt đầu tìm kiếm!</Text>
                        </View>
                        <View style={[styles.triangle, this.props.style]} />
                    </Animatable.View>
                </View>
        );
    }

    _renderBodyDuAn() {
        return(
            <View style={styles.viewBody}>
                <View style={styles.viewModalTop}>
                    <Animatable.View
                        animation="fadeIn"
                        // direction="alternate"
                    >
                        <View style={styles.viewAnimatable}>
                            <Text style={styles.textContent}>Nhấn vào đây</Text>
                            <Text style={styles.textContent}>để bắt đầu tìm kiếm!</Text>
                        </View>
                        <View style={[styles.triangle, this.props.style]} />
                    </Animatable.View>
                </View>
            </View>
        );
    }

    _onBackPress(){
        Actions.popTo("root");
        // Actions.MMeContent();
        Actions.MyProfile();
    }
}

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    viewHelpSearch: {
        width: 150,
        height: 118,
        backgroundColor: 'transparent',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom:  49,
        borderRadius: 5,
        borderWidth: 0
    },
    viewModalTop:{
      width: 150,
      height: 60,
      justifyContent: 'flex-end',
      alignItems: 'center',
      backgroundColor: 'transparent',
      paddingTop: 10,
      marginLeft: width/3 - 2
    },
    viewAnimatable:{
        width: 150,
        height: 60,
        backgroundColor: gui.mainColor,
        borderRadius: 5,
        borderWidth: 0,
        borderColor: '#d3d3d3',
        justifyContent: 'center',
        alignItems: 'center'
    },
    textContent: {
        color: '#fff',
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    triangle: {
        width: 0,
        height: 0,
        backgroundColor: 'transparent',
        borderStyle: 'solid',
        borderLeftWidth: 6,
        borderRightWidth: 6,
        borderBottomWidth: 9,
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderBottomColor: gui.mainColor,
        transform: [
            {rotate: '180deg'}
        ],
        marginLeft: 14
    }

    });

export default MeDuAn;