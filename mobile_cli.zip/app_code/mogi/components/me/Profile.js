'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as authActions from '../../reducers/auth/authActions';
import * as registerActions from '../../reducers/register/registerActions';
import GiftedSpinner from 'react-native-gifted-spinner';
import DatePicker from 'react-native-datepicker';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import React, {Component} from 'react';
import {
    Text, View, StyleSheet, ScrollView, Image, Alert, AlertIOS,
    TextInput, StatusBar, TouchableOpacity, DatePickerIOS,
    InteractionManager, TouchableWithoutFeedback, Keyboard
} from 'react-native'
import TruliaIcon from '../TruliaIcon';
import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import log from '../../lib/logUtil';
import MChartView from '../MChartView';
import Toast, {DURATION} from '../toast/Toast';
import moment from 'moment';
import FullLine from '../line/FullLine';
import ScalableText from 'react-native-text';
import Camera from 'react-native-camera';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import Button from 'react-native-button';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import DanhMuc from '../../assets/DanhMuc';
const Permissions = require('react-native-permissions');
import CodeInput from '../loginGroup/ConfirmationCodeInput';
var Modal  = require('react-native-modalbox');
var {width, height} = util.getDimensions();
import cfg from "../../cfg";
import _ from 'lodash';
var Fabric = require('react-native-fabric');
import OfflineBar from '../line/OfflineBar';
var { Crashlytics } = Fabric;

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
var Analytics = require('react-native-firebase-analytics');

var rootUrl = `${cfg.serverUrl}`;
const actions = [
    globalActions,
    meActions,
    postAdsActions,
    authActions,
    registerActions
];
function mapStateToProps(state) {
    return {
        ...state
    };
}
function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();
    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
class Profile extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
        let date = this.props.me.profile.date ? this.props.me.profile.date : '';
        let username = this.props.me.profile.username;        
        // let usernameIsPhone = username.indexOf('@') <= -1;
        let phoneEditable = true;
        let emailEditable = true;
        if (!this.props.me.profile.fbID) {
            if ( username.indexOf('@') <= -1) 
                phoneEditable = false;
            else emailEditable = false;
        }
        this.state = {
            date: date,
            // usernameIsPhone : usernameIsPhone,
            phoneEditable : phoneEditable,
            emailEditable : emailEditable,            
            timeZoneOffsetInHours: date ? (+7) * (date).getTimezoneOffset() / 60 : 0,
            showNgaySinhPicker:false,
            toggleState: false,
            avatar: null,
            thumbnail: null,
            avatarUrl: null,
            thumbnailUrl: null,
            email : props.me.profile.email,
            phone : props.me.profile.phone,
            fullName: props.me.profile.fullName,
            isFetching: false,
            verifyCode: undefined,
            isOpenVerify: false
        }
        // console.log('============> owner', this.props.owner);
    }
    render() {
        return (
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                      style={{flex: 1}}
            >
                <View style={style.container}>
                    <OfflineBar />
                    {this._renderHeader()}
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'
                        extraScrollHeight={30}
                    >
                        <View style={style.viewScrollBody}>
                                    {this._renderContentGroupTitleTop('THÔNG TIN LIÊN LẠC')}
                                    {this._renderTenDangNhap()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderTenDayDu()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderSoDienThoai()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderEmail()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderWebsite()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderGioiThieu()}
                                    <Toast
                                        ref="toastTop"
                                        position='top'
                                        positionValue={height/3 - 40}
                                        fadeInDuration={850}
                                        fadeOutDuration={1400}
                                        opacity={0.56}
                                        textStyle={{color:'#fff'}}
                                    />
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderPhoto()}
                                    {this._renderContentGroupTitle('')}
                                    {this._renderDoiMatKhau()}
                                    {this._renderContentGroupTitle('THÔNG TIN CÁ NHÂN')}
                                    {this._renderGioiTinh()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderNgaySinh()}
                                    {/*{this._renderNgaySinhPicker()}*/}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderDiaChi()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {this._renderMoiGioi()}
                                    <FullLine style={{ marginLeft: 15 }} />
                                    {/*this._renderContentGroupTitle('THÔNG TIN TÀI KHOẢN')*/}
                                    {/*this._renderThongTinTaiKhoan()*/}
                        </View>
                    </KeyboardAwareScrollView>
                    {/*{this.state.toggleState ? <Button onPress={() => dismissKeyboard()}*/}
                                                      {/*style={[style.searchButtonText2, { textAlign: 'right', color: gui.mainColor,*/}
                                                          {/*backgroundColor: gui.doneKeyButton }]}>Xong</Button> : null}*/}
                    {/*<KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>*/}
                    {this._renderModalVerify()}
                    {this._renderLoadingView()}
                </View>
            </TouchableWithoutFeedback>
        )
    }

    _renderModalVerify() {
        return(
            <Modal isOpen={this.state.isOpenVerify}
                   onClosed={this._onCloseVerify.bind(this)}
                   style={style.viewModalVerify}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderVerifyContent()}
            </Modal>
        );
    }


    _renderVerifyContent() {
        let isChangedPhone = this._isChangedPhone();
        let destinationType = isChangedPhone ? "điện thoại" : "email";
        let codeGuide = `Mã xác nhận gồm 5 chữ số vừa được gửi đến ${destinationType} của bạn.`;
        return(
            <View style={style.viewContentModal}>
                <ScrollView contentContainerStyle={style.scrollView}
                            style={{flex: 1}}
                            automaticallyAdjustContentInsets={false}
                            vertical={true}>
                    <View style={style.viewBackButton}>
                        <TouchableOpacity style={style.touchBackButton}
                                          onPress={this._onCloseVerify.bind(this)}
                        >
                            <MaterialCommunityIcons name="close"
                                        size={22}
                                        color="#526173"
                                        mainProps={{marginLeft: 0}}
                                        noAction={true} />
                        </TouchableOpacity>
                        <View style={style.viewSendCodeAgain}>
                        </View>
                    </View>
                    <View style={style.viewDangNhap}>
                        <Text style={style.textDangNhap}>Nhập mã xác nhận</Text>
                    </View>
                    <View style={style.lineDangNhap}/>
                    <View style={style.viewCodeGuide}>
                        <Text style={[style.textSendCodeAgain, {color: 'rgba(82,97,115,0.5)'}]}>
                            {codeGuide}
                        </Text>
                    </View>
                    <View style={style.viewCodeElement}>
                        <CodeInput
                            ref="codeInputRef"
                            keyboardType="numeric"
                            codeLength={5}
                            className={'border-circle'}
                            //compareWithCode='12345'
                            autoFocus={true}
                            codeInputStyle={style.codeInputStyle}
                            onFulfill={(code) => this.doApplyChangeWithVerify(code)}
                        />
                    </View>
                    {this.state.isFetching ?
                        (<View style={style.viewIsFetching}>
                            <GiftedSpinner size="large" color={gui.mainTextColor} />
                        </View>) : null
                    }
                    <Toast
                        ref="toastTopModal"
                        position='top'
                        positionValue={292}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{color:'#fff'}}
                    />
                </ScrollView>
            </View>
        )
    }

    _onFinishCheckingCode() {

    }
    _onCloseVerify() {
        this.setState({
            isOpenVerify: false
        })
    }
    onKeyboardToggle(toggleState) {
        this.setState({ toggleState});
    }
    _onBack() {
        Actions.pop();
    }

    validateData(){
        let phone = this.state.phone;
        let email = this.state.email;
        let fullName = this.state.fullName;

        if (!phone && !email){
            // Alert.alert('Thông báo', 'Bạn phải có thông tin số điện thoại hoặc email.');
            this.refs.toastTop && this.refs.toastTop.show('Bạn phải nhập thông tin số điện thoại hoặc email.',DURATION.LENGTH_LONG);
            return false;
        }

        if (!fullName || fullName.trim().length == 0){
            // Alert.alert('Thông báo', 'Bạn phải có thông tin số điện thoại hoặc email.');
            this.refs.toastTop && this.refs.toastTop.show('Bạn phải nhập thông tin họ tên.',DURATION.LENGTH_LONG);
            return false;
        }

        if (phone && !util.validatePhone(phone)){
            // Alert.alert('Thông báo', 'Số điện thoại không đúng định dạng');
            this.refs.toastTop && this.refs.toastTop.show('Số điện thoại không đúng định dạng.',DURATION.LENGTH_LONG);
            return false;
        }

        if (email && !util.validateEmail(email)){
            // Alert.alert('Thông báo', 'Email không đúng định dạng.');
            this.refs.toastTop && this.refs.toastTop.show('Email không đúng định dạng.',DURATION.LENGTH_LONG);
            return false;
        }

        return true;
    }
    
    _onApply(){
        if (!this.validateData())
            return;

        let phone = this.state.phone;
        let email = this.state.email;
        let oldPhone = this.props.me.profile.phone;
        let oldEmail = this.props.me.profile.email;
        let checkingAccountList = [];
        if (phone && phone != oldPhone) {
            checkingAccountList.push(phone);
        }

        if (email && email != oldEmail) {
            checkingAccountList.push(email);
        }

        if (checkingAccountList.length > 0) {
            this._checkUserExist(checkingAccountList);
        } else {
            this._onUpdateProfile();
        }
    }

    _onUpdateProfile() {
        if (this.props.global.currentUser.fbID) {
            this._doAfterCheckUserAccessable();
        } else {
            AlertIOS.prompt('Nhập mật khẩu',
                `Nhập mật khẩu để thay đổi thông tin của bạn`,
                [{text: 'Xong', onPress: this._applyChange.bind(this)}, {text: 'Hủy', style: 'cancel'}], 'secure-text');
        }
    }

    _checkUserExist(checkingAccountList) {
        this._checkPhoneOrEmailExist(checkingAccountList[0], () => {
            if (checkingAccountList.length > 1) {
                this._checkPhoneOrEmailExist(checkingAccountList[1], () => {
                    this._onUpdateProfile();
                });
            } else {
                this._onUpdateProfile();
            }
        });
    }

    _checkPhoneOrEmailExist(phoneOrEmail, callback) {
        this.props.actions.checkUserExist(phoneOrEmail).then(
            (res) => {
                log.info("Login._checkPhoneOrEmailExist");
                this.setState({checkingUser: false});
                if (res.status != 0) {
                    let msg = this._getErrorMessage(phoneOrEmail);
                    this.refs.toastTop && this.refs.toastTop.show(msg,DURATION.LENGTH_LONG);
                }
                else if (res.exist){
                    let msg = this._getUserExistMessage(phoneOrEmail);
                    this.refs.toastTop && this.refs.toastTop.show(msg,DURATION.LENGTH_LONG);
                } else {
                    callback();
                }
            }
        );
    }

    _getUserExistMessage(phoneOrEmail) {
        let msg = '';

        if (phoneOrEmail.indexOf("@")>=0) {
            msg = 'Email đã được sử dụng';
        } else {
            msg = 'Số điện thoại đã được sử dụng';
        }

        return msg;
    }

    _getErrorMessage(phoneOrEmail) {
        let msg = '';

        if (phoneOrEmail.indexOf("@")>=0) {
            msg = 'Hệ thống hiện tại không kiểm tra được trạng thái email của bạn';
        } else {
            msg = 'Hệ thống hiện tại không kiểm tra được trạng thái số điện thoại của bạn';
        }

        return msg;
    }

    _isChangedPhone() {
        let username = this.props.me.profile.username;
        let phone = this.state.phone;
        return phone && username != phone;
    }

    _applyChange(value) {
        this.props.actions.checkUserAccessable(this.props.me.profile.userID, value)
            .then( (e) => {
                if (e.status){

                    this._doAfterCheckUserAccessable();
                } else {
                    Alert.alert("Thông báo", e.msg);
                }
            });
    }

    _doAfterCheckUserAccessable() {

        if (!this.props.me.profile.fbID && (
                (this.state.phone && this.props.me.profile.phone != this.state.phone)
                || (this.state.email && this.props.me.profile.email != this.state.email)
            )){

            let isChangedPhone = this._isChangedPhone();
            let destinationType = isChangedPhone ? "điện thoại" : "email";

            this.setState({isFetching: true});
            let username  = isChangedPhone ? this.state.phone : this.state.email;

            if (username){
                this.props.actions.requestVerifyCode(
                    {   username: username,
                        verifyType: DanhMuc.VERIFY_TYPE.profile
                    })
                    .then ((res) => {
                        this.setState({isFetching: false});
                        if (res.success){
                           this.setState({isOpenVerify: true})
                        } else {
                            Alert.alert("Thông báo", "Hệ thống gửi mã xác nhận không thành công. Xin vui lòng kiểm tra lại số điện thoại hoặc thực hiện lại sau 15 phút.");
                        }
                    });
            } else {
                this.doApplyChange();
            }

        } else {
            this.doApplyChange();
        }
    }

    doApplyChangeWithVerify = async(value) =>{
        if (!value){
            this.refs.toastTop && this.refs.toastTop.show(gui.VERIFY_CODE_IS_UNFULFILLED,DURATION.LENGTH_LONG);
            return;
        }
        await this.setState({verifyCode: value});
        this.doApplyChange();
    }

    doApplyChange(){
        let sourceImageFile = this.state.avatar;
        let thumbnailImageFile = this.state.thumbnail;
        if (!sourceImageFile) {
            this._updateProfile();
        } else {
            let ms = moment().toDate().getTime();
            let userID = this.props.global.currentUser.userID;
            let destFileName = 'Avatar_' + userID + '_' + ms + sourceImageFile.substring(sourceImageFile.lastIndexOf('.'));
            this.props.actions.onUploadImage(destFileName, sourceImageFile, this._uploadCallBack.bind(this), 'normal');

            let thumbnailImageName = 'Thumbnail_Avatar_' + userID + '_' + ms + thumbnailImageFile.substring(thumbnailImageFile.lastIndexOf('.'));
            this.props.actions.onUploadImage(thumbnailImageName, thumbnailImageFile, this._uploadCallBack.bind(this), 'thumbnail');
        }
    }

    _uploadCallBack(err, result, type) {
        let data = result && result.data;
        if (err || data == '') {
            return;
        }
        let {success, file} = JSON.parse(data);
        if (success) {
            var {url} = file;
            let imgUrl = url;
            if (type=='normal') {
                this.state.avatarUrl = imgUrl
                this.props.actions.onProfileFieldChange('avatar', imgUrl);
            }
            if (type=='thumbnail') {
                this.state.thumbnailUrl = imgUrl
                this.props.actions.onProfileFieldChange('thumbnail', imgUrl);
            }
            
            if (this.state.avatarUrl && this.state.thumbnailUrl)
                InteractionManager.runAfterInteractions(() => {
                    this._updateProfile(imgUrl);
                });
        }
    }
    _updateProfile(imgUrl){
        let profile = this.props.me.profile;
        let dto = {
            userID: profile.userID,
            username: profile.username,
            fullName : profile.fullName,
            email : this.state.email||undefined,
            phone : this.state.phone||undefined,
            diaChi : profile.diaChi||undefined,
            gioiThieu: profile.gioiThieu||undefined,
            avatar : this.state.avatarUrl || profile.avatar || undefined,
            thumbnail: this.state.thumbnailUrl || profile.thumbnail || undefined,
            sex: profile.sex||'U', // F, M, U
            birthDate: profile.birthDate||undefined, // date type
            website: profile.website||undefined,
            broker: profile.broker||'U',
            verifyCode: this.state.verifyCode || undefined,
            verifyType: this.state.verifyCode ? DanhMuc.VERIFY_TYPE.profile : undefined
        };

        console.log('_updateProfile dto to updadate ********', dto)
        let token = this.props.global.currentUser.token;
        this.props.actions.updateProfile(dto, token).then(
            (res) =>{
                if (res.success){
                    this._updateCurrentUser();
                    this.setState({isOpenVerify: false});                    
                    Alert.alert('Thông báo','Cập nhật thông tin cá nhân thành công.');
                    this.setState({avatar: null, thumbnail: null});     
                    Actions.pop();
                } else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        ). catch((res) => {
            Alert.alert('Thông báo', res.toString());
        })
    }
    _updateCurrentUser(){
        let {userID, username, fullName, avatar, thumbnail, email, phone} = this.props.me.profile;
        this.props.actions.onCurrenUserFieldChange('fullName', fullName);
        this.props.actions.onCurrenUserFieldChange('phone', phone);
        this.props.actions.onCurrenUserFieldChange('email', email);
        this.props.actions.onCurrenUserFieldChange('avatar', avatar);
        this.props.actions.onCurrenUserFieldChange('thumbnail', thumbnail);
        let name = username;
        if (fullName) {
            name = fullName;
        }
        if (userID) {
            let name = username;
            if (fullName) {
                name = fullName;
            }

            Crashlytics.setUserName(name);
            let phoneEmail = phone || email;
            if (phone && email) {
                phoneEmail = phone + '/' + email;
            }
            Crashlytics.setUserEmail(phoneEmail);

            const options = {
                "emailsCryptType": 2,
                "emails":[
                    phoneEmail
                ]
            };

            Analytics.setUserProperty('email', email);
            Analytics.setUserProperty('phone', phone);
            Analytics.setUserProperty('name', name);
            Analytics.setUserProperty('avatar', avatar);

            Analytics.logEvent('login', {
                'userID': userID,
                'email': email,
                'phone': phone,
                'name': name,
                'avatar': avatar
            });
        }
    }
    _renderHeader(){
        return (
            <View>
                <View style={style.headerContainer}>
                    <TouchableOpacity style={style.viewPlusPost}
                                      onPress={this._onBack.bind(this)}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                    </TouchableOpacity>
                    <View style={style.headerTitle}>
                        <ScalableText style={style.headerTitleText}>
                            {this.props.me.profile.fullName}
                        </ScalableText>
                    </View>
                    <TouchableOpacity onPress={this._onApply.bind(this)}>
                        <View style={style.changeButton}>
                            <Button onPress={this._onApply.bind(this)}
                                    style={[style.headerTitleText,style.textButtonChange,
                                    {textAlign: 'right', width: 65}]}>
                                Thay đổi
                            </Button>
                        </View>
                    </TouchableOpacity>
                </View>
                <FullLine/>
            </View>
        );
    }
    _renderLoadingView(){
        if (this.props.me.isUpdatingProfile || this.props.postAds.imageUploading || this.props.auth.isFetching){
            return (
                <View style={style.viewSpinLoading}>
                    <GiftedSpinner size="small" color="gray" />
                </View>
            )
        }
    }
    _renderContentGroupTitle(title){
        return (
            <View>
                <FullLine />
                <View style={style.contentGroupTitle}>
                    <Text style={style.contentGroupTitleText}>{title}</Text>
                </View>
                <FullLine />
            </View>
        );
    }
    _renderContentGroupTitleTop(title) {
        return (
            <View>
                <View style={style.contentGroupTitle}>
                    <Text style={style.contentGroupTitleText}>{title}</Text>
                </View>
                <FullLine />
            </View>
        );
    }
    _renderTenDangNhap(){
        return (
            <View style={style.rowContainer}>
                <Text style={[style.contentLabel]}>
                    Tên đăng nhập
                </Text>
                <TextInput
                    editable={false}
                    secureTextEntry={false}
                    autoCorrect = {false}
                    style={style.contentText}
                    value={this.props.me.profile.username}
                    onChangeText={(text) => {log.info("do nothing !!!!")}}
                />
            </View>
        );
    }
    _renderTenDayDu(){
        return (
            <View style={style.rowContainer}>
                <Text style={[style.contentLabel]}>
                    Họ tên
                </Text>
                <TextInput
                    secureTextEntry={false}
                    autoCorrect = {false}
                    autoCapitalize='words'
                    style={[style.contentText, style.viewBorderProfile]}
                    value={this._getFullName()}
                    onChangeText={(text) => {this.onValueChange("fullName", text); this.setState({fullName: text}) }}
                />
            </View>
        );
    }
    _renderSoDienThoai(){
        return (
            <View style={style.rowContainer}>
                <Text style={[style.contentLabel]}>
                    Số điện thoại
                </Text>
                <TextInput
                    editable={this.state.phoneEditable}
                    secureTextEntry={false}
                    autoCorrect = {false}
                    keyboardType="numeric"
                    returnKeyType='done'
                    style={[style.contentText,style.viewBorderProfile]}
                    value={this._getSoDienThoai()}
                    onChangeText={(text) => this.setState({phone: text})}
                />
            </View>
        );
    }
    _renderEmail(){
        return (
            <View style={style.rowContainer}>
                <Text style={[style.contentLabel]}>
                    Email
                </Text>
                <TextInput
                    editable={this.state.emailEditable}
                    secureTextEntry={false}
                    autoCorrect = {false}
                    autoCapitalize = {'none'}
                    style={[style.contentText, style.viewBorderProfile]}
                    value={this._getEmail()}
                    onChangeText={(text) => this.setState({email: text})}
                />
            </View>
        );
    }
    _renderWebsite(){
        return (
            <View style={style.rowContainer}>
                <Text style={[style.contentLabel]}>
                    Website
                </Text>
                <TextInput
                    secureTextEntry={false}
                    autoCapitalize = {'none'}
                    autoCorrect = {false}
                    style={[style.contentText, style.viewBorderProfile]}
                    value={this._getWebsite()}
                    onChangeText={(text) => this.onValueChange("website", text)}
                    returnKeyType='done'
                />
            </View>
        );
    }
    _onChangeAvatar(avatar, type) {
        if (type=='normal')
            this.setState({avatar: avatar});
        if (type=='thumbnail')
            this.setState({thumbnail: avatar});        
    }
    _renderPhoto(){
        let avatarUri = this.state.avatar ? {uri: this.state.avatar} : null;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!avatarUri) {
            avatarUri = this.props.me.profile.avatar ? {uri: this.props.me.profile.avatar} : defaultAvatar;
        }
        return (
            <TouchableOpacity
                onPress={this.takePicture.bind(this)}
            >
                <View style={style.rowContainer}>
                    <Text style={[style.contentLabel]}>
                        Ảnh
                    </Text>
                        <Image
                            style={style.avatarIcon}
                            resizeMode={Image.resizeMode.cover}
                            source={avatarUri}
                            defaultSource={defaultAvatar}
                        />
                        <ScalableText style={style.contentText}>
                            Chạm để thay đổi ảnh
                        </ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
    _renderGioiThieu(){
        let totalGioiThieu = this.props.me.profile.gioiThieu || "";
        let number = totalGioiThieu.length;
        return (
            <View style={style.rowContainer}>
                <Text style={[style.contentLabel]}>
                    Giới thiệu
                </Text>
                <View style={{flex:1}}>
                    <TextInput
                        secureTextEntry={false}
                        autoCapitalize = {'words'}
                        autoCorrect={false}
                        placeholder='Giới thiệu về bản thân'
                        placeholderTextColor='#adb4b7'
                        textAlignVertical={'top'}
                        multiline = {true}
                        maxLength={250}
                        returnKeyType='next'
                        numberOfLines = {5}
                        style={[style.contentText, style.viewBorderProfile, {height: 100}]}
                        value={this._getGioiThieu()}
                        onChangeText={(text) => this.onValueChange("gioiThieu", text)}
                    />
                    <View style={style.numberPicture}>
                        <Text style={{marginRight:25, color:'gray', fontWeight:'200', fontSize:12 }}>{number}/250</Text>
                    </View>
                </View>
            </View>
        );
    }
    _renderDoiMatKhau(){
        return (
            <TouchableOpacity onPress={() => this._onDoiMatKhauPressed()}>
                <View style={style.rowIconContainer}>
                    <Text style={[style.contentLabel, {width: 150}]}>
                        Thay đổi mật khẩu
                    </Text>
                    <View style={style.arrowIcon}>
                        <Text style={style.label}> </Text>
                        <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
    _renderGioiTinh(){
        return (
            <TouchableOpacity onPress={() => this._onGioiTinhPressed()}>
                <View style={style.rowIconContainer}>
                    <Text style={[style.contentLabel]}>
                        Giới tính
                    </Text>
                    <View style={style.arrowIcon}>
                        <Text style={style.label}>{this._getGioiTinh()}</Text>
                        <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
    _renderNgaySinh(){
        return (
            <View style={[style.rowIconContainer, {paddingRight: 15}]}>
                <Text style={[style.contentLabel]}>
                    Ngày sinh
                </Text>
                <View style={style.arrowIcon}>
                    {/*<Text style={style.label}>{this._getNgaySinh()}</Text>*/}
                    <DatePicker
                        style={{
                            width: width/2 - 30,
                            marginRight: 10,
                        }}
                        customStyles={{
                            dateInput : {
                                borderColor: '#dcdcdc',
                                borderWidth: 1
                            },
                            placeholderText: {
                                color: '#8A8A8A'
                            },
                            dateText: {
                                color: '#8A8A8A'
                            }
                        }}
                        showIcon={false}
                        date={this._getNgaySinh()}
                        mode="date"
                        placeholder="Chọn ngày sinh"
                        format="DD/MM/YYYY"
                        minDate="01/01/1916"
                        maxDate={moment().format("DD/MM/YYYY")}
                        confirmBtnText="Chọn"
                        cancelBtnText="Hủy"
                        onDateChange={this._onNgaySinhChange.bind(this)}
                    />
                    {/*<TruliaIcon name={"arrow-down"} color={gui.arrowColor} size={18} />*/}
                </View>
            </View>
        );
    }
    // _renderNgaySinhPicker(){
    //     if (!this.state.showNgaySinhPicker)
    //         return <View />;
    //
    //     return (
    //         <DatePickerIOS
    //             date={this.state.date}
    //             mode="date"
    //             timeZoneOffsetInMinutes={this.state.timeZoneOffsetInHours}
    //             onDateChange={this._onNgaySinhChange.bind(this)}
    //         />
    //     );
    // }
    _renderDiaChi(){
        return (
            <View style={[style.rowIconContainer, {paddingRight: 15}]}>
                <Text style={[style.contentLabel]}>
                    Địa chỉ
                </Text>
                <View style={style.arrowIcon}>
                    <TextInput
                        multiline = {false}
                        autoCorrect = {false}
                        numberOfLines = {3}
                        style={[style.contentText, style.viewBorderProfile]}
                        value={this._getDiaChi()}
                        onChangeText={(text) => this.onValueChange("diaChi", text)}
                        returnKeyType='done'
                    />
                </View>
            </View>
        );
    }
    _renderMoiGioi(){
        return (
            <TouchableOpacity onPress={() => this._onMoiGioiPressed()}>
                <View style={style.rowIconContainer}>
                    <Text style={[style.contentLabel, {width: 140}]}>
                        Vai trò của bạn
                    </Text>
                    <View style={style.arrowIcon}>
                        <Text style={style.label}>{this._getMoiGioi()}</Text>
                        <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
    _renderThongTinTaiKhoan() {
        let main = this.props.global.currentUser.account.main ? this.props.global.currentUser.account.main : 0;
        let bonus = this.props.global.currentUser.account.bonus ? this.props.global.currentUser.account.bonus : 0;

        let data = [];
        let pallete = [];

        if (main>0 ) {
            data.push({
                "name": "",
                "fillColor" : gui.mainColor,
                "value": main
            });
            pallete.push(util.hexToRgb(gui.mainColor));
        }

        if (bonus>0){
            data.push({
                "name": "",
                "fillColor" : "#DE6207",
                "value": bonus
            });
            pallete.push(util.hexToRgb("#DE6207"));
        }

        // var data = [{
        //     "name": "",
        //     "fillColor" : gui.mainColor,
        //     "value": 400
        // }, {
        //     "name": "",
        //     "fillColor" : "#DE6207",
        //     "value": 100
        // }];
        // var pallete = [
        //     util.hexToRgb(gui.mainColor), util.hexToRgb("#EA9409")
        // ];

        let options = {
            margin: {
                top: 1,
                left: 2,
                bottom: 1,
                right: 2
            },
            width: 148,
            height: 148,
            r: 58,
            R: 73,
            legendPosition: 'topLeft',
            animate: {
                type: 'oneByOne',
                duration: 200,
                fillTransition: 3
            },
            label: {
                fontFamily: gui.fontFamily,
                fontSize: gui.buttonFontSize,
                fontWeight: 'normal'
            }
        };
        let chartTitleBold = `${util.getPriceText(main + bonus)}`;
        let chartTitle = 'Tổng tài khoản';
        return (
            <View>
                <View style={style.viewChartProfile}>
                    <View style={style.viewChartBody}>
                        <MChartView
                            data={data}
                            options={options}
                            pallete={pallete}
                            chartTitle={chartTitle}
                            chartTitleBold={chartTitleBold}
                        />
                    </View>
                    <View style={{paddingLeft: 0, paddingTop:2, marginLeft: 8}}>
                        {this._renderMoneyLine("Tài khoản chính", `${util.getPriceText(main)}`, gui.mainColor)}
                        {this._renderMoneyLine("Tài khoản phụ", `${util.getPriceText(bonus)}`, '#DE6207')}
                    </View>
                </View>
                <Text style={{fontSize: 5}} />
            </View>
        );
    }
    _renderMoneyLine(label, value, dotColor) {
        return (
            <View style={{flexDirection:'row'}}>
                <View style={[style.dot3, {borderColor: dotColor}]}>
                </View>
                <View style={{flexDirection:'column', marginTop: 8, marginBottom: 8}}>
                    <Text style={{fontSize: 15, fontFamily: gui.fontFamily, fontWeight: 'bold'}}>
                        {value}
                    </Text>
                    <Text style={{fontSize: 12, fontFamily: gui.fontFamily, color: '#9C9C9C'}}>
                        {label}
                    </Text>
                </View>
            </View>
        )
    }
    _onGioiTinhPressed(){
        Actions.GioiTinh();
    }
    _onMoiGioiPressed(){
        Actions.MoiGioi();
    }
    _onDoiMatKhauPressed(){
        Actions.ChangePassword();
    }
    _onNgaySinhPressed(){
        let showNgaySinhPicker = this.state.showNgaySinhPicker;
        this.setState({showNgaySinhPicker: !showNgaySinhPicker});
        if (!showNgaySinhPicker)
            this._onScrollNgaySinh();
    }
    _onNgaySinhChange(date){
        let birthDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState( { date: date});
        this.onValueChange('birthDate', birthDate);
    }
    _onScrollNgaySinh() {
        // let  scrollTo = 300;
        // this.refs.scroll.scrollTo({y: scrollTo});
    }

    onValueChange(field, value){
        this.props.actions.onProfileFieldChange(field, value);
    }

    takePicture() {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {
                if (e){
                    Permissions.requestPermission('photo')
                    .then(response => {
                        if (response == 'authorized') {
                            Actions.PostAds({owner: 'profile', onChangeAvatar: this._onChangeAvatar.bind(this)});
                        } else {
                        Alert.alert("Thông báo", gui.INF_PhotoAccess);
                        }
                    });  
                    
                } else {
                    Alert.alert('Thông báo', gui.INF_CameraAccess);
                }
            });
    }
    _getFullName(){
        return this.props.me.profile.fullName;
    }
    _getSoDienThoai(){
        return this.state.phone;
    }
    _getEmail(){
        return this.state.email;
    }
    _getWebsite(){
        return this.props.me.profile.website;
    }
    _getGioiThieu(){
        return this.props.me.profile.gioiThieu;
    }
    _getAvatar(){
        return this.props.me.profile.avatar;
    }
    _getGioiTinh(){
        return DanhMuc.GioiTinh[this.props.me.profile.sex]||'';
    }
    _getNgaySinh(){
        return this.props.me.profile.birthDate ? moment(this.props.me.profile.birthDate).format('DD/MM/YYYY') : '';
    }
    _getDiaChi(){
        return this.props.me.profile.diaChi;
    }
    _getMoiGioi(){
        return DanhMuc.MoiGioi[this.props.me.profile.broker]||'';
    }

    _renderVerifyModal(){
        return (
            <Modal open={this.state.open} style={styles.modalmore} ref={"verifyModal"} position={"center"} swipeToClose={false}>
                <View style={styles.modalContainer}>
                    <View style={[styles.toolbarModalSend, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
                        <TouchableOpacity onPress={()=>this.refs.modalResetPassword.close()} style={styles.modalBack} >
                            <Icon name="angle-left" size={40} color="white" />
                        </TouchableOpacity>
                        <View style={styles.modalViewTitle}>
                            <Text style={styles.modalTextTile}>Cập nhật mật khẩu</Text>
                        </View>
                        <View style={styles.modalTextCan}></View>
                    </View>
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'>
                        <View style={styles.modalBody}>
                            <View style ={styles.viewCapNhat}>
                                <ScalableText style={styles.textXacNhan}>Nhập mật khẩu và mã xác nhận</ScalableText>
                            </View>
                            <TextInput
                                underlineColorAndroid='rgba(0,0,0,0)'
                                autoCorrect={false}
                                returnKeyType='next'
                                style={styles.textInput}
                                placeholder="Mã xác nhận" placeholderTextColor='#adb4b7'
                                onChangeText={(text) => this.setState({verifyCode: (text)})}
                                value={this.state.verifyCode}
                            />
                            <TextInput
                                underlineColorAndroid='rgba(0,0,0,0)'
                                returnKeyType='go'
                                secureTextEntry={true}
                                style={styles.textInput}
                                placeholder="Mật khẩu" placeholderTextColor='#adb4b7'
                                onChangeText={(text) => this.setState({newPassword: (text)})}
                                value={this.state.newPassword}
                            />

                            <TouchableOpacity onPress={() => this._onVerifyChange()} style={styles.actionButton} >
                                <Text style={styles.textActionButton}>Thực hiện</Text>
                            </TouchableOpacity>
                        </View>
                    </KeyboardAwareScrollView>
                </View>
            </Modal>
        )
    }

}
/**
 * ## Styles
 */
var style = StyleSheet.create({
    lineWithIconStyle : {
        borderTopColor: '#ebebeb',
        borderBottomColor: '#ebebeb',
        borderTopWidth: 0.5,
        borderBottomWidth: 0.5,
    },
    container: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'stretch',
        backgroundColor: 'transparent'
    },
    viewScrollBody:{
        flex: 1,
        backgroundColor: 'white'
    },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        top: 0,
        height: 60
    },
    headerTitle: {
        left: 36,
        right: 36,
        marginTop: 30,
        marginBottom: 10,
        position: 'absolute'
    },
    headerTitleText: {
        color: gui.mainTextColor,
        fontSize: 15,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    textButtonChange: {
        textAlign:'right',
        fontWeight: '400',
        fontSize: 15,
        marginTop: 2,
        color: gui.mainColor
    },
    changeButton: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        width: 80,
        right: 0,
        paddingTop: 30,
        paddingBottom: 10,
        paddingRight: 15,
        position: 'absolute',
        paddingLeft: 5
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 15,
        paddingRight: 15
    },
    backButtonText: {
        color: 'white',
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    label: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        paddingRight: 5,
        color: '#8A8A8A'
    },
    normalFont: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#8A8A8A'
    },
    contentGroupTitle: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8',
        // borderTopWidth:0,
        // borderColor:'lightgray'
    },
    contentGroupTitleText: {
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: '#313131',
        justifyContent :'space-between',
        padding: 0,
        fontWeight:"300"
    },
    line: {
        backgroundColor: 'lightgray',
        height: 0.5,
        marginLeft: 15
    },
    fullLine: {
        backgroundColor: 'lightgray',
        height: 0.5
    },
    rowContainer: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: 'white',
        marginTop: 6,
        marginBottom: 6,
        paddingLeft: 15,
    },
    contentLabel: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        justifyContent: 'center',
        fontSize: 15,
        fontWeight: '400',
        fontFamily: gui.fontFamily,
        color: 'black',
        width: 100
    },
    contentText: {
        textAlign: 'left',
        alignItems: 'flex-end',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#8A8A8A',
        marginLeft: 10,
        width: width-165,
        paddingLeft: 5,
        paddingRight: 5,
        marginRight: 10
    },
    rowIconContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: 'white',
        marginTop: 6,
        marginBottom: 6,
        paddingLeft: 15
    },
    arrowIcon: {
        flexDirection: "row",
        alignItems: "flex-end",
        paddingRight: 15
    },
    textFullWidth: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: 'black',
        marginTop: 8,
        marginBottom: 7,
        marginLeft: 0,
        marginRight: 0,
    },
    dot3 : {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 14,
        marginTop: 18,
        backgroundColor: 'white',
        borderWidth: 3.5
    },
    avatarIcon : {
        height: 60,
        width: 60,
        borderRadius: 30
    },
    numberPicture:{
        backgroundColor:'white',
        height:20,
        marginTop:5,
        alignItems:'flex-end',
        justifyContent:'center'
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    viewBorderProfile: {
        borderColor: '#dcdcdc',
        borderWidth: 1,
        height: 28
    },
    viewChartProfile: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor:'white',
        paddingTop: 16,
        paddingBottom: 16

    },
    viewChartBody: {
        paddingLeft: 13,
        paddingTop:2,
        width: width/2,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewModalVerify: {
        width: width,
        height: height
    },
    viewContentModal: {
        width: width,
        height: height,
        backgroundColor: '#fff'
    },
    scrollView: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 48
    },
    viewBackButton: {
        width: width,
        height: 60,
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    touchBackButton: {
        height: 60,
        width: 20,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 22
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 24
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width,
        opacity: 0.8
    },
    viewSendCodeAgain: {
        height: 20,
        width: 80,
        justifyContent: 'center',
        alignItems: 'flex-end',
        position: 'absolute',
        right: 16,
        backgroundColor: '#fff'
    },
    textSendCodeAgain: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontSize: 15
    },
    viewCodeGuide: {
        width: width,
        height: 40,
        paddingLeft: 16,
        paddingRight: 23,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        marginTop: 18
    },
    viewCodeElement: {
        height: 64,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 31, //55
        backgroundColor: '#fff'
    },
    codeInputStyle: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        color: '#526173',
        fontWeight: '500',
        fontFamily: gui.fontFamily
    },
    viewIsFetching: {
        marginTop: 50,
        width: width,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        marginTop: 22,
        marginLeft: 12
    },
    viewSpinLoading: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    }

});
export default connect(mapStateToProps, mapDispatchToProps)(Profile);