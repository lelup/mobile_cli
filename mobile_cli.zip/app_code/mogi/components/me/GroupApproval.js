import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Image
} from 'react-native';

import { Actions } from 'react-native-router-flux';
var Intercom = require('react-native-intercom');
import ScalableText from 'react-native-text';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Map} from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';

import danhMuc from '../../assets/DanhMuc';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
let {width, height} = utils.getDimensions();
import CommonUtils from '../../lib/CommonUtils';
import log from '../../lib/logUtil';
import RelandIcon from '../RelandIcon';

import ImagePreviewChat from '../ImagePreviewChat';

const actions = [
    globalActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
class GroupApproval extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            numOfUnreadSupportMessage: 0,
            modal: false
        }
    }

    componentDidMount() {
        Intercom.addEventListener(Intercom.Notifications.UNREAD_COUNT, this._onUnreadChange);
    }

    componentWillUnmount() {
        Intercom.removeEventListener(Intercom.Notifications.UNREAD_COUNT, this._onUnreadChange);
    }

    _onUnreadChange = ({ count }) => {
        this.setState({numOfUnreadSupportMessage: count});
    }

    render() {
        let data = this.props.data;
        return (
            <View style={styles.container}>
                {this._renderHeaderAds()}
                {this._renderBodyApproval()}
                {this._renderChatSupport()}
                {this.state.modal ? <ImagePreviewChat images={[data.imgUrl]} owner={'alert'} closeModal={() => this.setState({modal: false}) }/> : null }
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>Chi tiết duyệt sàn</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _renderBodyApproval() {
        let data = this.props.data;
        let imageUriHome = {uri: data.imgUrl};
        if (!imageUriHome) {
            imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
        }
        let customData = data.customData;
        return(
            <ScrollView contentContainerStyle={styles.scrollView}
                        style={{flex: 1}}
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
            >
                <TouchableOpacity
                    onPress={this.doImagePress.bind(this)}>
                    <Image style={{width: width, height: height/2 - 68}}
                           source={imageUriHome}
                           resizeMode={'cover'}
                           defaultSource={CommonUtils.getNoCoverImage()}
                    />
                </TouchableOpacity>
                <View style={styles.viewLineAlert}/>
                {this._renderThongTinSan(customData)}
                <View style={styles.viewLineAlert}/>
                {this._renderTrangThai(customData)}
                {this._renderLyDo(customData)}
            </ScrollView>
        );
    }

    doImagePress() {
        if (this.state.modal) {
            return;
        }
        this.setState({
            modal: true
        });
    }

    _renderThongTinSan(data) {
        let tenSan = `Tên sàn: ${data.groupName}` || '';
        let thongTinSan = data.chiTiet || '';
        return(
            <View style={styles.viewThongTin}>
                <View style={styles.viewGiaContent}>
                    <Text style={[styles.textTitle, {fontSize: 18}]}>{tenSan}</Text>
                    <Text style={[styles.textContent, {fontSize: 15}]}>{thongTinSan}</Text>
                </View>
            </View>
        );
    }


    _renderTrangThai(data) {
        let trangThai = 'Trạng thái';
        let ngayDuyet = 'Ngày duyệt';
        let statusFmt = data.statusFmt || '';
        let ngayDuyetDetail = data.ngayDuyet || '';
        let lyDoTuChoi = data.lyDoTuChoi || '';
        if (!statusFmt) {
            if (!lyDoTuChoi) {
                statusFmt = "Đã duyệt";
            } else {
                statusFmt = "Bị từ chối";
            }
        }
        let detailItems = [];
        let index = 0;
        let color = statusFmt == "Đã duyệt" ? gui.mainColor : '#ff0000';
        if (statusFmt) {
            detailItems.push(
                <View key={index++} style={styles.viewEachDay}>
                    <View style={styles.eachTrangThai}>
                        <Text style={styles.textTitle}>{trangThai}</Text>
                    </View>
                    <View style={[styles.eachTrangThai, {alignItems: 'flex-end'}]}>
                        <Text style={[styles.textContent, {color: color}]}>{statusFmt}</Text>
                    </View>
                </View>
            );
        }
        if (ngayDuyetDetail) {
            detailItems.push(
                <View key={index++} style={styles.viewEachDay}>
                    <View style={styles.eachTrangThai}>
                        <Text style={styles.textTitle}>{ngayDuyet}</Text>
                    </View>
                    <View style={[styles.eachTrangThai, {alignItems: 'flex-end'}]}>
                        <Text style={styles.textContent}>{ngayDuyetDetail}</Text>
                    </View>
                </View>
            );
        }
        return(
            <View style={styles.viewTrangThai}>
                {detailItems}
            </View>
        );
    }

    _renderLyDo(data) {
        let lyDoTitle = 'Lý do từ chối';
        if(!data.lyDoTuChoi) {
            return;
        }
        let lyDoContent = data.lyDoTuChoi ? data.lyDoTuChoi : '';
        return(
            <View style={styles.viewLyDo}>
                <FullLine style={{width: width-25, marginBottom: 10}}/>
                <Text style={styles.textTitle}>{lyDoTitle}</Text>
                <Text style={styles.textContent}>{lyDoContent}</Text>
            </View>
        )
    }

    _renderChatSupport() {
        let supportUri = require('../../assets/image/logo.png');
        return (
            <View style={styles.supportChatView}>
                <TouchableOpacity onPress={this._onDisplayMessenger.bind(this)}>
                    <View style={{flexDirection: 'row', width: width, height: 72, backgroundColor: 'transparent',
                        justifyContent: 'flex-start', alignItems: 'center'}}>
                        <View style={styles.supportIconView} >
                            <Image
                                style={styles.supportIcon}
                                resizeMode={Image.resizeMode.cover}
                                source={supportUri}
                            />
                            {this._renderNumOfUnreadSupportMessage()}
                        </View>
                        <View style={{flexDirection: 'column'}}>
                            <ScalableText style={styles.contentTitle}>
                                Chăm sóc khách hàng
                            </ScalableText>
                            <ScalableText style={styles.contentText}>
                                Bạn cần hỗ trợ? Hãy Chat với chúng tôi ở đây
                            </ScalableText>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderNumOfUnreadSupportMessage() {
        if (this.state.numOfUnreadSupportMessage && this.state.numOfUnreadSupportMessage >0 ){
            return (
                <View style={styles.notification}>
                    <Text style={styles.notificationText}>
                        {this.state.numOfUnreadSupportMessage}
                    </Text>
                </View>
            )
        }
    }

    _onDisplayMessenger() {
        try {
            if (!this.props.global.loggedIn) {
                Intercom.reset().then(() => {
                    Intercom.registerUnidentifiedUser()
                        .then(() => {
                            Intercom.displayMessenger();
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            } else {
                let userID = this.props.global.currentUser.userID || undefined;
                let email = this.props.global.currentUser.email || undefined;
                let phone = this.props.global.currentUser.phone || undefined;
                let name = this.props.global.currentUser.username || undefined;
                let fullName = this.props.global.currentUser.fullName || undefined;
                if (fullName) {
                    name = fullName;
                }
                let avatar = this.props.global.currentUser.avatar || undefined;
                Intercom.reset().then(() => {
                    Intercom.registerIdentifiedUser({ userId: userID })
                        .then(() => {
                            log.info('registerIdentifiedUser done');

                            return Intercom.updateUser({
                                email: email,
                                phone: phone,
                                name: name,
                                avatar: { type: 'avatar', image_url: avatar }
                            })
                                .then(() => {
                                    Intercom.displayMessenger();
                                });
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            }

        } catch (error) {
            log.warn('========== onDisplayMessenger ERROR', error);
        }
    }

    _onBackPress() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10
    },
    viewBody: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    scrollView: {
        backgroundColor: '#fff',
        paddingBottom: 78,
    },
    supportChatView: {
        height: 78,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'flex-start',
        borderTopWidth: 1,
        borderColor: '#dcdcdc',
        position:'absolute',
        bottom: 0,
        marginBottom: 0
    },
    supportIconView: {
        height: 40,
        width: 40,
        borderRadius: 20,
        marginRight: 5,
        marginLeft: 8,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor
    },
    supportIcon: {
        height: 8,
        width: 33
    },
    contentTitle: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: '600'
    },
    contentText: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: 'normal',
    },
    notification: {
        position: 'absolute',
        backgroundColor: '#ff0000',
        top: 1,
        right: 1,
        alignSelf: 'auto',
        width: 18,
        height: 18,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center'
    },
    notificationText: {
        fontSize: 10,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#fff',
        textAlign: 'center',
        backgroundColor: 'transparent'
    },
    viewLineAlert: {
        width: width,
        height: 6,
        backgroundColor: '#e3e2e2'
    },
    viewTrangThai: {
        width: width,
        // height: 108,
        backgroundColor: '#fff',
        paddingLeft: 15,
        paddingRight: 10,
        paddingTop: 9,
        paddingBottom: 9
    },
    viewEachDay: {
        width: width - 25,
        height: 30,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    eachTrangThai: {
        width: (width - 25)/2,
        height: 30,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingRight: 8
    },
    viewLyDo: {
        paddingTop: 0,
        paddingBottom: 10,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 15,
        paddingRight: 10
    },
    textTitle: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: "500",
        color: '#464646',
    },
    textContent: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#898989',
    },
    viewGiaContent: {
        justifyContent: 'center',
        alignItems: 'flex-start',
        width: width - 25,
        backgroundColor: '#fff',
        paddingBottom: 9,
        paddingTop: 10
    },
    viewThongTin: {
        width: width,
        backgroundColor: '#fff',
        paddingLeft: 15,
        paddingRight: 10
    },
    textSan: {
        fontSize: 18,
        fontFamily: gui.fontFamily,
        fontWeight: "500",
        color: gui.mainTextColor
    },
    textThongTinSan: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#3f3f3f',
        marginTop: 3
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupApproval);