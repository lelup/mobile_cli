'use strict';

import  React from 'react';

import {View, Text, Navigator, Platform, StyleSheet, PanResponder, Alert} from 'react-native';
import {Schema, Actions} from 'react-native-router-flux';
import gui from '../../lib/gui';
import log from '../../lib/logUtil';

import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Map} from 'immutable';
import ScalableText from 'react-native-text';
import VersionCheck from 'react-native-version-check';

// START: iOS Only
VersionCheck.setAppID('1303128474');                    // Your App ID for App Store URL
VersionCheck.setAppName('landber-agent-moi-gioi-bds');

const actions = [
    globalActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class UpDateTabIcon extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            isNeedUpdate: false
        };
    }

    componentWillMount() {
        // let appVersion = this.props.global.deviceInfo.appVersion || undefined;
        //
        // VersionCheck.getLatestVersion()
        //     .then(latestVersion => {
        //         if(latestVersion != appVersion) {
        //             this.setState({
        //                 isNeedUpdate: true
        //             })
        //         }
        //     });

        VersionCheck.needUpdate()
            .then(res => {
                if (res.isNeeded) {
                    this.setState({
                        isNeedUpdate: true
                    })
                }
            });
    }


    render() {
        let color = this.props.selected ? gui.mainColor : '#8f8f8f';
        let iconName = this.props.selected ? this.props.selectedIconName : this.props.iconName;
        return (
            <View style={styles.tabIcon}>
                <View style={{marginTop: 2}}>
                    <FontAwesomeLight color={color} name={iconName} size={this.props.iconSize} noAction={true} iconOnly={true}/>
                </View>
                <ScalableText style={[styles.tabIconText, {color: color, top: 3}]}>{this.props.title}</ScalableText>
                { this.state.isNeedUpdate ?
                    (<View style={styles.notification}>
                    </View>)
                    : null
                }

            </View>
        );
    }
}

const styles = StyleSheet.create({
    tabIcon: {
        flex:1,
        alignItems:'center',
        alignSelf:'center',
        top: 5
    },

    tabIconText: {
        top: 3,
        fontSize:9,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },

    notification: {
        position: 'absolute',
        backgroundColor: '#ff0000',
        top: -2,
        right: -6,
        alignSelf: 'auto',
        width: 6,
        height: 6,
        borderRadius: 3,
        justifyContent: 'center',
        alignItems: 'center'
    },
    notificationText: {
        fontSize: 10,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#fff',
        textAlign: 'center',
        backgroundColor: 'transparent'
    }

});

export default connect(mapStateToProps, mapDispatchToProps)(UpDateTabIcon);