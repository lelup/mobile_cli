import React, { PropTypes, Component } from 'react';
import {
    Animated,
    ScrollView,
    Text,
    View,
    StyleSheet,
    TouchableOpacity
} from 'react-native';
// import EStyleSheet from 'react-native-extended-stylesheet'
import gui from '../../lib/gui';
import utils from '../../lib/utils';

const {width, height} = utils.getDimensions();

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    scrollView: {
        padding: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    text: {
        marginBottom: 60,
    },
    fixedFooter: {
        backgroundColor: gui.mainColor,
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: 40,
        width: width
    },
    buttonProduct: {
        backgroundColor: 'transparent',
        height: 40,
        width: width,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewChild: {
        width: 150,
        height: 75,
        borderRadius: 5,
        backgroundColor: 'gray',
        marginTop: 20
    },
    textBottom: {
        color: '#fff',
        fontSize: 17,
        fontWeight: '500'
    }
});


export default class AnimatedScroll extends Component {
    // static propTypes = {
    //
    // }

    constructor(props) {
        super(props);
        this.state = {
            scrollY: new Animated.Value(0),
        }
    }

    onScrollMoveFooter(event) {
        const currentOffset = event.nativeEvent.contentOffset.y;
        const direction = currentOffset > this.offset ? 'down' : 'up';
        const distance = this.offset ? (this.offset - currentOffset) : 0;
        const newPosition = this.state.scrollY._value - distance;

        if (currentOffset > 0 && currentOffset < (this.contentHeight - this.scrollViewHeight)) { // Don't react at iOS ScrollView Bounce
            if (direction === 'down') {
                if (this.state.scrollY._value < 50) {
                    this.state.scrollY.setValue(newPosition > 50 ? 50 : newPosition)
                }
            }
            if (direction === 'up') {
                if (this.state.scrollY._value >= 0) {
                    this.state.scrollY.setValue(newPosition < 0 ? 0 : newPosition)
                }
            }
            this.offset = currentOffset
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <ScrollView
                    onContentSizeChange={(w, h) => { this.contentHeight = h }}
                    onLayout={(ev) => { this.scrollViewHeight = ev.nativeEvent.layout.height }}
                    onScroll={this.onScrollMoveFooter.bind(this)}
                    scrollEventThrottle={16}
                    contentContainerStyle={styles.scrollView}
                >
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>
                    <View style={styles.viewChild}></View>

                </ScrollView>
                <Animated.View
                    style={[
                        styles.fixedFooter,
                        { transform: [{ translateY: this.state.scrollY }] },
                    ]}
                >
                    <TouchableOpacity style={styles.buttonProduct}>
                        <Text style={styles.textBottom}>BUY PRODUCT</Text>
                    </TouchableOpacity>
                </Animated.View>
            </View>
        )
    }
}