'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as authActions from '../../reducers/auth/authActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as eventActions from '../../reducers/event/eventActions';
import * as registerActions from '../../reducers/register/registerActions';
const FBSDK = require('react-native-fbsdk');
const {
    LoginManager,
    AccessToken,
    GraphRequest,
    GraphRequestManager,
} = FBSDK;
import {Map} from 'immutable';

import React, { Component} from 'react';
import { Text, View, StyleSheet, TouchableOpacity, PixelRatio,
         Image, ScrollView, StatusBar, Alert, Keyboard, Linking} from 'react-native';

//import ImagePicker from 'react-native-image-picker';

import ScalableText from 'react-native-text';

import utils from '../../lib/utils';
const {height, width} = utils.getDimensions();

import {Actions} from 'react-native-router-flux';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import cfg from '../../cfg';

import VersionCheck from 'react-native-version-check';

import dismissKeyboard from 'react-native-dismiss-keyboard';

// START: iOS Only
VersionCheck.setAppID('1303128474');                    // Your App ID for App Store URL
VersionCheck.setAppName('landber-agent-moi-gioi-bds');

var Analytics = require('react-native-firebase-analytics');

const actions = [
    globalActions,
    meActions,
    authActions,
    searchActions,
    adsMgmtActions,
    chatActions,
    groupActions,
    registerActions,
    eventActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MMeContent extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        this.state = {
            avatarSource: null,
            videoSource: null,
            isNeedUpdate: false
        };
    }

    componentWillMount() {
        // let appVersion = this.props.global.deviceInfo.appVersion || undefined;
        //
        // VersionCheck.getLatestVersion()
        //     .then(latestVersion => {
        //         if(latestVersion != appVersion) {
        //             this.setState({
        //                 isNeedUpdate: true
        //             })
        //         }
        //     });

        VersionCheck.needUpdate()
            .then(res => {
                if (res.isNeeded) {
                    this.setState({
                        isNeedUpdate: true
                    })
                }
            });
    }

    selectPhotoTapped() {
        /*const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            storageOptions: {
                skipBackup: true
            }
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled photo picker');
            }
            else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            }
            else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            }
            else {
                let source = { uri: response.uri };

                // You can also display the image using data:
                // let source = { uri: 'data:image/jpeg;base64,' + response.data };

                this.setState({
                    avatarSource: source
                });
            }
        });*/
    }

    _onProfile() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({doFinalAction: () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
            }});
        } else {
            let currentUser = this.props.global.currentUser;
            this.props.actions.profile(currentUser.userID, currentUser.token).then(
                (res) => {
                    if (res.success) {
                        Actions.Profile();
                    } else {
                        Alert.alert('Thông báo', 'Tải thông tin cá nhân không thành công.');
                    }
                }
            );
        }
    }

    // _onLogout() {
    //     if (!this.props.global.loggedIn) {
    //         Actions.Login();
    //     } else {
    //         this.props.actions.logout(this.props.global.currentUser);
    //     }
    // }
    //
    // _onTopup() {
    //     Actions.Topup();
    // }

    _onSetting(){
        Actions.Setting();
    }

    _onNapTien(){
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({doFinalAction: () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
                this._onPressNapTien();
            }});
        } else {
            this._onPressNapTien();
        }
    }

    _onPressNapTien() {
        let currentUser = this.props.global.currentUser;
        this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
            (res) => {
                if (res.status == 0) {
                    Actions.MoneyInPayment();
                } else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        );
    }


    _renderSavedSearch() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
                this._onSavedSearch();
            }});
        } else {
            this._onSavedSearch();
        }
    }

    _onSavedSearch() {
        Actions.SavedSearch();
    }

    _onAdsSavedMgmt() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
                this._onPressSavedMgmt();
            }});
        } else {
            this._onPressSavedMgmt();
        }
    }

    _onPressSavedMgmt() {
        Actions.AdsMgmt2();
    }

    _onPostAdsSaved() {
        if(!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction: () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
                this._onPressPostAds();
            }});
        } else {
            this._onPressPostAds();
        }
    }

    _onPressPostAds() {
        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        let token = this.props.global.currentUser.token;
        this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);

        let listScrollPos = {...this.props.adsMgmt.listScrollPos};
        let listScrollKey = Object.keys(listScrollPos);
        listScrollKey.forEach((key) => {listScrollPos[key] = 0});
        this.props.actions.onAdsMgmtFieldChange('listScrollPos', listScrollPos);

        Actions.AdsMgmt();
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderAvatar()}
                <ScrollView
                    style={styles.viewScrollMe}
                >
                    {this._renderDetail()}
                    {this._renderHelpSetting()}
                    <View style={styles.viewBottomScroll}></View>
                </ScrollView>
            </View>
        );
    }

    _renderAvatar() {
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = this.props.global.currentUser.avatar ? {uri: this.props.global.currentUser.avatar} :
            defaultAvatar;

        return (
            <TouchableOpacity style={styles.viewAvatar}
                              onPress={this._onProfile.bind(this)}
            >
                <View style={styles.viewPersonal}>
                    <ScalableText style={styles.textPersonal}>Cá nhân</ScalableText>
                </View>
                <View style={styles.touchBodyAvatar}>
                    <View style={[styles.avatar, styles.avatarContainer]}>
                        <Image style={styles.avatar} source={avatarUri}
                                defaultSource={defaultAvatar} />
                        {/* this.state.avatarSource === null ? <Text>Select a Photo</Text> :
                            <Image style={styles.avatar} source={this.state.avatarSource} />
                        */}
                    </View>
                    <View style={styles.viewContact}>
                        <ScalableText style={styles.textName}>{this.props.global.currentUser.fullName||''}</ScalableText>
                        <ScalableText style={styles.textPhoneNumber}>{this.props.global.currentUser.username||''}</ScalableText>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _renderDetail() {
        return(
            <View style={styles.viewDetail}>
                {this._renderSearch()}
                {this._renderLuuTin()}
                {this._renderDuAnLuu()}
                {this._renderDangTin()}
                {this._renderLichSu()}
                {this._renderService()}
            </View>
        );
    }

    _renderHelpSetting() {
        return(
            <View style={styles.viewHelpSetting}>
                {/*this._renderXacThucSoDo()*/}
                {/*this._renderLine()*/}
                {this._renderNapTien()}
                {this._renderLine()}
                {this._renderSetting()}
                {this._renderLine()}
                {this._renderHelped()}
                {this._renderLine()}
                {this._renderLogout()}
            </View>
        );
    }

    _renderSearch() {
        return (
            <TouchableOpacity style={[styles.viewTimKiem, {backgroundColor:'#fdc66c'}]}
                              onPress={this._renderSavedSearch.bind(this)}
            >
                {/*<View style={styles.viewUserNote}>
                    <Text style={styles.textUserNote}>1</Text>
                </View>*/}
                <Image
                    style={styles.imageStyle}
                    source={require('../../assets/image/me/1.png')}
                    defaultSource={require('../../assets/image/me/1.png')}
                />
                <View style={styles.viewSearchBottom}>
                    <ScalableText style={styles.textBottom}>Tìm kiếm đã lưu</ScalableText>
                </View>
            </TouchableOpacity>
        );
    }

    _renderDangTin() {
        return (
            <TouchableOpacity style={[styles.viewTimKiem, {backgroundColor:'#78c7a7'}]}
                              onPress={this._onPostAdsSaved.bind(this)}
            >
                <Image
                    style={styles.imageStyle}
                    source={require('../../assets/image/me/4.png')}
                    defaultSource={require('../../assets/image/me/4.png')}
                />
                <View style={[styles.viewSearchBottom, {backgroundColor:'#eaf5ef'}]}>
                    <ScalableText style={styles.textBottom}>Tin đăng</ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
    _renderLuuTin() {
        return (
            <TouchableOpacity style={[styles.viewTimKiem, { backgroundColor: '#36beaa'}]}
                              onPress={this._onAdsSavedMgmt.bind(this)}
            >
                <Image
                    style={styles.imageStyle}
                    source={require('../../assets/image/me/2.png')}
                    defaultSource={require('../../assets/image/me/2.png')}
                />
                <View style={[styles.viewSearchBottom, {backgroundColor:'#e3f3f0'}]}>
                    <ScalableText style={styles.textBottom}>Tin đã lưu</ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
    _renderLichSu() {
        return (
            <TouchableOpacity style={[styles.viewTimKiem, {backgroundColor: '#f89979'}]}
                              onPress={this._renderHistory.bind(this)}
            >
                {<View style={styles.viewSearchTop}>
                    {/*<ScalableText style={[styles.textBottom, {color: 'rgba(255,0,0,0.65)', fontSize: 12}]}>Coming soon!</ScalableText>*/}
                </View>}
                <Image
                    style={styles.imageStyle}
                    source={require('../../assets/image/me/5.png')}
                    defaultSource={require('../../assets/image/me/5.png')}
                />
                <View style={[styles.viewSearchBottom, {backgroundColor:'#fef0e7'}]}>
                    <ScalableText style={styles.textBottom}>Lịch sử giao dịch</ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
    _renderDuAnLuu() {
        return (
            <TouchableOpacity style={[styles.viewTimKiem, { backgroundColor: '#85c7ea'}]}
                              onPress={this._renderAdsSendCheck.bind(this)}
                              //   onPress = {() => Actions.DetailDuAn()}
            >
                {/*<View style={[styles.viewUserNote, {width: 28 }]}>
                    <Text style={styles.textUserNote}>15</Text>
                </View>*/}
                <View style={styles.viewSearchTop}>
                    {/*<ScalableText style={[styles.textBottom, {color: 'rgba(255,0,0,0.65)', fontSize: 12}]}>Coming soon!</ScalableText>*/}
                </View>
                <Image
                    style={styles.imageStyle}
                    source={require('../../assets/image/me/3.png')}
                    defaultSource={require('../../assets/image/me/3.png')}
                />
                <View style={[styles.viewSearchBottom, {backgroundColor: '#ecf5fc'}]}>
                    <ScalableText style={styles.textBottom}>Tin đã gửi</ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
    _renderService() {
        return (
            <TouchableOpacity style={[styles.viewTimKiem, { backgroundColor: '#6f7aba'}]}
                              // onPress={this._renderMyAlert.bind(this)}
                              // onPress={this._renderNewLogin.bind(this)}
                              // onPress={this._renderMyInbox.bind(this)}
                              onPress={this._renderAgentHome.bind(this)}
            >
                {/*<View style={styles.viewSearchTop}>*/}
                    {/*<ScalableText style={[styles.textBottom, {color: 'rgba(255,0,0,0.65)', fontSize: 12}]}>Coming soon!</ScalableText>*/}
                {/*</View>*/}
                {/*this._renderRedNotification()*/}
                <Image
                    style={styles.imageStyle}
                    source={require('../../assets/image/me/6.png')}
                    defaultSource={require('../../assets/image/me/6.png')}
                />
                <View style={[styles.viewSearchBottom, {backgroundColor:'#e3e5f2', flexDirection: 'row'}]}>
                    {this._renderDotNotification()}
                    <ScalableText style={styles.textBottom}>Chat</ScalableText>
                </View>
            </TouchableOpacity>
        );
    }

    _renderRedNotification() {
        return(
            <View style={styles.viewUserNote}>
                <Text style={styles.textUserNote}>new</Text>
            </View>
        );
    }

    _renderDotNotification() {
        let myNotifyList = this.props.me.myNotifyList;
        let unReadNotification = myNotifyList.filter((val) => {
                return val.status == 1;
            }
        );
        let unReadLength = unReadNotification.length;
        let readNotificaton = this.props.me.pushMessage;
        if(readNotificaton == 1 || unReadLength >= 1 ){
            return(
                    <View style={[styles.viewDotAlert,{backgroundColor: '#ff0000', marginRight: 8}]}/>
            )
        } else return null;
    }

    _renderHelped() {
        return(
            <TouchableOpacity style={styles.viewHelped}
                              onPress={this._onHelpMenuPressed.bind(this)}
            >
                <Image
                    style={[styles.imageHelp]}
                    source={require('../../assets/image/me/trogiup.png')}
                    defaultSource={require('../../assets/image/me/trogiup.png')}
                />
                <ScalableText style={styles.textHelped}>Báo giá, chỉ dẫn nạp tiền</ScalableText>
            </TouchableOpacity>
        );
    }

    _onHelpMenuPressed() {
        let link = cfg.serverUrl + "/bao-gia";
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }

    _renderLogout() {
        let imageSource = this.props.global.loggedIn ? require('../../assets/image/me/me_logout.png') : require('../../assets/image/me/me_login.png');
        return(
            <TouchableOpacity style={styles.viewHelped}
                              onPress={this._onLogoutPress.bind(this)}
            >
                <Image
                    style={[styles.imageHelp]}
                    source={imageSource}
                    defaultSource={imageSource}
                />
                <ScalableText style={styles.textHelped}>{this.props.global.loggedIn ? "Đăng xuất" : "Đăng nhập"}</ScalableText>
            </TouchableOpacity>
        );
    }

    _renderLine() {
        return(
            <View style={styles.viewLine}></View>
        );
    }

    _renderSetting() {
        return (
            <TouchableOpacity style={styles.viewHelped} onPress={this._onSetting}>
                <Image
                    style={[styles.imageHelp]}
                    source={require('../../assets/image/me/caidat.png')}
                    defaultSource={require('../../assets/image/me/caidat.png')}
                />
                <ScalableText style={styles.textHelped}>Cài đặt</ScalableText>
                {this._renderDotUpdate()}
            </TouchableOpacity>
        );
    }

    _renderDotUpdate() {
        if (this.state.isNeedUpdate) {
            return (
                <View style={[styles.viewDotAlert, {backgroundColor: '#ff0000', marginLeft: 18}]}/>
            )
        } else return null;
    }

    _renderNapTien() {
        return(
            <TouchableOpacity style={styles.viewHelped} onPress={this._onNapTien.bind(this)}>
                <Image
                    style={styles.imageHelp2}
                    source={require('../../assets/image/me/me_coins.png')}
                    defaultSource={require('../../assets/image/me/me_coins.png')}
                />
                <ScalableText style={[styles.textHelped,{marginLeft: 16}]}>Nạp tiền</ScalableText>
            </TouchableOpacity>
        );
    }

    _renderXacThucSoDo() {
        return(
            <TouchableOpacity style={styles.viewHelped} onPress={this._onXacThucSoDo.bind(this)}>
                <Image
                    style={styles.imageHelp2}
                    source={require('../../assets/image/me/certificate_of_land.png')}
                    defaultSource={require('../../assets/image/me/certificate_of_land.png')}
                />
                <ScalableText style={[styles.textHelped,{marginLeft: 16}]}>Xác minh sổ đỏ</ScalableText>
            </TouchableOpacity>
        );
    }

    _onXacThucSoDo() {
        let link = cfg.serverUrl + "/xac-thuc-so-do";
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }

    _renderMyAlert() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
                this._onMyAlert();
            }});
        } else {
            this._onMyAlert();
        }
    }

    _renderMyInbox() {
        Actions.Inbox();
    }

    _renderAgentHome() {
        // this.props.actions.onEventFieldChange('eventList', [])
        this.props.actions.getAllCalendarEvent(
            { 'userID': this.props.global.currentUser.userID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
            }
            , (error) => {
                console.log('server respond data: =====>>>>>', error)                
            });
        Actions.AgentHome();
    }

    _renderNewLogin() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
               this._renderchatGroup();
            }});
        } else {
            this._renderchatGroup();
        }
    }

    _renderchatGroup() {
        Actions.WelcomeLandber();
        let partner = {
            avatar: "https://s3-ap-southeast-1.amazonaws.com/dev.landber/7c562f05-a770-41e4-a4dc-119e17dbf2c4.JPEG",
            email: "bachtv.vnu@gmail.com",
            fullName: "Bach Tran",
            userID: "User_506"
        };
        let relatedToAds = {
            adsID: "Ads_00_648",
            cover: "https://s3-ap-southeast-1.amazonaws.com/dev.landber/ee2a6caf-d68d-44d3-8134-598dc4adfe9a.jpg",
            dangBoi: {
                email: "bachtv.vnu@gmail.com",
                name: "Bach Tran",
                userID: "User_506"
            },
            image: {
                cover: "https://s3-ap-southeast-1.amazonaws.com/dev.landber/ee2a6caf-d68d-44d3-8134-598dc4adfe9a.jpg"
            },
            loaiNhaDat: 2,
            loaiNhaDatFmt: "Nhà riêng",
            loaiTin: 0,
            timestamp: 1504608022403
        };
        this.props.actions.startChat(this.props.global.currentUser,
            partner,
            relatedToAds). then ((e) => {
            Actions.GroupChat();
        });

    }

    _onMyAlert() {
        this.props.actions.getMyNotify(this.props.global.currentUser.userID);
        this.props.actions.onNotificationFieldChange('pushMessage',0);
        Actions.MyAlert();
    }

    _renderHistory(){
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
                this._onCoinHistory();
            }});
        } else {
            this._onCoinHistory();
        }
    }

     _renderAdsSendCheck () {
         if (!this.props.global.loggedIn) {
             Actions.NewLogin({ doFinalAction : () => {
                 this.props.actions.onRerenderHomeChange(true);
                 this.props.actions.onRerenderSearchChange(true);
                 this._renderAdsSended();
             }});
         } else {
             this._renderAdsSended();
         }
     }

    _renderAdsSended () {
        this.props.actions.getMyWTS({userID: this.props.global.currentUser.userID},
            this.props.global.currentUser.token)
            .then(
                (e) => {
                    Actions.popTo("root");
                    Actions.AdsSended();
                });
    }

    // _renderDuAnContent(){
    //     Actions.MeDuAn();
    // }

    _onCoinHistory() {
        this.props.actions.getTopupLog(this.props.global.currentUser.userID, this.props.global.currentUser.token);
        Actions.CoinHistory();
    }

    _onLogoutPress() {
        LoginManager.logOut();
        if(this.props.global.loggedIn) {
            Alert.alert('Đăng xuất', 'Bạn có muốn đăng xuất không?',
                [{text: 'Hủy', onPress: () => log.info('Cancel Pressed!')},
                    {text: 'Đồng ý', onPress: () => this._onLogout()}
                ]);
        } else {
            Actions.NewLogin({doFinalAction: () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
            }});
        }

    }

    _onLogout() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({doFinalAction: () => {
                this.props.actions.onRerenderHomeChange(true);
                this.props.actions.onRerenderSearchChange(true);
            }});
        } else {
            this.props.actions.logout(this.props.global.currentUser);
            LoginManager.logOut();
            this.props.actions.onRegisterFieldChange('fbToken', '');
            this.props.actions.onRerenderHomeChange(true);
            this.props.actions.onRerenderSearchChange(true);
            dismissKeyboard();
            let {deviceID} = this.props.global.deviceInfo;
            if (deviceID) {

                const eventName = "af_logout";
                const eventValues = {
                    "af_success": "true",
                    "af_customer_user_id": deviceID
                };

                Analytics.logEvent('logout', {
                    'userID': deviceID
                });
            }
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: 'transparent'
    },
    viewScrollMe: {
        flex: 1
    },
    viewAvatar: {
        //flex: 0.55,
        backgroundColor: '#1ea7de',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 15,
        paddingTop: 10,
        height: 226,
        width: width
    },
    viewDetail: {
        flex: 5,
        backgroundColor: '#fff',
        flexWrap: 'wrap',
        flexDirection: 'row'
    },
    viewHelpSetting: {
        flex: 2,
        backgroundColor: '#fff'
    },
    avatarContainer: {
        borderColor: '#fff',
        borderWidth: 1 / PixelRatio.get(),
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 15,
        marginBottom: 5
    },
    avatar: {
        borderRadius: 50,
        width: 100,
        height: 100
    },
    viewPersonal:{
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 40,
        height: 40,
        paddingTop: 22,
        width: width
    },
    textPersonal: {
        fontSize: 17,
        color: '#fff',
        marginBottom: 15,
        fontWeight: '700'
    },
    touchBodyAvatar: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewContact: {
        justifyContent:'center',
        alignItems: 'center',
        marginTop: 8,
        paddingBottom: 12,
        width: width
    },
    textName: {
        fontSize: 17,
        color: '#fff',
        fontWeight: '700'
    },
    textPhoneNumber: {
        fontSize: 17,
        color: '#fff',
        marginBottom: 15,
        fontWeight: '400'
    },
    viewTimKiem: {
        width: width/3 -10,
        height: 150,
        marginTop: 8,
        marginLeft: 8,
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewSearch: {
        width: width/3 -10,
        height: 150,
        marginTop: 8,
        marginLeft: 8,
        borderRadius: 5,
        backgroundColor: '#fdc66c'
    },
    imageStyle:{
        transform: [
            {scaleX: 0.7},
            {scaleY: 0.7}
        ],
        // width: 86,
        // height: 86,
        marginBottom: 20,
        backgroundColor:'transparent'

    },
    imageHelp: {
        transform: [
            {scaleX: 0.7},
            {scaleY: 0.7}
        ],
        marginLeft: 12
    },
    imageHelpUpDate: {
        transform: [
            {scaleX: 0.66},
            {scaleY: 0.66}
        ],
        marginLeft: 8
    },
    imageHelp2: {
        transform: [
            {scaleX: 0.8},
            {scaleY: 0.8}
        ],
        marginLeft: 12
    },
    viewHelped: {
        width: width,
        height: 50,
        backgroundColor: 'transparent',
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewUserNote: {
        width: 38,
        height: 20,
        borderRadius: 8,
        backgroundColor: '#ee4035',
        position: 'absolute',
        right: 4,
        top: 4,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textUserNote: {
        fontSize: 15,
        color: '#fff',
        fontWeight: '700'
    },
    viewSearchBottom: {
        backgroundColor: '#fef7e7',
        position: 'absolute',
        bottom: 0,
        width: width/3 -10,
        height: 30,
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    },
    viewSearchTop: {
        backgroundColor: 'transparent',
        position: 'absolute',
        top: 0,
        width: width/3 -10,
        height: 30,
        borderRadius: 5,
        paddingTop: 2,
        alignItems: 'center',
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0
    },
    textBottom: {
        fontSize: 15,
        color: '#000',
        fontWeight: '600'
    },
    textHelped :{
        fontSize: 17,
        color: '#000',
        fontWeight: '600',
        marginLeft: 18
    },
    viewLine: {
        borderTopWidth: 0.5,
        height:1,
        borderColor: "lightgray",
        marginLeft : 56
    },
    viewBottomScroll: {
        width: width,
        height: 45,
        backgroundColor: 'transparent'
    },
    viewDotAlert: {
        width: 12,
        height: 12,
        borderRadius: 6
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(MMeContent);