import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Image,
    Linking
} from 'react-native';


import moment from 'moment';

import {Map} from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import { Actions } from 'react-native-router-flux';

import GiftedSpinner from 'react-native-gifted-spinner';

import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
let {width, height} = utils.getDimensions();
import CommonUtils from '../../lib/CommonUtils';
import log from '../../lib/logUtil';

import ImagePreviewChat from '../ImagePreviewChat';

const actions = [
    globalActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class AlertMarketing extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            modal: false
        }
    }

    render() {
        let headerMarketing = this._getHeaderMarketing();
        let data = this.props.data;
        return (
            <View style={styles.container}>
                {this._renderHeaderAds(headerMarketing)}
                {this._renderBodyMarketing(headerMarketing)}
                {this.state.modal ? <ImagePreviewChat images={[data.imgUrl]} owner={'alert'} closeModal={() => this.setState({modal: false}) }/> : null }
            </View>
        );
    }

    _renderHeaderAds(headerMarketing) {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text numberOfLines={2} style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>Chi tiết thông báo</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _getHeaderMarketing() {
        let data = this.props.data;
        let headerMarketing = data && data.header.replaceAll('<b>','');
        return headerMarketing && headerMarketing.length > 120 ? headerMarketing.substring(0, 45) + "..." : headerMarketing;
    }

    _renderBodyMarketing(headerMarketing) {
        let data = this.props.data;
        let imageUriHome = {uri: data.imgUrl};
        if (!imageUriHome) {
            imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
        }
        let contentMarketing =  data.content.replaceAll('<b>','');
        return(
            <ScrollView contentContainerStyle={styles.scrollView}
                        style={{flex: 1}}
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
            >   
            {data.imgUrl ? 
                <TouchableOpacity
                    onPress={this.doImagePress.bind(this)}>
                    <Image style={{width: width, height: height/2 - 64}}
                           source={imageUriHome}
                           resizeMode={'cover'}
                           defaultSource={CommonUtils.getNoCoverImage()}
                    />
                </TouchableOpacity>
                : null }
                <View style={styles.viewTextContent}>
                    <Text style={styles.titleTop}>{headerMarketing}</Text>
                    <FullLine style={{marginTop: 10}}/>
                    <Text style={styles.textContent}>{contentMarketing}</Text>
                </View>
                <View style={styles.moreButton}>
                    {/* {this._renderMoreButton()} */}
                </View>
            </ScrollView>
        );
    }

    doImagePress() {
        if (this.state.modal) {
            return;
        }
        this.setState({
            modal: true
        });
    }

    _renderMoreButton() {
        return(
            <TouchableOpacity style={styles.touchButton}
                              onPress={() => this._onPressMoreMarketing()}
            >
                <Text style={styles.textButton}>Xem thêm</Text>
            </TouchableOpacity>
        );
    }

    _onPressMoreMarketing() {
        let data = this.props.data;
        let link = data && data.link;
        if (link) {
            Linking.canOpenURL(link).then(supported => {
                if (!supported) {
                    log.info('Can\'t handle url: ' + link);
                } else {
                    Linking.openURL(link);
                }
            }).catch(err => log.error('An error occurred', link, err));
        }
    }

    _onBackPress() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10
    },
    viewBody: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: '#fff'
    },
    scrollView: {
        backgroundColor: '#fff',
        paddingBottom: 49,
    },
    viewTextContent: {
        backgroundColor: 'transparent',
        paddingLeft: 15,
        paddingRight: 10,
        overflow:'hidden',
        width: width,
        marginTop: 10,
        marginBottom: 8
    },
    titleTop : {
        color   :'#000',
        fontSize: 18,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0,
        marginTop: 0
    },
    textContent: {
        color   :'#464646',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginTop: 10
    },
    moreButton: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginBottom: 10
    },
    touchButton: {
        width: 145,
        height: 38,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: gui.mainColor,
        marginTop: 18,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textButton: {
        color   : gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(AlertMarketing);