import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Image
} from 'react-native';

import { Actions } from 'react-native-router-flux';
var Intercom = require('react-native-intercom');
import ScalableText from 'react-native-text';

import {Map} from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';

import danhMuc from '../../assets/DanhMuc';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
let {width, height} = utils.getDimensions();
import CommonUtils from '../../lib/CommonUtils';
import log from '../../lib/logUtil';
import RelandIcon from '../RelandIcon';

import ImagePreviewChat from '../ImagePreviewChat';

const actions = [
    globalActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
class AlertApproval extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            numOfUnreadSupportMessage: 0,
            modal: false
        }
    }

    componentDidMount() {
        Intercom.addEventListener(Intercom.Notifications.UNREAD_COUNT, this._onUnreadChange);
    }

    componentWillUnmount() {
        Intercom.removeEventListener(Intercom.Notifications.UNREAD_COUNT, this._onUnreadChange);
    }

    _onUnreadChange = ({ count }) => {
        this.setState({numOfUnreadSupportMessage: count});
    }

    render() {
        let data = this.props.data;
        return (
            <View style={styles.container}>
                {this._renderHeaderAds()}
                {this._renderBodyApproval()}
                {this._renderChatSupport()}
                {this.state.modal ? <ImagePreviewChat images={[data.imgUrl]} owner={'alert'} closeModal={() => this.setState({modal: false}) }/> : null }
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>Chi tiết duyệt tin</Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _renderBodyApproval() {
        let data = this.props.data;
        let imageUriHome = {uri: data.imgUrl};
        if (!imageUriHome) {
            imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
        }
        let customData = data.customData;
        return(
            <ScrollView contentContainerStyle={styles.scrollView}
                        style={{flex: 1}}
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
            >
                <TouchableOpacity
                    onPress={this.doImagePress.bind(this)}>
                    <Image style={{width: width, height: height/2 - 68}}
                           source={imageUriHome}
                           resizeMode={'cover'}
                           defaultSource={CommonUtils.getNoCoverImage()}
                    />
                </TouchableOpacity>
                {this._renderThongTinAds(customData)}
                <View style={styles.viewLineAlert}/>
                {this._renderTrangThai(customData)}
                {this._renderLyDo(customData)}
            </ScrollView>
        );
    }

    doImagePress() {
        if (this.state.modal) {
            return;
        }
        this.setState({
            modal: true
        });
    }

    _renderThongTinAds(data) {
        if (!data) {
            return null;
        }
        let gia = data.giaFmt || '';
        let diaChi = data.diaChi || '';
        let dienTich = data.dienTichFmt || '';
        let phongTam = data.soPhongTam || '';
        let phongNgu = data.soPhongNgu || '';
        let soTang = data.soTang || '';
        let huongNha = data.huongNha || '';
        let showChiTiet = dienTich && dienTich != danhMuc.KHONG_RO ||
            phongTam && phongTam != danhMuc.KHONG_RO ||
            phongNgu && phongNgu != danhMuc.KHONG_RO ||
            soTang && soTang != danhMuc.KHONG_RO ||
            huongNha && huongNha != danhMuc.KHONG_RO;
        return(
            <View style={styles.viewThongTin}>
                <View style={styles.viewGiaContent}>
                    <Text style={styles.textGia}>{gia}</Text>
                    <Text style={styles.textDiaChi}>{diaChi}</Text>
                </View>
                {showChiTiet ? <View>
                    <FullLine />
                    <View style={styles.viewSoPhongNgu}>
                        <ScrollView horizontal={true} contentContainerStyle={styles.detailScrollView}>
                            {this._renderDetailIcon('acreage-b', dienTich)}
                            {this._renderDetailIcon('bath-b', phongTam)}
                            {this._renderDetailIcon('bed-b', phongNgu)}
                            {this._renderDetailIcon('building-b', soTang)}
                            {this._renderDetailIcon('direction', huongNha)}
                        </ScrollView>
                    </View>
                </View> : null}
            </View>
        )

    }

    _renderDetailIcon(name, title, textStyle) {
        if(title && title != danhMuc.KHONG_RO) {
            return(
                <View style={[styles.viewDienTich, textStyle]}>
                    <RelandIcon name={name} color="#353535" size={19}
                                mainProps={{paddingLeft: 0, paddingRight: 0, marginTop: 12}}
                                noAction={true}
                    />
                    <Text style={[styles.textDiaChi, {marginLeft: 5}]}>{title}</Text>
                </View>
            );
        }
    }

    _renderTrangThai(data) {
        if (!data) {
            return null;
        }
        let trangThai = 'Trạng thái';
        let ngayDuyet = 'Ngày duyệt';
        let ngayDang = 'Ngày đăng';
        let ngayHetHan = 'Ngày hết hạn';
        let status = data.status;
        let statusFmt = data.statusFmt || '';
        let ngayDuyetDetail = data.ngayDuyet || '';
        let thoiGianDangTu = data.thoiGianDangTu || '';
        let thoiGianDangDen = data.thoiGianDangDen || '';
        let lyDoTuChoi = data.lyDoTuChoi || '';
        if (!statusFmt) {
            if (!lyDoTuChoi) {
                status = 2;
                statusFmt = "Đã duyệt";
            } else {
                status = 3;
                statusFmt = "Bị từ chối";
            }
        }
        let detailItems = [];
        let index = 0;
        let color = statusFmt == "Đã duyệt" ? gui.mainColor : '#ff0000';
        if (statusFmt) {
            detailItems.push(
                <View key={index++} style={styles.viewEachDay}>
                    <View style={styles.eachTrangThai}>
                        <Text style={styles.textTitle}>{trangThai}</Text>
                    </View>
                    <View style={[styles.eachTrangThai, {alignItems: 'flex-end'}]}>
                        <Text style={[styles.textContent, {color: color}]}>{statusFmt}</Text>
                    </View>
                </View>
            );
        }
        if (ngayDuyetDetail) {
            detailItems.push(
                <View key={index++} style={styles.viewEachDay}>
                    <View style={styles.eachTrangThai}>
                        <Text style={styles.textTitle}>{ngayDuyet}</Text>
                    </View>
                    <View style={[styles.eachTrangThai, {alignItems: 'flex-end'}]}>
                        <Text style={styles.textContent}>{ngayDuyetDetail}</Text>
                    </View>
                </View>
            );
        }
        if (thoiGianDangTu) {
            detailItems.push(
                <View key={index++} style={styles.viewEachDay}>
                    <View style={styles.eachTrangThai}>
                        <Text style={styles.textTitle}>{ngayDang}</Text>
                    </View>
                    <View style={[styles.eachTrangThai, {alignItems: 'flex-end'}]}>
                        <Text style={styles.textContent}>{thoiGianDangTu}</Text>
                    </View>
                </View>
            );
        }
        if (status == 2) {
            detailItems.push(
                <View key={index++} style={styles.viewEachDay}>
                    <View style={styles.eachTrangThai}>
                        <Text style={styles.textTitle}>{ngayHetHan}</Text>
                    </View>
                    <View style={[styles.eachTrangThai, {alignItems: 'flex-end'}]}>
                        <Text style={styles.textContent}>{thoiGianDangDen}</Text>
                    </View>
                </View>
            );
        }
        return(
            <View style={styles.viewTrangThai}>
                {detailItems}
            </View>
        );
    }

    _renderLyDo(data) {
        if (!data) {
            return null;
        }
        let lyDoTitle = 'Lý do từ chối';
        if(!data.lyDoTuChoi) {
            return null;
        }
        let lyDoContent = data.lyDoTuChoi ? data.lyDoTuChoi : '';
        return(
            <View style={styles.viewLyDo}>
                <FullLine style={{width: width-25, marginBottom: 10}}/>
                <Text style={styles.textTitle}>{lyDoTitle}</Text>
                <Text style={styles.textContent}>{lyDoContent}</Text>
            </View>
        )
    }

    _renderChatSupport() {
        let supportUri = require('../../assets/image/logo.png');
        return (
            <View style={styles.supportChatView}>
                <TouchableOpacity onPress={this._onDisplayMessenger.bind(this)}>
                    <View style={{flexDirection: 'row', width: width, height: 72, backgroundColor: 'transparent',
                        justifyContent: 'flex-start', alignItems: 'center'}}>
                        <View style={styles.supportIconView} >
                            <Image
                                style={styles.supportIcon}
                                resizeMode={Image.resizeMode.cover}
                                source={supportUri}
                            />
                            {this._renderNumOfUnreadSupportMessage()}
                        </View>
                        <View style={{flexDirection: 'column'}}>
                            <ScalableText style={styles.contentTitle}>
                                Chăm sóc khách hàng
                            </ScalableText>
                            <ScalableText style={styles.contentText}>
                                Bạn cần hỗ trợ? Hãy Chat với chúng tôi ở đây
                            </ScalableText>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderNumOfUnreadSupportMessage() {
        if (this.state.numOfUnreadSupportMessage && this.state.numOfUnreadSupportMessage >0 ){
            return (
                <View style={styles.notification}>
                    <Text style={styles.notificationText}>
                        {this.state.numOfUnreadSupportMessage}
                    </Text>
                </View>
            )
        }
    }

    _onDisplayMessenger() {
        try {
            if (!this.props.global.loggedIn) {
                Intercom.reset().then(() => {
                    Intercom.registerUnidentifiedUser()
                        .then(() => {
                            Intercom.displayMessenger();
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            } else {
                let userID = this.props.global.currentUser.userID || undefined;
                let email = this.props.global.currentUser.email || undefined;
                let phone = this.props.global.currentUser.phone || undefined;
                let name = this.props.global.currentUser.username || undefined;
                let fullName = this.props.global.currentUser.fullName || undefined;
                if (fullName) {
                    name = fullName;
                }
                let avatar = this.props.global.currentUser.avatar || undefined;
                Intercom.reset().then(() => {
                    Intercom.registerIdentifiedUser({ userId: userID })
                        .then(() => {
                            log.info('registerIdentifiedUser done');

                            return Intercom.updateUser({
                                email: email,
                                phone: phone,
                                name: name,
                                avatar: { type: 'avatar', image_url: avatar }
                            })
                                .then(() => {
                                    Intercom.displayMessenger();
                                });
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            }

        } catch (error) {
            log.warn('========== onDisplayMessenger ERROR', error);
        }
    }

    _onBackPress() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    scrollView: {
        backgroundColor: '#fff',
        paddingBottom: 78,
    },
    supportChatView: {
        height: 78,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'flex-start',
        borderTopWidth: 1,
        borderColor: '#dcdcdc',
        position:'absolute',
        bottom: 0,
        marginBottom: 0
    },
    supportIconView: {
        height: 40,
        width: 40,
        borderRadius: 20,
        marginRight: 5,
        marginLeft: 8,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor
    },
    supportIcon: {
        height: 8,
        width: 33
    },
    contentTitle: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: '600'
    },
    contentText: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: 'normal',
    },
    notification: {
        position: 'absolute',
        backgroundColor: '#ff0000',
        top: 1,
        right: 1,
        alignSelf: 'auto',
        width: 18,
        height: 18,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center'
    },
    notificationText: {
        fontSize: 10,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#fff',
        textAlign: 'center',
        backgroundColor: 'transparent'
    },
    viewThongTin: {
        width: width,
        // height: 108,
        backgroundColor: '#fff',
        paddingLeft: 15,
        paddingRight: 10
    },
    viewLineAlert: {
        width: width,
        height: 6,
        backgroundColor: '#e3e2e2'
    },
    viewTrangThai: {
        width: width,
        // height: 108,
        backgroundColor: '#fff',
        paddingLeft: 15,
        paddingRight: 10,
        paddingTop: 9,
        paddingBottom: 9
    },
    viewEachDay: {
        width: width - 25,
        height: 30,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    eachTrangThai: {
        width: (width - 25)/2,
        height: 30,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingRight: 8
    },
    viewLyDo: {
        paddingTop: 0,
        paddingBottom: 10,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 15,
        paddingRight: 10
    },
    viewGiaContent: {
        justifyContent: 'center',
        alignItems: 'flex-start',
        // height: 65,
        width: width - 25,
        backgroundColor: '#fff',
        paddingBottom: 10,
        paddingTop: 10,
    },
    viewSoPhongNgu: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        height: 42,
        width: width - 25,
        backgroundColor: '#fff',
    },
    textGia: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: "500",
        color: gui.mainColor
    },
    textDiaChi: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#3f3f3f',
        marginTop: 3
    },
    viewDienTich: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        height: 42,
        paddingLeft:0,
        paddingRight: 18,
        backgroundColor: '#fff'
    },
    textTitle: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: "500",
        color: '#464646',
    },
    textContent: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: "400",
        color: '#898989',
    },
    detailScrollView: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(AlertApproval);