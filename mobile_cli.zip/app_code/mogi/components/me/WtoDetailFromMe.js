'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as registerActions from '../../reducers/register/registerActions';

import {Map} from 'immutable';

import gui from '../../lib/gui';

import React, {Component} from 'react';

import { Text, View, Navigator, TouchableOpacity, InteractionManager, TouchableHighlight, Alert
    , SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS, TextInput, Image, Switch } from 'react-native'

import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon'
import RelandIcon from '../RelandIcon';

import RangeUtils from "../../lib/RangeUtils"

import DanhMuc from "../../assets/DanhMuc"

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import placeUtil from '../../lib/PlaceUtil';

import GiftedSpinner from 'react-native-gifted-spinner';

import moment from 'moment';

import CommonUtils from '../../lib/CommonUtils';

import Communications from '../detail/MCommunications';

import utils from '../../lib/utils';

import log from '../../lib/logUtil';

const {width, height} = utils.getDimensions();
const mapWidth = width-30;
const mapHeight = (width-width%2)/2+3;

const imgHeight = 181;

const actions = [
    globalActions,
    needToBuyActions,
    adsMgmtActions,
    searchActions,
    chatActions,
    registerActions
];

const ONE_MILLION = 1000000.0;

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class WToDetailFromMe extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: props.data,
            loading: true
        };
    }

    componentDidMount() {
        this._fillWToDetail(this.state.data.wto);
    }

    _fillWToDetail(wtoDto) {
        let content = wtoDto.content;
        let wtoID = wtoDto.wtoID;
        let mua = {loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE};
        let thue = {loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE};
        let loaiTin = content.loaiTin==0 ? 'mua' : 'thue';
        let loaiNhaDat = content.loaiNhaDat;
        let giaTu = content.giaTu;
        let giaDen = content.giaDen;
        let gia = giaTu && giaDen ? RangeUtils.sellPriceRange.rangeVal2Display([giaTu, giaDen]) : RangeUtils.BAT_KY_RANGE;
        if (loaiTin == 'mua') {
            mua = {loaiNhaDat: loaiNhaDat ? loaiNhaDat : '', gia: gia};
        } else {
            thue = {loaiNhaDat: loaiNhaDat ? loaiNhaDat : '', gia: gia};
        }

        let initGia = gia;
        let giaVal = [giaTu, giaDen];
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }

        let dienTichTu = content.dienTichTu;
        let dienTichDen = content.dienTichDen;
        let dienTich = dienTichTu && dienTichDen ? RangeUtils.dienTichRange.rangeVal2Display([dienTichTu, dienTichDen]) :
            RangeUtils.BAT_KY_RANGE;

        let initDienTich = dienTich;
        let dienTichVal = [dienTichTu, dienTichDen];
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }

        let title = DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, loaiNhaDat);

        this.setState({
            wtoID: wtoID,
            title: title,
            initGia: initGia,
            initDienTich: initDienTich,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            loaiTin: loaiTin,
            loaiNhaDat: loaiNhaDat,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            soTang: content.soTang,
            soPhongNgu: content.soPhongNgu,
            soPhongTam: content.soPhongTam,
            huongNha: content.huongNha,
            place: content.place,
            ghiChu: content.ghiChu,
            loading: false
        });
    }



    renderLoadingView() {
        return (
            <View style={[myStyles.searchFilter, {top: 64, height: height-64, alignItems: 'center', justifyContent: 'center'}]}>
                <GiftedSpinner size='large' color='gray' />
            </View>
        )
    }

    renderWToBody() {
        return (
            <View style={[myStyles.searchFilter, {top: 64}]}>
                <ScrollView style={[myStyles.searchFilter, {top: 0, height: height-108}]}
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="on-drag"
                            ref='scroll'>
                    {this._renderCover()}
                    {this._renderChiTietWTo()}
                    <FullLine />
                    {this._renderChiTietAds()}
                    {this._renderPreferenceView()}
                    <FullLine />
                    <View style={myStyles.searchSectionTitle}>
                        <Text style={myStyles.cacDieuKienText}>
                            Ghi chú
                        </Text>
                    </View>
                    <FullLine />
                    {this._renderGhiChu()}
                </ScrollView>
            </View>
        );
    }

    _renderGhiChu() {
        let wts = this.state.data;
        let ghiChu = wts && wts.noiDung || '';
        return (
            <View style={[myStyles.searchFilterAttribute, {paddingBottom: 20}]}>
                <ScalableText style={myStyles.ghiChuItem}>{ghiChu}</ScalableText>
            </View>
        )
    }

    _renderPreferenceView() {
        if (!this._isThuTucMienPhi() && !this._isDeLaiDoTrongNha()) {
            return null;
        }
        return (
            <View style={myStyles.preferenceView} pointerEvents="none" >
                <FullLine />
                <View style={myStyles.searchSectionTitle}>
                    <Text style={myStyles.cacDieuKienText}>
                        NHỮNG ƯU ĐÃI
                    </Text>
                </View>
                <FullLine />
                {this._renderThuTucMienPhi()}
                {this._renderDeLaiDoTrongNha()}
            </View>
        );
    }


    _onValueChange(key, value) {
        let newState = {};
        newState[key] = value;
        this.setState(newState);
    }

    _renderThuTucMienPhi() {
        if (!this._isThuTucMienPhi()) {
            return null;
        }
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={[myStyles.preferenceSubView1, {width: width/2}]}>
                    <Text style={[myStyles.label, {marginLeft: 17}]}>
                        Bao sang tên
                    </Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {justifyContent: 'flex-end', width: width/2-10, paddingRight: 10}]}>
                    {/*<Switch
                     onValueChange={(value) => this._onValueChange('thuTucMienPhi', value)}
                     value={this._isThuTucMienPhi()} />*/}
                    <RelandIcon name={'check-icon'} color={'#27AB5F'} mainProps={{flexDirection: 'row'}}
                                size={22} textProps={{paddingLeft: 20}}
                                noAction={true} />
                </View>
            </View>
        );
    }

    _isThuTucMienPhi() {
        let wts = this.state.data;
        return wts && wts.baoSangTen;
    }

    _renderDeLaiDoTrongNha() {
        if (!this._isDeLaiDoTrongNha()) {
            return null;
        }
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={[myStyles.preferenceSubView1, {width: width/2}]}>
                    <Text style={[myStyles.label, {marginLeft: 17}]}>
                        Để lại đồ trong nhà
                    </Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {justifyContent: 'flex-end', width: width/2-10, paddingRight: 10}]}>
                    {/*<Switch
                     onValueChange={(value) => this._onValueChange('deLaiDoTrongNha', value)}
                     value={this._isDeLaiDoTrongNha()} />*/}
                    <RelandIcon name={'check-icon'} color={'#27AB5F'} mainProps={{flexDirection: 'row'}}
                                size={22} textProps={{paddingLeft: 20}}
                                noAction={true} />
                </View>
            </View>
        );
    }

    _isDeLaiDoTrongNha() {
        let wts = this.state.data;
        return wts && wts.deLaiDoDac;
    }

    _renderCover() {
        let data = this.state.data;
        let {fullName, avatar} = data.toUser;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = avatar ? {uri: avatar} : defaultAvatar;
        let fullNameText = fullName || '';

        let {timeModified} = data;
        let ngayDang = moment(timeModified).format("HH:mm | DD/MM/YYYY");
        ngayDang = 'Tin đăng: ' + ngayDang;
        let thongTinNhan = 'Thông tin người nhận:';
        return (
            <View>
                <ScalableText style={[myStyles.priceItem, myStyles.styleThongTin, {marginLeft: 15}]}>{thongTinNhan}</ScalableText>
                <View style={myStyles.dangBoiView}>
                    <View style={myStyles.avatarView}>
                        <Image style={myStyles.avatarImage}
                               resizeMode={Image.resizeMode.cover}
                               source={avatarUri}
                               defaultSource={defaultAvatar}
                        />
                    </View>
                    <View style={myStyles.userInfoView}>
                        <ScalableText style={myStyles.fullNameText}>{fullNameText}</ScalableText>
                        <ScalableText style={myStyles.ngayDangText}>{ngayDang}</ScalableText>
                    </View>
                </View>
                <FullLine style ={{marginLeft: 15, marginRight: 15}}/>
            </View>
        );
    }

    render() {
        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={myStyles.mainView}>
                    {this.state.loading ? this.renderLoadingView() : this.renderWToBody()}
                </View>

                {this._renderHeaderAds()}
                {this._renderPostWToButton()}
            </View>
        );
    }

    _getGiaText() {
        let {initGia, fromGia, toGia} = this.state;
        if (!fromGia && !toGia) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        if (!fromGia) {
            return 'Giá: <= ' + initGia[1];
        }
        if (!toGia) {
            return 'Giá: >= ' + initGia[0];
        }
        return 'Giá: ' + initGia[0] + ' - ' + initGia[1];
    }

    _getDienTichText() {
        let {initDienTich, fromDienTich, toDienTich} = this.state;
        if (!fromDienTich && !toDienTich) {
            return '';
        }
        if (!fromDienTich) {
            return '<= ' + initDienTich[1];
        }
        if (!toDienTich) {
            return '>= ' + initDienTich[0];
        }
        return initDienTich[0] + ' - ' + initDienTich[1];
    }

    _renderChiTietWTo() {
        let {soTang, soPhongNgu, soPhongTam, huongNha, ghiChu} = this.state;
        let giaText = this._getGiaText();
        let diaChi = this._getDiaChiFullname();

        let dacDiemValues = [];
        let dienTichText = this._getDienTichText();
        if (dienTichText) {
            dacDiemValues.push(dienTichText);
        }

        let soTangText = '';
        if (soTang) {
            soTangText = soTang + ' tầng';
            dacDiemValues.push(soTangText);
        }
        let soPhongTamText = '';
        if (soPhongTam) {
            soPhongTamText = soPhongTam + ' phòng tắm';
            dacDiemValues.push(soPhongTamText);
        }

        if (soPhongNgu) {
            dacDiemValues.push(soPhongNgu + ' phòng ngủ');
        }

        if (huongNha && huongNha != '-1') {
            dacDiemValues.push("Hướng " + DanhMuc.HuongNha[huongNha]);
        }

        let dacDiemItems = [];
        for (let i = 0; i<dacDiemValues.length; i = i+2) {
            let one = dacDiemValues[i];
            let other = '';
            if (i < dacDiemValues.length-1) {
                other = dacDiemValues[i+1];
            }
            let item = this.renderTwoNormalProps(one, other, {marginTop: 11}, {marginTop: 4, marginBottom: 4}, 'prop_' + i);
            dacDiemItems.push(item);
        }

        return (
            <View style={myStyles.chiTietView}>
                <View style={myStyles.chiTietSubView1}>
                    <ScalableText style={myStyles.chiTietTitleItem}>{this.state.title}</ScalableText>
                    <ScalableText style={myStyles.priceItem}>{giaText}</ScalableText>
                    <ScalableText style={[myStyles.diaChiItem, {marginTop: 5, marginBottom: 10}]}>{diaChi}</ScalableText>
                    {dacDiemItems.length > 0 ? <FullLine style={{marginBottom: 4}} /> : null}
                    {dacDiemItems}
                </View>
                {ghiChu ?
                    <View style={myStyles.chiTietSubView2}>
                        <FullLine style={{marginTop: 4, marginBottom: 8}} />
                        <ScalableText style={myStyles.ghiChuItem}>{ghiChu}</ScalableText>
                    </View> : <View style={{marginBottom: 8}} /> }
            </View>
        );
    }

    renderTwoNormalProps(prop1, prop2, dotStyle, textStyle, key) {
        if (prop1 || prop2) {
            let dotIcon1Style = prop1 ? {} : {backgroundColor: 'transparent'};
            let dotIcon2Style = prop2 ? {} : {backgroundColor: 'transparent'};
            return (
                <View key={key} style={[myStyles.searchDetailRowAlign]}>
                    <View style={{flexDirection: 'row'}}>
                        <View style={[myStyles.dot2, dotIcon1Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop1}
                        </Text>
                    </View>
                    <View style={{flexDirection: 'row', marginLeft: 10}}>
                        <View style={[myStyles.dot2, dotIcon2Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop2}
                        </Text>
                    </View>
                </View>
            )
        }
    }

    _getDiaChiFullname() {
        let {place} = this.state;
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    _renderChiTietAds() {
        let wts = this.state.data;
        let rowData = wts && wts.ads;
        if (!rowData) {
            return null;
        }
        let loaiTinVal = rowData.loaiTin;
        let loaiNhaDat = loaiTinVal ? DanhMuc.LoaiNhaDatThue[rowData.loaiNhaDat] :  DanhMuc.LoaiNhaDatBan[rowData.loaiNhaDat];
        let diaChi = rowData.place.diaChi;

        let dacDiemValues = [];
        dacDiemValues.push(loaiNhaDat);

        let dienTich = utils.getDienTichDisplay(rowData.dienTich);
        if (dienTich == 'Không rõ') {
            dienTich = '';
        }
        if (dienTich) {
            dacDiemValues.push(dienTich);
        }

        let giaGiam = wts && wts.giaGiam;
        let gia = utils.getPriceDisplay(rowData.gia, loaiTinVal);
        let giaDaGiam = giaGiam ? utils.getPriceDisplay(rowData.gia-giaGiam, loaiTinVal) : '';
        let giaStyle = {marginLeft: 5};
        if (giaGiam) {
            giaStyle = {marginLeft: 5,
                textDecorationLine: 'line-through', color: '#C7C8CA'};
        }
        let giaLabel = 'Giá: ';

        let soTang = rowData.soTang;
        if (soTang) {
            soTang = soTang + ' tầng';
            dacDiemValues.push(soTang);
        }

        let soPhongTamVal = rowData.soPhongTam;
        let soPhongTam = soPhongTamVal;
        if (soPhongTam) {
            soPhongTam = soPhongTam + ' phòng tắm';
            dacDiemValues.push(soPhongTam);
        }

        let soPhongNguVal = rowData.soPhongNgu;
        let soPhongNgu = soPhongNguVal;
        if (soPhongNgu) {
            soPhongNgu = soPhongNgu + ' phòng ngủ';
        }
        if (soPhongNgu) {
            dacDiemValues.push(soPhongNgu);
        }

        let huongNha = DanhMuc.HuongNha[rowData.huongNha];
        let huongNhaText = '';
        if (rowData.huongNha && rowData.huongNha != '-1') {
            huongNhaText = "Hướng " + huongNha;
        }
        if (huongNhaText) {
            dacDiemValues.push(huongNhaText);
        }

        let soNgayDaDangTin = rowData.soNgayDaDangTinFmt;
        if (soNgayDaDangTin) {
            dacDiemValues.push(soNgayDaDangTin);
        }

        let dacDiemItems = [];
        for (let i = 0; i<dacDiemValues.length; i = i+2) {
            let one = dacDiemValues[i];
            let other = '';
            if (i < dacDiemValues.length-1) {
                other = dacDiemValues[i+1];
            }
            let item = this.renderTwoNormalProps(one, other, {marginTop: 11}, {marginTop: 4, marginBottom: 4}, 'prop_' + i);
            dacDiemItems.push(item);
        }

        let thongTinGui = 'Thông tin gửi:';

        return (
            <View style={[myStyles.chiTietView, {paddingTop: 5}]}>
                <ScalableText style={[myStyles.priceItem, myStyles.styleThongTin]}>{thongTinGui}</ScalableText>
                <View style={myStyles.chiTietSubView1}>
                    <View style={{flexDirection: 'row'}}>
                        <ScalableText style={myStyles.priceItem}>{giaLabel}</ScalableText>
                        <ScalableText style={[myStyles.priceItem, giaStyle]}>{gia}</ScalableText>
                        <ScalableText style={[myStyles.priceItem, {marginLeft: 15}]}>{giaDaGiam}</ScalableText>
                    </View>
                    <ScalableText style={[myStyles.diaChiItem, {marginTop: 5, marginBottom: 10}]}>{diaChi}</ScalableText>
                    {dacDiemItems.length > 0 ? <FullLine style={{marginBottom: 4}} /> : null}
                    {dacDiemItems}
                </View>
            </View>
        );
    }

    renderTwoNormalProps(prop1, prop2, dotStyle, textStyle, key) {
        if (prop1 || prop2) {
            let dotIcon1Style = prop1 ? {} : {backgroundColor: 'transparent'};
            let dotIcon2Style = prop2 ? {} : {backgroundColor: 'transparent'};
            return (
                <View key={key} style={[myStyles.searchDetailRowAlign]}>
                    <View style={{flexDirection: 'row'}}>
                        <View style={[myStyles.dot2, dotIcon1Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop1}
                        </Text>
                    </View>
                    <View style={{flexDirection: 'row', marginLeft: 10}}>
                        <View style={[myStyles.dot2, dotIcon2Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop2}
                        </Text>
                    </View>
                </View>
            )
        }
    }

    _renderHeaderAds() {
        return (
            <View style={myStyles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this.onCancel()}
                    style={myStyles.backButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={myStyles.viewTitleHeader}>
                    <ScalableText style={[myStyles.textHeader, {fontWeight: '500', fontSize: 17}]}>
                        Chi tiết
                    </ScalableText>
                </View>
                <View
                    style={myStyles.viewRightHeader}>
                </View>
            </View>
        );
    }

    _renderPostWToButton() {
        let data = this.state.data;

        if (!data || !data.wto || data.wto.status == 5
                || !data.ads || data.ads.status != 2) {
            return;
        }

        return (
            <TouchableOpacity onPress={this.onApply.bind(this)} style={myStyles.searchButton}>
                <ScalableText style={[myStyles.searchButtonText, {fontWeight: '500'}]}>
                    Gửi lại cho người mua
                </ScalableText>
            </TouchableOpacity>
        )
    }

    onApply () {
        Actions.WToAdsSendFromMe({wts: this.state.data,
            doViTriFinalAction: this._refreshAdsPackage.bind(this),
            doPostWTSFinalAction: this._refreshWTSPackage.bind(this)});
    }

    _refreshAdsPackage(newAds) {
        let wts = this.state.data;
        if (wts) {
            wts.ads = newAds;
            this.setState({data: wts});
        }
    }

    _refreshWTSPackage(wts) {
        this.setState({data: wts});
    }

    onCancel() {
        Actions.pop();
    }
}

const myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        width: width,
        height: 64
    },

    searchButton: {
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        top: height -44 ,
        height: 44,
        width: width,
        justifyContent: 'center',
        backgroundColor: '#E83522',
        zIndex: 1
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchMoreFilterButton: {
        flexGrow: 0.5,
        alignItems: 'stretch',
        justifyContent: 'center'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchResetText: {
        color: 'red',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    searchAttributeLabel : {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: 'black'
    },
    searchAttributeValue : {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.arrowColor,
        marginRight: 3
    },
    searchFilterButton: {
        flexDirection: 'column'
    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchSectionTitle: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingLeft: 17,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8'
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection:"column"
    },
    scrollView: {
        flex: 1,
        height: height-123
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent :'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute3: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 17,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 0,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt3: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 17,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    addViewBottom: {
        height:30,
        width:width,
        backgroundColor:'#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewTitleHeader:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    searchDiaChinhView: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    diaChinhSubView: {
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'column'
    },
    diaChinhTouchable: {
        padding: 4,
        paddingLeft: 10,
        height: 38,
        marginLeft: 0,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    diaChinhText: {
        fontSize: 15,
        color: '#9fa0a4',
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    locationIcon: {
        backgroundColor:'white',
        height:25,
        width:25,
        marginRight:4,
        justifyContent:'center',
        alignItems:'center'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width-30,
        height: 60
    },
    textInputView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    textInputView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/3-5,
        marginTop: 10,
        marginBottom: 10
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width/3-5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    dangBoiView: {
        height: 90,
        width: width,
        marginLeft: 17,
        flexDirection: 'row'
    },
    avatarView: {
        height: 90,
        width: 90,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    userInfoView: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 15
    },
    fullNameText: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    ngayDangText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    chiTietView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15
    },
    chiTietSubView1: {
        flex: 1
    },
    chiTietSubView2: {
        flex: 1,
        paddingBottom: 15
    },
    chiTietTitleItem: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 5
    },
    ghiChuItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#6E6F73',
        fontFamily: gui.fontFamily
    },
    priceItem: {
        fontSize: 15,
        fontWeight: '400',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#1E94D6',
        fontFamily: gui.fontFamily,
        paddingTop: 5
    },
    attributeView: {
        flex: 1,
        flexDirection: 'row',
        paddingTop: 5,
        alignItems: 'center'
    },
    diaChiItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    viTriView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15,
        paddingBottom: 15
    },
    titleViTriItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    hintViTriItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 15
    },
    miniMapItem: {
        width: mapWidth,
        height: mapHeight
    },
    shareView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15
    },
    titleShareItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    hintShareItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 15
    },
    sharedButtonsView: {
        flex: 1,
        flexDirection: 'row',
        paddingBottom: 15
    },
    circleContainer: {
        marginTop: 0,
        marginBottom: 0,
        marginRight: 10,
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: '#A8A8A8'
    },
    circleContainer2: {
        marginTop: -7,
        marginBottom: 0,
        marginRight: 10,
        backgroundColor: '#A8A8A8'
    },
    shareIcon: {
        marginTop: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    searchDetailRowAlign: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-around',
    },
    dot2 : {
        width: 5,
        height: 5,
        borderRadius: 2.5,
        marginTop: 11,
        marginLeft: 20,
        marginRight: 0,
        backgroundColor: '#C1C1C1'
    },
    textHalfWidth: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: 'black',
        marginTop: 3,
        marginBottom: 4,
        marginLeft: 5,
        marginRight: 10,
        width: width/2-20
    },
    mainView: {
        flexGrow: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor : "transparent"
    },
    imgItem: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: imgHeight,
        alignSelf: 'auto'
    },
    preferenceView: {
        flex: 1
    },
    preferenceSubView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    preferenceSubView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        marginRight: 10
    },
    preferenceSubView2: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/2+15,
        marginTop: 10,
        marginBottom: 10
    },
    priceUnitView: {
        flex: 1,
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10
    },
    styleThongTin: {
        fontSize: 17,
        color: '#000',
        fontWeight: '500'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(WToDetailFromMe);
