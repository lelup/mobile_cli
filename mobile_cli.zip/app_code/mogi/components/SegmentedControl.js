import React, {Component} from 'react';
import {View, Text, StyleSheet, SegmentedControlIOS} from 'react-native';

import gui from '../lib/gui';

import SegmentedControlTab from './SegmentedControlTab2';

// Create our component
class SegmentedControl extends Component {
    render() {
        // return (
        //     <View style={[myStyles.searchFilterAttributeExt, {flexDirection: "column"}]}>
        //         <View style={{paddingBottom: 4, paddingTop: 3}}>
        //             <Text style={myStyles.searchAttributeLabel}>
        //                 {this.props.label}
        //             </Text>
        //         </View>
        //         <View style={{paddingLeft: 0, paddingRight: 6, paddingBottom: 9}}>
        //
        //             <SegmentedControlIOS
        //                 values={this.props.values}
        //                 selectedIndex={this.props.selectedIndexAttribute}
        //                 onChange={this.props.onChange}
        //                 tintColor={gui.mainColor} height={28}
        //             >
        //             </SegmentedControlIOS>
        //         </View>
        //     </View>
        // );

        return (
            <View style={[myStyles.searchFilterAttributeExt, {flexDirection: "column"}]}>
                <View style={{paddingBottom: 4, paddingTop: 3}}>
                    <Text style={myStyles.searchAttributeLabel}>
                        {this.props.label}
                    </Text>
                </View>
                <View style={{paddingLeft: 0, paddingRight: 6, paddingBottom: 9}}>

                    <SegmentedControlTab
                        values={this.props.values}
                        selectedIndex={this.props.selectedIndexAttribute}
                        //onChange={this.props.onChange}
                        //onTabPress={index => this.setState({selected:index})}
                        onTabPress={this.props.onChange}
                        tabStyle ={myStyles.tabStyle}
                        tabTextStyle={myStyles.tabTextStyle}
                        activeTabStyle={{backgroundColor: gui.mainColor}}
                        activeTabTextStyle={myStyles.activeTabTextStyle}
                        tabsContainerStyle={myStyles.tabsContainerStyle}
                    />
                </View>
            </View>
        );
    }
}

// Later on in your styles..
var myStyles = StyleSheet.create({
    searchFilterAttributeExt: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingTop: 5,
        paddingLeft: 0,
        paddingBottom: 8,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchAttributeLabel: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: 'black'
    },
    tabStyle: {
        backgroundColor: '#fff',
        // borderWidth: 1,
        borderColor:gui.mainColor,
        paddingVertical: 5,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        // marginLeft:-2
    },
    tabTextStyle: {
        color:gui.mainColor,
        fontWeight: '400',
        fontFamily:gui.fontFamily,
        fontSize: 15
    },
    activeTabTextStyle: {
        color: '#fff',
        fontWeight: '400',
        fontFamily:gui.fontFamily,
        fontSize: 15
    },
    tabsContainerStyle: {
        alignItems:'center',
        backgroundColor:'transparent',
        marginTop:5
    }
});

// Make this code available elsewhere
export default  SegmentedControl;
