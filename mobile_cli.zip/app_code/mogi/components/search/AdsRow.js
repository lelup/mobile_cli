'use strict';

import React from 'react';
import { Image, StyleSheet, Text, View , ListView, ImageBackground, TouchableOpacity, TouchableHighlight} from 'react-native';
import {Actions} from 'react-native-router-flux';
import LinearGradient from 'react-native-linear-gradient';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';
import MHeartIcon from '../MHeartIcon';
import MEyeIcon from '../MEyeIcon';
// import FullLine from '../line/FullLine';

import CommonUtils from '../../lib/CommonUtils';
import gui from '../../lib/gui';
import GiftedSpinner from 'react-native-gifted-spinner';
import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();
import ScalableText from 'react-native-text';

import RelandIcon from '../RelandIcon';

var Analytics = require('react-native-firebase-analytics');

const imgHeight = 181;

var { createIconSet } = require('react-native-vector-icons');
var glyphMap = { 'heart':59457, 'heart-o':59458};
var Icon = createIconSet(glyphMap, 'TruliaIcon');


class AdsRow extends React.Component {
  renderLikeIcon(ads) {
    //log.info("renderLikeIcon, ", ads.isLiked);
    let isLiked = this.isLiked(ads);
    let color = isLiked ? 'white' : 'white';
    let bgColor = isLiked ? '#E50064' : '#4A443F';
    let bgStyle = isLiked ? {} : {opacity: 0.55};

    if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == ads.adsID){
      return (
          <View style={{position: "absolute", left: width-45, backgroundColor:'transparent', top: -120}}>
            <View style={myStyles.heartButton}>
              <GiftedSpinner size="small" color="white"/>
            </View>
          </View>
      );
    } else {
      return (
        <View style={{position: "absolute", left: width-65, backgroundColor:'transparent', top: -120}}>
          <MHeartIcon onPress={() => this.onLike(ads)} color={color} bgColor={bgColor} bgStyle={bgStyle} size={22}
                      mainProps={myStyles.heartButton} />
        </View>
      )
    }
  }
  /*
   <TouchableHighlight underlayColor='transparent' style={{overflow: 'hidden'}} onPress={() => this.onLike(ads)}>
   <View style={myStyles.heartButton} >
   <MHeartIcon color={color} bgColor={bgColor} bgStyle={bgStyle} size={22} noAction={true} />
   </View>
   </TouchableHighlight>
  */

  isLiked(ads) {
    const {adsLikes} = this.props;
    return adsLikes && adsLikes.indexOf(ads.adsID) > -1;
  }

  onLike(ads) {
    if (!this.props.loggedIn) {
      //this.props.actions.onAuthFieldChange('activeRegisterLoginTab',0);
      Actions.NewLogin();
    } else {
      let adsID = ads.adsID;
      let userID = this.props.userID;
      if (!this.isLiked(ads)) {
        Analytics.logEvent('SEARCH_LIKE', {adsID: adsID, userID: userID});
        this.props.likeAds(userID, adsID, this.props.updateLikeAdsProcessing);
      } else {
        Analytics.logEvent('SEARCH_UNLIKE', {adsID: adsID, userID: userID});
        this.props.unlikeAds(userID, adsID, this.props.updateLikeAdsProcessing);
      }
    }
  }

  renderImageStack(ads) {
    var imageIndex  = 0;
    if (ads.image) {
      if (ads.image.cover) {
        return (
          <MyImage imageIndex={0} ads={ads} imageUrl={ads.image.cover} noCoverUrl={this.props.noCoverUrl} owner={this.props.owner}/>
        )
      } else if (ads.image.images && ads.image.images.length > 0) {
        return (
            <MyImage imageIndex={0} ads={ads} imageUrl={ads.image.images[0]} noCoverUrl={this.props.noCoverUrl} owner={this.props.owner}/>
        );
      }

      // let list = [];
      // for (var i=0; i < ads.image.images.length ; i++) {
      //   list.push(ads.image.images[i]);
      // }
      //
      // return list.map(imageUrl => {
      //   return <MyImage key={imageIndex} imageIndex={imageIndex++} ads={ads} imageUrl={imageUrl}/>
      // });

    } else {
      return (
        <MyImage imageIndex={0} ads={ads} imageUrl={this.props.noCoverUrl} noCoverUrl={this.props.noCoverUrl} owner={this.props.owner}/>
      );
    }
  }

  getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
    var moreInfo = '';
    var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
    if (loaiNhaDat == loaiNhaDatKeys[1]) {
      moreInfo = ' ' + dienTich + soPhongNgu;
    }
    else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
      || (loaiNhaDat == loaiNhaDatKeys[3])
      || (loaiNhaDat == loaiNhaDatKeys[4])) ||
        loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[6]))) {
      moreInfo = ' ' + dienTich + soTang;
    }
    else {
      moreInfo = ' ' + dienTich;
    }
    return moreInfo;
  }

  render() {
    const {ads} = this.props;

    let loaiTin = ads.loaiTin;
    let diaChi = ads.diaChi || '';
    let originDiaChi = ads.diaChi || '';
    let loaiNhaDat = ads.loaiNhaDat;
    let giaCu = ads.giaCuFmt || utils.getPriceDisplay(ads.giaCu, ads.loaiTin);
    let isGiamGia = ads.giaCu && ads.gia && ads.gia < ads.giaCu;
    let giaDaGiam = ads.giaFmt || utils.getPriceDisplay(ads.gia, ads.loaiTin);
    let dienTich = '';
    if (ads.dienTichFmt && ads.dienTichFmt != 'Không rõ') {
      dienTich = '· ' + ads.dienTichFmt;
    }
    let soPhongNgu = '';
    if (ads.soPhongNguFmt) {
      soPhongNgu = "   " + ads.soPhongNguFmt;
    }

    let soTang = '';
    if (ads.soTangFmt) {
      soTang = "   " + ads.soTangFmt;
    }

    let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);

    let maxDiaChiLength = width*7/64 - moreInfo.length;

    let index = diaChi.indexOf(',', maxDiaChiLength - 5);
    let length = 0;
    if (index !== -1 && index <= maxDiaChiLength) {
      length = index;
    } else {
      index = diaChi.indexOf(' ', maxDiaChiLength - 5);
      length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
    }
    diaChi = diaChi.substring(0, length);
    if (diaChi.length < originDiaChi.length) {
      diaChi = diaChi + '...';
    }

    let logoItems = [];
    if (ads.goiLogo && ads.goiLogo.length>0) {
      let uuid = new Date().getTime();
      let index = 0;
      for (let i=0; i<ads.goiLogo.length; i++) {
        let adsLogo = ads.goiLogo[i];
        let remainDays = utils.getRemainDay(adsLogo);
        if (remainDays > 0 && adsLogo.text) {
          let marginLeft = index == 0 ? 12 : 5;
          let bgColor = adsLogo.bgColor || gui.mainColor;
          logoItems.push(
            <View key={'logo_' + ads.adsID + uuid + index} style={[myStyles.logoContainer,
                                                                  {backgroundColor: bgColor, marginLeft: marginLeft}]}>
              <ScalableText style={myStyles.logo}
                            onStartShouldSetResponder={(evt) => false}
                            onMoveShouldSetResponder={(evt) => false}
              >{adsLogo.text.toUpperCase()}</ScalableText>
            </View>
          );
          index++;
        }
      }
    }

    let firstControl = null;
    let lastControl = null;
    let {showFirstControl, isFirstRow, showLastControl, isLastRow, showFirstLoading} = this.props;

    if (isFirstRow) {
      if (this.props.loading) {
        if (showFirstLoading) {
          firstControl = <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
            <GiftedSpinner size="small"/>
          </View>;
        }
      } else {
        if (showFirstControl) {
          firstControl =
              <View>
              <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                <TouchableHighlight onPress={this.props.loadPreviousPage} underlayColor="transparent">
                  <View style={{flexDirection: 'column'}}>
                    <Text style={myStyles.rowControl}>Nhấn vào đây để quay lại trang trước</Text>
                    <Text style={myStyles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                  </View>
                </TouchableHighlight>
              </View>
          </View>;
        }
        // else if (this.props.getDieuKienLoc) {
        //   let searchText = 'Điều kiện lọc: ' + this.props.getDieuKienLoc();
        //   firstControl =
        //       <View>
        //         <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
        //           <View>
        //             <Text style={myStyles.pagingTitle}>{searchText}</Text>
        //           </View>
        //         </View>
        //       </View>
        //   ;
        // }
      }
    }
    if (showLastControl && isLastRow) {
      lastControl =
          <View>
            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
              <TouchableHighlight onPress={this.props.loadNextPage} underlayColor="transparent">
                <View style={{flexDirection: 'column'}}>
                  <Text style={myStyles.rowControl}>Nhấn vào đây để đi đến trang sau</Text>
                  <Text style={myStyles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                </View>
              </TouchableHighlight>
            </View>
          </View>
            ;
    }
    return (
      <View key={ads.adsID} style={{flexDirection: 'column', overflow: 'hidden'}}>
        {firstControl}
        <TouchableHighlight
              onPress={() => Actions.SearchResultDetail({adsID: ads.adsID, source: 'server', imageDetail: ads.image.cover, owner: this.props.owner})}
              style={myStyles.detail}
              onStartShouldSetResponder={(evt) => false}
              onMoveShouldSetResponder={(evt) => false}>
            <View>
            {/*<Swiper style={myStyles.wrapper} height={imgHeight}
                    showsButtons={false} autoplay={false} loop={false} bounces={true}
                    dot={<View style={[myStyles.dot, {backgroundColor: 'transparent'}]} />}
                    activeDot={<View style={[myStyles.dot, {backgroundColor: 'transparent'}]}/>}
            >
              {this.renderImageStack(ads)}
            </Swiper>*/}
            {this.renderImageStack(ads)}
            {this.renderGoiViTri(ads)}
            {/*this.renderAdsNoPos(ads)*/}
            {this.renderHideAds(ads)}
            <View style={[myStyles.searchListViewRowAlign, {justifyContent: 'flex-start', top: imgHeight - 85, marginLeft: 5}]}>
              {logoItems}
            </View>
            <View style={myStyles.searchListViewRowAlign}
                  onStartShouldSetResponder={(evt) => false}
                  onMoveShouldSetResponder={(evt) => false}
            >
              <View
                onStartShouldSetResponder={(evt) => false}
                onMoveShouldSetResponder={(evt) => false}
                pointerEvents="none"
              >

                <View style={{flexDirection: 'row'}}>
                  {isGiamGia ?
                      <View style={{flexDirection: 'row'}}>
                        <Text style={myStyles.price}
                              onStartShouldSetResponder={(evt) => false}
                              onMoveShouldSetResponder={(evt) => false}
                              numberOfLines={1}>{giaDaGiam}</Text>
                        <Text
                            onStartShouldSetResponder={(evt) => false}
                            onMoveShouldSetResponder={(evt) => false}
                            style={[myStyles.price, {marginLeft: 10, textDecorationLine: 'line-through',
                                                  color: '#C7C8CA'}]} numberOfLines={1}>{giaCu}</Text>
                      </View> :
                      <Text
                          onStartShouldSetResponder={(evt) => false}
                          onMoveShouldSetResponder={(evt) => false}
                          style={myStyles.price} numberOfLines={1}>{giaDaGiam}</Text>
                  }
                </View>
                <ScalableText style={myStyles.text}>{diaChi}{moreInfo}</ScalableText>
              </View>
              {this.renderLikeIcon(ads)}
            </View>
          </View>
        </TouchableHighlight>
        {lastControl}
      </View>
    );
  }

  renderAdsNoPos(ads) {
    if (!ads.place.geo || isNaN(ads.place.geo.lat) || isNaN(ads.place.geo.lon) || ads.isFakeGeo) {
      return (
          <View style={myStyles.adsNoPosContainer}>
            <RelandIcon name="no-location" color='#fff' mainProps={{flexDirection: 'row'}}
                        size={26} textProps={{paddingLeft: 0}}
                        noAction={true} />
          </View>
      )
    }
    return null;
  }

  renderHideAds(ads) {
    // if (this.props.isHiddenAds(ads)) {
    //   return null;
    // }

    let color = 'white';
    let bgColor = '#4A443F';
    let bgStyle = {opacity: 0.55};
    return (
        <View style={myStyles.hideAdsContainer}>
          <MEyeIcon onPress={() => this.props.onHideAds(ads)} color={color} bgColor={bgColor} bgStyle={bgStyle} size={35}
                      mainProps={{flexDirection: 'row'}} />
        </View>
    )
  }

  renderGoiViTri(ads) {
    if (ads.goiViTri) {
      let remainDays = utils.getRemainDay(ads.goiViTri);
      let goiViTriIcon = utils.getGoiViTriIcon(ads.goiViTri);
      if (remainDays > 0 && goiViTriIcon) {
        return (
            <View style={myStyles.goiViTriView}>
              <Image style={myStyles.goiViTriIcon} source={goiViTriIcon} resizeMode={Image.resizeMode.cover} />
            </View>
        );
      }
    }
    return null;
  }
}

class MyImage extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    let imageUri = {uri: this.props.imageUrl};
    if (this.props.noCoverUrl == this.props.imageUrl) {
      imageUri = require('../../assets/image/reland_house_large.jpg');
    }
    return(
      <View style={myStyles.slide} key={"img"+(this.props.imageIndex)}>
        <TouchableOpacity onPress={() => Actions.SearchResultDetail({adsID: this.props.ads.adsID, source: 'server', imageDetail: this.props.ads.image.cover, owner: this.props.owner})}>
          <ImageBackground style={myStyles.thumb} source={imageUri} defaultSource={CommonUtils.getNoCoverImage()} >
            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.55)']}
                            style={myStyles.linearGradient2}>
            </LinearGradient>
          </ImageBackground>
        </TouchableOpacity>
      </View>
    );
  }
}

const myStyles = StyleSheet.create({
  detail: {
    flex: 0
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
    bottom: 32
  },
  wrapper: {
    backgroundColor: 'black'
  },
  searchListViewRowAlign: {
    position: 'absolute',
    backgroundColor: 'transparent',
    flexDirection: 'row',
    justifyContent: 'space-between',
    top: imgHeight - 57,
    width: width
  },
  logoContainer: {
    marginLeft: 12,
    justifyContent: "center",
    backgroundColor: gui.mainColor,
    borderRadius: 5,
    padding: 4,
    paddingLeft: 6,
    paddingRight: 6
  },
  logo: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily
  },
  goiViTriView: {
    position: 'absolute',
    backgroundColor: 'transparent',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    top: 10,
    left: 10,
    width: 40,
    height: 40
  },
  goiViTriIcon: {
    width: 29,
    height: 36
  },
  price: {
    fontSize: 17,
    fontWeight: 'bold',
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 17,
    color: 'white'
  },
  text: {
    fontSize: 13,
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 17,
    marginBottom: 15,
    marginRight: 0,
    marginTop: 2,
    color: 'white',
    fontWeight: '300',
  },
  rowControl: {
    fontSize: 13,
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: gui.mainColor
  },
  pagingTitle: {
    fontSize: 13,
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'gray'
  },

  slide: {
    justifyContent: 'center',
    backgroundColor: 'transparent'
    //
  },
  linearGradient2: {
    marginTop: imgHeight / 2,
    height: imgHeight / 2,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor: "transparent"
  },
  thumb: {
    justifyContent: 'flex-end',
    alignItems: 'stretch',
    height: imgHeight,
    alignSelf: 'auto'
  },

  heartButton: {
    marginTop: 6,
    paddingRight: 25,
    paddingLeft: 0
  },
  image: {
    height: 200,
    alignSelf: 'stretch',
  },
  adsNoPosContainer: {
    position: 'absolute',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    top: imgHeight - 50,
    right: 21,
    width: 55,
    backgroundColor: 'transparent'
  },
  hideAdsContainer: {
    position: 'absolute',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    top: 5,
    right: 65,
    width: width-65,
    backgroundColor: 'transparent'
  }
});

module.exports = AdsRow;
