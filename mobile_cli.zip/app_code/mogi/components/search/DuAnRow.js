'use strict';

import React from 'react';
import { Image, StyleSheet, Text, View, TouchableOpacity, TouchableHighlight, ListView, ImageBackground} from 'react-native';
import {Actions} from 'react-native-router-flux';
import LinearGradient from 'react-native-linear-gradient';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';
import MHeartIcon from '../MHeartIcon';
// import FullLine from '../line/FullLine';

import CommonUtils from '../../lib/CommonUtils';
import gui from '../../lib/gui';
import GiftedSpinner from 'react-native-gifted-spinner';
import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();
import ScalableText from 'react-native-text';

var Analytics = require('react-native-firebase-analytics');

var imgHeight = 181;

var { createIconSet } = require('react-native-vector-icons');
var glyphMap = { 'heart':59457, 'heart-o':59458};
var Icon = createIconSet(glyphMap, 'TruliaIcon');


class DuAnRow extends React.Component {
  renderLikeIcon(ads) {
    //log.info("renderLikeIcon, ", ads.isLiked);
    let isLiked = this.isLiked(ads);
    let color = isLiked ? 'white' : 'white';
    let bgColor = isLiked ? '#E50064' : '#4A443F';
    let bgStyle = isLiked ? {} : {opacity: 0.55};

    if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == ads.adsID){
      return (
          <View style={{position: "absolute", left: width-45, backgroundColor:'transparent', top: -120}}>
            <View style={myStyles.heartButton}>
              <GiftedSpinner size="small" color="white"/>
            </View>
          </View>
      );
    } else {
      return (
        <View style={{position: "absolute", left: width-65, backgroundColor:'transparent', top: -120}}>
          <MHeartIcon onPress={() => this.onLike(ads)} color={color} bgColor={bgColor} bgStyle={bgStyle} size={22}
                      mainProps={myStyles.heartButton} />
        </View>
      )
    }
  }

  isLiked(ads) {
    const {adsLikes} = this.props;
    return adsLikes && adsLikes.indexOf(ads.adsID) > -1;
  }

  onLike(ads) {
    if (!this.props.loggedIn) {
      Actions.NewLogin();
    } else {
      let adsID = ads.adsID;
      let userID = this.props.userID;
      if (!this.isLiked(ads)) {
        Analytics.logEvent('SEARCH_LIKE', {adsID: adsID, userID: userID});
        this.props.likeAds(userID, adsID, this.props.updateLikeAdsProcessing);
      } else {
        Analytics.logEvent('SEARCH_UNLIKE', {adsID: adsID, userID: userID});
        this.props.unlikeAds(userID, adsID, this.props.updateLikeAdsProcessing);
      }
    }
  }

  renderImageStack(duAn) {
    return duAn.coverImage ?
        <MyImage imageIndex={0} duAn={duAn} imageUrl={duAn.coverImage} noCoverUrl={this.props.noCoverUrl}/>
        : <MyImage imageIndex={0} duAn={duAn} imageUrl={this.props.noCoverUrl} noCoverUrl={this.props.noCoverUrl}/>
  }

  getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
    var moreInfo = '';
    var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
    if (loaiNhaDat == loaiNhaDatKeys[1]) {
      moreInfo = ' ' + dienTich + soPhongNgu;
    }
    else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
      || (loaiNhaDat == loaiNhaDatKeys[3])
      || (loaiNhaDat == loaiNhaDatKeys[4])) ||
        loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[6]))) {
      moreInfo = ' ' + dienTich + soTang;
    }
    else {
      moreInfo = ' ' + dienTich;
    }
    return moreInfo;
  }

  render() {
    const {duAn} = this.props;

    let diaChi = duAn.place.diaChi || '';
    let originDiaChi = diaChi;
    let moreInfo = '';
    if (duAn.tongDienTichFmt && duAn.tongDienTichFmt != 'Không rõ') {
      moreInfo = ' ' + duAn.tongDienTichFmt;
    }

    let maxDiaChiLength = width*7/64 - moreInfo.length;

    let index = diaChi.indexOf(',', maxDiaChiLength - 5);
    let length = 0;
    if (index !== -1 && index <= maxDiaChiLength) {
      length = index;
    } else {
      index = diaChi.indexOf(' ', maxDiaChiLength - 5);
      length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
    }
    diaChi = diaChi.substring(0, length);
    if (diaChi.length < originDiaChi.length) {
      diaChi = diaChi + '...';
    }
    let currentTime = new Date().getTime();

    let firstControl = null;
    let lastControl = null;
    let {showFirstControl, isFirstRow, showLastControl, isLastRow, showFirstLoading} = this.props;

    if (isFirstRow) {
      if (this.props.loading) {
        if (showFirstLoading) {
          firstControl = <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
            <GiftedSpinner size="small"/>
          </View>;
        }
      } else {
        if (showFirstControl) {
          firstControl =
              <View>
              <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
                <TouchableHighlight onPress={this.props.loadPreviousPage} underlayColor="transparent">
                  <View style={{flexDirection: 'column'}}>
                    <Text style={myStyles.rowControl}>Nhấn vào đây để quay lại trang trước</Text>
                    <Text style={myStyles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                  </View>
                </TouchableHighlight>
              </View>
          </View>;
        }
      }
    }
    if (showLastControl && isLastRow) {
      lastControl =
          <View>
            <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
              <TouchableHighlight onPress={this.props.loadNextPage} underlayColor="transparent">
                <View style={{flexDirection: 'column'}}>
                  <Text style={myStyles.rowControl}>Nhấn vào đây để đi đến trang sau</Text>
                  <Text style={myStyles.pagingTitle}>{this.props.getPagingTitle()}</Text>
                </View>
              </TouchableHighlight>
            </View>
          </View>
            ;
    }
    return (
      <View key={duAn.duAnID} style={{flexDirection: 'column', overflow: 'hidden'}}>
        {firstControl}
        <TouchableHighlight
              onPress={() => Actions.DetailDuAn({duAnID: duAn.duAnID, imageDetail: duAn.coverImage})}
              style={myStyles.detail}
              onStartShouldSetResponder={(evt) => false}
              onMoveShouldSetResponder={(evt) => false}>
          <View>
            {this.renderImageStack(duAn)}

            <View style={myStyles.searchListViewRowAlign}
                  onStartShouldSetResponder={(evt) => false}
                  onMoveShouldSetResponder={(evt) => false}
            >
              <View
                onStartShouldSetResponder={(evt) => false}
                onMoveShouldSetResponder={(evt) => false}
                pointerEvents="none"
              >

                <ScalableText style={myStyles.price}
                      onStartShouldSetResponder={(evt) => false}
                      onMoveShouldSetResponder={(evt) => false}
                >{duAn.tenDuAn}</ScalableText>
                <ScalableText style={myStyles.text}>{diaChi}{moreInfo}</ScalableText>
              </View>
              {/*this.renderLikeIcon(duAn)*/}
            </View>
          </View>
        </TouchableHighlight>
        {lastControl}
      </View>
    );
  }
}

class MyImage extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    let imageUri = {uri: this.props.imageUrl};
    if (this.props.noCoverUrl == this.props.imageUrl) {
      imageUri = require('../../assets/image/reland_house_large.jpg');
    }
    return(
      <View style={myStyles.slide} key={"img"+(this.props.imageIndex)}>
        <TouchableOpacity onPress={() => this.showDuAnDetail()}>
          <ImageBackground style={myStyles.thumb} source={imageUri} defaultSource={CommonUtils.getNoCoverImage()} >
            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.55)']}
                            style={myStyles.linearGradient2}>
            </LinearGradient>
          </ImageBackground>
        </TouchableOpacity>
      </View>
    );
  }

  showDuAnDetail(){
    let duAn = this.props.duAn;
    Actions.DetailDuAn({duAnID: duAn.duAnID, imageDetail: duAn.coverImage});
  }
}

const myStyles = StyleSheet.create({
  detail: {
    flex: 0
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
    bottom: 32
  },
  wrapper: {
    backgroundColor: 'black'
  },
  searchListViewRowAlign: {
    position: 'absolute',
    backgroundColor: 'transparent',
    flexDirection: 'row',
    justifyContent: 'space-between',
    top: imgHeight - 57,
    width: width
  },
  logoContainer: {
    marginLeft: 12,
    justifyContent: "center",
    backgroundColor: '#009CD6',
    borderRadius: 5,
    width: 100,
    height: 22
  },
  logo: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white'
  },
  price: {
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 17,
    color: 'white'
  },
  text: {
    fontSize: 13,
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginLeft: 17,
    marginBottom: 15,
    marginRight: 0,
    marginTop: 2,
    color: 'white',
    fontWeight: '300',
  },
  rowControl: {
    fontSize: 13,
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: gui.mainColor
  },
  pagingTitle: {
    fontSize: 13,
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'gray'
  },

  slide: {
    justifyContent: 'center',
    backgroundColor: 'transparent'
    //
  },
  linearGradient2: {
    marginTop: imgHeight / 2,
    height: imgHeight / 2,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor: "transparent"
  },
  thumb: {
    justifyContent: 'flex-end',
    alignItems: 'stretch',
    height: imgHeight,
    alignSelf: 'auto'
  },

  heartButton: {
    marginTop: 6,
    paddingRight: 25,
    paddingLeft: 0
  },
  image: {
    height: 200,
    alignSelf: 'stretch',
  }
});

module.exports = DuAnRow;
