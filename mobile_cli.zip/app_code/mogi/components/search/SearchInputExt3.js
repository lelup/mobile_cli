'use strict';

import React, {Component} from 'react';


import {
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View,
    ScrollView,
    TouchableHighlight
} from 'react-native';

import gui from "../../lib/gui";
import {Actions} from 'react-native-router-flux';
import TruliaIcon from './../TruliaIcon';
import RelandIcon from '../RelandIcon';
import util from "../../lib/utils";
const {width, height} = util.getDimensions();

import GiftedSpinner from 'react-native-gifted-spinner';


export default class SearchInputExt3 extends Component {
    render() {
        let btnColor = '#526173';
        //bachtv them activeView = 'Home'
        let editable = this.props.activeView != 'SearchResult' && this.props.activeView != 'Home';
        let placeName = this.props.activeView == 'SearchResult' || this.props.activeView == 'Home' ? this.props.placeName : this.props.textValue;
        let widthIcon = this.props.activeView == 'GooglePlacesAutocomplete3' ? 0 : 26
        return(
            <View style={styles.container}>
                <View style={styles.searchContainer}>
                <TouchableOpacity
                    accessible={true}
                    onPress={() => {this.props.onSuggestPress && this.props.onSuggestPress(); this.refs.textInput.focus()}}
                    disabled={this.props.disabled}
                    style={{flex: 1}}>
                <View style={{flexDirection: 'row'}}
                      onStartShouldSetResponder={(evt) => false}
                      onMoveShouldSetResponder={(evt) => false}
                      pointerEvents="none">
                    <View style={[styles.viewIconChange, {width: widthIcon}]}>
                        {this._renderSearchButton()}
                    </View>
                    <TextInput ref="textInput"
                               autoCorrect={false}
                               autoFocus={this.props.autoFocus}
                               onChangeText={this.props.onChangeText}
                               style={[styles.titleText, {color: btnColor}]}
                               editable={editable} value={placeName}
                               placeholder={this.props.placeholder}
                               onFocus={this.props.onFocus}
                               placeholderTextColor={gui.arrowColor}
                               selectionColor={'rgba(255,255,255,0.5)'}
                               clearButtonMode="never"
                               selectTextOnFocus={true}
                               allowFontScaling={false}
                               blurOnSubmit={false}
                    />
                </View>
                </TouchableOpacity>
                
                </View>
            </View>
        )
    }

    _renderCloseButton() {
        return (
            this.props.showCloseButton ? <RelandIcon name="close-circle-f" size={18} color={'#fff'}
                                                     mainProps={{flexDirection: 'row', paddingTop: 1, paddingLeft: 5, paddingRight: 7}}
                                                     textProps={{paddingLeft: 0}}
                                                     onPress={() => {this.props.onChangeText('')}} /> : null
        );
    }

    focusInputSearch() {
        this.refs.textInput.focus();
    }

    _renderSearchButton() {
        if (this.props.activeView == 'GooglePlacesAutocomplete3') {
            return (<View></View>)
        }
        if (this.props.isHeaderLoading && this.props.isHeaderLoading()){
            return (
                <View style={{paddingRight: 7, marginLeft: 10, marginTop: 3, backgroundColor: 'transparent', width: 22, alignItems: 'center'}}>
                    <GiftedSpinner size="small" color="#fff" />
                </View>
            )
        } else {
            let btnColor = this.props.disabled ? '#C5C2BA' : 'white';
            return (
                <RelandIcon name="search-b" size={15} color={btnColor}
                            iconProps={{marginRight: 0}}
                            mainProps={[styles.searchIcon, {flexDirection: 'row'}]}
                            textProps={{paddingLeft: 0}}/>
            )
        }

    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'transparent',
        top: 0,
        position: 'absolute',
        left:0,
        right:0,
        bottom: 0,
        height: 50
    },
    searchIcon: {
        marginLeft: 8,
        marginRight: 0,
        marginTop: 6
    },
    searchContainer: {
        marginTop: 0,
        marginBottom: 0,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'transparent',        
        marginLeft: 0,
        marginRight: 0,
        height: 26
    },
    textInput : {
        fontSize: 15,
        height: 30,
        borderRadius: 5
    },
    autocompleteContainer: {
        flex: 1,
        left: 0,
        position: 'absolute',
        right: 0,
        top: 15

    },
    inputContainerStyle: {
        borderRadius:5
    },

    itemText: {
        fontSize: 15,
        margin: 2
    },
    info: {
        paddingTop: 60,
        flex:4
    },
    infoText: {
        textAlign: 'center'
    },
    titleText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        paddingLeft: 5,
        color: 'red',
        backgroundColor: 'transparent',
        flex: 1,
        paddingVertical: 0
    },
    directorText: {
        color: 'grey',
        fontSize: 12,
        marginBottom: 10,
        textAlign: 'center'
    },
    openingText: {
        textAlign: 'left'
    },
    viewIconChange: {
        width: 26,
        height: 26,
        backgroundColor: 'transparent'
    }

});
