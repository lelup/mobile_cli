// Import some code we need
import React, {Component} from 'react';

import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import TruliaIcon from './../TruliaIcon';

import RelandIcon from './../RelandIcon';

import {Actions} from 'react-native-router-flux';

import gui from '../../lib/gui';

import SearchInputExt from './SearchMapInputExt';

import ScalableText from 'react-native-text';

import utils from '../../lib/utils';

var {width, height} = utils.getDimensions();

// Create our component
var CommonHeader = React.createClass({
  render: function() {
    let isNotFoundAds = this.props.isNotFoundAds && this.props.isNotFoundAds();
    let textColor = this.props.owner == 'map' && isNotFoundAds ? 'white' : 'white';
    return <View style={mStyles.container}>
      <View style={mStyles.home}>
      <TruliaIcon onPress={this._onHome}
                  name="arrow-left" color={"white"}
                  mainProps={{paddingLeft: 20, paddingRight: 12}} size={26} />
          {/* <RelandIcon onPress={this._onHome}
        name="close" color="white" size={18}
        mainProps={{flexDirection: 'row', paddingLeft: 20, paddingRight: 17}}
        >
      </RelandIcon>*/}
      </View>
      <View style={mStyles.text}>
        <SearchInputExt placeName={this.props.placeName} refreshRegion={this.props.refreshRegion}
                           onShowMessage={this.props.onShowMessage} isHeaderLoading={this.props.isHeaderLoading}
                           loadHomeData={this.props.loadHomeData} owner={this.props.owner}/>
      </View>
      <View style={mStyles.search}>
      <TouchableOpacity onPress={this._onSearch} underlayColor="transparent"
        style={{paddingLeft: 7, paddingRight: 15}}
        >
          <ScalableText style={[mStyles.titleText, {color: textColor}]}>Lọc</ScalableText>
      </TouchableOpacity>
      </View>
    </View>
  },

  _onHome: function() {
    Actions.Home({type:"reset"});
  },

  _onSearch: function(){
    Actions.Search2({needBack:true, onShowMessage: this.props.onShowMessage, refreshRegion: this.props.refreshRegion,
        owner: this.props.owner, refreshAllMarkers: this.props.refreshAllMarkers});
  }
});

// Make this code available elsewhere
module.exports = CommonHeader;

var mStyles = StyleSheet.create({
  container: {
      top: 0,
      flexDirection: 'row',
      alignItems: 'stretch',
      justifyContent: 'space-between',
      backgroundColor: 'transparent',
      height: 64
  },
  search: {
      marginTop: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent'
  },
  home: {
      marginTop: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent'
  },
  text: {
    backgroundColor: 'transparent',
    position: 'absolute',
    left:50,
    right:40,
    width:width-90
  },
  titleText: {
      backgroundColor: 'transparent',
      color: gui.mainColor,
      fontFamily: gui.fontFamily,
      fontSize: 17,
      fontWeight: '600',
      paddingBottom:4,
  }
});
