// Import some code we need
import React, {Component} from 'react';

import {View, Text, StyleSheet, TouchableOpacity, StatusBar} from 'react-native';

import TruliaIcon from './../TruliaIcon';

import RelandIcon from './../RelandIcon';

import {Actions} from 'react-native-router-flux';

import gui from '../../lib/gui';

import PropTypes from 'prop-types';

import SearchInputExt from './SearchInputExt2';

// Create our component
class SearchHeaderFlip extends Component {

    constructor(props) {
        super(props)
        StatusBar.setBarStyle('dark-content');
    }

   static propTypes = {
        autoFocus: PropTypes.bool,
        onChangeText: PropTypes.func,
        textValue: PropTypes.string,
        placeholder: PropTypes.string,
        onFocus: PropTypes.func,
        showCloseButton: PropTypes.bool
    };
   static defaultProps = {
            autoFocus: false,
            onChangeText: () => {},
            textValue: '',
            placeholder: '',
            onFocus: () => {},
            showCloseButton: false
        } ;

  render () {
    let showBackButton = this.props.activeView == 'SearchResult' && !this.props.searchFilterActived;
    let textInputLeft = showBackButton ? 40 : 15;
    let hideFilter = this.props.activeView == 'Home';
    let filterRight = hideFilter ? 5 : 40;
    return <View style={mStyles.container}>
      <View style={mStyles.home}>
          {showBackButton ? <TruliaIcon onPress={this.props.onBackPress}
           name="arrow-left" color="white" size={26}
           mainProps={{paddingLeft: 20, paddingRight: 12}}
           >
           </TruliaIcon> : null}
      </View>
      <View style={[mStyles.text, {left: textInputLeft, right: filterRight}]}>
        <SearchInputExt    ref="searchInputExt"
                           placeName={this.props.placeName} refreshRegion={this.props.refreshRegion}
                           onShowMessage={this.props.onShowMessage} isHeaderLoading={this.props.isHeaderLoading}
                           loadHomeData={this.props.loadHomeData} owner={this.props.owner}
                           resetAllMarkers={this.props.resetAllMarkers}
                           onChangePositionSearch={this.props.onChangePositionSearch}
                           onSuggestPress={this.props.onSuggestPress}
                           onSelectPress={this.props.onSelectPress}
                           activeView={this.props.activeView}
                           autoFocus={this.props.autoFocus}
                           onChangeText={this.props.onChangeText}
                           textValue={this.props.textValue}
                           placeholder={this.props.placeholder}
                           onFocus={this.props.onFocus}
                           showCloseButton={this.props.showCloseButton}
                           disabled={this.props.disabled} />
      </View>
      <View style={mStyles.search}>
          {this._renderFilterButton()}
      </View>
    </View>
  }
  _renderFilterButton() {
      let btnColor = this.props.disabled ? gui.arrowColor : gui.mainColor;
      
      if (this.props.activeView == 'Home') {
          return (
          <View style={{backgroundColor:'transparent'}}></View>
        )
      }
      if (this.props.activeView == 'SearchResult' && !this.props.searchFilterActived) {
          return (
              <RelandIcon onPress={this._onSearch.bind(this)}
                          disabled={this.props.disabled}
                          name="filter-o" color={btnColor} size={22}
                          mainProps={{flexDirection: 'row', paddingLeft: 10, paddingRight: 10}}
              >
              </RelandIcon>
          );
      } 
      else {
          return (
              
              //bachtv rao nut Huy - ko rao nua hehe
              <TouchableOpacity onPress={this._onSearch.bind(this)} underlayColor="transparent" disabled={this.props.disabled}
                                style={{paddingLeft: 10, paddingRight: 10, height:30}}
              >
                  <Text style={[mStyles.titleText, {color: btnColor}]}>Hủy</Text>
              </TouchableOpacity>
          );
      }
  }
  focusInputSearch() {
      this.refs.searchInputExt.focusInputSearch();
  }

  // _onHome: function() {
  //   Actions.Home({type:"reset"});
  // },

  _onSearch (){
    if (this.props.activeView == 'SearchResult') {
        // Actions.Search2({needBack:true, onShowMessage: this.props.onShowMessage, refreshRegion: this.props.refreshRegion,
        //     owner: this.props.owner, resetAllMarkers: this.props.resetAllMarkers, 
        //     deviceID: this.props.deviceID, userID: this.props.userID});
        this.props.onSearchFilterPress && this.props.onSearchFilterPress();
    } else {
        this.props.onCancelPress && this.props.onCancelPress();
    }
  }
}

// Make this code available elsewhere
export default SearchHeaderFlip;

const mStyles = StyleSheet.create({
  container: {
      top: 0,
      flexDirection: 'row',
      alignItems: 'stretch',
      justifyContent: 'space-between',
      //backgroundColor: gui.mainColor,
      backgroundColor: 'transparent',
      height: 64
  },
  search: {
      marginTop: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent',
      //backgroundColor: gui.mainColor
  },
  home: {
      marginTop: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent',
      //backgroundColor: gui.mainColor
  },
  text: {
    backgroundColor: 'transparent',
    position: 'absolute',
    left:40,
    right: 40 //bachtv
  },
  titleText: {
      backgroundColor: 'transparent',
      color: 'white',
      fontFamily: gui.fontFamily,
      fontSize: 17,
      fontWeight: '600',
      marginTop: 3
  }
});
