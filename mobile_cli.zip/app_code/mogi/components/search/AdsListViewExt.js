'use strict';

import AdsRow from './AdsRow';
import React from 'react';
import { StyleSheet, ListView, View, Text, RefreshControl,
    TouchableOpacity, AlertIOS, Alert, Image, ImageBackground } from 'react-native';
import gui from '../../lib/gui';
var myDs = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
import log from '../../lib/logUtil';
import GiftedSpinner from 'react-native-gifted-spinner';
import {Actions} from 'react-native-router-flux';
import findApi from '../../lib/FindApi';
import utils from '../../lib/utils';
import CommonUtils from '../../lib/CommonUtils';
var {width, height} = utils.getDimensions();
import ScalableText from 'react-native-text';
let imageUriHome = require('../../assets/image/default_cover/no_cover_03.jpg');

class AdsListViewExt extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nextBtnPressed: false
    }
  }
  componentDidMount() {
    this.reachBottom = false;
  }
  _scrollToTop() {
    let query = this.props.getQuery();
    let pageNo = !query ? 1 : query.pageNo;

    if (pageNo == 1 || !this.state.nextBtnPressed) {
      setTimeout(() => this._scrollTo(0), 100);
    } else {
      setTimeout(() => this._scrollTo(40), 100);
    }
  }
  _scrollTo(pos) {
    if (this._listView) {
      this._listView.scrollTo({y: pos});
    }
  }
  render() {
    log.info("Call AdsListView.render");

    let myProps = this.props;

    let query = myProps.getQuery();

    let searchText = query ? findApi.convertQuery2String(query) : "";

    if ((myProps.mounting || myProps.loading) && myProps.listAds.length === 0) {
      return (
        <View style={styles.viewLoaderAds}>
          <ImageBackground style={styles.viewChildRow}
                 source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
          >
            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]}></View>
            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]}></View>
          </ImageBackground>
          <ImageBackground style={styles.viewChildRow}
                 source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
          >
            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]}></View>
            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]}></View>
          </ImageBackground>
          <ImageBackground style={styles.viewChildRow}
                 source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
          >
            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]}></View>
            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]}></View>
          </ImageBackground>
          <ImageBackground style={styles.viewChildRow}
                 source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
          >
            <View style={[styles.viewLineLoaderRow, {width: 38, height: 15 }]}></View>
            <View style={[styles.viewLineLoaderRow, {marginBottom: 21}]}></View>
          </ImageBackground>
        </View>
      )
    }

    if (myProps.listAds.length === 0 || myProps.errorMsg) {
      let imageUri = require('../../assets/image/no_result_list.png');
      let msg = myProps.errorMsg || 'Không tìm thấy kết quả nào!';
      return (
        <View style={styles.viewNoneResult}>
          <View style={styles.viewNoneTop}>
            <ScalableText style={styles.textTopNone}>{msg}</ScalableText>
          </View>
          <View style={[styles.viewNoneTop, styles.viewNoneMiddle]}>
            <View style={styles.viewDieuKien}>
              <ScalableText style={styles.textDieuKien}>Điều kiện lọc hiện tại:</ScalableText>
              <ScalableText style={styles.textDieuKienDetail}>{searchText}</ScalableText>
            </View>
          </View>
          <View style={[styles.viewNoneTop, styles.viewNoneBottom]}>
            <Image style={styles.imageNoneResult} resizeMode={'cover'} source={imageUri}/>
          </View>

        </View>
      )
    }

    let ds = myDs.cloneWithRows(myProps.listAds);

    return (
        <ListView
            ref={(listView) => { this._listView = listView; }}
            dataSource={ds}
            renderRow={(rowData, sectionID, rowID) => this.renderRow(rowData, sectionID, rowID, (rowID == 0), (rowID == (ds._dataBlob.s1.length-1)))}
            stickyHeaderIndices={[]}
            // initialListSize={25}
            // onEndReachedThreshold={200}
            // onEndReached={this.loadNextPage.bind(this)}
            renderFooter={this.renderFooter.bind(this)}
            // scrollRenderAheadDistance={3}
            // pageSize={5}
            onScroll={this.handleScroll.bind(this)}
            scrollEventThrottle={200}
            //renderSeparator={(sectionID, rowID) => <View key={`${sectionID}-${rowID}`} style={styles.separator} />}
            style={styles.searchListView}
        />
    );
  }

  renderFooter () {
    return this.props.loading ? <View style={{flex: 0, height: 40, alignItems: 'center', justifyContent: 'center'}}>
        <GiftedSpinner size="small" color={gui.mainColor} />
      </View> : null
  }

  _handleSearchAction(newPageNo, newDiaChinh, newPolygon, newCenter){
    var {loaiTin, ban, thue, soPhongNguSelectedIdx, soNhaTamSelectedIdx,
        radiusInKmSelectedIdx, dienTich, orderBy, viewport, diaChinh, center, huongNha, ngayDaDang,
        polygon, pageNo} = this.props.fields;
    var fields = {
      loaiTin: loaiTin,
      ban: ban,
      thue: thue,
      soPhongNguSelectedIdx: soPhongNguSelectedIdx,
      soNhaTamSelectedIdx : soNhaTamSelectedIdx,
      dienTich: dienTich,
      orderBy: orderBy,
      viewport: viewport,
      diaChinh: newDiaChinh || diaChinh,
      center: newCenter || center,
      radiusInKmSelectedIdx: radiusInKmSelectedIdx,
      huongNha: huongNha,
      ngayDaDang: ngayDaDang,
      polygon: newPolygon || polygon,
      pageNo: newPageNo || pageNo,
      limit: this.props.limit,
      isIncludeCountInResponse: true,
      userID: this.props.userID || undefined,
      deviceID: this.props.deviceID || undefined};

    this.props.actions.searchExt(
        fields
        , () => {this.props.scrollToTop();}
        , (error) =>
            Alert.alert('Thông báo',
                error,
                [{
                  text: 'Đóng',
                  onPress: () => {}
                }]));
  }

  handleScroll(event: Object) {
    let pos = event.nativeEvent.contentOffset.y;
    this.reachBottom = pos > 100;
  }

  renderRow(rowData = {}, sectionID, rowID, isFirstRow, isLastRow) {
    let myProps = this.props;

    let query = this.props.getQuery();

    let pageNo = !query ? 1 : query.pageNo;
    let totalPages = myProps.totalCount/ myProps.limit;

    let showFirstLoading = pageNo > 2 || (!this.reachBottom && !myProps.mounting);
    let showFirstControl = pageNo > 1;
    let showLastControl = !myProps.loading && totalPages && pageNo < totalPages;

    return (
      <AdsRow ads={rowData} noCoverUrl={this.props.noCoverUrl}
              userID = {this.props.userID}
              likeAds = {this.props.actions.likeAds}
              unlikeAds = {this.props.actions.unlikeAds}
              loggedIn = {this.props.loggedIn}
              adsLikes={this.props.adsLikes}
              isFirstRow={isFirstRow}
              showFirstControl={showFirstControl}
              showFirstLoading={showFirstLoading}
              isLastRow={isLastRow}
              showLastControl={showLastControl}
              loadPreviousPage={() => this.loadPreviousPage()}
              loadNextPage={() => this.loadNextPage()}
              getPagingTitle={this.getPagingTitle.bind(this)}
              loading={this.props.loading}
              uploadingLikedAds={this.props.uploadingLikedAds}
              updateLikeAdsProcessing={this.props.updateLikeAdsProcessing}
              owner={'SearchResultListExt'}
              onHideAds={this.props.onHideAds}
              isHiddenAds={this.props.isHiddenAds}/>
    );
  }

  loadPreviousPage() {
    let myProps = this.props;
    if (myProps.loading) {
      return;
    }

    let query = this.props.getQuery();

    let pageNo = !query ? 1 : query.pageNo;

    if (pageNo > 1) {
      pageNo = pageNo-1;
      this.setState({nextBtnPressed: false});
      if (query) {
        this.props.actions.onResetAdsExtList();
        query.pageNo = pageNo;
        this.props.actions.searchFromHome(query, () => {this.props.scrollToTop()}
            , (error) =>
            Alert.alert('Thông báo',
                error,
                [{
                  text: 'Đóng',
                  onPress: () => {}
                }]));
      }
    }
  }

  loadNextPage() {
    let myProps = this.props;
    if (myProps.loading) {
      return;
    }

    let query = this.props.getQuery();
    
    let pageNo = !query ? 1 : query.pageNo;
    let totalPages = myProps.totalCount/ myProps.limit;

    if (totalPages && pageNo < totalPages) {
      pageNo = pageNo+1;
      this.setState({nextBtnPressed: true});
      if (query) {
        this.props.actions.onResetAdsExtList();
        query.pageNo = pageNo;
        this.props.actions.searchFromHome(query, () => {this.props.scrollToTop()}
            , (error) =>
                Alert.alert('Thông báo',
                    error,
                    [{
                      text: 'Đóng',
                      onPress: () => {}
                    }]));
      }
    }
  }

  getPagingTitle() {
    let myProps = this.props;
    let numberOfAds = myProps.listAds.length;
    let totalCount = myProps.totalCount;

    let query = this.props.getQuery();

    let pageNo = !query ? 1 : query.pageNo;
    let limit = myProps.limit;
    let totalPages = totalCount/ limit;
    let beginAdsIndex = (pageNo-1)*limit+1;
    let endAdsIndex = (pageNo-1)*limit+numberOfAds;
    if (totalCount < endAdsIndex) {
      totalCount = endAdsIndex;
    }
    if (pageNo == totalPages) {
      totalCount = endAdsIndex;
    }
    let title = (beginAdsIndex > 1 || totalCount > endAdsIndex) ? 'Đang hiển thị từ ' + beginAdsIndex + "-" + endAdsIndex + ' / ' + totalCount + ' kết quả' :
    'Đang hiển thị ' + numberOfAds + ' kết quả';
    return title;
  }
}
const styles = StyleSheet.create({
  viewNoneResult: {
    flex: 1,
    backgroundColor: 'transparent'
  },
    viewNoneTop: {
      flex: 1,
      backgroundColor: 'transparent',
      justifyContent: 'center',
      alignItems: 'center'
    },
    viewNoneMiddle: {
      backgroundColor: '#fff'
    },
    viewNoneBottom: {
      backgroundColor: 'transparent',
      justifyContent: 'flex-start',
      marginBottom: 30
  },
    viewDieuKien: {
      justifyContent: 'center',
      alignItems: 'center',
      flex: 1,
      marginLeft: 5,
      marginRight: 5
    },
    viewResetFilter: {
      justifyContent: 'center',
      alignItems: 'center',
      width: 240,
      height: 38,
      borderWidth: 1,
      borderColor: gui.mainColor,
      borderRadius: 6,
      marginBottom: 6
    },
    textTopNone: {
      fontFamily: gui.fontFamily,
      fontWeight: '600',
      fontSize: 22,
      color: '#3a3a3c',
      marginTop: width/4 -19
    },
    textDieuKien: {
      fontFamily: gui.fontFamily,
      fontWeight: '500',
      fontSize: 17,
      color: '#58585a'
    },
    textDieuKienDetail: {
      fontFamily: gui.fontFamily,
      fontSize: 12,
      color: '#6e6f71',
      fontWeight: '300'
  },
    textReserFilter: {
      color: gui.mainColor,
      fontFamily: gui.fontFamily,
      fontSize: 17,
      fontWeight: '500',
    },
    imageNoneResult:{
      // width: width,
      // height: 200
        transform: [
            {scaleX: 0.4},
            {scaleY: 0.4}
        ]
    },
  welcome: {
    marginTop: -50,
    marginBottom: 50,
    fontSize: 17,
    textAlign: 'center',
    margin: 10,
  },
  separator: {
    height: 1,
    backgroundColor: '#CCCCCC',
  },
  searchListView: {
    marginTop: 0,
    margin: 0,
    backgroundColor: 'white'
  },
  allRegion: {
    margin: 9,
    padding: 4,
    paddingLeft: 58,
    paddingRight: 58,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: gui.mainColor,
    borderRadius: 5,
    borderColor: 'transparent'
  },
  allRegionButton: {
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15
  },
    viewChildRow: {
        width: width,
        height: 181,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingLeft: 17,
        borderBottomWidth: 1,
        borderColor: '#eaebed'
    },
    viewLineLoaderRow: {
        height: 14,
        width: width/3,
        backgroundColor: 'rgba(234, 234, 234, 0.5)',
        marginBottom: 8
    },
    viewLoaderAds: {
        flex:1,
        alignItems:'center',
        justifyContent:'flex-start',
  }
});

module.exports = AdsListViewExt;
