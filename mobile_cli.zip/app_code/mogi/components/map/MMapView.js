'use strict';

import React, {Component} from 'react';

import { Text, View, StyleSheet, Navigator, TouchableOpacity,
    TouchableHighlight, StatusBar } from 'react-native'

import {Actions} from 'react-native-router-flux';
import MapView from 'react-native-maps';
import Button from 'react-native-button';

import CommonHeader from '../CommonHeader';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import findApi from '../../lib/FindApi';

import apiUtil from '../../lib/ApiUtils';

import placeUtil from '../../lib/PlaceUtil';

import RelandIcon from '../RelandIcon';

import utils from '../../lib/utils';

import ScalableText from 'react-native-text';

var { width, height } = utils.getDimensions();

const ASPECT_RATIO = width / (height-110);
const LATITUDE = 20.95389909999999;
const LONGITUDE = 105.75490945;
const LATITUDE_DELTA = 0.00616620000177733;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

/**
 * ## Redux boilerplate
 */

class MMapView extends Component {

  constructor(props) {
    log.info("Call PostAdsMapView.constructor");
    super(props);
    StatusBar.setBarStyle('default');

    var location = props.location;
    var region ={}
    if (!location || !location.lat ||location.lat == '') {
      region.latitude = LATITUDE;
      region.longitude = LONGITUDE;
    } else{
      region.latitude = location.lat;
      region.longitude = location.lon;
    }
    region.latitudeDelta = LATITUDE_DELTA;
    region.longitudeDelta = LONGITUDE_DELTA;
    

    this.state = {
      showSuggestionPosition: props.showSuggestionPosition || false,
      region: region,
      firstRegion: region,
      enableRegionChange: false,
      diaChi: null,
      mapType: "standard",
      mapName: "Satellite"
    }
  }

  componentDidMount() {
    this.setState({enableRegionChange: true});
  }

  render() {
    log.info("Call PostAdsMapView.render");

    return (
        <View style={styles.fullWidthContainer}>

          <View style={styles.search}>
            <CommonHeader backTitle={"Trở lại"} />
            <View style={styles.headerSeparator} />
          </View>

          <View style={styles.map}>
            <MapView
              region={this.state.region}
              style={styles.mapView}
              mapType={this.state.mapType}
              onRegionChange={this._onRegionChange.bind(this)}
              onRegionChangeComplete={this._onRegionChangeComplete.bind(this)}
            >
            </MapView>

            {this._renderGooglePlaceAutoComplete()}

            <View style={styles.positionIcon}>
              <RelandIcon name="home-marker" color={gui.mainColor}
                          size={30} textProps={{paddingLeft: 0}}
                          />
            </View>

            {this._renderButtonOnMap()}

            <View style={styles.mapButtonContainer}>
              <View style={styles.searchListButton}>
                <Button onPress={this._onCancel.bind(this)}
                        style={styles.buttonText}>Hủy</Button>
                <Button onPress={this._onApply.bind(this)}
                        style={styles.buttonText}>Chọn</Button>
              </View>
            </View>
          </View>
        </View>
    )
  }

  _renderGooglePlaceAutoComplete(){
    return (
        <TouchableHighlight onPress={this._onPress.bind(this)} style={styles.touchSearch}>
          <View style={styles.searchTextContainer}>
            <View style={styles.viewIconSearch}>
              <RelandIcon name="search" color='#8a8a8a' mainProps={{ top: 10, marginLeft: 6 }}
                          size={18} textProps={{}}
              />
            </View>
            <View style={styles.viewSearch}>
              <ScalableText style={styles.searchTextBottom}>
                  {this._getdiaChi()}
              </ScalableText>
            </View>
          </View>
        </TouchableHighlight>
    );
  }

  _getdiaChi() {
      var diaChi = this.state.diaChi;

      if (!diaChi || diaChi.length <= 0)
          return 'Chọn địa điểm';

      if (diaChi.length > 40) {
          diaChi = diaChi.substring(0, 40) + '...';
      }

      return diaChi;
  }

  _onPress(){
    log.info("PostAdsMapView press place");
    Actions.PostAdsGoogleAutoComplete({onSuggestionPressed: (location)=>this._setRegionFromGoogleAutoComplete(location)});
  }

  _renderButtonOnMap(){
    return (
        <View style={styles.inMapButtonContainer}>
          {this._renderSuggestionPositionButton()}
          {this._renderCurrentPositionButton()}
        </View>
    );
  }
  _renderCurrentPositionButton() {
    return (
        <View >
          <TouchableOpacity onPress={this._onCurrentLocationPress.bind(this)} >
            <View style={[styles.bubble, styles.button, {marginTop: 10}]}>
              <RelandIcon name="direction" color='black' mainProps={{flexDirection: 'row'}}
                          size={20} textProps={{paddingLeft: 0}}
                          noAction={true}></RelandIcon>
            </View>
          </TouchableOpacity>
        </View>
    );
  }

  _renderSuggestionPositionButton() {
    if (!this.props.showSuggestionPosition)
        return;

    return (
        <View >
          <TouchableOpacity onPress={this._onSuggestionLocationPress.bind(this)} >
            <View style={[styles.bubble, styles.button, {flexDirection: 'column'}]}>
              <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                <RelandIcon name="plus" color={'black'}
                            mainProps={{flexDirection: 'row'}}
                            size={22} textProps={{paddingLeft: 0}}
                            noAction={true}></RelandIcon>
                <Text style={[styles.positionSuggetionIconText, {color: 'black'}]}>Gợi ý</Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
    );
  }

  _onCurrentLocationPress() {
    navigator.geolocation.getCurrentPosition(
        (position) => {
          var region = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA
          };
          this.setState({region: region});
          findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
        },
        (error) => {
          log.warn(error);
        },
        {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
    );
  }

  _onSuggestionLocationPress() {
    let region = this.state.firstRegion;
    this.setState({region: region});
    findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
  }

  _setRegionFromGoogleAutoComplete(location){

    let region = apiUtil.getRegionByViewport(location.viewport);
    this.setState({region: region});
    findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
    Actions.pop();
  }

  _onRegionChange(region) {
    if (!this.state.enableRegionChange) {
      return;
    }
    this.setState({region: region});
  }

  _onRegionChangeComplete(region) {
    if (!this.state.enableRegionChange) {
      return;
    }
    this.setState({region: region});
    findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
  }

  _onApply() {
    var {region} = this.state;
    findApi.getGeocoding(region.latitude, region.longitude, this.geoCallback.bind(this));
    Actions.pop();
  }

  _getDiaChinhContent(data){
    let diaChinh = placeUtil.parseDiaChinh(data);

    let {tinh, huyen, xa, diaDiem} = diaChinh;

    let fullName = tinh;
    if (huyen && huyen!=''){
      fullName = huyen + ', ' + fullName;
    }

    if (xa && xa!=''){
      fullName = xa + ', ' + fullName;
    }

    if (diaDiem && diaDiem.length >0){
      fullName = diaDiem + ', ' + fullName;
    }

    this.setState({diaChi: fullName});
  }

  geoCallback(data) {
    let location = {};
    var {region} = this.state;
    location.lat = region.latitude;
    location.lon = region.longitude;
    let diaChinh = placeUtil.parseDiaChinh(data);

    let {tinh, huyen, xa} = diaChinh;
    diaChinh.tinhKhongDau = utils.locDau(tinh);
    diaChinh.huyenKhongDau = utils.locDau(huyen);
    diaChinh.xaKhongDau = utils.locDau(xa);

    var placeType = 'T';
    if (diaChinh.huyenKhongDau)
      placeType = 'H';
    if (diaChinh.xaKhongDau)
      placeType = 'X';

    var diaChinhDto = {
      tinhKhongDau: diaChinh.tinhKhongDau || undefined,
      tinh: diaChinh.tinh,
      huyenKhongDau: diaChinh.huyenKhongDau || undefined,
      huyen: diaChinh.huyen,
      xaKhongDau: diaChinh.xaKhongDau || undefined,
      xa: diaChinh.xa,
      placeType: placeType
    }

    let position = {
      location: location,
      diaChi: this.state.diaChi,
      diaChinh: diaChinhDto
    }

    this.props.onPress(position);

  }

  _onCancel() {
    Actions.pop();
  }
}

// Later on in your styles..
var styles = StyleSheet.create({
  headerSeparator: {
    marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: gui.separatorLine
  },
  fullWidthContainer: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: 'white',
  },
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  searchListButtonText: {
    marginLeft: 15,
    marginRight: 15,
    marginTop: 0,
    marginBottom: 0,
    flexDirection: 'column',
  },
  map: {
    flex: 1,
    marginTop: 0,
    marginBottom: 0
  },
  mapView: {
    flex: 1,
    marginTop: 0,
    marginBottom: 0
  },
  title: {
    top:0,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
    backgroundColor: 'white'
  },
  search: {
    top:0,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
  },
  mapIcon: {
    color: 'white',
    textAlign: 'center'
  },
  text: {
    color: 'white'
  },
  mapButtonContainer: {
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    width: width,
    backgroundColor: 'transparent'
  },
  buttonText: {
    marginLeft: 17,
    marginRight: 17,
    marginTop: 10,
    marginBottom: 10,
    color: 'white',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight : 'normal'
  },
  searchListButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width,
    backgroundColor: gui.mainColor,
    height: 44
  },
  searchTextContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 28,
    width: width
  },
  searchText: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    textAlign: 'center',
    paddingLeft:2,
    paddingRight: 2,
    backgroundColor:'transparent'
  },
  positionIcon: {
    position: 'absolute',
    top: (height-60-25-60)/2,
    left: width/2 - 10,
    justifyContent: 'center',
    borderColor: gui.mainColor,
    backgroundColor: 'transparent'
  },
  inMapButtonContainer: {
    position: 'absolute',
    bottom: 80,
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginVertical: 5,
    marginBottom: 0,
    backgroundColor: 'transparent',
  },
  bubble: {
    backgroundColor: gui.mainColor,
    paddingHorizontal: 5,
    paddingVertical: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#C5C2BA',
    alignItems: 'center',
    justifyContent: 'center'
  },
  button: {
    width: 43,
    height: 38,
    paddingVertical: 5,
    alignItems: 'center',
    marginVertical: 5,
    backgroundColor: 'white',
    opacity: 0.9,
    marginLeft: 15
  },
  positionSuggetionIconText: {
    fontSize: 9,
    fontFamily: gui.fontFamily,
    fontWeight : 'normal',
    textAlign: 'center',
    backgroundColor:'transparent'
  },
  touchSearch:{
    position: 'absolute',
    top: 15,
    borderRadius:4,
    paddingLeft:0,
    marginLeft:15,
    marginRight:15,
    marginTop: 5,
    height:30,
    width:width - 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderWidth:1,
    borderColor:'lightgray',
    opacity: 0.9,
  },
  viewSearch:{
    width:width-65,
    height:28,
    right:20,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
    backgroundColor:'transparent',
  },
  searchTextBottom: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    textAlign: 'left',
    paddingTop:5,
    backgroundColor:'transparent',
    fontWeight:'400',
    width:width-65,
    height:28,
    color:'#1d1d1d'
  },
  viewIconSearch: {
    height: 28,
    width: 28,
    backgroundColor: 'transparent',
    left: 20,
    justifyContent: 'center',
    alignItems: 'flex-start'
  }
});

export default MMapView;