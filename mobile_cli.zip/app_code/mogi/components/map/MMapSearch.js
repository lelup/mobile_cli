'use strict';

import React, {Component} from 'react';

import { Text, View, StyleSheet, Navigator, TouchableOpacity,
    TouchableHighlight, StatusBar, Alert } from 'react-native'

import {Actions} from 'react-native-router-flux';
import MapView from 'react-native-maps';
import Button from 'react-native-button';

import TruliaIcon from '../TruliaIcon';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import findApi from '../../lib/FindApi';

import placeUtil from '../../lib/PlaceUtil';

import apiUtils from '../../lib/ApiUtils';

import RelandIcon from '../RelandIcon';

import utils from '../../lib/utils';

import LocationMarker from '../marker/LocationMarker';

import Slider from 'react-native-slider';

import ScalableText from 'react-native-text';

const { width, height } = utils.getDimensions();

const ASPECT_RATIO = width / (height-110);
const LATITUDE = 20.95389909999999;
const LONGITUDE = 105.75490945;
const LATITUDE_DELTA = 0.00616620000177733;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

/**
 * ## Redux boilerplate
 */

class MMapSearch extends Component {

    constructor(props) {
        log.info("Call MMapSearch.constructor");
        super(props);
        StatusBar.setBarStyle('default');

        var location = props.location;

        var region ={}
        if (!location || !location.latitude ||location.latitude == '') {
            region.latitude = LATITUDE;
            region.longitude = LONGITUDE;
            region.latitudeDelta = LATITUDE_DELTA;
            region.longitudeDelta = LATITUDE_DELTA;
        } else{
            region = location;
        }

        this.state = {
            showSuggestionPosition: props.showSuggestionPosition || false,
            region: region,
            firstRegion: region,
            enableRegionChange: false,
            diaChi: null,
            mapType: "standard",
            mapName: "Satellite",
            circle: {
                center: {
                    latitude: LATITUDE,
                    longitude: LONGITUDE,
                },
                radius: 0,
            }
        }
    }

    componentDidMount() {
        this.setState({enableRegionChange: true});
    }

    _onThucHien(){
        if(this.state.circle.radius > 0) {
            this.props.onPress(this.state.circle);
            Actions.pop();
        }else{
            Alert.alert('Thông báo', 'Bạn phải chọn bán kính để thực hiện tìm kiếm.') ;
        }
    }

    render() {
        log.info("Call MMapSearch.render");
        const { circle} = this.state;

        return (
            <View style={styles.fullWidthContainer}>

                <View style={styles.search}>
                    <HeaderMMapSearch backTitle={""} headerRightTitle={"Xong" } onPress={this._onThucHien.bind(this)}
                                      onBack={this.props.onBack}/>
                    <View style={styles.headerSeparator} />
                </View>
                <View style={styles.map}>
                    <MapView
                        region={this.state.region}
                        style={styles.mapView}
                        mapType={this.state.mapType}
                        onRegionChangeComplete={this._onRegionChangeComplete.bind(this)}
                    >
                        <MapView.Circle
                            key = {(circle.center.latitude + circle.center.longitude + circle.radius)}
                            center={circle.center}
                            radius={circle.radius}
                            fillColor="rgba(165,207,255,0.5)"
                            strokeColor={gui.mainColor}
                            position="absolute"
                            zIndex={1}
                            strokeWidth={1}
                        />
                        <MapView.Marker coordinate={circle.center}>
                            <LocationMarker/>
                        </MapView.Marker>
                    </MapView>

                    {this._renderGooglePlaceAutoComplete()}
                    {/*<View style={styles.positionIcon}>
                        <RelandIcon name="home-marker" color={gui.mainColor}
                                    size={30} textProps={{ paddingLeft: 0 }}
                        />
                    </View>*/}
                    {this._renderButtonOnMap()}
                    <View style={styles.mapButtonContainer}>
                        <View style={styles.searchListButton}>
                            <View style={styles.viewTopNav}>
                                <ScalableText style={styles.textSpaceTop}>{this.state.circle.radius/1000} km xung quanh vị trí đã chọn.</ScalableText>
                            </View>
                            <View style={styles.viewCenterNav}>
                                <Slider
                                    value={this.state.value}
                                    onValueChange={this._setRadiusCenter.bind(this)}
                                    trackStyle={styles.track}
                                    thumbStyle={styles.thumb}
                                    minimumValue={0}
                                    maximumValue={5}
                                    step={0.5}
                                    minimumTrackTintColor={gui.mainColor}
                                    maximumTrackTintColor='#b7b7b7'
                                />
                            </View>
                            {this._renderSliderView()}
                            <View style={styles.viewBottomNav}>
                                <View style={styles.viewTextBottom}>
                                    <Text style={styles.textBottomLeft}>{this.state.circle.radius/1000}</Text>
                                    <Text style={styles.textBottomCenter}>KM</Text>
                                </View>
                                <View style={{flex:1}}>
                                    <Text style={styles.textBottomRight}>5 KM</Text>
                                </View>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        )
    }

    _setRadiusCenter(radius){
        var circle = JSON.parse(JSON.stringify(this.state.circle));
        circle.radius = radius*1000;
        var region = JSON.parse(JSON.stringify(this.state.region));
        let delta = apiUtils.convertRadius2Delta(radius);
        region.latitudeDelta = delta;
        region.longitudeDelta = delta;
        this.setState({
            region: region,
            circle: circle});
    }

    _renderSliderView(){
        return (
            <View style={styles.viewMeasure}>
                <View style={styles.sliderDotOne}></View>
                <View style={styles.sliderDotTwo}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotFour}></View>
            </View>
        );
    }

    _renderGooglePlaceAutoComplete() {
        return (
            <TouchableHighlight onPress={this._onPress.bind(this)} style={styles.touchSearch}>
                <View style={styles.searchTextContainer}>
                    <View style={styles.viewIconSearch}>
                        <RelandIcon name="search" color='#8a8a8a' mainProps={{top:10, marginLeft:6}}
                                    size={18} textProps={{}}
                        />
                    </View>
                    <View style={styles.viewSearch}>
                        <ScalableText style={styles.searchTextBottom}>
                            {this._getdiaChi()}
                        </ScalableText>
                    </View>
                </View>
            </TouchableHighlight>
        );
    }

    _getdiaChi() {
        var diaChi = this.state.diaChi;

        if (!diaChi || diaChi.length <= 0)
            return 'Chọn địa điểm';

        if (diaChi.length > 40) {
            diaChi = diaChi.substring(0, 40) + '...';
        }

        return diaChi;
    }

    _onPress(){
        log.info("PostAdsMapView press place");
        Actions.PostAdsGoogleAutoComplete({onSuggestionPressed: (location)=>this._setRegionFromGoogleAutoComplete(location)});
    }

    _renderButtonOnMap(){
        return (
            <View style={styles.inMapButtonContainer}>
                {this._renderSuggestionPositionButton()}
                {this._renderCurrentPositionButton()}
            </View>
        );
    }
    _renderCurrentPositionButton() {
        return (
            <View >
                <TouchableOpacity onPress={this._onCurrentLocationPress.bind(this)} >
                    <View style={[styles.bubble, styles.button, {marginTop: 10}]}>
                        <RelandIcon name="direction" color='black' mainProps={{flexDirection: 'row'}}
                                    size={20} textProps={{paddingLeft: 0}}
                                    noAction={true}></RelandIcon>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderSuggestionPositionButton() {
        if (!this.props.showSuggestionPosition)
            return;

        return (
            <View >
                <TouchableOpacity onPress={this._onSuggestionLocationPress.bind(this)} >
                    <View style={[styles.bubble, styles.button, {flexDirection: 'column', width: 60}]}>
                        <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start'}}>
                            <RelandIcon name="hand-o-up" color={'black'}
                                        mainProps={{flexDirection: 'row'}}
                                        size={20} textProps={{paddingLeft: 0}}
                                        noAction={true}></RelandIcon>
                            <Text style={[styles.positionSuggetionIconText, {color: 'black'}]}>Vị trí gợi ý</Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onCurrentLocationPress() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                var region = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    latitudeDelta: this.state.region.latitudeDelta,
                    longitudeDelta: this.state.region.longitudeDelta
                };
                this.updateRegionDelta(region);
                this._onRegionChangeComplete(region);
            },
            (error) => {
                log.warn(error);
            },
            {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
        );
    }

    _onSuggestionLocationPress() {
        let region = this.state.firstRegion;
        this._onRegionChangeComplete(region);
    }

    _setRegionFromGoogleAutoComplete(location){

        let region = apiUtil.getRegionByViewport(location.viewport);
        this.updateRegionDelta(region);
        this._onRegionChangeComplete(region);
        Actions.pop();
    }

    updateRegionDelta(region) {
        var circle = JSON.parse(JSON.stringify(this.state.circle));
        if (circle.radius > 0) {
            let delta = apiUtils.convertRadius2Delta(circle.radius/1000);
            region.latitudeDelta = delta;
            region.longitudeDelta = delta;
        }
    }

    _onRegionChange(region) {
        if (!this.state.enableRegionChange) {
            return;
        }
        var circle = JSON.parse(JSON.stringify(this.state.circle));
        circle.center.latitude = region.latitude;
        circle.center.longitude = region.longitude;
        this.setState({region: region, circle: circle});
    }

    _onRegionChangeComplete(region) {
        if (!this.state.enableRegionChange) {
            return;
        }
        var circle = JSON.parse(JSON.stringify(this.state.circle));
        circle.center.latitude = region.latitude;
        circle.center.longitude = region.longitude;

        this.setState({region: region, circle: circle});
        findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
    }

    _onApply() {
        var {region} = this.state;
        findApi.getGeocoding(region.latitude, region.longitude, this.geoCallback.bind(this));
        Actions.pop();
    }

    _parseDiaChinh(data) {
        let diaChinh = {};
        let places = data.results;
        if (places.length > 0) {
            let newPlace = places[0];
            let diaDiem = placeUtil.getDiaDiem(newPlace);
            if (diaDiem == '') {
                for (let i = 0; i < places.length; i++) {
                    let value = placeUtil.getDiaDiem(places[i]);
                    if (value != '') {
                        diaDiem = value;
                        newPlace = places[i];
                        break;
                    }
                }
            }
            let xa = placeUtil.getXa(newPlace);
            if (diaDiem == '') {
                for (let i = 0; i < places.length; i++) {
                    let value = placeUtil.getXa(places[i]);
                    if (xa != '') {
                        xa = value;
                        newPlace = places[i];
                        break;
                    }
                }
            }

            let tinh = placeUtil.getTinh(newPlace);
            let huyen = placeUtil.getHuyen(newPlace);

            diaChinh = {tinh: tinh, huyen: huyen, xa: xa, diaDiem: diaDiem};
        }
        return diaChinh;
    }

    _getDiaChinhContent(data){
        let diaChinh = this._parseDiaChinh(data);

        let {tinh, huyen, xa, diaDiem} = diaChinh;

        let fullName = tinh;
        if (huyen && huyen!=''){
            fullName = huyen + ', ' + fullName;
        }

        if (xa && xa!=''){
            fullName = xa + ', ' + fullName;
        }

        if (diaDiem && diaDiem.length >0){
            fullName = diaDiem + ', ' + fullName;
        }

        this.setState({diaChi: fullName});
    }


    geoCallback(data) {
        let location = {};
        let {region} = this.state;
        location.lat = region.latitude;
        location.lon = region.longitude;
        let diaChinh = this._parseDiaChinh(data);

        let {tinh, huyen, xa} = diaChinh;
        diaChinh.tinhKhongDau = utils.locDau(tinh);
        diaChinh.huyenKhongDau = utils.locDau(huyen);
        diaChinh.xaKhongDau = utils.locDau(xa);

        let placeType = 'T';
        if (diaChinh.huyenKhongDau)
            placeType = 'H';
        if (diaChinh.xaKhongDau)
            placeType = 'X';

        let diaChinhDto = {
            tinhKhongDau: diaChinh.tinhKhongDau || undefined,
            tinh: diaChinh.tinh,
            huyenKhongDau: diaChinh.huyenKhongDau || undefined,
            huyen: diaChinh.huyen,
            xaKhongDau: diaChinh.xaKhongDau || undefined,
            xa: diaChinh.xa,
            placeType: placeType
        }

        let position = {
            location: location,
            diaChi: this.state.diaChi,
            diaChinh: diaChinhDto
        }

        this.props.onPress(position);

    }

    _onCancel() {
        Actions.pop();
    }
}

class HeaderMMapSearch extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return <View style={styles.customPageHeader}>
            <TruliaIcon onPress={this._onBack.bind(this)}
                        name="arrow-left" color={gui.mainColor} size={26}
                        mainProps={styles.backButton} text={this.props.backTitle}
                        textProps={styles.backButtonText} >
            </TruliaIcon>
            <View style={styles.customPageTitle2}>
                <ScalableText style={styles.customPageRightTitleText2}>
                    Chọn địa điểm và bán kính
                </ScalableText>
            </View>
            <TouchableOpacity onPress={this.props.onPress} style={styles.customPageRightTitle}>
                <ScalableText style={styles.customPageRightTitleText}>
                    {this.props.headerRightTitle}
                </ScalableText>
            </TouchableOpacity>
        </View>
    }

    _onBack() {
        this.props.onBack && this.props.onBack();
        Actions.pop();
    }
    _returnLatLonPress() {
        this.props.onPress(this.state.circle);
        Actions.pop();
    }

}


// Later on in your styles..
var styles = StyleSheet.create({
    headerSeparator: {
        marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'transparent',
    },
    container: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    map: {
        flex: 1,
        marginTop: 0,
        marginBottom: 0
    },
    mapView: {
        flex: 1,
        marginTop: 0,
        marginBottom: 0
    },
    title: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
        backgroundColor: 'white'
    },
    search: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    mapIcon: {
        color: 'white',
        textAlign: 'center'
    },
    text: {
        color: 'white'
    },
    mapButtonContainer: {
        position: 'absolute',
        bottom: 0,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: 'white'
    },
    buttonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchListButton: {
        flexDirection: 'column',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: 'transparent',
        height: 95,
        borderTopWidth:1,
        borderColor:'lightgray'
    },
    searchTextContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: 28,
        width: width
    },
    searchTextTop: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        textAlign: 'left',
        paddingLeft:0,
        paddingTop:5,
        backgroundColor:'transparent',
        fontWeight:'300',
        width:width-65,
        height:22,
        color:'#676769'
    },
    searchTextBottom: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        textAlign: 'left',
        paddingLeft:0,
        paddingTop:5,
        backgroundColor:'transparent',
        fontWeight:'400',
        width:width-65,
        height:28,
        color:'#1d1d1d'
    },
    positionIcon: {
        position: 'absolute',
        top: (height-60-25-60)/2 + 15,
        left: width/2 - 8,
        justifyContent: 'center',
        borderColor: gui.mainColor,
        backgroundColor: 'transparent'
    },
    inMapButtonContainer: {
        position: 'absolute',
        bottom: 120,
        left:8,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginVertical: 5,
        marginBottom: 0,
        backgroundColor: 'transparent',
    },
    bubble: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 5,
        paddingVertical: 5,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center'
    },
    button: {
        width: 43,
        height: 38,
        paddingVertical: 5,
        alignItems: 'center',
        marginVertical: 5,
        backgroundColor: 'white',
        opacity: 0.9,
        marginLeft: 15
    },
    positionSuggetionIconText: {
        fontSize: 9,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        textAlign: 'center'
    },
    touchSearch:{
        position: 'absolute',
        top: 15,
        borderRadius:4,
        paddingLeft:0,
        marginLeft:15,
        marginRight:15,
        marginTop: 5,
        height:30,
        width:width - 30,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        borderWidth:1,
        borderColor:'lightgray',
        opacity: 0.9,
    },
    viewSearch:{
        width:width-65,
        height:28,
        right:20,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor:'transparent',
    },
    textSpaceTop:{
        fontSize: 15,
        color:'#333333',
        textAlign:'center',
        marginTop: 8
    },
    textBottomLeft:{
        fontSize: 13,
        flex:1,
        color:'#676769',
        textAlign:'right',
        marginBottom: 5,
        paddingRight:3,
    },
    textBottomCenter:{
        fontSize: 13,
        flex:5,
        color:'#676769',
        textAlign:'left',
        marginBottom: 5,
    },
    textBottomRight:{
        fontSize: 13,
        flex:1,
        color:'#676769',
        textAlign:'right',
        paddingRight:15,
        marginBottom: 5
    },
    track: {
        height: 2,
        borderRadius: 1,
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: 'white',
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    viewTopNav: {
        backgroundColor: 'white',
        height: 25,
        width: width,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewCenterNav: {
        backgroundColor: 'white',
        height: 40,
        width: width - 30,
        right: 15,
        left: 15,
        alignItems: 'stretch',
        justifyContent: 'center',
        flexDirection:'column'
    },
    viewBottomNav: {
        backgroundColor: 'white',
        height: 30,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewMeasure: {
        backgroundColor: 'transparent',
        height: 5,
        width: width - 30,
        right: 15,
        left: 15,
        bottom: 8,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row'
    },
    sliderDotOne: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        left: 6
    },

    sliderDotTwo: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        marginLeft: (width - 30) / 10
    },
    sliderDotThree: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        marginLeft: (width - 30) / 10 - 7
    },
    sliderDotFour: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        marginLeft: (width - 30) / 10 - 6
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: 'transparent',
        height: 60
    },
    customPageTitle: {
        left:36,
        right:36,
        marginTop: 31,
        marginBottom: 10,
        position: 'absolute'
    },
    customPageRightTitle:{
        marginTop: 27,
        alignItems: 'flex-end',
        justifyContent: 'center',
        height:30,
        width: 80,
        right:18,
        marginBottom: 10,
        position: 'absolute',
        backgroundColor:'transparent'
    },
    customPageTitleText: {
        color: 'black',
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    customPageRightTitleText: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        textAlign: 'right',
        fontWeight:'400'
    },
    backButton: {
        marginTop: 31,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: gui.mainColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    customPageTitle2: {
        flex:1,
        justifyContent:'center',
        alignItems:'center',
        position: 'absolute',
        marginTop: 31,
        left:36,
        right:36
    },
    customPageRightTitleText2: {
        color: '#000',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        textAlign: 'center',
        fontWeight:'500'
    },
    viewTextBottom:{
        flex:1,
        justifyContent:'center',
        alignItems:'flex-start',
        flexDirection:'row',
        backgroundColor:'transparent'
    },
    viewIconSearch:{
        height:28,
        width:28,
        backgroundColor:'transparent',
        left:20,
        justifyContent:'center',
        alignItems:'flex-start'
    }
});

export default MMapSearch;
