import React, {Component} from 'react';

var {
    StyleSheet,
    View
} = require('react-native');

import gui from '../../lib/gui';
import RelandIcon from './../RelandIcon';

class SchoolMarker extends React.Component{
    render() {
        let {color, size} = this.props;
        return (
            <View style={styles.container} pointerEvents="none" >
                <RelandIcon name={"school"} size={size||22} color={color||gui.mainColor} mainProps={styles.markerIcon}/>
            </View>
        );
    }
}

var styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    markerIcon: {
        backgroundColor: 'transparent'
    }
});

module.exports = SchoolMarker;
