import React, {Component} from 'react';

var {
    StyleSheet,
    View,
    Image
} = require('react-native');

import gui from '../../lib/gui';
import RelandIcon from './../RelandIcon';

var currentColor = gui.mainColor;

class LocationMarker extends React.Component{

    constructor(){
        super();
        this.state = {
            color: gui.mainColor
        }
    }

    componentDidMount() {
        if (this.props.animation) {
            this.timer = setTimeout(() => this.setState({color: '#f0a401'}), 500);
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    render() {
        let {iconName, size, animation} = this.props;
        let color = this.state.color;
        if (animation && color != currentColor) {
            currentColor = color;
            clearTimeout(this.timer);
            let newColor = color == '#f0a401' ? gui.mainColor: '#f0a401';
            this.timer = setTimeout(() => this.setState({color: newColor}), 500);
        }
        return (
            <View style={styles.container} pointerEvents="none" >
                <View style={styles.markerContent2}>
                    <RelandIcon name={iconName||"loc-marker"} size={size||40} color={'#EB5E58'} mainProps={styles.markerIcon2}/>
                </View>
                <RelandIcon name={iconName||"loc-marker-o"} size={size||40} color={'#000000'} mainProps={styles.markerIcon}/>
                {/*<Image style={styles.googleMarker}
                 resizeMode={Image.resizeMode.contain}
                 source={require('../../assets/image/google-marker.png')} />*/}
            </View>
        );
    }
}

var styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    markerContent2: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 0,
        right: 0,
        left: 0,
        bottom: 0
    },
    markerIcon2: {
        backgroundColor: 'transparent'
    },
    markerIcon: {
        backgroundColor: 'transparent'
    },
    googleMarker: {
        height: 40,
        width: 40,
        // marginBottom: 40,
        backgroundColor: 'transparent'
    }
});

module.exports = LocationMarker;
