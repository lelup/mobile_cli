import React, {Component} from 'react';
import {View, Text, StyleSheet, SegmentedControlIOS, TextInput} from 'react-native';

import gui from '../lib/gui';
import SegmentedControlTab from './SegmentedControlTab2';
import utils from '../lib/utils';
import FullLine from './line/FullLine';

let {width, height} = utils.getDimensions();

class SegmentedControl3 extends Component {
    render() {
        return (
            <View style={[myStyles.searchFilterAttributeExt, {flexDirection: "column"}]}>
                <View style={{paddingBottom: 4, paddingTop: 3}}>
                    <Text style={myStyles.searchAttributeLabel}>
                        {this.props.label}
                    </Text>
                </View>
                <View style={{paddingLeft: 0, paddingRight: 6, paddingBottom: 9, flexDirection: "row"}}>
                    <SegmentedControlTab
                        values={this.props.values}
                        selectedIndex={this.props.selectedIndexAttribute}
                        onTabPress={this.props.onChange}
                        tabStyle ={myStyles.tabStyle}
                        tabTextStyle={myStyles.tabTextStyle}
                        activeTabStyle={{backgroundColor: gui.mainColor}}
                        activeTabTextStyle={myStyles.activeTabTextStyle}
                        tabsContainerStyle={myStyles.tabsContainerStyle}
                    />

                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={myStyles.input}
                        placeholder={this.props.placeholder}
                        placeholderTextColor={gui.mainColor}
                        value={this.props.textValue}
                        onChangeText={(text) => this.props.onTextChange(this.props.textField, text)}
                    />
                </View>
                <FullLine style={[myStyles.lineStyle, this.props.lineStyle]}/>
            </View>
        );
    }
}

// Later on in your styles..
const myStyles = StyleSheet.create({
    searchFilterAttributeExt: {
        flexDirection : "row",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingTop: 5,
        paddingLeft: 0,
        paddingBottom: 8,
        marginLeft: 16,
        marginRight: 16
    },
    searchAttributeLabel: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        paddingRight: 10,
        marginLeft:10,
        height: 28,
        borderColor: gui.mainColor,
        borderWidth: 1,
        borderRadius: 5,
        width: 60,
        textAlign: 'right',
        alignSelf: 'center',
        marginTop: 2
    },
    tabStyle: {
        backgroundColor: '#fff',
        // borderWidth: 1,
        borderColor:gui.mainColor,
        paddingVertical: 5,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        // marginLeft:-2
    },
    tabTextStyle: {
        color:gui.mainColor,
        fontWeight: '400',
        fontFamily:gui.fontFamily,
        fontSize: 15
    },
    activeTabTextStyle: {
        color: '#fff',
        fontWeight: '400',
        fontFamily:gui.fontFamily,
        fontSize: 15
    },
    tabsContainerStyle: {
        alignItems:'center',
        backgroundColor:'transparent',
        height:28,
        width: width-117,
        marginLeft:5,
        marginTop:2
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    }
});

export default SegmentedControl3;
