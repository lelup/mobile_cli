import React, {Component} from 'react';

import {StyleSheet,Text,View,Image,TouchableHighlight,Animated,TouchableOpacity} from 'react-native'; //Step 1

import gui from '../lib/gui';
import utils from '../lib/utils';

import TruliaIcon from './TruliaIcon';
import RelandIcon from './RelandIcon';

var {width} = utils.getDimensions();

class CollapsiblePanelModal extends Component{
    constructor(props){
        super(props);

        this.icons = {     //Step 2
            'up'    : 'arrow-up',
            'down'  : 'arrow-down'
        };

        this.state = {       //Step 3
            title       : props.title,
            subtitle    : props.subtitle,
            expanded    : props.expanded,
            animation   : new Animated.Value()
        };
    }

    toggle(){
        //Step 1
        let initialValue    = this.state.expanded? this.state.maxHeight + this.state.minHeight : this.state.minHeight,
            finalValue      = this.state.expanded? this.state.minHeight : this.state.maxHeight + this.state.minHeight;

        this.setState({
            expanded : !this.state.expanded  //Step 2
        });

        this.state.animation.setValue(initialValue);  //Step 3
        Animated.spring(     //Step 4
            this.state.animation,
            {
                toValue: finalValue
            }
        ).start();  //Step 5
        this.props.onPress && this.props.onPress();
    }

    collapse() {
        //Step 1
        let initialValue    = this.state.maxHeight + this.state.minHeight,
            finalValue      = this.state.minHeight;

        this.setState({
            expanded : false  //Step 2
        });

        this.state.animation.setValue(initialValue);  //Step 3
        Animated.spring(     //Step 4
            this.state.animation,
            {
                toValue: finalValue
            }
        ).start();  //Step 5
    }

    _setMaxHeight(event){
        this.setState({
            maxHeight   : event.nativeEvent.layout.height
        });
    }

    _setMinHeight(event){
        this.setState({
            minHeight   : event.nativeEvent.layout.height
        });
    }


    render(){
        let {mainProps, bodyProps, collapseProps, helpName, helpText} = this.props;

        let icon = this.icons['down'];

        if(this.state.expanded){
            icon = this.icons['up'];   //Step 4

            //Step 5
            return (
                <Animated.View style={[styles.container, mainProps,{height: this.state.animation}]} >

                    <TouchableOpacity
                        onPress={this.toggle.bind(this)}>
                        <View  onLayout={this._setMinHeight.bind(this)}>
                            <View style={[styles.titleContainer, {paddingTop: 8}]}>
                                <View style={styles.viewIconModal}>
                                    <RelandIcon name={helpName} color={gui.mainColor}
                                                mainProps={{flexDirection: 'row'}}
                                                size={20} textProps={{paddingLeft: 0}}
                                                text={helpText}
                                                noAction={true}/>
                                </View>
                                <View style={styles.viewTitle}>
                                    <Text style={styles.title}>{this.state.title}</Text>
                                </View>
                                <TruliaIcon onPress={this.toggle.bind(this)}
                                            name={icon} color={'gray'}
                                            mainProps={styles.button} size={20} />
                            </View>
                            {this.state.subtitle ? <Text style={styles.subtitle}>{this.state.subtitle}</Text> : null}
                        </View>

                        <View style={[styles.body, bodyProps]} onLayout={this._setMaxHeight.bind(this)}>
                            {this.props.children}
                        </View>
                    </TouchableOpacity>

                </Animated.View>
            );
        } else {
            //Step 5
            return (
                <Animated.View style={[styles.container, collapseProps, {height: this.state.animation}]} >

                    <TouchableOpacity
                        onPress={this.toggle.bind(this)}>
                        <View  onLayout={this._setMinHeight.bind(this)}>
                            <View style={styles.titleContainer}>
                                <View style={styles.viewIconModal}>
                                    <RelandIcon name={helpName} color={gui.mainColor}
                                                mainProps={{flexDirection: 'row'}}
                                                size={20} textProps={{paddingLeft: 0}}
                                                noAction={true}/>
                                </View>
                                <View style={styles.viewTitle}>
                                    <Text style={styles.title}>{this.state.title}</Text>
                                </View>
                                <TruliaIcon onPress={this.toggle.bind(this)}
                                            name={icon} color={'gray'}
                                            mainProps={styles.button} size={20} />
                            </View>
                            {this.state.subtitle ? <Text style={styles.subtitle}>{this.state.subtitle}</Text> : null}
                        </View>
                    </TouchableOpacity>

                </Animated.View>
            );
        }

    }
}

var styles = StyleSheet.create({
    container   : {
        backgroundColor: 'transparent',
        marginLeft: 0,
        overflow:'hidden',
        width: width-60
    },
    titleContainer : {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        margin: 0
    },
    title       : {
        //flex    : 1,
        color   :'#3a3a3a',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0,
        //width: width-100
    },
    viewTitle:{
        flex    : 1,
        marginLeft: 0,
        alignItems: 'flex-start',
        width: width-100
    },
    subtitle    : {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        color: '#9C9C9C',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0
    },
    button      : {
        marginTop: 0,
        marginBottom: 0,
        justifyContent: 'flex-end',
        height: 20,
        width: 30,
    },
    body        : {
        margin: 0,
        marginTop: 13,
    },
    viewIconModal:{
        height: 30,
        width: 30,
        marginRight: 2,
        paddingBottom: 6,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    }
});

export default CollapsiblePanelModal;
