import utils from '../../../lib/utils';

const window = utils.getDimensions();

export default {
  screenWidth: window.width,
  screenHeight: window.height,
  thumbnailHeight: 100,
  useRCTView: true, //debug or not?
  video: {
    minWidth: 1024,
    minHeight: 640,
    minFrameRate: 30
  }
}
