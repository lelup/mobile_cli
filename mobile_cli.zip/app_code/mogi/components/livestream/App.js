import React, { Component } from 'react';
import {StyleSheet, Text, TouchableHighlight, View, ListView, Image, TextInput, TouchableOpacity} from 'react-native';
import Thumbnails from "./components/Thumbnails.js";
import FullScreenVideo from "./components/FullScreenVideo.js";
import styles from "./style/app.js";

import {Actions} from 'react-native-router-flux';

import RelandIcon from '../RelandIcon';

import LinearGradient from 'react-native-linear-gradient';

import ScalableText from 'react-native-text';

import InCallManager from 'react-native-incall-manager';

const webRTCServices = require("./lib/services.js");

export default class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      activeStreamId: null,
      streams: [], //list of (id, url: friend Stream URL). Id = socketId
      joinState: "ready", //joining, joined
      name: props.username,
      isFront: false,
      handshaked: false,
      hangingUp: false,
      speakerOn: true,
      micOn: true,
      videoOn: true
    }
    // this.handupTimer && clearTimeout(this.handupTimer);
    // this.handupTimer = null;
  }

  componentDidMount() {
    let uuid = new Date().getTime();
    let selfStreamId = this.state.name + '_' + uuid;
    webRTCServices.getLocalStream(this.state.isFront, (stream) => {
      this.setState({
        activeStreamId: selfStreamId,
        streams: [{
          id: selfStreamId,
          name: this.state.name,
          url: stream.toURL()
        }]
      });
      InCallManager.start({media: 'audio'});
      webRTCServices.setEnabledLocalAudio(this.state.micOn);
      webRTCServices.setEnabledLocalVideo(this.state.videoOn);
    });
    setTimeout(this.handleJoinClick.bind(this), 1000);
    InCallManager.setKeepScreenOn(true);
  }

  componentWillUnmount() {
    // this.props.doFinalAction && this.props.doFinalAction();
    // webRTCServices.closePeerConnections();
    InCallManager.setKeepScreenOn(false);
  }

  render() {
    let activeStreamResult = this.state.streams.filter(stream => stream.id == this.state.activeStreamId);
    return <View style={styles.container}>
      <View style={styles.backgroundImage} blurRadius={3}>
        <Image
            style={styles.imageIntro} resizeMode = {'cover'}
            source={require('../../assets/image/logo.png')}
        />
      </View >
      <View style={styles.backgroundOverlay} />
      {
        this.state.joinState == "joined" ?
        <FullScreenVideo streamURL={activeStreamResult.length > 0 ? activeStreamResult[0].url : null}
                         name={activeStreamResult.length > 0 ? activeStreamResult[0].name : null}/>
        :
        null
      }
      {
        this.state.joinState == "joined"?
        <Thumbnails streams={this.state.streams}
          setActive={this.handleSetActive.bind(this)}
          activeStreamId={this.state.activeStreamId}/>
        :
        null
      }
      {this.renderJoinContainer()}
      {/*this.renderHeaderButtons()*/}
      {/*this.renderCameraButtons()*/}
      {this.renderSpeakerButton()}
      {this.renderMicButton()}
      {this.renderHangUpButton()}
      {this.renderVideoButton()}
    </View>
  }

  renderSpeakerButton() {
    let iconName = this.state.speakerOn ? 'speaker-on' : 'speaker-off';
    let iconColor = this.state.speakerOn ? 'black' : '#8f8f8f';
    let bgColor = this.state.speakerOn ? '#fff' : '#CCCCCC';
    return (
        <View style={styles.viewSpeakerButton} >
          <View style={[styles.speakerContainer, {backgroundColor: bgColor}]}>
            <RelandIcon name={iconName} color={iconColor}
                        mainProps={styles.speakerIcon}
                        size={26} onPress={this.onSpeakerPress.bind(this)}
            />
          </View>
        </View>
    );
  }

  onSpeakerPress() {
    let speakerOn = !this.state.speakerOn;
    this.setState({speakerOn: speakerOn});
    InCallManager.setForceSpeakerphoneOn(speakerOn);
  }

  renderMicButton() {
    let iconName = this.state.micOn ? 'mic-on' : 'mic-off';
    let iconColor = this.state.micOn ? 'black' : '#8f8f8f';
    let bgColor = this.state.micOn ? '#fff' : '#CCCCCC';
    return (
        <View style={styles.viewMicButton} >
          <View style={[styles.micContainer, {backgroundColor: bgColor}]}>
            <RelandIcon name={iconName} color={iconColor}
                        mainProps={styles.micIcon}
                        size={26} onPress={this.onMicPress.bind(this)}
            />
          </View>
        </View>
    );
  }

  onMicPress() {
    let micOn = !this.state.micOn;
    this.setState({micOn: micOn});
    webRTCServices.setEnabledLocalAudio(micOn);
  }

  renderVideoButton() {
    let iconName = this.state.videoOn ? 'video-on' : 'video-off';
    let iconColor = this.state.videoOn ? 'black' : '#8f8f8f';
    let bgColor = this.state.videoOn ? '#fff' : '#CCCCCC';
    return (
        <View style={styles.viewVideoButton} >
          <View style={[styles.videoContainer, {backgroundColor: bgColor}]}>
            <RelandIcon name={iconName} color={iconColor}
                        mainProps={styles.videoIcon}
                        size={26} onPress={this.onVideoPress.bind(this)}
            />
          </View>
        </View>
    );
  }

  onVideoPress() {
    let videoOn = !this.state.videoOn;
    this.setState({videoOn: videoOn});
    webRTCServices.setEnabledLocalVideo(videoOn);
  }

  renderHangUpButton() {
    return (
        <View style={styles.viewHangUp} >
          <View style={styles.hangUpContainer}>
            <RelandIcon name="phone" color="#fff"
                        mainProps={styles.hangUpIcon}
                        size={26} onPress={this.onBackPress.bind(this)}
            />
          </View>
        </View>
    );
  }

  renderCameraButtons() {
    return (
        <View style={styles.viewTypeCamera} >
          <LinearGradient colors={['transparent','rgba(50, 50, 50, 0.75)','transparent']}
                          style={styles.linearGradient}>
            <RelandIcon name="camera-switch" color="rgba(255,255,255,0.85)"
                        mainProps={styles.captureIcon}
                        size={22} onPress={this.switchVideoType.bind(this)}
            />
          </LinearGradient>
        </View>
    );
  }

  switchVideoType() {
    const isFront = !this.state.isFront;
    this.setState({isFront: isFront, joinState: "ready"});
    let uuid = new Date().getTime();
    let selfStreamId = this.state.name + '_' + uuid;
    webRTCServices.getLocalStream(isFront, (stream) => {
      this.setState({
        activeStreamId: selfStreamId,
        streams: [{
          id: selfStreamId,
          name: this.state.name,
          url: stream.toURL()
        }]
      });
    });
    setTimeout(this.handleJoinClick.bind(this), 1000);
  }

  renderHeaderButtons() {
    return (
        <View style={styles.pageHeader}>
          <TouchableOpacity
              onPress={this.onBackPress.bind(this)}
              style={styles.searchButton}
              activeOpacity={0}
          >
            {/*<TruliaIcon name="arrow-left" color="#fff" size={26}
                        mainProps={{paddingLeft: 0, paddingRight: 0}}
                        noAction={true}
            >
            </TruliaIcon>*/}
            <ScalableText style={styles.gacMayText}>Gác máy</ScalableText>
          </TouchableOpacity>
        </View>
    );
  }

  onBackPress() {
    if (!this.state.hangingUp) {
      this.setState({hangingUp: true});
      InCallManager.setForceSpeakerphoneOn(false);
      this.props.doFinalAction && this.props.doFinalAction();
      webRTCServices.closePeerConnections();
      Actions.pop();
    }
  }

  renderJoinContainer() {
    if(this.state.joinState != "joined") {
      return <View style={styles.joinContainer}>
        <Text style={styles.joinLabel}>Hãy là người đầu tiên tham gia cuộc trò chuyện này</Text>
        <TextInput style={styles.joinName}
          placeholder={"Enter your name"} placeholderTextColor={"#888"}
          onChangeText={(name) => this.setState({name})}
          value={this.state.name} />
        <TouchableHighlight style={styles.joinButton}
            onPress={this.handleJoinClick.bind(this)}>
          <Text style={styles.joinButtonText}>{this.state.joinState == "ready" ? "Kết nối" : "Đang kết nối..."}</Text>
        </TouchableHighlight>
      </View>
    }
    return null;
  }

  handleSetActive(streamId) {
    this.setState({
      activeStreamId: streamId
    });
  }

  handleJoinClick() {
    if(this.state.name.length == 0 || this.state.joinState != "ready") {
      return;
    }
    //ELSE:
    this.setState({
      joinState: "joining"
    });
    let callbacks = {
      joined: this.handleJoined.bind(this),
      friendConnected: this.handleFriendConnected.bind(this),
      friendLeft: this.handleFriendLeft.bind(this),
      dataChannelMessage: this.handleDataChannelMessage.bind(this)
    }
    webRTCServices.join(this.props.roomName, this.state.name, callbacks);
  }

  //----------------------------------------------------------------------------
  //  WebRTC service callbacks
  handleJoined() {
    console.log("Joined");
    this.setState({
      joinState: "joined"
    });
    // this.handupTimer = setTimeout(() => {
    //   if (!this.state.handshaked) {
    //     this.onBackPress();
    //   }
    // }, 300000);
  }

  handleFriendLeft(socketId) {
    if (this.state.joinState == "joined") {
      this.onBackPress();
    } else {
      let newState = {
        streams: this.state.streams.filter(stream => stream.id != socketId)
      }
      if(this.state.activeStreamId == socketId) {
        newState.activeStreamId = newState.streams[0].id;
      }
      this.setState(newState);
    }
  }

  handleFriendConnected(friend, stream) {
    this.setState({
      activeStreamId: friend.socketId,
      streams: [
        ...this.state.streams,
        {
          id: friend.socketId,
          name: friend.name,
          url: stream.toURL()
        }
      ],
      handshaked: true
    });
    InCallManager.setForceSpeakerphoneOn(this.state.speakerOn);
  }

  handleDataChannelMessage(message) {

  }
}
