import {StyleSheet} from 'react-native';
import config from "../config/app.js";
import gui from '../../../lib/gui';

export default StyleSheet.create({
  container: {
    width: config.screenWidth,
    height: config.screenHeight
  },
  video: {
    width: config.screenWidth,
    height: config.screenHeight
  },
  titleContainer: {
    position: "absolute",
    top: 14,
    left: 0,
    width: config.screenWidth,
    paddingRight: 10,
    height: 50,
    backgroundColor: "transparent",
    flex: 1,
    justifyContent: "center",
    alignItems: "flex-end"
  },
  titleText: {
    color: "white",
    fontSize: 17,
    fontWeight: "bold",
    fontFamily: gui.fontFamily
  },
  linearGradient: {
    paddingLeft: 5,
    paddingRight: 5,
    paddingBottom: 5,
    backgroundColor: "transparent"
  },
});
