import {StyleSheet} from 'react-native';
import config from "../config/app.js";
import gui from "../../../lib/gui";

export default StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    width: config.screenWidth,
    height: config.screenHeight,
    //borderWidth: 1, borderColor: "red"
  },
  logo: {
    position: "absolute",
    width: 100,
    height: 50,
    top: 0,
    left: 0,
    //borderWidth: 1, borderColor: "white"
    backgroundColor: "rgba(255, 255, 255, 0.5)"
  },
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    width: config.screenWidth,
    height: config.screenHeight,
    backgroundColor: gui.mainColor,
    justifyContent: 'center',
    alignItems: 'center'
  },
  backgroundOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    width: config.screenWidth,
    height: config.screenHeight,
    backgroundColor: "rgba(0, 0, 0, 0.5)"
  },

  joinContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    width: config.screenWidth,
    height: config.screenHeight,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    //borderWidth: 1, borderColor: "white"
  },

  joinLabel: {
    color: "white",
    fontSize: gui.normalFontSize,
    fontWeight: "bold",
    fontFamily: gui.fontFamily
  },
  joinName: {
    height: 50,
    marginLeft: 20,
    marginRight: 20,
    marginTop: 10,
    borderWidth: 1,
    borderColor: "#CCC",
    textAlign: "center",
    color: "white"
  },
  joinButton: {
    marginTop: 10,
    borderRadius: 5,
    backgroundColor: "#337ab7",
    padding: 10
  },
  joinButtonText: {
    color: "white",
    fontSize: 17,
    fontWeight: "bold"
  },
  pageHeader: {
    position: "absolute",
    top: 0,
    left: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: gui.mainColor,
    height: 65,
    width: config.screenWidth
  },
  searchButton: {
    paddingTop: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    height: 64,
    width: 100,
    paddingRight: 20
  },
  gacMayText: {
    color: "white",
    fontSize: gui.normalFontSize,
    fontFamily: gui.fontFamily
  },
  viewTypeCamera: {
    position: "absolute",
    top: 40,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor:'transparent',
    height: 20,
    width: config.screenWidth
  },
  viewHangUp: {
    position: "absolute",
    bottom: 40,
    left: config.screenWidth/2+15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor:'transparent',
    height: 44,
    width: config.screenWidth
  },
  captureIcon: {
    backgroundColor:'transparent',
    justifyContent: 'center',
    padding: 5,
    paddingLeft: 10
  },
  hangUpContainer: {
    margin: 0,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fa4916'
  },
  hangUpIcon: {
    marginTop: 9,
    justifyContent: 'center',
    alignItems: 'center'
  },
  linearGradient: {
    marginTop: 0,
    paddingLeft: 0,
    paddingRight: 5,
    backgroundColor: "transparent"
  },
  imageIntro: {
    backgroundColor: 'transparent',
    transform: [
      {scaleX: 0.21},
      {scaleY: 0.21}
    ]
  },
  viewSpeakerButton: {
    position: "absolute",
    bottom: 40,
    left: config.screenWidth/2-125,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor:'transparent',
    height: 44,
    width: config.screenWidth
  },
  speakerContainer: {
    margin: 0,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fff'
  },
  speakerIcon: {
    marginTop: 9,
    justifyContent: 'center',
    alignItems: 'center'
  },
  viewMicButton: {
    position: "absolute",
    bottom: 40,
    left: config.screenWidth/2-55,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor:'transparent',
    height: 44,
    width: config.screenWidth
  },
  micContainer: {
    margin: 0,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fff'
  },
  micIcon: {
    marginTop: 9,
    justifyContent: 'center',
    alignItems: 'center'
  },
  viewVideoButton: {
    position: "absolute",
    bottom: 40,
    left: config.screenWidth/2+85,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor:'transparent',
    height: 44,
    width: config.screenWidth
  },
  videoContainer: {
    margin: 0,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fff'
  },
  videoIcon: {
    marginTop: 9,
    justifyContent: 'center',
    alignItems: 'center'
  }
});
