import React, {Component} from  'react';
import {View, Text, TouchableOpacity, StyleSheet, TouchableWithoutFeedback,
        ScrollView, TextInput, Alert
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import util from "../../lib/utils";
const {width, height} = util.getDimensions();
import FullLine from '../line/FullLine';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import Modal from 'react-native-modalbox';

import Button from 'react-native-button';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import ScalableText from 'react-native-text';

import Toast, {DURATION} from '../toast/Toast';
import UserTapButton from '../UserTapButton';
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import gui from "../../lib/gui";
import log from '../../lib/logUtil';
import ServiceApi from '../../lib/ServiceApi';
import findApi from '../../lib/FindApi';
import DanhMuc from '../../assets/DanhMuc';

import * as Animatable from 'react-native-animatable';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
class UserQuestions extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpenFullPromote: false,
            isFirstBuy: 1,
            colorUserValue: '',
            userQuestions: {
                tapMuaDau: '',
                tapTimeBuy: '',
                tapLoaiNhaMua: '',
                tapAddressBuy: '',
                moneyHouseBuyText: '',
                moneyHouseBorrowText: '',
                userFullName: '',
                userPhoneText: '',
                userEmailText: '',
                userIdentification: ''
            },
            userDescriptions: {
                tapMuaDau: '',
                tapTimeBuy: '',
                tapLoaiNhaMua: '',
                tapAddressBuy: '',
                moneyHouseBuyText: '',
                moneyHouseBorrowText: '',
                userFullName: '',
                userPhoneText: '',
                userEmailText: '',
                userIdentification: ''
            },
            moneyHouseBuyNumber: 0,
            moneyHouseBorrowNumber: 0,
            codeDuAn: '',
            codeDuong: '',
            codeXa: '',
            codeHuyen: '',
            codeTinh: '',
            duAn: '',
            duong: '',
            xa: '',
            huyen: '',
            tinh: '',
            toggleState: false
        }
    }

    render() {
        return(
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                {this._renderUserQuestion()}
                {this._renderStepButton()}
                {this._renderModalFullPromote()}
                {this._renderModalEnd()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={this._onBackPress.bind(this)}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={styles.textEdit}>Câu hỏi</Text>
                </View>
                <TouchableOpacity style={[styles.viewEdit, {paddingTop: 22}]}
                                  onPress={this._onNextModal.bind(this, false)}
                >
                    <Text style={[styles.textEdit, {fontWeight: '400', fontSize: 15}]}>Tiếp theo</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _onNextModal(ignoreValidate) {
        if (!ignoreValidate) {
            let msg = this._checkInputData();
            if (msg) {
                // Alert.alert('Thông báo', msg);
                this.refs.toastTop && this.refs.toastTop.show(msg, 2000);
                return;
            }
        }
        if (this.state.isFirstBuy == 7) {
            // let loanRegister = '';
            // let {userDescriptions} = this.state;
            // let keys = Object.keys(userDescriptions);
            // for (let i = 0; i < keys.length; i++) {
            //     let val = userDescriptions[keys[i]];
            //     if (val) {
            //         loanRegister = loanRegister ? loanRegister + '. ' + val : val;
            //     }
            // }
            // let dto = {content: loanRegister};
            let fistBuyHouse = this.state.userQuestions.tapMuaDau == 'buyTrue' ? true : false;
            let dtoContent = {
                lanDauMuaNha: fistBuyHouse,
                thoiGianMua: DanhMuc.userQuestion2[this.state.userQuestions.tapTimeBuy],
                place: {      // mandatory
                    fullName: this.state.userQuestions.tapAddressBuy,
                    diaChinh: {
                            codeDuAn: this.state.codeDuAn ? this.state.codeDuAn : undefined ,
                            codeDuong: this.state.codeDuong ? this.state.codeDuong : undefined,
                            codeXa: this.state.codeXa ? this.state.codeXa : undefined,
                            codeHuyen: this.state.codeHuyen ? this.state.codeHuyen : undefined,
                            codeTinh: this.state.codeTinh ? this.state.codeTinh : undefined,
                            duAn: this.state.duAn ? this.state.duAn : undefined,
                            duong: this.state.duong ? this.state.duong : undefined,
                            xa: this.state.xa ? this.state.xa : undefined,
                            huyen: this.state.huyen ? this.state.huyen : undefined,
                            tinh: this.state.tinh ? this.state.tinh : undefined,
                        }
                },
                loaiNhaDat: DanhMuc.userQuestion3[this.state.userQuestions.tapLoaiNhaMua],
                giaNha: this.state.moneyHouseBuyNumber,
                tienVay: this.state.moneyHouseBorrowNumber,   // mandatory
                soDienThoai: this.state.userQuestions.userPhoneText,  // mandatory
                email: this.state.userQuestions.userEmailText,
                soCmnd: this.state.userQuestions.userIdentification, // mandatory
                tenNguoiVay: this.state.userQuestions.userFullName, // mandatory
                source: 'mobile'
        };
            ServiceApi.getLoanRegister(dtoContent);
            this.setState({
                isFirstBuy: this.state.isFirstBuy + 1
            })
        } else {
            this.setState({
                isFirstBuy: this.state.isFirstBuy + 1
            });
        }
    }

    _checkInputData() {
        let {userEmailText, tapMuaDau, tapAddressBuy, moneyHouseBorrowText, userPhoneText,
            userFullName, userIdentification} = this.state.userQuestions;
        if (this.state.isFirstBuy == 1 && !tapMuaDau) {
            return 'Để tiếp tục bạn cần chọn ĐÚNG hoặc SAI.';
        }
        if (this.state.isFirstBuy == 3 && !tapAddressBuy) {
            return 'Để tiếp tục bạn cần nhập địa chỉ muốn mua.';
        }
        if (this.state.isFirstBuy == 6 && !moneyHouseBorrowText) {
            return 'Để tiếp tục bạn cần nhập số tiền cần vay.';
        }
        if (this.state.isFirstBuy == 7 && ( !userFullName || !userPhoneText
            || !userIdentification)) {
            if (!userFullName) {
                return 'Để tiếp tục bạn cần nhập họ và tên.';
            }
            if (!userPhoneText) {
                return 'Để tiếp tục bạn cần nhập số điện thoại.';
            }
            if (userEmailText && (userEmailText.indexOf("@") < 0 || !util.validateEmail(userEmailText))) {
                return 'Email không đúng định dạng';
            }
            if (!userIdentification) {
                return 'Để tiếp tục bạn cần nhập số chứng minh nhân dân.';
            }
        }

        return null;
    }

    _onBackPress() {
        if (this.state.isFirstBuy == 1) {
            Actions.pop();
        } else {
            this.setState({
                isFirstBuy : this.state.isFirstBuy - 1
            });
        }

    }

    _renderModalFullPromote() {
        return(
            <Modal isOpen={this.state.isOpenFullPromote}
                   onClosed={this._onCloseFullPromote.bind(this)}
                   style={styles.viewFullPromote}
                   position={"top"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderFullPromoteContent()}
            </Modal>
        );
    }
    _onCloseFullPromote() {
        this.setState({
            isOpenFullPromote: false
        })
    }

    _renderModalEnd() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 8}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={[styles.viewBodyQuestions, {backgroundColor: 'blue'}]}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderModalEndContact()}
            </Modal>
        );
    }

    _renderModalEndContact() {
        let textSupportUser = 'Landber vừa nhận được thông tin mà quý khách muốn đăng ký, hệ thống sẽ kết nối để Ngân hàng liên lạc với quý khách trong khoảng thời gian sớm nhất. ' ;
        return(
            <View style={{flex:1}}>
                <View style={styles.pageHeader}>
                    <View style={styles.viewEditHome}>
                        <Text style={[styles.textEdit, {fontSize: 17}]}>Reway Group</Text>
                    </View>
                    <FullLine />
                </View>
                <View style={styles.viewBodyPromote}>
                    <Text style={[styles.textUpdate, {textAlign:'left', color: '#757575', fontSize: 15, marginLeft: 6}]}>
                        {textSupportUser}
                        <Text style={[styles.textUpdate, {textAlign:'left', color: '#3a3a3c', fontSize: 17}]}>
                            Cảm ơn quý khách!
                        </Text>
                    </Text>
                    <TouchableOpacity style={styles.viewButtonUpdate}
                                      onPress = {this._onCloseQuestion.bind(this)}
                    >
                        <Text style={[styles.textUpdate, {color: '#fff'}]}>Đóng</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _onCloseQuestion() {
        Actions.popTo('VayUocTinh3');
        //Actions.VayUocTinh();
    }


    _renderUserQuestion() {
        return(
            <View style={styles.viewBodyQuestions}>
                {this._onModalFirstBuy()}
                {this._onModalTimeBuy()}
                {this._onModalWhereBuy()}
                {this._onModalTypeHouse()}
                {this._onModalHouseCost()}
                {this._onModalInterest()}
                {this._onModalContactUs()}
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _onModalFirstBuy() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 1}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderFirstBuyContent()}
            </Modal>
        );
    }

    _onModalTimeBuy() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 2}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderModalTimeBuy()}
            </Modal>
        );
    }

    _onModalWhereBuy() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 3}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderWhereBuyContent()}
            </Modal>
        );
    }

    _onModalTypeHouse() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 4}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderTypeHouseContent()}
            </Modal>
        );
    }

    _onModalHouseCost() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 5}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderHouseCostContent()}
            </Modal>
        );
    }

    _onModalInterest() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 6}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderModalInterest()}
            </Modal>
        );
    }

    _onModalContactUs() {
        return(
            <Modal isOpen={this.state.isFirstBuy == 7}
                   onClosed={this._onCloseFirstBuy.bind(this)}
                   style={styles.viewBodyQuestions}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={false}
                   animationDuration={0}
                   backdropColor={'transparent'}
            >
                {this._renderModalContactUs()}
            </Modal>
        );
    }

    _onCloseFirstBuy() {

    }

    _renderFirstBuyContent() {
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Đây có phải lần đầu tiên bạn mua nhà?</Text>
                </View>
                <View style={styles.viewContentModal}>
                    <View style={styles.viewTabInterest}>
                        <UserTapButton name={'buyTrue'}
                                       onPress={this._onTapFirstBuy.bind(this)}
                                       selected={this.state.userQuestions.tapMuaDau == 'buyTrue'}>ĐÚNG</UserTapButton>
                        <UserTapButton name={'buyFalse'}
                                        onPress={this._onTapFirstBuy.bind(this)}
                                        selected={this.state.userQuestions.tapMuaDau == 'buyFalse'}>SAI</UserTapButton>
                    </View>
                </View>
            </View>
        );
    }

    _renderModalTimeBuy() {
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Bao lâu nữa bạn mua?</Text>
                </View>
                <View style={styles.viewContentModal}>
                    <View style={[styles.viewTabInterest, {height: 240}]}>
                        <UserTapButton name={'zeroToThree'}
                                       onPress={this._onTapTimeBuy.bind(this)}
                                       selected={this.state.userQuestions.tapTimeBuy == 'zeroToThree'}>0 - 3 tháng</UserTapButton>
                        <UserTapButton name={'threeToSix'}
                                       onPress={this._onTapTimeBuy.bind(this)}
                                       selected={this.state.userQuestions.tapTimeBuy == 'threeToSix'}>3 - 6 tháng</UserTapButton>
                        <UserTapButton name={'sixToYear'}
                                       onPress={this._onTapTimeBuy.bind(this)}
                                       selected={this.state.userQuestions.tapTimeBuy == 'sixToYear'}>6 - 12 tháng</UserTapButton>
                        <UserTapButton name={'timeOverYear'}
                                       onPress={this._onTapTimeBuy.bind(this)}
                                       selected={this.state.userQuestions.tapTimeBuy == 'timeOverYear'}>12+ tháng</UserTapButton>
                        <UserTapButton name={'timeToUnlimit'}
                                       onPress={this._onTapTimeBuy.bind(this)}
                                       selected={this.state.userQuestions.tapTimeBuy == 'timeToUnlimit'}>Tôi chưa biết</UserTapButton>
                    </View>
                </View>
            </View>
        );
    }

    _onTapFirstBuy(value) {
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                tapMuaDau: value
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                tapMuaDau: DanhMuc.userQuestion1[value]
            }
        });
        this._onNextModal(true);
    }

    _onTapTimeBuy(value) {
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                tapTimeBuy: value
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                tapTimeBuy: 'Thời gian ước tính mua nhà ' + DanhMuc.userQuestion2[value]
            }
        });
        this._onNextModal(true);
    }

    _onTapLoaiNha(value) {
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                tapLoaiNhaMua: value
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                tapLoaiNhaMua: 'Loại nhà cần mua ' + DanhMuc.userQuestion3[value]
            }
        });
        this._onNextModal(true);
    }

    _renderWhereBuyContent() {
        let diaChi = this.state.userQuestions.tapAddressBuy;
        let diaChiColor = (!diaChi || diaChi.length <= 0) ? '#9fa0a4' : '#000';
        let diaChiHienThi = 'Địa chỉ bạn muốn mua nhà: \n';
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Bạn muốn mua nhà ở đâu?</Text>
                </View>
                <View style={[styles.viewContentModal]}>
                    <View style={styles.viewUserBuy}>
                        <TouchableOpacity style={styles.inputUserBuy}
                                          onPress={this._onAddressPress.bind(this)}
                        >
                            <ScalableText style={[styles.textThietLap, {color: diaChiColor}]}>{this._onTextAddress()}</ScalableText>
                        </TouchableOpacity>
                        {
                            diaChi && diaChi.length > 0 ? (<View style={styles.viewAddressDetail}>
                            <ScalableText style={[styles.textNameTop, {paddingLeft: 10}]}>{diaChiHienThi}</ScalableText>
                            <ScalableText style={[styles.textThietLap, {color: gui.mainColor, paddingLeft: 10}]}>{diaChi}</ScalableText>
                        </View>) : null
                        }
                    </View>
                </View>
            </View>

        );
    }

    // _onAddresBuy(addressBuy) {
    //     this.setState({
    //         userQuestions: {
    //             ...this.state.userQuestions,
    //             tapAddressBuy: addressBuy
    //         },
    //         userDescriptions: {
    //             ...this.state.userDescriptions,
    //             tapAddressBuy: 'Địa chỉ muốn mua ' + addressBuy
    //         }
    //     })
    // }

    _onAddressPress () {
        Actions.QuestionPlacesAutoComplete(
            {
                onSuggestionBuyPressed: (location)=>this._collectSuggestionInfo(location),
            });
    }

    _getPlaceByLocation(lat, lon, callback) {
        findApi.getPlaceByLocation(lat, lon).then((res) => {
            if (res.success) {
                callback(res.result);
            }
        });
    }

    _collectSuggestionInfo(position) {
        if (position.placeType == DanhMuc.placeType.DIA_DIEM){
            this._getPlaceByLocation(position.location.lat, position.location.lon, (res) => {
                if (res) {
                    let diaChinh = {
                        codeDuAn: undefined,
                        codeDuong: undefined,
                        codeXa: res.codeXa || undefined,
                        codeHuyen: res.codeHuyen || undefined,
                        codeTinh: res.codeTinh || undefined,
                        duAn: undefined,
                        duong: undefined,
                        xa: res.xa || position.xaName || undefined,
                        huyen: res.huyen || position.huyenName || undefined,
                        tinh: res.tinh || position.tinhName || undefined,
                    };
                    this._updateDiaChinhDuAn(position, diaChinh);
                }
            });
        } else {
            let diaChinh = {
                codeDuAn: position.duAn || undefined,
                codeDuong: position.duong || undefined,
                codeXa: position.xa || undefined,
                codeHuyen: position.huyen || undefined,
                codeTinh: position.tinh || undefined,
                duAn: position.duAnName || undefined,
                duong: position.duongName || undefined,
                xa: position.xaName || undefined,
                huyen: position.huyenName || undefined,
                tinh: position.tinhName || undefined,
            };
            this._updateDiaChinhDuAn(position, diaChinh);
        }
    }

    _updateDiaChinhDuAn (position, diaChinh) {
        let codeDuAn = position.duAn || '';
        let fullName = codeDuAn ? 'Dự Án ' + position.fullName : position.fullName;
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                tapAddressBuy: fullName
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                tapAddressBuy: 'Địa chỉ muốn mua ' + position.fullName
            },
            codeDuAn: diaChinh.codeDuAn,
            codeDuong: diaChinh.codeDuong,
            codeXa: diaChinh.codeXa,
            codeHuyen: diaChinh.codeHuyen,
            codeTinh: diaChinh.codeTinh,
            duAn: diaChinh.duAn,
            duong: diaChinh.duong,
            xa: diaChinh.xa,
            huyen: diaChinh.huyen,
            tinh: diaChinh.tinh
        });
    }

    // _updateDiaChinhAddress (position) {
    //     this.setState({
    //         userQuestions: {
    //             ...this.state.userQuestions,
    //             tapAddressBuy: position.fullName
    //         },
    //         userDescriptions: {
    //             ...this.state.userDescriptions,
    //             tapAddressBuy: 'Địa chỉ muốn mua ' + position.fullName
    //         }
    //     });
    // }

    _onTextAddress () {
        let diaChi = this.state.userQuestions.tapAddressBuy;

        if (!diaChi || diaChi.length <= 0)
            return 'Nhập Tỉnh, Huyện, Xã hoặc Dự án';

        if (diaChi.length > 35) {
            diaChi = diaChi.substring(0, 35) + '...';
        }

        return diaChi;
    }

    _renderTypeHouseContent() {
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Loại nhà bạn mua là gì?</Text>
                </View>
                <View style={styles.viewContentModal}>
                    <View style={[styles.viewTabInterest, {height: 192}]}>
                        <UserTapButton name={'canHoChungCu'}
                                       onPress={this._onTapLoaiNha.bind(this)}
                                       selected={this.state.userQuestions.tapLoaiNhaMua == 'canHoChungCu'}>Căn hộ chung cư</UserTapButton>
                        <UserTapButton name={'loaiNhaRieng'}
                                       onPress={this._onTapLoaiNha.bind(this)}
                                       selected={this.state.userQuestions.tapLoaiNhaMua == 'loaiNhaRieng'}>Nhà riêng</UserTapButton>
                        <UserTapButton name={'loaiBietThu'}
                                       onPress={this._onTapLoaiNha.bind(this)}
                                       selected={this.state.userQuestions.tapLoaiNhaMua == 'loaiBietThu'}>Biệt thự, liền kề</UserTapButton>
                        <UserTapButton name={'loaiMatPho'}
                                       onPress={this._onTapLoaiNha.bind(this)}
                                       selected={this.state.userQuestions.tapLoaiNhaMua == 'loaiMatPho'}>Nhà mặt phố</UserTapButton>
                    </View>
                </View>
            </View>
        );
    }

    _renderHouseCostContent() {
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Bạn định mua nhà bao nhiêu tiền?</Text>
                </View>
                <View style={styles.viewContentModal}>
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'>
                            <View style={styles.contentInput}>
                                <TextInput
                                    keyboardType={'numeric'}
                                    selectTextOnFocus={true}
                                    autoFocus={true}
                                    returnKeyType='done'
                                    style={styles.inputBorrow}
                                    onChangeText={(moneyValue) => this._onMoneyBuyBox(moneyValue)}
                                    value={this.state.userQuestions.moneyHouseBuyText}
                                />
                                <View style={styles.viewButtonContinue}>
                                    <Text style={[styles.textUpdate, {color: '#d2d2d4'}]}>{DanhMuc.VND}</Text>
                                </View>
                            </View>
                    </KeyboardAwareScrollView>
                    {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                      style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                          backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}

                    <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>
                </View>
            </View>
        );
    }

    _onMoneyBuyBox(moneyValue) {
        let zeroNumber = '0' || '00' || '';
        if (moneyValue === zeroNumber) {
            moneyValue = '';
        }
        let moneyHouseBuyNumber = moneyValue.replace(/[a-zA-Z, -.]+/g,"");
        let valTienMua = moneyHouseBuyNumber && !isNaN(moneyHouseBuyNumber) ? Number(moneyHouseBuyNumber) : 0;
        let moneyHouseBuyText = util.addCommas(moneyHouseBuyNumber);
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                moneyHouseBuyText: moneyHouseBuyText
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                moneyHouseBuyText: 'Định mua nhà ' + moneyHouseBuyText + ' ' + DanhMuc.VND
            },
            moneyHouseBuyNumber: valTienMua,
        });
    }

    _renderModalInterest() {
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Bạn muốn vay bao nhiêu tiền?</Text>
                </View>
                <View style={styles.viewContentModal}>
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'>
                        <View style={styles.contentInput}>
                            <TextInput
                                keyboardType={'numeric'}
                                selectTextOnFocus={true}
                                autoFocus={true}
                                returnKeyType='done'
                                style={styles.inputBorrow}
                                onChangeText={(moneyBorrow) => this._onMoneyBorrowBox(moneyBorrow)}
                                value={this.state.userQuestions.moneyHouseBorrowText}
                            />
                            <View style={styles.viewButtonContinue}>
                                <Text style={[styles.textUpdate, {color: '#d2d2d4'}]}>{DanhMuc.VND}</Text>
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                    {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                      style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                          backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}

                    <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>
                </View>
            </View>
        );
    }

    _onMoneyBorrowBox(moneyBorrow) {
        let zeroNumber = '0' || '00' || '';
        if (moneyBorrow === zeroNumber) {
            moneyBorrow = '';
        }
        let moneyHouseBorrowNumber = moneyBorrow.replace(/[a-zA-Z, -.]+/g,"");
        let valMoneyTienVay = moneyHouseBorrowNumber && !isNaN(moneyHouseBorrowNumber) ? Number(moneyHouseBorrowNumber) : 0;
        let moneyHouseBorrowText = util.addCommas(moneyHouseBorrowNumber);
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                moneyHouseBorrowText: moneyHouseBorrowText,
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                moneyHouseBorrowText: 'Cần vay ' + moneyHouseBorrowText + ' ' + DanhMuc.VND
            },
            moneyHouseBorrowNumber: valMoneyTienVay,
        });
    }

    _renderModalContactUs() {
        return(
            <View style={{flex: 1}}>
                <View style={styles.viewQuestionTitle}>
                    <Text style={styles.textQuesTion}>Liên lạc với bạn như thế nào?</Text>
                </View>
                <View style={styles.viewContentModal}>
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'>

                        <View style={styles.contentContactUser}>
                            <View style={styles.viewPhoneUser}>
                                <Text style={[styles.textUpdate, {color: '#1b1b1b', fontSize: 15, textAlign:'left'}]}>
                                    Họ và tên:
                                    <Text style={[styles.textUpdate, {color: '#ff0000', fontSize: 15}]}> (*)</Text>
                                </Text>
                            </View>
                            <TextInput
                                keyboardType={'email-address'}
                                selectTextOnFocus={true}
                                autoFocus={true}
                                returnKeyType='done'
                                style={styles.inputPhoneUser}
                                onChangeText={(userFullName) => this._onUserFullName(userFullName)}
                                value={this.state.userQuestions.userFullName}
                            />
                        </View>
                        <View style={[styles.contentContactUser, {marginTop: 20}]}>
                            <View style={styles.viewPhoneUser}>
                                <Text style={[styles.textUpdate, {color: '#1b1b1b', fontSize: 15, textAlign:'left'}]}>
                                    Số điện thoại:
                                    <Text style={[styles.textUpdate, {color: '#ff0000', fontSize: 15}]}> (*)</Text>
                                </Text>
                            </View>
                            <TextInput
                                keyboardType={'numeric'}
                                selectTextOnFocus={true}
                                style={styles.inputPhoneUser}
                                onChangeText={(phoneText) => this._onUserPhone(phoneText)}
                                value={this.state.userQuestions.userPhoneText}
                            />
                        </View>
                        <View style={[styles.contentContactUser, {marginTop: 20}]}>
                            <View style={styles.viewPhoneUser}>
                                <Text style={[styles.textUpdate, {color: '#1b1b1b', fontSize: 15, textAlign:'left'}]}>Email: </Text>
                            </View>
                            <TextInput
                                keyboardType={'email-address'}
                                selectTextOnFocus={true}
                                returnKeyType='done'
                                style={styles.inputPhoneUser}
                                onChangeText={(emailText) => this._onUserEmail(emailText)}
                                value={this.state.userQuestions.userEmailText}
                            />
                        </View>
                        <View style={[styles.contentContactUser, {marginTop: 20}]}>
                            <View style={styles.viewPhoneUser}>
                                <Text style={[styles.textUpdate, {color: '#1b1b1b', fontSize: 15, textAlign:'left'}]}>
                                    Số chứng minh:
                                    <Text style={[styles.textUpdate, {color: '#ff0000', fontSize: 15}]}> (*)</Text>
                                </Text>
                            </View>
                            <TextInput
                                keyboardType={'numeric'}
                                selectTextOnFocus={true}
                                style={styles.inputPhoneUser}
                                onChangeText={(userIdentification) => this._onUserUserIdentification(userIdentification)}
                                value={this.state.userQuestions.userIdentification}
                            />
                        </View>
                    </KeyboardAwareScrollView>
                    {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                      style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                          backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}

                    <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

                </View>
            </View>
        );
    }

    _onUserFullName (userFullName) {
        let fullName = userFullName.replace(/[,0-9]+/g,"");
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                userFullName: fullName
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                userFullName: 'Họ và tên ' + fullName
            }
        });
    }

    _onUserPhone(phoneText) {

        let phone = util.monthNumeric(phoneText);
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                userPhoneText: phone
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                userPhoneText: 'Điện thoại liên lạc ' + phone
            }
        });
    }

    _onUserEmail(emailText) {
        let email = emailText.replace(/[, ]+/g,"");
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                userEmailText: email
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                userEmailText: 'Email liên lạc ' + email
            }
        });
    }

    _onUserUserIdentification (userIdentification) {
        let userIden = util.monthNumeric(userIdentification);
        this.setState({
            userQuestions: {
                ...this.state.userQuestions,
                userIdentification: userIden
            },
            userDescriptions: {
                ...this.state.userDescriptions,
                userIdentification: 'Số chứng minh thư ' + userIden
            }
        });
    }

    _renderFullPromoteContent() {
        let textPromoteFull = 'Reway Group là công ty hoạt động chủ yếu trong lĩnh vực bất động sản, với mục tiêu phát triển dự án Landber Agent thành nền tảng ứng dụng công nghệ hỗ trợ các nhà môi giới, sàn giao dịch bất động sản xây dựng và quản lý cộng đồng hàng đầu Việt Nam.';
        return(
            <View style={{flex:1}}>
                <View style={styles.pageHeader}>
                    <TouchableOpacity
                        onPress={() => this._onCloseFullPromote()}
                        style={[styles.searchButton, {paddingTop: 22}]}
                        activeOpacity={0}
                    >
                        <RelandIcon name="close" color={gui.mainColor} size={16}
                                    mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 8}}
                                    noAction={true}
                        />
                    </TouchableOpacity>
                    <View style={styles.viewEditHome}>
                        <Text style={[styles.textEdit, {fontSize: 17, color: gui.textPostAds}]}>Reway Group</Text>
                    </View>
                    <View style={styles.viewEdit}>
                    </View>
                </View>
                <View style={styles.viewBodyPromote}>
                    <Text style={[styles.textUpdate, {textAlign:'left', color: gui.textPostAds, fontSize: 15, marginLeft: 6}]}>
                        {textPromoteFull}
                    </Text>
                </View>
            </View>
        )
    }

    _renderStepButton() {
        let textPromote = 'Reway Group là công ty hoạt động chủ yếu trong lĩnh vực bất động sản, với mục tiêu ';
        return(
            <View style={styles.viewBottom}>
                <TouchableOpacity style={styles.viewHuyButton}
                                  onPress={this._onBackOriginPress.bind(this)}
                >
                    <Text style={[styles.textUpdate, {fontWeight: '500'}]}>Hủy</Text>
                </TouchableOpacity>
                <TouchableWithoutFeedback style={styles.viewForPromote}
                                  onPress={() => {this.setState({isOpenFullPromote: true})}}
                                  activeOpacity={0}
                >
                    <View style={styles.viewPromoteText}>
                        <Text style={[styles.textUpdate, {textAlign:'left', color: '#000', fontSize: 15}]}>
                            {textPromote}
                            <Text style={[styles.textUpdate, {color: gui.mainColor, fontSize: 15}]}> ... xem thêm</Text>
                        </Text>
                    </View>
                </TouchableWithoutFeedback>
            </View>
        );
    }

    _onBackOriginPress(){
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 65,
        width: width,
        borderBottomWidth: 1,
        borderColor: '#dcdcdc'
    },
    searchButton: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 100,
        paddingRight: 44
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 100
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18,
        backgroundColor: '#fff'
    },
    textEdit:{
        fontFamily:gui.fontFamily,
        color:gui.mainTextColor,
        fontWeight: '500',
        fontSize: 17
    },
    viewBodyQuestions: {
        flex: 1,
        backgroundColor: '#fff',
        height: height - 165,
        width: width
    },
    viewBottom: {
        position:'absolute',
        bottom: 0,
        backgroundColor: '#fff',
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 100
    },
    viewHuyButton: {
        backgroundColor: '#fff',
        marginBottom: 0,
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 40
    },
    viewForPromote: {
        height: 60,
        backgroundColor: '#f8f9fb',
        width: width
    },
    viewPromoteText: {
        height: 60,
        backgroundColor: '#f8f9fb',
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        paddingLeft: 8,
        paddingBottom: 8,
        padding: 5
    },
    textUpdate:{
        fontSize: 17,
        color:gui.mainColor,
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
    viewFullPromote: {
        position:'absolute',
        backgroundColor: 'white',
        width: width,
        height: height
    },
    viewBodyPromote: {
        flex: 1,
        paddingTop: 17,
        paddingLeft: 10,
        paddingRight: 5,
        backgroundColor: '#fff'
    },
    viewQuestionTitle: {
        width: width,
        height: 48,
        alignItems: 'center',
        justifyContent: 'flex-end'
    },
    textQuesTion: {
        fontSize: 17,
        color: '#030303',
        fontWeight: '500',
        fontFamily: gui.fontFamily
    },
    viewButtonUpdate: {
        position:'absolute',
        bottom: 0,
        backgroundColor: gui.mainColor,
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 43,
        borderRadius: 5,
        borderColor: gui.mainColor,
        borderWidth: 1
    },
    viewContentModal: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingTop: 44
    },
    viewTabInterest: {
        backgroundColor: '#fff',
        flexDirection: 'column',
        width: width - 80,
        height: 96
    },
    contentInput: {
        justifyContent: 'center',
        alignItems: 'center',
        height: 42,
        width: width - 80,
        borderColor: '#d2d2d4',
        borderWidth: 1,
        borderRadius: 5,
        flexDirection: 'row'
    },
    viewUserBuy: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 80,
        flexDirection: 'column',
        height: 120
    },
    inputBorrow: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 4,
        paddingRight: 10,
        height: 38,
        marginLeft: 0,
        width: width - 140,
        textAlign: 'left',
        alignSelf: 'flex-start',
        color: '#000'
    },
    inputUserBuy: {
        padding: 4,
        paddingLeft: 10,
        height: 38,
        marginLeft: 0,
        width: width - 80,
        borderColor: '#d2d2d4',
        borderWidth: 1,
        borderRadius: 3,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewButtonContinue: {
        height: 38,
        width: 58,
        justifyContent: 'center',
        alignItems: 'center'
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : '500',
        width: width
    },
    contentContactUser: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        height: 42,
        width: width,
        flexDirection: 'row',
        paddingLeft: 19
    },
    inputPhoneUser: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        paddingLeft: 8,
        height: 38,
        marginLeft: 20,
        width: width/2 - 20,
        borderColor: '#d2d2d4',
        borderWidth: 1,
        borderRadius: 3,
        textAlign: 'left',
        alignSelf: 'flex-start',
        color: '#1b1b1b'
    },
    viewPhoneUser: {
        height: 38,
        width: 135,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textContent: {
        color: '#8b8b90',
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        textAlign: 'left',
        marginTop: 16
    },
    textThietLap: {
        fontSize: 15,
        color: '#9fa0a4',
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    viewAddressDetail: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        width: width - 80,
        height: 82,
        paddingTop: 18,
        paddingRight: 2
    },
    textNameTop: {
        fontFamily: gui.fontFamily,
        color: '#030303',
        fontSize: 15,
        fontWeight: '400',
    }
});

export default UserQuestions;