'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, TextInput, Alert} from 'react-native';

import FullLine from '../line/FullLine';
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import log from '../../lib/logUtil';
import util from "../../lib/utils";
import MChartView from '../MChartView';
import MLikeTapButton from '../MLikeTapButton';

import {Actions} from 'react-native-router-flux';
import Button from 'react-native-button';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Slider from 'react-native-slider';

var {width, height} = util.getDimensions();

const MAX_SLIDER_LOAN = 10000000000; // don vi: VNĐ
const MAX_SLIDER_LOAN_PERIOD = 300; // don vi: tháng
const MAX_SLIDER_INTEREST_RATE = 50; // don vi: %
const SLIDER_SIZE = 100;
const SLIDER_STEP = 1;

class VayUocTinh extends React.Component {
    constructor(props) {
        super(props);
        let totalLoan = props.totalLoan;
        let loanPeriod = props.totalLoanPeriod;
        let interestRate = props.interestRate;
        let firstMonthLoan = props.firstMonthLoan;
        let firstMonthInterest = props.firstMonthInterest;
        let totalInterest =  props.totalInterest;

        this.state = {
            loanValueText: totalLoan ? util.addCommas(totalLoan.toString()) : '',
            loanValueNumber: totalLoan ? totalLoan : 0,
            totalOriginPerMonth: totalLoan ? totalLoan : 0,
            totalInterestPerMonth: totalInterest? totalInterest : 0,
            moneyValue: totalLoan ? totalLoan.toString() : '',
            slideValue: totalLoan ? (totalLoan/MAX_SLIDER_LOAN) * SLIDER_SIZE  : 0,
            timeValue: loanPeriod ? loanPeriod.toString() : '240',
            slideTime: loanPeriod ? (loanPeriod/MAX_SLIDER_LOAN_PERIOD) * SLIDER_SIZE : (240/MAX_SLIDER_LOAN_PERIOD) * SLIDER_SIZE,
            interestValue: interestRate ? interestRate.toString() : '8.5',
            slideInterest: interestRate ? (interestRate/MAX_SLIDER_INTEREST_RATE) * SLIDER_SIZE : (8.5/MAX_SLIDER_INTEREST_RATE) * SLIDER_SIZE,
            toggleState: false,
            summaryMonth: 0,
            originPerMonth: firstMonthLoan ? firstMonthLoan : 0,
            interestPerMonth: firstMonthInterest ? firstMonthInterest : 0,
            typeInterest: 'interestFirstMonth'
        }
    }

    _renderHeader() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>Ước tính tiền vay</Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {

        return (
            <View style={{flex: 1}}>
                {this._renderHeader()}
                <FullLine/>
                {this._renderBody()}
            </View>
        );
    }

    _renderBody() {
        return(
            <View style={styles.viewBody}>
                    <View style={[styles.scrollView]}>
                        <ScrollView style={[styles.scrollView]}
                                    keyboardShouldPersistTaps="always"
                                    keyboardDismissMode="none"
                                    ref="_scrollview"
                        >
                            {this._renderBodyTop()}
                            {this._renderTienVay()}
                            {this._renderThoiGianVay()}
                            {this._renderLaiSuat()}
                            {this._renderLoaiVay()}
                        </ScrollView>
                        {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                          style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                              backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}

                        <KeyboardSpacer topSpacing={-40} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>
                    </View>
                {this._renderButtonDangky()}
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _onTypeInterest(value) {
        this.setState({
            typeInterest: value
        });
    }

    _renderBodyTop() {
        return(
            <View style={styles.viewBodyTop}>
                <View style={styles.thangDauTien}>
                    <View style={styles.viewTabInterest}>
                        <MLikeTapButton name={'interestFirstMonth'}
                                       onPress={this._onTypeInterest.bind(this)}
                                       selected={this.state.typeInterest == 'interestFirstMonth'}>Tháng đầu tiên</MLikeTapButton>
                        <MLikeTapButton name={'interestTotalMonth'}
                                       onPress={this._onTypeInterest.bind(this)}
                                       selected={this.state.typeInterest == 'interestTotalMonth'}>Tổng phải trả</MLikeTapButton>
                    </View>
                    {this.state.typeInterest == 'interestFirstMonth' ?
                        <Text style={styles.textTrungBinh}>Số tiền bạn phải trả tháng đầu tiên :</Text> :
                        <Text style={styles.textTrungBinh}>Tổng số tiền phải trả :</Text>
                    }
                </View>
                {this._renderRowView()}
                <View style={styles.viewLoanDetail}>
                    <TouchableOpacity onPress = {this.onApply.bind(this)}
                                      style={styles.touchForMonth}
                    >
                        <Text style={styles.textChiTiet}>Xem chi tiết hằng tháng</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _renderRowView() {
        if (this.state.typeInterest == 'interestFirstMonth') {
            return (
                <View style={[styles.giaTrungBinh, {flexDirection: 'row', backgroundColor: 'transparent'}]}>
                    <View style={styles.coinUpperCaseCenter}>
                        {this._renderCoinPerMonth()}
                    </View>
                    <View style={styles.coinUpperCase}>
                        <View style={styles.coinChild}>
                            <View style={styles.viewCoinCircle}>
                                <View style={styles.viewCircleCoin} />
                            </View>
                            <View style={styles.viewCoinMonth}>
                                <Text style={[styles.textCoinDetail, {color: gui.mainColor}]}>{this.state.originPerMonth ? this.state.originPerMonth.toLocaleString() : "0"} VNĐ</Text>
                                <Text style={styles.textOrigin}>Tiền gốc</Text>
                            </View>
                        </View>
                        <View style={styles.coinChild}>
                            <View style={styles.viewCoinCircle}>
                                <View style={[styles.viewCircleCoin, {borderColor: '#f4ac57'}]} />
                            </View>
                            <View style={styles.viewCoinMonth}>
                                <Text style={[styles.textCoinDetail, {color: '#f4ac57'}]}>{this.state.interestPerMonth ? this.state.interestPerMonth.toLocaleString() : "0"} VNĐ</Text>
                                <Text style={styles.textOrigin}>Tiền lãi</Text>
                            </View>
                        </View>
                    </View>
                </View>
            );
        }
        else if (this.state.typeInterest == 'interestTotalMonth') {
            return (
                <View style={[styles.giaTrungBinh, {flexDirection: 'row', backgroundColor: 'transparent'}]}>
                    <View style={styles.coinUpperCaseCenter}>
                        {this._renderCoinPerMonth()}
                    </View>
                    <View style={styles.coinUpperCase}>
                        <View style={styles.coinChild}>
                            <View style={styles.viewCoinCircle}>
                                <View style={styles.viewCircleCoin} />
                            </View>
                            <View style={styles.viewCoinMonth}>
                                <Text style={[styles.textCoinDetail, {color: gui.mainColor}]}>{this.state.totalOriginPerMonth ? this.state.totalOriginPerMonth.toLocaleString() : "0"} VNĐ</Text>
                                <Text style={styles.textOrigin}>Tiền gốc</Text>
                            </View>
                        </View>
                        <View style={styles.coinChild}>
                            <View style={styles.viewCoinCircle}>
                                <View style={[styles.viewCircleCoin, {borderColor: '#f4ac57'}]} />
                            </View>
                            <View style={styles.viewCoinMonth}>
                                <Text style={[styles.textCoinDetail, {color: '#f4ac57'}]}>{this.state.totalInterestPerMonth? this.state.totalInterestPerMonth.toLocaleString() : "0"} VNĐ</Text>
                                <Text style={styles.textOrigin}>Tiền lãi</Text>
                            </View>
                        </View>
                    </View>
                </View>
            );
        } else return null;
    }

    _renderCoinPerMonth() {
        let main;
        let bonus;
        if (this.state.typeInterest == 'interestFirstMonth') {
             main = this.state.originPerMonth || 0;
             bonus = this.state.interestPerMonth || 0;
        } else if (this.state.typeInterest == 'interestTotalMonth') {
            main = this.state.totalOriginPerMonth || 0;
            bonus = this.state.totalInterestPerMonth || 0;
        }

        var data = [];
        var pallete = [];

        if (main>0 ) {
            data.push({
                "name": "",
                "fillColor" : "#1396E0",
                "value": main
            });
            pallete.push(util.hexToRgb("#1396E0"));
        }

        if (bonus>0){
            data.push({
                "name": "",
                "fillColor" : "#f4ac57",
                "value": bonus
            });
            pallete.push(util.hexToRgb("#f4ac57"));
        }

        var options = {
            margin: {
                top: 1,
                left: 2,
                bottom: 1,
                right: 2
            },
            width: 126,
            height: 126,
            r: 46,
            R: 61,
            legendPosition: 'topLeft',
            animate: {
                type: 'oneByOne',
                duration: 200,
                fillTransition: 3
            },
            label: {
                fontFamily: gui.fontFamily,
                fontSize: gui.buttonFontSize,
                fontWeight: 'normal'
            }
        };
        let chartTitleBold;
        let chartTitle;
        let totalMoney = main + bonus;
        let oneBillion = 1000000000;
        if(totalMoney >= 0 && totalMoney < oneBillion) {
            chartTitleBold = `${util.convertPriceToComaInterest(main + bonus)}`;
            chartTitle = 'Triệu';
        }
        if (totalMoney >= oneBillion) {
            chartTitleBold = `${util.convertPriceToComaBillion(main + bonus)}`;
            chartTitle = 'Tỷ';
        }
        // let chartTitleBold = `${util.convertPriceToComaInterest(main + bonus)}`;
        // let chartTitle = 'Triệu';
        return (
            <View>
                <View style={styles.viewChartProfile}>
                    <View style={styles.viewChartBody}>
                        <MChartView
                            data={data}
                            options={options}
                            pallete={pallete}
                            chartTitle={chartTitle}
                            chartTitleBold={chartTitleBold}
                            chartBold={'#ff0000'}
                            chartText={'#363636'}
                        />
                    </View>
                </View>
            </View>
        );
    }

    // _renderBodyBottom() {
    //     return (
    //         <ScrollView style={styles.viewBodyBottom}>
    //             {this._renderTienVay()}
    //             {this._renderThoiGianVay()}
    //             {this._renderLaiXuat()}
    //             {this._renderLoaiVay()}
    //         </ScrollView>
    //     );
    // }

    _renderTienVay() {
        return(
            <View style={styles.viewTienVay}>
                <View style={[styles.viewTopTienVay, {flexDirection: 'row'}]}>
                    <View style={styles.leftTienVay}>
                        <Text style={[styles.textCoinDetail, {color: '#3a3a3c'}]}>Số tiền vay</Text>
                    </View>
                    <View style={[styles.leftTienVay, {backgroundColor: '#fff', paddingLeft: 0}]}>
                        <View style={styles.viewInputCoin}>
                            <TextInput
                                keyboardType={'numeric'}
                                selectTextOnFocus={true}
                                returnKeyType='done'
                                style={styles.inputBorrow}
                                onChangeText={(moneyValue) => this._onLoanTextChange(moneyValue)}
                                value={this.state.loanValueText}
                                onFocus={this._onTienVayFocus.bind(this)}
                            />
                        </View>
                        <View style={styles.viewDonViRight}>
                            <Text style={styles.textRightVay}>VNĐ</Text>
                        </View>
                    </View>
                </View>
                <View style={[styles.viewTopTienVay, styles.viewSlider]}>
                        <Slider
                            value={(this.state.slideValue)}
                            onValueChange={this._onLoanSliderChange.bind(this)}
                            trackStyle={styles.track}
                            thumbStyle={styles.thumb}
                            minimumValue={0}
                            maximumValue={SLIDER_SIZE}
                            step={SLIDER_STEP}
                            minimumTrackTintColor={gui.mainColor}
                            maximumTrackTintColor='#e7e8ea'
                        />
                </View>
                <FullLine/>
            </View>
        );
    }

    _onTienVayFocus() {
        if (this.refs._scrollview) {
            if(this.state.toggleState){
                this.refs._scrollview.scrollTo({y: 90});
            } else {
                this.refs._scrollview.scrollTo({y: 90});
            }
        }
    }

    _onLoanSliderChange(slideValue){
        let totalPrincipal =  slideValue * MAX_SLIDER_LOAN/SLIDER_SIZE;

        let result = util.getPayment(totalPrincipal, this.state.timeValue, this.state.interestValue/100);
        let originPerMonth = result.allMonth[1].originalPerMonth;
        let interestPerMonth =result.allMonth[1].interestPerMonth;
        let totalOriginPerMonth = result.totalPrincipal;
        let totalInterestPerMonth = result.totalInterest;

        this.setState({
            originPerMonth: originPerMonth,
            interestPerMonth: interestPerMonth,
            loanValueText: util.addCommas(totalPrincipal),
            loanValueNumber: totalPrincipal,
            slideValue: slideValue,
            totalOriginPerMonth: totalOriginPerMonth,
            totalInterestPerMonth: totalInterestPerMonth
        });
    }


    _onLoanTextChange(moneyValue) {
        let moneyValueNumber = moneyValue.replace(/,/g,"");

        let valMoney = moneyValueNumber && !isNaN(moneyValueNumber) ? Number(moneyValueNumber) : 0;

        let result = util.getPayment(valMoney, this.state.timeValue, this.state.interestValue/100);

        let originPerMonth = result.allMonth[1].originalPerMonth;
        let interestPerMonth =result.allMonth[1].interestPerMonth;
        let totalOriginPerMonth = result.totalPrincipal;
        let totalInterestPerMonth = result.totalInterest;

        let slidePrincipal =  (valMoney/MAX_SLIDER_LOAN)*SLIDER_SIZE > 100 ? 100 : (valMoney/MAX_SLIDER_LOAN)*SLIDER_SIZE;

        this.setState({
            originPerMonth: originPerMonth,
            interestPerMonth: interestPerMonth,
            loanValueText: util.addCommas(moneyValueNumber),
            loanValueNumber: valMoney,
            slideValue: slidePrincipal,
            totalOriginPerMonth: totalOriginPerMonth,
            totalInterestPerMonth: totalInterestPerMonth
        });
    }

    _renderThoiGianVay() {
        return(
            <View style={styles.viewTienVay}>
                <View style={[styles.viewTopTienVay, {flexDirection: 'row'}]}>
                    <View style={styles.leftTienVay}>
                        <Text style={[styles.textCoinDetail, {color: '#3a3a3c'}]}>Thời gian vay</Text>
                    </View>
                    <View style={[styles.leftTienVay, {backgroundColor: '#fff', paddingLeft: 0}]}>
                        <View style={styles.viewInputCoin}>
                            <TextInput
                                keyboardType={'numeric'}
                                selectTextOnFocus={true}
                                returnKeyType='done'
                                style={styles.inputBorrow}
                                onChangeText={(timeValue) => this._onLoanPeriodTextChange(timeValue)}
                                value={this.state.timeValue}
                                onFocus={this._onThoiGianFocus.bind(this)}
                                />
                        </View>
                        <View style={styles.viewDonViRight}>
                            <Text style={styles.textRightVay}>tháng</Text>
                        </View>
                    </View>
                </View>
                <View style={[styles.viewTopTienVay, styles.viewSlider]}>
                    <Slider
                        value={this.state.slideTime}
                        onValueChange={this._onLoadPeriodSliderChange.bind(this)}
                        trackStyle={styles.track}
                        thumbStyle={styles.thumb}
                        minimumValue={1}
                        maximumValue={SLIDER_SIZE}
                        step={SLIDER_STEP}
                        minimumTrackTintColor={gui.mainColor}
                        maximumTrackTintColor='#e7e8ea'
                    />
                </View>
                <FullLine/>
            </View>
        );
    }

    _onThoiGianFocus() {
        if (this.refs._scrollview) {
            if(this.state.toggleState){
                this.refs._scrollview.scrollTo({y: 180});
            } else {
                this.refs._scrollview.scrollTo({y: 180});
            }
        }
    }

    _onLoanPeriodTextChange(timeValue) {
        if(!timeValue || timeValue == '0') {
            Alert.alert('Thông báo', 'Thời gian chọn không hợp lệ!');
            return;
        }
        let valTime = timeValue && !isNaN(timeValue) ? Number(timeValue) : MAX_SLIDER_LOAN/SLIDER_SIZE;
        let result = util.getPayment(   this.state.loanValueNumber,
                                        valTime,
                                        this.state.interestValue/100);
        let originPerMonth = result.allMonth[1].originalPerMonth;
        let interestPerMonth = result.allMonth[1].interestPerMonth;
        let totalOriginPerMonth = result.totalPrincipal;
        let totalInterestPerMonth = result.totalInterest;

        let loanPeriodSlider = (valTime/MAX_SLIDER_LOAN_PERIOD)*SLIDER_SIZE;
        loanPeriodSlider = loanPeriodSlider > 100 ? 100 : loanPeriodSlider;

        this.setState({
            originPerMonth: originPerMonth,
            interestPerMonth: interestPerMonth,
            timeValue: timeValue,
            slideTime: loanPeriodSlider,
            totalOriginPerMonth: totalOriginPerMonth,
            totalInterestPerMonth: totalInterestPerMonth

        });
    }

    _onLoadPeriodSliderChange(slideTime) {

        let result = util.getPayment(   this.state.loanValueNumber,
                                        slideTime*MAX_SLIDER_LOAN_PERIOD/SLIDER_SIZE,
                                        this.state.interestValue/100);

        let originPerMonth = result.allMonth[1].originalPerMonth;
        let interestPerMonth = result.allMonth[1].interestPerMonth;
        let totalOriginPerMonth = result.totalPrincipal;
        let totalInterestPerMonth = result.totalInterest;

        this.setState({
            originPerMonth: originPerMonth,
            interestPerMonth: interestPerMonth,
            timeValue: String(3*slideTime),
            slideTime: slideTime,
            totalOriginPerMonth: totalOriginPerMonth,
            totalInterestPerMonth: totalInterestPerMonth
        });

    }

    _renderLaiSuat() {
        return(
            <View style={styles.viewTienVay}>
                <View style={[styles.viewTopTienVay, {flexDirection: 'row'}]}>
                    <View style={styles.leftTienVay}>
                        <Text style={[styles.textCoinDetail, {color: '#3a3a3c'}]}>Lãi suất vay</Text>
                    </View>
                    <View style={[styles.leftTienVay, {backgroundColor: '#fff', paddingLeft: 0}]}>
                        <View style={styles.viewInputCoin}>
                            <TextInput
                                keyboardType={'numeric'}
                                selectTextOnFocus={true}
                                returnKeyType='done'
                                style={styles.inputBorrow}
                                onChangeText={(interestValue) => this._onInterestTextChange(interestValue)}
                                value={this.state.interestValue}
                                onFocus={this._onLaiXuatFocus.bind(this)}
                            />
                        </View>
                        <View style={styles.viewDonViRight}>
                            <Text style={styles.textRightVay}>%/năm</Text>
                        </View>
                    </View>
                </View>
                <View style={[styles.viewTopTienVay, styles.viewSlider]}>
                    <Slider
                        value={this.state.slideInterest}
                        onValueChange={this._onInterestSlider.bind(this)}
                        trackStyle={styles.track}
                        thumbStyle={styles.thumb}
                        minimumValue={0}
                        maximumValue={SLIDER_SIZE}
                        step={SLIDER_STEP}
                        minimumTrackTintColor={gui.mainColor}
                        maximumTrackTintColor='#e7e8ea'
                    />
                </View>
                <FullLine/>
            </View>
        );
    }

    _onLaiXuatFocus() {
        if (this.refs._scrollview) {
            if(this.state.toggleState){
                this.refs._scrollview.scrollTo({y: 270});
            } else {
                this.refs._scrollview.scrollTo({y: 270});
            }
        }
    }

    _onInterestTextChange(interestValue) {
        let valInterest = interestValue && !isNaN(interestValue) ? Number(interestValue) : 0;

        let result = util.getPayment(this.state.loanValueNumber, this.state.timeValue, valInterest/100);
        let originPerMonth = result.allMonth[1].originalPerMonth;
        let interestPerMonth = result.allMonth[1].interestPerMonth;
        let totalOriginPerMonth = result.totalPrincipal;
        let totalInterestPerMonth = result.totalInterest;

        let slideInterest = (valInterest/MAX_SLIDER_INTEREST_RATE) * SLIDER_SIZE;

        slideInterest = slideInterest>100 ? 100 : slideInterest;

        this.setState({
            originPerMonth: originPerMonth,
            interestPerMonth: interestPerMonth,
            interestValue: interestValue,
            slideInterest: slideInterest,
            totalOriginPerMonth: totalOriginPerMonth,
            totalInterestPerMonth: totalInterestPerMonth
        });
    }

    _onInterestSlider(slideInterest) {
        let interestValue = (slideInterest*MAX_SLIDER_INTEREST_RATE)/SLIDER_SIZE;

        let result = util.getPayment(   this.state.loanValueNumber,
                                        this.state.timeValue,
                                        interestValue/100);

        let originPerMonth = result.allMonth[1].originalPerMonth;

        let interestPerMonth = result.allMonth[1].interestPerMonth;
        let totalOriginPerMonth = result.totalPrincipal;
        let totalInterestPerMonth = result.totalInterest;

        this.setState({
            originPerMonth: originPerMonth,
            interestPerMonth: interestPerMonth,
            interestValue: String(interestValue),
            slideInterest: slideInterest,
            totalOriginPerMonth: totalOriginPerMonth,
            totalInterestPerMonth: totalInterestPerMonth
        });
    }

    _renderLoaiVay() {
        return(
            <View style={styles.viewDuNoBody}>
                <View style={styles.viewDuNoRow}>
                    <View style={styles.viewLoaiVay}>
                        <Text style={[styles.textCoinDetail, {color: '#3a3a3c'}]}>Loại vay</Text>
                    </View>
                    <TouchableOpacity style={styles.viewLoaiVayRight}
                          onPress={this._onLoaiVay.bind(this)}
                    >
                        <Text style={styles.textRightVay}>Dư nợ giảm dần</Text>
                        <View style={styles.arrowIcon}>
                            {/*<TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />*/}
                        </View>
                    </TouchableOpacity>
                </View>
                <FullLine/>
            </View>
        );
    }

    _onLoaiVay() {
        log.info('==============> press loan Type!!!');
    }
    _renderButtonDangky() {
        return(
            <TouchableOpacity style={styles.viewButtonUpdate}
                              onPress = {this._onDangKyVay.bind(this)}
            >
                <Text style={styles.textUpdate}>Đăng ký vay</Text>
            </TouchableOpacity>
        );
    }

    _onDangKyVay() {
        Actions.UserQuestions();
    }

    onApply() {
        if(this.state.loanValueNumber<=0){
            Alert.alert('Thông báo', 'Bạn nhập chưa chọn số tiền vay');
            return;
        }
        if(!Number(this.state.timeValue)){
            Alert.alert('Thông báo', 'Bạn nhập chưa chọn thời gian vay');
            return;
        }
        if(!Number(this.state.interestValue)){
            Alert.alert('Thông báo', 'Bạn nhập chưa chọn lãi xuất vay');
            return;
        }
        Actions.LoanMonthDetail({
            loanValue: Number(this.state.loanValueNumber),
            loanTime: Number(this.state.timeValue),
            loanInterest: Number(this.state.interestValue)
        });
    }

}
export default VayUocTinh;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: 'white'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewBodyTop: {
        width: width,
        height: 265,
        backgroundColor: '#fff'
    },
    giaTrungBinh: {
      width: width,
        height: 150,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f3f3f5'
    },
    thangDauTien: {
        width: width,
        height: 80,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f3f3f5',
        paddingBottom: 0
    },
    viewTabInterest: {
        width: 220,
        height: 38,
        backgroundColor: '#f3f3f5',
        flexDirection: 'row',
        borderRadius: 11,
        borderWidth: 1,
        borderColor: gui.mainColor

    },
    viewLoanDetail: {
      width: width,
        height: 30,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#f3f3f5',
        paddingBottom: 5
    },
    touchForMonth: {
        height: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    textChiTiet: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: '400'
    },
    textTrungBinh:{
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: '#59595b',
        marginTop: 3
    },
    textCoinMonth: {
        fontFamily: gui.fontFamily,
        fontSize: 11,
        fontWeight: '300',
        color: '#3a3a3c'
    },
    textCoinDetail: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '600',
        color: '#000'
    },
    textOrigin: {
        fontFamily: gui.fontFamily,
        fontSize: 11,
        fontWeight: '400',
        color: '#58585a'
    },
    viewLineConnect: {
        height: 28,
        width: 1,
        backgroundColor: 'rgba(88,88,90,0.7)'
    },
    textForMonth: {
        fontFamily: gui.fontFamily,
        fontSize: 42,
        fontWeight: '500',
        color: '#ec4e2b'
    },
    giaHangThang: {
        height: 100,
        justifyContent: 'center',
        backgroundColor: '#f3f3f5',
        width: 42,
        alignItems: 'center'
    },
    coinUpperCaseCenter:{
        width: width/2,
        height: 150,
        backgroundColor: '#f3f3f5',
        justifyContent: 'center',
        alignItems: 'center',
    },
    coinUpperCase: {
        width: width/2,
        height: 150,
        backgroundColor: '#f3f3f5',
        justifyContent: 'center',
        alignItems: 'flex-start',
        flex: 1
    },
    coinChild: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'row',
    },
    viewCoinCircle: {
        width: 15,
        height: 75,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingBottom: 14
    },
    viewCircleCoin:{
        width: 12,
        height: 12,
        borderRadius: 6,
        marginRight: 6,
        backgroundColor: 'white',
        borderWidth: 2,
        borderColor: gui.mainColor
    },
    viewCoinMonth: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        height: 75,
        width: width/2 - 15,
        paddingLeft: 8

    },
    viewCircle: {
         width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: '#1ea6e0',
        marginTop: 8
    },
    viewButtonUpdate: {
        position:'absolute',
        bottom: 0,
        backgroundColor: '#fa4917',
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 43
    },
    textUpdate:{
        fontSize: 17,
        color:'#fff',
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
    viewDonViRight: {
      height: 50,
        width: 65,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewInputCoin: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    textRightVay: {
        fontSize:15,
        color:'#a8a9ad',
        fontWeight: '300',
        fontFamily: gui.fontFamily
    },
    scrollView: {
        backgroundColor: '#fff',
        paddingBottom: 43,
        flex: 1
    },
    viewBodyBottom: {
        flex: 1,
        backgroundColor: '#fff',
        width: width,
        height: height - 372
    },
    viewTienVay: {
        width: width,
        height: 101,
        backgroundColor: '#fff'
    },
    viewTopTienVay: {
        width: width,
        height: 50,
        backgroundColor: '#fff'
    },
    leftTienVay: {
        width: width/2 - 30,
        height: 50,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 18,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    inputBorrow: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 4,
        paddingRight: 10,
        height: 30,
        borderColor: '#d2d2d4',
        borderWidth: 1,
        borderRadius: 3,
        marginLeft: 0,
        width: width/2 - 65 + 30,
        textAlign: 'right',
        alignSelf: 'flex-end',
        color: gui.mainColor
    },
    viewSlider: {
        backgroundColor: 'white',
        height: 40,
        width: width - 30,
        right: 15,
        left: 15,
        alignItems: 'stretch',
        justifyContent: 'center',
        flexDirection:'column',
        paddingBottom: 3
    },
    track: {
        height: 2,
        borderRadius: 1,
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: gui.mainColor,
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    viewDuNoBody: {
        width: width,
        height: 41,
        backgroundColor: '#fff',
        paddingVertical: 0
    },
    viewDuNoRow:{
        flex: 1,
        flexDirection: 'row',
        width: width,
        height: 40
    },
    viewLoaiVay: {
        width: width/2,
        height: 40,
        paddingLeft: 15,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    viewLoaiVayRight: {
        width: width/2,
        height: 40,
        paddingRight: 12 ,
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    arrowIcon: {
        backgroundColor:'transparent',
        justifyContent: 'center',
        alignItems: 'flex-end',
        width: 60,
        height:40,
        marginRight: 2
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : '500'
    },
    viewChartProfile: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor:'#f3f3f5',
        paddingTop: 0,
        paddingBottom: 0

    },
    viewChartBody: {
        paddingLeft: 0,
        paddingTop:0,
        width: width/2-25,
        alignItems: 'center',
        justifyContent: 'center'
    }
});