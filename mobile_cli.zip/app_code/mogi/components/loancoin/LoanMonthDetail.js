'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ListView} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

import GiftedSpinner from 'react-native-gifted-spinner';

var {width, height} = util.getDimensions();

let loanDs  = new ListView.DataSource({rowHasChanged:(r1,r2) => r1 !== r2 });

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
class LoanMonthDetail extends React.Component {
    constructor(props) {
        super(props);
        let result = this.props.resultDetail;
        // let numOfMonth = this.props.lastTimeValue;
        // let interestRatePerYear = this.props.lastInterestValue/100;
        // let preferredInterestRateMonth = this.props.preferredInterestRateMonth;
        // let preferredInterestRate =  this.props.preferredInterestRate/100;
        // let result = util.getPayment(totalPrincipal, numOfMonth, interestRatePerYear, preferredInterestRateMonth, preferredInterestRate);

        this.state = {
            dataSource: loanDs.cloneWithRows(result.allMonth),
            result: result,
            loading: true
        };
    }

    componentDidMount() {
        setTimeout(() => this.setState({loading: false}), 300);
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                    disabled={this.state.loading}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 15}]}>
                        Số tiền trả từng tháng
                    </Text>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        this.setState({loading: true});
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyBorrow()}
            </View>
        );
    }

    _renderLoadingView() {
        return (<View style={styles.viewBody}>
                <GiftedSpinner color="white" />
            </View>
        );
    }

    _renderBodyBorrow() {
        return(
            <View style={styles.viewBody}>
                    {this._renderBodyTop()}
                {this.state.loading ? this._renderLoadingView() :
                    <ScrollView
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
                        style={[styles.scrollView]}
                    >
                        {this._renderBodyBottom()}
                        {this._renderSummary()}
                        {this._renderDonVi()}
                    </ScrollView>
                }
                {this._renderButtonDangky()}
            </View>
        );
    }
    _renderBodyTop() {
        return(
            <View style={styles.viewBodyTop}>
                <View style={styles.viewThang}>
                    <Text style={styles.textThangTop}>Tháng</Text>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3}]}>
                    <Text style={styles.textThangTop}>Gốc còn lại</Text>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3}]}>
                    <Text style={styles.textThangTop}>Gốc</Text>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3, borderRightWidth: 0}]}>
                    <Text style={styles.textThangTop}>Lãi</Text>
                </View>
            </View>
        );
    }

    _renderBodyBottom() {
        return (
                <ListView
                    enableEmptySections = {true}
                    dataSource={this.state.dataSource}
                    renderRow={this._renderRowLoan.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                />
        );
    }
    _renderRowLoan(data) {
        return(
            <View style={styles.viewBodyTop}>
                <View style={[styles.viewThang, {backgroundColor: '#fff'}]}>
                    <ScalableText style={styles.textThang}>{data.month}</ScalableText>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3, backgroundColor: '#fff'}]}>
                    <ScalableText style={styles.textThang}>{util.addCommas(data.totalRemain.toString())}</ScalableText>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3, backgroundColor: '#fff'}]}>
                    <ScalableText style={styles.textThang}>{util.addCommas(data.originalPerMonth.toString())}</ScalableText>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3, borderRightWidth: 0, backgroundColor: '#fff'}]}>
                    <ScalableText style={styles.textThang}>{util.addCommas(data.interestPerMonth.toString())}</ScalableText>
                </View>
            </View>
        );
    }

    _renderSummary() {
        return(
            <View style={styles.viewBodyTop}>
                <View style={[styles.viewThang, {borderRightWidth: 0}]}>
                    <Text style={styles.textThangTop}>Tổng</Text>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3, borderRightWidth: 0}]} />
                <View style={[styles.viewThang, {width: (width-55)/3}]}>
                    <ScalableText style={styles.textThangTop}>{util.addCommas(this.state.result.totalPrincipal.toString())}</ScalableText>
                </View>
                <View style={[styles.viewThang, {width: (width-55)/3, borderRightWidth: 0}]}>
                    <ScalableText style={styles.textThangTop}>{util.addCommas(this.state.result.totalInterest.toString())}</ScalableText>
                </View>
            </View>
        );
    }

    _renderDonVi() {
        return(
            <View style={styles.viewBodyDonVi}>
                <View style={styles.viewBlankDonVi} />
                <View style={styles.viewRightDonVi}>
                    <Text style={[styles.textThang, {color: gui.mainColor}]}>Đơn vị: VNĐ</Text>
                </View>
            </View>
        );
    }

    _renderButtonDangky() {
        return(
            <TouchableOpacity style={styles.viewButtonUpdate}
                              onPress = {this._onDangKyVay.bind(this)}
            >
                <Text style={styles.textUpdate}>Đăng ký vay</Text>
            </TouchableOpacity>
        );
    }
    _onDangKyVay() {
        Actions.UserQuestions();
    }

}
export default LoanMonthDetail;

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewBodyTop: {
        width: width,
        height: 43,
        backgroundColor: '#fff',
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderColor: '#cfd0d2'

    },
    viewBodyDonVi:{
        width: width,
        height: 42,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewBlankDonVi: {
        width: width -(width-55)/3,
        height: 42,
        backgroundColor: '#fff'
    },
    viewRightDonVi:{
        width: (width-55)/3,
        height: 42,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewThang: {
        height: 42,
        width: 55,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f3f3f5',
        borderRightWidth: 1,
        borderColor: '#cfd0d2'
    },
    textThang:{
        fontSize:13,
        color:'#252528',
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
    textThangTop: {
        fontSize: 15,
        color:'#2f2f31',
        fontWeight: '600',
        fontFamily: gui.fontFamily
    },
    viewButtonUpdate: {
        position:'absolute',
        bottom: 0,
        backgroundColor: '#fa4917',
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 43
    },
    textUpdate:{
        fontSize: 17,
        color:'#fff',
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
    scrollView: {
        backgroundColor: '#fff',
        marginBottom: 38
    },
    viewListContainer: {
        paddingBottom: 0
    },
});