'use strict';

import  React, {Component} from 'react';

import {
    StyleSheet, StatusBar
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import gui from "../../lib/gui";
import log from "../../lib/logUtil";

import GooglePlacesAutocomplete from '../GooglePlacesAutocomplete';

class QuestionPlacesAutoComplete extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        StatusBar.setBarStyle('dark-content');
    }

    _onPress(data) {
        log.enter("DinhGiaPlacesAutocomplete._onPress", data);
        this.props.onSuggestionBuyPressed(data);
        Actions.pop();

    }

    _updateBarColor() {
        if (this.props.owner != 'home') {
            StatusBar.setBarStyle('dark-content');
        }
    }

    _onCancelPress() {
        Actions.pop();
        this._updateBarColor();
    }

    render() {
        StatusBar.setBarStyle('dark-content');
        let predefinedPlaces = [
        ];

        let placeHolder = 'Nhập Tỉnh, Huyện, Xã hoặc Dự án';

        return (

            <GooglePlacesAutocomplete
                placeholder={placeHolder}
                minLength={2} // minimum length of text to search
                autoFocus={true}
                fetchDetails={false}
                onPress={this._onPress.bind(this)}
                onCancelPress={this._onCancelPress.bind(this)}
                getDefaultValue={() => {
          return ''; // text input default value
        }}
                textInputProps={{
            autoCorrect: false
        }}
                styles={{
          description: {
            //fontWeight: 'bold',
            fontFamily : gui.fontFamily,
            fontSize: 15,
            marginLeft:10,
            marginRight: 10,
            color: '#3a3a3c'
          },
          predefinedPlacesDescription: {
            color: '#1faadb'
          },
          container: {
            paddingTop: 0,
            backgroundColor: 'white'
          },
          row : {
            height: 44
          },
          separator:{
            backgroundColor: "#E9E9E9",
            marginLeft: 0,
            marginRight: 0
          }
        }}

                currentLocation={false} // Will add a 'Vị trí Hiện tại' button at the top of the predefined places list
                predefinedPlacesAlwaysVisible={false}
                predefinedPlaces = {predefinedPlaces}
                enablePoweredByContainer={false}
                category={["DIA_CHINH", "DU_AN", "DUONG", "DIA_DIEM"]}
            />
        );
    }
}

export default QuestionPlacesAutoComplete;