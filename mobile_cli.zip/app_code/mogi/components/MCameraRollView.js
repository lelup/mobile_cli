'use strict';

import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    StatusBar,
    TouchableOpacity,
    Alert
} from 'react-native';

import gui from "../lib/gui";
import log from "../lib/logUtil";

import utils from './../lib/utils';
import FullLine from './line/FullLine';
var { width, height } = utils.getDimensions();
import TruliaIcon from './TruliaIcon';

import {Map} from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../reducers/global/globalActions';
import * as postAdsActions from '../reducers/postAds/postAdsActions';
import * as chatActions from '../reducers/chat/chatActions';
import * as registerActions from '../reducers/register/registerActions';
import * as meActions from '../reducers/me/meActions';

import CameraRollPicker from './cameraRoll/CameraRollPicker';

import ImageResizer from 'react-native-image-resizer';

import GiftedSpinner from 'react-native-gifted-spinner';

import {Actions} from 'react-native-router-flux';

import moment from 'moment';

import danhMuc from '../assets/DanhMuc';

import cfg from "../cfg";

var rootUrl = `${cfg.serverUrl}`;

//counter for image need upload (normal size + thumbnail size)
var count = 0;

const actions = [
    globalActions,
    postAdsActions,
    chatActions,
    registerActions,
    meActions
];

function mapStateToProps(state) {
    return {
        global: state.global,
        chat: state.chat,
        photos: state.postAds.photos,
        imageIndex: state.postAds.imageIndex,
        pickMode: state.postAds.pickMode
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MCameraRollView extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        let {photos, imageIndex, owner, pickMode} = props;

        let maxImage = 0;

        switch (owner) {
            case 'register':
                imageIndex = 0;
                maxImage = 1;
                break;
            case 'profile':
                imageIndex = 0;
                maxImage = 1;
                break;
            case 'chat':
                imageIndex = 0;
                maxImage = 1;
                break;
            case 'groupchat':
                imageIndex = 0;
                maxImage = 1;
                break;
            default:
                if (pickMode == 'edit') {
                    maxImage = 1;
                } else {
                    maxImage = 20;
                    for (let i=0; i< photos.length; i++){
                        if (photos[i].uri && photos[i].uri.length>0)
                            maxImage = maxImage -1;
                    }
                    if (maxImage<=0){
                        maxImage = 1;
                    }
                }
        }

        this.state = {
            num: 0,
            selected: [],
            photos : photos,
            imageIndex: imageIndex,
            maxImage: maxImage,
            owner: owner,
            loading: false,
            thumbnailUrl: null,
            fullSizeUrl: null
        };
    }

    getSelectedImages(images, current) {
        var num = images.length;
        this.setState({
            num: num,
            selected: images,
        });

    }

    _onChonPressed(){
        let owner = this.state.owner;
        let selectedPhotos = this.state.selected || [];
        let photos = this.state.photos || [];

        if (['register','chat', 'groupchat', 'profile'].indexOf(owner) >=0){
            if (selectedPhotos.length >0){
                let firstPhoto = selectedPhotos[0];
                switch(owner) {
                    case 'register':
                        log.info("take photo for registering user");
                        this.setState({loading: true});
                        this._onSelectRegisterAvatar(firstPhoto.image.uri);
                        break;
                    case 'chat':
                        log.info("take photo for chatting");
                        this.setState({loading: true});
                        this._onSendImage(firstPhoto.image.uri);
                        break;
                    case 'groupchat':
                        log.info("take photo for group chatting");
                        this.setState({loading: true});
                        this._onSendImage(firstPhoto.image.uri);
                        break;
                    case 'profile':
                        log.info("take photo for updating profile");
                        this.setState({loading: true});
                        this._onSelectProfileAvatar(firstPhoto.image.uri);
                        break;
                    default:
                        log.info("do nothing");
                }

            }
            
            return;
        }

        if ( selectedPhotos.length > 0 ){
            photos[this.state.imageIndex] = {uri: selectedPhotos[0].image.uri, location: selectedPhotos[0].location};

            for (var i=1; i<selectedPhotos.length; i++){
                for (var j=0; j<20; j++){
                    if (!photos[j] || !photos[j].uri || photos[j].uri.length<=0){
                        photos[j] = {uri: selectedPhotos[i].image.uri, location: selectedPhotos[i].location}
                        break;
                    }
                }
            }
        }

        this.props.actions.onPostAdsFieldChange('photos', this.state.photos);
        this.props.onTakePhoto && this.props.onTakePhoto();
        Actions.popTo('root');
        // Actions.PostAdsDetail({owner: this.props.owner});
        Actions.NewPostAdsDetail({owner: this.props.owner});
    }

    _onBack(){
        Actions.pop();
    }

    _onSelectRegisterAvatar(uri) {
        ImageResizer.createResizedImage(uri, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
            this.props.actions.onRegisterFieldChange('image', resizedImageUri);
            ImageResizer.createResizedImage(uri, cfg.thumbWidth, cfg.thumbWidth, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri2) => {
                this.props.actions.onRegisterFieldChange('thumbnail', resizedImageUri2);
                Actions.pop();
                Actions.pop();
            }).catch((err) => {
                log.error(err);
            });
        }).catch((err) => {
            log.error(err);
        });
    }

    _onSelectProfileAvatar(uri) {
        ImageResizer.createResizedImage(uri, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
            this.props.onChangeAvatar && this.props.onChangeAvatar(resizedImageUri, 'normal');
            
            ImageResizer.createResizedImage(uri, cfg.thumbWidth, cfg.thumbHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri2) => {
                this.props.onChangeAvatar && this.props.onChangeAvatar(resizedImageUri2, 'thumbnail');
                
                Actions.popTo('Profile');
            }).catch((err) => {
                log.error(err);
            });            
        }).catch((err) => {
            log.error(err);
        });
    }

    _onSendImage(uri) {
        count = 0;

        const userID = this.props.global.currentUser.userID;
        ImageResizer.createResizedImage(uri, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
            var ms = moment().toDate().getTime();
            var filename = 'Chat_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
            this.props.actions.onUploadImage(filename, resizedImageUri, this._uploadCallBack.bind(this), 'normal');
        }).catch((err) => {
            log.error(err);
        });

        //upload thumbnail for image chat
        ImageResizer.createResizedImage(uri, cfg.adsThumbWidth, cfg.adsThumbHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
            var ms = moment().toDate().getTime();
            var filename = 'Chat_Thumbnail' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
            this.props.actions.onUploadImage(filename, resizedImageUri, this._uploadCallBack.bind(this), 'thumbnail');
        }).catch((err) => {
            log.error(err);
        });
    }

    _uploadCallBack(err, result, type) {
        var {data} = result;
        if (err || data == '') {
            return;
        }
        var {success, file} = JSON.parse(data);
        if (success) {            
            var {url} = file;
            if (type=='thumbnail')
                this.state.thumbnailUrl = url
            if (type=='normal')
                this.state.fullSizeUrl = url
            count++;

            if (this.props.owner == 'chat') {
                this._onSaveMsg(url);
                Actions.pop();
                Actions.pop();
            }
            else if (this.props.owner == 'groupchat' && count==2) {
                this._onSaveGroupMsg(url);
                Actions.pop();
                Actions.pop();
            }
        }
    }

    _onSaveMsg(url) {
        log.info("Enter onSaveMsg...");

        const userID = this.props.global.currentUser.userID;
        const chatID = "Chat_" + userID + "_" + new Date().getTime();

        let myMsg = {
            _id : chatID,
            chatID : chatID,
            id : chatID,
            fromUserID : userID,
            fromFullName : this.props.global.currentUser.fullName,
            toUserID : this.props.chat.partner.userID,
            toFullName : this.props.chat.partner.fullName,
            relatedToAds : this.props.chat.ads,
            avatar: this.props.global.currentUser.avatar,
            content: url,
            msgType : danhMuc.CHAT_MESSAGE_TYPE.IMAGE,
            read: false,
            date : new Date(),
            type: 'Chat'
        };

        this.props.actions.sendChatMsg(myMsg);
    }

    _onSaveGroupMsg(url) {
        log.info("Enter onSaveGroupMsg...");

        const userID = this.props.global.currentUser.userID;
        const chatID = "ChatMsg_" + userID + "_" + new Date().getTime();

        let myMsg = {
            _id : chatID,            
            id : chatID,
            fromUserID : userID,
            fromUserAvatar: this.props.global.currentUser.thumbnail,
            fromUserEmail: this.props.global.currentUser.email,
            fromUserPhone: this.props.global.currentUser.phone,
            fromFullName : this.props.global.currentUser.fullName,            
            toChatGroupID: this.props.chat.chatGroupID,
            toChatGroupType: this.props.chat.chatGroupType,
            toChatGroupName: this.props.chat.chatGroupName,
            toChatGroupImage: this.props.chat.chatGroupImage,
            partners: this.props.chat.partners,          
            avatar: this.props.global.currentUser.thumbnail,
            content: this.state.thumbnailUrl,
            fullImage: this.state.fullSizeUrl,
            msgType : danhMuc.CHAT_MESSAGE_TYPE.IMAGE,                        
            type: 'ChatMsg',
            timestamp : new Date().getTime()
        };

        // this.props.actions.sendGroupChatMsg(myMsg);
        if (!this.props.chat.kicked)
            this.props.actions.sendGroupChatMsg(myMsg);
        else {
            Alert.alert('Thông báo', 'Bạn không thể tiếp tục chat trong nhóm này', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }
    }   

    render() {
        let chonBtn = this.state.loading ?
            <View style={styles.thoatButton}>
                <View style={{marginRight: 5}}>
                    <GiftedSpinner size="small" color="#8A8A8A"/>
                </View>
                <Text style={styles.thoatButtonText}>
                    Chọn
                </Text>
            </View> :
            <TouchableOpacity onPress = {() => this._onChonPressed()}>
            <View style={styles.thoatButton}>
                <Text style={styles.thoatButtonText}>
                    Chọn
                </Text>
            </View>
        </TouchableOpacity>

        return (
            <View style={styles.container}>
                <View style={styles.viewCameraRoll}>
                    <View style={styles.header}>
                        <TruliaIcon onPress = {() => this._onBack()}
                                    name="arrow-left" color={gui.mainColor} size={26}
                                    mainProps={styles.backButton} text={this.props.backTitle}
                                    textProps={styles.backButtonText} >
                        </TruliaIcon>
                        <View style={styles.customPageTitle}>
                            <Text style={styles.customPageTitleText}>
                                Kho ảnh
                            </Text>
                        </View>
                        {chonBtn}
                    </View>
                    <FullLine/>
                </View>
                <CameraRollPicker
                    // scrollRenderAheadDistance={500}
                    initialListSize={1}
                    pageSize={3}
                    removeClippedSubviews={false}
                    groupTypes='SavedPhotos'
                    batchSize={5}
                    maximum={this.state.maxImage}
                    selected={this.state.selected}
                    assetType='Photos'
                    imagesPerRow={3}
                    imageMargin={5}
                    callback={this.getSelectedImages.bind(this)} />
            </View>
        );
    }
}

var styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    headerSeparator: {
        marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    search: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start'
    },
    content: {
        marginTop: 15,
        height: 50,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        flexWrap: 'wrap',
    },
    text: {
        fontSize: 17,
        alignItems: 'center',
        color: '#fff',
    },
    bold: {
        fontWeight: 'bold',
    },
    info: {
        fontSize: 12,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        backgroundColor: 'transparent',
        height: 60
    },
    viewCameraRoll: {
        flexDirection: 'column',
        backgroundColor: 'transparent',
        height: 61,
        width: width
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: gui.mainColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    customPageTitle: {
        left:60,
        right:60,
        marginTop: 31,
        marginBottom: 10,
        position: 'absolute'
    },
    customPageTitleText: {
        color: gui.mainColor,
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    thoatButton: {
        marginTop: 31,
        // paddingTop: 31,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18,
        // paddingBottom: 18
    },
    thoatButtonText: {
        color: gui.mainColor,
        fontSize: 17,
        fontWeight: '400',
        fontFamily: gui.fontFamily,
        textAlign: 'right',
        marginRight: 7
    }
});

//module.exports = CameraRollView;

export default connect(mapStateToProps, mapDispatchToProps)(MCameraRollView);