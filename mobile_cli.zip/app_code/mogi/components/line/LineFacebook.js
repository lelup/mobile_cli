import React, {Component} from 'react';
import {
    Text,
    View,
    StyleSheet

} from 'react-native';

import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();
import gui from '../../lib/gui';
export default class LineFacebook extends Component {

    render(){
        let mstyle = this.props.style || {};
        return(
            <View style={[styles.headerSeparate, mstyle]}></View>
        );
    }
}

const styles = StyleSheet.create({
    headerSeparate: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },

});