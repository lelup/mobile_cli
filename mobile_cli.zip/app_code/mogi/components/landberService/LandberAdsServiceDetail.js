'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as meActions from '../../reducers/me/meActions';

import CommonUtils from '../../lib/CommonUtils';

import {Map} from 'immutable';

import React, {Component} from 'react';

import { Text, View, Image, ScrollView,TouchableOpacity,
    StyleSheet, StatusBar, TouchableHighlight, Linking, Alert, ListView, Animated, ImageBackground} from 'react-native'

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import {Actions} from 'react-native-router-flux';

import DanhMuc from '../../assets/DanhMuc';

import gui from '../../lib/gui';
import utils from '../../lib/utils';

import Icon from 'react-native-vector-icons/FontAwesome';
import FontAwesomeLight from '../font/FontAwesomeLight';

import log from '../../lib/logUtil';

import FullLine from '../line/FullLine';

import MMessage from '../message/MMessage';

import ScalableText from 'react-native-text'

import SelectSitesLink from '../postAds/SelectSitesLink';

var Analytics = require('react-native-firebase-analytics');

const actions = [
    globalActions,
    postAdsActions,
    adsMgmtActions,
    meActions
];

function mapStateToProps(state) {
  return {
      ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
          .merge(...actions)
          .filter(value => typeof value === 'function')
          .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

var {width, height} = utils.getDimensions();
var mapWidth = width-44;
var mapHeight = (width-width%2)/2+3;

var imgHeight = height/2;

var url = '';

class LandberAdsServiceDetail extends Component {
  constructor(props) {
    super(props);

    StatusBar.setBarStyle('default');

    let ads = props.ads;
    let streetViewUrl = '';
    if (ads.place.geo && !isNaN(ads.place.geo.lat) && !isNaN(ads.place.geo.lon)) {
        streetViewUrl = 'https://www.instantstreetview.com/s/'+ads.place.geo.lat+','+ads.place.geo.lon;
    }

    this.state = {
      textMessage: '',
      msgType: '',
      msgBgColor: null,
      msgTextColor: null,
      'data' : ads,
      'streetViewUrl': streetViewUrl,
      modal: false,
      isChatLoading: false,
      showAllSite: false
    }
  }

  _updateMessageProcessing(textMessage, bgColor, textColor) {
    this.setState({textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor});
    this._onMsgAnimationStart();
  }

  _onMsgAnimationStart() {
    this.setState({msgType: 'fadeInDown'});
    clearTimeout(this.msgTimer);
    this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
  }

  _renderMessageItem() {
    let textValue = this.state.textMessage;
    if (textValue == '' || this.state.msgType == '') {
      return null;
    }
    return (
        <MMessage mainStyle={{top: 0}}
                  hideStatus={this.state.msgType == 'fadeInDown'}
                  // barStyle="light-content"
                  animation={this.state.msgType}
                  duration={500}
                  onAnimationEnd={this._onAnimationEnd.bind(this)}
                  textValue={textValue}
                  bgColor={this.state.msgBgColor}
                  textColor={this.state.msgTextColor}/>
    );
  }

  _onAnimationEnd() {
    if (this.state.msgType === 'slideOutUp') {
      clearTimeout(this.msgTimer);
      this.msgTimer = setTimeout(() => {this.setState({textMessage: '', msgType: ''})}, 2000);
    }
  }

  componentWillMount() {
    //this.props.actions.loadHomeData();
    StatusBar.setBarStyle('default');
    // let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    // let userID = this.props.global.currentUser.userID || undefined;
    // Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
  }
  renderLoadingView() {
    return (
            <View style={styles.viewLoaderContent}>
                <View style={styles.viewLineLoader}></View>
                <View style={[styles.viewLineLoader1, {marginTop: 15}]}></View>
                <View style={[styles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[styles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[styles.viewLineLoader1, {width: width*3/4 -50}]}></View>

                <View style={[styles.viewLineLoader, {marginTop : 30 }]}></View>
                <View style={[styles.viewLineLoader1, {marginTop: 15}]}></View>
                <View style={[styles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[styles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[styles.viewLineLoader1, {width: width*3/4 -50}]}></View>
            </View>
    )
  }

  componentDidMount() {
  }

  _renderHeaderBar() {
      let label = 'Tin sử dụng dịch vụ của Landber';
      return (
        <View>
            <View style={[styles.customPageHeader, {backgroundColor: '#fff'}]}>
                <TouchableOpacity style={styles.viewPlusPost}
                                  onPress={this._onBack.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
              <View style={styles.detailMainLabel}>
                  <Text style={styles.detailMainText}>{label}</Text>
              </View>
            </View>
            <FullLine style={{ marginTop: 64 }} />
        </View>
    );
  }
  render() {
      let imageUriHome = {uri: this.props.imageDetail};
      if (!imageUriHome) {
          imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
      }

      let _scrollView: ScrollView;

    return (
        <View style={styles.fullWidthContainer}>
        <View style={styles.mainView}>
          <ScrollView
              ref={(scrollView) => { _scrollView = scrollView; }}
              automaticallyAdjustContentInsets={false}
              showsVerticalScrollIndicator={false}
              vertical={true}
              style={styles.scrollView}
          >
            <View style={styles.searchContent}>

                <View style={styles.wrapper}>
                    <ImageBackground style={[styles.imgItem, { height: gui.ADS_IMAGE_RATIO * width-12 }]}
                           source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}>
                        {/*this._renderTotalPhoto()*/}
                        {this._renderTypePost()}
                    </ImageBackground>
                    {this._renderBodyContent()}
                </View>

                {this.renderGoiViTri()}
                {this._renderPostToOtherWebsite()}
            </View>
          </ScrollView>

          {this._renderHeaderBar()}

          {this._renderMessageItem()}
        </View>
        </View>
		)
	}

    // _renderRejectPost (rowData) {
    //     let trangThaiTin = rowData.statusFmt || "";
    //     if (trangThaiTin == "Bị từ chối") {
    //         return (
    //             <TouchableOpacity style={myStyles.viewReject}
    //                               onPress={this._onPressRejectPost.bind(this, rowData)}
    //             >
    //                 <Text style={myStyles.textLyDo}>XEM LÝ DO</Text>
    //             </TouchableOpacity>
    //         );
    //     } else return null;
    // }

    renderGoiViTri() {
        let ads = this.state.data;
        let goiViTri = ads.landberInfo ? ads.landberInfo.goiViTri : undefined;
        if (!goiViTri || goiViTri.length <= 0) {
            return null;
        }

        let goiViTriName = utils.getLevelName(goiViTri);
        let remainDays = utils.getRemainDay(goiViTri);
        let dayConvert = utils.getPackValue2(remainDays);
        let label = 'NÂNG CẤP';

        if (ads.landberInfo && ads.landberInfo.status==3) {
            let textTuChoi = ' (Bị từ chối)'
            let xemLydo = 'Xem lý do'
            return (
                <View style={{flex: 1}}>
                {this._renderBasicInfo('ĐĂNG TIN TRÊN LANDBER')}
                <View style={styles.viewTotalGoiVip}>
                    <View style={styles.viewEachVip}>
                        <ScalableText style={styles.vipTextContent}>
                            {goiViTriName}{textTuChoi}
                        </ScalableText>

                    </View>

                    <TouchableHighlight onPress={() => this._onXemLyDoTuChoi(ads)}
                                        underlayColor='transparent'
                                        style={styles.goiViTriButton}>
                        <View>
                            <Text style={styles.goiViTriText}>{xemLydo}</Text>
                        </View>
                    </TouchableHighlight>
                </View>
            </View>
            )
        }
        
        return (
            <View style={{flex: 1}}>
                {this._renderBasicInfo('ĐĂNG TIN TRÊN LANDBER')}
                <View style={styles.viewTotalGoiVip}>
                    <View style={styles.viewEachVip}>
                        <ScalableText style={styles.vipTextContent}>
                            {goiViTriName}{dayConvert}
                        </ScalableText>

                    </View>

                    <TouchableHighlight onPress={() => this._onChangeGoiViTri(ads)}
                                        underlayColor='transparent'
                                        style={styles.goiViTriButton}>
                        <View>
                            <Text style={styles.goiViTriText}>{label}</Text>
                        </View>
                    </TouchableHighlight>
                </View>
            </View>
        )
    }

    _onXemLyDoTuChoi(ads) {
        Actions.RejectInfo({dataReject: ads});
    }

    _onChangeGoiViTri(ads) {
        this.props.actions.changePackageField('adsID', ads.adsID);
        this.props.actions.changePackageField('ads', ads);

        if (ads.landberInfo.goiViTri){
            let remainDays = utils.getRemainDay(ads.landberInfo.goiViTri);
            this.props.actions.changePackageField(
                'current_goiViTri', remainDays>0 ? utils.getLevelName(ads.landberInfo.goiViTri) : "Chưa có");
        } else {
            this.props.actions.changePackageField(
                'current_goiViTri', "Chưa có");
        }

        if (ads.goiLogo && ads.goiLogo.length>0) {
            ads.goiLogo.sort((a, b) => a.startDateTime - b.startDateTime);
            let index = ads.goiLogo.length - 1;
            let remainDays = utils.getRemainDay(ads.goiLogo[index]);
            this.props.actions.changePackageField(
                'current_goiLogo', remainDays>0 ? ads.goiLogo[index].text : "Chưa có");
        } else {
            this.props.actions.changePackageField(
                'current_goiLogo', "Chưa có");
        }

        let currentUser = this.props.global.currentUser;
        this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
            (res) => {
                if (res.status == 0) {
                    this.props.actions.changeSelectedPackage('goiViTri');
                    Actions.PackageUpdater({action : 'upgrade', doViTriFinalAction: this._doAfterChangeGoiViTri.bind(this)});
                } else {
                    Alert.alert('Thông báo', res.msg, [{text: 'Đóng', onPress: () => {}}]);
                }
            }
        );
    }

    _doAfterChangeGoiViTri() {

    }

    _renderPostToOtherWebsite() {
        let ads = this.state.data;
        let postAdsToOtherWebsite = ads.postAdsToOtherWebsite;
        if (!postAdsToOtherWebsite || postAdsToOtherWebsite.length <= 0) {
            return null;
        }

        let service = postAdsToOtherWebsite.service;
        let serviceName = service && service.name;

        let label = 'NÂNG CẤP';
        return (
            <View style={{flex: 1}}>
                {this._renderBasicInfo('ĐĂNG TIN TRÊN NHIỀU WEBSITE', true)}
                <View style={styles.viewTotalGoiVip}>
                    <View style={styles.viewEachVip}>
                        <ScalableText style={styles.vipTextContent}>
                            {serviceName}
                        </ScalableText>

                    </View>

                    <TouchableHighlight onPress={() => this._onChangeGoiPostToOtherWebsite(ads)}
                                        underlayColor='transparent'
                                        style={styles.goiViTriButton}>
                        <View>
                            <Text style={styles.goiViTriText}>{label}</Text>
                        </View>
                    </TouchableHighlight>
                </View>
                <FullLine style={[styles.lineStyle, {width: width}]}/>
                {this.renderSites()}
                <FullLine style={[styles.lineStyle, {width: width}]}/>
            </View>
        )
    }

    renderSites() {
        let {postAdsToOtherWebsite} = this.state.data;
        if (!postAdsToOtherWebsite || postAdsToOtherWebsite.length <= 0) {
            return null;
        }
        let showAllSite = this.state.showAllSite;
        let allSites = postAdsToOtherWebsite.sites || [];
        let sites = allSites;

        if (!showAllSite) {
            sites = sites.slice(0, 5);
        }

        let showAllSiteLabel = showAllSite ? 'Thu gọn' : 'Xem tất cả';
        let showAllSiteIcon = showAllSite ? 'chevron-up' : 'chevron-down';

        return(
            <View style={{flex: 1}}>
                <SelectSitesLink
                    items={sites}
                    selectedItems={sites}
                    selectedLabelStyle={{color: gui.mainColor}}
                    selectedRowStyle={{backgroundColor: gui.groupBackground2}}
                    selectedCheckboxStyle={{width: 19}}
                    rowStyle={{paddingLeft: 20, paddingTop: 5, paddingBottom: 5}}
                    onSelectionsChange={this.onSelectionsChange.bind(this)}
                    onPressLinkChange={(data) => this.onPressLinkChange(data)} />

                {allSites.length <= 5 ? null :
                    <TouchableHighlight underlayColor='transparent'
                                      onPress={() => this.setState({showAllSite: !showAllSite})}>
                        <View  style={[styles.viewMoreInfo, {marginTop: 16, marginBottom: 16}]}>
                            <Text style={styles.textMoreInfo}>{showAllSiteLabel}</Text>
                            <Icon name={showAllSiteIcon} color={gui.mainAgentColor} size={15} style={{marginLeft: 5}}/>
                        </View>
                    </TouchableHighlight>
                }
            </View>
        )
    }

    onSelectionsChange() {
        log.info('==========> onSelectionsChange');
    }
    onPressLinkChange(data) {
        let link = data.value;
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }

    _onChangeGoiPostToOtherWebsite(ads) {
        let currentUser = this.props.global.currentUser;
        this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
            (res) => {
                if (res.status == 0) {
                    Actions.PostOnWebsitesAgent({ads: ads});
                } else {
                    Alert.alert('Thông báo', res.msg, [{text: 'Đóng', onPress: () => {}}]);
                }
            }
        );
    }

    _renderBasicInfo(value, includeFirstLine) {
        return(
            <View style={styles.viewTextBasic}>
                {includeFirstLine ? <FullLine style={[styles.lineStyle, {width: width}]}/> : null}
                <Text style={[styles.textBasic, {fontSize: 13,
                    marginLeft: 12, marginRight: 12, marginTop: 10, marginBottom: 12}]}>{value}</Text>
                <FullLine style={[styles.lineStyle, {width: width}]}/>
            </View>
        );
    }

    _renderTypePost() {
        let data =  this.state.data;
        let typePost = DanhMuc.LoaiTin[data.loaiTin].toUpperCase();

        return (
            <View style={styles.viewNewTypePost}>
                <Text style={[styles.textTypePost, { fontSize: 14 }]}>{typePost}</Text>
            </View>
        );
    }

	_renderBodyContent() {

        let data = this.state.data;
        if(!data) {
            return this.renderLoadingView();
        }
        let giaFmt = data && data.giaFmt ? `Giá: ${data.giaFmt}` : '';
        let areaValue = data.dienTichFmt || DanhMuc.KHONG_RO;
        let bedroomValue = data.soPhongNgu ? String(data.soPhongNgu) : '';
        let bathroomValue = data.soPhongTam ? String(data.soPhongTam) : '';
        let huongNhaValue = data.huongNha ? DanhMuc.HuongNha[data.huongNha] : DanhMuc.BAT_KY;
        let diaChiFullName = data.diaChi ? data.diaChi : (data.place ? data.place.diaChi : ' ');
        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }
        return (
            <View style={[styles.viewNewDetailPost, {marginTop: 8, marginBottom: 8, paddingLeft: 12}]}>
                <FullLine style={[styles.lineStyle, {width: width-48}]}/>
                <View style={[styles.viewPercentDraft, { marginTop: 12 }]}>
                    <Text style={[styles.textGiaNha, { fontSize: 17, fontWeight: '500' }]} numberOfLines={1}>{giaFmt}</Text>
                </View>
                {detailItems && detailItems.length > 0 ? (
                    <View style={[styles.viewPercentDraft, { flexDirection: 'row', marginTop: 3 }]}>
                        {detailItems}
                    </View>
                ) : null}
                <View style={[styles.viewLabel, { alignItems: 'flex-start', marginTop: 5 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 72 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { fontSize: 14, color: gui.textPostCommon }]}>{diaChiFullName}</Text>
                    </View>
                </View>
            </View>
        );
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostCommon} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                                      name="compass" color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                                      name="bath" color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

  _onBack() {
    // if (this.props.owner != 'GroupWall') {
    //     StatusBar.setBarStyle('default');
    // }
    StatusBar.setBarStyle('default');
    Actions.pop();
  }

}

var styles = StyleSheet.create({
  pagingText: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: '#fff',
    marginRight: 10,
    marginBottom: 2,
    marginTop: 2
  },
  pagingIcon: {
    borderRadius: 0,
    marginLeft: 10,
    marginBottom: 2,
    marginTop: 2
  },
  pagingView: {
    flexDirection: 'row',
    backgroundColor: '#5b5c61',
    borderRadius: 5,
    opacity: 0.75
  },
  moiGioiStar: {
    marginRight: 5
  },
  moiGioiStarO: {
    marginRight: 5
  },
  moiGioiStarView: {
    flexDirection: 'row',
    marginTop: 5,
    marginBottom: 5
  },
  moiGioiRowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  moiGioiRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  moiGioiInfo: {
    flexDirection: 'column',
    marginLeft: 8,
    width: width - 192
  },
  moiGioiImage: {
    width: 60,
    height: 60
  },
  moiGioiName: {
    fontSize: 13,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: 'black'
  },
  moiGioiNumberOfAds: {
    fontSize: 13,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: 'black'
  },
  moiGioiButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  moiGioiChatButton: {
    backgroundColor: 'transparent',
    color: '#EA9409',
    borderColor: '#EA9409',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15,
    textAlign: 'center',
    borderWidth: 2,
    borderRadius: 5,
    padding: 5,
    paddingTop: 3,
    paddingBottom: 0
  },
  moiGioiCallButton: {
    backgroundColor: 'transparent',
    color: '#FB0007',
    borderColor: '#FB0007',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15,
    textAlign: 'center',
    borderWidth: 2,
    borderRadius: 5,
    marginLeft: 5,
    padding: 5,
    paddingTop: 3,
    paddingBottom: 0
  },
  shareButton: {
    paddingLeft: 10,
    marginTop: 24,
    paddingRight: 5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  backButton: {
    paddingLeft: 15,
    paddingRight: 15,
    marginTop: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  circleContainer: {
    marginTop: 0,
    marginBottom: 0,
    marginRight: 10,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#A8A8A8'
  },
    circleContainer2: {
        marginTop: -7,
        marginBottom: 0,
        marginRight: 10,
        backgroundColor: '#A8A8A8'
    },
  shareIcon: {
    marginTop: 5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  shareLeft: {
    width: width-80,
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: 8,
    marginBottom: 8
  },
  shareRight: {
    alignItems: 'flex-end',
    marginTop: 8,
    marginBottom: 8
  },
  welcome: {
      marginTop: -50,
      marginBottom: 50,
      fontSize: 17,
      textAlign: 'center',
      margin: 10,
  },
  linearGradient: {
    flexGrow: 1,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor : "transparent"
  },
  mainView: {
    flexGrow: 1,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor : "transparent"
  },
  scrollView: {
    flexGrow: 1,
    position: 'absolute',
    height: height-64,
    marginTop: 64
  },
  fullWidthContainer: {
    flexGrow: 1,
      alignItems: 'stretch',
      backgroundColor: 'white',
  },
  searchContent: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: gui.groupBackground2
  },
  searchDetailRowAlign: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-around',
  },
  chiTietText: {
      marginBottom: 8,
      marginLeft: 20
  },
  shareMainView: {
      flexDirection: 'row'
  },
  headerContainer: {
    borderBottomColor: '#D7D7D7',
    borderBottomWidth: 0.5
  },
  customPageHeader: {
      position: 'absolute',
      top: 0,
      left: 0,
      width: width,
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'flex-start',
      height: 64
  },
	search: {
      marginLeft: 20,
			marginTop: 20,
	    flexDirection: 'row',
	    alignItems: 'center',
			justifyContent: 'center',
			backgroundColor: 'transparent',
	},
  search2: {
      marginLeft: 10,
      marginTop: 28,
      marginRight: 5,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent',
  },
  wrapper: {
    marginTop: 12,
    marginLeft: 12,
    marginRight: 12,
    marginBottom: 0,
    backgroundColor: 'white',
    width: width-24,
    borderWidth: 1,
    borderColor: '#E1E1E1'
  },
  slide: {
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  dot : {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
    bottom: 32
  },
  dot2 : {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    marginTop: 11,
    marginLeft: 20,
    marginRight: 0,
    backgroundColor: '#C1C1C1'
  },
  dot3 : {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: 14,
    marginTop: 18,
    backgroundColor: 'white',
    borderWidth: 3.5
  },
  imgItem: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: width-24,
    height: imgHeight,
      alignSelf: 'auto'
  },
  searchMapView: {
    marginTop: 7,
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'center'
  },
  imgMapView: {
    width: mapWidth,
    height: mapHeight,
  },
  mapViewButton: {
    backgroundColor: 'transparent',
    width: mapWidth,
    // marginLeft: 20,
    // marginRight: 20
  },
  slideItem: {
    flexGrow: 1,
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    backgroundColor: 'transparent',
    marginTop: 8,
    paddingBottom: 15

  },
  price: {
    fontSize: 22,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    textAlign: 'left',
    backgroundColor: 'transparent',
    color: '#f33333',
    marginBottom: 8,
    marginLeft: 18.5,
    marginRight: 20,
  },
  textTitle: {
    fontSize: 17,
    fontFamily: gui.fontFamily,
    fontWeight: '600',
    textAlign: 'left',
    backgroundColor: 'transparent',
    color: 'black',
    marginBottom: 16,
    marginLeft: 20,
    marginRight: 22.5,
  },
  textHalfWidth: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 3,
    marginBottom: 4,
    marginLeft: 5,
    marginRight: 10,
    width: width/2-20
  },
  textHalfWidthBold: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: 'black',
    marginTop: 8,
    marginBottom: 8,
    marginLeft: 10,
    marginRight: 10,
    width: width/2-20
  },
  textHalfWidth2: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 3,
    marginBottom: 2,
    marginLeft: 10,
    marginRight: 9.5,
    width: width/2 - 55
  },
  textHalfWidthBold2: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: 'black',
    marginTop: 3,
    marginBottom: 2,
    marginLeft: 10,
    marginRight: 9.5,
    width: width/2 + 17
  },
  textFullWidth: {
    textAlign: 'justify',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 8,
    marginBottom: 7,
    marginLeft: 0,
    marginRight: 0,
  },
  lineBorder: {
    // borderTopWidth: 1,
    // borderTopColor: 'rgba(220,220,220,0.6)',
    width: width - 44,
    marginLeft: 20
  },
  lineBorder2: {
    borderTopWidth: 0,
    borderTopColor: 'rgba(220,220,220,0.6)',
    width: width,
    marginLeft: 0,
    marginRight: 0
  },
  danDuongView: {
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'space-between',
    paddingTop: 8,
    marginBottom: 8
  },
  danDuongLeftView: {
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  danDuongRightView: {
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  danDuongText: {
    marginLeft: 10,
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: 'black',
    textAlign: 'justify'
  },
    textTaiChinh: {
      textAlign: 'center',
      fontSize: 15,
      fontFamily: gui.fontFamily,
      color: gui.mainColor,
      fontWeight: '600',
      marginBottom: 8
    },
    viewListView: {
        flexGrow:1,
        backgroundColor:'white',
        marginTop:6,
        width: width - 37,
        // height: 142,
        marginRight: 37
    },
    viewListNhaGan: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    viewBdsCungLoai: {
        height: 'auto', //220,
        width: width,
        paddingLeft: 37,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewCungLoai: {
        // height: 221,
        width: width,
        marginBottom: 30,
        paddingLeft: 0,
        justifyContent: 'center',
        flexDirection: 'column'
    },
    viewTextTile: {
        marginTop: 11,
        height: 40,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: width - 92,
        height: 142,
        marginRight: 9
    },
    linearGradient2: {
        marginTop: 71,
        height: 71,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent",
        flexGrow: 1
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 8,
        right: 8,
        width: 35,
        height: 35,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 10
    },
    viewTextContent: {
        paddingTop: 8,
        marginTop: -71,
        marginLeft: 12,
        height: 71,
        width: 180
    },
    priceText: {
        fontSize: 13,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        paddingTop:1
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    },
    textTitleSuggest: {
        color   :'#000',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0,
    },
    viewImgDefault: {
      width: width,
      height: height/2 - 1,
      backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewImageBlank: {
        height: height/2,
        width: width
    },
    viewLoaderContent: {
        flex: 1,
        paddingLeft: 20,
        backgroundColor: 'transparent',
        justifyContent: 'flex-start',
        height: imgHeight,
        width: width
    },
    viewLineLoader: {
        height: 25,
        width: width/3,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
        marginTop: 16
    },
    viewLineLoader1: {
        height: 18,
        width: width*3/4,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
        marginTop: 10
    },
    tinCanMuaRowContent: {
        flex: 1,
        justifyContent:'center',
        width: width - 83,
        height: 142,
        flexDirection: 'row'
    },
    avatarContent: {
        height: 142,
        width: 90,
        justifyContent: 'center',
        alignItems: 'center'
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    tinCanMuaRowInfo: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 10,
        paddingLeft: 0,
        paddingTop: 0
    },
    tinCanMuaLine1Text: {
        fontSize: 12,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoTitleText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        height: 142,
        width: 9,
        backgroundColor: '#F0F0F2'
    },
    viewTabInterest: {
        flexGrow:1,
        flexDirection: 'row',
        paddingLeft: 5,
        paddingRight: 5
    },
    tabResultDetail: {
        borderTopRightRadius: 0,
        borderBottomRightRadius: 0,
        marginLeft: 10,
        marginRight: 0,
        borderRadius: 5,
        margin: 0,
        width: (width - 30)/3
    },
    tabNeedToBuy: {
        borderRadius: 0,
        margin: 0,
        width: (width - 30)/3,
        borderLeftWidth: 0,
        borderRightWidth: 0
    },
    tabNeedToReceive : {
        borderTopLeftRadius: 0,
        borderBottomLeftRadius: 0,
        marginLeft: 0,
        marginRight: 10,
        borderRadius: 5,
        margin: 0,
        width: (width - 30)/3
    },
    viewContent: {
        marginTop: 15,
        width: width - 37,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 18
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        // height: 80,
        width: width - 108,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 168,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        // paddingRight: 21,
        marginTop: 22,
        marginLeft: 16
    },
    viewContentButton: {
        width: width,
        height: 56,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    buttonContact: {
        height: 40,
        width: (width - 60)/2,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 20
    },
    textCommon: {
        fontSize: 13,
        fontFamily:gui.fontFamily,
        color: "rgba(112,112,112,1)",
        fontWeight: '500'
    },
    detailMainLabel: {
        position: 'absolute',
        top: 32,
        left: 44,
        right: 44,
        height: 35,
        width: width-88,
        alignItems: 'center',
        justifyContent: 'flex-start'
    },
    detailMainText: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor2
    },
    viewNewTypePost: {
        backgroundColor: gui.mainColor,
        paddingVertical: 6,
        paddingHorizontal: 14,
        borderRadius: 14,
        position: 'absolute',
        left: 11,
        bottom: 11
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewNewDetailPost: {
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width - 26
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostCommon,
        marginLeft: 0
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: '500',
        color: gui.textPostAds,
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        width: width - 50,
        height: 20,
        backgroundColor: '#fff'
    },
    viewTextBasic: {
        flex: 1,
        backgroundColor: '#F8F8F8'
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    textBasic: {
        fontFamily: gui.fontFamily,
        fontSize: 22,
        fontWeight: '500',
        color: gui.mainTextColor,
        justifyContent: 'flex-end'
    },
    viewEachVip: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 12,
        paddingTop: 16,
        paddingBottom: 16,
        flex: 1
    },
    vipTextContent: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#232323'
    },
    viewTotalGoiVip: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        width: width,
        backgroundColor: '#fff'
    },
    goiViTriButton: {
        width: 84,
        height: 32,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: gui.groupBackground,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.15,
        shadowRadius: 2
    },
    goiViTriText: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#3897F1'
    },
    viewMoreInfo: {
        height: 17,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        marginTop: 23,
        marginBottom: 22,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textMoreInfo: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: '500',
        color: gui.mainAgentColor
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(LandberAdsServiceDetail);
