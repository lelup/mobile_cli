// Import some code we need
import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import TruliaIcon from './TruliaIcon';

import {Actions} from 'react-native-router-flux';

import gui from '../lib/gui';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
// Create our component
var CommonHeader2 = React.createClass({
    render: function() {
        return <View style={myStyles.customPageHeader}>
            <View style={myStyles.customPageTitle}>
                <Text style={myStyles.customPageTitleText}>
                    {this.props.headerTitle}
                </Text>
            </View>
            <TouchableOpacity style={myStyles.viewPlusPost}
                              onPress={this._onBack}
            >
                <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} />
            </TouchableOpacity>
        </View>
    },
    _onBack: function() {
        Actions.pop();
    }
});

// Make this code available elsewhere
module.exports = CommonHeader2;

var myStyles = StyleSheet.create({
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#fff',
        height: 64
    },
    customPageTitle: {
        left:36,
        right:36,
        marginTop: 31,
        marginBottom: 10,
        position: 'absolute'
    },
    customPageTitleText: {
        color: gui.textAgentSolid,
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: '#fff',
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        // paddingRight: 21,
        marginTop: 22,
        marginLeft: 16
    },
});
