'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

import {Map} from 'immutable';

import gui from '../../lib/gui';

import React, {Component} from 'react';

import { Text, View, Navigator, TouchableOpacity, InteractionManager, TouchableHighlight, Alert
    , SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS, TextInput } from 'react-native'

import Button from 'react-native-button';
import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon'
import RelandIcon from '../RelandIcon';

import TitleTabButton from './TitleTabButton';
import RangeUtils from "../../lib/RangeUtils"

import DanhMuc from "../../assets/DanhMuc"

import SegmentedControl from '../SegmentedControl';

import log from '../../lib/logUtil';

import PickerExt from '../picker/PickerExt';

import FullLine from '../line/FullLine';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import ScalableText from 'react-native-text';

import placeUtil from '../../lib/PlaceUtil';

import Toast, {DURATION} from '../toast/Toast';

import GiftedSpinner from 'react-native-gifted-spinner';

import utils from '../../lib/utils';

var {width, height} = utils.getDimensions();

var Analytics = require('react-native-firebase-analytics');

const actions = [
    globalActions,
    needToBuyActions,
    adsMgmtActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class NeedToBuyFilter extends Component {
    constructor(props) {
        super(props);

        let {id, loaiTin, mua, thue, huongNha, dienTich, soTangSelectedIdx,
            soPhongNguSelectedIdx, soNhaTamSelectedIdx, ghiChu} = this.props.needToBuy.fields;
        let {initDienTich, fromDienTich, toDienTich} = this._initDienTich();
        let {initGia, fromGia, toGia} = this._initGia(loaiTin);
        this.state = {
            id: id,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            toggleState: false,
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            ghiChu: ghiChu,
            onCancelling: false,
            blankFromGiaColor: gui.placeholderColor,
            blankToGiaColor: gui.placeholderColor,
            blankDiaChiColor: gui.placeholderColor
        };
    }

    _initDienTich() {
        let {dienTich} = this.props.needToBuy.fields;
        let initDienTich = [];
        Object.assign(initDienTich, dienTich);
        let dienTichVal = RangeUtils.dienTichRange.toValRange(initDienTich);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        return {initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich};
    }

    _initGia(loaiTin) {
        let gia = this.props.needToBuy.fields[loaiTin].gia;
        let initGia = [];
        Object.assign(initGia, gia);
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(initGia);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        return {initGia: initGia, fromGia: fromGia, toGia: toGia};
    }

    _onLoaiTinChange(value) {
        let {initGia, fromGia, toGia} = this._initGia(value);
        this.setState({loaiTin: value, initGia: initGia, fromGia: fromGia, toGia: toGia, showGia: false, showDienTich: false});
    }

    _onPressGiaHandle(){
        // this.pickerGia.toggle();
        var {showGia} = this.state;
        this.setState({showGia: !showGia});
        if (!showGia) {
            this._onScrollGia();
        }
    }

    _onScrollGia() {
        if (this._scrollView) {
            // var {showDienTich} = this.state;
            // var scrollTo = 38;
            // if (showDienTich) {
            //     scrollTo = scrollTo + 225;
            // }
            // this._scrollView.scrollTo({y: scrollTo});
            this._scrollView.scrollTo({y: 40});
        }
    }

    _onPressDienTichHandle(){
        // this.pickerDienTich.toggle();
        var {showDienTich} = this.state;
        this.setState({showDienTich: !showDienTich});
        if (!showDienTich) {
            this._onScrollDienTich();
        }
    }

    _onScrollDienTich() {
        if (this._scrollView) {
            this._scrollView.scrollTo({y: 90});
        }
    }

    _onGhiChuFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + 175;
            if (this.showSoTang()) {
                scrollTo = scrollTo + 95;
            }
            if (this.showSoPhongNgu()) {
                scrollTo = scrollTo + 95;
            }
            if (this.showSoNhaTam()) {
                scrollTo = scrollTo + 95;
            }
            this._scrollView.scrollTo({y: scrollTo});
        }
    }

    _doChangeGia(loaiTin, giaVal) {
        var parent = {};
        Object.assign(parent, this.state[loaiTin]);
        parent.gia = giaVal;
        if (loaiTin == 'mua') {
            this.setState({mua: parent});
        } else {
            this.setState({thue: parent});
        }
    }

    // _onGiaChanged(pickedValue) {
    //     let {loaiTin} = this.state;
    //     let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
    //     let giaVal = pickedValue.split('_');
    //     let value = giaStepValues.rangeVal2Display(giaVal);
    //     this._doChangeGia(loaiTin, value);
    //     var initGia = [];
    //     Object.assign(initGia, value);
    //     let fromGia = giaVal[0];
    //     let toGia = giaVal[1];
    //     if (fromGia == -1 || fromGia == DanhMuc.BIG) {
    //         fromGia = '';
    //     } else if ('mua' === loaiTin) {
    //         fromGia = fromGia / 1000;
    //     }
    //     if (toGia == -1 || toGia == DanhMuc.BIG) {
    //         toGia = '';
    //     } else if ('mua' === loaiTin) {
    //         toGia = toGia / 1000;
    //     }
    //     this.setState({initGia: initGia, fromGia: fromGia, toGia: toGia});
    // }
    _onDienTichChanged(pickedValue) {
        let dienTichVal = pickedValue.split('_');
        let value = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        var initDienTich = [];
        Object.assign(initDienTich, value);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value});
    }

    // _getGiaValue() {
    //     let {loaiTin} = this.state;
    //     let gia = this.state[loaiTin].gia;
    //     let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
    //     let giaVal = giaStepValues.toValRange(gia);
    //     giaVal.sort((a, b) => this._onArraySort(a, b));
    //     let newGia = giaStepValues.rangeVal2Display(giaVal);
    //     return RangeUtils.getFromToDisplay(newGia, giaStepValues.getUnitText());
    // }

    // _getDienTichValue() {
    //     let {dienTich} = this.state;
    //     let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
    //     dienTichVal.sort((a,b) => this._onArraySort(a, b));
    //     let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
    //     return RangeUtils.getFromToDisplay(newDienTich, RangeUtils.dienTichRange.getUnitText());
    // }

    _getLoaiNhatDatValue() {
        let {loaiTin} = this.state;
        return DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat, true).substring(0, 25);
    }

    _getHuongNhaValue() {
        var {huongNha} = this.state;
        if (!huongNha) {
            return RangeUtils.BAT_KY;
        }
        return DanhMuc.HuongNha[huongNha];
    }

    _getHeaderTitle() {
        let {place} = this.props.needToBuy.fields;
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    render() {
        //log.info(RangeUtils.sellPriceRange.getPickerData());
        log.info("CALL Search.render");
        //log.info(this.props);

        let {loaiTin, blankDiaChiColor} = this.state;

        let diaChi = this._getHeaderTitle();
        let diaChiColor = (diaChi == gui.CHON_KHU_VUC) ? blankDiaChiColor : '#000';

        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={[myStyles.searchFilter, {top: 64}]}>

                    <View style={[myStyles.searchFilterButton]}>
                        <View style = {{flexGrow:1, flexDirection: 'row', paddingLeft: 5, paddingRight: 5}}>
                            
                            <TitleTabButton name={'mua'}
                                            disabled = {this.isUploading()}
                                           onPress={this._onLoaiTinChange.bind(this)}
                                           selected={loaiTin === 'mua'}
                                           mainProps={{borderTopLeftRadius: 5, borderBottomLeftRadius: 5,
                                                        borderTopWidth: 1, borderLeftWidth: 1, borderBottomWidth: 1,
                                           marginLeft: 10, marginRight: 0, width: width/2 - 15}}>Cần mua</TitleTabButton>
                            <TitleTabButton name={'thue'}
                                            disabled = {this.isUploading()}
                                           onPress={this._onLoaiTinChange.bind(this)}
                                           selected={loaiTin === 'thue'}
                                            mainProps={{borderTopRightRadius: 5, borderBottomRightRadius: 5,
                                                        borderTopWidth: 1, borderBottomWidth: 1, borderRightWidth: 1,
                                           marginLeft: 0, marginRight: 10, width: width/2 - 15}}>Cần thuê</TitleTabButton>
                        </View>
                        <FullLine />
                    </View>

                    <View style={myStyles.scrollView}>
                    <ScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        ref={(scrollView) => { this._scrollView = scrollView; }}
                        onLayout={event => {
                            this._scrollViewHeight = event.nativeEvent.layout.y
                          }}
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
                        style={myStyles.scrollView2}>

                        <View style={myStyles.searchFilterDetail}>
                            <View style={[myStyles.searchMoreFilterAttribute, myStyles.searchMoreSeparator]}>
                                <Text />
                            </View>
                            <TouchableOpacity
                                disabled = {this.isUploading()}
                                onPress={this._onAddressPress.bind(this)}
                            >
                                <View style={myStyles.searchDiaChinhView}>
                                    <View style={myStyles.diaChinhSubView}>
                                        <View style={myStyles.diaChinhTouchable}>
                                            <View style={myStyles.locationIcon}>
                                                <RelandIcon name="location" color={'#29AB60'} mainProps={{flexDirection: 'row'}}
                                                            size={22} textProps={{paddingLeft: 0}}
                                                            noAction={true} />
                                            </View>
                                            <ScalableText style={[myStyles.diaChinhText, {color: diaChiColor}]}>{this._getTextAddress()}</ScalableText>
                                        </View>
                                    </View>
                                </View>
                            </TouchableOpacity>
                            <View style={myStyles.searchSectionTitle}>
                                <Text style={myStyles.cacDieuKienText}>
                                    ĐẶC ĐIỂM
                                </Text>
                            </View>
                            <FullLine />
                            <TouchableOpacity
                                disabled = {this.isUploading()}
                                onPress={this._onPropertyTypesPressed.bind(this)}>
                                <View style={myStyles.searchFilterAttributeExt3}>
                                    <Text style={myStyles.searchAttributeLabel}>
                                        Loại nhà đất
                                    </Text>
                                    <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                                        <ScalableText style={myStyles.searchAttributeValue}> {this._getLoaiNhatDatValue()} </ScalableText>
                                        <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                                    </View>
                                </View>
                            </TouchableOpacity>
                            <FullLine style={{ marginLeft: 17 }} />
                            {this._renderGia()}
                            <FullLine style={{ marginLeft: 17 }} />
                            {this._renderDienTich()}
                            <FullLine style={{ marginLeft: 17 }} />
                            {this._renderHuongNha()}
                            {this.showSoTang() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                            {this._renderSoTang()}
                            {this.showSoPhongNgu() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                            {this._renderSoPhongNgu()}
                            {this.showSoNhaTam() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                            {this._renderSoNhaTam()}
                            <FullLine />
                            {this._renderGhiChu()}
                            <FullLine />
                        </View>

                        <View style={myStyles.searchMoreFilterButton}>
                            <View style={[myStyles.searchMoreFilterAttribute, myStyles.searchMoreSeparator]}>
                                <Text />
                            </View>
                            <FullLine />
                            <View style={myStyles.searchMoreFilterAttribute}>
                                <Button disabled = {this.isUploading()}
                                    onPress={() => this.onResetFilters(true)} style={myStyles.searchResetText}>Thiết lập lại</Button>
                            </View>
                            <FullLine />
                        </View>
                        <View style={myStyles.addViewBottom}></View>
                    </ScrollView>

                    {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                      style={[myStyles.searchButtonText2, {textAlign: 'right', color: gui.mainColor,
                                        backgroundColor: gui.doneKeyButton}]}>Xong</Button> : null}
                    <KeyboardSpacer topSpacing={-96} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

                    </View>
                </View>
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
                {this._renderPostWToButton()}
                {this._renderLoadingView()}
                {this._renderHeaderAds()}
            </View>
        );
    }

    _renderLoadingView() {
        if (this.state.onCancelling || this.isUploading()) {
            return (<View style={myStyles.resultContainer}>
                <View style={myStyles.loadingContent}>
                    <GiftedSpinner size="large" color={'#d3d3d3'} />
                </View>
            </View>)
        }
    }

    _renderPostWToButton() {
        if (this.isUploading()) {
            return (
                <View style={myStyles.searchButton}>
                    <GiftedSpinner color="white" />
                </View>
            )
        } else {
            return (
                <TouchableHighlight onPress={this.onApply.bind(this)}>
                    <View style={myStyles.searchButton}>
                        <ScalableText
                            style={[myStyles.searchButtonText, {fontWeight: 'bold'}]}>{this.state.id ? 'Cập nhật' : 'Đăng tin'}</ScalableText>
                    </View>
                </TouchableHighlight>
            )
        }
    }

    _onAddressPress() {
        let {place} = this.props.needToBuy.fields;
        let placeType = place.codeDuAn ? DanhMuc.placeType.DU_AN : DanhMuc.placeType.DIA_DIEM;
        let selectedDuAn = undefined;
        if (placeType == DanhMuc.placeType.DU_AN) {
            selectedDuAn = {
                duAn: place.codeDuAn,
                placeName: place.tenDuAn,
                tinhName: place.tenTinh,
                tinh: place.codeTinh,
                huyenName: place.tenHuyen,
                huyen: place.codeHuyen,
                xaName: place.tenXa,
                xa: place.codeXa,
                duongName: place.tenDuong,
                duong: place.codeDuong
            };
        }
        let selectedDiaChinh = {
            codeTinh: place.codeTinh || undefined,
            codeHuyen: place.codeHuyen || undefined,
            codeXa: place.codeXa || undefined,
            codeDuong: place.codeDuong || undefined,
            tinh: place.tenTinh || undefined,
            huyen: place.tenHuyen || undefined,
            xa: place.tenXa || undefined,
            duong: place.tenDuong || undefined
        }
        // Actions.WToPlacesAutoComplete(
        //     {
        //         onSuggestionPressed: (location)=>this._collectSuggestionInfo(location),
        //         onPositionInMapPressed: (position) => this._loadPositionInMap(position),
        //         viewport: place.viewport, diaChi: place.fullName, placeType: placeType,
        //         duAn: selectedDuAn, diaChinhInfo: selectedDiaChinh,
        //         circle: place.circle, polygon: place.polygon
        //     });
        this.setState({geoFinding: false});
        Actions.WToPlaceMapView({
            onPress: this._loadPositionInMap.bind(this),
            diaChi: place.fullName,
            viewport: place.viewport,
            placeType: placeType,
            duAn: selectedDuAn,
            diaChinhInfo: selectedDiaChinh,
            circle: place.circle,
            polygon: place.polygon
        });
    }

    _loadPositionInMap(position) {
        let {diaChinhInfo, duAn, diaChi, circle, polygon, viewport, location} = position;
        let ignoreDiaChinh = circle && circle.radius > 0 || polygon && polygon.length > 0;
        let place = {
            codeDuong: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.codeDuong || undefined),
            tenDuong: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.duong || undefined),
            codeXa: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.codeXa || undefined),
            tenXa: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.xa || undefined),
            codeHuyen: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.codeHuyen || undefined),
            tenHuyen: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.huyen || undefined),
            codeTinh: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.codeTinh || undefined),
            tenTinh: ignoreDiaChinh ? undefined : (diaChinhInfo && diaChinhInfo.tinh || undefined),
            codeDuAn: ignoreDiaChinh ? undefined : (duAn && duAn.duAn || undefined),
            tenDuAn: ignoreDiaChinh ? undefined : (duAn && duAn.duAnName || undefined),
            viewport: viewport || undefined,
            location: location || undefined,
            fullName: diaChi || undefined,
            circle: circle || undefined,
            polygon: polygon || undefined
        };
        this.props.actions.onNeedToBuyFieldChange('place', place);
    }

    _collectSuggestionInfo(position) {
        let place = {
            codeDuong: position.duong || undefined,
            tenDuong: (position.placeType == 'D' ? position.placeName : position.duongName) || undefined,
            codeXa: position.xa || undefined,
            tenXa: (position.placeType == 'X' ? position.placeName : position.xaName) || undefined,
            codeHuyen: position.huyen || undefined,
            tenHuyen: (position.placeType == 'H' ? position.placeName : position.huyenName) || undefined,
            codeTinh: position.tinh || undefined,
            tenTinh: (position.placeType == 'T' ? position.placeName : position.tinhName) || undefined,
            codeDuAn: position.duAn || undefined,
            tenDuAn: (position.placeType == 'A' ? position.placeName : position.duAnName) || undefined,
            viewport: position.viewport || undefined,
            fullName: position.fullName || undefined
        };
        this.props.actions.onNeedToBuyFieldChange('place', place);
    }

    _getTextAddress() {
        let diaChi = this._getHeaderTitle();

        if (diaChi && diaChi.length > 40) {
            diaChi = diaChi.substring(0, 40) + '...';
        }

        return diaChi ? diaChi : 'Nhập địa chính hoặc dự án...';
    }

    _renderGhiChu() {
        let placeholder = 'Nhập ghi chú...';
        return (
            <View style={myStyles.searchFilterAttribute}>
                <TextInput ref="textInput"
                           autoCorrect={false}
                           multiline={true}
                           onChangeText={this._onGhiChuChangeText.bind(this)}
                           style={myStyles.textInput}
                           value={this.state.ghiChu}
                           placeholder={placeholder}
                           placeholderTextColor={gui.arrowColor}
                           onFocus={() => this._onGhiChuFocus()}
                           clearButtonMode="never"
                           selectTextOnFocus={true}
                           disabled = {this.isUploading()}
                           allowFontScaling={false}
                />
            </View>
        )
    }

    _onGhiChuChangeText(text) {
        this.setState({ghiChu: text});
    }

    _renderHeaderAds() {
        return (
            <View style={myStyles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this.onCancel()}
                    style={myStyles.backButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={myStyles.viewTitleHeader}>
                    <ScalableText style={[myStyles.textHeader, {fontWeight: '500', fontSize: 17}]}>
                        Đăng tin cần mua/thuê
                    </ScalableText>
                </View>
                <View
                    style={myStyles.viewRightHeader}>
                </View>
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({toggleState: toggleState});
    }

    onCancel() {
        let isUpdate = this.state.id && this.state.id.length > 0 ;
        this.setState({onCancelling: true});
        Alert.alert('Thông báo', isUpdate ? 'Bạn muốn ngừng sửa tin ?': 'Bạn muốn ngừng đăng tin ?',
            [   { text: 'Hủy', onPress: () => {
                    this.setState({onCancelling: false});
                }
            },
                {
                    text: 'Đồng ý', onPress: () => {
                        Actions.pop();
                    }
                }
            ]);
    }

    isValidLoaiTin() {
        let {loaiTin} = this.state;
        let loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if (loaiNhaDat == '' || loaiNhaDat === 0) {
            return false;
        }
        let dmLoaiNhatDatKeys = loaiTin=='mua' ? DanhMuc.LoaiNhaDatBanKey : DanhMuc.LoaiNhaDatThueKey;
        let found = dmLoaiNhatDatKeys.filter((item) => item == loaiNhaDat);
        return found && found.length > 0;
    }

    isValidPlace() {
        let {place} = this.props.needToBuy.fields;
        let validDiaChinh = place.codeDuAn || place.codeXa || place.codeHuyen || place.codeTinh || place.codeDuong;
        let ignoreDiaChinh = (place.circle && place.circle.radius > 0) || (place.polygon && place.polygon.length > 0);
        let valid = ignoreDiaChinh || validDiaChinh;
        this.setState({blankDiaChiColor: valid ? '#000' : 'red'});
        return valid;
    }

    isValidGia() {
        let {loaiTin} = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let blankFromGiaColor = '#000';
        if (giaVal[0] <= 0) {
            blankFromGiaColor = 'red';
        }
        let blankToGiaColor = '#000';
        if (giaVal[1] <= 0 || giaVal[1] == DanhMuc.BIG) {
            blankToGiaColor = 'red';
        }
        this.setState({blankFromGiaColor: blankFromGiaColor, blankToGiaColor: blankToGiaColor});
        return giaVal[0] > 0 && (giaVal[1] > 0 && giaVal[1] != DanhMuc.BIG);
    }

    _validInputData() {
        let errors = '';

        if (!this.isValidPlace()) {
            errors += ' (địa điểm/dự án)';
        }
        //
        // if (!this.isValidLoaiTin()) {
        //     errors += ' (loại nhà)';
        // }

        if (!this.isValidGia()) {
            errors += ' (giá)';
        }

        if (errors != '') {
            return 'Bạn nhập thiếu thông tin' + errors + '!';
        }

        return null;
    }

    isUploading() {
        return this.props.needToBuy.needToBuyLoading;
    }

    onApply() {
        log.info("Call NeedToBuyFilter.onApply");
        let msg = this._validInputData();
        if (msg) {
            this.refs.toastTop && this.refs.toastTop.show(msg, 3000);
            return;
        }

        let {loaiTin, dienTich, soTangSelectedIdx, soPhongNguSelectedIdx, soNhaTamSelectedIdx, huongNha,
            ghiChu} = this.state;

        let {id, place} = this.props.needToBuy.fields;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        let mua = null;
        let thue = null;
        if (loaiTin == 'mua') {
            mua = this.state['mua'];
        } else {
            thue = this.state['thue'];
        }

        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;

        this.props.actions.onNeedToBuyFieldChange('loaiTin', loaiTin);
        this.props.actions.onNeedToBuyFieldChange(loaiTin, loaiNhaDatParent);

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);
        this.props.actions.onNeedToBuyFieldChange("dienTich", newDienTich);
        this.props.actions.onNeedToBuyFieldChange("soTangSelectedIdx", soTangSelectedIdx);
        this.props.actions.onNeedToBuyFieldChange("soPhongNguSelectedIdx", soPhongNguSelectedIdx);
        this.props.actions.onNeedToBuyFieldChange("soNhaTamSelectedIdx", soNhaTamSelectedIdx);
        this.props.actions.onNeedToBuyFieldChange("huongNha", huongNha);
        this.props.actions.onNeedToBuyFieldChange("ghiChu", ghiChu);

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let userID = currentUser.userID;

        let dto = {
            id: id,
            loaiTin: loaiTin,
            mua: loaiTin == 'mua' ? loaiNhaDatParent : undefined,
            thue: loaiTin != 'mua' ? loaiNhaDatParent : undefined,
            dienTich: newDienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            place : place,
            ghiChu: ghiChu,
            userID: userID
        };

        let loaiTinVal = (loaiTin === 'mua') ? 0 : 1;

        this.props.actions.saveNeedToBuy(dto, token)
            .then(res => {
                if (res.status != 0) {
                    this.refs.toastTop && this.refs.toastTop.show(res.error, 3000);
                } else {
                    setTimeout(() => {
                        let token = this.props.global.currentUser.token;
                        this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
                    }, 300);
                    this.props.actions.onAdsMgmtFieldChange('activeTab', loaiTinVal == 0 ? 2 : 3);
                    Actions.popTo('root');
                    Actions.AdsMgmt();
                    let wtoID = this.state.id;
                    if (wtoID && wtoID.length > 0) {
                        setTimeout(() => Alert.alert("Thông báo", "Thay đổi thành công."), 1000);
                    } else {
                        setTimeout(() => Alert.alert("Thông báo", "Tin đã đăng thành công."), 1000);
                    }
                }
            });
    }

    _onArraySort(a, b) {
        if (a === '') {
            return 1;
        }
        if (b === '') {
            return -1;
        }
        return a - b;
    }

    onResetFilters(keepID) {
        let defaultMua = {loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE};
        let defaultThue = {loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE};
        this.props.actions.onNeedToBuyFieldChange("mua", defaultMua);
        this.props.actions.onNeedToBuyFieldChange("thue", defaultThue);
        this.props.actions.onNeedToBuyFieldChange("soTangSelectedIdx", 0);
        this.props.actions.onNeedToBuyFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onNeedToBuyFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onNeedToBuyFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onNeedToBuyFieldChange("huongNha", 0);
        this.props.actions.onNeedToBuyFieldChange("place", {});
        this.props.actions.onNeedToBuyFieldChange("ghiChu", '');

        let id = keepID ? this.props.needToBuy.fields.id : null;
        this.props.actions.onNeedToBuyFieldChange('id', id);

        this.setState({id: id, initGia: RangeUtils.BAT_KY_RANGE, initDienTich: RangeUtils.BAT_KY_RANGE,
            fromDienTich: '', toDienTich: '', fromGia: '', toGia: '', showGia: false, showDienTich: false,
            mua: defaultMua, thue: defaultThue, dienTich: RangeUtils.BAT_KY_RANGE,
            soTangSelectedIdx: 0, soPhongNguSelectedIdx: 0, soNhaTamSelectedIdx: 0, huongNha: 0, ghiChu: '',
            onCancelling: false});
    }

    _onPropertyTypesPressed() {
        let {loaiTin} = this.state;
        Actions.PropertyTypesWTo({func: 'search', loaiTin: loaiTin, loaiNhaDat: this.state[loaiTin].loaiNhaDat,
            onLoaiNhaDatChange: (loaiNhaDat) => this._onLoaiNhaDatChange(loaiNhaDat)});
    }

    _onLoaiNhaDatChange(loaiNhaDat) {
        let {loaiTin} = this.state;
        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = loaiNhaDat;
        if (loaiTin == 'mua') {
            this.setState({mua: loaiNhaDatParent});
        } else {
            this.setState({thue: loaiNhaDatParent});
        }
    }

    _onHuongNhaPressed() {
        Actions.WToHuongNha({huongNha: this.state.huongNha, onHuongNhaChange: (huongNha) => this._onHuongNhaChange(huongNha)});
    }

    _onHuongNhaChange(huongNha) {
        this.setState({huongNha: huongNha});
    }

    _onSoPhongNguChanged(index) {
        this.setState({soPhongNguSelectedIdx: index});
    }

    _onSoTangChanged(index) {
        this.setState({soTangSelectedIdx: index});
    }

    _onSoNhaTamChanged(index) {
        this.setState({soNhaTamSelectedIdx: index});
    }

    _renderDienTich() {
        // var {showDienTich} = this.state;
        // var iconName = showDienTich ? "arrow-up" : "arrow-down";
        // return (
        //     <View>
        //         <TouchableOpacity
        //             onPress={this._onPressDienTichHandle.bind(this)}>
        //             <View style={myStyles.searchFilterAttribute}>
        //                 <Text style={myStyles.searchAttributeLabel}>
        //                     Diện tích
        //                 </Text>
        //
        //                 <View style={{flexDirection: "row", alignItems: "flex-end"}}>
        //                     <ScalableText style={myStyles.searchAttributeValue}>{this._getDienTichValue()} </ScalableText>
        //                     <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
        //                 </View>
        //             </View>
        //         </TouchableOpacity>
        //         {this._renderDienTichPicker()}
        //     </View>
        // );
        let {fromDienTich, toDienTich} = this.state;
        let fromPlaceholder = 'từ';
        let toPlaceholder = 'đến';
        let onTextChange = this._onDienTichInputChange.bind(this);
        let onTextFocus = this._onScrollDienTich.bind(this);
        return (
            <View style={myStyles.textInputView}>
                <View style={[myStyles.textInputView1, {width: width/3+15}]}>
                    <Text style={[myStyles.searchAttributeLabel, {marginLeft: 17}]}>
                        Diện tích (m²)
                    </Text>
                </View>
                <View style={[myStyles.textInputView1, {justifyContent: 'flex-end', width: width/3-10,
                borderRightColor: gui.separatorLine, borderRightWidth: 1}]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={myStyles.input}
                        placeholder={fromPlaceholder}
                        value={String(fromDienTich)}
                        onChangeText={(text) => onTextChange(0, text)}
                        onFocus={() => onTextFocus()}
                        disabled = {this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
                <View style={[myStyles.textInputView1, {width: width/3-10}]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={[myStyles.input, {marginLeft: 0, borderLeftColor: gui.separatorLine, borderLeftWidth: 1}]}
                        placeholder={toPlaceholder}
                        value={String(toDienTich)}
                        onChangeText={(text) => onTextChange(1, text)}
                        onFocus={() => onTextFocus()}
                        disabled = {this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
            </View>
        );
    }

    _renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder, onTextChange, onTextFocus,
                     pickerSelectedValue, onPickerValueChange, onPress, inputLabel, fromValue, toValue, unitText) {
        return (
            <PickerExt pickerRange={pickerRange} rangeStepValues={rangeStepValues} fromPlaceholder={fromPlaceholder}
                       toPlaceholder={toPlaceholder} onTextChange={onTextChange} onTextFocus={onTextFocus}
                       pickerSelectedValue={pickerSelectedValue} onPickerValueChange={onPickerValueChange}
                       onPress={onPress} inputLabel={inputLabel} fromValue={fromValue} toValue={toValue}
                       unitText={unitText}/>
        );
    }

    // _renderDienTichPicker() {
    //     var {showDienTich, initDienTich, fromDienTich, toDienTich} = this.state;
    //     if (showDienTich) {
    //         let rangeStepValues = RangeUtils.dienTichRange;
    //         let pickerRange = rangeStepValues.getAllRangeVal();
    //         let fromPlaceholder = 'Từ';
    //         let toPlaceholder = 'Đến';
    //         let onTextChange = this._onDienTichInputChange.bind(this);
    //         let onTextFocus = this._onScrollDienTich.bind(this);
    //         let dienTichRange = rangeStepValues.toValRange(initDienTich);
    //         let pickerSelectedValue = dienTichRange[0] + '_' + dienTichRange[1];
    //         let onPickerValueChange = this._onDienTichChanged.bind(this);
    //         return this._renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder,
    //             onTextChange, onTextFocus, pickerSelectedValue, onPickerValueChange,
    //             this._onPressDienTichHandle.bind(this), "m²", String(fromDienTich), String(toDienTich),
    //             rangeStepValues.getUnitText());
    //     }
    // }

    _onDienTichInputChange(index, val) {
        let {dienTich} = this.state;
        let newDienTich = [];
        Object.assign(newDienTich, dienTich);
        if (val === '') {
            val = -1;
        } else {
            val = utils.interestNumeric(val);
            if(utils.countDot(val, '\\.') >= 2){
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!',DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (val === '.') {
            val = '0.';
        }
        newDienTich[index] = val;
        let other = newDienTich[1-index];
        if (DanhMuc.CHUA_XAC_DINH == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            other = Number(other.substring(0, other.indexOf(" ")));
        } else {
            other = -1;
        }
        newDienTich[1-index] = other;
        // newDienTich.sort((a, b) => a - b);

        let value = RangeUtils.dienTichRange.rangeVal2Display(newDienTich);

        let fromDienTich = newDienTich[0];
        let toDienTich = newDienTich[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value});
    }

    _renderGia() {
        // var {showGia} = this.state;
        // var iconName = showGia ? "arrow-up" : "arrow-down";
        // return (
        //     <View>
        //         <TouchableOpacity
        //             onPress={this._onPressGiaHandle.bind(this)}>
        //             <View style={myStyles.searchFilterAttribute}>
        //                 <Text style={myStyles.searchAttributeLabel}>
        //                     Mức giá
        //                 </Text>
        //
        //                 <View style={{flexDirection: "row", alignItems: "flex-end"}}>
        //                     <ScalableText style={myStyles.searchAttributeValue}> {this._getGiaValue()} </ScalableText>
        //                     <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
        //                 </View>
        //             </View>
        //         </TouchableOpacity>
        //         {this._renderGiaPicker()}
        //     </View>
        // );
        let {loaiTin, fromGia, toGia, blankFromGiaColor, blankToGiaColor} = this.state;
        let fromPlaceholder = 'từ';
        let toPlaceholder = 'đến';
        let onTextChange = this._onGiaInputChange.bind(this);
        let onTextFocus = this._onScrollGia.bind(this);
        let donViTien = 'mua' === loaiTin ? "tỷ" : "triệu";
        return (
            <View style={myStyles.textInputView}>
                <View style={[myStyles.textInputView1, {width: width/3+15}]}>
                    <Text style={[myStyles.searchAttributeLabel, {marginLeft: 17}]}>
                        Mức giá ({donViTien})
                    </Text>
                </View>
                <View style={[myStyles.textInputView1, {justifyContent: 'flex-end', width: width/3-10,
                borderRightColor: gui.separatorLine, borderRightWidth: 1}]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={myStyles.input}
                        placeholder={fromPlaceholder}
                        placeholderTextColor={blankFromGiaColor}
                        value={String(fromGia)}
                        onChangeText={(text) => onTextChange(0, text)}
                        onFocus={() => onTextFocus()}
                        disabled = {this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
                <View style={[myStyles.textInputView1, {width: width/3-10}]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={[myStyles.input, {marginLeft: 0, borderLeftColor: gui.separatorLine, borderLeftWidth: 1}]}
                        placeholder={toPlaceholder}
                        placeholderTextColor={blankToGiaColor}
                        value={String(toGia)}
                        onChangeText={(text) => onTextChange(1, text)}
                        onFocus={() => onTextFocus()}
                        disabled = {this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
            </View>
        );
    }

    // _renderGiaPicker() {
    //     var {loaiTin, showGia, initGia, fromGia, toGia} = this.state;
    //     if (showGia) {
    //         var rangeStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
    //         let pickerRange = rangeStepValues.getAllRangeVal();
    //         let fromPlaceholder = 'Từ';
    //         let toPlaceholder = 'Đến';
    //         let onTextChange = this._onGiaInputChange.bind(this);
    //         let onTextFocus = this._onScrollGia.bind(this);
    //         let giaRange = rangeStepValues.toValRange(initGia);
    //         let pickerSelectedValue = giaRange[0] + '_' + giaRange[1];
    //         let onPickerValueChange = this._onGiaChanged.bind(this);
    //         let inputLabel = 'mua' === loaiTin ? "tỷ" : "triệu";
    //         return this._renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder,
    //             onTextChange, onTextFocus, pickerSelectedValue, onPickerValueChange,
    //             this._onPressGiaHandle.bind(this), inputLabel, String(fromGia), String(toGia),
    //             rangeStepValues.getUnitText());
    //     }
    // }

    _onGiaInputChange(index, val) {
        let {loaiTin} = this.state;
        let gia = this.state[loaiTin].gia;
        let rangeStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
        let newGia = [];
        let newVal = val;
        Object.assign(newGia, gia);
        if (newVal === '') {
            newVal = -1;
        } else {
            newVal = utils.interestNumeric(newVal);
            val = newVal;
            if(utils.countDot(newVal, '\\.') >= 2){
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!',DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (newVal === '.') {
            newVal = '0.';
        }
        // let hasLastDot = newVal[newVal.length-1] === '.';
        if ('mua' === loaiTin && newVal != -1) {
            newVal = 1000 * newVal;
        }
        // newGia[index] = hasLastDot && 'mua' === loaiTin ? newVal + '.' : newVal;
        newGia[index] = newVal;
        let other = String(newGia[1-index]);
        if (DanhMuc.THOA_THUAN == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            if (other.indexOf("tỷ") != -1) {
                other = 1000 * Number(other.substring(0, other.indexOf(" ")));
            } else {
                other = Number(other.substring(0, other.indexOf(" ")));
            }
        } else {
            other = -1;
        }
        newGia[1-index] = other;

        let value = rangeStepValues.rangeVal2Display(newGia);
        this._doChangeGia(loaiTin, value);
        let fromGia = newGia[0];
        let toGia = newGia[1];
        // hasLastDot = fromGia[fromGia.length-1] === '.';
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        // fromGia = hasLastDot && 'mua' === loaiTin ? fromGia + '.' : fromGia;
        // hasLastDot = toGia[toGia.length-1] === '.';
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        // toGia = hasLastDot && 'mua' === loaiTin ? toGia + '.' : toGia;
        if (index == 0) {
            this.setState({fromGia: val, toGia: toGia});
        } else {
            this.setState({fromGia: fromGia, toGia: val});
        }
    }

    _renderSoPhongNgu(){
        if (this.showSoPhongNgu()){
            return this._renderSegment("Số phòng ngủ", DanhMuc.getSoPhongNguValues(),
                this.state["soPhongNguSelectedIdx"], this._onSoPhongNguChanged.bind(this));
        } else if (0 != this.state.soPhongNguSelectedIdx) {
            this.setState({soPhongNguSelectedIdx: 0});
        }
        return null;
    }

    _renderSoTang() {
        if (this.showSoTang()){
            return this._renderSegment("Số tầng", DanhMuc.getSoTangValues(),
                this.state["soTangSelectedIdx"], this._onSoTangChanged.bind(this));
        }else if (0 != this.state.soTangSelectedIdx) {
            this.setState({soTangSelectedIdx: 0});
        }
        return null;
    }

    _renderSoNhaTam() {
        if (this.showSoNhaTam()){
            return this._renderSegment("Số nhà tắm", DanhMuc.getSoPhongTamValues(),
                this.state["soNhaTamSelectedIdx"], this._onSoNhaTamChanged.bind(this));
        }else if (0 != this.state.soNhaTamSelectedIdx) {
            this.setState({soNhaTamSelectedIdx: 0});
        }
        return null;
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                              onChange={onChange} disabled = {this.isUploading()} />
        );
    }

    _renderHuongNha() {
        return (
            <TouchableOpacity
                disabled = {this.isUploading()}
                onPress={() => this._onHuongNhaPressed()}>
                <View style={myStyles.searchFilterAttributeExt3}>
                    <Text style={myStyles.searchAttributeLabel}>
                        Hướng nhà
                    </Text>
                    <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                        <ScalableText style={myStyles.searchAttributeValue}> {this._getHuongNhaValue()} </ScalableText>
                        <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    showSoPhongNgu(){
        var {loaiTin} = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if (loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0){
            return true;
        } else {
            return false;
        }
    }

    showSoTang(){
        var {loaiTin} = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if ((loaiNhaDat && [2,3,4].indexOf(loaiNhaDat)>=0 && loaiTin=='mua')
            || (loaiNhaDat && [2,3,4,5,6].indexOf(loaiNhaDat)>=0 && loaiTin=='thue')
        ) {
            return true;
        } else {
            return false;
        }
    }

    showSoNhaTam(){
        var {loaiTin} = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if (loaiNhaDat && [1,2,3,4].indexOf(loaiNhaDat)>=0) {
            return true;
        } else {
            return false;
        }
    }

    showBanKinhTimKiem(){
        // let {center} = this.props.search.form.fields;
        // return center && !isNaN(center.lat);
        return false;
    }
}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        width: width,
        height: 64
    },
    // searchAttributeLabelBold : {
    //   fontSize: gui.normalFontSize,
    //   fontFamily: gui.fontFamily,
    //   color: 'black',
    //   fontWeight: 'bold'
    // },

    searchButton: {
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        top: height -44 ,
        height: 44,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: '#E83522',
    },
    // searchButtonWrapper: {
    //   flexDirection: 'row',
    //   justifyContent: 'space-between',
    //   backgroundColor: gui.mainColor,
    //   height: 44
    // },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 11,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchMoreFilterButton: {
        flexGrow: 0.5,
        alignItems: 'stretch',
        justifyContent: 'center'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchResetText: {
        color: 'red',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    searchAttributeLabel : {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: 'black'
    },
    searchAttributeValue : {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.arrowColor,
        marginRight: 3
    },
    searchFilterButton: {
        flexDirection: 'column'
    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchSectionTitle: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingLeft: 17,
        paddingTop: 28,
        paddingBottom: 8,
        // borderTopWidth: 1,
        // borderTopColor: '#f8f8f8',
        backgroundColor: '#f8f8f8'
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection:"column"
        //borderWidth:1,
        //borderColor: "green"
    },
    scrollView: {
        flex: 1,
        height: height-210
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent :'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    // searchFilterAttribute2: {
    //   flexDirection : "row",
    //   borderWidth:1,
    //   borderColor: "red",
    //   justifyContent :'space-between',
    //   paddingRight: 8,
    //   paddingTop: 5,
    //   paddingLeft: 17,
    //   paddingBottom: 7,
    //   borderTopWidth: 0,
    //   borderTopColor: gui.separatorLine
    // },
    searchFilterAttribute3: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 17,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 0,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    // searchFilterAttributeExt2: {
    //   flexDirection : "row",
    //   borderWidth:1,
    //   borderColor: "red",
    //   justifyContent :'space-between',
    //   paddingRight: 10,
    //   paddingTop: 5,
    //   paddingLeft: 0,
    //   paddingBottom: 8,
    //   borderTopWidth: 0,
    //   marginLeft: 17,
    //   borderTopColor: gui.separatorLine
    // },
    searchFilterAttributeExt3: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 17,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    // ngayDaDangItem: {
    //   fontSize: gui.normalFontSize,
    //   fontFamily: gui.fontFamily
    // },
    addViewBottom: {
        height:30,
        width:width,
        backgroundColor:'#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewTitleHeader:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    searchDiaChinhView: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    diaChinhSubView: {
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'column'
    },
    diaChinhTouchable: {
        padding: 4,
        paddingLeft: 10,
        height: 38,
        marginLeft: 0,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    diaChinhText: {
        fontSize: 15,
        color: '#9fa0a4',
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    locationIcon: {
        backgroundColor:'white',
        height:25,
        width:25,
        marginRight:4,
        justifyContent:'center',
        alignItems:'center'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width-30,
        height: 60
    },
    textInputView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    textInputView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/3-5,
        marginTop: 10,
        marginBottom: 10
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width/3-5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    loadingContent: {
        position: 'absolute',
        top: -23,
        left: width / 2 - 19,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: height / 2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NeedToBuyFilter);
