'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as searchActions from '../../reducers/search/searchActions';

import {Map} from 'immutable';

import gui from '../../lib/gui';

import React, {Component} from 'react';

import { Text, View, Navigator, TouchableOpacity, InteractionManager, TouchableHighlight, Alert, ImageBackground
    , SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS, TextInput, Image, ListView } from 'react-native'

import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon'
import RelandIcon from '../RelandIcon';

import RangeUtils from "../../lib/RangeUtils"

import DanhMuc from "../../assets/DanhMuc"

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import placeUtil from '../../lib/PlaceUtil';

import log from '../../lib/logUtil';

import findApi from '../../lib/FindApi';

import CommonUtils from '../../lib/CommonUtils';

import LinearGradient from 'react-native-linear-gradient';

import MHeartIcon from '../MHeartIcon';

import GiftedSpinner from 'react-native-gifted-spinner';

import MapView from 'react-native-maps';

import LocationMarker from '../marker/LocationMarker';

import apiUtils from '../../lib/ApiUtils';

import utils from '../../lib/utils';

const {width, height} = utils.getDimensions();
const mapWidth = width-30;
const mapHeight = (width-width%2)/2+3;
const ASPECT_RATIO = mapWidth / mapHeight;

const LATITUDE = 20.95389909999999;
const LONGITUDE = 105.75490945;

var Analytics = require('react-native-firebase-analytics');

import moment from 'moment';

const actions = [
    globalActions,
    needToBuyActions,
    adsMgmtActions,
    searchActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class NeedToBuyDetail extends Component {
    constructor(props) {
        super(props);

        let ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});
        this.state = {
            loading: true,
            ds: ds,
            nhaCanBanGap: []
        };
    }

    componentWillMount() {
        setTimeout(() => this._fetchData(), 300);
    }

    _fetchData() {
        let wtoID = this.props.wtoID;
        this.props.actions.getWToDetail(wtoID)
            .then(
                (res) => {
                    if (res.status == 0 && res.wto) {
                        this._fillWToDetail(res.wto);
                        this._loadNhaCanBanGap(wtoID);
                    } else {
                        Alert.alert('Thông báo', 'Lỗi không tải được tin đã đăng.');
                    }
                }
            );
    }

    _loadNhaCanBanGap(wtoID) {
        let token = this.props.global.currentUser.token;
        findApi.getWToNhaCanBanGapData({wtoID: wtoID}, token)
            .then((res) => {
                if (res.status == 0 && res.data) {
                    let nhaCanBanGap = res.data.wtsList;
                    // let hashNhaCanBanGap = {};
                    // let nhaCanBanGap = res.data.wtsList.filter(function (item) {
                    //     let existed = hashNhaCanBanGap[item.adsID];
                    //     if (!existed) {
                    //         hashNhaCanBanGap[item.adsID] = true;
                    //     }
                    //     return !existed;
                    // });
                    this.setState({
                        nhaCanBanGap: nhaCanBanGap
                    });
                }
            });
    }

    _fillWToDetail(wtoDto) {
        let content = wtoDto.content;
        let id = wtoDto.id;
        let mua = {loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE};
        let thue = {loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE};
        let loaiTin = wtoDto.loaiTin==0 ? 'mua' : 'thue';
        let loaiNhaDat = content.loaiNhaDat;
        let giaTu = content.giaTu;
        let giaDen = content.giaDen;
        let gia = giaTu && giaDen ? RangeUtils.sellPriceRange.rangeVal2Display([giaTu, giaDen]) : RangeUtils.BAT_KY_RANGE;
        if (loaiTin == 'mua') {
            mua = {loaiNhaDat: loaiNhaDat ? loaiNhaDat : '', gia: gia};
        } else {
            thue = {loaiNhaDat: loaiNhaDat ? loaiNhaDat : '', gia: gia};
        }

        let initGia = gia;
        let giaVal = [giaTu, giaDen];
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }

        let dienTichTu = content.dienTichTu;
        let dienTichDen = content.dienTichDen;
        let dienTich = dienTichTu && dienTichDen ? RangeUtils.dienTichRange.rangeVal2Display([dienTichTu, dienTichDen]) :
            RangeUtils.BAT_KY_RANGE;

        let initDienTich = dienTich;
        let dienTichVal = [dienTichTu, dienTichDen];
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }

        let timeModified = wtoDto.timeModified;
        let title = DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, loaiNhaDat);

        this.setState({
            id: id,
            userID: wtoDto.userID,
            fullName: wtoDto.fullName || 'Ẩn Danh',
            avatar: wtoDto.avatar,
            title: title,
            initGia: initGia,
            initDienTich: initDienTich,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            loaiTin: loaiTin,
            loaiNhaDat: loaiNhaDat,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            soTang: content.soTang,
            soPhongNgu: content.soPhongNgu,
            soPhongTam: content.soPhongTam,
            huongNha: content.huongNha,
            place: content.place,
            ghiChu: content.ghiChu,
            timeModified: timeModified,
            loading: false
        });
    }

    _getDiaChiFullname() {
        let {place} = this.state;
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    renderLoadingView() {
        if (this.state.loading || this.isUploading()) {
            return (
                <View style={myStyles.styleLoadingDetail}>
                    <View style={myStyles.viewLoadingAvatar}>
                        <View style={myStyles.avatarView}>
                            <View style={[myStyles.avatarImage, {backgroundColor: 'rgba(234, 234, 234, 0.5)'}]}
                            />
                        </View>
                        <View style={myStyles.userInfoView}>
                            <View style={[myStyles.viewLineLoaderRow, {width: 38, height: 15 }]} />
                            <View style={[myStyles.viewLineLoaderRow, {width: 120, height: 15 }]} />
                        </View>
                    </View>
                    <View style={myStyles.separatedViewLoading} />
                    {this._renderChiTietLoading()}
                    <View style={myStyles.separatedViewLoading} />
                    {this._renderViTriWToLoading()}
                    <View style={myStyles.separatedViewLoading} />
                    {this._renderShareLoading()}
                </View>
            )
        }
    }

    _renderChiTietLoading () {
        return (
            <View style={myStyles.viewTextDetailLoading}>
                <View style={[myStyles.viewLineLoaderRow, {width: 65, height: 18 , marginTop: 20, marginBottom: 20}]} />
                <View style={[myStyles.viewLineLoaderRow, {width: 140, height: 15 }]} />
                <View style={[myStyles.viewLineLoaderRow, {width: width/2 + 30, height: 15, marginTop: 3}]} />
            </View>
        );
    }

    _renderViTriWToLoading() {
        return (
            <View style={myStyles.viewViTriLoading}>
                <View style={[myStyles.viewLineLoaderRow, {width: 40, height: 18 }]} />
                <View style={[myStyles.viewLineLoaderRow, {width: width*3/4, height: 15, marginTop: 3}]} />
                <View style={[myStyles.viewLineLoaderRow, {width: mapWidth, height: mapHeight, marginTop: 1}]} />
            </View>
        )
    }

    _renderShareLoading() {
        return (
            <View style={myStyles.viewViTriLoading}>
                <View style={[myStyles.viewLineLoaderRow, {width: 55, height: 18 }]} />
                <View style={[myStyles.viewLineLoaderRow, {width: width*3/4 - 30, height: 15, marginTop: 3}]} />
                <View style={{flexDirection: 'row'}}>
                    <View style={[myStyles.styleCircleColor, {marginTop: 3}]}></View>
                    <View style={[myStyles.styleCircleColor, {marginLeft: 8, marginTop: 3}]}></View>
                    <View style={[myStyles.styleCircleColor, {marginLeft: 8, marginTop: 3}]}></View>
                </View>
            </View>
        );
    }

    renderWToBody(showPostWToButton) {
        let scrollHeight = showPostWToButton ? height-208 : height-164;
        return (
            <View style={[myStyles.searchFilter, {top: 64}]}>
                {this._renderDangBoi()}
                <View style={myStyles.separatedView} />
                <ScrollView style={[myStyles.searchFilter, {top: 100, height: scrollHeight}]}
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="on-drag"
                    ref='scroll'>
                    {this._renderChiTietWTo()}
                    {this._renderViTriWTo()}
                    {/*showPostWToButton ? this._renderSharedButtons() : this._renderNhaCanBanGap()*/}
                    {showPostWToButton ? null : this._renderNhaCanBanGap()}
                </ScrollView>
            </View>
        );
    }

    _renderNhaCanBanGap() {
        if (!this.state.nhaCanBanGap || this.state.nhaCanBanGap.length == 0){
            return null;
        }
        let nhaCanBanGapTitle = this.state.loaiTin == 'mua' ? 'Nhà cần bán gấp nhận được' :
            'Nhà cho thuê nhận được';
        let nhaCanBanGapSubTitle = this.state.loaiTin == 'mua' ? 'Tin bán của những người cần bán gấp gửi đến bạn' :
            'Tin thuê của những người cần cho thuê gửi đến bạn';
        return (
            <View style={{flex: 1, marginBottom: 30}}>
                <View style={myStyles.separatedView} />
                <View style={myStyles.nhaCanBanGapView}>
                    <View style={[myStyles.searchSectionTitle, {backgroundColor: '#fff', paddingTop: 10}]}>
                        <ScalableText style={[myStyles.cacDieuKienText, {fontSize: 15, fontWeight: '500'}]}>
                            {nhaCanBanGapTitle}
                        </ScalableText>
                        <ScalableText style={myStyles.nhaCanBanGapSubTitleText}>{nhaCanBanGapSubTitle}</ScalableText>
                    </View>
                    {this._renderAdsListView()}
                </View>
            </View>
        )
    }

    _renderAdsListView() {
        return (
            <View style={myStyles.adsListView}>
                <ListView style={myStyles.adsListSubView}
                          horizontal={true}
                          enableEmptySections={true}
                          showsHorizontalScrollIndicator={false}
                          showsVerticalScrollIndicator={false}
                          dataSource={this.state.ds.cloneWithRows(this.state.nhaCanBanGap)}
                          renderRow={this._renderAdsRow.bind(this)} />
                {this.renderAdsLoadingView()}
            </View>
        );
    }

    renderAdsLoadingView() {
        if (this.props.needToBuy.deleteWTSLoading) {
            return (
                <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                alignItems: 'center', justifyContent: 'center'}}>
                    <GiftedSpinner size='large' color='gray' />
                </View>
            )
        }
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateMessageProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateMessageProcessing.bind(this));
            }
        }
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        this.msgTimer && clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }

    _renderAdsRow(wts) {
        let data = wts.ads;
        data.adsID = wts.adsID;
        let isLiked = this.isLiked(data.adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let diaChi = data.place.diaChi;
        let shortedAddress = diaChi && diaChi.length>50 ? diaChi.substring(0,50) + "..." : diaChi;

        let giaGiam = wts && wts.giaGiam;
        let gia = utils.getPriceDisplay(data.gia, data.loaiTin);
        let giaDaGiam = giaGiam ? utils.getPriceDisplay(data.gia-giaGiam, data.loaiTin) : '';
        let giaText = 'Giá: ';
        let dienTichText = '';
        let dienTichFmt = utils.getDienTichDisplay(data.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNgu) {
            soPhongNgu = "   " + data.soPhongNgu + "pn";
        }

        let soTang = '';
        if (data.soTang) {
            soTang = "   " + data.soTang + "t";
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTichText, soPhongNgu, soTang);
        detail = detail.trim();
        return(
            <TouchableOpacity onPress={this._onChiTietNhaCanBanGapPress.bind(this, wts)} >
                <View style={{flex: 1}}>
                    <View style={[myStyles.eachViewKetQua, {width: width/2-15}]}>
                        <ImageBackground style={{width: width/2-15, height: 142, marginRight: 9}}
                               source={{uri: data.image.cover}}
                               resizeMode={'cover'}
                               defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                            style={myStyles.linearGradient2}>
                            </LinearGradient>
                            <View style={myStyles.deleteAdsContent}>
                                <RelandIcon name="close" color={'black'}
                                            mainProps={myStyles.captureIcon}
                                            size={10} textProps={{ paddingLeft: 0 }}
                                            onPress={this._onDeleteWTS.bind(this, wts.id)}
                                />
                            </View>
                            <View style={myStyles.heartContent}>
                                {this.props.search.uploadingLikedAds.uploading && this.props.search.uploadingLikedAds.adsID == data.adsID ?
                                    (<View style={myStyles.heartButton2}>
                                        <GiftedSpinner size="small" color="white"/>
                                    </View>)
                                    :
                                    (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                                 color={color} bgColor={bgColor}
                                                 bgStyle={bgStyle}
                                                 mainProps={myStyles.heartButton}/>)
                                }
                            </View>
                        </ImageBackground>
                    </View>
                    <View style={myStyles.viewTextContent}>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={myStyles.priceText} numberOfLines={1}>{giaText}</Text>
                            {giaGiam ?
                                <View style={{flexDirection: 'row'}}>
                                    <Text style={[myStyles.priceText, {marginLeft: 5}]} numberOfLines={1}>{giaDaGiam}</Text>
                                    <Text style={[myStyles.priceText, {marginLeft: 10, textDecorationLine: 'line-through',
                                        color: '#C7C8CA'}]} numberOfLines={1}>{gia}</Text>
                                </View> :
                                <Text style={[myStyles.priceText, {marginLeft: 5}]} numberOfLines={1}>{gia}</Text>
                            }
                        </View>
                        <Text style={myStyles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                        <Text style={myStyles.infoText}>{detail}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _onDeleteWTS(wtsID) {
        Alert.alert(
            'Thông báo',
            'Có phải bạn không muốn xem tin này?',
            [
                {text: 'Hủy', onPress: () => {}, style: 'cancel'},
                {text: 'Đồng ý', onPress: () =>  {this._doDeleteWTS(wtsID)}},
            ],
        );
    }

    _doDeleteWTS(wtsID) {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.deleteWTS({userID: userID, wtsID: wtsID}, token).then(
            (res) => {
                if (res.status == 0) {
                    let wtoID = this.props.wtoID;
                    this._loadNhaCanBanGap(wtoID);
                } else {
                    Alert.alert('Thông báo', res.msg);
                }
            });
    }

    _onChiTietNhaCanBanGapPress(wts) {
        if (this.props.global.loggedIn) {
            this._showCanBanGapDetail(wts);
        } else {
            Actions.NewLogin({doFinalAction: () => this._showCanBanGapDetail(wts)});
        }
    }

    _showCanBanGapDetail(wts) {
        Actions.WToDetailFromHome({wts: wts});
        let wtsID = wts.wtsID || wts.id;
        Analytics.logEvent('ADSMGMT_WTS_DETAIL', {wtsID: wtsID});
    }

    render() {
        let showPostWToButton = (this.state.userID && this.state.userID != this.props.global.currentUser.userID);
        return (
            <View style={myStyles.fullWidthContainer}>
                {this.state.loading ? null : this.renderWToBody(showPostWToButton)}

                {showPostWToButton ? this._renderPostWToButton() : null}

                {this._renderHeaderAds()}
                {this.renderLoadingView()}
            </View>
        );
    }

    _renderDangBoi() {
        let {fullName, avatar} = this.state;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = avatar ? {uri: avatar} : defaultAvatar;
        let fullNameText = fullName || '';

        let {timeModified} = this.state;
        let ngayDang = moment(timeModified).format("HH:mm | DD/MM/YYYY");
        ngayDang = 'Tin đăng: ' + ngayDang;

        return (
            <View style={myStyles.dangBoiView}>
                <View style={myStyles.avatarView}>
                    <Image style={myStyles.avatarImage}
                           resizeMode={Image.resizeMode.cover}
                           source={avatarUri}
                           defaultSource={defaultAvatar}
                    />
                </View>
                <View style={myStyles.userInfoView}>
                    <ScalableText style={myStyles.fullNameText}>{fullNameText}</ScalableText>
                    <ScalableText style={myStyles.ngayDangText}>{ngayDang}</ScalableText>
                </View>
            </View>
        );
    }

    _getGiaText() {
        let {initGia, fromGia, toGia} = this.state;
        if (!fromGia && !toGia) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        if (!fromGia) {
            return 'Giá: <= ' + initGia[1];
        }
        if (!toGia) {
            return 'Giá: >= ' + initGia[0];
        }
        return 'Giá: ' + initGia[0] + ' - ' + initGia[1];
    }

    _getDienTichText() {
        let {initDienTich, fromDienTich, toDienTich} = this.state;
        if (!fromDienTich && !toDienTich) {
            return '';
        }
        if (!fromDienTich) {
            return '<= ' + initDienTich[1];
        }
        if (!toDienTich) {
            return '>= ' + initDienTich[0];
        }
        return initDienTich[0] + ' - ' + initDienTich[1];
    }
    
    _renderChiTietWTo() {
        let {soTang, soPhongNgu, soPhongTam, huongNha, ghiChu} = this.state;
        let giaText = this._getGiaText();
        let diaChi = this._getDiaChiFullname();

        let dacDiemValues = [];
        let dienTichText = this._getDienTichText();
        if (dienTichText) {
            dacDiemValues.push(dienTichText);
        }

        let soTangText = '';
        if (soTang) {
            soTangText = soTang + ' tầng';
            dacDiemValues.push(soTangText);
        }
        let soPhongTamText = '';
        if (soPhongTam) {
            soPhongTamText = soPhongTam + ' phòng tắm';
            dacDiemValues.push(soPhongTamText);
        }

        if (soPhongNgu) {
            dacDiemValues.push(soPhongNgu + ' phòng ngủ');
        }

        if (huongNha && huongNha != '-1') {
            dacDiemValues.push("Hướng " + DanhMuc.HuongNha[huongNha]);
        }

        let dacDiemItems = [];
        for (let i = 0; i<dacDiemValues.length; i = i+2) {
            let one = dacDiemValues[i];
            let other = '';
            if (i < dacDiemValues.length-1) {
                other = dacDiemValues[i+1];
            }
            let item = this.renderTwoNormalProps(one, other, {marginTop: 11}, {marginTop: 4, marginBottom: 4}, 'prop_' + i);
            dacDiemItems.push(item);
        }

        return (
            <View style={myStyles.chiTietView}>
                <View style={myStyles.chiTietSubView1}>
                    <Text style={myStyles.chiTietTitleItem}>{this.state.title}</Text>
                    <Text style={myStyles.priceItem}>{giaText}</Text>
                    <ScalableText style={[myStyles.diaChiItem, {marginTop: 5, marginBottom: 10}]}>{diaChi}</ScalableText>
                    {dacDiemItems.length > 0 ? <FullLine style={{marginBottom: 4}} /> : null}
                    {dacDiemItems}
                </View>
                {ghiChu ?
                <View style={myStyles.chiTietSubView2}>
                    <FullLine style={{marginTop: 4, marginBottom: 8}} />
                    <ScalableText style={myStyles.ghiChuItem}>{ghiChu}</ScalableText>
                </View> : <View style={{marginBottom: 8}} /> }
            </View>
        );
    }

    renderTwoNormalProps(prop1, prop2, dotStyle, textStyle, key) {
        if (prop1 || prop2) {
            let dotIcon1Style = prop1 ? {} : {backgroundColor: 'transparent'};
            let dotIcon2Style = prop2 ? {} : {backgroundColor: 'transparent'};
            return (
                <View key={key} style={[myStyles.searchDetailRowAlign]}>
                    <View style={{flexDirection: 'row'}}>
                        <View style={[myStyles.dot2, dotIcon1Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop1}
                        </Text>
                    </View>
                    <View style={{flexDirection: 'row', marginLeft: 10}}>
                        <View style={[myStyles.dot2, dotIcon2Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop2}
                        </Text>
                    </View>
                </View>
            )
        }
    }

    _renderViTriWTo() {
        let hintViTri = 'Vị trí của bất động sản cần mua trên bản đồ';
        let {place} = this.state;
        let circle = place && place.circle;
        let hasCirle = circle && circle.radius > 0;
        let polygon = place && place.polygon;
        let hasPolygon = polygon && polygon.length > 0;
        let viewport = place && place.viewport;
        let location = place && place.location;
        let region = undefined;
        if (viewport) {
            region = apiUtils.getRegionByViewport(viewport);
        }
        else if (location) {
            region = {latitude: location.lat, longitude: location.lon, latitudeDelta: 0.021, longitudeDelta: 0.0144};
        }

        if (hasCirle) {
            if (!region) {
                let radius = circle.radius;
                let delta = apiUtils.convertRadius2Delta(radius);
                region = {latitude: circle.center.lat, longitude: circle.center.lon,
                    latitudeDelta: delta, longitudeDelta: delta*ASPECT_RATIO};
            }
            region.latitudeDelta = region.latitudeDelta*1.2;
            region.longitudeDelta = region.longitudeDelta*1.2;
        }
        else if (hasPolygon) {
            if (!region) {
                let geoBox = apiUtils.getWToPolygonBox(polygon);
                region = apiUtils.getRegion(geoBox);
            }
            region.latitudeDelta = region.latitudeDelta*1.2;
            region.longitudeDelta = region.longitudeDelta*1.2;
        }
        else if (!region) {
            region = {latitude: LATITUDE, longitude: LONGITUDE, latitudeDelta: 0.021, longitudeDelta: 0.0144};
        }
        let showMarker = !polygon || polygon.length <= 0;
        return (
            <View>
                <View style={myStyles.separatedView} />
                <View style={myStyles.viTriView}>
                    <ScalableText style={myStyles.titleViTriItem}>Vị trí</ScalableText>
                    <ScalableText style={myStyles.hintViTriItem}>{hintViTri}</ScalableText>
                    <MapView
                        style={myStyles.miniMapItem}
                        scrollEnabled={false}
                        zoomEnabled={false}
                        pitchEnabled={false}
                        rotateEnabled={false}
                        initialRegion={region}
                        onPress={() => this._onMapPressed()}>
                        {showMarker ? <MapView.Marker coordinate={region} pointerEvents="none">
                                <LocationMarker/>
                            </MapView.Marker> : null
                        }
                        {this._renderMapCircle(circle)}
                        {this._renderMapPolygon(polygon)}
                    </MapView>
                </View>
            </View>
        )
    }

    _renderMapPolygon(polygon) {
        if (!polygon || polygon.length <= 0) {
            return null;
        }
        let polygonGUI = apiUtils.convertPolygonForGUI(polygon);
        return (
            <MapView.Polygon
                coordinates={polygonGUI}
                strokeColor={gui.mainColor}
                fillColor="rgba(0,168,230,0.3)"
                strokeWidth={2}
            />
        );
    }

    _renderMapCircle(circle) {
        if (!circle || !circle.radius){
            return null;
        }
        let center = {latitude: circle.center.lat, longitude: circle.center.lon};
        let radius = circle.radius*1000;
        return (
            <MapView.Circle
                key={center.latitude + center.longitude + radius}
                center={center}
                radius={radius}
                fillColor="rgba(165,207,255,0.5)"
                strokeColor={gui.mainColor}
                position="absolute"
                zIndex={1}
                strokeWidth={1}
            />
        );
    }

    _renderSharedButtons() {
        let hintShare = 'Chia sẻ tin cần mua này với người thân';
        return (
            <View>
                <View style={myStyles.separatedView} />
                <View style={myStyles.shareView}>
                    <ScalableText style={myStyles.titleShareItem}>Chia sẻ</ScalableText>
                    <ScalableText style={myStyles.hintShareItem}>{hintShare}</ScalableText>
                    <View style={myStyles.sharedButtonsView}>
                        <View style={[myStyles.circleContainer2, {backgroundColor: '#fff'}]} >
                            <RelandIcon onPress={() => this._onSmsFriend()}
                                        name="share-sms" color={'#ffcf00'}
                                        size={40} iconProps={{style: myStyles.shareIcon}}>
                            </RelandIcon>
                        </View>
                        <View style={[myStyles.circleContainer2, {backgroundColor: '#fff'}]} >
                            <RelandIcon onPress={() => this._onEmailFriend()}
                                        name="share-mail" color={'#dd5044'}
                                        size={40} iconProps={{style: myStyles.shareIcon}}>
                            </RelandIcon>
                        </View>
                        <View style={[myStyles.circleContainer, {backgroundColor: '#A6A6A6'}]} >
                            <RelandIcon onPress={this._onCopy.bind(this)}
                                        name="copy-link" color={'white'}
                                        size={26} iconProps={{style: myStyles.shareIcon}}>
                            </RelandIcon>
                        </View>
                    </View>
                </View>
            </View>
        );
    }

    _renderPostWToButton() {
        if (this.isUploading()) {
            return (
                <View style={myStyles.searchButton}>
                    <GiftedSpinner color="white" />
                </View>
            )
        } else {
            return (
                <TouchableHighlight onPress={this.onApply.bind(this)} underlayColor="transparent">
                    <View style={myStyles.searchButton}>
                        <ScalableText
                            style={[myStyles.searchButtonText, {fontWeight: 'bold'}]}>Gửi thông tin cho người mua</ScalableText>
                    </View>
                </TouchableHighlight>
            )
        }
    }

    _renderHeaderAds() {
        return (
            <View style={myStyles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this.onCancel()}
                    style={myStyles.backButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={myStyles.viewTitleHeader}>
                    <ScalableText style={[myStyles.textHeader, {fontWeight: '500', fontSize: 17}]}>
                        Chi tiết
                    </ScalableText>
                </View>
                <View
                    style={myStyles.viewRightHeader}>
                </View>
            </View>
        );
    }

    isUploading() {
        return this.props.needToBuy.needToBuyLoading;
    }

    _onMapPressed() {
        let {initDienTich, initGia, place} = this.state;
        let giaText = initGia ? 'Giá: ' + initGia[0] + ' - ' + initGia[1] : '';
        let dienTichText = initDienTich ? initDienTich[0] + ' - ' + initDienTich[1] : '';
        let diaChi = this._getDiaChiFullname();
        let viewport = place && place.viewport;
        let circle = place && place.circle;
        let polygon = place && place.polygon;
        let location = place && place.location;
        let lat = '';
        let lon = '';
        let region = {};
        if (viewport) {
            region = apiUtils.getRegionByViewport(viewport);
            lat = region.latitude;
            lon = region.longitude;
        }
        else if (location) {
            lat = location.lat;
            lon = location.lon;
            region = {
                latitude: lat,
                longitude: lon,
                latitudeDelta: 0.021,
                longitudeDelta: 0.0144
            };
        }
        let ads = {
            place: {
                geo: {
                    lat: lat,
                    lon: lon
                },
                diaChi: diaChi
            },
            giaFmt: giaText,
            dienTich: dienTichText,
            image: {
                cover: ''
            }
        };
        Actions.SearchMapDetail({region: region, ads: ads, circle: circle, polygon: polygon});
    }

    _onSmsFriend() {
        this._renderComing();
    }

    _onEmailFriend() {
        this._renderComing();
    }

    _onCopy() {
        this._renderComing();
    }

    _renderComing() {
        Alert.alert('Thông báo', 'Tính năng đang phát triển!');
    }

    onCancel() {
        Actions.pop();
    }

    onApply() {
        if (this.state.userID == this.props.global.currentUser.userID) {
            Alert.alert('Thông báo', gui.ERR_NotAllowChatYourSelf);
        } else {
            let wto = {
                ...this.state
            };
            Actions.WToSelectAdsToSend({wto: wto});
        }
    }
}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        width: width,
        height: 64
    },

    searchButton: {
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        top: height -44 ,
        height: 44,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: '#E83522',
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 11,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchMoreFilterButton: {
        flexGrow: 0.5,
        alignItems: 'stretch',
        justifyContent: 'center'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchResetText: {
        color: 'red',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    searchAttributeLabel : {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: 'black'
    },
    searchAttributeValue : {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.arrowColor,
        marginRight: 3
    },
    searchFilterButton: {
        flexDirection: 'column'
    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchSectionTitle: {
        flexDirection : "column",
        paddingRight: 8,
        paddingLeft: 17,
        paddingTop: 28,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8'
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection:"column"
        //borderWidth:1,
        //borderColor: "green"
    },
    scrollView: {
        flex: 1,
        height: height-123
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent :'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute3: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 17,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 0,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt3: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 17,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    addViewBottom: {
        height:30,
        width:width,
        backgroundColor:'#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewTitleHeader:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    searchDiaChinhView: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    diaChinhSubView: {
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'column'
    },
    diaChinhTouchable: {
        padding: 4,
        paddingLeft: 10,
        height: 38,
        marginLeft: 0,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    diaChinhText: {
        fontSize: 15,
        color: '#9fa0a4',
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    locationIcon: {
        backgroundColor:'white',
        height:25,
        width:25,
        marginRight:4,
        justifyContent:'center',
        alignItems:'center'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width-30,
        height: 60
    },
    textInputView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    textInputView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/3-5,
        marginTop: 10,
        marginBottom: 10
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width/3-5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    dangBoiView: {
        flex: 1,
        flexDirection: 'row'
    },
    viewLoadingAvatar: {
        flexDirection: 'row',
        height: 90,
        width: width
    },
    avatarView: {
        height: 90,
        width: 90,
        padding: 15
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    userInfoView: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 15
    },
    fullNameText: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    ngayDangText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    separatedViewLoading: {
        height: 10,
        width: width,
        backgroundColor:'rgba(234, 235, 237, 0.75)',
    },
    chiTietView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15
    },
    chiTietSubView1: {
        flex: 1
    },
    chiTietSubView2: {
        flex: 1,
        paddingBottom: 15
    },
    chiTietTitleItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 5
    },
    ghiChuItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    priceItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#1E94D6',
        fontFamily: gui.fontFamily,
        paddingTop: 5
    },
    attributeView: {
        flex: 1,
        flexDirection: 'row',
        paddingTop: 5,
        alignItems: 'center'
    },
    diaChiItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    viTriView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15,
        paddingBottom: 15
    },
    titleViTriItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    hintViTriItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 15
    },
    miniMapItem: {
        width: mapWidth,
        height: mapHeight
    },
    shareView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15
    },
    titleShareItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    hintShareItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 15
    },
    sharedButtonsView: {
        flex: 1,
        flexDirection: 'row',
        paddingBottom: 15
    },
    circleContainer: {
        marginTop: 0,
        marginBottom: 0,
        marginRight: 10,
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: '#A8A8A8'
    },
    circleContainer2: {
        marginTop: -7,
        marginBottom: 0,
        marginRight: 10,
        backgroundColor: '#A8A8A8'
    },
    shareIcon: {
        marginTop: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    searchDetailRowAlign: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-around',
    },
    dot2 : {
        width: 5,
        height: 5,
        borderRadius: 2.5,
        marginTop: 11,
        marginLeft: 20,
        marginRight: 0,
        backgroundColor: '#C1C1C1'
    },
    textHalfWidth: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: 'black',
        marginTop: 3,
        marginBottom: 4,
        marginLeft: 5,
        marginRight: 10,
        width: width/2-20
    },
    nhaCanBanGapView: {
        flexGrow: 0,
        flexDirection:"column"
    },
    adsListView: {
        flex: 1,
        marginTop:6,
        width: width-30,
        marginLeft: 17
    },
    adsListSubView: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        // marginTop: 10,
        // marginBottom: 10
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: 142,
        height: 142,
        marginRight: 9
    },
    heartContent: {
        backgroundColor: 'transparent',
        position: "absolute",
        top: 0,
        right: 8,
        width: 38,
        height: 38,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 10
    },
    viewTextContent: {
        flex: 1,
        paddingTop: 8
    },
    priceContent: {
        backgroundColor: '#EB4222',
        position: "absolute",
        bottom: 10,
        left: 10,
        padding: 2,
        borderRadius: 2
    },
    priceText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#EB4222'
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#5C5D5F',
        width: 142
    },
    nhaCanBanGapSubTitleText: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#464648'
    },
    deleteAdsContent: {
        backgroundColor: 'white',
        position: "absolute",
        top: 10,
        left: 10,
        paddingLeft: 2,
        paddingRight: 2,
        borderRadius: 2
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    styleLoadingDetail: {
        top: 64,
        height: height-64,
        width: width,
        alignItems: 'flex-start',
        justifyContent: 'flex-start'
    },
    viewLineLoaderRow: {
        height: 14,
        width: width*3/4,
        backgroundColor:'rgba(234, 235, 237, 0.8)',
        marginBottom: 8
    },
    viewTextDetailLoading: {
        width: width,
        height: 120,
        backgroundColor: '#fff',
        marginLeft: 15,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewViTriLoading: {
        padding: 15
    },
    styleCircleColor: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor:'rgba(234, 235, 237, 0.8)'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NeedToBuyDetail);
