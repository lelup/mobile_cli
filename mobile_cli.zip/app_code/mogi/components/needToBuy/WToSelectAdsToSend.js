'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as chatActions from '../../reducers/chat/chatActions';

import {Map} from 'immutable';

import gui from '../../lib/gui';

import React, {Component} from 'react';

import { Text, View, Navigator, TouchableOpacity, InteractionManager, TouchableHighlight, Alert, Image
    , SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS, TextInput, ListView, Switch, ImageBackground } from 'react-native'

import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';

import MHeartIcon from '../MHeartIcon';

import DanhMuc from "../../assets/DanhMuc"

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import Toast, {DURATION} from '../toast/Toast';

import GiftedSpinner from 'react-native-gifted-spinner';

import utils from '../../lib/utils';

import findApi from '../../lib/FindApi';

import userApi from '../../lib/userApi';

import log from '../../lib/logUtil';

import CommonUtils from '../../lib/CommonUtils';

import LinearGradient from 'react-native-linear-gradient';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import Button from 'react-native-button';

import MMessage from '../message/MMessage';

var {width, height} = utils.getDimensions();

var Analytics = require('react-native-firebase-analytics');

const actions = [
    globalActions,
    needToBuyActions,
    adsMgmtActions,
    searchActions,
    chatActions
];

const ONE_MILLION = 1000000.0;

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class WToSelectAdsToSend extends Component {
    constructor(props) {
        super(props);

        let {id, userID, loaiTin, mua, thue, place, fromDienTich, toDienTich, fromGia, toGia} = props.wto;
        let ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});
        this.state = {
            wtoID: id,
            toUserID: userID,
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            place: place,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            soTienGiamGia: null,
            thuTucMienPhi: false,
            deLaiDoTrongNha: false,
            toggleState: false,
            onCancelling: false,
            ds: ds,
            adsList: [],
            selectedAds: null,
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null
        };
    }

    componentWillMount() {
        setTimeout(() => this._fetchData(), 300);
    }

    _fetchData() {
        this.setState({adsList: []});

        let {wtoID} = this.state;

        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;

        findApi.getMatchingAdsOfWTo({userID: userID, wtoID: wtoID}, token).then(
            (res) => {
                if (res.status == 0 && res.data) {
                    let adsList = res.data;
                    adsList.sort((a, b) => b.timeModified - a.timeModified);

                    this.setState({
                        adsList: adsList
                    });
                }
            });

    }

    _onGhiChuFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + 350;
            this._scrollView.scrollTo({y: scrollTo});
        }
    }

    render() {
        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={[myStyles.searchFilter, {top: 64}]}>

                    <View style={myStyles.scrollView}>
                        <ScrollView
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode={this.state.keyboardDismissMode}
                            ref={(scrollView) => { this._scrollView = scrollView; }}
                            onLayout={event => {
                                this._scrollViewHeight = event.nativeEvent.layout.y
                            }}
                            automaticallyAdjustContentInsets={false}
                            vertical={true}
                            style={myStyles.scrollView2}>

                            <View style={myStyles.searchFilterDetail}>
                                <View style={[myStyles.searchSectionTitle, {backgroundColor: '#fff', paddingTop: 10}]}>
                                    <Text style={[myStyles.cacDieuKienText, {fontSize: gui.normalFontSize, fontWeight: '500'}]}>
                                        Chọn tin gửi
                                    </Text>
                                </View>
                                {this._renderAdsListView()}
                                <View style={myStyles.searchSectionTitle}>
                                    <Text style={myStyles.cacDieuKienText}>
                                        Chọn ưu đãi
                                    </Text>
                                </View>
                                <FullLine />
                                {this._renderPreferenceView()}
                                <FullLine />
                                <View style={myStyles.searchSectionTitle}>
                                    <Text style={myStyles.cacDieuKienText}>
                                        Ghi chú
                                    </Text>
                                </View>
                                {this._renderGhiChu()}
                            </View>
                        </ScrollView>

                        {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                          style={[myStyles.searchButtonText2, {textAlign: 'right', color: gui.mainColor,
                                                              backgroundColor: gui.doneKeyButton}]}>Xong</Button> : null}
                        <KeyboardSpacer topSpacing={-46} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

                    </View>
                </View>
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.8}
                    textStyle={{color:'#fff'}}
                />
                {this._renderPostWToButton()}
                {this._renderLoadingView()}
                {this._renderMessageItem()}
                {this._renderHeaderAds()}
            </View>
        );
    }

    _renderPreferenceView() {
        return (
            <View style={myStyles.preferenceView}>
                {this._renderGiamGia()}
                {this._renderThuTucMienPhi()}
                {this._renderDeLaiDoTrongNha()}
            </View>
        );
    }

    _renderGiamGia() {
        let placeholder = 'Nhập số tiền giảm';
        let soTienGiamGia = this.state.soTienGiamGia;
        let onGiamGiaTextChange = this._onGiamGiaTextChange.bind(this);
        let onGiamGiaTextFocus = this._onGiamGiaTextFocus.bind(this);
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={myStyles.preferenceSubView1}>
                    <Text style={myStyles.label}>Giảm giá</Text>
                </View>
                <View style={myStyles.preferenceSubView2}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={[myStyles.input, {width: width/2+15, textAlign: 'left'}]}
                        placeholder={placeholder}
                        value={soTienGiamGia}
                        onChangeText={(text) => onGiamGiaTextChange(text)}
                        onFocus={() => onGiamGiaTextFocus()}
                        disabled = {this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
                <View style={myStyles.priceUnitView}>
                    <Text style={myStyles.label}>{DanhMuc.VND}</Text>
                </View>
            </View>
        );
    }

    _onValueChange(key, value) {
        let newState = {};
        newState[key] = value;
        this.setState(newState);
    }

    _renderThuTucMienPhi() {
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={[myStyles.preferenceSubView1, {width: width/2}]}>
                    <Text style={myStyles.label}>
                        Bao sang tên
                    </Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {justifyContent: 'flex-end', width: width/2-10, paddingRight: 10}]}>
                    <Switch
                        onValueChange={(value) => this._onValueChange('thuTucMienPhi', value)}
                        value={this._getThuTucMienPhi()} />
                </View>
            </View>
        );
    }

    _getThuTucMienPhi() {
        return this.state.thuTucMienPhi;
    }

    _renderDeLaiDoTrongNha() {
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={[myStyles.preferenceSubView1, {width: width/2}]}>
                    <Text style={myStyles.label}>
                        Để lại đồ trong nhà
                    </Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {justifyContent: 'flex-end', width: width/2-10, paddingRight: 10}]}>
                    <Switch
                        onValueChange={(value) => this._onValueChange('deLaiDoTrongNha', value)}
                        value={this._getDeLaiDoTrongNha()} />
                </View>
            </View>
        );
    }

    _getDeLaiDoTrongNha() {
        return this.state.deLaiDoTrongNha;
    }

    _onGiamGiaTextChange(moneyValue) {
        let zeroNumber = '0' || '00';
        if (moneyValue === zeroNumber) {
            moneyValue = '';
        }
        let moneyValueNumber = moneyValue.replace(/[, -.]+/g,"");

        this.setState({
            soTienGiamGia: utils.addCommas(moneyValueNumber)
        });
    }

    _onGiamGiaTextFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + 130;
            this._scrollView.scrollTo({y: scrollTo});
        }
    }

    _renderAdsListView() {
        return (
            <View style={myStyles.adsListView}>
                <ListView style={myStyles.adsListSubView}
                          horizontal={true}
                          enableEmptySections={true}
                          showsHorizontalScrollIndicator={false}
                          showsVerticalScrollIndicator={false}
                          dataSource={this.state.ds.cloneWithRows(this.state.adsList)}
                          renderRow={this._renderAdsRow.bind(this)} />
            </View>
        );
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateMessageProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateMessageProcessing.bind(this));
            }
        }
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
    }

    _renderMessageItem() {
        let textValue = this.state.textMessage;
        if (textValue == '' || this.state.msgType == '') {
            return null;
        }
        return (
            <MMessage mainStyle={{top: 64}}
                      hideStatus={this.state.msgType == 'fadeInDown'}
                // barStyle="light-content"
                      animation={this.state.msgType}
                      duration={500}
                      onAnimationEnd={this._onAnimationEnd.bind(this)}
                      textValue={textValue}
                      bgColor={this.state.msgBgColor}
                      textColor={this.state.msgTextColor}/>
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({textMessage: '', msgType: ''})}, 2000);
        }
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }

    _isSelectedAds(adsID) {
        return this.state.selectedAds && this.state.selectedAds.adsID == adsID;
    }

    setSelectedAds(data) {
        this.setState({selectedAds: data});
    }

    _renderAdsRow(data) {
        let isLiked = this.isLiked(data.adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let diaChi = data.place.diaChi;
        let shortedAddress = diaChi && diaChi.length>50 ? diaChi.substring(0,50) + "..." : diaChi;
        let dienTichText = '';
        let dienTichFmt = utils.getDienTichDisplay(data.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNgu) {
            soPhongNgu = "   " + data.soPhongNgu + "pn";
        }

        let soTang = '';
        if (data.soTang) {
            soTang = "   " + data.soTang + "t";
        }

        let gia = data.giaFmt || utils.getPriceDisplay(data.gia, data.loaiTin);

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTichText, soPhongNgu, soTang);
        let isSelectedAds = this._isSelectedAds(data.adsID);
        return(
            <View style={{flex: 1}}>
                <TouchableHighlight onPress={() => this.setSelectedAds(data)}
                                    underlayColor="transparent" >
                    <View style={myStyles.eachViewKetQua}>
                        <ImageBackground style={{width: 142, height: 142, marginRight: 9}}
                                         source={{uri: data.image.cover}}
                                         resizeMode={'cover'}
                                         defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                            style={myStyles.linearGradient2}>
                            </LinearGradient>
                            <View style={myStyles.priceContent}>
                                <Text style={myStyles.priceText}>{gia}</Text>
                            </View>
                            {this.renderGoiViTri(data)}
                            <View style={myStyles.heartContent}>
                                {this.props.history.uploadingLikedAds.uploading && this.props.history.uploadingLikedAds.adsID == data.adsID ?
                                    (<View style={myStyles.heartButton2}>
                                        <GiftedSpinner size="small" color="white"/>
                                    </View>)
                                    :
                                    (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                                 color={color} bgColor={bgColor}
                                                 bgStyle={bgStyle}
                                                 mainProps={myStyles.heartButton}/>)
                                }
                            </View>
                            {isSelectedAds ? <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                                backgroundColor: 'black', opacity: 0.4}} /> : null}
                            {isSelectedAds ? <View style={myStyles.selectedAdsView}>
                                <TruliaIcon
                                    name="check" color={'white'} size={24}
                                    mainProps={{width: 24, height: 24, marginLeft: 5, marginBottom: 5}}
                                />
                            </View> : null}
                        </ImageBackground>
                    </View>
                </TouchableHighlight>
                <View style={myStyles.viewTextContent}>
                    <Text style={myStyles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                    <Text style={myStyles.infoText}>{detail}</Text>
                </View>
            </View>
        );
    }

    renderGoiViTri(ads) {
        if (ads.goiViTri) {
            let remainDays = utils.getRemainDay(ads.goiViTri);
            let goiViTriIcon = utils.getGoiViTriIcon(ads.goiViTri);
            if (remainDays > 0 && goiViTriIcon) {
                return (
                    <View style={myStyles.goiViTriView}>
                        <Image style={myStyles.goiViTriIcon} source={goiViTriIcon} resizeMode={Image.resizeMode.cover} />
                    </View>
                );
            }
        }
        return null;
    }

    _renderLoadingView() {
        if (this.state.onCancelling || this.isUploading()) {
            return (
                <View style={myStyles.loadingContent}>
                    <GiftedSpinner size="large" color='gray' />
                </View>
            )
        }
    }

    _renderPostWToButton() {
        if (this.isUploading()) {
            return (
                <View style={myStyles.searchButton}>
                    <GiftedSpinner color="white" />
                </View>
            )
        } else {
            return (
                <TouchableHighlight onPress={this.onApply.bind(this)} underlayColor="transparent">
                    <View style={myStyles.searchButton}>
                        <ScalableText
                            style={[myStyles.searchButtonText, {fontWeight: 'bold'}]}>Gửi bất động sản</ScalableText>
                    </View>
                </TouchableHighlight>
            )
        }
    }

    _renderGhiChu() {
        let placeholder = 'Nhập ghi chú...';
        return (
            <View style={myStyles.searchFilterAttribute}>
                <TextInput ref="textInput"
                           autoCorrect={false}
                           multiline={true}
                           onChangeText={this._onGhiChuChangeText.bind(this)}
                           style={myStyles.textInput}
                           value={this.state.ghiChu}
                           placeholder={placeholder}
                           placeholderTextColor={gui.arrowColor}
                           onFocus={() => this._onGhiChuFocus()}
                           clearButtonMode="never"
                           selectTextOnFocus={true}
                           allowFontScaling={false}
                           disabled = {this.isUploading()} />
            </View>
        )
    }

    _onGhiChuChangeText(text) {
        this.setState({ghiChu: text});
    }

    _renderHeaderAds() {
        return (
            <View style={myStyles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this.onCancel()}
                    style={myStyles.backButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={myStyles.viewTitleHeader}>
                    <ScalableText style={[myStyles.textHeader, {fontWeight: '500', fontSize: 17}]}>
                        Chọn tin để gửi
                    </ScalableText>
                </View>
                <View
                    style={myStyles.viewRightHeader}>
                </View>
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({toggleState: toggleState});
    }

    onCancel() {
        this.setState({onCancelling: true});
        Alert.alert('Thông báo', 'Bạn muốn ngừng gửi tin ?',
            [   { text: 'Hủy', onPress: () => {
                this.setState({onCancelling: false});
            }
            },
                {
                    text: 'Đồng ý', onPress: () => {
                    Actions.pop();
                }
                }
            ]);
    }

    isUploading() {
        return this.props.needToBuy.needToBuyLoading;
    }

    onApply() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            let msg = this._isValidInputData();
            if (msg) {
                this.refs.toastTop && this.refs.toastTop.show(msg, 3000);
                return;
            }
            let {fullName} = this.props.wto;
            let fullNameText = fullName || 'Ẩn danh';
            let msgLabel = 'Bạn chắc chắn muốn gửi bất động sản tới ' + fullNameText + '?';
            Alert.alert(
                'Thông báo', msgLabel,
                [
                    {text: 'Hủy', onPress: () => log.info('Cancel Pressed!')},
                    {text: 'Đồng ý', onPress: () => {
                        let ads = this.state.selectedAds;
                        let adsID = ads.adsID;

                        let currentUser = this.props.global.currentUser;
                        let token = currentUser.token;
                        let userID = currentUser.userID;

                        let {wtoID, toUserID, soTienGiamGia, thuTucMienPhi, deLaiDoTrongNha, ghiChu} = this.state;

                        let moneyValueNumber = soTienGiamGia && soTienGiamGia.replace(/[, -.]+/g,"");

                        let dto = {
                            userID: userID,
                            toUserID: toUserID,
                            wtoID: wtoID,
                            adsID: adsID,
                            giaGiam: soTienGiamGia ? Number(moneyValueNumber/ONE_MILLION) : undefined,
                            baoSangTen: thuTucMienPhi,
                            deLaiDoDac: deLaiDoTrongNha,
                            noiDung: ghiChu,
                            workstation: { name: this.props.global.deviceInfo.deviceModel,
                                workstationID: this.props.global.deviceInfo.deviceID,
                                appType: 'app' }
                        };

                        this.props.actions.postWTS(dto, token)
                            .then(res => {
                                if (res.status == 99) {
                                    Alert.alert('Thông báo', res.msg ? res.msg + '.\nBạn có muốn nâng cấp gói tin?'
                                            : 'Bạn có muốn nâng cấp gói tin?',
                                        [   { text: 'Hủy', onPress: () => { }
                                        },
                                            {
                                                text: 'Đồng ý', onPress: () => {
                                                this._upgradeAds(ads);
                                            }
                                            }
                                        ]);
                                }
                                else if (res.status == 0) {
                                    let msg = res.msg || "Gửi tin thành công";
                                    Alert.alert("Thông báo", msg,
                                        [ { text: 'Đóng', onPress: () => {
                                            Actions.pop();
                                            this._onStartChat();
                                        }} ]);
                                    Analytics.logEvent('POST_WTS', {userID: userID});
                                } else {
                                    let msg = res.msg || res.error;
                                    Alert.alert("Thông báo", msg,
                                        [ { text: 'Đóng', onPress: () => {}} ]);
                                }
                            });
                    }}
                ]);
        }
    }

    _onStartChat() {
        let {selectedAds} = this.state;
        if(!selectedAds){
            let msg = 'Bạn cần chọn tin để Chat với người cần mua';
            this.refs.toastTop && this.refs.toastTop.show(msg, 3000);
            return;
        }
        let {userID, fullName, avatar} = this.props.wto;
        let partner = {
            userID: userID || undefined,
            fullName : fullName || undefined,
            avatar: avatar || undefined
        };
        this.props.actions.startChat(this.props.global.currentUser, partner, selectedAds)
            .then( () => {
                this._doChatPress();
            });
    }

    _doChatPress() {
        Actions.Chat();
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('CHAT_WTO', {deviceID: deviceID, userID: userID});
    }

    _upgradeAds(ads) {
        let adsID = ads.adsID;
        this.props.actions.changePackageField('adsID', adsID);
        this.props.actions.changePackageField('ads', ads);

        if (ads.goiViTri){
            let remainDays = utils.getRemainDay(ads.goiViTri);
            this.props.actions.changePackageField(
                'current_goiViTri', remainDays>0 ? utils.getLevelName(ads.goiViTri) : "Chưa có");
        } else {
            this.props.actions.changePackageField('current_goiViTri', "Chưa có");
        }

        if (ads.goiLogo && ads.goiLogo.length>0) {
            let index = ads.goiLogo.length - 1;
            let remainDays = utils.getRemainDay(ads.goiLogo[index]);
            this.props.actions.changePackageField(
                'current_goiLogo', remainDays>0 ? ads.goiLogo[0].text : "Chưa có");
        } else {
            this.props.actions.changePackageField('current_goiLogo', "Chưa có");
        }

        Actions.UpgradePackgeSelector({ads:ads, doViTriFinalAction: this._refreshAdsPackage.bind(this, adsID)});
    }

    _refreshAdsPackage(adsID) {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.props.actions.getDetail(
            {'adsID' : adsID, 'userID': userID, 'deviceID': deviceID}
            , (data) => {
                let ads = data.ads;
                let adsList = this.state.adsList;
                let newAdsList = adsList;
                for(let i=0; i<adsList.length; i++){
                    if (adsList[i].adsID == ads.adsID){
                        newAdsList = [...adsList.slice(0,i), ads, ...adsList.slice(i+1)];
                        break;
                    }
                }
                this.setState({
                    adsList: newAdsList,
                    selectedAds: ads
                });
            });
    }

    _isValidGiamGia() {
        let soTienGiamMin = this._getSoTienGiamMin();
        let {soTienGiamGia} = this.state;
        let adsGia = this._getAdsGia();

        let moneyValueNumber = soTienGiamGia && soTienGiamGia.replace(/[, -.]+/g,"");

        // if (!moneyValueNumber) {
        //     return 'Bạn chưa nhập số tiền giảm giá!';
        // }

        if (soTienGiamGia && soTienGiamGia.trim().length > 0) {
            if (moneyValueNumber < soTienGiamMin) {
                return 'Số tiền giảm giá không được nhỏ hơn ' + utils.addCommas(soTienGiamMin) + ' ' + DanhMuc.VND;
            }

            if (adsGia > 0 && moneyValueNumber > adsGia*ONE_MILLION) {
                return 'Số tiền giảm giá không được lớn hơn ' + utils.addCommas(adsGia*ONE_MILLION) + ' ' + DanhMuc.VND;
            }
        }

        return null;
    }

    _getSoTienGiamMin() {
        if (this.state.loaiTin == 'mua') {
            return 10000000;
        } else {
            return 100000;
        }
    }

    _isValidInputData() {
        let {adsList, selectedAds} = this.state;
        if (Object.keys(adsList).length == 0) {
            return 'Bạn không có tin nào phù hợp!';
        }
        if (!selectedAds) {
            return 'Bạn chưa chọn tin gửi!';
        }
        return this._isValidGiamGia();
    }

    _getAdsGia() {
        let ads = this.state.selectedAds;
        return ads && ads.gia;
    }

    _onArraySort(a, b) {
        if (a === '') {
            return 1;
        }
        if (b === '') {
            return -1;
        }
        return a - b;
    }
}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        width: width,
        height: 64
    },

    searchButton: {
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        top: height -44 ,
        height: 44,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: '#E83522',
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 11,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchSectionTitle: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingLeft: 17,
        paddingTop: 28,
        paddingBottom: 8,
        // borderTopWidth: 1,
        // borderTopColor: '#f8f8f8',
        backgroundColor: '#F0F0F2'
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection:"column"
        //borderWidth:1,
        //borderColor: "green"
    },
    scrollView: {
        flex: 1,
        height: height-110
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent :'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    addViewBottom: {
        height:30,
        width:width,
        backgroundColor:'#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewTitleHeader:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width-30,
        height: 60
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width/3-5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    loadingContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: height / 2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    adsListView: {
        flexGrow:1,
        backgroundColor:'white',
        marginTop:6,
        width: width - 37,
        marginLeft: 17,
        marginBottom: 20
    },
    adsListSubView: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    preferenceView: {
        flex: 1
    },
    preferenceSubView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    preferenceSubView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        marginRight: 10
    },
    preferenceSubView2: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/2+15,
        marginTop: 10,
        marginBottom: 10
    },
    priceUnitView: {
        flex: 1,
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: 142,
        height: 142,
        marginRight: 9
    },
    heartContent: {
        backgroundColor: 'transparent',
        position: "absolute",
        top: 10,
        left: 98,
        right: 10
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 10
    },
    viewTextContent: {
        flex: 1,
        paddingTop: 8
    },
    priceContent: {
        backgroundColor: '#EB4222',
        position: "absolute",
        bottom: 10,
        left: 10,
        padding: 2,
        borderRadius: 2
    },
    priceText: {
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    },
    goiViTriView: {
        position: 'absolute',
        backgroundColor: 'transparent',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        top: 10,
        left: 10,
        width: 40,
        height: 40
    },
    goiViTriIcon: {
        width: 29,
        height: 36
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#5C5D5F',
        width: 142
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        marginLeft: 17
    },
    selectedAdsView: {
        position: 'absolute',
        top: 48,
        right: 48,
        backgroundColor: '#29AB60',
        borderColor: 'white',
        width: 40,
        height: 40,
        borderRadius: 20,
        borderWidth: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(WToSelectAdsToSend);
