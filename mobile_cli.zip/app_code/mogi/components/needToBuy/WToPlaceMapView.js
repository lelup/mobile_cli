'use strict';

import React, {Component} from 'react';

import { Text, View, StyleSheet, Navigator, TouchableOpacity,
    TouchableHighlight, StatusBar, Image, Alert, PanResponder } from 'react-native'

import {Actions} from 'react-native-router-flux';
import MapView from 'react-native-maps';
import Button from 'react-native-button';

import CommonHeader from '../CommonHeader2';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import danhMuc from '../../assets/DanhMuc';

import findApi from '../../lib/FindApi';
import apiUtils from '../../lib/ApiUtils';

import placeUtil from '../../lib/PlaceUtil';

import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';

import ScalableText from 'react-native-text';

import MMessage from '../message/MMessage';

import LocationMarker from '../marker/LocationMarker';

import Toast, {DURATION} from '../toast/Toast';

import Modal from 'react-native-modalbox';

import Slider from 'react-native-slider';

import SearchInput from '../search/SearchInputExt2';

import MPlacesAutoComplete from '../autoComplete/MPlacesAutoComplete';

import PriceMarker from '../marker/PriceMarker';

const imageHeight = 143;
import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const ASPECT_RATIO = width / (height-134);
const LATITUDE = 20.95389909999999;
const LONGITUDE = 105.75490945;
const LATITUDE_DELTA = 0.00856620000177733;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

/**
 * ## Redux boilerplate
 */

class WToPlaceMapView extends Component {
    _panResponder = {};
    _previousLeft = 0;
    _previousTop = 0;

    constructor(props) {
        log.info("Call WToPlaceMapView.constructor");
        super(props);
        StatusBar.setBarStyle('light-content');

        let viewport = props.viewport;
        let region = viewport && apiUtils.getRegionByViewport(viewport) || undefined;
        if (!region) {
            region = {latitude: LATITUDE, longitude: LONGITUDE,
                latitudeDelta: LATITUDE_DELTA, longitudeDelta: LONGITUDE_DELTA};
        }

        let headerText = "Vị trí";
        if (!props.diaChi || props.diaChi == gui.CHON_KHU_VUC) {
            headerText = "Nhấn để chọn vị trí";
        }
        let diaChi = props.diaChi;
        let circle = {center: {}, radius: 0};
        if (props.circle && props.circle.radius > 0) {
            let center = {latitude: props.circle.center.lat, longitude: props.circle.center.lon};
            let radius = props.circle.radius;
            circle = {center: center, radius: radius*1000};
            let delta = apiUtils.convertRadius2Delta(radius);
            if (0.5*region.latitudeDelta < delta) {
                region.latitudeDelta = delta/ASPECT_RATIO;
                region.longitudeDelta = delta;
            }
            diaChi = this._getCircleDesc(circle);
        } else if (props.polygon && props.polygon.length > 0) {
            diaChi = 'Trong khu vực vẽ tay';
            let geoBox = apiUtils.getWToPolygonBox(props.polygon);
            region = apiUtils.getRegion(geoBox);
            region.latitudeDelta = region.latitudeDelta*1.2;
            region.longitudeDelta = region.longitudeDelta*1.2;
        }

        this.editing = null;

        this.state = {
            textMessage: '',
            msgType: '',
            isFirstLoad: true,
            showSuggestionPosition: props.showSuggestionPosition || false,
            mapRegion: region,
            position: region,
            firstRegion: region,
            firstDuAn: props.duAn,
            firstDiaChinhInfo: props.diaChinhInfo,
            firstDiaChi: props.diaChi,
            firstPlaceType: props.placeType,
            enableRegionChange: false,
            diaChi: diaChi || gui.CHON_KHU_VUC,
            mapType: "standard",
            mapName: "Satellite",
            enableMap: true,
            placeType: props.placeType,
            duAn: props.duAn,
            diaChinhInfo: props.diaChinhInfo,
            headerText: headerText,
            geoFinding: false,
            circle: circle,
            polygon: props.polygon,
            positionSearchPress: circle.radius > 0,
            openRadiusModal: false,
            openDraw: false,
            isSuggestionFlipped: false,
            placeBoundary: []
        }
    }

    _getCircleDesc(circle) {
        let {center, radius} = circle;
        if (radius) {
            return 'Vị trí: (' + center.latitude.toFixed(6) + ',' + center.longitude.toFixed(6) + '), R: ' + radius/1000 + 'km';
        }
        return '';
    }

    _updateMessageProcessing(textMessage) {
        this.setState({textMessage: textMessage});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
    }

    _renderMessageItem() {
        let textValue = this.state.textMessage;
        if (textValue == '' || this.state.msgType == '') {
            return null;
        }
        return (
            <MMessage mainStyle={{top: 64}}
                      barStyle="light-content"
                      animation={this.state.msgType}
                      duration={500}
                      onAnimationEnd={this._onAnimationEnd.bind(this)}
                      textValue={textValue}
                      bgColor={'#fa4916'}
                      textColor={'white'}/>
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({textMessage: '', msgType: ''})}, 2000);
        }
    }

    componentWillMount() {
        this._panResponder = PanResponder.create({
            onStartShouldSetPanResponder: this._handleStartShouldSetPanResponder.bind(this),
            onMoveShouldSetPanResponder: this._handleMoveShouldSetPanResponder.bind(this),
            onPanResponderGrant: this._handlePanResponderGrant.bind(this),
            onPanResponderMove: this._handlePanResponderMove.bind(this),
            onPanResponderRelease: this._handlePanResponderEnd.bind(this),
            onPanResponderTerminate: this._handlePanResponderEnd.bind(this),
        });
        this._previousLeft = 20;
        this._previousTop = 84;

    }

    componentDidMount() {
        this.setState({enableRegionChange: true});
        if (!this.state.duAn) {
            this._loadPlaceBoundary(this.state.diaChinhInfo);
        }
    }

    render() {
        log.info("Call WToPlaceMapView.render");
        if (this.state.isSuggestionFlipped) {
            return this._renderPlaceAutoComplete();
        } else {
            return this._renderMainView();
        }
    }

    _renderPlaceAutoComplete() {
        let predefinedPlaces = [
        ];
        return (
            <View style={styles.fullWidthContainer}>
                <MPlacesAutoComplete
                    ref={'placeSuggestion'}
                    onSelectPress={this._onPlacePress.bind(this)}
                    onCancelPress={this._onCancelPress.bind(this)}
                    predefinedPlaces={predefinedPlaces}
                />
            </View>
        )
    }

    _onPlacePress(data) {
        this._collectSuggestionInfo(data);
        this._flipSuggestion();
    }

    _onCancelPress() {
        this._flipSuggestion();
    }

    _renderMainView() {
        let {polygon, openDraw, position, alertDrawMessage, circle, duAn, diaChinhInfo, diaChi} = this.state;
        let textGuid = alertDrawMessage || 'Chọn vị trí từ thanh tìm kiếm hoặc di chuyển icon trên bản đồ';
        let polygonGUI = polygon && apiUtils.convertPolygonForGUI(polygon) || [];
        let showPoline = (polygonGUI.length === 0) && this.editing;
        let hasCircle = circle && circle.radius > 0;
        let showMarker = (polygonGUI.length === 0) && !openDraw && (hasCircle || duAn || !diaChinhInfo);
        return (
            <View style={styles.fullWidthContainer}>
                <View style={styles.viewGuidHead}>
                    <Text style={styles.textGuidTop}>{textGuid}</Text>
                </View>
                <View style={styles.map}>
                    <MapView
                        initialRegion={this.state.mapRegion}
                        region={this.state.mapRegion}
                        style={styles.mapView}
                        mapType={this.state.mapType}
                        scrollEnabled = {this.state.enableMap}
                        zoomEnabled = {this.state.enableMap}
                        rotateEnabled = {this.state.enableMap}
                        onRegionChange={this._onRegionChange.bind(this)}
                        onRegionChangeComplete={this._onRegionChangeComplete.bind(this)}
                        onPress={this._onSelectPlace.bind(this)}
                        onLongPress={this._onSelectPlace.bind(this)}
                    >
                        {showMarker ? <MapView.Marker coordinate={position} pointerEvents="none">
                            {duAn ? <PriceMarker color={gui.mainColor} amount={diaChi}/> : <LocationMarker/>}
                        </MapView.Marker> : null
                        }

                        {this._renderMapCircle()}

                        {polygonGUI.length > 0 ? <MapView.Polygon
                            coordinates={polygonGUI}
                            strokeColor={gui.mainColor}
                            fillColor="rgba(0,168,230,0.3)"
                            strokeWidth={2}
                        /> : null}
                        {showPoline && (
                            <MapView.Polyline
                                coordinates={this.editing}
                                strokeColor={gui.mainColor}
                                fillColor="rgba(0,168,230,0.3)"
                                strokeWidth={2}
                            />
                        )}
                        {this._renderPlaceBoundary()}

                        <View pointerEvents={openDraw ? "auto" : "none"}
                              style={{width: width, height: height - 134, backgroundColor: 'transparent'}}
                            {...this._panResponder.panHandlers}>
                        </View>
                    </MapView>

                    {/*openDraw ? null : this._renderGooglePlaceAutoComplete()*/}

                    {/*<View style={styles.positionIcon} pointerEvents="none">
                     <Image style={styles.googleMarker}
                     resizeMode={Image.resizeMode.contain}
                     source={require('../../assets/image/google-marker.png')} />
                     </View>*/}

                    {this._renderButtonOnMap()}

                    <Toast
                        ref="toastNumber"
                        position='top'
                        positionValue={height/2-80}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{color:'#fff'}}
                    />

                    <View style={styles.mapButtonContainer}>
                        {!this.state.geoFinding && !this.state.openRadiusModal && !openDraw ?
                            <TouchableOpacity style={styles.searchListButton}
                                              onPress={this._onApply.bind(this)}>
                                <Text style={styles.buttonText}>Chọn</Text>
                            </TouchableOpacity> :
                            <View style={[styles.searchListButton, {backgroundColor: '#C5C2BA'}]}>
                                <Text style={styles.buttonText}>Chọn</Text>
                            </View>
                        }
                    </View>

                    {this._renderRadiusModal()}
                </View>

                {this._renderMessageItem()}

                {this._renderPlaceHeader()}
            </View>
        )
    }

    _renderPlaceBoundary() {
        if (!this.state.placeBoundary) {
            return null;
        }
        let boundaryItems = [];
        let boundaryId = 0;
        this.state.placeBoundary.map((oneBoundary) => {
            let boundary = oneBoundary.filter((location) => {
                return location.latitude !== null && location.longitude !== null;
            });
            if (boundary.length > 0) {
                if (this.state.diaChinhInfo && this.state.diaChinhInfo.codeDuong) {
                    boundaryItems.push(
                        <MapView.Polyline
                            key={boundaryId++}
                            coordinates={boundary}
                            strokeColor={gui.mainColor}
                            fillColor="rgba(0,168,230,0.1)"
                            strokeWidth={3}
                        />
                    )
                } else {
                    boundaryItems.push(
                        <MapView.Polygon
                            key={boundaryId++}
                            coordinates={boundary}
                            strokeColor={gui.mainColor}
                            fillColor="rgba(0,168,230,0.1)"
                            strokeWidth={2}
                        />
                    )
                }
            }
        });
        return boundaryItems;
    }

    _renderPlaceHeader() {
        let placeName = this.state.diaChi;
        let btnDisabled = this.state.openDraw;
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onCancel()}
                    style={styles.backButton2}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 10, paddingRight: 10}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewTitleHeader}>
                    <SearchInput placeName={placeName} activeView={'SearchResult'}
                                 onSuggestPress={this._onSuggestPress.bind(this)}
                                 disabled={btnDisabled} />
                </View>
            </View>
        )
    }

    _onCancel() {
        Actions.pop();
    }

    _onSuggestPress() {
        this.refs.placeSuggestion && this.refs.placeSuggestion.focusInputSearch();
        this._flipSuggestion();
    }

    _flipSuggestion() {
        this.setState({isSuggestionFlipped: !this.state.isSuggestionFlipped});
    }

    _renderPositionSearchButton() {
        let {openDraw, polygon, positionSearchPress} = this.state;
        let mainColor = openDraw || (polygon && polygon.length > 0) ? '#C5C2BA' : positionSearchPress ? gui.mainColor : 'black';
        return (
            <TouchableOpacity disabled={openDraw || (polygon && polygon.length > 0)}
                              onPress={this._onMMapSearch.bind(this)}>
                <View style={[styles.bubble2, styles.button2, {marginTop: 1}]}>
                    {!positionSearchPress ?
                        <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                            <RelandIcon name="map-view" color={mainColor}
                                        mainProps={{flexDirection: 'row'}}
                                        size={24} textProps={{paddingLeft: 0}}
                                        noAction={true}/>
                            <View style={styles.viewIconDiaDiem}>
                                <Text style={[styles.textIconDiaDiem, {color: mainColor}]}>Bán kính</Text>
                            </View>
                        </View> :
                        <RelandIcon name="close" color='black' mainProps={{flexDirection: 'row'}}
                                    size={15} textProps={{paddingLeft: 0}}
                                    noAction={true}/>
                    }
                </View>
            </TouchableOpacity>
        );
    }

    _onMMapSearch() {
        if (!this.state.positionSearchPress){
            this.setState({positionSearchPress: true, openRadiusModal: true, duAn: undefined, diaChinhInfo: undefined,
                circleSearchMsg: gui.INF_RadiusSelection, placeBoundary: []});
        } else {
            // let region = this.state.position;
            // this.setState({geoFinding: true});
            // this._getPlaceByLocation(region.latitude, region.longitude,
            //     (data) => {
            //         this._loadDiaChinhContent(data);
            //         this.setState({positionSearchPress: false, openRadiusModal: false, circle: {},
            //             circleSearchMsg: ''});
            //     });
            this.setState({
                positionSearchPress: false,
                openRadiusModal: false,
                circle: {},
                circleSearchMsg: '',
                diaChi: gui.KHUNG_NHIN_HIEN_TAI,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Vị trí",
                diaChinhInfo: undefined
            });
        }
    }

    _onVitri() {
        if(!this.state.circle.radius) {
            Alert.alert('Thông báo', 'Bạn phải chọn bán kính để giới hạn vùng tìm kiếm của tin cần mua.') ;
            return;
        }
        this.setState({openRadiusModal: false, circleSearchMsg: ''});
    }

    _renderMapCircle() {
        let circle = this.state.circle;
        let region = JSON.parse(JSON.stringify(this.state.position));
        if (this.state.openRadiusModal && region && Object.keys(region).length > 0) {
            circle.center = {latitude: region.latitude, longitude: region.longitude};
        }

        if (this.state.positionSearchPress && circle && (circle.radius > 0 || this.state.openRadiusModal)){
            return (
                <MapView.Circle
                    key={circle.center.latitude + circle.center.longitude + circle.radius}
                    center={circle.center}
                    radius={circle.radius || 0}
                    fillColor="rgba(165,207,255,0.5)"
                    strokeColor={gui.mainColor}
                    position="absolute"
                    zIndex={1}
                    strokeWidth={1}
                />
            )
        }
    }

    _renderRadiusModal() {
        const modalHeight = 105;
        return (
            <Modal animationDuration={100} style={[styles.adsModal,{height: modalHeight}]} isOpen={this.state.openRadiusModal} position={"bottom"}
                   ref={"radiusModal"} isDisabled={false} onPress={() => {this._onCloseRadiusModel()}}
                   onClosed={this._onCloseRadiusModel.bind(this)} backdrop={false}>
                {this._renderRadiusContent()}
            </Modal>
        );
    }

    _onCloseRadiusModel() {
        this.setState({openRadiusModal: false});
    }

    _renderRadiusContent() {
        let radius = this.state.circle.radius ? this.state.circle.radius : 0;
        return (
            <View style={styles.searchListButton2}>
                <View style={styles.viewTopNav}>
                    <TruliaIcon onPress={this._onMMapSearch.bind(this)}
                                name="arrow-down" color={gui.mainColor} size={26}
                                mainProps={styles.backButton} text={this.props.backTitle}
                                textProps={styles.backButtonText} >
                    </TruliaIcon>
                    <ScalableText style={styles.textSpaceTop}>{radius/1000} km xung quanh vị trí đã chọn.</ScalableText>
                    <TouchableOpacity onPress={this._onVitri.bind(this)} style={styles.customPageRightTitle}>
                        <ScalableText style={styles.customPageRightTitleText}>
                            Xong
                        </ScalableText>
                    </TouchableOpacity>

                </View>
                <View style={styles.viewCenterNav}>
                    <Slider
                        value={radius/1000}
                        onValueChange={this._setRadiusCenter.bind(this)}
                        trackStyle={styles.track}
                        thumbStyle={styles.thumb}
                        minimumValue={0}
                        maximumValue={5}
                        step={0.5}
                        minimumTrackTintColor={gui.mainColor}
                        maximumTrackTintColor='#b7b7b7'
                    />
                </View>
                {this._renderSliderView()}
                <View style={styles.viewBottomNav}>
                    <View style={styles.viewTextBottom}>
                        <Text style={styles.textBottomLeft}>{radius/1000}</Text>
                        <Text style={styles.textBottomCenter}>KM</Text>
                    </View>
                    <View style={{flex:1}}>
                        <Text style={styles.textBottomRight}>5 KM</Text>
                    </View>
                </View>
            </View>
        );
    }

    _setRadiusCenter(radius){
        let circle = JSON.parse(JSON.stringify(this.state.circle));
        circle.radius = radius*1000;
        let region = JSON.parse(JSON.stringify(this.state.mapRegion));
        let center = {latitude: region.latitude, longitude: region.longitude};
        circle.center = center;
        let delta = apiUtils.convertRadius2Delta(radius);
        if (0.5*region.latitudeDelta < delta) {
            region.latitudeDelta = delta/ASPECT_RATIO;
            region.longitudeDelta = delta;
        }
        let diaChi = this.state.diaChi;
        if (radius > 0) {
            diaChi = this._getCircleDesc(circle);
        }
        this.setState({
            mapRegion: region,
            diaChi: diaChi,
            circle: circle});
    }

    _renderSliderView(){
        return (
            <View style={styles.viewMeasure}>
                <View style={styles.sliderDotOne}/>
                <View style={styles.sliderDotTwo}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotThree}/>
                <View style={styles.sliderDotFour}/>
            </View>
        );
    }

    _renderGooglePlaceAutoComplete(){
        if (this.state.polygon && this.state.polygon.length > 0) {
            return (
                <View style={styles.touchSearch}>
                    <View style={styles.searchTextContainer}>
                        <View style={styles.viewIconSearch}>
                            <RelandIcon name="search" color='#8a8a8a' mainProps={{ top: 10, marginLeft: 6 }}
                                        size={18} textProps={{}}
                            />
                        </View>
                        <View style={styles.viewSearch}>
                            <ScalableText style={styles.searchTextBottom}>
                                {this._getdiaChi()}
                            </ScalableText>
                        </View>
                    </View>
                </View>
            );
        } else  {
            return (
                <TouchableHighlight onPress={this._onPress.bind(this)}
                                    underlayColor="rgba(30,30,30,0.4)"
                                    style={styles.touchSearch}>
                    <View style={styles.searchTextContainer}>
                        <View style={styles.viewIconSearch}>
                            <RelandIcon name="search" color='#8a8a8a' mainProps={{ top: 10, marginLeft: 6 }}
                                        size={18} textProps={{}}
                            />
                        </View>
                        <View style={styles.viewSearch}>
                            <ScalableText style={styles.searchTextBottom}>
                                {this._getdiaChi()}
                            </ScalableText>
                        </View>
                    </View>
                </TouchableHighlight>
            );
        }
    }

    _getdiaChi() {
        var diaChi = this.state.diaChi;

        if (!diaChi || diaChi.length <= 0)
            return gui.CHON_KHU_VUC;

        if (diaChi.length > 40) {
            diaChi = diaChi.substring(0, 40) + '...';
        }

        return diaChi;
    }

    _onPress(){
        log.info("WToPlaceMapView._onPress");
        Actions.DinhGiaPlacesAutoComplete(
            {
                onSuggestionPressed: (location)=>this._collectSuggestionInfo(location),
                placeType: ["DIA_DIEM"]

            });
    }

    _collectSuggestionInfo(location){
        let region = apiUtils.getRegionByViewport(location.viewport);
        // region.latitudeDelta = LATITUDE_DELTA;
        // region.longitudeDelta = LONGITUDE_DELTA;
        let diaChi = location.fullName;
        let circle = {};

        let isDuAnPlace = location.placeType == danhMuc.placeType.DU_AN;
        let isDiaDiemPlace = location.placeType == danhMuc.placeType.DIA_DIEM;
        let diaChinhInfo = undefined;
        if (isDiaDiemPlace) {
            diaChi = gui.KHUNG_NHIN_HIEN_TAI;
            circle = this.state.circle;
            if (circle && circle.radius > 0) {
                circle.center = {latitude: region.latitude, longitude: region.longitude};
                let radius = circle.radius/1000;
                let delta = apiUtils.convertRadius2Delta(radius);
                if (0.5*region.latitudeDelta < delta) {
                    region.latitudeDelta = delta/ASPECT_RATIO;
                    region.longitudeDelta = delta;
                }
                diaChi = this._getCircleDesc(this.state.circle);
            }
        } else if (!isDuAnPlace) {
            diaChinhInfo = {
                codeTinh: location.tinh,
                codeHuyen: location.huyen,
                codeXa: location.xa,
                codeDuong: location.duong,
                tinh: location.tinhName,
                huyen: location.huyenName,
                xa: location.xaName,
                duong: location.duongName
            }
        }
        this.setState(
            { enableMap: true,
                diaChi: diaChi,
                placeType: location.placeType,
                headerText: "Vị trí",
                duAn: isDuAnPlace ? location : undefined,
                diaChinhInfo: diaChinhInfo,
                position: region,
                mapRegion: region,
                openDraw: false,
                alertDrawMessage: '',
                polygon: [],
                circle: circle,
                positionSearchPress: circle && circle.radius > 0,
                openRadiusModal: false,
                placeBoundary: []
            });
        if (!isDuAnPlace && !isDiaDiemPlace) {
            this._loadPlaceBoundary(diaChinhInfo);
        }
    }
    
    _loadPlaceBoundary(diaChinhInfo) {
        this.setState({placeBoundary: []});
        if (diaChinhInfo &&
            (diaChinhInfo.codeTinh || diaChinhInfo.codeHuyen || diaChinhInfo.codeXa)) {
            let diaChinhDto = {codeTinh: diaChinhInfo.codeTinh || undefined,
                codeHuyen: diaChinhInfo.codeHuyen || undefined, codeXa: diaChinhInfo.codeXa || undefined,
                codeDuong: diaChinhInfo.codeDuong || undefined};
            findApi.getBoundary(diaChinhDto).then((res) => {
                if (res.status == 0 && res.data) {
                    this._updateMapViewport(res.data, diaChinhInfo.codeDuong);
                }
            });
        }
    }

    _updateMapViewport(boundary, isDuongPlace) {
        if (isDuongPlace) {
            let geoBox = apiUtils.getGeoBoxBoundary(boundary);
            if (geoBox.length == 0) {
                return;
            }
            let region = apiUtils.getRegion(geoBox);
            let oldRatio = region.longitudeDelta/region.latitudeDelta;
            let delta = Math.max(region.latitudeDelta, region.longitudeDelta);
            region.latitudeDelta = oldRatio > ASPECT_RATIO ? delta/ASPECT_RATIO : delta;
            region.longitudeDelta = oldRatio > ASPECT_RATIO ? delta : delta*ASPECT_RATIO;
            region.latitudeDelta = delta/ASPECT_RATIO;
            region.longitudeDelta = delta;
            this.setState({position: region, mapRegion: region, placeBoundary: boundary});
        } else {
            this.setState({placeBoundary: boundary});
        }
    }

    _renderButtonOnMap(){
        return (
            <View style={styles.inMapButtonContainer}>
                {this._renderSuggestionPositionButton()}
                {this._renderPositionSearchButton()}
                {this._renderDrawButton()}
                {this._renderCurrentPositionButton()}
            </View>
        );
    }

    _renderDrawButton() {
        let drawIconColor = this.state.positionSearchPress ? '#C5C2BA' :
            this.state.polygon && this.state.polygon.length == 0 && this.state.openDraw ? gui.mainColor : 'black';
        return (
            <TouchableOpacity disabled={this.state.positionSearchPress}
                              onPress={this._onDrawPressed.bind(this)}>
                <View style={[styles.bubble, styles.button, {flexDirection: 'column'}]}>
                    {this.state.polygon && this.state.polygon.length > 0 ? (
                        <RelandIcon name="close" color='black' mainProps={{flexDirection: 'row'}}
                                    size={15} textProps={{paddingLeft: 0}}
                                    noAction={true}/>) :
                        (
                            <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                                <RelandIcon name="hand-o-up" color={drawIconColor}
                                            mainProps={{flexDirection: 'row'}}
                                            size={20} textProps={{paddingLeft: 0}}
                                            noAction={true}/>
                                <Text style={[styles.drawIconText, {color: drawIconColor}]}>Vẽ tay</Text>
                            </View>
                        )}
                </View>
            </TouchableOpacity>
        );
    }

    _handleStartShouldSetPanResponder(e, gestureState) {
        // Should we become active when the user presses down on the circle?
        return true;
    }

    _handleMoveShouldSetPanResponder(e, gestureState) {
        // Should we become active when the user moves a touch over the circle?
        return true;
    }

    _handlePanResponderGrant(e, gestureState) {
        this._previousLeft = gestureState.x0;
        this._previousTop = gestureState.y0;
    }

    _handlePanResponderMove(e, gestureState) {
        this._refreshPolygons(gestureState);
    }

    _refreshPolygons(gestureState) {
        var region = this.state.mapRegion;
        if (isNaN(region.latitude) || isNaN(region.longitude)) {
            return;
        }
        var x0 = this._previousLeft + gestureState.dx;
        var y0 = this._previousTop + gestureState.dy;
        var lat = region.latitude + (region.longitudeDelta/ASPECT_RATIO)*(0.5-(y0-84)/(height-134));
        var lon = region.longitude + region.longitudeDelta*(x0/width-0.5);
        var coordinate = {latitude: lat, longitude: lon};
        let editing = this.editing;
        if (!editing) {
            this.editing = [coordinate];
        } else {
            this.editing = [
                ...editing,
                coordinate
            ];
        }
        this.forceUpdate();
    }

    _handlePanResponderEnd(e, gestureState) {
        this._previousLeft += gestureState.dx;
        this._previousTop += gestureState.dy;

        let {position, mapRegion} = this.state;
        let editing = this.editing;
        let hasPolygon = editing && editing.length > 2;
        let polygon = [];
        if (hasPolygon) {
            let geoBox = apiUtils.getPolygonBox2(editing);
            let latitudeDelta = geoBox[2] - geoBox[0];
            let longitudeDelta = geoBox[3] - geoBox[1];
            if (latitudeDelta >= 0.05*mapRegion.latitudeDelta && longitudeDelta >= 0.05*mapRegion.longitudeDelta) {
                polygon = apiUtils.convertPolygon2(editing);
            }
        }
        if (polygon.length == 0){
            // this.setState({geoFinding: true});
            // this._getPlaceByLocation(position.latitude, position.longitude, this._loadDiaChinhContent.bind(this));
            this.setState({
                diaChi: gui.KHUNG_NHIN_HIEN_TAI,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Vị trí",
                diaChinhInfo: undefined
            });
        } else {
            this.setState({diaChi: 'Trong khu vực vẽ tay'});
        }
        this.setState({
            openDraw: false,
            alertDrawMessage: '',
            polygon: polygon
        });
        this.editing = null;
        this.forceUpdate();
    }

    _onDrawPressed() {
        let {polygon, position} = this.state;
        let hasPolygon = polygon && polygon.length > 0;
        if (!this.state.openDraw && !hasPolygon) {
            this.setState({
                openDraw: true,
                positionSearchPress: false,
                circle: {},
                polygon: [],
                duAn: undefined,
                diaChinhInfo: undefined,
                alertDrawMessage: 'Hãy vẽ khu vực muốn mua/thuê.',
                placeBoundary: []});
        } else {
            // if (hasPolygon) {
            //     this.setState({geoFinding: true});
            //     this._getPlaceByLocation(position.latitude, position.longitude, this._loadDiaChinhContent.bind(this));
            // }
            this.setState({
                openDraw: false,
                alertDrawMessage: '',
                polygon: [],
                diaChi: gui.KHUNG_NHIN_HIEN_TAI,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Vị trí",
                diaChinhInfo: undefined
            });
        }
        this.editing = null;
        this.forceUpdate();
    }

    _renderCurrentPositionButton() {
        let {openDraw, polygon, positionSearchPress} = this.state;
        let color = openDraw || (polygon && polygon.length > 0) || positionSearchPress ? '#C5C2BA' : 'black';

        return (
            <View >
                <TouchableOpacity disabled={  positionSearchPress || openDraw || (polygon && polygon.length > 0)}
                                  onPress={this._onCurrentLocationPress.bind(this)} >
                    <View style={[styles.bubble, styles.button, {marginTop: 10}]}>
                        <RelandIcon name="direction" color={color} mainProps={{flexDirection: 'row'}}
                                    size={20} textProps={{paddingLeft: 0}}
                                    noAction={true} />
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderSuggestionPositionButton() {
        if (!this.props.showSuggestionPosition)
            return;

        return (
            <View >
                <TouchableOpacity onPress={this._onSuggestionLocationPress.bind(this)} >
                    <View style={[styles.bubble, styles.button, {flexDirection: 'column'}]}>
                        <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                            <RelandIcon name="plus" color={'black'}
                                        mainProps={{flexDirection: 'row'}}
                                        size={22} textProps={{paddingLeft: 0}}
                                        noAction={true}></RelandIcon>
                            <Text style={[styles.positionSuggetionIconText, {color: 'black'}]}>Gợi ý</Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onCurrentLocationPress() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                var region = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    latitudeDelta: this.state.mapRegion.latitudeDelta || LATITUDE_DELTA,
                    longitudeDelta: this.state.mapRegion.longitudeDelta || LONGITUDE_DELTA
                };
                // this.setState(
                //     { position: region,
                //         mapRegion: region,
                //         placeType: danhMuc.placeType.DIA_DIEM,
                //         duAn: undefined,
                //         geoFinding: true
                //     });
                // this._getPlaceByLocation(region.latitude, region.longitude, this._loadDiaChinhContent.bind(this));
                // findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this),
                //     () => {this.setState({geoFinding: false})});
                this.setState({
                    position: region,
                    mapRegion: region,
                    diaChi: gui.KHUNG_NHIN_HIEN_TAI,
                    placeType: danhMuc.placeType.DIA_DIEM,
                    duAn: undefined,
                    headerText: "Vị trí",
                    diaChinhInfo: undefined
                });
            },
            (error) => {
                this._updateMessageProcessing(gui.ERR_LocationNotOn);
            },
            {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
        );
    }

    _getPlaceByLocation(lat, lon, callback) {
        findApi.getPlaceByLocation(lat, lon).then((res) => {
            if (res.success) {
                callback(res.result);
            } else {
                this.setState({geoFinding: false});
            }
        });
    }

    _loadDiaChinhContent(data){
        if (!data) {
            this.setState({geoFinding: false});
            return;
        }
        let diaChinh = {
            codeTinh: data.codeTinh,
            codeHuyen: data.codeHuyen,
            codeXa: data.codeXa,
            tinh: data.tinh,
            huyen: data.huyen,
            xa: data.xa
        };

        this.setState(
            { diaChi: data.fullName,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Vị trí",
                diaChinhInfo: diaChinh,
                geoFinding: false
            });
    }

    _onSuggestionLocationPress() {
        let {firstRegion, firstDuAn, firstDiaChinhInfo, firstDiaChi, firstPlaceType} = this.state;
        if (firstDiaChi != gui.CHON_KHU_VUC) {
            let placeType = firstPlaceType;
            this.setState({diaChi: firstDiaChi, position: firstRegion, mapRegion: firstRegion,
                duAn: firstDuAn, diaChinhInfo: firstDiaChinhInfo, placeType: placeType});
        } else {
            // this.setState({position: firstRegion, mapRegion: firstRegion, geoFinding: true});
            // this._getPlaceByLocation(firstRegion.latitude, firstRegion.longitude, this._loadDiaChinhContent.bind(this));
            // findApi.getGeocoding(firstRegion.latitude, firstRegion.longitude, this._getDiaChinhContent.bind(this),
            //     () => {this.setState({geoFinding: false})});
            this.setState({
                position: firstRegion,
                mapRegion: firstRegion,
                diaChi: gui.KHUNG_NHIN_HIEN_TAI,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Vị trí",
                diaChinhInfo: undefined
            });
        }
    }

    _onSelectPlace(event) {
        if (this.state.polygon && this.state.polygon.length > 0) {
            return;
        }
        let coordinate = event.nativeEvent.coordinate;
        let region = {
            ...this.state.mapRegion,
            latitude: coordinate.latitude,
            longitude: coordinate.longitude
        };
        this.setState({position: region});
        let {circle} = this.state;
        if (circle && circle.radius > 0) {
            circle.center = {
                latitude: coordinate.latitude,
                longitude: coordinate.longitude
            };
            let diaChi = this._getCircleDesc(circle);
            this.setState(
                { diaChi: diaChi,
                    circle: circle,
                    placeType: danhMuc.placeType.DIA_DIEM,
                    duAn: undefined,
                    headerText: "Vị trí",
                    diaChinhInfo: undefined,
                    geoFinding: false
                });
        }
        else {
            // this.setState({geoFinding: true});
            // this._getPlaceByLocation(region.latitude, region.longitude, this._loadDiaChinhContent.bind(this));
            // findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this),
            //     () => {this.setState({geoFinding: false})});

            if (!this.state.positionSearchPress){
                this.setState({positionSearchPress: true, openRadiusModal: true,
                    circleSearchMsg: gui.INF_RadiusSelection});
            }

            this.setState(
                { diaChi: gui.KHUNG_NHIN_HIEN_TAI,
                    placeType: danhMuc.placeType.DIA_DIEM,
                    duAn: undefined,
                    headerText: "Vị trí",
                    diaChinhInfo: undefined,
                    placeBoundary: [],
                    geoFinding: false
                });
        }
    }

    _onRegionChange(region) {
        if (!this.state.enableRegionChange) {
            return;
        }

        this.setState({mapRegion: region});
    }

    _onRegionChangeComplete(region) {
        if (!this.state.enableRegionChange) {
            return;
        }

        this.setState({mapRegion: region});
        //
        // if (this.state.placeType == danhMuc.placeType.DIA_DIEM
        //     || (this.state.placeType == danhMuc.placeType.DU_AN && !this.state.isFirstLoad)){
        //   findApi.getGeocoding(region.latitude, region.longitude, this._getDiaChinhContent.bind(this));
        // }

        this.setState({
            isFirstLoad: false
        })
    }

    _onApply() {
        let {position, diaChi, placeType, duAn, diaChinhInfo, circle, polygon} = this.state;
        if (!position || diaChi == gui.CHON_KHU_VUC) {
            this.refs.toastNumber.show(gui.INF_MapViewSelection,5000);
            return;
        }

        this.setState({geoFinding: true});

        let viewport = apiUtils.getViewport(position);
        let location = {lat: position.latitude, lon: position.longitude};

        let sCircle = undefined;
        let hasCircle = circle && circle.radius > 0;
        if (hasCircle) {
            let center = {lat: circle.center.latitude, lon: circle.center.longitude};
            let radius = circle.radius/1000;
            sCircle = {center: center, radius: radius};
            let delta = apiUtils.convertRadius2Delta(radius);
            let region = {latitude: center.lat, longitude: center.lon,
                latitudeDelta: delta/ASPECT_RATIO, longitudeDelta: delta};
            viewport = apiUtils.getViewport(region);
            location = center;
        }
        let hasPolygon = polygon && polygon.length > 0;
        if (hasPolygon) {
            let geoBox = apiUtils.getWToPolygonBox(polygon);
            viewport = apiUtils.getViewportByBox(geoBox);
            let region = apiUtils.getRegion(geoBox);
            location = {lat: region.latitude, lon: region.longitude};
        }
        let ignoreDiaChinh = hasCircle || hasPolygon;

        if (!ignoreDiaChinh && !duAn && !diaChinhInfo) {
            this.setState({geoFinding: false});
            Alert.alert('Thông báo', 'Bạn phải chọn bán kính để giới hạn vùng tìm kiếm của tin cần mua.',
                [{text: 'Đóng', onPress: () => {
                    this.setState({positionSearchPress: true, openRadiusModal: true,
                        circleSearchMsg: gui.INF_RadiusSelection});
                }}]) ;

            return;
        }

        let data = {
            viewport: viewport,
            location: location,
            diaChi: diaChi,
            placeType: placeType,
            duAn: ignoreDiaChinh ? undefined : duAn,
            diaChinhInfo: ignoreDiaChinh ? undefined : diaChinhInfo,
            circle: sCircle,
            polygon: hasPolygon ? polygon : undefined
        };

        this._onLoadDiaChinhSuccess(data);
    }

    _onLoadDiaChinhSuccess(data) {
        this.props.onPress(data);
        Actions.pop();
    }

    _getDiaChinhContent(data){
        let diaChinh = placeUtil.parseDiaChinh(data);

        let {tinh, huyen, xa, diaDiem} = diaChinh;

        let fullName = tinh;
        if (huyen && huyen!=''){
            fullName = huyen + ', ' + fullName;
        }

        if (xa && xa!=''){
            fullName = xa + ', ' + fullName;
        }

        if (diaDiem && diaDiem.length >0){
            fullName = diaDiem + ', ' + fullName;
        }

        this.setState(
            { diaChi: fullName,
                placeType: danhMuc.placeType.DIA_DIEM,
                duAn: undefined,
                headerText: "Vị trí",
                diaChinhInfo: diaChinh,
                geoFinding: false
            });
    }

    _onCancel() {
        Actions.pop();
    }
}

// Later on in your styles..
var styles = StyleSheet.create({
    headerSeparator: {
        // marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white',
    },
    container: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    searchListButtonText: {
        marginLeft: 15,
        marginRight: 15,
        marginTop: 0,
        marginBottom: 0,
        flexDirection: 'column',
    },
    map: {
        position: 'absolute',
        top: 84,
        left: 0,
        right: 0,
        bottom: 0
    },
    mapView: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 50,
        marginTop: 0,
        marginBottom: 0
    },
    googleMarker: {
        height: 40,
        width: 40,
        marginBottom: 40,
        backgroundColor: 'transparent'
    },
    title: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
        backgroundColor: 'white'
    },
    search: {
        position: 'absolute',
        top:0,
        left: 0,
        right: 0,
        height: 64,
        backgroundColor: 'white',
        alignItems: 'stretch',
        justifyContent: 'flex-start'
    },
    mapIcon: {
        color: 'white',
        textAlign: 'center'
    },
    text: {
        color: 'white'
    },
    mapButtonContainer: {
        position: 'absolute',
        bottom: 0,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: 'transparent'
    },
    buttonText: {
        color: 'white',
        fontSize: 17,
        fontWeight: 'bold',
        fontFamily: gui.fontFamily
    },
    searchListButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        backgroundColor: gui.mainColor,
        height: 50
    },
    searchTextContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: 28,
        width: width
    },
    searchText: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        textAlign: 'center',
        paddingLeft:2,
        paddingRight: 2,
        backgroundColor:'transparent'
    },
    positionIcon: {
        position: 'absolute',
        top: (height-60-25-60)/2,
        left: width/2 - 10,
        justifyContent: 'center',
        borderColor: gui.mainColor,
        backgroundColor: 'transparent'
    },
    inMapButtonContainer: {
        position: 'absolute',
        bottom: 80,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginVertical: 5,
        marginBottom: 0,
        backgroundColor: 'transparent',
    },
    bubble: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 5,
        paddingVertical: 5,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center'
    },
    button: {
        width: 43,
        height: 38,
        paddingVertical: 5,
        alignItems: 'center',
        marginVertical: 5,
        backgroundColor: 'white',
        opacity: 0.9,
        marginLeft: 10
    },
    positionSuggetionIconText: {
        fontSize: 9,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        textAlign: 'center',
        backgroundColor:'transparent'
    },
    touchSearch:{
        position: 'absolute',
        top: 15,
        borderRadius:4,
        paddingLeft:0,
        marginLeft:10,
        marginRight:10,
        marginTop: 5,
        height:30,
        width:width - 20,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        borderWidth:1,
        borderColor:'lightgray',
        opacity: 0.9,
    },
    viewSearch:{
        width:width-65,
        height:28,
        right:20,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor:'transparent',
    },
    searchTextBottom: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        textAlign: 'left',
        paddingTop:5,
        backgroundColor:'transparent',
        fontWeight:'400',
        width:width-65,
        height:28,
        color:'#1d1d1d'
    },
    viewIconSearch: {
        height: 28,
        width: 28,
        backgroundColor: 'transparent',
        left: 20,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewGuidHead: {
        width: width,
        height: 20,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top:64,
        left: 0,
        right: 0
    },
    textGuidTop: {
        fontSize: 11,
        fontFamily: gui.fontFamily,
        fontWeight : '400',
        color: '#868686',
        textAlign: 'center'
    },
    adsModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        height: imageHeight,
        width: width,
        marginVertical: 0
    },
    searchListButton2: {
        flexDirection: 'column',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: 'transparent',
        height: 100,
        borderTopWidth:1,
        borderColor:'lightgray'
    },
    viewTopNav: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        backgroundColor: 'white',
        height: 30,
        width: width
    },
    backButton: {
        width: 60,
        paddingTop: 5,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingRight: 18,
        paddingLeft: 5
    },
    backButtonText: {
        color: gui.mainColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 5
    },
    textSpaceTop:{
        fontSize: 15,
        color:'#333333',
        textAlign:'center',
        alignItems: 'center',
    },
    customPageRightTitle:{
        alignItems: 'flex-end',
        justifyContent: 'center',
        height:25,
        width: 60,
        paddingTop: 5,
        paddingRight: 5,
        backgroundColor:'transparent'
    },
    customPageRightTitleText: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        textAlign: 'right',
        fontWeight:'500'
    },
    viewCenterNav: {
        backgroundColor: 'white',
        height: 40,
        width: width - 30,
        right: 15,
        left: 15,
        alignItems: 'stretch',
        justifyContent: 'center',
        flexDirection:'column'
    },
    track: {
        height: 2,
        borderRadius: 1,
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: gui.mainColor,
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    viewMeasure: {
        backgroundColor: 'transparent',
        height: 5,
        width: width - 30,
        right: 15,
        left: 15,
        bottom: 8,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row'
    },
    sliderDotOne: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        left: 6
    },

    sliderDotTwo: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        marginLeft: (width - 30) / 10
    },
    sliderDotThree: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        marginLeft: (width - 30) / 10 - 7
    },
    sliderDotFour: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius:5,
        marginLeft: (width - 30) / 10 - 6
    },
    viewBottomNav: {
        backgroundColor: 'white',
        height: 30,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewTextBottom:{
        flex:1,
        justifyContent:'center',
        alignItems:'flex-start',
        flexDirection:'row',
        backgroundColor:'transparent'
    },
    textBottomLeft:{
        fontSize: 13,
        flex:1,
        color:'#676769',
        textAlign:'right',
        marginBottom: 5,
        paddingRight:3,
    },
    textBottomCenter:{
        fontSize: 13,
        flex:5,
        color:'#676769',
        textAlign:'left',
        marginBottom: 5,
    },
    textBottomRight:{
        fontSize: 13,
        flex:1,
        color:'#676769',
        textAlign:'right',
        paddingRight:15,
        marginBottom: 5
    },
    bubble2: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 2,
        paddingVertical: 2,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom:13
    },
    button2: {
        width: 43,
        height: 38,
        paddingVertical: 2,
        alignItems: 'center',
        marginVertical: 2,
        backgroundColor: 'white',
        opacity: 0.75,
        marginLeft: 10
    },
    viewIconDiaDiem:{
        flex:1,
        backgroundColor:'transparent',
        justifyContent:'flex-end'
    },
    textIconDiaDiem:{
        backgroundColor:'white',
        fontSize:8
    },
    drawIconText: {
        fontSize: 8,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        textAlign: 'center'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        width: width,
        height: 64
    },
    backButton2: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    viewTitleHeader:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    }
});

export default WToPlaceMapView;