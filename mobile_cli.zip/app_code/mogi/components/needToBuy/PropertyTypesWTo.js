'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import { Map } from 'immutable';

import React, { Component } from 'react';

import { View, SegmentedControlIOS, Text, StyleSheet, TouchableOpacity } from 'react-native'

import { Actions } from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import TruliaIcon from '../TruliaIcon';
import CommonHeader from '../CommonHeader2';
import DanhMuc from '../../assets/DanhMuc';
import FullLine from '../line/FullLine';

import MultipleChoice from '../MultipleChoice';
import MultipleChoice3 from '../MultipleChoice3';

import gui from '../../lib/gui';

/**
* ## Redux boilerplate
*/
const actions = [
  globalActions,
  searchActions,
  postAdsActions
];

function mapStateToProps(state) {
  return {
    ...state,
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

var loaiNhaDatValues = [];
var loaiNhaDatKeys = [];

class PropertyTypesWTo extends Component {
  constructor(props) {
    super(props);
    var loaiTin = this.getLoaiTin();
    loaiNhaDatKeys = loaiTin == 'mua' ? DanhMuc.LoaiNhaDatBanKey : DanhMuc.LoaiNhaDatThueKey;
    loaiNhaDatValues = loaiTin == 'mua' ? DanhMuc.getLoaiNhaCanMuaValues() : DanhMuc.getLoaiNhaCanThueValues();

    var loaiNhaDatVal = [];
    props.loaiNhaDat && props.loaiNhaDat.map((one) => {
      loaiNhaDatVal.push(this.getLoaiNhaDatVal(one));
    });
    if (!loaiNhaDatVal) {
      loaiNhaDatVal = [loaiNhaDatValues[0]];
    }

    this.state = {
      loaiNhaDat: loaiNhaDatVal,
    };
  }

  getLoaiTin() {
    var { func, loaiTin, postAds } = this.props;
    return (func == 'search') ? loaiTin : postAds.loaiTin;
  }

  getLoaiNhaDat() {
    var { func, loaiNhaDat, postAds } = this.props;
    return (func == 'search') ? loaiNhaDat : postAds.loaiNhaDat;
  }

  getLoaiNhaDatVal(oneLoaiNhaDat) {
    var loaiTin = this.getLoaiTin();
    loaiNhaDatValues = loaiTin == 'mua' ? DanhMuc.getLoaiNhaCanMuaValues() : DanhMuc.getLoaiNhaCanThueValues();
    var loaiNhaDatVal = this.getValueByKey(loaiNhaDatValues, oneLoaiNhaDat);
    if (!loaiNhaDatVal) {
      loaiNhaDatVal = loaiNhaDatValues[0];
    }
    return loaiNhaDatVal;
  }

  render() {
    // console.log('Propertytypeswto this.props.owner', this.props.owner)
    if (this.props.owner == 'ContactNhuCau')
      return (
        <View style={myStyles.fullWidthContainer}>
          <View style={myStyles.search}>
            <View style={myStyles.customPageHeader}>
              <TouchableOpacity style={myStyles.viewPlusPost}
                                onPress={this._onBack.bind(this)}
              >
                <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
              </TouchableOpacity>
              <View style={myStyles.customPageTitle}>
                <Text style={myStyles.customPageTitleText}>
                  Loại nhà đất
                </Text>
              </View>
              <TouchableOpacity style={myStyles.viewHuy}
                onPress={this._onDone.bind(this)}
              >
                <Text style={[myStyles.customPageTitleText, { fontSize: 15, fontWeight: '400', marginTop: 2, color: gui.mainColor }]}>
                  Chọn
                </Text>
              </TouchableOpacity>
            </View>
            <FullLine />
          </View>

          <MultipleChoice3
            options={loaiNhaDatValues}
            style={myStyles.choiceList}
            selectedOptions={this.state.loaiNhaDat}
            maxSelectedOptions={loaiNhaDatValues.length}//{this.props.search.form.fields.loaiTin=='mua' ? nhaDatBan.length : nhaDatChoThue.length}
            onSelection={(option) => this._onApply(option)}
          />
        </View>
      );
    else
      return (
        <View style={myStyles.fullWidthContainer}>
          <CommonHeader headerTitle={"Loại nhà đất"} />
          <View style={myStyles.headerSeparator} />

          <MultipleChoice
            options={loaiNhaDatValues}
            style={myStyles.choiceList}
            selectedOptions={this.state.loaiNhaDat}
            maxSelectedOptions={loaiNhaDatValues.length}//{this.props.search.form.fields.loaiTin=='mua' ? nhaDatBan.length : nhaDatChoThue.length}
            onSelection={(option) => this._onApply(option)}
          />
        </View>
      );
  }

  _onBack() {
    Actions.pop();
  }

  _onApply_old(option) {

    var { func, search } = this.props;
    let loaiNhaDatVal = this.getKeyByValue(loaiNhaDatValues, option);
    if (func == 'search') {
      this.props.onLoaiNhaDatChange(loaiNhaDatVal);
    } else {
      this.props.actions.onPostAdsFieldChange("loaiNhaDat", loaiNhaDatVal);
    }
    Actions.pop();
  }

  _onApply(option) {
    var loaiTin = this.getLoaiTin();
    loaiNhaDatValues = loaiTin == 'mua' ? DanhMuc.getLoaiNhaCanMuaValues() : DanhMuc.getLoaiNhaCanThueValues();
    if (option == loaiNhaDatValues[0]) {
      this.setState({ loaiNhaDat: [loaiNhaDatValues[0]] });
      return;
    }

    let newLoaiNhaDat = this.state.loaiNhaDat.filter((one) => {
      return one != loaiNhaDatValues[0]
    }) || [];

    this.setState({ loaiNhaDat: newLoaiNhaDat });
  }

  _onDone() {
    console.log('_onDone ****', this.state.loaiNhaDat)
    var loaiTin = this.getLoaiTin();
    let loaiNhaDatKeys = [];
    loaiNhaDatValues = loaiTin == 'mua' ? DanhMuc.getLoaiNhaCanMuaValues() : DanhMuc.getLoaiNhaCanThueValues();
    this.state.loaiNhaDat.map((one) => {
      loaiNhaDatKeys.push(this.getKeyByValue(loaiNhaDatValues, one));
    });
    this.props.onLoaiNhaDatChange(loaiNhaDatKeys);
    Actions.pop();
  }

  getValueByKey(values, key) {
    var value = '';
    for (var i = 0; i < loaiNhaDatKeys.length; i++) {
      var loaiKey = loaiNhaDatKeys[i];
      if (key == loaiKey) {
        value = values[i];
        break;
      }
    }
    // console.log(value);
    return value;
  }

  getKeyByValue(values, value) {
    var key = '';
    for (var i = 0; i < values.length; i++) {
      var oneValue = values[i];
      if (value == oneValue) {
        key = loaiNhaDatKeys[i];
        break;
      }
    }
    // console.log(key);
    return key;
  }

}

export default connect(mapStateToProps, mapDispatchToProps)(PropertyTypesWTo);



// Later on in your styles..
var myStyles = StyleSheet.create({
  fullWidthContainer: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: 'white'
  },
  choiceList: {
    paddingTop: 10,
    paddingLeft: 26,
    paddingRight: 0
  },
  searchButton: {
    alignItems: 'stretch',
    justifyContent: 'flex-end'
  },
  searchButtonWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: gui.mainColor,
    height: 44
  },
  searchButtonText: {
    marginLeft: 17,
    marginRight: 17,
    marginTop: 10,
    marginBottom: 10,
    color: 'white',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  headerSeparator: {
    marginTop: 0,
    borderTopWidth: 1,
    borderTopColor: gui.separatorLine
  },
  search: {
    top: 0,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
  },
  customPageHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    backgroundColor: '#fff',
    height: 60
  },
  backButton: {
    marginTop: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    paddingLeft: 18,
    paddingRight: 18
  },
  customPageTitle: {
    left: 36,
    right: 36,
    marginTop: 31,
    marginBottom: 10,
    position: 'absolute'
  },
  customPageTitleText: {
    color: gui.mainTextColor,
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    textAlign: 'center'
  },
  viewHuy: {
    position: 'absolute',
    right: 0,
    width: 60,
    backgroundColor: '#fff',
    alignItems: 'center',
    marginTop: 31
  },
  viewPlusPost: {
      height: 35,
      width: 35,
      justifyContent: 'flex-end',
      alignItems: 'flex-start',
      // paddingRight: 21,
      marginTop: 22,
      marginLeft: 16
  },
});

