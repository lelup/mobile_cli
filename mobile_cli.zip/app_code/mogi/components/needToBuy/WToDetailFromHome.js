'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as registerActions from '../../reducers/register/registerActions';

import {Map} from 'immutable';

import gui from '../../lib/gui';

import React, {Component} from 'react';

import { Text, View, Navigator, TouchableOpacity, InteractionManager, TouchableHighlight, Alert
    , SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS, TextInput, Image, Switch } from 'react-native'

import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon'
import RelandIcon from '../RelandIcon';

import RangeUtils from "../../lib/RangeUtils"

import DanhMuc from "../../assets/DanhMuc"

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import placeUtil from '../../lib/PlaceUtil';

import GiftedSpinner from 'react-native-gifted-spinner';

import SearchResultDetailFooter from '../detail/SearchResultDetailFooter';

import CommonUtils from '../../lib/CommonUtils';

import Communications from '../detail/MCommunications';

import utils from '../../lib/utils';

import log from '../../lib/logUtil';

var {width, height} = utils.getDimensions();
var mapWidth = width-30;
var mapHeight = (width-width%2)/2+3;

var imgHeight = 181;

var Analytics = require('react-native-firebase-analytics');

import MMessage from '../message/MMessage';

import cfg from "../../cfg";

const actions = [
    globalActions,
    needToBuyActions,
    adsMgmtActions,
    searchActions,
    chatActions,
    registerActions
];

const ONE_MILLION = 1000000.0;

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class WToDetailFromHome extends Component {
    constructor(props) {
        super(props);

        this.state = {
            wts: props.wts,
            isChatLoading: false,
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null
        };
    }
    //
    // componentWillMount() {
    //     setTimeout(() => this._fetchWTSData(), 300);
    // }
    //
    // _fetchWTSData() {
    //     let wtsID = this.props.wtsID;
    //     this.props.actions.getWTSDetail(wtsID).then(
    //         (res) => this.setState({
    //             wts: res.wts,
    //             loading: false
    //         })
    //     );
    // }

    renderLoadingView() {
        return (
            <View style={[myStyles.searchFilter, myStyles.styleLoadingView]}>
                <GiftedSpinner size='large' color='gray' />
            </View>
        )
    }

    renderWToBody() {
        return (
            <View style={[myStyles.searchFilter, {top: 64}]}>
                <ScrollView style={[myStyles.searchFilter, {top: 0, height: height-108}]}
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="on-drag"
                    ref='scroll'>
                    {this._renderCover()}
                    {this._renderChiTietWTo()}
                    {this._renderPreferenceView()}
                    <FullLine />
                    <View style={myStyles.searchSectionTitle}>
                        <Text style={myStyles.cacDieuKienText}>
                            Ghi chú
                        </Text>
                    </View>
                    {this._renderGhiChu()}
                </ScrollView>
            </View>
        );
    }

    _renderGhiChu() {
        let wts = this.state.wts;
        let ghiChu = wts && wts.noiDung || '';
        return (
            <View style={[myStyles.searchFilterAttribute, {paddingBottom: 20}]}>
                <ScalableText style={myStyles.ghiChuItem}>{ghiChu}</ScalableText>
            </View>
        )
    }

    _renderPreferenceView() {
        if (!this._isThuTucMienPhi() && !this._isDeLaiDoTrongNha()) {
            return null;
        }
        return (
            <View style={myStyles.preferenceView} pointerEvents="none" >
                <FullLine />
                <View style={myStyles.searchSectionTitle}>
                    <Text style={myStyles.cacDieuKienText}>
                        NHỮNG ƯU ĐÃI
                    </Text>
                </View>
                <FullLine />
                {/*this._renderGiamGia()*/}
                {this._renderThuTucMienPhi()}
                {this._renderDeLaiDoTrongNha()}
            </View>
        );
    }

    _renderGiamGia() {
        let wts = this.state.wts;
        let giaGiam = wts && wts.giaGiam;
        let soTienGiamGia = giaGiam ? utils.addCommas(giaGiam*ONE_MILLION) : '0';
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={myStyles.preferenceSubView1}>
                    <Text style={[myStyles.label, {marginLeft: 17}]}>Giảm giá</Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {height: 28}]}>
                    <ScalableText style={[myStyles.input, {width: width/2+15, textAlign: 'left', color: '#6E6F73'}]}>
                        {soTienGiamGia}
                    </ScalableText>
                </View>
                <View style={myStyles.priceUnitView}>
                    <Text style={myStyles.label}>{DanhMuc.VND}</Text>
                </View>
            </View>
        );
    }

    _onValueChange(key, value) {
        let newState = {};
        newState[key] = value;
        this.setState(newState);
    }

    _renderThuTucMienPhi() {
        if (!this._isThuTucMienPhi()) {
            return null;
        }
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={[myStyles.preferenceSubView1, {width: width/2}]}>
                    <Text style={[myStyles.label, {marginLeft: 17}]}>
                        Bao sang tên
                    </Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {justifyContent: 'flex-end', width: width/2-10, paddingRight: 10}]}>
                    {/*<Switch
                        onValueChange={(value) => this._onValueChange('thuTucMienPhi', value)}
                        value={this._isThuTucMienPhi()} />*/}
                    <RelandIcon name={'check-icon'} color={'#27AB5F'} mainProps={{flexDirection: 'row'}}
                                size={22} textProps={{paddingLeft: 20}}
                                noAction={true} />
                </View>
            </View>
        );
    }

    _isThuTucMienPhi() {
        let wts = this.state.wts;
        return wts && wts.baoSangTen;
    }

    _renderDeLaiDoTrongNha() {
        if (!this._isDeLaiDoTrongNha()) {
            return null;
        }
        return (
            <View style={myStyles.preferenceSubView}>
                <View style={[myStyles.preferenceSubView1, {width: width/2}]}>
                    <Text style={[myStyles.label, {marginLeft: 17}]}>
                        Để lại đồ trong nhà
                    </Text>
                </View>
                <View style={[myStyles.preferenceSubView2, {justifyContent: 'flex-end', width: width/2-10, paddingRight: 10}]}>
                    {/*<Switch
                        onValueChange={(value) => this._onValueChange('deLaiDoTrongNha', value)}
                        value={this._isDeLaiDoTrongNha()} />*/}
                    <RelandIcon name={'check-icon'} color={'#27AB5F'} mainProps={{flexDirection: 'row'}}
                                size={22} textProps={{paddingLeft: 20}}
                                noAction={true} />
                </View>
            </View>
        );
    }

    _isDeLaiDoTrongNha() {
        let wts = this.state.wts;
        return wts && wts.deLaiDoDac;
    }

    _renderCover() {
        let wts = this.state.wts;
        let rowData = wts && wts.ads;
        if(!rowData) {
            return null;
        }
        let imageUriHome = rowData.image && rowData.image.cover ? {uri: rowData.image.cover} : null;
        if (!imageUriHome) {
            imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
        }
        let imagePreviewAction = this._onImagePreviewPressed.bind(this);
        return (
            <View style={{backgroundColor: 'white', height: imgHeight, width: width}}>
                <TouchableHighlight onPress={imagePreviewAction} underlayColor="transparent" >
                    <Image style={myStyles.imgItem}
                           source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()} />
                </TouchableHighlight>
            </View>
        )
    }

    _onImagePreviewPressed() {
        let wts = this.state.wts;
        let rowData = wts && wts.ads;
        if(!rowData) {
            return;
        }
        Actions.SearchResultDetail({adsID: rowData.adsID, source: 'server', imageDetail: rowData.image.cover})
    }

    render() {
        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={myStyles.mainView}>
                    {this.state.loading ? this.renderLoadingView() : this.renderWToBody()}
                </View>

                {this._renderFooter()}

                {this._renderMessageItem()}

                {this._renderHeaderAds()}
            </View>
        );
    }

    _renderFooter() {
        let wts = this.state.wts;
        let rowData = wts && wts.ads;
        if (!rowData) {
            return null;
        }
        rowData.adsID = wts.adsID;
        let mobile = rowData.lienHe && rowData.lienHe.phone ? rowData.lienHe.phone : '';
        let isLiked = false;
        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            let adsLikes = currentUser && currentUser.adsLikes;
            userID = currentUser && currentUser.userID;
            isLiked = rowData && adsLikes && adsLikes.indexOf(rowData.adsID) > -1;
        }
        return (
            <SearchResultDetailFooter mobile={mobile} onChat={() => this._onChat(rowData)} userID={userID} deviceID={deviceID}
                                      isLiked={isLiked} ads={rowData} loggedIn={this.props.global.loggedIn}
                                      likeAds={this.props.actions.likeAds}
                                      unlikeAds={this.props.actions.unlikeAds}
                                      updateMessageProcessing={this._updateMessageProcessing.bind(this)}
                                      isChatLoading={this.state.isChatLoading}
                                      isLikeAdsLoading={this.props.search.uploadingLikedAds.uploading} />
        );
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
    }

    _renderMessageItem() {
        let textValue = this.state.textMessage;
        if (textValue == '' || this.state.msgType == '') {
            return null;
        }
        return (
            <MMessage mainStyle={{top: 64}}
                      hideStatus={this.state.msgType == 'fadeInDown'}
                // barStyle="light-content"
                      animation={this.state.msgType}
                      duration={500}
                      onAnimationEnd={this._onAnimationEnd.bind(this)}
                      textValue={textValue}
                      bgColor={this.state.msgBgColor}
                      textColor={this.state.msgTextColor}/>
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({textMessage: '', msgType: ''})}, 2000);
        }
    }

    _onChat(ads) {
        if (!ads || !ads.dangBoi) {
            return;
        }
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (ads.dangBoi.userID == this.props.global.currentUser.userID) {
                Alert.alert('Thông báo', gui.ERR_NotAllowChatYourSelf);
                return;
            }

            this._beginChatLoading();

            let partner = {
                phone: ads.dangBoi.phone || undefined,
                email: ads.dangBoi.email || undefined,
                fullName : ads.dangBoi.name  || undefined
            };

            let relatedToAds = {
                adsID : ads.id||ads.adsID,
                loaiNhaDatFmt : utils.getLoaiNhaDatFmt(ads),
                giaFmt : utils.getPriceDisplay(ads.gia, ads.loaiTin),
                diaChinhFullName : ads.place.diaChi,
                cover : ads.image.cover,
                loaiTin: ads.loaiTin,
                dienTichFmt: utils.getDienTichDisplay(ads.dienTich),
                loaiNhaDat: ads.loaiNhaDat,
                dangBoi: ads.dangBoi
            };

            if (!ads.dangBoi.userID){
                this.props.actions.registerTempUser(partner). then ((e) => {
                    if (e.status == 0){
                        partner.userID = e.res.userID;
                        partner.active = e.res.active;
                        this.props.actions.startChat(this.props.global.currentUser, partner, relatedToAds)
                            .then( () => {
                                this._doChatPress(partner, relatedToAds);
                            });
                    } else {
                        if (ads.dangBoi.phone && ads.dangBoi.phone.length >0){
                            let bodyText = this._createTextMessage(ads);
                            this._onSms(ads.dangBoi.phone, bodyText);
                            return;
                        }
                        Alert.alert('Thông báo', gui.ERR_NotRelandUser);
                    }
                });
            } else {
                partner.userID = ads.dangBoi.userID;

                this.props.actions.startChat(this.props.global.currentUser, partner, relatedToAds)
                    .then( () => {
                        this._doChatPress(partner, relatedToAds);
                    });
            }
        }
    }

    _beginChatLoading() {
        this.setState({isChatLoading: true});
    }

    _endChatLoading() {
        this.setState({isChatLoading: false});
    }

    _createTextMessage(ads) {
        let loaiTin = DanhMuc.getLoaiTinValue(ads.loaiTin).toLowerCase();
        let bodyText = `Mình thấy bạn đang rao ${loaiTin} nhà ở đây `;
        let linkAds = cfg.serverUrl + '/web/detail/' + ads.adsID;
        bodyText += linkAds;
        bodyText += `. Nhà đã ${loaiTin} chưa bạn? Bạn là chủ hay môi giới thế ?`;
        return bodyText;
    }

    _onSms(phone, bodyText) {
        if (!phone) {
            return;
        }
        Communications.text(phone, bodyText);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        let wts = this.state.wts;
        let adsID = wts && wts.adsID;
        Analytics.logEvent('DETAIL_SENDSMS', {deviceID: deviceID, userID: userID, adsID: adsID, phone: phone});
    }

    _doChatPress(partner, relatedToAds) {
        Actions.Chat();
        this._endChatLoading();
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('DETAIL_CHAT', {deviceID: deviceID, userID: userID, partner: partner, relatedToAds: relatedToAds});
    }

    _renderChiTietWTo() {
        let wts = this.state.wts;
        let rowData = wts && wts.ads;
        if (!rowData) {
            return null;
        }
        let loaiTinVal = rowData.loaiTin;
        let loaiNhaDat = loaiTinVal ? DanhMuc.LoaiNhaDatThue[rowData.loaiNhaDat] :  DanhMuc.LoaiNhaDatBan[rowData.loaiNhaDat];
        let diaChi = rowData.place.diaChi;

        let dacDiemValues = [];
        dacDiemValues.push(loaiNhaDat);

        let dienTich = utils.getDienTichDisplay(rowData.dienTich);
        if (dienTich == 'Không rõ') {
            dienTich = '';
        }
        if (dienTich) {
            dacDiemValues.push(dienTich);
        }

        let giaGiam = wts && wts.giaGiam;
        let gia = utils.getPriceDisplay(rowData.gia, loaiTinVal);
        let giaDaGiam = giaGiam ? utils.getPriceDisplay(rowData.gia-giaGiam, loaiTinVal) : '';
        let giaStyle = {marginLeft: 5};
        if (giaGiam) {
            giaStyle = {marginLeft: 5,
                textDecorationLine: 'line-through', color: '#C7C8CA'};
        }
        let giaLabel = 'Giá: ';

        let soTang = rowData.soTang;
        if (soTang) {
            soTang = soTang + ' tầng';
            dacDiemValues.push(soTang);
        }

        let soPhongTamVal = rowData.soPhongTam;
        let soPhongTam = soPhongTamVal;
        if (soPhongTam) {
            soPhongTam = soPhongTam + ' phòng tắm';
            dacDiemValues.push(soPhongTam);
        }

        let soPhongNguVal = rowData.soPhongNgu;
        let soPhongNgu = soPhongNguVal;
        if (soPhongNgu) {
            soPhongNgu = soPhongNgu + ' phòng ngủ';
        }
        if (soPhongNgu) {
            dacDiemValues.push(soPhongNgu);
        }

        let huongNha = DanhMuc.HuongNha[rowData.huongNha];
        let huongNhaText = '';
        if (rowData.huongNha && rowData.huongNha != '-1') {
            huongNhaText = "Hướng " + huongNha;
        }
        if (huongNhaText) {
            dacDiemValues.push(huongNhaText);
        }

        let soNgayDaDangTin = rowData.soNgayDaDangTinFmt;
        if (soNgayDaDangTin) {
            dacDiemValues.push(soNgayDaDangTin);
        }

        let dacDiemItems = [];
        for (let i = 0; i<dacDiemValues.length; i = i+2) {
            let one = dacDiemValues[i];
            let other = '';
            if (i < dacDiemValues.length-1) {
                other = dacDiemValues[i+1];
            }
            let item = this.renderTwoNormalProps(one, other, {marginTop: 11}, {marginTop: 4, marginBottom: 4}, 'prop_' + i);
            dacDiemItems.push(item);
        }

        return (
            <View style={myStyles.chiTietView}>
                <View style={myStyles.chiTietSubView1}>
                    <View style={{flexDirection: 'row'}}>
                        <Text style={myStyles.priceItem}>{giaLabel}</Text>
                        <Text style={[myStyles.priceItem, giaStyle]}>{gia}</Text>
                        <Text style={[myStyles.priceItem, {marginLeft: 15}]}>{giaDaGiam}</Text>
                    </View>
                    <ScalableText style={[myStyles.diaChiItem, {marginTop: 5, marginBottom: 10}]}>{diaChi}</ScalableText>
                    {dacDiemItems.length > 0 ? <FullLine style={{marginBottom: 4}} /> : null}
                    {dacDiemItems}
                </View>
            </View>
        );
    }

    renderTwoNormalProps(prop1, prop2, dotStyle, textStyle, key) {
        if (prop1 || prop2) {
            let dotIcon1Style = prop1 ? {} : {backgroundColor: 'transparent'};
            let dotIcon2Style = prop2 ? {} : {backgroundColor: 'transparent'};
            return (
                <View key={key} style={[myStyles.searchDetailRowAlign]}>
                    <View style={{flexDirection: 'row'}}>
                        <View style={[myStyles.dot2, dotIcon1Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop1}
                        </Text>
                    </View>
                    <View style={{flexDirection: 'row', marginLeft: 10}}>
                        <View style={[myStyles.dot2, dotIcon2Style, dotStyle]} />
                        <Text style={[myStyles.textHalfWidth, textStyle]}>
                            {prop2}
                        </Text>
                    </View>
                </View>
            )
        }
    }

    _renderHeaderAds() {
        return (
            <View style={myStyles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this.onCancel()}
                    style={myStyles.backButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={myStyles.viewTitleHeader}>
                    <ScalableText style={[myStyles.textHeader, {fontWeight: '500', fontSize: 17}]}>
                        Chi tiết tin bán gấp
                    </ScalableText>
                </View>
                <View
                    style={myStyles.viewRightHeader}>
                </View>
            </View>
        );
    }

    onCancel() {
        Actions.pop();
    }
}

/**
 * ## Styles
 */
var myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        width: width,
        height: 64
    },

    searchButton: {
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        top: height -44 ,
        height: 44,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: '#E83522',
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 11,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    searchMoreFilterButton: {
        flexGrow: 0.5,
        alignItems: 'stretch',
        justifyContent: 'center'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchResetText: {
        color: 'red',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    searchAttributeLabel : {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        color: 'black'
    },
    searchAttributeValue : {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.arrowColor,
        marginRight: 3
    },
    searchFilterButton: {
        flexDirection: 'column'
    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchSectionTitle: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingRight: 8,
        paddingLeft: 17,
        paddingTop: 28,
        paddingBottom: 8,
        // borderTopWidth: 1,
        // borderTopColor: '#f8f8f8',
        backgroundColor: '#f8f8f8'
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection:"column"
        //borderWidth:1,
        //borderColor: "green"
    },
    scrollView: {
        flex: 1,
        height: height-123
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent :'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute3: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 10,
        paddingLeft: 17,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 0,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt3: {
        flexDirection : "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent :'space-between',
        paddingTop: 12,
        paddingLeft: 17,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    addViewBottom: {
        height:30,
        width:width,
        backgroundColor:'#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewTitleHeader:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    searchDiaChinhView: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    diaChinhSubView: {
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'column'
    },
    diaChinhTouchable: {
        padding: 4,
        paddingLeft: 10,
        height: 38,
        marginLeft: 0,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    diaChinhText: {
        fontSize: 15,
        color: '#9fa0a4',
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    locationIcon: {
        backgroundColor:'white',
        height:25,
        width:25,
        marginRight:4,
        justifyContent:'center',
        alignItems:'center'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width-30,
        height: 60
    },
    textInputView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    textInputView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/3-5,
        marginTop: 10,
        marginBottom: 10
    },
    input: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width/3-5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    dangBoiView: {
        flex: 1,
        flexDirection: 'row'
    },
    avatarView: {
        height: 90,
        width: 90,
        padding: 15
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    userInfoView: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 15
    },
    fullNameText: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    ngayDangText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        flex: 1,
        height: 10,
        backgroundColor: '#F0F0F2'
    },
    chiTietView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15
    },
    chiTietSubView1: {
        flex: 1
    },
    chiTietSubView2: {
        flex: 1,
        paddingBottom: 15
    },
    chiTietTitleItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 5
    },
    ghiChuItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#6E6F73',
        fontFamily: gui.fontFamily
    },
    priceItem: {
        fontSize: gui.normalFontSize,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#1E94D6',
        fontFamily: gui.fontFamily,
        paddingTop: 5
    },
    attributeView: {
        flex: 1,
        flexDirection: 'row',
        paddingTop: 5,
        alignItems: 'center'
    },
    diaChiItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    viTriView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15,
        paddingBottom: 15
    },
    titleViTriItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    hintViTriItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 15
    },
    miniMapItem: {
        width: mapWidth,
        height: mapHeight
    },
    shareView: {
        flex: 1,
        paddingTop: 15,
        paddingLeft: 15,
        paddingRight: 15
    },
    titleShareItem: {
        fontSize: gui.normalFontSize,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    hintShareItem: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily,
        paddingBottom: 15
    },
    sharedButtonsView: {
        flex: 1,
        flexDirection: 'row',
        paddingBottom: 15
    },
    circleContainer: {
        marginTop: 0,
        marginBottom: 0,
        marginRight: 10,
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: '#A8A8A8'
    },
    circleContainer2: {
        marginTop: -7,
        marginBottom: 0,
        marginRight: 10,
        backgroundColor: '#A8A8A8'
    },
    shareIcon: {
        marginTop: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    searchDetailRowAlign: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-around',
    },
    dot2 : {
        width: 5,
        height: 5,
        borderRadius: 2.5,
        marginTop: 11,
        marginLeft: 20,
        marginRight: 0,
        backgroundColor: '#C1C1C1'
    },
    textHalfWidth: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: 'black',
        marginTop: 3,
        marginBottom: 4,
        marginLeft: 5,
        marginRight: 10,
        width: width/2-20
    },
    mainView: {
        flexGrow: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor : "transparent"
    },
    imgItem: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: imgHeight,
        alignSelf: 'auto'
    },
    preferenceView: {
        flex: 1
    },
    preferenceSubView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    preferenceSubView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        marginRight: 10
    },
    preferenceSubView2: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width/2+15,
        marginTop: 10,
        marginBottom: 10
    },
    priceUnitView: {
        flex: 1,
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10
    },
    styleLoadingView: {
        top: 64,
        height: height-64,
        alignItems: 'flex-start',
        justifyContent: 'flex-start'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(WToDetailFromHome);
