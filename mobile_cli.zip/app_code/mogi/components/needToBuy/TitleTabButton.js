import React, {Component} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';
import utils from '../../lib/utils';

var {width} = utils.getDimensions();

export default class TitleTabButton extends React.Component {
  render() {
    var selected = this.props.selected;
    var myStyle = selected? 'buttonTextSelected' : 'buttonText';
    var mainStyle = selected? 'wrapperSelected' : 'wrapper';
    return (
      <TouchableOpacity
          onPress={() => this.props.onPress(this.props.name)}>
        <View style={[styles.mainView, styles[mainStyle], this.props.mainProps]}>
            <ScalableText style={styles[myStyle]} >
              {this.props.children}
            </ScalableText>
        </View>
      </TouchableOpacity>
    );
  }
}


var styles = StyleSheet.create({
  lineunder: {
    flexGrow: 1,
    borderBottomColor: gui.mainColor, 
   
    borderStyle: "solid", 
    //width: 60, 
    height: 3, 
    marginLeft: 5,
    marginRight: 5

  },

  mainView: {
    flexGrow: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    // borderWidth: 1,
    // borderRadius: 5,
    margin: 10,
    width: width/2 - 25
  },

  wrapper: {
    backgroundColor: 'white',
    borderColor: gui.mainColor
  },

  wrapperSelected: {
    backgroundColor: gui.mainColor,
    borderColor: gui.mainColor
  },

  buttonText: {
    flexGrow: 1,
    alignSelf:'center',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    padding: 5,
    color: gui.mainColor,
    fontWeight : 'normal'
  },

  buttonTextSelected: {
    flexGrow: 1,
    alignSelf:'center',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    padding: 5,
    color: 'white',
    fontWeight : 'bold'
  }
});