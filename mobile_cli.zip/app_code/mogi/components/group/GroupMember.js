import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableHighlight,
    Alert
} from 'react-native';

import FontAwesomeLight from '../font/FontAwesomeLight';
import { Actions } from 'react-native-router-flux';
import OfflineBar from '../line/OfflineBar';
import { Map } from 'immutable';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import Toast, { DURATION } from '../toast/Toast';
import Modal from 'react-native-modalbox';
import FunctionModal from '../FunctionModal'
import Communications from 'react-native-communications';
var Analytics = require('react-native-firebase-analytics');
import UserModal from '../UserModal';

import userApi from '../../lib/userApi';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as chatActions from '../../reducers/chat/chatActions';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

const actions = [
    globalActions,
    meActions,
    groupActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_groupRequest = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

let { width, height } = utils.getDimensions();

class GroupMember extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            searchText: '',
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null,
            loaded: false,
            isOpenMoreModal: false,
            selectedMember: null,
            isModalContent: false,
            dataContent: null
        }
    }

    componentWillMount() {
        // this.fetchData(this.props)
        // setTimeout(() => this.fetchData(this.props), 300);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.groupID !== this.props.groupID) {
            this.fetchData(nextProps);
        }
    }

    fetchData(props) {
        this.props.actions.getAllMember(
            { 'groupID': props.groupID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
                this.refreshRowData(res.data)
            }
            , (error) => {
                this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });

    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'memberList': data,
            loaded: true
        });

    }

    render() {
        let groupData = this.props.groupData;
        let dataForRender = [];
        this.props.group.memberList.forEach((e) => {
            if (e.member != groupData.userID)
                dataForRender.push(e);
        })
        let extRowItem = (
            dataForRender.length == 0 ? <View>
                {this.renderSection("CHỦ SÀN")}
                {this._renderRowAdmin()}
            </View> : null
        )
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this.renderHeaderMember()}
                <ScrollView
                    automaticallyAdjustContentInsets={false}
                    showsVerticalScrollIndicator={false}
                    vertical={true}
                    style={styles.scrollView}>
                    {extRowItem}
                    {this._renderMemberList()}
                </ScrollView>
                {this._openMoreModal()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
                {this._openModalDetail()}
            </View>
        );
    }

    _openModalDetail() {
        return (
            <Modal isOpen={this.state.isModalContent}
                onClosed={this.outModalDetail.bind(this)}
                style={styles.viewModalDetail}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                <UserModal groupName={this.props.groupData && this.props.groupData.name ? this.props.groupData.name : ''}
                    data={this.state.dataContent}
                    onClosePress={this.outModalContent.bind(this)} />
                {/*{this.renderContent()}*/}
            </Modal>
        );
    }

    outModalDetail() {
        this.setState({
            isModalContent: false,
            dataContent: null
        })
    }

    /*renderContent() {
    //TODO: replaced by UserModal, need to remove this function
        let data = this.state.dataContent;
        if(!data){
            return;
        }
        let imgUrl = data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }

        let phone = data.phone || data.phoneChuSan || data.username;
        let phoneNumber = Number(phone);
        let name = data.fullName || data.fullNameChuSan;
        let approveTime = data.approveTime || data.timeModified;
        let timeJoined = ` từ ${utils.getDiffTime(approveTime)}`;
        let groupName = ` ${this.props.groupName}`;
        return(
            <View style={styles.viewDetailContent}>
                <View style={styles.modalAvatar}>
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsDetailCover} />
                </View>
                <Text style={[styles.headerText2, {color: gui.textAgentSolid, marginTop: 16, marginBottom: 2}]}>{name}</Text>
                <Text style={[styles.textNameAvatar, {textAlign: 'center'}]}>
                    Thành viên của
                    <Text style={[styles.textNameAvatar, {fontWeight: '500', textAlign: 'center'}]}>{groupName}</Text>{timeJoined}</Text>
                <Text style={[styles.textNameAvatar, {color: gui.textAgentSolid, marginTop: 10}]}>{phone}</Text>

                <View style={[styles.lineHorizontal, {marginTop: 10}]} />
                <View style={styles.viewButtonModalContent}>
                    <View style={styles.viewButtonModalDetail}>
                        <TouchableOpacity style={[styles.viewCallButton, {backgroundColor: 'rgba(49,207,100,1)'}]}
                                          onPress={this.onPhoneDetail.bind(this, phoneNumber)}
                        >
                            <FontAwesomeLight name="phone" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                            <Text style={[styles.textChatStyle, {marginLeft: 4}]}>Gọi điện</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.viewCallButton, {marginLeft: 10}]}
                                          onPress={this.onChat.bind(this, data)}
                        >
                            <FontAwesomeLight name="comment-dots" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                            <Text style={[styles.textChatStyle, {marginLeft: 4}]}>Chat</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={styles.lineHorizontal} />
                <TouchableOpacity style={styles.viewCloseButton}
                                  onPress={this.outModalContent.bind(this)}
                >
                    <Text style={[styles.textTopPattern, {color: 'rgba(237,28,36,1)'}]}>Đóng</Text>
                </TouchableOpacity>
            </View>
        )
    }*/

    onLogEvent(title, componentType) {
        let eventDto = {
            scene: "GroupMember",
            parentScene: undefined,  //truyen owner neu co
            componentType: componentType,
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,            
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    outModalContent() {
        this.setState({
            isModalContent: false
        })
    }

    _onMoreButtonPress(data) {
        let groupData = this.props.groupData;
        let userID = this.props.global.currentUser.userID;

        if (userID != groupData.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Tính năng này chỉ dành cho chủ sàn', DURATION.LENGTH_LONG);
        } else {
            this.setState({ selectedMember: data, isOpenMoreModal: true });
        }
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {

        let items = [
            { _text: 'Xoá khỏi sàn', _function: () => this._onLeaveGroupPress() },            
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outMoreModal.bind(this)} />
        )
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn xoá thành viên khỏi sàn ?');
    }

    _doLeaveOrCall(title) {
        let selectedMember = this.state.selectedMember;
        if (!selectedMember) {
            return;
        }
        if (this.props.global.currentUser.userID != this.props.groupData.userID) {
            Alert.alert('Thông báo', 'Bạn không phải là quản trị của sàn \'' + this.props.groupData.name + '\' ?');
            this._outMoreModal();
            return;
        }
        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = this.props.groupID;
                    let groupData = this.props.groupData;
                    let userID = selectedMember.member;
                    let admin = this.props.groupData.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.kickMember({ groupID: groupID, groupData: groupData, userID: userID, admin: admin }, token);
                    this._outMoreModal();
                }
            }
            ]);
    }

    renderHeaderMember() {
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let userID = this.props.global.currentUser.userID;
        let listDaThamGia = listRelatedGroup.filter((one) => {
            return one.joinStatus == 2
        }) || [];
        let isMember = false;
        if (listDaThamGia.filter((e) => { return e.groupID == this.props.groupID }).length > 0)
            isMember = true;
        return (
            <View style={styles.viewHeaderMember}>
                <TouchableOpacity style={styles.viewBackButton}
                    onPress={this._onCancelClicked.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewHeaderContent}>
                    <Text style={[styles.headerText]}>Thành viên</Text>
                </View>
                {isMember ?
                    <TouchableOpacity style={styles.viewPlusButton}
                        onPress={this._onAddMemberPress.bind(this)}
                    >
                        <FontAwesomeLight name="plus" size={24} color={gui.mainColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>
                    : null}
            </View>
        )
    }

    renderSection(title) {
        return (
            <View style={styles.viewSection}>
                <Text style={styles.textTitle}>{title}</Text>
            </View>
        )
    }

    _onCancelClicked() {
        Actions.pop();
    }

    _onAddMemberPress() {
        Actions.InviteFriends({ groupData: this.props.groupData, groupID: this.props.groupID });
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    onDetailContent(data) {
        this.onLogEvent('Xem chi tiết','listItem')
        this.setState({
            isModalContent: true,
            dataContent: data
        })
    }

    _renderMemberList() {
        let groupData = this.props.groupData;
        let dataForRender = [];
        this.props.group.memberList.forEach((e) => {
            if (e.member != groupData.userID)
                dataForRender.push(e);
        })
        let dsRequest = ds_groupRequest.cloneWithRows(dataForRender);
        return (
            <View style={{ flex: 1 }}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsRequest}
                    renderRow={(rowData, sectionID, rowID) => this._renderRowMember(rowData, (rowID == 0))}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowMember(data, isFirstRow) {
        let imgUrl = data.thumbnail //|| data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }

        let member = data.fullName;
        let phone = data.phone;
        let approveTime = data.approveTime;

        let extControl = null;
        if (isFirstRow) {
            extControl = <View>
                {this.renderSection("CHỦ SÀN")}
                {this._renderRowAdmin()}
                {this.renderSection("THÀNH VIÊN")}
            </View>
        }
        return (
            <View style={styles.viewRowContent}
            >
                {extControl}
                <View>
                    <TouchableOpacity style={styles.viewContent}
                        onPress={this.onDetailContent.bind(this, data)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageGroup}
                            defaultSource={defaultCover}
                            style={styles.adsCover} />
                        <View style={styles.viewBodyContent}>
                            <View style={styles.viewNameGroup}>
                                <Text style={[styles.textNameGroup, { marginLeft: 8 }]} numberOfLines={1}>{member}</Text>
                            </View>
                            <View style={styles.viewTimeGroup}>
                                <Text style={[styles.textNameAvatar, { marginLeft: 8 }]}>Tham gia {utils.getDiffTime(approveTime)}</Text>
                            </View>
                        </View>
                        <TouchableOpacity style={styles.approve}
                            onPress={this.onPhoneDetail.bind(this, phone)}>
                            <FontAwesomeLight name="phone" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.reject}
                            onPress={this.onChat.bind(this, data)}>
                            <FontAwesomeLight name="comment-dots" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                        {this.renderRemoveUser(data)}
                    </TouchableOpacity>
                    <FullLine />
                </View>
            </View>
        )
    }

    renderRemoveUser(data) {
        let groupData = this.props.groupData;
        let userID = this.props.global.currentUser.userID;

        if (userID == groupData.userID) {
            return (
                <TouchableOpacity style={[styles.reject, { marginLeft: 5 }]}
                    onPress={this._onMoreButtonPress.bind(this, data)}>
                    <FontAwesomeLight name="ellipsis-v-alt" size={20} color={'rgba(111,111,111,1)'} noAction={true} iconOnly={true} />
                </TouchableOpacity>
            )
        } else return null;
    }

    _renderRowAdmin() {
        let data = this.props.groupData;        
        let imgUrl = data.thumbnailAvatar //|| data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }

        let member = data.fullNameChuSan;
        let phone = data.phoneChuSan;

        return (
            <View style={styles.viewRowContent}>
                <TouchableOpacity style={styles.viewContent}
                    onPress={this.onDetailContent.bind(this, data)}
                >
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsCover} />
                    <View style={styles.viewBodyContent}>
                        <View style={styles.viewNameGroup}>
                            <Text style={[styles.textNameGroup, { marginLeft: 8 }]} numberOfLines={1}>{member}</Text>
                        </View>
                        <View style={styles.viewTimeGroup}>
                            <Text style={[styles.textNameAvatar, { marginLeft: 8 }]}>{phone}</Text>
                        </View>
                    </View>
                    <TouchableOpacity style={styles.approve}
                        onPress={this.onPhoneDetail.bind(this, phone)}>
                        <FontAwesomeLight name="phone" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.reject}
                        onPress={this.onChat.bind(this, data)}
                    >
                        <FontAwesomeLight name="comment-dots" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>
                </TouchableOpacity>
            </View>
        )
    }

    onChat(data) {
        this.onLogEvent('Chat','button')
        let partner = data.userID ? { userID: data.userID } : { userID: data.member };
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');
        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);            
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
                this.setState({
                    isloadingPressRow: false
                })
            });
    }

    onPhoneDetail(phone) {
        if (!phone) {
            return;
        }
        this.onLogEvent('Gọi điện','button')
        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(phone, true);
        Analytics.logEvent('GROUPMEMBER_USER_DIALING', { deviceID: deviceID, userID: userID, phone: phone });
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        flex: 1,
        backgroundColor: '#fff',
        paddingBottom: 50
    },
    textTopPattern: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontSize: 15
    },
    viewContent: {
        width: width - 32,
        height: 60,
        marginTop: 10,
        marginBottom: 10,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row',
    },
    adsCover: {
        width: 60,
        height: 60,
        marginLeft: 0,
        borderRadius: 30
    },
    viewBodyContent: {
        backgroundColor: 'transparent',
        height: 48,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginRight: 6
    },
    viewNameGroup: {
        backgroundColor: 'transparent',
        height: 24,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeGroup: {
        backgroundColor: 'transparent',
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textShare,
        fontWeight: 'normal'
    },
    textMessage: {
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        fontSize: 12
    },
    viewRowContent: {
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent'
    },
    viewListContainer: {
        paddingBottom: 50
    },
    viewHeaderMember: {
        width: width,
        height: 64,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewPlusButton: {
        width: 60,
        height: 64,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16,
        paddingTop: gui.marginTopAgent
    },
    viewBackButton: {
        width: 60,
        height: 64,
        justifyContent: 'center',
        paddingLeft: 16,
        paddingTop: gui.marginTopAgent
    },
    viewHeaderContent: {
        width: width - 120,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    headerView3: {
        backgroundColor: 'transparent',
        marginTop: 23,
        marginLeft: 16,
        width: width - 32,
        height: 24
    },
    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    headerText2: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    textChatStyle: {
        fontSize: 15,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#fff'
    },
    approve: {
        width: 21,
        height: 21,
        backgroundColor: 'transparent',
    },
    reject: {
        width: 21,
        height: 21,
        marginLeft: 15,
        backgroundColor: 'transparent',
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    viewSection: {
        height: 38,
        width: width,
        justifyContent: 'center',
        paddingLeft: 16,
        backgroundColor: gui.newLineFacebook
    },
    textTitle: {
        color: gui.textPostAds,
        fontSize: 13,
        fontFamily: gui.fontFamily,
    },
    viewModalDetail: {
        justifyContent: 'flex-start',
        height: 'auto',
        backgroundColor: 'transparent',
        alignItems: 'center',
    },
    viewDetailContent: {
        height: 'auto',
        width: width - 72,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderRadius: 5,
        paddingLeft: 16,
        paddingRight: 16
    },
    modalAvatar: {
        height: 76,
        width: width - 72,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 24,
        backgroundColor: '#fff'
    },
    adsDetailCover: {
        height: 74,
        width: 74,
        borderRadius: 37
    },
    viewButtonModalContent: {
        width: width - 104,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    viewButtonModalDetail: {
        width: width - 104,
        height: 54,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewCallButton: {
        height: 40,
        width: (width - 104) / 2 - 17,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        flexDirection: 'row',
        borderRadius: 20
    },
    viewCloseButton: {
        height: 44,
        width: width - 104,
        justifyContent: 'center',
        alignItems: 'center',
    },
    lineHorizontal: {
        height: 1,
        width: width - 104,
        backgroundColor: 'rgba(211,211,211,0.5)',
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupMember);