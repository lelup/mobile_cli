import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    TouchableHighlight,
    ListView,
    ScrollView,
    Alert,
    StatusBar,
    Navigator,
    InteractionManager,
    SegmentedControlIOS,
    PickerIOS,
    TextInput,
    Animated,
    Platform
} from 'react-native';

import { Actions } from 'react-native-router-flux';
import { Map } from 'immutable';
import moment from 'moment';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import DanhMuc from '../../assets/DanhMuc';
import Toast, { DURATION } from '../toast/Toast';
import Button from 'react-native-button';
import RelandIcon from '../RelandIcon';
import RangeUtils from "../../lib/RangeUtils"

import TagGroup from './TagGroup';
import MLikeTapButton3 from '../MLikeTapButton3';
import SegmentedControl from '../SegmentedControl';
import KeyboardSpacer from 'react-native-keyboard-spacer';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import DatePicker from 'react-native-datepicker';
import ScalableText from 'react-native-text';

import placeUtil from '../../lib/PlaceUtil';

import TitleTabButton from './TitleTabButton';
import CheckBoxNhuCau from './CheckBoxNhuCau';
import CheckDotNhuCau from '../detail/CheckDotNhuCau';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import FullLine from '../line/FullLine';
let { width, height } = utils.getDimensions();

import userApi from '../../lib/userApi';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    adsMgmtActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class ContactImportDetail extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
        this._firstDisplay = true;
        this._scrollViewHeight = 0;
        this._scrollContentHeight = 0;
        this._scrollToBottomOnNextRender = false;
        this._scrollToPreviousPosition = false;
        this.listViewMaxHeight = height-65;
        let { id, loaiTin, mua, thue, huongNha, dienTich, soTangSelectedIdx,
            soPhongNguSelectedIdx, soNhaTamSelectedIdx, ghiChu } = props.group.nhuCauFields;
        let { initDienTich, fromDienTich, toDienTich } = this._initDienTich();
        let { initGia, fromGia, toGia } = this._initGia(loaiTin);
        let contacts = props.contacts;
        this.state = {
            id: id,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            toggleState: false,
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            ghiChu: ghiChu,
            onCancelling: false,
            blankFromGiaColor: gui.placeholderColor,
            blankToGiaColor: gui.placeholderColor,
            blankDiaChiColor: gui.placeholderColor,
            isLoading: false,
            contactSaleState: 1,
            contactType: 1,
            isCheckNhuCau: false,
            dateStart: null,
            dateEnd: null,
            likeStatus:'hot',
            contacts: contacts,
            isExpanded: false,
            height: new Animated.Value(this.listViewMaxHeight),
            ghiChuFocus: false
        };
    }

    componentWillReceiveProps(nextProps) {
        // if (nextProps.group.contactSaleState !== this.props.group.contactSaleState) {
        //     this.setState({
        //         contactSaleState: nextProps.group.contactSaleState
        //     });
        // }
    }

    componentDidMount() {
        this.scrollResponder = this._scrollView.getScrollResponder();
    }

    componentWillUnmount() {
        StatusBar.setBarStyle('dark-content');
    }

    onKeyboardWillHide() {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight,
            duration: 150,
        }).start();
    }

    onKeyboardDidHide(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillHide(e);
        }

        this.scrollToBottom();
    }

    onKeyboardWillShow(e) {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight - e.endCoordinates.height - 40,
            duration: 200,
        }).start();
    }
    onKeyboardDidShow(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillShow(e);
        }

        setTimeout(() => {
            this.scrollToBottom();
        }, (Platform.OS === 'android' ? 200 : 100));
    }

    scrollToBottom(animated = null) {
        if (this.state.ghiChuFocus && this._scrollViewHeight && this._scrollContentHeight && this._scrollContentHeight > this._scrollViewHeight) {
            let scrollDistance = this._scrollViewHeight - this._scrollContentHeight;

            if (this.scrollResponder) {
                this.scrollResponder.scrollTo({
                    y: -scrollDistance,
                    x: 0,
                    animated: typeof animated === 'boolean' ? animated : true
                });
            }
        }
    }

    _initDienTich() {
        let { dienTich } = this.props.group.nhuCauFields;
        let initDienTich = [];
        Object.assign(initDienTich, dienTich);
        let dienTichVal = RangeUtils.dienTichRange.toValRange(initDienTich);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        return { initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich };
    }

    _initGia(loaiTin) {
        let gia = this.props.group.nhuCauFields[loaiTin].gia;
        let initGia = [];
        Object.assign(initGia, gia);
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(initGia);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        return { initGia: initGia, fromGia: fromGia, toGia: toGia };
    }

    _onLoaiTinChange(value) {
        let { initGia, fromGia, toGia } = this._initGia(value);
        this.setState({ loaiTin: value, initGia: initGia, fromGia: fromGia, toGia: toGia, showGia: false, showDienTich: false });
    }

    _onScrollGia() {
        if (this._scrollView) {
            this._scrollView.scrollTo({ y: 40 });
        }
    }

    _onScrollDienTich() {
        if (this._scrollView) {
            this._scrollView.scrollTo({ y: 90 });
        }
    }

    _onGhiChuFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + 175;
            if (this.showSoTang()) {
                scrollTo = scrollTo + 95;
            }
            if (this.showSoPhongNgu()) {
                scrollTo = scrollTo + 95;
            }
            if (this.showSoNhaTam()) {
                scrollTo = scrollTo + 95;
            }
            this._scrollView.scrollTo({ y: scrollTo });
        }
    }

    _doChangeGia(loaiTin, giaVal) {
        var parent = {};
        Object.assign(parent, this.state[loaiTin]);
        parent.gia = giaVal;
        if (loaiTin == 'mua') {
            this.setState({ mua: parent });
        } else {
            this.setState({ thue: parent });
        }
    }

    // _getLoaiNhatDatValue() {
    //     let { loaiTin } = this.state;
    //     return DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat, true).substring(0, 25);
    // }

    // _getHuongNhaValue() {
    //     var { huongNha } = this.state;
    //     if (!huongNha) {
    //         return RangeUtils.BAT_KY;
    //     }
    //     return DanhMuc.HuongNha[huongNha];
    // }

    _getLoaiNhatDatValue() {        
        let { loaiTin } = this.state;
        if (!this.state[loaiTin].loaiNhaDat || this.state[loaiTin].loaiNhaDat.length == 0 || this.state[loaiTin].loaiNhaDat[0] == 0) {
            return RangeUtils.BAT_KY;
        }
        return utils.getLoaiNhaDatText(loaiTin, this.state[loaiTin].loaiNhaDat, 20);
    }

    _getHuongNhaValue() {
        let { huongNha } = this.state;
        if (!huongNha || huongNha.length == 0 || huongNha[0] == 0) {
            return RangeUtils.BAT_KY;
        }
        return utils.getHuongNhaText(huongNha, 20);
    }

    _getHeaderTitle() {
        let { place } = this.props.group.nhuCauFields;
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    render() {
        log.info('==================>', this.state.contacts);
        let { loaiTin, blankDiaChiColor } = this.state;
        let diaChi = this._getHeaderTitle();
        let diaChiColor = (diaChi == gui.CHON_KHU_VUC) ? blankDiaChiColor : '#000';
        let styleHot = this.state.likeStatus == 'hot' ? [styles.tabStyle, { marginLeft: 0 }, styles.mainViewSelected1] : [styles.tabStyle, { marginLeft: 0 }];
        let styleWarm = this.state.likeStatus == 'warm' ? [styles.tabStyle, styles.mainViewSelected2] : [styles.tabStyle] ;
        let styleInactive = this.state.likeStatus == 'inactive' ? [styles.tabStyle, styles.mainViewSelected3] : [styles.tabStyle];

        return (
            <View style={styles.container}>
                {this._renderHeaderAds()}
                <FullLine />
                <View style={styles.scrollView}>
                    <Animated.View
                        style={{
                                height: this.state.height,
                                justifyContent: 'flex-end',
                            }}
                    >
                        <ScrollView
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="on-drag"
                            ref={(scrollView) => { this._scrollView = scrollView; }}
                            onLayout={event => {
                                            this._scrollViewHeight = event.nativeEvent.layout.height
                                        }}
                            onContentSizeChange={(contentWidth, contentHeight) => {
                                            this._scrollContentHeight = contentHeight;
                                        }}
                            // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
                            onKeyboardWillShow={this.onKeyboardWillShow.bind(this)}
                            onKeyboardDidShow={this.onKeyboardDidShow.bind(this)}
                            // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
                            onKeyboardWillHide={this.onKeyboardWillHide.bind(this)}
                            onKeyboardDidHide={this.onKeyboardDidHide.bind(this)}
                            automaticallyAdjustContentInsets={false}
                            vertical={true}
                            style={{flex: 1}}

                        >
                            {this.renderListContactTag()}
                            {this._renderContactType()}
                            {this.renderDanhGia()}
                            <FullLine/>
                            {this.renderCheckBoxNhuCau()}
                            {this.state.isCheckNhuCau ?
                                (<View style={styles.viewContentNhucau}>

                                    <View style={[styles.searchFilterButton]}>
                                        <View style={{ flexGrow: 1, flexDirection: 'row', paddingLeft: 5, paddingRight: 5 }}>

                                            <TitleTabButton name={'mua'}
                                                            disabled={this.isUploading()}
                                                            onPress={this._onLoaiTinChange.bind(this)}
                                                            selected={loaiTin === 'mua'}
                                                            mainProps={{
                                    borderTopLeftRadius: 5, borderBottomLeftRadius: 5,
                                    borderTopWidth: 1, borderLeftWidth: 1, borderBottomWidth: 1,
                                    marginLeft: 10, marginRight: 0, width: width / 2 - 15
                                }}>Cần mua</TitleTabButton>
                                            <TitleTabButton name={'thue'}
                                                            disabled={this.isUploading()}
                                                            onPress={this._onLoaiTinChange.bind(this)}
                                                            selected={loaiTin === 'thue'}
                                                            mainProps={{
                                    borderTopRightRadius: 5, borderBottomRightRadius: 5,
                                    borderTopWidth: 1, borderBottomWidth: 1, borderRightWidth: 1,
                                    marginLeft: 0, marginRight: 10, width: width / 2 - 15
                                }}>Cần thuê</TitleTabButton>
                                        </View>
                                        <FullLine />
                                        <View style={styles.searchFilterDetail}>
                                            <TouchableOpacity
                                                disabled={this.isUploading()}
                                                onPress={this._onAddressPress.bind(this)}
                                            >
                                                <View style={styles.searchDiaChinhView}>
                                                    <View style={styles.diaChinhSubView}>
                                                        <View style={styles.diaChinhTouchable}>
                                                            <View style={styles.locationIcon}>
                                                                <RelandIcon name="location" color={'rgba(178,178,178,1)'} mainProps={{ flexDirection: 'row' }}
                                                                            size={20} textProps={{ paddingLeft: 0 }}
                                                                            noAction={true} />
                                                            </View>
                                                            <Text style={[styles.diaChinhText, { color: diaChiColor }]}>{this._getTextAddress()}</Text>
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                            <FullLine />
                                            <View style={styles.searchSectionTitle}>
                                                <Text style={styles.cacDieuKienText}>
                                                    ĐẶC ĐIỂM
                                                </Text>
                                            </View>
                                            <FullLine />
                                            <TouchableOpacity
                                                disabled={this.isUploading()}
                                                onPress={this._onPropertyTypesPressed.bind(this)}>
                                                <View style={styles.searchFilterAttributeExt3}>
                                                    <Text style={[styles.searchAttributeLabel, {color: 'rgba(85,85,85,1)'}]}>
                                                        Loại nhà đất
                                                    </Text>
                                                    <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                                                        <Text style={styles.searchAttributeValue}> {this._getLoaiNhatDatValue()} </Text>
                                                        <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                            <FullLine style={{ marginLeft: 17 }} />
                                            {this._renderGia()}
                                            <FullLine style={{ marginLeft: 17 }} />
                                            {this._renderDienTich()}
                                            <FullLine style={{ marginLeft: 17 }} />
                                            {this._renderHuongNha()}
                                            {this.showSoTang() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                                            {this._renderSoTang()}
                                            {this.showSoPhongNgu() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                                            {this._renderSoPhongNgu()}
                                            {this.showSoNhaTam() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                                            {this._renderSoNhaTam()}
                                            {/*<FullLine />*/}
                                            {/*{this._renderGhiChu()}*/}
                                            {/*<FullLine />*/}
                                            <View style={styles.lineSuggest} />
                                            <View style={styles.searchSectionTitle}>
                                                <Text style={styles.cacDieuKienText}>
                                                    THỜI GIAN
                                                </Text>
                                            </View>
                                            <FullLine />
                                            {this._renderDayStartNoti()}
                                            {this._renderDayEndNoti()}
                                            <View style={styles.lineSuggest} />
                                            <View style={styles.searchSectionTitle}>
                                                <Text style={styles.cacDieuKienText}>
                                                    ĐỘ ƯU TIÊN
                                                </Text>
                                            </View>
                                            <FullLine />
                                            <View style={[styles.viewTabInterest]}>
                                                <MLikeTapButton3 name={'hot'}
                                                                 onPress={this._onStatusPress.bind(this)}
                                                                 selected={this.state.likeStatus == 'hot'}
                                                                 mainProps={styleHot}
                                                                 line1="Hot"></MLikeTapButton3>

                                                <MLikeTapButton3 name={'warm'}
                                                                 onPress={this._onStatusPress.bind(this)}
                                                                 selected={this.state.likeStatus == 'warm'}
                                                                 mainProps={styleWarm}
                                                                 line1="Warm"></MLikeTapButton3>

                                                <MLikeTapButton3 name={'inactive'}
                                                                 onPress={this._onStatusPress.bind(this)}
                                                                 selected={this.state.likeStatus == 'inactive'}
                                                                 mainProps={styleInactive}
                                                                 line1="Inactive"></MLikeTapButton3>
                                            </View>
                                            <View style={styles.lineSuggest} />
                                            <View style={styles.searchSectionTitle}>
                                                <Text style={styles.cacDieuKienText}>
                                                    GHI CHÚ
                                                </Text>
                                            </View>
                                            <FullLine />
                                            {this._renderGhiChu()}
                                        </View>
                                    </View>
                                </View>)
                                : null}
                        </ScrollView>
                    </Animated.View>
                    {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                      style={[styles.searchButtonText2, {
                                textAlign: 'right', color: gui.mainColor,
                                backgroundColor: gui.doneKeyButton
                            }]}>Xong</Button> : null}
                    <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />

                </View>
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={100}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }} />
            </View>
        );

    }
    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity style={styles.viewBackButton}
                                  onPress={this.onBackPress.bind(this)}
                >
                    <Text style={styles.textCommon}>Hủy</Text>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, { fontWeight: '500', fontSize: 17 }]}>Thêm liên hệ</Text>
                </View>
                <TouchableOpacity 
                    onPress={this.onApply.bind(this)}
                    style={styles.addButton}>
                    <Text style={styles.textCommon}>Lưu</Text>
                </TouchableOpacity>
            </View>

        );
    }

    // _renderBody() {
    //         return (
    //             <ScrollView
    //                 keyboardShouldPersistTaps="always"
    //                 keyboardDismissMode="on-drag"
    //                 ref={(scrollView) => { this._scrollView = scrollView; }}
    //                 onLayout={event => {
    //                                 this._scrollViewHeight = event.nativeEvent.layout.height
    //                             }}
    //                 onContentSizeChange={(contentWidth, contentHeight) => {
    //                                 this._scrollContentHeight = contentHeight;
    //                             }}
    //                 // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
    //                 onKeyboardWillShow={this.onKeyboardWillShow.bind(this)}
    //                 onKeyboardDidShow={this.onKeyboardDidShow.bind(this)}
    //                 // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
    //                 onKeyboardWillHide={this.onKeyboardWillHide.bind(this)}
    //                 onKeyboardDidHide={this.onKeyboardDidHide.bind(this)}
    //                 automaticallyAdjustContentInsets={false}
    //                 vertical={true}
    //             >
    //                 {this.renderListContactTag()}
    //                 {this.renderDanhGia()}
    //                 <FullLine/>
    //                 {this.renderCheckBoxNhuCau()}
    //                 {this.state.isCheckNhuCau ? this.renderContentNhuCau() : null}
    //             </ScrollView>
    //         )
    // }

    getBackgroundButton() {
        let backgroundColor = '#fff';
        if(this.state.likeStatus == 'hot')
            backgroundColor = 'rgba(255,81,81,1)';
        if(this.state.likeStatus == 'warm')
            backgroundColor = 'rgba(255,207,86,1)';
        if(this.state.likeStatus == 'inactive')
            backgroundColor = 'rgba(169,183,200,1)';
        return backgroundColor;
    }

    renderContentNhuCau() {
        let { loaiTin, blankDiaChiColor } = this.state;
        let diaChi = this._getHeaderTitle();
        let diaChiColor = (diaChi == gui.CHON_KHU_VUC) ? blankDiaChiColor : '#000';
        let styleHot = this.state.likeStatus == 'hot' ? [styles.tabStyle, { marginLeft: 0 }, styles.mainViewSelected1] : [styles.tabStyle, { marginLeft: 0 }];
        let styleWarm = this.state.likeStatus == 'warm' ? [styles.tabStyle, styles.mainViewSelected2] : [styles.tabStyle] ;
        let styleInactive = this.state.likeStatus == 'inactive' ? [styles.tabStyle, styles.mainViewSelected3] : [styles.tabStyle];
        return(
            <View style={styles.viewContentNhucau}>

                <View style={[styles.searchFilterButton]}>
                    <View style={{ flexGrow: 1, flexDirection: 'row', paddingLeft: 5, paddingRight: 5 }}>

                        <TitleTabButton name={'mua'}
                                        disabled={this.isUploading()}
                                        onPress={this._onLoaiTinChange.bind(this)}
                                        selected={loaiTin === 'mua'}
                                        mainProps={{
                                    borderTopLeftRadius: 5, borderBottomLeftRadius: 5,
                                    borderTopWidth: 1, borderLeftWidth: 1, borderBottomWidth: 1,
                                    marginLeft: 10, marginRight: 0, width: width / 2 - 15
                                }}>Cần mua</TitleTabButton>
                        <TitleTabButton name={'thue'}
                                        disabled={this.isUploading()}
                                        onPress={this._onLoaiTinChange.bind(this)}
                                        selected={loaiTin === 'thue'}
                                        mainProps={{
                                    borderTopRightRadius: 5, borderBottomRightRadius: 5,
                                    borderTopWidth: 1, borderBottomWidth: 1, borderRightWidth: 1,
                                    marginLeft: 0, marginRight: 10, width: width / 2 - 15
                                }}>Cần thuê</TitleTabButton>
                    </View>
                    <FullLine />
                    <View style={styles.searchFilterDetail}>
                        <TouchableOpacity
                            disabled={this.isUploading()}
                            onPress={this._onAddressPress.bind(this)}
                        >
                            <View style={styles.searchDiaChinhView}>
                                <View style={styles.diaChinhSubView}>
                                    <View style={styles.diaChinhTouchable}>
                                        <View style={styles.locationIcon}>
                                            <RelandIcon name="location" color={'rgba(178,178,178,1)'} mainProps={{ flexDirection: 'row' }}
                                                        size={20} textProps={{ paddingLeft: 0 }}
                                                        noAction={true} />
                                        </View>
                                        <Text style={[styles.diaChinhText, { color: diaChiColor }]}>{this._getTextAddress()}</Text>
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <FullLine />
                        <View style={styles.searchSectionTitle}>
                            <Text style={styles.cacDieuKienText}>
                                ĐẶC ĐIỂM
                            </Text>
                        </View>
                        <FullLine />
                        <TouchableOpacity
                            disabled={this.isUploading()}
                            onPress={this._onPropertyTypesPressed.bind(this)}>
                            <View style={styles.searchFilterAttributeExt3}>
                                <Text style={[styles.searchAttributeLabel, {color: 'rgba(85,85,85,1)'}]}>
                                    Loại nhà đất
                                </Text>
                                <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                                    <Text style={styles.searchAttributeValue}> {this._getLoaiNhatDatValue()} </Text>
                                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                                </View>
                            </View>
                        </TouchableOpacity>
                        <FullLine style={{ marginLeft: 17 }} />
                        {this._renderGia()}
                        <FullLine style={{ marginLeft: 17 }} />
                        {this._renderDienTich()}
                        <FullLine style={{ marginLeft: 17 }} />
                        {this._renderHuongNha()}
                        {this.showSoTang() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                        {this._renderSoTang()}
                        {this.showSoPhongNgu() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                        {this._renderSoPhongNgu()}
                        {this.showSoNhaTam() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                        {this._renderSoNhaTam()}
                        {/*<FullLine />*/}
                        {/*{this._renderGhiChu()}*/}
                        {/*<FullLine />*/}
                        <View style={styles.lineSuggest} />
                        <View style={styles.searchSectionTitle}>
                            <Text style={styles.cacDieuKienText}>
                                THỜI GIAN
                            </Text>
                        </View>
                        <FullLine />
                        {this._renderDayStartNoti()}
                        {this._renderDayEndNoti()}
                        <View style={styles.lineSuggest} />
                        <View style={styles.searchSectionTitle}>
                            <Text style={styles.cacDieuKienText}>
                                ĐỘ ƯU TIÊN
                            </Text>
                        </View>
                        <FullLine />
                        <View style={[styles.viewTabInterest]}>
                            <MLikeTapButton3 name={'hot'}
                                             onPress={this._onStatusPress.bind(this)}
                                             selected={this.state.likeStatus == 'hot'}
                                             mainProps={styleHot}
                                             line1="Hot"></MLikeTapButton3>

                            <MLikeTapButton3 name={'warm'}
                                             onPress={this._onStatusPress.bind(this)}
                                             selected={this.state.likeStatus == 'warm'}
                                             mainProps={styleWarm}
                                             line1="Warm"></MLikeTapButton3>

                            <MLikeTapButton3 name={'inactive'}
                                             onPress={this._onStatusPress.bind(this)}
                                             selected={this.state.likeStatus == 'inactive'}
                                             mainProps={styleInactive}
                                             line1="Inactive"></MLikeTapButton3>
                        </View>
                        <View style={styles.lineSuggest} />
                        <View style={styles.searchSectionTitle}>
                            <Text style={styles.cacDieuKienText}>
                                GHI CHÚ
                            </Text>
                        </View>
                        <FullLine />
                        {this._renderGhiChu()}
                    </View>
                </View>
            </View>
        )
    }

    _renderDayStartNoti() {
        let textStart = 'Bắt đầu';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{textStart}</Text>
                    <View style={styles.touchKieuNha}>
                        <DatePicker
                            style={{
                                width: width / 2 - 30,
                            }}
                            customStyles={{
                                dateInput: {
                                    borderWidth: 0,
                                    alignItems: 'flex-end'
                                },
                                placeholderText: {
                                    color: 'rgba(56,151,241,1)',
                                    fontWeight: '500'
                                },
                                dateText: {
                                    color: 'rgba(56,151,241,1)',
                                    fontWeight: '500'
                                }
                            }}
                            showIcon={false}
                            date={this.state.dateStart}
                            mode="date"
                            placeholder="Chọn thời gian"
                            format="DD/MM/YYYY"
                            minDate="01/12/2017"
                            maxDate="01/12/2020"
                            confirmBtnText="Chọn"
                            cancelBtnText="Hủy"
                            onDateChange={this._onDateStartChange.bind(this)}
                        />
                    </View>
                    <View style={styles.dotStyle} />
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _renderDayEndNoti() {
        let textEnd = 'Kết thúc';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{textEnd}</Text>
                    <View style={styles.touchKieuNha}>
                        <DatePicker
                            style={{
                                width: width / 2 - 30,
                            }}
                            customStyles={{
                                dateInput: {
                                    borderWidth: 0,
                                    alignItems: 'flex-end'
                                },
                                placeholderText: {
                                    color: 'rgba(255,81,81,1)',
                                    fontWeight: '500'
                                },
                                dateText: {
                                    color: 'rgba(255,81,81,1)',
                                    fontWeight: '500'
                                }
                            }}
                            showIcon={false}
                            date={this.state.dateEnd}
                            mode="date"
                            placeholder="Chọn thời gian"
                            format="DD/MM/YYYY"
                            minDate="01/12/2017"
                            maxDate="01/12/2020"
                            confirmBtnText="Chọn"
                            cancelBtnText="Hủy"
                            onDateChange={this._onDateEndChange.bind(this)}
                        />
                    </View>
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }


    _onDateStartChange(date) {
        let eventStartDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState({ dateStart: eventStartDate });
    }

    _onDateEndChange(date) {
        let eventEndDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState({ dateEnd: eventEndDate });
    }

    onLayoutLastTag = (endPosOfTag: number) => {
        const margin = 3;
        this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
        const inputWidth = ContactImportDetail.inputWidth(
            this.state.text,
            this.spaceLeft,
            this.wrapperWidth,
        );
        if (inputWidth !== this.state.inputWidth) {
            this.setState({ inputWidth });
        }
    }

    static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
        if (text === "") {
            return 90;
        } else if (spaceLeft >= 100) {
            return spaceLeft - 10;
        } else {
            return wrapperWidth;
        }
    }


    removeContact = (index: number) => {
        const tags = [...this.state.contacts];
        tags.splice(index, 1);
        this.setState({ contacts: tags });
    };

    renderListContactTag() {
        let contactsToShow = this.state.isExpanded ? this.state.contacts : (this.state.contacts.length>5 ? this.state.contacts.slice(0,5) : this.state.contacts)

        let tags = contactsToShow.map((tag, index) => (
            <TagGroup
                type="DiaChinh"
                index={index}
                label={tag.contactName}
                isLastTag={this.state.contacts.length === index + 1}
                onLayoutLastTag={this.onLayoutLastTag}
                removeIndex={this.removeContact.bind(this)}
                tagColor='rgba(246,246,246,1)'
                tagTextColor='rgba(35,35,35,1)'
                key={index}
            />
        ));
        return(
                <View style={styles.viewDanhGia}>
                    <Text style={styles.textDanhGia}>Liên hệ bạn mới thêm</Text>
                    <View style={[styles.viewTypeHide, styles.addTag]}>
                        {tags}
                    </View>
                    {this.renderAllContacts()}
                    <FullLine/>
                </View>
            );
    }

    renderAllContacts() {
        let textMore = this.state.isExpanded ? 'Rút gọn' : 'Tất cả liên hệ mới thêm';
        let iconName = this.state.isExpanded ? "arrow-up" : "arrow-down"
        return(
            <TouchableOpacity style={styles.viewMoreContact}
                onPress={this._onExpand.bind(this)}>
                <Text style={[styles.textDanhGia, {fontSize: 13, color: gui.mainColor}]}>{textMore}</Text>
                <TruliaIcon name={iconName} color={gui.mainColor} size={14} mainProps={{marginTop: 1, marginLeft: 4}} />
            </TouchableOpacity>
        )
    }

    _onExpand() {
        this.setState({isExpanded: !this.state.isExpanded})
    }

    _renderContactType() {
        let potentialCustomer = 'Phân loại';

        let contactTypeItems = [];
        let contactTypeKeys = Object.keys(DanhMuc.contactType);
        contactTypeKeys.forEach((aType) => {
            let contactType = DanhMuc.contactType[aType];

            contactTypeItems.push(
                <CheckDotNhuCau name={aType} key={aType}
                                onPress={this._onContactType.bind(this)}
                                selected={this.state.contactType == aType}
                                mainProps={[styles.viewSaleState]}>{contactType}</CheckDotNhuCau>
            );
        });

        return (
            <View style={styles.viewDanhGia}>
                <Text style={styles.textDanhGia}>{potentialCustomer}</Text>
                <View style={styles.viewTypeHide}>
                    {contactTypeItems}
                </View>
            </View>
        )


    }

    _onContactType(value) {
        this.setState({contactType: value});
    }

    renderDanhGia() {
        let saleStateItems = [];
        let sateStateKeys = Object.keys(DanhMuc.contactSaleState);
        sateStateKeys.forEach((saleState) => {
            let hiddenType = DanhMuc.contactSaleState[saleState];

            saleStateItems.push(
                <CheckDotNhuCau name={saleState} key={saleState}
                          onPress={this._onSaleState.bind(this)}
                          selected={this.state.contactSaleState == saleState}
                          mainProps={[styles.viewSaleState]}>{hiddenType}</CheckDotNhuCau>
            );
        });
        return(
            <View style={styles.viewDanhGia}>
                <Text style={styles.textDanhGia}>Đánh giá tiềm năng</Text>
                <View style={styles.viewTypeHide}>
                    {saleStateItems}
                </View>
            </View>
        )
    }

    renderCheckBoxNhuCau() {
        return(
            <TouchableOpacity style={styles.viewCheckBox}
                              onPress={this.onCheckNhuCau.bind(this)}
            >
                <CheckBoxNhuCau
                    size={18}
                    selected={this.state.isCheckNhuCau}
                    onPress={this.onCheckNhuCau.bind(this)} />
                <Text style={[styles.textDanhGia, {marginLeft: 5}]}>Thêm nhu cầu</Text>
            </TouchableOpacity>
        )
    }

    onCheckNhuCau() {
        this.setState({
            isCheckNhuCau : !this.state.isCheckNhuCau
        })
    }

    _onStatusPress(value) {
        this.setState({
            likeStatus: value
        });
    }

    _onSaleState(value) {
        this.setState({ contactSaleState: value });
    }

    _onAddressPress() {
        this.setState({ geoFinding: false });
        Actions.ContactWtoAutoComplete(
            {
                onSuggestionBuyPressed: (location) => this._collectSuggestionInfo(location),
                category: ["DIA_CHINH", "DU_AN"],
                placeHolder: 'Nhập tên địa chính/dự án'
            });

    }

    _collectSuggestionInfo(position) {

        let place = {
            codeDuong: position.duong || undefined,
            tenDuong: (position.placeType == 'D' ? position.placeName : position.duongName) || undefined,
            codeXa: position.xa || undefined,
            tenXa: (position.placeType == 'X' ? position.placeName : position.xaName) || undefined,
            codeHuyen: position.huyen || undefined,
            tenHuyen: (position.placeType == 'H' ? position.placeName : position.huyenName) || undefined,
            codeTinh: position.tinh || undefined,
            tenTinh: (position.placeType == 'T' ? position.placeName : position.tinhName) || undefined,
            codeDuAn: position.duAn || undefined,
            tenDuAn: (position.placeType == 'A' ? position.placeName : position.duAnName) || undefined,
            viewport: position.viewport || undefined,
            location: position.location || undefined,
            fullName: position.fullName || undefined
        };
        this.props.actions.onNhuCauFieldChange('place', place);
    }

    _getTextAddress() {
        let diaChi = this._getHeaderTitle();

        if (diaChi && diaChi.length > 40) {
            diaChi = diaChi.substring(0, 40) + '...';
        }

        return diaChi ? diaChi : 'Nhập địa chính hoặc dự án...';
    }

    _renderGhiChu() {
        let placeholder = 'Nhập ghi chú...';
        return (
            <View style={styles.searchFilterAttribute}>
                <TextInput ref="textInput"
                           autoCorrect={false}
                           multiline={true}
                           onChangeText={this._onGhiChuChangeText.bind(this)}
                           style={styles.textInput}
                           value={this.state.ghiChu}
                           placeholder={placeholder}
                           placeholderTextColor={gui.arrowColor}
                           clearButtonMode="never"
                           selectTextOnFocus={true}
                           disabled={this.isUploading()}
                           allowFontScaling={false}
                           onFocus={() => this.setState({ghiChuFocus: true})}
                           onBlur={() => setTimeout(() => this.setState({ghiChuFocus: false}), 1000)}
                />
            </View>
        )
    }

    _onGhiChuChangeText(text) {
        this.setState({ ghiChu: text });
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    onCancel() {
        let isUpdate = this.state.id && this.state.id.length > 0;
        this.setState({ onCancelling: true });
        Actions.pop();
    }

    isValidPlace() {
        let { place } = this.props.group.nhuCauFields;
        let validDiaChinh = place.codeDuAn || place.codeXa || place.codeHuyen || place.codeTinh || place.codeDuong;
        let ignoreDiaChinh = (place.circle && place.circle.radius > 0) || (place.polygon && place.polygon.length > 0);
        let valid = ignoreDiaChinh || validDiaChinh;
        this.setState({ blankDiaChiColor: valid ? '#000' : 'red' });
        return valid;
    }

    isValidGia() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let blankFromGiaColor = '#000';
        if (giaVal[0] <= 0) {
            blankFromGiaColor = 'red';
        }
        let blankToGiaColor = '#000';
        if (giaVal[1] <= 0 || giaVal[1] == DanhMuc.BIG) {
            blankToGiaColor = 'red';
        }
        this.setState({ blankFromGiaColor: blankFromGiaColor, blankToGiaColor: blankToGiaColor });
        return giaVal[0] > 0 && (giaVal[1] > 0 && giaVal[1] != DanhMuc.BIG);
    }

    _validInputData() {
        let errors = '';        

        if (!this.isValidPlace()) {
            errors += ' (địa điểm/dự án)';
        }

        if (!this.isValidGia()) {
            errors += ' (giá)';
        }

        if (errors != '') {
            return 'Bạn chưa nhập thông tin' + errors + '!';
        }
        
        if (this.state.dateStart && this.state.dateEnd && this.state.dateStart.diff(this.state.dateEnd) > 0) {
            // Alert.alert("Thông báo", 'Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc', [{ text: 'Đóng', onPress: () => { } }]);
            this.refs.toastTop && this.refs.toastTop.show('Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc', 3000);
            return null;
        }

        return null;
    }

    isUploading() {
        return this.props.group.creatingContactWto;
    }

    onLogEvent(title) {
        let eventDto = {
            scene: "ContactImportDetail",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,
            customData: this.state.contacts ? {numOfContact: this.state.contacts.length} : undefined
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    onApply() {
        this.onLogEvent("Lưu danh bạ từ máy");
        if (this.state.isCheckNhuCau) {
            let msg = this._validInputData();
            if (msg) {
                this.refs.toastTop && this.refs.toastTop.show(msg, 3000);
                return;
            }
        }

        let { loaiTin, dienTich, soTangSelectedIdx, soPhongNguSelectedIdx, soNhaTamSelectedIdx, huongNha,
            ghiChu, dateStart, dateEnd } = this.state;

        let { id, place } = this.props.group.nhuCauFields;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        let mua = null;
        let thue = null;
        if (loaiTin == 'mua') {
            mua = this.state['mua'];
        } else {
            thue = this.state['thue'];
        }

        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;

        this.props.actions.onNhuCauFieldChange('loaiTin', loaiTin);
        this.props.actions.onNhuCauFieldChange(loaiTin, loaiNhaDatParent);

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);
        this.props.actions.onNhuCauFieldChange("dienTich", newDienTich);
        this.props.actions.onNhuCauFieldChange("soTangSelectedIdx", soTangSelectedIdx);
        this.props.actions.onNhuCauFieldChange("soPhongNguSelectedIdx", soPhongNguSelectedIdx);
        this.props.actions.onNhuCauFieldChange("soNhaTamSelectedIdx", soNhaTamSelectedIdx);
        this.props.actions.onNhuCauFieldChange("huongNha", huongNha);
        this.props.actions.onNhuCauFieldChange("ghiChu", ghiChu);

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let userID = currentUser.userID;

        let dto = {
            id: id,            
            loaiTin: loaiTin,
            mua: loaiTin == 'mua' ? loaiNhaDatParent : undefined,
            thue: loaiTin != 'mua' ? loaiNhaDatParent : undefined,
            dienTich: newDienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            place: place,
            ghiChu: ghiChu,
            userID: userID,
            dateStart: dateStart,
            dateEnd: dateEnd,
            priority: this.state.likeStatus
        };

        let loaiTinVal = (loaiTin === 'mua') ? 0 : 1;
        let wtoDto = this.convertWToFieldsToParams(dto)
        let importDto = {
            "userID": userID || undefined,
            "contacts": this.state.contacts,
            "wto": this.state.isCheckNhuCau ? wtoDto : undefined,
            "contactSaleState": this.state.contactSaleState,
            "contactType": this.state.contactType
        }
        importDto.contacts.forEach((e) => {
            e.zaloStatus = 'request'
        })

        if (this.state.contacts.length > 0) {
        this.props.actions.importContacts(importDto, token)
            .then(res => {
                this.setState({
                    loading: false,
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    let newState = this.props.groupContact.filteredDeviceContactList;
                    this.props.checkedDeviceContactList.forEach((e) => {
                        newState.reduce(function (filtered, oldValue) {
                            if (oldValue.recordID == e.recordID) {
                                var newValue = oldValue;
                                newValue.canInvite = false;
                                newValue.checked = false;
                                filtered.push(newValue);
                            } else {
                                filtered.push(oldValue);
                            }
                            return filtered;
                        }, []);
                    });
                    this.setState({ deviceContactList: newState });                    
                    this.props.actions.onGroupContactFieldChange('filteredDeviceContactList', newState)
                    //
                    let newState2 = this.props.groupContact.allDeviceContactList;
                    this.props.checkedDeviceContactList.forEach((e) => {
                        newState2.reduce(function (filtered, oldValue) {
                            if (oldValue.recordID == e.recordID) {
                                var newValue = oldValue;
                                newValue.canInvite = false;
                                newValue.checked = false;
                                filtered.push(newValue);
                            } else {
                                filtered.push(oldValue);
                            }
                            return filtered;
                        }, []);
                    });
                    this.props.actions.onGroupContactFieldChange('allDeviceContactList', newState2)

                    setTimeout(() => Alert.alert(
                        "Thông báo",
                        "Tải liên hệ thành công.",
                        [{ text: 'Đóng', onPress: () => {
                            this.props.request && this.props.request(this.props.text)                            
                            Actions.pop() ;                            
                        } }]), 300);
                
                }
            })
        } else {
            Alert.alert("Thông báo", 'Bạn chưa chọn liên hệ để tải', [{ text: 'Đóng', onPress: () => { } }]);
        }


    }

    convertWToFieldsToParams(fields) {
        var { id, loaiTin, dienTich, soTangSelectedIdx, soPhongNguSelectedIdx, soNhaTamSelectedIdx,
            huongNha, place, ghiChu, userID, contactID, dateStart, dateEnd, priority
        } = fields;

        let loaiNhaDat = fields[loaiTin].loaiNhaDat;
        let gia = fields[loaiTin].gia;

        let giaRange = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;

        let giaTu = undefined;
        let giaDen = undefined;
        if (gia) {
            let giaVal = giaRange.toValRange(gia);
            giaTu = giaVal[0];
            giaDen = giaVal[1];
        }

        let dienTichTu = undefined;
        let dienTichDen = undefined;
        if (dienTich) {
            let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
            dienTichTu = dienTichVal[0];
            dienTichDen = dienTichVal[1];
        }

        let loaiTinVal = 'mua' === loaiTin ? 0 : 1;
        let textKhongDau = '';
        if (loaiNhaDat && loaiNhaDat.length>0)
            textKhongDau += utils.getLoaiNhaDatText(loaiTin, loaiNhaDat) + ' '
        
        textKhongDau += place.fullName + ' '; //
        if (huongNha && huongNha.length>0)
            textKhongDau += utils.getHuongNhaText2(huongNha) + ' ' 

        let donViTien = 0 === loaiTin ? "tỷ" : "triệu";      
        if (giaTu)
            textKhongDau += String(this.state.fromGia) + ' ' + donViTien + ' '
        if (giaDen)
            textKhongDau += String(this.state.toGia) + ' ' + donViTien + ' '

        textKhongDau = utils.locDauV2(utils.standardlizeName(textKhongDau));


        let params = {
            'id': id || undefined,
            'userID': userID || undefined,
            'contactID': contactID || undefined,
            'loaiTin': loaiTinVal,
            'dateStart': dateStart ? dateStart.format('YYYYMMDD') : undefined,
            'dateEnd': dateEnd ? dateEnd.format('YYYYMMDD') : undefined,
            'priority': priority,
            content: {
                'textKhongDau': textKhongDau,
                'loaiTin': loaiTinVal,
                'loaiNhaDat': loaiNhaDat || undefined,
                'giaTu': giaTu || undefined,
                'giaDen': giaDen || undefined,
                'dienTichTu': dienTichTu || undefined,
                'dienTichDen': dienTichDen || undefined,
                'soTang': Number(DanhMuc.getSoTangByIndex(soTangSelectedIdx)) || undefined,
                'soPhongNgu': Number(DanhMuc.getSoPhongByIndex(soPhongNguSelectedIdx)) || undefined,
                'soPhongTam': Number(DanhMuc.getSoPhongTamByIndex(soNhaTamSelectedIdx)) || undefined,
                'place': place && Object.keys(place).length > 0 ? place : undefined,
                'huongNha': huongNha || undefined,
                'ghiChu': ghiChu || undefined
            }
        };

        return params
    }

    _onArraySort(a, b) {
        if (a === '') {
            return 1;
        }
        if (b === '') {
            return -1;
        }
        return a - b;
    }

    onResetFilters(keepID) {
        let defaultMua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onNhuCauFieldChange("mua", defaultMua);
        this.props.actions.onNhuCauFieldChange("thue", defaultThue);
        this.props.actions.onNhuCauFieldChange("soTangSelectedIdx", 0);
        this.props.actions.onNhuCauFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onNhuCauFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onNhuCauFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onNhuCauFieldChange("huongNha", 0);
        this.props.actions.onNhuCauFieldChange("place", {});
        this.props.actions.onNhuCauFieldChange("ghiChu", '');

        let id = keepID ? this.props.group.nhuCauFields.id : null;
        this.props.actions.onNhuCauFieldChange('id', id);

        this.setState({
            id: id, initGia: RangeUtils.BAT_KY_RANGE, initDienTich: RangeUtils.BAT_KY_RANGE,
            fromDienTich: '', toDienTich: '', fromGia: '', toGia: '', showGia: false, showDienTich: false,
            mua: defaultMua, thue: defaultThue, dienTich: RangeUtils.BAT_KY_RANGE,
            soTangSelectedIdx: 0, soPhongNguSelectedIdx: 0, soNhaTamSelectedIdx: 0, huongNha: 0, ghiChu: '',
            onCancelling: false
        });
    }

    _onPropertyTypesPressed() {
        let { loaiTin } = this.state;
        Actions.PropertyTypesWTo({
            owner: 'ContactNhuCau', func: 'search', loaiTin: loaiTin, loaiNhaDat: this.state[loaiTin].loaiNhaDat,
            onLoaiNhaDatChange: (loaiNhaDat) => this._onLoaiNhaDatChange(loaiNhaDat)
        });
    }

    _onLoaiNhaDatChange(loaiNhaDat) {
        let { loaiTin } = this.state;
        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = loaiNhaDat;
        if (loaiTin == 'mua') {
            this.setState({ mua: loaiNhaDatParent });
        } else {
            this.setState({ thue: loaiNhaDatParent });
        }
    }

    _onHuongNhaPressed() {
        Actions.WToHuongNha({ owner: 'ContactNhuCau', huongNha: this.state.huongNha, onHuongNhaChange: (huongNha) => this._onHuongNhaChange(huongNha) });
    }

    _onHuongNhaChange(huongNha) {
        this.setState({ huongNha: huongNha });
    }

    _onSoPhongNguChanged(index) {
        this.setState({ soPhongNguSelectedIdx: index });
    }

    _onSoTangChanged(index) {
        this.setState({ soTangSelectedIdx: index });
    }

    _onSoNhaTamChanged(index) {
        this.setState({ soNhaTamSelectedIdx: index });
    }

    _renderDienTich() {
        let { fromDienTich, toDienTich } = this.state;
        let fromPlaceholder = 'từ';
        let toPlaceholder = 'đến';
        let onTextChange = this._onDienTichInputChange.bind(this);
        let onTextFocus = this._onScrollDienTich.bind(this);
        return (
            <View style={styles.textInputView}>
                <View style={[styles.textInputView1, { width: width / 3 + 15 }]}>
                    <Text style={[styles.searchAttributeLabel, { marginLeft: 17 }]}>
                        Diện tích (m²)
                    </Text>
                </View>
                <View style={[styles.textInputView1, {
                    justifyContent: 'flex-end', width: width / 3 - 10,
                    borderRightColor: gui.separatorLine, borderRightWidth: 1
                }]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={styles.input}
                        placeholder={fromPlaceholder}
                        value={String(fromDienTich)}
                        onChangeText={(text) => onTextChange(0, text)}
                        //onFocus={() => onTextFocus()}
                        disabled={this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
                <View style={[styles.textInputView1, { width: width / 3 - 10 }]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={[styles.input, { marginLeft: 0, borderLeftColor: gui.separatorLine, borderLeftWidth: 1 }]}
                        placeholder={toPlaceholder}
                        value={String(toDienTich)}
                        onChangeText={(text) => onTextChange(1, text)}
                        //onFocus={() => onTextFocus()}
                        disabled={this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
            </View>
        );
    }

    _onDienTichInputChange(index, val) {
        let { dienTich } = this.state;
        let newDienTich = [];
        Object.assign(newDienTich, dienTich);
        if (val === '') {
            val = -1;
        } else {
            val = utils.interestNumeric(val);
            if (utils.countDot(val, '\\.') >= 2) {
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!', DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (val === '.') {
            val = '0.';
        }
        newDienTich[index] = val;
        let other = newDienTich[1 - index];
        if (DanhMuc.CHUA_XAC_DINH == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            other = Number(other.substring(0, other.indexOf(" ")));
        } else {
            other = -1;
        }
        newDienTich[1 - index] = other;

        let value = RangeUtils.dienTichRange.rangeVal2Display(newDienTich);

        let fromDienTich = newDienTich[0];
        let toDienTich = newDienTich[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({ fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value });
    }

    _renderGia() {
        let { loaiTin, fromGia, toGia, blankFromGiaColor, blankToGiaColor } = this.state;
        let fromPlaceholder = 'từ';
        let toPlaceholder = 'đến';
        let onTextChange = this._onGiaInputChange.bind(this);
        let onTextFocus = this._onScrollGia.bind(this);
        let donViTien = 'mua' === loaiTin ? "tỷ" : "triệu";
        return (
            <View style={styles.textInputView}>
                <View style={[styles.textInputView1, { width: width / 3 + 15 }]}>
                    <Text style={[styles.searchAttributeLabel, { marginLeft: 17 }]}>
                        Mức giá ({donViTien})
                    </Text>
                </View>
                <View style={[styles.textInputView1, {
                    justifyContent: 'flex-end', width: width / 3 - 10,
                    borderRightColor: gui.separatorLine, borderRightWidth: 1
                }]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={styles.input}
                        placeholder={fromPlaceholder}
                        placeholderTextColor={blankFromGiaColor}
                        value={String(fromGia)}
                        onChangeText={(text) => onTextChange(0, text)}
                        //onFocus={() => onTextFocus()}
                        disabled={this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
                <View style={[styles.textInputView1, { width: width / 3 - 10 }]}>
                    <TextInput
                        secureTextEntry={false}
                        keyboardType={'numeric'}
                        style={[styles.input, { marginLeft: 0, borderLeftColor: gui.separatorLine, borderLeftWidth: 1 }]}
                        placeholder={toPlaceholder}
                        placeholderTextColor={blankToGiaColor}
                        value={String(toGia)}
                        onChangeText={(text) => onTextChange(1, text)}
                        //onFocus={() => onTextFocus()}
                        disabled={this.isUploading()}
                        selectTextOnFocus={true}
                        allowFontScaling={false}
                    />
                </View>
            </View>
        );
    }


    _onGiaInputChange(index, val) {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let rangeStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let newGia = [];
        let newVal = val;
        Object.assign(newGia, gia);
        if (newVal === '') {
            newVal = -1;
        } else {
            newVal = utils.interestNumeric(newVal);
            val = newVal;
            if (utils.countDot(newVal, '\\.') >= 2) {
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!', DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (newVal === '.') {
            newVal = '0.';
        }
        // let hasLastDot = newVal[newVal.length-1] === '.';
        if ('mua' === loaiTin && newVal != -1) {
            newVal = 1000 * newVal;
        }
        // newGia[index] = hasLastDot && 'mua' === loaiTin ? newVal + '.' : newVal;
        newGia[index] = newVal;
        let other = String(newGia[1 - index]);
        if (DanhMuc.THOA_THUAN == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            if (other.indexOf("tỷ") != -1) {
                other = 1000 * Number(other.substring(0, other.indexOf(" ")));
            } else {
                other = Number(other.substring(0, other.indexOf(" ")));
            }
        } else {
            other = -1;
        }
        newGia[1 - index] = other;

        let value = rangeStepValues.rangeVal2Display(newGia);
        this._doChangeGia(loaiTin, value);
        let fromGia = newGia[0];
        let toGia = newGia[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        if (index == 0) {
            this.setState({ fromGia: val, toGia: toGia });
        } else {
            this.setState({ fromGia: fromGia, toGia: val });
        }
    }

    _renderSoPhongNgu() {
        if (this.showSoPhongNgu()) {
            return this._renderSegment("Số phòng ngủ", DanhMuc.getSoPhongNguValues(),
                this.state["soPhongNguSelectedIdx"], this._onSoPhongNguChanged.bind(this));
        } else if (0 != this.state.soPhongNguSelectedIdx) {
            this.setState({ soPhongNguSelectedIdx: 0 });
        }
        return null;
    }

    _renderSoTang() {
        if (this.showSoTang()) {
            return this._renderSegment("Số tầng", DanhMuc.getSoTangValues(),
                this.state["soTangSelectedIdx"], this._onSoTangChanged.bind(this));
        } else if (0 != this.state.soTangSelectedIdx) {
            this.setState({ soTangSelectedIdx: 0 });
        }
        return null;
    }

    _renderSoNhaTam() {
        if (this.showSoNhaTam()) {
            return this._renderSegment("Số nhà tắm", DanhMuc.getSoPhongTamValues(),
                this.state["soNhaTamSelectedIdx"], this._onSoNhaTamChanged.bind(this));
        } else if (0 != this.state.soNhaTamSelectedIdx) {
            this.setState({ soNhaTamSelectedIdx: 0 });
        }
        return null;
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                              onChange={onChange} disabled={this.isUploading()} />
        );
    }

    _renderHuongNha() {
        return (
            <TouchableOpacity
                disabled={this.isUploading()}
                onPress={() => this._onHuongNhaPressed()}>
                <View style={styles.searchFilterAttributeExt3}>
                    <Text style={styles.searchAttributeLabel}>
                        Hướng nhà
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                        <Text style={styles.searchAttributeValue}> {this._getHuongNhaValue()} </Text>
                        <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    showSoPhongNgu() {
        var { loaiTin } = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        // arr1.some(r=> arr2.indexOf(r) >= 0)
        if (loaiNhaDat && [1, 2, 3, 4].some( r => loaiNhaDat.indexOf(r) >= 0) ) {
            return true;
        } else {
            return false;
        }
    }

    showSoTang() {
        var { loaiTin } = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if ((loaiNhaDat && [2, 3, 4].some( r => loaiNhaDat.indexOf(r) >= 0) && loaiTin == 'mua')
            || (loaiNhaDat && [2, 3, 4, 5, 6].some( r => loaiNhaDat.indexOf(r) >= 0) && loaiTin == 'thue')
        ) {
            return true;
        } else {
            return false;
        }
    }

    showSoNhaTam() {
        var { loaiTin } = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if (loaiNhaDat && [1, 2, 3, 4].some( r => loaiNhaDat.indexOf(r) >= 0)) {
            return true;
        } else {
            return false;
        }
    }

    onBackPress() {
        Actions.pop();
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pageHeader: {
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width,
        flexDirection: 'row'
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewBackButton: {
        height: 64,
        width: 68,
        paddingLeft: 16,
        paddingTop: 18,
        justifyContent: 'center',
    },
    addButton: {
        height: 64,
        width: 68,
        paddingRight: 16,
        paddingTop: 18,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewEditHome: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    textCommon: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: 'normal'
    },
    viewDanhGia: {
        width: width,
        height: 'auto',
        paddingLeft: 16,
        paddingTop: 14,
        paddingBottom: 12
    },
    viewMoreContact: {
        height: 44,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection : 'row'
    },
    textDanhGia: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.textPostAds,
        fontWeight: 'normal'
    },
    addTag: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'flex-start',
    },
    viewTypeHide: {
        justifyContent: 'center',
        width: width,
        height: 'auto',
        marginTop: 6
    },
    viewSaleState: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        margin: 5,
        marginLeft: 0,
        marginRight: 0,
        width: width - 24,
    },
    viewCheckBox: {
        height: 44,
        alignItems: 'center',
        paddingLeft: 12,
        flexDirection: 'row'
    },
    viewContentNhucau: {
        flex: 1,
        backgroundColor: '#fff'
    },
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 11,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreFilterButton: {
        flexGrow: 0.5,
        alignItems: 'stretch',
        justifyContent: 'center'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchResetText: {
        color: 'red',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    searchAttributeLabel: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid
    },
    searchAttributeValue: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.arrowColor,
        marginRight: 3
    },
    searchFilterButton: {
        flexDirection: 'column'
    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchSectionTitle: {
        justifyContent: 'center',
        paddingLeft: 16,
        backgroundColor: '#fff',
        height: 32
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection: "column"
    },
    scrollView: {
        flex: 1,
        height: height - 65
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent: 'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection: "row",
        justifyContent: 'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute3: {
        flexDirection: "row",
        justifyContent: 'space-between',
        paddingTop: 10,
        paddingLeft: 17,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt: {
        flexDirection: "row",
        justifyContent: 'space-between',
        paddingTop: 12,
        paddingLeft: 0,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt3: {
        flexDirection: "row",
        justifyContent: 'space-between',
        paddingTop: 12,
        paddingLeft: 17,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    addViewBottom: {
        height: 30,
        width: width,
        backgroundColor: '#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewTitleHeader: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    searchDiaChinhView: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    diaChinhSubView: {
        justifyContent: 'center',
        alignItems: 'center',
        height: 60,
        width: width,
        backgroundColor: 'rgba(248,248,248,1)'
    },
    diaChinhTouchable: {
        height: 44,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderRadius: 5,
        width: width - 32
    },
    diaChinhText: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    locationIcon: {
        backgroundColor: 'white',
        height: 25,
        width: 25,
        marginRight: 4,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width - 30,
        height: 60
    },
    textInputView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    textInputView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width / 3 - 5,
        marginTop: 10,
        marginBottom: 10
    },
    input: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width / 3 - 5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    label: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    viewEachInfo: {
        height: 44,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    viewKieuNha: {
        height: 44,
        width: width - 32,
        flexDirection: 'row',
        // marginTop: 13,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textSavePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textAgentSolid
    },
    touchKieuNha: {
        position: 'absolute',
        right: 8,
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    tabStyle: {
        height: 30,
        width: (width - 52) / 3,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderRadius: 15,
        marginLeft: 10,
        backgroundColor: '#fff',
        borderColor : 'rgba(54,54,54,1)',
    },
    viewTabInterest: {
        flexGrow: 1,
        flexDirection: 'row',
        width: width - 32,
        height: 30,
        marginVertical: 7,
        marginLeft: 16,
    },
    mainViewSelected1: {
        flexGrow: 1,
        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: 'rgba(255,81,81,1)',
        borderColor : 'rgba(255,81,81,1)',
    },
    mainViewSelected2: {
        flexGrow: 1,
        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: 'rgba(255,207,86,1)',
        borderColor : 'rgba(255,207,86,1)',
    },
    mainViewSelected3: {
        flexGrow: 1,
        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: 'rgba(169,183,200,1)',
        borderColor : 'rgba(169,183,200,1)',
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(ContactImportDetail);