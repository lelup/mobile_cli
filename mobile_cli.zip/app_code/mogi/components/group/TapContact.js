import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';

export default class TapContact extends React.Component {
    render() {
        const selected = this.props.selected;
        const myStyle = selected ? 'buttonTextSelected' : 'buttonText';
        const wrapper = selected ? 'buttonViewSelected' : 'buttonView';

        return (
            <View style={[styles[wrapper], this.props.stylesButton]}>
                <TouchableOpacity
                    onPress={() => this.props.onPress(this.props.name)}>
                    <ScalableText style={[styles[myStyle], this.props.mainProps]} >
                        {this.props.children}
                    </ScalableText>
                </TouchableOpacity>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    lineunder: {
        borderStyle: "solid"
    },
    buttonViewSelected: {
        flexDirection: 'column',
        justifyContent: 'center',
        borderRadius: 13,
        paddingHorizontal: 10,
        paddingVertical: 4,
        backgroundColor: gui.mainColor,
        borderWidth: 1,
        borderColor: gui.mainColor,

    },
    buttonView: {
        flexDirection: 'column',
        justifyContent: 'center',
        borderRadius: 13,
        borderWidth: 1,
        borderColor: 'rgba(54,54,54,0.2)',
        paddingHorizontal: 10,
        paddingVertical: 4,
        backgroundColor: '#fff'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 0,
        color: gui.textAgentSolid
    },

    buttonTextSelected: {
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 0,
        color: '#fff',
    }
});