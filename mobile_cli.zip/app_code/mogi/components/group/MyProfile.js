import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    Alert,
    Linking,
    StatusBar
} from 'react-native';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import OfflineBar from '../line/OfflineBar';
import userApi from '../../lib/userApi';
import log from '../../lib/logUtil';
import cfg from '../../cfg';

const FBSDK = require('react-native-fbsdk');
const {
    LoginManager,
    AccessToken,
    GraphRequest,
    GraphRequestManager,
} = FBSDK;

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
var Analytics = require('react-native-firebase-analytics');

import _ from 'lodash';
var Intercom = require('react-native-intercom');

import TruliaIcon from '../TruliaIcon';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as authActions from '../../reducers/auth/authActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as eventActions from '../../reducers/event/eventActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Actions } from 'react-native-router-flux';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import VersionCheck from 'react-native-version-check';
// START: iOS Only
VersionCheck.setAppID('1303128474');                    // Your App ID for App Store URL
VersionCheck.setAppName('landber-agent-moi-gioi-bds');
let { width, height } = utils.getDimensions();

const actions = [
    globalActions,
    meActions,
    authActions,
    searchActions,
    groupActions,
    inboxActions,
    registerActions,
    adsMgmtActions,
    eventActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MyProfile extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
        this.state = {
            isNeedUpdate: false
        };
    }

    componentWillUnmount() {
        StatusBar.setBarStyle('dark-content');
    }

    componentWillMount() {
        VersionCheck.needUpdate()
            .then(res => {
                if (res.isNeeded) {
                    this.setState({
                        isNeedUpdate: true
                    })
                }
            });
    }

    render() {
        let heartImg = require('../../assets/image/p_heart.png');
        let listImg = require('../../assets/image/p_list.png');
        let moneyImg = require('../../assets/image/p_money.png');
        let newsImg = require('../../assets/image/p_news.png');
        let homeImg = require('../../assets/image/p_home.png');
        let logoutImg = require('../../assets/image/p_logout.png');
        let settingsImg = require('../../assets/image/p_settings.png');
        let helpImg = require('../../assets/image/p_support_help.png');
        let huongNhaImg = require('../../assets/image/p_huongnha.png');
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this.renderNewHeader()}
                <FullLine />
                    <ScrollView
                        automaticallyAdjustContentInsets={false}
                        showsVerticalScrollIndicator={false}
                        style={styles.scrollView}
                        contentContainerStyle={{ backgroundColor: gui.groupBackground, marginBottom: 0 }}
                    >
                        {/*<View style={styles.lineBold} />*/}
                        {this._renderMyAvatar()}
                        {/*<FullLine />*/}
                        {this._renderRowChatSupport("Chăm sóc khách hàng", "Trò chuyện trực tiếp với tư vấn viên.", "help-box", 20)}
                        {/*<FullLine />*/}
                        <View style={styles.lineBold} />
                        {/*<FullLine />*/}
                        <View style={{backgroundColor: '#fff'}}>
                            {/*<View style={styles.viewRowIcon}>*/}
                                {/*<View style={styles.viewTextChild}>*/}
                                    {/*<Text style={styles.textChild} numberOfLines={1}>Tiện ích mở rộng</Text>*/}
                                {/*</View>*/}
                            {/*</View>*/}
                            {/*<FullLine style={{marginLeft: 16, marginRight: 0}}/>*/}
                            {this._renderRowProfile("Tin đã lưu", heartImg, {width: 30, height: 30}, this._onAdsSavedMgmt.bind(this))}
                            <FullLine style={{marginLeft: 70, marginRight: 0}}/>
                            {this._renderRowEvent("Quản lý công việc", listImg, 22)}
                            <FullLine style={{marginLeft: 70, marginRight: 0}}/>
                            {this._renderRowProfile("Tính tiền vay", moneyImg, {width: 31, height: 31}, this._onTinhTienVayPress.bind(this))}
                            <FullLine style={{marginLeft: 70, marginRight: 0}}/>
                            {this._renderRowProfile("Tin tức bất động sản", newsImg, {width: 29, height: 31}, this._onNewsList.bind(this))}
                            <FullLine style={{marginLeft: 70, marginRight: 0}}/>
                            {this._renderRowProfile("Định giá nhà", homeImg, {width: 31, height: 31}, this._onDinhGiaPress.bind(this))}
                            <FullLine style={{marginLeft: 70, marginRight: 0}}/>
                            {this._renderRowProfile("Phong thủy", huongNhaImg, {width: 31, height: 31}, this._onXemHuongNha.bind(this))}
                            {/*<FullLine style={{marginLeft: 52, marginRight: 16}}/>*/}
                            {/*this._renderRowProfile("Tra cứu sổ đỏ", 'credit-card-front', 22, this._onTraCuuSoDo.bind(this))*/}
                            {/*<FullLine style={{marginLeft: 16}}/>*/}
                            {/*this._renderRowContact("Danh bạ khách hàng", "account-box", 20)*/}
                            {/*<FullLine />*/}
                            {/*{this._renderRowProfile("Bài đăng", "home-outline", 20, this._onPostAdsPress.bind(this))}*/}
                            {/*<FullLine />*/}
                            {/*this._renderRowProfile("Thông tin tài khoản", this._onNapTienPress.bind(this))*/}
                            {/*<FullLine style={{marginLeft: 16}}/>*/}
                            {/*this._renderRowProfile("Lịch sử giao dịch", this._onCoinHistoryPress.bind(this))*/}
                            {/*<FullLine />*/}
                        </View>
                        <View style={styles.lineBold} />
                        {/*<FullLine />*/}
                        <View style={{backgroundColor: '#fff'}}>
                            {/*{this._renderRowProfile("Cài đặt","settings", 20, this._onSettingPress.bind(this))}*/}
                            {this._renderRowProfile("Thông tin & Hỗ trợ", helpImg, {width: 31, height: 31}, this._onHelpAgent.bind(this))}
                            <FullLine style={{marginLeft: 70}}/>
                            {this._renderNewSetting()}
                            <FullLine style={{marginLeft: 70}}/>
                            {/*this._renderRowProfile("Hỗ trợ", "help-circle", 20, this._onHelpPress.bind(this))*/}
                            {/*<FullLine />*/}
                            {/*{this._renderRowSignInOut()}*/}
                            {this._renderRowProfileOut("Đăng xuất", logoutImg, {width: 30, height: 31}, this._onSignInOutPress.bind(this))}
                        </View>
                    </ScrollView>
                {/*<View style={styles.lineBottom} />*/}
            </View>
        );
    }

    _onXemHuongNha() {
        Actions.XemHuongNha();
    }

    _onNewsList() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this._showNewsList();
            }});
        } else {
            this._showNewsList();
        }
    }

    _showNewsList() {
        Actions.NewsList({owner: 'MyProfile'});

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_PROFILE_NEWS', { deviceID: deviceID, userID: userID });
    }

    _onAdsSavedMgmt() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this._onPressSavedMgmt();
            }});
        } else {
            this._onPressSavedMgmt();
        }
    }

    _onTraCuuSoDo() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction : () => {
                this._onPressTraCuSoDo();
            }});
        } else {
            this._onPressTraCuSoDo();
        }
    }    

    _onPressTraCuSoDo() {
        Actions.TraCuuSoDo();
    }

    _onPressSavedMgmt() {
        Actions.AdsMgmt2();

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_PROFILE_ADS_LIKES', { deviceID: deviceID, userID: userID });
    }

    _renderRowChatSupport(title, subtitle, iconName, size) {
        let supportUri = require('../../assets/image/p_support.png');
        return (
            <TouchableOpacity onPress={this._onDisplayMessenger.bind(this)} style={styles.viewNewSupport}>
                <View style={styles.viewIconSupport}>
                    <Image
                        style={styles.supportIcon}
                        resizeMode={Image.resizeMode.cover}
                        source={supportUri}
                    />
                </View>
                <View style={styles.viewContentSupport}>
                    <Text style={[styles.textChild, { color: gui.mainAgentColor, fontSize: 15 }]} numberOfLines={1}>{title}</Text>
                    <Text style={[styles.textChild, { fontSize: 13, color: 'rgba(178,178,178,1)' }]} numberOfLines={1}>{subtitle}</Text>
                </View>
                {/*<View style={styles.viewIcon}>*/}
                    {/*<TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}*/}
                                {/*noAction={true}*/}
                    {/*>*/}
                    {/*</TruliaIcon>*/}
                {/*</View>*/}
            </TouchableOpacity>
        );
    }

    _onDisplayMessenger() {
        try {
            if (!this.props.global.loggedIn) {
                Intercom.reset().then(() => {
                    Intercom.registerUnidentifiedUser()
                        .then(() => {
                            Intercom.displayMessenger();
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            } else {
                let userID = this.props.global.currentUser.userID || undefined;
                let email = this.props.global.currentUser.email || undefined;
                let phone = this.props.global.currentUser.phone || undefined;
                let name = this.props.global.currentUser.username || undefined;
                let fullName = this.props.global.currentUser.fullName || undefined;
                if (fullName) {
                    name = fullName;
                }
                let avatar = this.props.global.currentUser.avatar || undefined;
                Intercom.reset().then(() => {
                    Intercom.registerIdentifiedUser({ userId: userID })
                        .then(() => {
                            log.info('registerIdentifiedUser done');

                            return Intercom.updateUser({
                                email: email,
                                phone: phone,
                                name: name,
                                avatar: { type: 'avatar', image_url: avatar }
                            })
                                .then(() => {
                                    Intercom.displayMessenger();
                                });
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            }

        } catch (error) {
            log.warn('========== onDisplayMessenger ERROR', error);
        }
    }

    _onPostAdsPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction: this._doPostAds.bind(this) });
        } else {
            this._doPostAds();
        }
    }

    _doPostAds = async () => {
        StatusBar.setBarStyle('default');
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.onGroupFieldChange('textSearchAds', '')
        /*await*/
        this.props.actions.loadMySellRentList(userID)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    setTimeout(() => {
                        let adsList = [];
                        res.data.forEach((e) => {
                            // log.info('calling getwtomatchingads ***', e)
                            adsList.push({
                                id: e.adsID,
                                loaiTin: e.loaiTin,
                                status: e.status,
                                gia: e.gia,
                                dienTich: e.dienTich,
                                soPhongNgu: e.soPhongNgu,
                                soPhongTam: e.soPhongTam,
                                soTang: e.soTang,
                                loaiNhaDat: e.loaiNhaDat,
                                huongNha: e.huongNha,
                                place: e.place,
                            })
                        })
                        this.props.actions.getWtoMatchingAds(
                            {
                                'userID': this.props.global.currentUser.userID,
                                'adsList': adsList
                            }
                            , (res) => {
                                // Actions.pop()
                            }
                            , (error) => {
                                // Actions.pop()
                            });
                    }, 300);
                }
            });
            
        Actions.NewAgentPost();
    }

    _onDinhGiaPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({ doFinalAction: this._doDinhGia.bind(this) });
        } else {
            this._doDinhGia();
        }
    }

    _onHelpAgent() {
        Actions.AboutLandber();
    }

    _doDinhGia() {
        this.onLogEvent("Định giá");
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_DINHGIA', { deviceID: deviceID, userID: userID });
        Actions.DinhGia2();
    }

    _onHelpPress() {
        let link = cfg.serverUrl + "/bao-gia";
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                log.info('Can\'t handle url: ' + link);
            } else {
                Linking.openURL(link);
            }
        }).catch(err => log.error('An error occurred', link, err));
    }

    _onSettingPress() {
        Actions.Setting();
        //  Actions.IntroAgent();
    }

    _onCoinHistoryPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                    this._showCoinHistory();
                }
            });
        } else {
            this._showCoinHistory();
        }
    }

    _showCoinHistory() {
        this.props.actions.getTopupLog(this.props.global.currentUser.userID, this.props.global.currentUser.token);
        Actions.CoinHistory();
    }

    _onTinhTienVayPress() {
        this.onLogEvent("Tính tiền vay");
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_PROFILE_TIENVAY', { deviceID: deviceID, userID: userID });
        Actions.VayUocTinh3();
    }

    onLogEvent(title) {
        let eventDto = {
            scene: "MyProfile",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onNapTienPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                    this._showNapTien();
                }
            });
        } else {
            this._showNapTien();
        }
    }

    _showNapTien() {
        let currentUser = this.props.global.currentUser;
        this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
            (res) => {
                if (res.status == 0) {
                    Actions.MoneyInPayment();
                } else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        );
    }

    _renderRowSignInOut() {
        return (
                <TouchableOpacity style={[styles.viewRowIcon, {paddingLeft: 16, paddingRight: 16, height: 68}]}
                                  onPress={this._onSignInOutPress.bind(this)}
                >
                    <View style={styles.viewIconSetting}>
                        <FontAwesomeLight name={"sign-out-alt"} size={20} color={"#ff0000"} noAction={true} iconOnly={true} />
                    </View>
                    <View style={styles.viewTextSetting}>
                        <Text style={styles.textChild} numberOfLines={1}>Đăng xuất</Text>
                    </View>
                </TouchableOpacity>

        );
    }

    _onSignInOutPress() {
        LoginManager.logOut();
        if (this.props.global.loggedIn) {
            Alert.alert('Đăng xuất', 'Bạn có muốn đăng xuất không?',
                [{ text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
                { text: 'Đồng ý', onPress: () => this._onSignInOut() }
                ]);
        } else {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                }
            });
        }

    }

    _onSignInOut() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                }
            });
        } else {
            this.props.actions.logout(this.props.global.currentUser);
            LoginManager.logOut();
            this.props.actions.onRegisterFieldChange('fbToken', '');
            this.props.actions.onRerenderHomeChange(true);
            this.props.actions.onRerenderSearchChange(true);
            dismissKeyboard();
            let { deviceID } = this.props.global.deviceInfo;
            if (deviceID) {

                const eventName = "af_logout";
                const eventValues = {
                    "af_success": "true",
                    "af_customer_user_id": deviceID
                };

                Analytics.logEvent('logout', {
                    'userID': deviceID
                });
            }
            Actions.NewLogin({ type: 'reset', disableBackButton: true });
        }
    }

    renderNewHeader() {

        let numberInbox = 0;
        if (this.props.inbox.listHomeInbox) {
            let allGroupInboxDS = this.props.inbox.listHomeInbox.filter((one) => {
                    let valid = one.content != undefined && (!one.spamStatus || (one.spamStatus != 1 && one.spamStatus != 2));
                    return valid && !!one.numOfUnreadMessage;
                }) || [];
            numberInbox = allGroupInboxDS.length;
        }

        return(
            <View style={styles.viewNewHeader}>
                <TouchableOpacity style={styles.viewDoneTouch}
                                  //onPress={this.onBackPress.bind(this)}
                                  onPress={this.onPressChat.bind(this)}
                >
                    <View style={{padding: 0}}>
                        <FontAwesomeLight name="comment-dots" size={24} color={gui.mainColor} noAction={true} iconOnly={true} />
                        {numberInbox ?
                            <View style={styles.numberOfMessage2}>
                                <Text style={styles.numberInbox}>{numberInbox}</Text>
                            </View>
                            : null
                        }
                    </View>
                </TouchableOpacity>
                <View style={styles.mainNewHeader}>
                    <Text style={[styles.textChild, {color: gui.textAgentSolid}]}>Cá nhân</Text>
                </View>
                <TouchableOpacity style={styles.viewDoneTouch}
                                  onPress={this.onPressMyAlert.bind(this)}
                >
                    <View style={{padding: 0}}>
                        <FontAwesomeLight name="bell" size={23} color={gui.mainColor} noAction={true} iconOnly={true} />
                        {this.props.me.pushMessage == 1 ?
                            (<View style={styles.notification}>
                            </View>)
                            : null
                        }
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    onPressChat() {
        Actions.GroupInbox();

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_PROFILE_INBOX', { deviceID: deviceID, userID: userID });
    }

    onPressMyAlert() {
        Actions.MyAlert();

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_PROFILE_NOTIFICATION', { deviceID: deviceID, userID: userID });
    }

    onBackPress() {
        Actions.pop();
    }

    _renderMyAvatar() {
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let uriAvatar = this.props.global.currentUser.avatar ? { uri: this.props.global.currentUser.avatar } :
            defaultAvatar;
        return (
            <TouchableOpacity style={styles.viewMyAvatar}
                onPress={this._onProfile.bind(this)}
            >
                <Image
                    source={uriAvatar}
                    style={styles.myAvatar}
                    defaultSource={defaultAvatar}
                />
                {this._renderLoginCurrent()}
            </TouchableOpacity>
        )
    }

    _renderLoginCurrent() {
        let userName = this.props.global.currentUser.fullName || this.props.global.currentUser.username || '';
        let textHoSo = 'Sửa hồ sơ';
        let textEmpty = 'Đăng nhập để có trải nghiệm tốt hơn!';
        if (userName && userName.length > 0) {
            return (
                <View style={styles.viewUserName}>
                    <View style={styles.myUserName}>
                        <Text style={[styles.textUserName, { fontSize: 24 }]} numberOfLines={1}>{userName}</Text>
                    </View>
                    {this.props.global.loggedIn ?
                        <View style={{flexDirection: 'row', marginTop: 21}}>
                            <FontAwesomeSolid name="pen" size={12} color={gui.mainColor}
                                              mainProps={{marginTop: 3}}
                                              noAction={true} iconOnly={true} />
                            <Text style={[styles.textHoSo, {marginTop: 0, marginLeft: 8}]}>{textHoSo}</Text>
                        </View>
                        : null}
                </View>
            );
        }
        return (
            <View style={styles.viewUserName}>
                <Text style={styles.textUserName}>{textEmpty}</Text>
            </View>
        );
    }

    _onProfile() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                }
            });
        } else {
            let currentUser = this.props.global.currentUser;
            this.props.actions.profile(currentUser.userID, currentUser.token).then(
                (res) => {
                    if (res.success) {
                        Actions.Profile();

                        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
                        let userID = this.props.global.currentUser.userID || undefined;
                        Analytics.logEvent('AGENT_PROFILE_MODIFY', { deviceID: deviceID, userID: userID });
                    } else {
                        Alert.alert('Thông báo', 'Tải thông tin cá nhân không thành công.');
                    }
                }
            );
        }
    }

    _renderNewSetting() {
        let settingsImg = require('../../assets/image/p_settings.png');
        return (

            <TouchableOpacity style={[styles.viewRowIcon, {height: 68}]}
                              onPress={this._onSettingPress.bind(this)}
            >
                <View style={styles.viewChildIcon}>
                    <Image
                        style={{width: 31, height: 31}}
                        resizeMode={Image.resizeMode.cover}
                        source={settingsImg}
                    />
                </View>
                {this._renderNewUpdate()}
                <View style={styles.viewTextChild}>
                    <Text style={styles.textChild} numberOfLines={1}>Thiết lập ứng dụng</Text>
                </View>
                <View style={styles.viewIcon}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        )
    }

    _renderNewUpdate() {
        if (this.state.isNeedUpdate) {
            return (
                <View style={[styles.viewNoti, { backgroundColor: '#ff0000', top: 11 }]} />
            )
        }
        else return null;
    }

    _renderRowProfile(value, imageSource, iconStyle, onPress) {
        let onPressEvent = onPress ? onPress : () => { };
        return (
            <TouchableOpacity style={[styles.viewRowIcon, {height: 68}]}
                onPress={onPressEvent}
            >
                <View style={styles.viewChildIcon}>
                    <Image
                        style={iconStyle}
                        resizeMode={Image.resizeMode.cover}
                        source={imageSource}
                    />
                </View>
                <View style={styles.viewTextChild}>
                    <Text style={styles.textChild} numberOfLines={1}>{value}</Text>
                </View>
                <View style={styles.viewIcon}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }


    _renderRowProfileOut(value, imageSource, iconStyle, onPress) {
        let onPressEvent = onPress ? onPress : () => { };
        return (
            <TouchableOpacity style={[styles.viewRowIcon, {height: 68}]}
                              onPress={onPressEvent}
            >
                <View style={styles.viewChildIcon}>
                    <Image
                        style={iconStyle}
                        resizeMode={Image.resizeMode.cover}
                        source={imageSource}
                    />
                </View>
                <View style={styles.viewTextChild}>
                    <Text style={styles.textChild} numberOfLines={1}>{value}</Text>
                </View>
            </TouchableOpacity>
        );
    }


    _renderRowContact(value, iconName, size) {
        return (
            <TouchableOpacity onPress={this._onContactPress.bind(this)} style={styles.viewRowIcon}>
                <View style={styles.viewTextChild}>
                    <Text style={styles.textChild} numberOfLines={1}>{value}</Text>
                </View>
                <View style={styles.viewIcon}>
                    <MaterialCommunityIcons name={iconName} color={gui.mainTextColor} size={size} />
                </View>
            </TouchableOpacity>
        );
    }

    _renderRowEvent(value, listImg, size) {
        return (
            <TouchableOpacity onPress={this._onEventPress.bind(this)} style={[styles.viewRowIcon, {height: 68}]}>
                <View style={styles.viewChildIcon}>
                    <Image
                        style={{width: 27, height: 32}}
                        resizeMode={Image.resizeMode.cover}
                        source={listImg}
                    />
                </View>
                <View style={styles.viewTextChild}>
                    <Text style={styles.textChild} numberOfLines={1}>{value}</Text>
                </View>
                <View style={styles.viewIcon}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _onContactPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                    this.props.actions.getAllContact(
                        { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
                        , (res) => {
                        }
                        , (error) => {
                            console.log('server respond error: =====>>>>>', error)
                        });
                    Actions.Contact({ owner: 'MyProfile' });
                }
            });
        } else {
            this.props.actions.getAllContact(
                { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
                , (res) => {
                }
                , (error) => {
                    console.log('server respond error: =====>>>>>', error)
                });
            Actions.Contact({ owner: 'MyProfile' });
        }
    }

    _onEventPress() {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin({
                doFinalAction: () => {
                    this.props.actions.onRerenderHomeChange(true);
                    this.props.actions.onRerenderSearchChange(true);
                    // this.props.actions.onEventFieldChange('eventList', [])
                    this.props.actions.getAllCalendarEvent(
                        {
                            'userID': this.props.global.currentUser.userID,
                            'startDateTimeFrom': this.props.event.startDateTimeFrom,
                            'startDateTimeTo': this.props.event.startDateTimeTo
                        }
                        , (res) => {
                            // console.log('server respond data: =====>>>>>', res)
                        }
                        , (error) => {
                            console.log('server respond data: =====>>>>>', error)
                        });
                    Actions.CalendarEvent({owner:'MyProfile', isOpenMoreCalendarModal: false, selectedEvent: null });

                    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
                    let userID = this.props.global.currentUser.userID || undefined;
                    Analytics.logEvent('AGENT_PROFILE_CALENDAR_EVENTS', { deviceID: deviceID, userID: userID });
                }
            });
        } else {
            // this.props.actions.onEventFieldChange('eventList', [])
            this.props.actions.getAllCalendarEvent(
                {
                    'userID': this.props.global.currentUser.userID,
                    'startDateTimeFrom': this.props.event.startDateTimeFrom,
                    'startDateTimeTo': this.props.event.startDateTimeTo
                }
                , (res) => {
                    // console.log('server respond data: =====>>>>>', res)
                }
                , (error) => {
                    console.log('server respond data: =====>>>>>', error)
                });
            Actions.CalendarEvent({owner:'MyProfile', isOpenMoreCalendarModal: false, selectedEvent: null });

            let deviceID = this.props.global.deviceInfo.deviceID || undefined;
            let userID = this.props.global.currentUser.userID || undefined;
            Analytics.logEvent('AGENT_PROFILE_CALENDAR_EVENTS', { deviceID: deviceID, userID: userID });
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: gui.groupBackground
    },
    scrollView: {
        flex: 1,
        marginBottom: 50
    },
    viewMyAvatar: {
        height: 'auto',
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: gui.groupBackground
    },
    viewUserName: {
        height: 42,
        // width: width,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        // marginTop: 14
    },
    myUserName: {
        height: 24,
        // width: width,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textUserName: {
        color: gui.textAgentSolid,
        fontSize: 23,
        fontFamily: gui.fontFamily
    },
    textHoSo: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        marginTop: 6
    },
    myAvatar: {
        width: 70,
        height: 70,
        borderRadius: 35,
        borderWidth: 1,
        borderColor: gui.mainTextColor3,
        margin: 16
    },
    boldLine: {
        height: 16,
        width: width,
        backgroundColor: gui.groupBackground
    },
    viewRowIcon: {
        height: 44,
        width: width,
        // paddingLeft: 16,
        // paddingRight: 16,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewChildIcon: {
        height: 68,
        width: 70,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewIconSetting: {
        height: 44,
        width: 22,
        justifyContent: 'center'
    },
    viewTextSetting: {
        height: 44,
        width: width -32 - 22,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewNewSupport: {
        height: 85,
        width: width,
        // paddingLeft: 8,
        // paddingRight: 8,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewTextChild: {
        height: 68,
        width: width - 64 - 70,
        justifyContent: 'center'
    },
    textChild: {
        color: gui.textAgentSolid,
        fontSize: 17,
        fontFamily: gui.fontFamily
    },
    viewIcon: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewIconSupport: {
        height: 85,
        width: 80,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewContentSupport: {
        height: 85,
        width: width - 38 - 80,
        paddingRight: 8,
        justifyContent: 'center',
        backgroundColor: '#fff'
    },
    supportIcon: {
        height: 45,
        width: 45
    },
    lineBold: {
        height: 16,
        width: width,
        backgroundColor: gui.groupBackground
    },
    lineBottom: {
        flex: 1,
        backgroundColor: gui.groupBackground,
        marginBottom: 50
    },
    viewNoti: {
        height: 6,
        width: 6,
        borderRadius: 3,
        backgroundColor: '#ff0000',
        position: 'absolute',
        top: 15,
        left: 43
    },
    viewNewHeader: {
        height: 64,
        width: width,
        flexDirection: 'row',
        // paddingRight: 16,
        // paddingLeft: 16,
        backgroundColor: '#fff'
    },
    viewDoneTouch: {
        height: 64,
        width: 46,
        justifyContent: 'center',
        paddingTop: 20
    },
    mainNewHeader: {
        // width: width - 112,
        flex: 1,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 20
    },
    notification: {
        position: 'absolute',
        backgroundColor: '#ff0000',
        top: -2,
        right: 6,
        alignSelf: 'auto',
        width: 6,
        height: 6,
        borderRadius: 3,
        justifyContent: 'center',
        alignItems: 'center'
    },
    numberOfMessage2: {
        height: 16,
        width: 16,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: -3,
        // left: 0,
        right: 12,
        backgroundColor: '#ff0000'
    },
    numberInbox: {
        fontSize: 8,
        color: '#fff',
        backgroundColor: 'transparent'
    },
});


export default connect(mapStateToProps, mapDispatchToProps)(MyProfile);