import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TextInput,
    Alert,
    KeyboardAvoidingView,
    StatusBar,
    FlatList,
    Animated,
    Platform,
    PixelRatio,
    ImageBackground,
    Linking
} from 'react-native';

import FontAwesomeLight from '../font/FontAwesomeLight';
import LinearGradient from 'react-native-linear-gradient';
import DanhMuc from '../../assets/DanhMuc';
import OfflineBar from '../line/OfflineBar';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import RelandIcon from '../RelandIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import ImagePreview from './ImagePreview';
import GiftedSpinner from "../GiftedSpinner";
import dismissKeyboard from 'react-native-dismiss-keyboard';
import ScalableText from 'react-native-text';
import Toast, { DURATION } from '../toast/Toast';
import moment from 'moment';
import userApi from '../../lib/userApi';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as wallActions from '../../reducers/wall/wallActions';
import { Map } from 'immutable';

import gui from '../../lib/gui';
import { Actions } from 'react-native-router-flux';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Modal from 'react-native-modalbox';
import FunctionModal from '../FunctionModal'
import UserModal from '../UserModal';
import KeyboardSpacer from 'react-native-keyboard-spacer';

let imageGroup = 188;
const MAX_LENGTH = 300;

const actions = [
    globalActions,
    meActions,
    groupActions,
    wallActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_listComment = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

class GroupComment extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');

        this._firstDisplay = true;
        this._listHeight = 0;
        this._contentHeight = 0;
        this._scrollToBottomOnNextRender = false;
        this._scrollToPreviousPosition = false;
        this.listViewMaxHeight = height - 112;

        this.state = {
            loading: false,
            disabled: true,
            height: new Animated.Value(this.listViewMaxHeight),
            appearAnim: new Animated.Value(0),
            dropdownSelection: '',
            listHeight: 0,
            scrollViewHeight: 0,
            isOpenMoreModal: false,
            selectedComment: null,
            isEditOldComment: false,
            // valueComment: '',
            toggleKeyboard: false,
            commentContent: props.wall.commentContent,
            commentList: props.wall.commentList,
            userLikeList: props.wall.userLikeList,
            expandedComment: [],
            userModalData: null
        }
    }


    componentWillMount() {
        setTimeout(() => this.fetchData(), 300);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        //Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.wall.commentContent !== this.props.wall.commentContent) {
            this.setState({
                commentContent: nextProps.wall.commentContent
            });
        }
        if (nextProps.wall.commentList !== this.props.wall.commentList) {
            this.setState({ commentList: nextProps.wall.commentList })
            if (this.isLastMessageVisible()) {
                this._scrollToBottomOnNextRender = true;
            }
        }

        if (nextProps.wall.userLikeList !== this.props.wall.userLikeList) {
            this.setState({ userLikeList: nextProps.wall.userLikeList })
        }
    }

    isLastMessageVisible() {
        return this.state.commentList && this.state.commentList.length > 0;
    }

    componentDidMount() {
        this.scrollResponder = this.scrollView.getScrollResponder();
    }

    fetchData() {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.props.actions.getWallComment(
            {
                'groupWallID': this.props.groupWallID
            }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
                //query user like this post
                this.props.actions.getUserLike({'groupWallID': this.props.groupWallID}, 
                (res2) => {
                    this.refreshRowData(res.data);
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, (Platform.OS === 'android' ? 200 : 100));
                }, (error) => {
                    this.setState({ loaded: true });
                    this._updateMessageProcessing(error, '#fa4916', 'white');
                })
            }
            , (error) => {
                this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'commentList': data,
            loaded: true
        });
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderComment()}
                <FullLine />
                {this._renderListComment()}
                {this._renderTextInputComment()}
                {this.props.wall.showImagePreview ? this._renderImagePreviewModal(this.state.pickedRow) : null}
                {this._renderLoadingView()}
                {this._openGroupCommentUserModal()}
                {this._openMoreModal()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        );
    }

    _openGroupCommentUserModal() {
        let groupName = 'Cộng đồng Landber Agent';

        return (
            <Modal isOpen={this.state.isOpenUserModal}
                onClosed={this.closeUserModal.bind(this)}
                style={styles.viewUserModal}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                <UserModal groupName={groupName}
                    data={this.state.userModalData}
                    onClosePress={this.closeUserModal.bind(this)}
                />
            </Modal>
        );
    }

    _onUserCommentPress(data) {
        // log.info("========== _onGroupWallUserPress print user data ", data);
        this.setState({
            isOpenUserModal: true,
            userModalData: data
        })
    }

    closeUserModal() {
        this.setState({
            isOpenUserModal: false,
            userModalData: null
        })
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        let modalHeight = 173;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {

        let items = [
            { _text: 'Sửa bình luận', _function: () => this._onEditCommentPress() },
            { _text: 'Xóa bình luận', _function: () => this._onDeleteCommentPress() },
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outMoreModal.bind(this)} />
        )
    }

    _onEditCommentPress() {
        this.setState({ isEditOldComment: true });

        let selectedComment = this.state.selectedComment;
        if (!selectedComment) {
            return;
        }
        let userID = this.props.global.currentUser.userID;

        this.props.actions.onWallFieldChange('commentID', selectedComment.id);
        this.onValueChange('commentContent', selectedComment.content);
        // this.props.actions.onWallFieldChange('commentContent', selectedComment.content);

        // Actions.Group();
        this.refs.commentInput.focus();
        this._outMoreModal();
    }

    _onDeleteCommentPress() {
        let selectedComment = this.state.selectedComment;
        if (!selectedComment) {
            return;
        }
        Alert.alert('Thông báo', 'Bạn muốn xóa bình luận?',
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let commentID = selectedComment.id;
                    let token = this.props.global.currentUser.token;
                    let dto = {
                        id: commentID,
                        groupWallID: selectedComment.groupWallID
                    }
                    let deleteCommentAlertDto = {
                        fromUserID: selectedComment.createdBy,
                        groupWallID: selectedComment.groupWallID,
                        groupID: selectedComment.groupID,
                        action: 'delete',
                        commentDto: selectedComment
                    };
                    this.props.actions.deleteComment(dto, token, deleteCommentAlertDto, this.props.owner)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            } else {
                                let userID = this.props.global.currentUser.userID || undefined;
                                // this.fetchData();
                                //re-new data
                                let commentList = this.state.commentList;
                                commentList = commentList.filter((e) => { return (e.id != commentID) })
                                this.setState({ commentList: commentList.slice(0) })
                                this.props.actions.onWallFieldChange('commentList', commentList.slice(0))

                                this.onValueChange('commentContent', '');
                                // this.props.actions.onWallFieldChange('commentContent', '');
                            }
                        });
                    this._outMoreModal();
                }
            }
            ]);
    }

    renderFooterComment(data) {
        // log.info('================> data', data);
        let sourceEmpty = require('../../assets/image/icon_comment.png');
        let commentEmpty = 'Hãy là người đầu tiên bình luận!';
        if (data && data.length == 0 && !this.props.wall.loadingComment) {
            return (
                <View style={styles.viewEmptyComment}>
                    <Image style={styles.imageEmptyHistory}
                        source={sourceEmpty}
                        defaultSource={sourceEmpty}
                        resizeMode={'cover'}
                    />
                    <Text style={[styles.textEmpty, { marginTop: 16 }]}>{commentEmpty}</Text>
                </View>
            )
        } else return null;
    }

    _renderParentContent(data) {

        if (data.adsList && data.adsList.length > 0 && (data.adsList[0].id || data.adsList[0].adsID))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderAdsImagePost(data)}
                    {this._renderDetailPost(data)}
                    {this._renderCommentCount(data)}
                </View>
            );
        if (data.wtoList && data.wtoList.length > 0 && (data.wtoList[0].id))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderWtoPost(data)}
                    {this._renderCommentCount(data)}
                </View>
            );
        if (data.image && (data.image.cover || data.image.images && data.image.images.length > 0))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderSimpleImagePost(data)}
                    {this._renderCommentCount(data)}

                </View>
            );
        return (
            <View style={styles.viewListMyGroup}>
                {this._renderRowTopContent(data)}
                {this._renderCommentCount(data)}

            </View>
        );
    }

    _renderCommentCount(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let commentCount = this.state.commentList ? this.state.commentList.length : 0;
        let commentValue = commentCount + ' Bình luận';
        let viewsValue = data.viewsValue;

        return (
            <View style={styles.viewDetailPostComment}>

                <View style={[styles.lineDangNhap, { width: width - 16 }]} />
                <View style={[styles.viewLikeComment]}>
                    <Text style={[styles.textMainUser, { fontWeight: 'normal', fontSize: 15, color: gui.textComment }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >
                        {commentValue}
                    </Text>
                </View>
                <View style={[styles.lineDangNhap, { width: width }]} />
            </View>
        )
    }

    _renderWtoPost(data) {
        // log.info('===========> groupwal2 _renderRowWto',status);

        if (data.wtoList && data.wtoList.length > 0) {
            data = data.wtoList[0];
        }
        let content = data.content;
        let priceRange = 'Giá:'

        let giaTuFmt = utils.getPriceDisplay(content.giaTu, content.loaiTin);
        if (giaTuFmt != DanhMuc.THOA_THUAN) {
            title += `${giaTuFmt}`;
        }

        let giaDenFmt = utils.getPriceDisplay(content.giaDen, content.loaiTin);
        if (giaDenFmt != DanhMuc.THOA_THUAN) {
            title += ` - ${giaDenFmt}`;
        }

        let diaChi = '';
        let title = utils.getTitleWtoDetail(data.content)

        return (
            <View style={styles.viewAdsWto}>
                <TouchableOpacity style={styles.viewRowPostWto} onPress={() => this._onPressWto(data)}>
                    {this._renderDetailWtoPost(data)}
                </TouchableOpacity>
            </View>
        )
    }

    _renderDetailWtoPost(data) {
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))
        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;

        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;

        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        let diaChiFullName = data.content.place.fullName || ' ';
        return (
            <View style={[styles.viewDetailPost2, { height: 'auto' }]}>
                <View style={styles.viewTieuDe}>
                    <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                        <Text style={styles.textTypePost}>{priority}</Text>
                    </View>
                    <View style={styles.viewTextTieuDe}>
                        <Text style={styles.textTieuDe} numberOfLines={1}>{diaChiFullname}</Text>
                    </View>
                </View>
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { fontWeight: '500' }]} numberOfLines={1}>{giaNha}</Text>
                </View>
                <View style={[styles.viewLabel, { marginTop: 6 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 48 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { color: gui.textPostCommon }]}>{diaChiFullName}</Text>
                    </View>
                </View>
                {
                    detailItems && detailItems.length > 0 ?
                        <View style={[styles.viewPercentDraft, { flexDirection: 'row' }]}>
                            {detailItems}
                        </View> : null
                }
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { color: '#898989' }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                </View>
            </View>
        );
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="compass" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="bath" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostAds} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }


    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _renderDetailPost(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let areaValue = utils.getDienTichDisplay(ads.dienTich);
        let bedroomValue = ads.soPhongNgu;
        let bathroomValue = ads.soPhongTam;
        let huongNha = ads.huongNha ? DanhMuc.HuongNha[ads.huongNha] : '';
        let addressValue = '';
        let textMotionValue = '';
        if (ads.place) {
            addressValue = ads.place.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail(ads);
        } else {
            addressValue = ads.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail2(ads);
        }
        let timePostValue = ads.ngayDangTin ? utils.formatDate(ads.ngayDangTin) : '';
        let commentCount = this.state.commentList ? this.state.commentList.length : 0;

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }

        if (!!huongNha) {
            detailItems.push(this._renderHuongNha(huongNha, (detailItems.length == 0) ? 0 : 12));
        }

        return (
            <View style={styles.viewDetailPost}>
                <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}>
                    <View style={styles.viewMainTextPost}>
                        <Text style={[styles.textMainPost, { color: gui.textAgentSolid }]} numberOfLines={2}>{textMotionValue}</Text>
                        <Text style={[styles.textTimePost, { color: gui.textComment, marginTop: 2 }]} numberOfLines={1}>{timePostValue}</Text>
                    </View>
                    <View style={styles.lineDangNhap} />
                    {this._renderGiaFmt(data)}
                    <View style={styles.viewTextAddress}>
                        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
                        <Text style={[styles.textMainMinute, { marginLeft: 8, color: gui.textPostAds, fontSize: 15 }]} numberOfLines={1}>{addressValue}</Text>
                    </View>
                    <View style={styles.viewContentSource}>
                        {detailItems}
                    </View>
                </TouchableOpacity>
            </View>
        )
    }


    _renderGiaFmt(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        let giaFmt = `Giá: ${priceValue}`;
        return (
            <View style={styles.viewGiaFmt}>
                <Text style={styles.textPriceFmt}>{giaFmt}</Text>
            </View>
        );
    }

    _renderRowTopContent(data, topRowStyles) {
        let avatarUrl = data.avatar || data.createdByAvatar || '';
        let userAvatar = { uri: avatarUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!avatarUrl) {
            userAvatar = defaultAvatar;
        }
        let textPromote = data.content || '';
        let nameMainUser = data.fullName || data.createdByName || '';
        let timePost = utils.getDiffTime(data.timeCreated) || '';
        return (
            <View style={[styles.viewRowTopContent, topRowStyles]}>
                <View style={styles.viewMainUser}>
                    <Image
                        resizeMode={"cover"}
                        source={userAvatar}
                        defaultSource={defaultCover}
                        style={styles.mainUserAvatar} />
                    <View style={styles.viewUserContent}>
                        <Text numberOfLines={1} style={[styles.textMainUser, { fontSize: 15, color: gui.textAgentSolid }]}>{nameMainUser}</Text>
                        <Text style={[styles.textMainMinute, { fontSize: 12 }]}>{timePost}</Text>
                    </View>
                    {/* <TouchableOpacity onPress={this.onChat.bind(this, data)} style={styles.viewIconBubble}>
                        <MaterialIcons name="chat-bubble" size={19} color={gui.mainTextColor}/>
                    </TouchableOpacity> */}

                </View>
                <Text style={[styles.textSearch, { marginTop: 16, color: gui.textAgentSolid }]}>{textPromote}</Text>
            </View>
        );
    }

    _renderAdsImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let adsCoverPhoto = { uri: ads.image ? ads.image.cover : '' };
        if (!ads.image || !ads.image.cover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <View style={styles.imageContentRow}>
                {/*<View style={styles.viewBorderTopAds}>*/}
                {/*<View style={styles.viewBorderTopImage} />*/}
                {/*</View>*/}
                <ImageBackground style={[styles.imgItem, { height: gui.ADS_IMAGE_RATIO * width }]}
                    source={adsCoverPhoto} defaultSource={defaultCover}>
                    <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}>
                        <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                            style={styles.linearGradientMain}>
                            {this._renderUserLogo(data)}
                            {/*{this._renderNamePrice(data)}*/}
                        </LinearGradient>
                    </TouchableOpacity>
                </ImageBackground>
                {/*<View style={[styles.lineDangNhap2, {marginTop: 8, marginLeft: 8}]} />*/}
            </View>
        )
    }

    _onPressAdsRow(ads) {
        Actions.GroupAdsDetail({ adsID: ads.id || ads.adsID, imageDetail: ads.image.cover, owner: 'GroupWall' });
    }

    _onPressWto(data) {
        if (!data.phone) {
            this.props.actions.getUserInfo(data.userID)
                .then(res => {
                    if (res.status != 0) {
                        Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                    } else {

                        if (res.userInfo) {
                            data.phone = res.userInfo.phone
                            data.email = res.userInfo.email
                            data.fullName = res.userInfo.fullName
                            data.avatar = res.userInfo.avatar
                        }

                        Actions.AgentWtoDetail({ data: data });
                    }
                });
        } else Actions.AgentWtoDetail({ data: data });
    }

    _renderUserLogo(data) {
        let ads;
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let logoItems = [];
        let index = 0;

        if (ads && ads.banGap) {
            let marginLeft = index == 0 ? 0 : 8;
            let banGapText = ads.loaiTin ? DanhMuc.THUE_GAP : DanhMuc.BAN_GAP;
            logoItems.push(
                <View key={'logoBanGap'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{banGapText}</Text>
                </View>
            );
            index++;
        }


        if (ads && ads.chinhChuDangTin) {
            let marginLeft = index == 0 ? 0 : 8;
            logoItems.push(
                <View key={'logoChinhChuDangTin'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{DanhMuc.CHINH_CHU}</Text>
                </View>
            );
            index++;
        }

        return (
            <View style={styles.viewUserLogo}>
                {logoItems}
            </View>
        );
    }

    _renderNamePrice(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let imageChildUser = { uri: ads.avatar };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        let nameUserChild = ads.fullName;
        return (
            <View style={styles.viewNamePrice}>
                <View style={styles.viewPrice}>
                    <Text style={[styles.textNameGroup, { fontSize: 20 }]} numberOfLines={1}>{priceValue}</Text>
                </View>
                {/* <View style={styles.viewUserPostChild}>
                    <View style={styles.viewNameUserChild}>
                        <Text style={[styles.textNameChild, { color: '#fff' }]} numberOfLines={1}>{nameUserChild}</Text>
                    </View>
                    <Image
                        resizeMode={"cover"}
                        source={imageChildUser}
                        defaultSource={defaultCover}
                        style={styles.mainUserChild} />
                </View> */}
            </View>
        );
    }

    _renderSimpleImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let imageCover = {};
        if (data.image && data.image.cover) {
            imageCover = data.image.cover;
        }
        // if (data.image && data.image.length > 0) {
        //     if (data.image.constructor === Array && data.image.length > 0) {
        //         imageCover = data.image[0];
        //     } else {
        //         imageCover = data.image;
        //     }
        // }
        let adsCoverPhoto = { uri: imageCover };
        if (!imageCover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <View style={styles.imageContentRow}>
                <TouchableOpacity
                    onPress={this._onImagePreviewPressed.bind(this, data)}
                    underlayColor="transparent" >
                    <View>
                        <ImageBackground style={[styles.imgItem, { height: gui.ADS_IMAGE_RATIO * width }]}
                            source={adsCoverPhoto} defaultSource={defaultCover}>
                            <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                                style={styles.linearGradientMain}>
                            </LinearGradient>
                            {this._renderTotalPhoto(data)}
                        </ImageBackground>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _onImagePreviewPressed(data) {
        if (!data.image) {
            return;
        }
        if (this.props.wall.showImagePreview) {
            return;
        }
        this.props.actions.onWallFieldChange('showImagePreview', true);
        this.setState({
            pickedRow: data
        });
    }

    _renderImagePreviewModal(data) {
        if (!data)
            return null;

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image && data.image.images) {
            if (data.image.constructor === Object && data.image.images.length > 0) {
                for (let i = 0; i < data.image.images.length; i++) {
                    let imageUrl = data.image.images[i];
                    if (hashLoadedImage[imageUrl]) {
                        continue;
                    }
                    imageDataItems.push(imageUrl);
                    hashLoadedImage[imageUrl] = true;
                }
            } else {
                imageDataItems.push(data.image);
            }
        }

        let userID = null;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        return (
            <ImagePreview images={imageDataItems}
                closeModal={() => this.props.actions.onWallFieldChange('showImagePreview', false)} ads={data} userID={userID}
                loggedIn={this.props.global.loggedIn}
            />
        );
    }

    _renderTotalPhoto(data) {
        if (!data) {
            return null;
        }

        let total = 0;
        let hashLoadedImage = {};
        if (data.image) {
            if (data.image.constructor === Object && data.image.images.length > 0) {
                for (let i = 0; i < data.image.images.length; i++) {
                    let imageUrl = data.image.images[i];
                    if (hashLoadedImage[imageUrl]) {
                        continue;
                    }
                    total++;
                    hashLoadedImage[imageUrl] = true;
                }
            } else {
                total++;
            }
        }
        return (
            <View style={{
                position: 'absolute',
                bottom: 20,
                left: 16
            }}>
                <RelandIcon name="camera-o" color="#fff"
                    iconProps={{ style: styles.pagingIcon }} size={16}
                    textProps={styles.pagingText}
                    mainProps={styles.pagingView}
                    text={(total) + ' ảnh'}
                >
                </RelandIcon>
            </View>
        );
    }

    _renderHeaderComment() {
        return (
            <View style={styles.viewHeaderContent}>
                <TouchableOpacity style={[styles.viewCloseIcon, { paddingLeft: 12 }]}
                    onPress={this._onBackComment.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewCommentHead}>
                    <Text style={styles.textCommentHead}>Bình luận</Text>
                </View>
                <View style={styles.viewCloseIcon}>
                </View>
            </View>
        );
    }

    _renderListComment() {

        // let dsComment = ds_listComment.cloneWithRows(this.props.wall.commentList);
        let data = this.state.commentList;
        return (
            <View style={{ flex: 1 }}>
                <Animated.View
                    style={{
                        height: this.state.height,
                        justifyContent: 'flex-end',
                    }}

                >


                    <FlatList
                        ref={(ref) => this.scrollView = ref}
                        data={data}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderRowComment(data.item)}
                        removeClippedSubviews={false}
                        enableEmptySections
                        showsVerticalScrollIndicator={false}
                        initialListSize={25}
                        ListHeaderComponent={this._renderParentContent(this.props.parentContent)}
                        ListFooterComponent={this.renderFooterComment(data)}
                        style={styles.listContent}
                        contentContainerStyle={{ paddingBottom: 10 }}
                        onLayout={this.onLayout.bind(this)}
                        onContentSizeChange={this.onContentSizeChange.bind(this)}
                        // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
                        onKeyboardWillShow={this.onKeyboardWillShow.bind(this)}
                        onKeyboardDidShow={this.onKeyboardDidShow.bind(this)}
                        // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
                        onKeyboardWillHide={this.onKeyboardWillHide.bind(this)}
                        onKeyboardDidHide={this.onKeyboardDidHide.bind(this)}
                    />
                </Animated.View>
                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)} />
            </View>
        );
    }

    onContentSizeChange(contentWidth, contentHeight) {
        this._contentHeight = contentHeight;
    }

    onLayout(event) {
        const layout = event.nativeEvent.layout;
        this._listHeight = layout.height;

        if (this._firstDisplay === true) {
            requestAnimationFrame(() => {
                this._firstDisplay = false;
                // this.scrollToBottom(false);
            });
        }
    }

    onKeyboardWillHide() {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight,
            duration: 150,
        }).start();
    }

    onKeyboardDidHide(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillHide(e);
        }

        // TODO test in android
        //if (this.props.keyboardShouldPersistTaps === false) {
        if (this.isLastMessageVisible()) {
            this.scrollToBottom();
        }
        //}
    }

    onKeyboardWillShow(e) {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight - e.endCoordinates.height,
            duration: 200,
        }).start();
    }

    onKeyboardDidShow(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillShow(e);
        }

        setTimeout(() => {
            this.scrollToBottom();
        }, (Platform.OS === 'android' ? 200 : 100));
    }

    scrollToBottom(animated = null) {
        if (this._listHeight && this._contentHeight && this._contentHeight > this._listHeight) {
            let scrollDistance = this._listHeight - this._contentHeight;

            if (this.scrollResponder) {
                this.scrollResponder.scrollTo({
                    y: -scrollDistance,
                    x: 0,
                    animated: typeof animated === 'boolean' ? animated : true
                });
                // this.scrollView.scrollToEnd({animated: typeof animated === 'boolean' ? animated : true});
            }
        }
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    _renderRowComment(data, index) {
        // log.info('==================> _renderRowComment data', data);
        let imageUserComment = { uri: data.avatar };
        if (!imageUserComment) {
            imageUserComment = require('../../assets/image/no_cover.jpg');
        }
        let defaultCover = require('../../assets/image/no_cover.jpg');

        let nameUser = data.fullName || '';
        let timeComment = data.timeCreated || '';
        let commentContent = data.content;

        return (
            <View style={styles.viewRowComment} key={index}>
                <TouchableOpacity onPress={this._onUserCommentPress.bind(this, data)}>
                    <Image
                        resizeMode={"cover"}
                        source={imageUserComment}
                        defaultSource={defaultCover}
                        style={styles.myAvatarCommnent} />
                </TouchableOpacity>
                <View style={styles.viewDetailComment}>
                    <TouchableOpacity onPress={this._onPressComment.bind(this, data)} style={styles.viewContentComment}>
                        <View style={styles.viewNameUser}>
                            <Text style={styles.nameUserComment} numberOfLines={2}>{nameUser}</Text>
                        </View>
                        {/*<Text style={styles.textContentChat}>{commentContent}</Text>*/}
                        <View style={{ flex: 1, flexWrap: 'wrap', flexDirection: 'row', paddingRight: 4 }}>
                            {this._urlify(commentContent, gui.textAgentSolid, data.id)}
                        </View>
                    </TouchableOpacity>
                    <Text style={styles.timeMinuteComment}>{utils.getDiffTime(timeComment)}</Text>
                </View>
            </View>
        );
    }

    _onShowMore(commentID) {
        let expandedComment = this.state.expandedComment;
        expandedComment.push(commentID)
        this.setState({
            expandedComment: expandedComment
        })
    };

    _urlify(text, color, commentID) {
        if (!text) {
            return text;
        }

        let words = text.split(' ');
        let items = [];
        let index = 0;
        let totalLength = 0;
        let showMoreText = '... Xem thêm';
        let reachedMax = false;
        let expandedComment = this.state.expandedComment;

        words.forEach((word) => {
            if (reachedMax)
                return;

            if (index > 0) {
                totalLength += 1
                items.push(
                    <Text key={index++} style={{ flexWrap: 'wrap', fontFamily: gui.fontFamily, color: color }}>{' '}</Text>
                );
            }
            if (word && word.match(/(https?:\/\/[^\s]+)/g)) {
                if (expandedComment.indexOf(commentID) > -1)
                    items.push(
                        <TouchableOpacity key={index++} onPress={() => this._onOpenURL(word)}>
                            <Text style={{ flexWrap: 'wrap', textDecorationLine: 'underline', fontFamily: gui.fontFamily, fontSize: 15, color: color }}>{word}</Text>
                        </TouchableOpacity>
                    )
                else {
                    totalLength += word.length
                    if (totalLength < MAX_LENGTH && !reachedMax)
                        items.push(
                            <TouchableOpacity key={index++} onPress={() => this._onOpenURL(word)}>
                                <Text style={{ flexWrap: 'wrap', textDecorationLine: 'underline', fontFamily: gui.fontFamily, fontSize: 15, color: color }}>{word}</Text>
                            </TouchableOpacity>
                        );
                    else {
                        items.push(
                            <TouchableOpacity key={index++} onPress={() => this._onShowMore(commentID)}>
                                <Text style={{ flexWrap: 'wrap', textDecorationLine: 'underline', fontFamily: gui.fontFamily, fontSize: 13, color: gui.mainAgentColor }}>{showMoreText}</Text>
                            </TouchableOpacity>
                        );
                        reachedMax = true;
                    }
                }
            } else {
                if (expandedComment.indexOf(commentID) > -1)
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontFamily: gui.fontFamily, fontSize: 15, color: color }}>{word}</Text>
                    );
                else {
                    totalLength += word.length
                    if (totalLength < MAX_LENGTH)
                        items.push(
                            <Text key={index++} style={{ flexWrap: 'wrap', fontFamily: gui.fontFamily, fontSize: 15, color: color }}>{word}</Text>
                        );
                    else {
                        items.push(
                            <TouchableOpacity key={index++} onPress={() => this._onShowMore(commentID)}>
                                <Text style={{ flexWrap: 'wrap', textDecorationLine: 'underline', fontFamily: gui.fontFamily, fontSize: 13, color: gui.mainAgentColor }}>{showMoreText}</Text>
                            </TouchableOpacity>
                        );
                        reachedMax = true;
                    }
                }
            }
        });

        return items;
    }

    _onOpenURL(geoUrl) {
        Linking.canOpenURL(geoUrl).then(supported => {
            if (supported) {
                Linking.openURL(geoUrl);
            } else {
                log.info('Don\'t know how to open URI: ' + geoUrl);
            }
        });
    }

    _onPressComment(data) {
        let currentUser = this.props.global.currentUser;
        if (currentUser.userID == data.createdBy) {
            this.setState({ selectedComment: data, isOpenMoreModal: true });
        } else {
            this.setState({
                isOpenUserModal: true,
                userModalData: data
            })
        }
    }

    _renderTextInputComment() {
        let blockStatus = this.props.global.currentUser.block
        let isBlocked = false;
        if (blockStatus && blockStatus.status == 1) {
            let today = moment().format('YYYYMMDD')
            let expiredDate = moment(blockStatus.startDateTime).add(blockStatus.days, 'days').format('YYYYMMDD')
            if (expiredDate >= today)
                isBlocked = true;
        }

        return (
            <KeyboardAvoidingView
                behavior='position'
            >
                <View style={styles.viewTabPost}>
                    <View style={styles.viewInputComment}>

                        {isBlocked == true
                            ?
                            <View style={[styles.viewLock, { paddingLeft: 0, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }]}>
                                <View style={[styles.myAvatarPost, { borderColor: '#ff0000', justifyContent: 'center', alignItems: 'center', borderWidth: 1 }]}>
                                    <FontAwesomeLight name="lock-alt" size={16} color={'#ff0000'} noAction={true} iconOnly={true} />
                                </View>
                                <Text style={[{ color: '#ff0000', marginLeft: 8 }]}>Bạn tạm thời bị khóa chức năng bình luận</Text>
                            </View>
                            :
                            <TextInput
                                ref="commentInput"
                                autoFocus={false}
                                autoCorrect={false}
                                keyboardType="twitter"
                                underlineColorAndroid='rgba(0,0,0,0)'
                                autoGrow={true}
                                multiline={true}
                                numberOfLines={6}
                                style={styles.viewTextInput}
                                placeholder="Nhập bình luận tại đây..." placeholderTextColor={gui.colorMainBlur}
                                onChangeText={(text) => { this.onValueChange("commentContent", text) }}
                                value={this.state.commentContent}
                            />
                        }
                    </View>
                    {this._renderPostingButton()}
                </View>
            </KeyboardAvoidingView>
        );
    }

    _renderPostingButton() {
        let nameIcon = this.state.isEditOldComment ? "pencil" : "arrow-up";
        if (this.props.wall.creatingComment)
            return (
                <View
                    style={styles.viewButtonPost}>
                    {/*<Text style={styles.textPost}>{textButton}</Text>*/}
                    <MaterialCommunityIcons name={nameIcon} size={20} color={'#fff'} />
                </View>
            )
        return (
            <TouchableOpacity
                onPress={this._onPostComment.bind(this)}
                style={styles.viewButtonPost}>
                {/*<Text style={styles.textPost}>{textButton}</Text>*/}
                <MaterialCommunityIcons name={nameIcon} size={20} color={'#fff'} />
            </TouchableOpacity>
        )
    }

    _renderLoadingView() {
        if (this.props.wall.creatingComment || this.props.wall.loadingComment) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='small' color="grey" />
            </View>)
        }
    }

    isValidInputData() {
        let errors = '';
        // console.log("==============>", this.props.wall);
        let commentContent = this.state.commentContent ? this.state.commentContent.trim() : '';

        if (!commentContent) {
            errors += ' (nội dung bình luận)';
        }

        if (errors != '') {
            errorMessage = 'Bạn chưa nhập' + errors + '!';
            return false;
        }
        return true;
    }

    _onLogEvent() {
        let eventDto = {
            scene: "GroupComment",
            parentScene: this.props.owner,  //truyen owner neu co            
            componentType: "button",
            component: "Bình luận",
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onPostComment() {
        this._onLogEvent();
        //  this._scrollView.scrollTo({ y: 0 });
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
            this.props.actions.onWallFieldChange('error', errorMessage);
            return;
        }
        let groupWallOwner = this.props.parentContent.createdBy || this.props.parentContent.userID;
        let groupWallOwnerFullName = this.props.parentContent.fullName || this.props.parentContent.createdByName;

        let otherUsersCommented = [];
        if (this.state.commentList && this.state.commentList.length > 0) {
            this.state.commentList.forEach((e) => {
                if (!otherUsersCommented.includes(e.createdBy)
                    && e.createdBy != currentUser.userID
                    && e.createdBy != groupWallOwner) {
                    otherUsersCommented.push(e.createdBy)
                }
            })
        }

        let userLikeList = [];
        if (this.state.userLikeList && this.state.userLikeList.length > 0) {
            this.state.userLikeList.forEach((e) => {
                if (!userLikeList.includes(e.userID)
                    && !otherUsersCommented.includes(e.userID)
                    && e.userID != currentUser.userID
                    && e.userID != groupWallOwner) {
                    userLikeList.push(e.userID)
                }
            })
        }

        let commentDto = {
            "id": this.props.wall.commentID || undefined,
            "createdByName": currentUser.fullName || currentUser.email || currentUser.phone || undefined,
            "createdByAvatar": currentUser.thumbnail || currentUser.avatar || undefined,
            "createdBy": currentUser.userID || undefined,
            "contentType": 'text' || undefined,
            "content": this.state.commentContent || undefined,
            "groupWallID": this.props.groupWallID || undefined,
            "groupID": this.props.groupID || undefined,
            "groupWallOwner": groupWallOwner,
            "groupWallOwnerFullName": groupWallOwnerFullName,
        }

        this.props.actions.saveGroupComment(this.props.owner, commentDto, token, otherUsersCommented, userLikeList)
            .then(res => {
                this.setState({ isEditOldComment: false });
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    dismissKeyboard();
                    // this.fetchData();
                    //re-new data
                    let commentList = this.state.commentList;
                    let newComment = res.data;
                    commentList = commentList.filter((e) => { return (e.id != newComment.id) })
                    newComment.username = currentUser.username
                    newComment.fullName = currentUser.fullName
                    newComment.avatar = currentUser.thumbnail
                    commentList.push(newComment)
                    this.setState({ commentList: commentList.slice(0) })
                    this.props.actions.onWallFieldChange('commentList', commentList.slice(0))
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, (Platform.OS === 'android' ? 200 : 100));

                    this.onValueChange('commentContent', '');
                    // this.props.actions.onWallFieldChange('commentContent', '');
                    this.onValueChange('commentID', null);
                    this.props.actions.onWallFieldChange('commentID', null);
                }
            });

        // this.scrollView.scrollToEnd({ animated: false });

    }

    onValueChange(key: string, value: string) {
        // this.props.actions.onWallFieldChange(key, value);
        this.setState({ commentContent: value })
    }

    _onChangeText(text) {
        this.setState({
            valueComment: text
        })
    }

    _onBackComment() {
        this.setState({
            commentList: []
        })
        this.props.actions.onWallFieldChange('commentList', [])
        this.props.actions.onWallFieldChange('commentID', null);
        this.props.actions.onWallFieldChange('commentContent', '');
        Actions.pop();
        StatusBar.setBarStyle('default');
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollContainer: {
        width: width,
        height: height - 112
    },
    commentsView: {
        flex: 1
    },
    viewHeaderContent: {
        height: 64,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewCloseIcon: {
        height: 64,
        width: 60,
        justifyContent: 'center',
        paddingTop: gui.marginTopAgent
    },
    textCommentHead: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        fontSize: 17,
        color: gui.textAgentSolid
    },
    viewCommentHead: {
        height: 64,
        width: width - 120,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    viewRowComment: {
        paddingHorizontal: 8,
        paddingTop: 8,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        flexDirection: 'row',
        width: width - 16,
        height: 'auto',
        marginTop: 3,
        marginRight: 8,
        // backgroundColor: '#dcdcdc'
    },
    myAvatarCommnent: {
        width: 32,
        height: 32,
        borderRadius: 16
    },
    viewDetailComment: {
        height: 'auto',
        width: width - 56,
        marginLeft: 8,
        marginRight: 8,
        backgroundColor: '#fff',
        alignSelf: 'flex-start'
    },
    viewContentComment: {
        // flex: 1,
        width: width - 56,
        height: 'auto',
        justifyContent: 'center',
        backgroundColor: '#f0f1f3',
        borderRadius: 12,
        paddingHorizontal: 8,
        paddingVertical: 8,
        alignSelf: 'flex-start',
        marginRight: 8
    },
    viewNameUser: {
        height: 18,
        width: width - 56,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        // paddingLeft: 8
    },
    viewNameComment: {
        height: 30,
        width: width - 160
    },
    viewTimeComment: {
        height: 30,
        width: 80,
        alignItems: 'flex-end'
    },
    nameUserComment: {
        fontSize: 15,
        color: gui.textAgentSolid,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    timeMinuteComment: {
        fontSize: 12,
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        marginTop: 3
    },
    textContentChat: {
        fontSize: 15,
        color: gui.textAgentSolid,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        marginRight: 8
    },
    viewListContainer: {
        paddingBottom: 57,
        flex: 1
    },
    viewInputComment: {
        width: width - 48,
        height: 56,
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderColor: "lightgray",
    },
    viewLock: {
        backgroundColor: '#fff',
        width: width - 48,
        height: 38,
        paddingLeft: 8,
        color: gui.mainTextColor,
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        backgroundColor: '#fff',
        width: width - 48,
        height: 'auto',
        paddingLeft: 8,
        color: gui.mainTextColor,
    },
    viewButtonPost: {
        height: 30,
        width: 30,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor,
        borderRadius: 15,
        position: 'absolute',
        right: 8
    },
    viewTabPost: {
        height: 56,
        width: width,
        flexDirection: 'row',
        paddingLeft: 16,
        paddingRight: 16,
        position: 'absolute',
        justifyContent: 'flex-start',
        alignItems: 'center',
        bottom: 0,
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderColor: gui.colorMainBlur
    },
    textPost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: '#fff'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    listContent: {
        height: height - 112,
        width: width,
    },

    viewListMyGroup: {
        // flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 8, //14,
        backgroundColor: '#fff'
    },
    viewRowTopContent: {
        // marginLeft: 8,
        // marginRight: 8,
        // paddingTop: 16,
        // paddingBottom: 12,
        // paddingLeft: 16,
        // paddingRight: 16,
        // borderWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)',
        // borderRadius: 2,
        // borderBottomWidth: 0,
        // borderBottomLeftRadius: 0,
        // borderBottomRightRadius: 0,
        // backgroundColor: '#fff',
        // width: width - 16,
        // height: 'auto'
        // marginLeft: 8,
        // marginRight: 8,
        // paddingTop: 16,
        paddingBottom: 12,
        paddingLeft: 8,
        paddingRight: 8,
        // borderWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)',
        // borderRadius: 2,
        // borderBottomWidth: 0,
        // borderBottomLeftRadius: 0,
        // borderBottomRightRadius: 0,
        backgroundColor: '#fff',
        width: width,
        height: 'auto'
    },
    viewMainUser: {
        height: 36, // 24
        width: width - 16, // 48
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewUserContent: {
        width: width - 68 - 12,
        height: 34,
        marginLeft: 8,
        marginBottom: 2
    },
    mainUserAvatar: {
        // height: 24,
        // width: 24,
        // borderRadius: 12
        height: 36,
        width: 36,
        borderRadius: 18
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        marginLeft: 0, //8
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    viewIconBubble: {
        position: 'absolute',
        right: 0,
        top: 0
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    imageContentRow: {
        width: width,
        height: gui.ADS_IMAGE_RATIO * width,
        backgroundColor: '#fff'
    },
    viewBorderTopAds: {
        height: 9,
        width: width,
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewBorderTopImage: {
        height: 8,
        width: width - 16,
        borderWidth: 1,
        borderBottomWidth: 0,
        borderColor: 'rgba(211,211,211,0.5)'
    },
    imgItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 16,
        height: imageGroup,
        alignSelf: 'auto',
        marginLeft: 8,
        marginRight: 8
    },
    linearGradientMain: {
        marginTop: 0,
        height: gui.ADS_IMAGE_RATIO * width,
        width: width - 16,
        marginLeft: 0,
        marginRight: 0,
        backgroundColor: "transparent"
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 16, //23
        bottom: 13,
        height: 32,
        width: width - 46,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent'
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: '#fff',
        fontWeight: '500'
    },
    pagingIcon: {
        borderRadius: 0,
        marginLeft: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingView: {
        flexDirection: 'row',
        backgroundColor: '#5b5c61',
        borderRadius: 5,
        opacity: 0.75
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent',
    },
    pagingText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#fff',
        marginRight: 10,
        marginBottom: 2,
        marginTop: 2
    },
    viewDetailPost: {
        // height: 145,
        width: width - 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderTopWidth: 0,
        borderColor: 'rgba(211,211,211,0.5)',
        borderRadius: 2,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        backgroundColor: '#fff',
        marginBottom: 8
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 12,
        paddingLeft: 16,
        paddingRight: 16,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 46,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 16
    },
    viewContentSource: {
        // height: 36,
        width: width - 12,
        paddingLeft: 16,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 8
    },
    viewTextAddress: {
        //height: 20,
        width: width - 12,
        marginBottom: 4,
        // marginTop: 6,
        paddingLeft: 16,
        paddingRight: 16,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 2
    },
    textTimePost: {
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewUserLogo: {
        position: 'absolute',
        left: 17,
        bottom: 17,
        height: 24,
        // width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewRowPostNormalWto: {
        width: width,
        height: 'auto'
    },
    viewAdsWto: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff',
    },
    viewRowPostWto: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingRight: 8,
        paddingTop: 6,
        paddingBottom: 3,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        width: width - 16,
        height: 'auto',
        //marginTop: 8,
        marginBottom: 8,
        marginLeft: 8,
        marginRight: 8
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    viewDetailPost2: {
        height: 'auto',
        width: width - 34,
        justifyContent: 'center',
        backgroundColor: '#fff',
        paddingLeft: 6
    },
    viewTieuDe: {
        flexDirection: 'row',
        width: width - 138 + 34 - 16,
        alignItems: 'center',
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
        marginLeft: 9
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textPostAds,
    },
    viewTextTieuDe: {
        height: 24,
        width: width - 62 - 32 - 16,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    viewEmptyComment: {
        height: 92,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 40
    },
    imageEmptyHistory: {
        width: 159,
        height: 60
    },
    textEmpty: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        alignSelf: 'center',
        textAlign: 'center'
    },
    viewDetailPostComment: {
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        height: 'auto'
    },
    viewLikeComment: {
        height: 39,
        width: width,
        paddingLeft: 8,
        paddingRight: 8,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    },
    lineDangNhap2: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 16,
        opacity: 0.8,
        // marginLeft: 8,
        // marginRight: 8
    },
    viewGiaFmt: {
        width: width - 18,
        height: 28,
        paddingLeft: 16,
        justifyContent: 'flex-end',
    },
    textPriceFmt: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.textPostAds
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        width: width - 34,
        height: 20,
        backgroundColor: '#fff'
    },
    myAvatarPost: {
        // width: 32,
        // height: 32,
        // borderRadius: 16,
        marginLeft: 8,
        height: 36,
        width: 36,
        borderRadius: 18
    },
    viewUserModal: {
        justifyContent: 'flex-start',
        height: 'auto',
        backgroundColor: 'transparent',
        alignItems: 'center',
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupComment);