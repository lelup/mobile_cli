import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    Image,
    ActivityIndicator
} from 'react-native';

import { Actions } from 'react-native-router-flux';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import DanhMuc from '../../assets/DanhMuc';

import FontAwesomeLight from '../font/FontAwesomeLight';
import utils from '../../lib/utils';
const { width, height } = utils.getDimensions();
import FullLine from '../line/FullLine'
import gui from "../../lib/gui";
import moment from 'moment';
import userApi from '../../lib/userApi';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import log from '../../lib/logUtil';

import * as globalActions from '../../reducers/global/globalActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as meActions from '../../reducers/me/meActions';


const actions = [
    globalActions,
    registerActions,
    groupActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}


let dataNews = [
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Chính chủ Kim Văn Kim Lũ cho thuê gấp trong tháng 9',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà riêng tại Phố Yên Hoa, Phường Yên Phụ, Quận Tây Hồ, Hà Nội, giá 5.6 tỷ',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/23991349/4e5e0cbe_original.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà TimeCity giá 4.5 tỷ, liên hệ ngay để có giá tốt hơn, phone: 0900882222',
        'timeStamp': 1496912814
    },
    {
        'imageNewsUrl': 'https://a0.muscache.com/im/pictures/7bf5a969-7379-44ae-abe3-3315e7a0683b.jpg?aki_policy=x_large',
        'textTitle': 'Bán nhà biệt thự liền kề Quận Tây Hồ, Hà Nội, giá 9.2 tỷ',
        'timeStamp': 1496912814
    },
]

class NewsList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: dataNews,
            newsList: props.group.newsList,
            newsPageNo: props.group.newsPageNo,
        }
    }

    render() {
        let { hideHeader } = this.props;
        return (
            <View style={styles.container}>
                {hideHeader ? null : this._renderHeader()}
                {hideHeader ? null : <FullLine />}
                {this._renderListNews()}
            </View>
        )
    }

    _renderHeader() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, { fontSize: 17 }]}>Tin tức</Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _renderListNews() {
        return (
            <View style={{ flex: 1 }}>
                <FlatList
                    data={this.props.group.newsList}
                    keyExtractor={(items, index) => "list" + index}
                    renderItem={(data) => this._renderRowNews(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.viewListNews}
                    onEndReachedThreshold={0}
                    onEndReached={() => this.loadNextPage()}
                    ListFooterComponent={() =>
                        this.state.loaded
                            ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
                            : null}
                />
            </View>
        )
    }

    _renderRowNews(data) {
        let imgUrl = data && data.image;
        let sourceNewsUrl = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!sourceNewsUrl) {
            sourceNewsUrl = require('../../assets/image/no_cover.jpg');
        }
        let category = DanhMuc.allCategoryName[data.parent_cate || data.cate];
        let newsTitle = data.title;
        let timeStamp = data.createdtime
        return (
            <TouchableOpacity style={styles.viewRowNews}
                onPress={this.onRowPress.bind(this, data)}
            >
                <Image
                    resizeMode={"cover"}
                    source={sourceNewsUrl}
                    defaultSource={defaultCover}
                    style={styles.newsCover}
                />
                <View style={styles.itemsContent}>
                    <View style={styles.viewTextTitle}>
                        <Text style={[styles.textTitle, { fontSize: 17 }]} numberOfLines={3}>{newsTitle}</Text>
                    </View>
                    <View style={styles.viewTimeStamp}>
                        <View style={styles.sourceNews}>                            
                            <Text style={[styles.textTime, { marginLeft: 0 }]}>{category}</Text>
                        </View>
                        <View style={{flexDirection:'row', justifyContent:'center', alignItems:'center'}}>
                            <FontAwesomeLight name="clock"
                                size={13}
                                color={gui.textShare}
                                noAction={true}
                                iconOnly={true}
                                mainProps={{ marginBottom: 3 }} />
                            <Text style={styles.textTime}>{timeStamp}</Text>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    onRowPress(newsData) {
        let eventDto = {
            scene: "NewsList",
            parentScene: this.props.owner,  //truyen owner neu co            
            componentType: "listItem",
            component: "Chi tiết tin tức",
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,
            customData: {url: newsData.url}
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
        
        Actions.NewsDetail({data: newsData})
    }

    _onBackPress() {
        Actions.pop();
    }

    loadNextPage = () => {
        let currentPageNo = this.state.newsPageNo;
        let totalPages = this.props.group.totalNewsCount / 20;
        if (totalPages && currentPageNo < totalPages) {
            this.props.actions.onGroupFieldChange("newsPageNo", currentPageNo + 1)
            this.setState(state => ({ newsPageNo: state.newsPageNo + 1 }), () => this.getNextNews());
        }
        // this.getNextNews()
    };

    getNextNews = () => {
        this.setState({ loaded: true });
        
        this.props.actions.loadNews({
            'limit': 20,
            'page': this.state.newsPageNo
        }
            , (res) => {
                log.info(' server respond data: =====>>>>> ', res.data);
                // this.refreshFeed(res.data)
            }
            , (error) => {
                this.setState({
                    loaded: false
                });
            }
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        paddingLeft: 16,
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewListNews: {
        flex: 1
    },
    viewRowNews: {
        height: 80,
        width: width - 32,
        marginTop: 16,
        marginBottom: 4,
        marginLeft: 16,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    newsCover: {
        height: 80,
        width: 104
    },
    itemsContent: {
        height: 80,
        width: width - 136
    },
    viewTextTitle: {
        height: 60,
        width: width - 136,
        paddingLeft: 12
    },
    textTitle: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    viewTimeStamp: {
        flexDirection: 'row',
        height: 20,
        width: width - 136,
        paddingLeft: 12,
        alignItems: 'flex-end',
        justifyContent:'space-between'
    },
    sourceNews: {
        flexDirection: 'row',
        height: 20,
        width: 100,
        alignItems: 'flex-end'
    },
    textTime: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        color: gui.textShare,
        fontWeight: '300',
        marginLeft: 5
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NewsList);