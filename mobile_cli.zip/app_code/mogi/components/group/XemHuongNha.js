import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    Image,
    ScrollView,
    Linking,
    WebView,
    PixelRatio
} from 'react-native';

import {Actions} from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import HTMLView from 'react-native-htmlview';

import DanhMuc from '../../assets/DanhMuc';
import FontAwesomeLight from '../font/FontAwesomeLight';
import utils from '../../lib/utils';
const {width, height} = utils.getDimensions();
import FullLine from '../line/FullLine'
import gui from "../../lib/gui";
import log from '../../lib/logUtil';

let dataPhongThuy = {
    "srcUrl": "http://vansu.net/xem-huong-lam-nha-1930-Canh-Ngo-nu-gioi-huong-Bac.html",
    "namSinh": "1930",
    "mota": "Canh Ngo",
    "sex": "F",
    "huongNha": 4,
    "image": "http://vansu.net/sites/all/themes/somenh/images/ngo.gif",
    "content": "\r\n\r\nGia chủ\r\n\r\n- Năm sinh dương lịch: 1930\r\n- Năm sinh âm lịch: Canh Ngọ \r\n- Quẻ mệnh: Cấn Thổ\r\n- Ngũ hành: Lộ Bàng Thổ (Đất đường đi) \r\n- Thuộc Tây Tứ Mệnh, nhà hướng Bắc, thuộc Đông Tứ Trạch\r\n\r\n\r\nHướng tốt - Hướng xấu\r\n- Hướng tốt:  Tây Bắc (Thiên Y); Đông Bắc (Phục Vị); Tây Nam (Sinh Khí); Tây (Diên Niên); \r\n- Hướng xấu: Bắc (Ngũ Quỷ); Đông (Lục Sát); Đông Nam (Tuyệt Mệnh); Nam (Hoạ Hại);\r\n\r\nKết luận, lời khuyên:\r\nRất tiếc, hướng cửa chính (quay về hướng Ngũ Quỷ) không hợp với tuổi của quý khách. Nhưng xin chớ quá lo lắng, có thể khắc phục bằng các cách sau:\r\n                                + Cách thứ nhất: Chuyển hướng cửa hoặc thêm cửa phụ thứ hai ở trong nhà theo hướng Đông Bắc (hướng Phục Vị).\r\n                             \r\n                             \r\n                             \r\n                                 + Cách thứ hai: Dùng màu sắc của thảm trải trước cửa để hoá giải tà khí theo quy luật ngũ hành tương sinh, tương khắc:       \r\n                              Nhà quay về hướng Bắc, có tà khí của Hoả. \r\n                              Có thể trải thảm màu \r\n                              Nâu hoặc Vàng\r\n\r\n              \t\t\r\n              \t\t\r\n                       ",
    "id": "PhongThuy_01"
};

const IMAGES_MAX_WIDTH = width - 32;
const CUSTOM_STYLES = {};
const CUSTOM_RENDERERS = {};
const DEFAULT_PROPS = {
    htmlStyles: CUSTOM_STYLES,
    renderers: CUSTOM_RENDERERS,
    imagesMaxWidth: IMAGES_MAX_WIDTH,
    onLinkPress: (evt, href) => { Linking.openURL(href); },
    debug: true
}

class XemHuongNha extends Component {
    constructor(props) {
        super(props);

        this.state = {
            // data: this.props.data
            data: dataPhongThuy
        }
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                <FullLine/>
                {this._renderListDetail()}
            </View>
        )
    }

    _renderHeader() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontSize: 17}]}>Phong thủy hướng nhà</Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop();
    }

    _renderListDetail() {
        let data = this.state.data;
        let htmlContent = '';
        let arrData = data && data.content.split('\r\n');
        let preText = '';
        arrData.forEach((one) => {
            let text = one.trim();
            if (text == 'Gia chủ' || text == 'Hướng tốt - Hướng xấu' || text == 'Kết luận, lời khuyên:') {
                text = htmlContent == '' ? '<strong>' + text + '</strong>' : '\r\n<strong>' + text + '</strong>';
            }
            if (text) {
                if (preText == 'Có thể trải thảm màu') {
                    htmlContent = htmlContent + ' ' + text;
                } else {
                    htmlContent = htmlContent == '' ? text : htmlContent + '\r\n' + text;
                }
                preText = text;
            }
        });
        return(
            <ScrollView style={{ flex: 1 }}>
                {this._renderNamSinh()}
                {this._renderHuongNha()}
                {this._renderGioiTinh()}
                {this._renderImage()}
                {this._renderTuoi()}
                <View style={styles.viewWrapHtml}>
                    <HTMLView
                        value={htmlContent}
                        stylesheet={styles}
                        paragraphBreak={null}
                        lineBreak={null}
                        addLineBreaks={false}
                        bullet={null}
                        textComponentProps={ styles }
                        renderNode={this.renderNode}
                        nodeComponentProps={styles}
                    />
                </View>
            </ScrollView>
        )
    }

    _renderTuoi() {
        let namSinh = Number(this.state.data.namSinh);
        let namHienTai = new Date().getFullYear();
        let tuoiText = (namHienTai-namSinh) + ' tuổi';
        let namAmLich = utils.getNamAmLich(namSinh);
        let amLichText = '(' + namSinh + '-' + namAmLich + ')';
        return (
            <View style={styles.imageView}>
                <Text style={styles.tuoiText}>{tuoiText.toUpperCase()}</Text>
                <Text style={[styles.tuoiText, {fontSize: 20, color: '#838E9D'}]}>{amLichText.toUpperCase()}</Text>
            </View>
        )
    }

    _renderImage() {
        let imgUri = this.state.data.image ? {uri: this.state.data.image} : undefined;
        return (
            <View style={styles.imageView}>
                <Image
                    source={imgUri}
                    style={styles.imageSoMenh}
                    resizeMode={'contain'}
                />
            </View>
        )
    }

    _renderNamSinh() {
        let textNamSinh = this._getNamSinhValue();
        let textColor = textNamSinh == 'Nhập năm sinh' ? gui.colorMainBlur : gui.mainTextColor;
        let namSinhLabel = 'Năm sinh';
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewNamSinh}
                                  disabled={this.isUploading()}
                                  onPress={() => this._onNamSinhPressed()}>
                    <View style={styles.viewTitleNamSinh}>
                        <Text style={styles.textNamSinh}>{namSinhLabel}</Text>
                        <Text style={[styles.label, { color: '#ff0000', fontSize: 15 }]}>*</Text>
                    </View>
                    <View style={styles.touchNamSinh}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{textNamSinh}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _getNamSinhValue() {
        return '1930';
    }

    _onNamSinhPressed() {

    }

    isUploading() {
        return false;
    }

    _renderHuongNha() {
        let textHuongNha = this._getHuongNhaValue();
        let textColor = textHuongNha == 'Nhập hướng nhà' ? gui.colorMainBlur : gui.mainTextColor;
        let huongNhaLabel = 'Hướng nhà';
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewNamSinh}
                                  disabled={this.isUploading()}
                                  onPress={() => this._onHuongNhaPressed()}>
                    <View style={styles.viewTitleNamSinh}>
                        <Text style={styles.textNamSinh}>{huongNhaLabel}</Text>
                        <Text style={[styles.label, { color: '#ff0000', fontSize: 15 }]}>*</Text>
                    </View>
                    <View style={styles.touchNamSinh}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{textHuongNha}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _getHuongNhaValue() {
        return 'Bắc';
    }

    _onHuongNhaPressed() {

    }

    _renderGioiTinh() {
        let textGioiTinh = this._getGioiTinhValue();
        let textColor = textGioiTinh == 'Nhập giới tính' ? gui.colorMainBlur : gui.mainTextColor;
        let gioiTinhLabel = 'Giới tính';
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewNamSinh}
                                  disabled={this.isUploading()}
                                  onPress={() => this._onGioiTinhPressed()}>
                    <View style={styles.viewTitleNamSinh}>
                        <Text style={styles.textNamSinh}>{gioiTinhLabel}</Text>
                        <Text style={[styles.label, { color: '#ff0000', fontSize: 15 }]}>*</Text>
                    </View>
                    <View style={styles.touchNamSinh}>
                        <Text style={[styles.textResult, { color: textColor, marginRight: 8 }]} numberOfLines={1}>{textGioiTinh}</Text>
                        <FontAwesomeLight name="chevron-right" size={17} color={'#959595'} noAction={true} iconOnly={true} />
                    </View>
                </TouchableOpacity>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _getGioiTinhValue() {
        return 'Nữ';
    }

    _onGioiTinhPressed() {

    }

    renderNode(node, index, siblings, parent, defaultRenderer) {
        if (node.name == 'img') {
            const { src, height } = node.attribs;
            let style = node.attribs.style && node.attribs.style.split(';');
            let imageWidth = width - 32;
            let imageHeight = 320;
            if (style && style.length >= 2) {
                let one = style.find((e) => e.indexOf('width') >= 0);
                if (one) {
                    imageWidth = Number(one.split(':')[1].replace('px','').replace('%',''));
                }
                one = style.find((e) => e.indexOf('height') >= 0);
                if (one) {
                    imageHeight = Number(one.split(':')[1].replace('px','').replace('%',''));
                }
            }
            let ratio = (width - 32)/imageWidth;
            if (ratio < 1) {
                imageWidth = width - 32;
                imageHeight = ratio * imageHeight;
            }
            return (
                <View style={{alignItems: 'center',
                    width: width - 32,
                    height: imageHeight + 20,
                    paddingVertical: 10}}
                      key={index}
                >
                    <Image
                        key={index}
                        style={{ width: imageWidth, height: imageHeight}}
                        source={{ uri: src }}
                        resizeMode={'contain'}
                    />
                </View>
            );
        }
    }

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        paddingLeft: 16,
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewListNews: {
        flex: 1
    },
    viewRowNews: {
        height: 80,
        width: width - 32,
        marginTop: 16,
        marginBottom: 4,
        marginLeft: 16,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    textTitle: {
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    viewTimeStamp: {
        flexDirection: 'row',
        height: 20,
        width: width - 32,
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        marginTop: 6
    },
    sourceNews: {
        flexDirection: 'row',
        height: 20,
        // width: 100,
        flex: 1,
        alignItems: 'flex-end'
    },
    textTime: {
        fontSize: 15,
        fontFamily:gui.fontFamily,
        color: gui.textShare,
        fontWeight: '300',
        marginLeft: 5
    },
    viewTitle: {
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginTop: 16
    },
    textTitleNews: {
        fontSize: 20,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '600'
    },
    viewWrapHtml: {
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginRight: 16,
        marginTop: 16,
        paddingBottom: 16,
        overflow: 'hidden'
    },
    // span: {
    //     fontWeight: '300',
    //     color: gui.textPostAds,
    //     fontFamily:gui.fontFamily
    // },
    // p: {
    //     fontWeight: '300',
    //     color: gui.textPostAds,
    //     fontFamily:gui.fontFamily
    // },
    // a: {
    //     fontWeight: '300',
    //     color: gui.mainColor, // make links coloured pink
    // },
    img: {
        width: width - 32,
        height: 'auto', // make links coloured pink
        marginTop: 5,
        marginBottom: 5
    },
    p: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        fontSize: 17,
        // textAlign: 'justify'
    },
    // span: {
    //     textAlign: 'justify'
    // },
    // strong: {
    //     textInden: 'justify'
    // },
    ul: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        fontSize: 17,
    },
    ol: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        fontSize: 17,
    },
    em : {
        marginTop: 5,
        marginBottom: 5,
        fontSize: 17,
        fontFamily:gui.fontFamily
    },
    span: {
        fontSize: 17,
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        // textAlign: 'justify'
    },
    a: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        color: gui.mainColor,
        fontSize: 17,
    },
    strong: {
        fontFamily:gui.fontFamily,
        textAlign: 'justify',
        fontSize: 17,
        fontWeight: 'bold'
    },
    h2: {
        fontSize: 17,
        fontFamily:gui.fontFamily
    },
    div: {
        fontSize: 17,
        fontFamily:gui.fontFamily
    },
    viewNamSinh: {
        // height: 41,
        width: width - 32,
        flexDirection: 'row',
        marginTop: 16,
        marginBottom: 16,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewEachInfo: {
        height: 55,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    viewTitleNamSinh: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    label: {
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily
    },
    textNamSinh: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    touchNamSinh: {
        position: 'absolute',
        right: 0,
        flexDirection: 'row'
    },
    textResult: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.colorMainBlur
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    imageSoMenh: {
        height: 0.27*width,
        width: 0.27*width
    },
    imageView: {
        flex: 1,
        alignItems: 'center',
        marginTop: 20
    },
    tuoiText: {
        fontSize: 22,
        fontFamily:gui.fontFamily
    }
});

export default XemHuongNha;