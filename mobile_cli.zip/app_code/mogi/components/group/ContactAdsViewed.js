import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    FlatList,
    TouchableOpacity,
    ListView,
    ScrollView
} from 'react-native';

import FontAwesome  from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons  from 'react-native-vector-icons/MaterialCommunityIcons';
import { Actions } from 'react-native-router-flux';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import Modal from 'react-native-modalbox';
import FullLine from '../line/FullLine';
import RelandIcon from '../RelandIcon';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import GiftedSpinner from "../GiftedSpinner";
import FontAwesomeLight from '../font/FontAwesomeLight';

import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';

const actions = [
    groupActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
import DanhMuc from '../../assets/DanhMuc';
let { width, height } = utils.getDimensions();

class ContactAdsViewed extends Component {
    constructor(props) {
        super(props);
        
        this.state = {            
            isOpenMoreModal: false,
            comment:'',
            contactRespondList: props.groupContact.contactRespondList
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.groupContact.contactRespondList !== this.props.groupContact.contactRespondList) {
            this.setState({ contactRespondList: nextProps.groupContact.contactRespondList });
        }
    }

    _renderLoadingView() {
        if (this.props.group.loadingContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    render() {
        let  data = this.state.contactRespondList;
        let headerText = this.props.owner == 'CalendarEvent' ? 'Thêm phản hồi' : 'Thêm nhà đã xem'
        let marginTop = this.props.owner == 'CalendarEvent' ? 20 : 0;
        let adsViewedEmpty = 'Nơi bạn lưu lại những phản hồi của khách khi xem nhà';
        let sourceEmpty =  require('../../assets/image/icon_da_xem.png');
        return (
            <View style={styles.container}>
                {this.props.owner == 'CalendarEvent' ? this._renderNewHeader() : this._renderHeader()}

                {data && data.length>0 
                ? 
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRow(data.item)}
                    removeClippedSubviews={false}
                    enableEmptySections
                    showsVerticalScrollIndicator={false}
                    style={styles.viewListContainer}
                />
                : <View style={[styles.contentHistory]}>
                    <Image  style={styles.imageEmptyHistory}
                            source={sourceEmpty}
                            defaultSource={sourceEmpty}
                            resizeMode={'cover'}
                    />
                    <Text style={[styles.textPhone,{marginTop: 47}]}>{adsViewedEmpty}</Text>
                </View>}
                
                {this._renderLoadingView()}
            </View>
        )
    }

    _renderNewHeader() {
        return(
            <View>
                <View style={styles.viewNewHeader}>
                    <TouchableOpacity style={styles.viewBackIcon}
                                      onPress={this._onBackButton.bind(this)}>
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.viewHeaderContent} onPress={this._themNhaDaXem.bind(this)}>
                            <MaterialCommunityIcons name={'plus'} size={16} color={gui.mainAgentColor}/>
                            <Text style={styles.textThemNha}>Thêm phản hồi</Text>
                        </TouchableOpacity>
                    <View style={styles.viewBackIcon}></View>
                </View>
                <FullLine />
            </View>
        )
    }

    _renderHeader() {
        return(
            <View>
                <TouchableOpacity onPress={this._themNhaDaXem.bind(this)} style={styles.touchAdd}>
                    <MaterialCommunityIcons name={'plus'} size={16} color={gui.mainAgentColor}/>
                    <Text style={styles.textThemNha}>Thêm nhà đã xem</Text>
                </TouchableOpacity >
                <FullLine style={{ marginLeft: 6, marginRight: 6, marginBottom: 0 }}/>
            </View>
        )
    }

    _onBackButton() {    
        if (this.props.owner == 'CalendarEvent')       
            // Actions.CalendarEvent({ isOpenMoreCalendarModal: false, selectedEvent: null });
            Actions.popTo('CalendarEvent')
        else Actions.pop();
    }

    _onOpenMoreComment(value) {
        if (value) {
            this.props.actions.onGroupContactFieldChange('openCommentViewed', true);
            this.props.actions.onGroupContactFieldChange('commentViewed', value);
        }
    }

    _renderRow(data) {
        // console.log('========== render nha da xem row', data);
        let image = data.image ? data.image.cover : '';
        let uriImage = { uri: image };
        let defaultSource = require('../../assets/image/no_cover.jpg');
        // console.log('==================> gia', data.gia);
        let giaFmt = utils.getPriceDisplay2(data.gia);
        let status = data.likeStatus;
        let backgroundColor = DanhMuc.likeBackground[status];
        let statusText = DanhMuc.likeStatus[status];
        let name = DanhMuc.likeIcon[status];
        let dienTich = !data.dienTich || data.dienTich == -1 ? '' : data.dienTich + ' m2';
        let phongTam =  data.soPhongTam;
        let phongNgu = data.soPhongNgu;
        let content = data.title || data.diaChi;
        let comment = data.comment;
        return(
            <TouchableOpacity onPress={this._onEditNhaDaXem.bind(this, data)} style={[styles.viewMainRow, {height: 'auto'}]}>
                <Image style={styles.imageStyle}
                       source={uriImage}
                       defaultSource={defaultSource}
                       resizeMode={'cover'}
                />
                <FullLine style={{ marginLeft: 12, marginRight: 12, marginTop: 8 }} />
                <View style={styles.viewContentChild}>
                    <Text style={styles.textGiaDemand}>{giaFmt}</Text>
                    <View style={[styles.viewButtonStatus, {backgroundColor: backgroundColor}]}>
                        <FontAwesome name={name} color='#fff' size={12}/>
                        <Text style={styles.textStatus}>{statusText}</Text>
                    </View>
                </View>
                <View style={styles.viewTextContent}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 48 }}>
                        <Text style={[styles.textContent, {marginLeft: 8}]} numberOfLines={1}>{content}</Text>
                    </View>
                </View>
                <View style={styles.viewLeftIcons}>
                    {dienTich ? this._renderSquareIcon(dienTich) : null}
                    {this._renderItemIcon('bath',phongTam, 13)}
                    {this._renderItemIcon('bed',phongNgu, 14)}
                </View>
                {/*<FullLine style={{marginLeft: 11, marginRight: 11}}/>*/}
                <FullLine style={{marginLeft: 11, marginRight: 11}}/>
                <TouchableOpacity style={styles.viewAvatarComment}
                                  onPress={this._onOpenMoreComment.bind(this, comment)}
                >
                    <Image style={styles.imageAvatarComment}
                           source={uriImage}
                           defaultSource={defaultSource}
                           resizeMode={'cover'}
                    />
                    <View style={styles.viewCommentCover}>
                        <Text style={styles.textComment} numberOfLines={1}>{comment}</Text>
                    </View>
                </TouchableOpacity>
            </TouchableOpacity>
        )
    }

    _themNhaDaXem() {
        this.resetContactRespond();
        Actions.ContactRespond({owner: this.props.owner, selectedEvent: this.props.selectedEvent });
    }

    _onEditNhaDaXem(data) {
        let personContactDto ;
        let selectedEvent = this.props.selectedEvent;

        if (this.props.owner=='CalendarEvent')
            personContactDto = {
                contactID: this.props.selectedEvent.contactID,
                contactName: this.props.selectedEvent.contactName,
                contactPhone: this.props.selectedEvent.contactPhone,
                contactAvatar: this.props.selectedEvent.contactAvatar,
                contactSaleState: this.props.selectedEvent.contactSaleState
            }
        else personContactDto = {
            contactID: this.props.groupContact.selectedContact.id || this.props.groupContact.selectedContact.contactID,
            contactName: this.props.groupContact.selectedContact.contactName,
            contactPhone: this.props.groupContact.selectedContact.contactPhone,
            contactEmail: this.props.groupContact.selectedContact.contactEmail,
            contactType: this.props.groupContact.selectedContact.contactType == 1 ? true : false,
            contactAvatar: this.props.groupContact.selectedContact.avatar,
            contactSaleState: this.props.groupContact.selectedContact.contactSaleState
        }
        let adsDto = {
            adsID: data.adsID,
            image: data.image,
            dienTich: data.dienTich,            
            diaChi: data.diaChi,
            loaiTin: data.loaiTin,
            gia: data.gia,
            title: data.title,
            soPhongNgu: data.soPhongNgu,
            soPhongTam: data.soPhongTam
        }

        this.props.actions.onGroupContactFieldChange('contactRespondAds', adsDto)
        this.props.actions.onGroupContactFieldChange('contactOfRespond', personContactDto)
        this.props.actions.onGroupContactFieldChange('likeStatus', data.likeStatus)
        this.props.actions.onGroupContactFieldChange('contactRespondComment',data.comment)
        this.props.actions.onGroupContactFieldChange('contactRespondID',data.id)
        this.props.actions.onGroupContactFieldChange('contactRespondEventID', data.eventID)

        Actions.ContactRespond({owner:this.props.owner, selectedEvent: selectedEvent});
    }

    resetContactRespond() {
        let personContactDto ;
        let selectedEvent = this.props.selectedEvent;
        if (this.props.owner=='CalendarEvent')
            personContactDto = {
                contactID: this.props.selectedEvent.contactID,
                contactName: this.props.selectedEvent.contactName,
                contactPhone: this.props.selectedEvent.contactPhone,
                contactAvatar: this.props.selectedEvent.contactAvatar,
                contactSaleState: this.props.selectedEvent.contactSaleState
            }
        else 
            personContactDto = {
                contactID: this.props.groupContact.selectedContact.id || this.props.groupContact.selectedContact.contactID,
                contactName: this.props.groupContact.selectedContact.contactName,
                contactPhone: this.props.groupContact.selectedContact.contactPhone,
                contactEmail: this.props.groupContact.selectedContact.contactEmail,
                contactType: this.props.groupContact.selectedContact.contactType == 1 ? true : false,
                contactAvatar: this.props.groupContact.selectedContact.avatar,
                contactSaleState: this.props.groupContact.selectedContact.contactSaleState
            }

        this.props.actions.onGroupContactFieldChange('contactRespondAds', null)
        this.props.actions.onGroupContactFieldChange('contactOfRespond', personContactDto)
        this.props.actions.onGroupContactFieldChange('likeStatus', 'normal')
        this.props.actions.onGroupContactFieldChange('contactRespondComment','')
        this.props.actions.onGroupContactFieldChange('contactRespondID',null)
        this.props.actions.onGroupContactFieldChange('contactRespondEventID', selectedEvent?selectedEvent.id:null )
              
    }

    _renderSquareIcon(value) {
        if(!!value) {
            return(
                <View style={styles.viewSquare}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostCommon} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={styles.textIcon}>{value}</Text>
                </View>
            )
        }
        return null;
    }

    _renderItemIcon = (name, value, size) => {
        if(!!value) {
            return(
                <View style={[styles.viewItemIcon]}>
                    <FontAwesomeLight name={name} size={size} color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: 12 }} noAction={true} iconOnly={true} />
                    <Text style={styles.textIcon}>{value}</Text>
                </View>
            )
        }
        return null;
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: gui.newLineFacebook
    },
    viewItemIcon: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 12,
        height: 14
    },
    textIcon: {
        color: gui.textPostAds,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewSquare: {
        flexDirection: 'row',
        height: 14,
        marginLeft: 0,
        alignItems: 'center'
    },
    viewListContainer: {
        flex: 1
    },
    contentHistory: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewMainRow: {
        height: gui.ADS_IMAGE_RATIO*width+139,
        width: width,
        marginBottom: 8,
        backgroundColor: '#fff'
    },
    imageStyle: {
        height: gui.ADS_IMAGE_RATIO*width,
        width: width,
    },
    viewContentChild: {
        height: 22,
        width: width, //true with - 32?
        paddingLeft: 10,
        marginTop: 10,
        paddingRight: 0,
        flexDirection: 'row',
        alignItems: 'center'
    },
    textGiaDemand: {
        fontSize: 17,
        fontWeight: '500',
        color: gui.textPostAds,
        fontFamily: gui.fontFamily
    },
    viewButtonStatus: {
        paddingVertical: 2,
        paddingHorizontal: 4,
        borderRadius: 2,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        marginLeft: 11
    },
    textStatus: {
        fontSize: 10,
        color: '#fff',
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewLeftIcons: {
        height: 20,
        width: width,
        marginTop: 2,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingLeft: 11,
        marginBottom: 10
    },
    viewTextContent: {
        height: 20,
        width: width,
        paddingRight: 0,
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 11,
        marginTop: 2
    },
    textContent: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textPostAds,
        fontFamily: gui.fontFamily
    },
    viewAvatarComment: {
        height: 54,
        width: width, // ? style 69
        marginLeft: 10,
        flexDirection: 'row',
        alignItems: 'center'
    },
    imageAvatarComment: {
        height: 30,
        width: 30,
        borderRadius: 15
    },
    viewCommentCover: {
        height: 30,
        width: width - 67 + 12,
        marginLeft: 5,
        borderRadius: 15,
        paddingLeft: 10,
        paddingRight: 10,
        justifyContent: 'center',
        backgroundColor: '#f0f1f3'
    },
    textComment: {
        fontSize: 15,
        color: gui.textPostAds,
        fontFamily: gui.fontFamily
    },
    touchAdd: {
        width: width,
        height: 36,
        justifyContent:'center',
        alignItems:'center',
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    textThemNha: {
        fontSize: 15,
        color: gui.mainColor,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewModalStyle: {
        height: 160,
        width: width
    },
    viewModalContent: {
        height: 160,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        paddingTop: 10
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    textPhone: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        alignSelf: 'center',
        textAlign: 'center'
    },
    viewBackIcon: {
        height: 36,
        width: 36,
        justifyContent: 'center',
    },
    viewNewHeader: {
        height: 36,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        marginTop: gui.marginTopAgent
    },
    viewHeaderContent: {
        width: width - 104,
        height: 36,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    imageEmptyHistory: {
        width: 162,
        height: 150,
        marginTop: 24
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(ContactAdsViewed);