import React, { Component } from 'react';
import {
    Text,
    View,
    Image,
    StyleSheet,
    TouchableOpacity,
    Alert,
} from 'react-native';

import { Actions } from 'react-native-router-flux';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FullLine from '../line/FullLine';
import DanhMuc from '../../assets/DanhMuc';
import RelandIcon from '../RelandIcon';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();
import DatePicker from 'react-native-datepicker';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as eventActions from '../../reducers/event/eventActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import moment from 'moment'

import CheckDotEvent from '../detail/CheckDotEvent';


const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    eventActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class EventFilter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            eventFilterState: props.event.eventFilterState,
            startDateTimeFrom: props.event.startDateTimeFrom,
            startDateTimeTo: props.event.startDateTimeTo,
            dateStart: moment(props.event.startDateTimeFrom),
            dateEnd: moment(props.event.startDateTimeTo),
        }
    }

    // componentWillMount() {
    //     let today = new Date();
    //     console.log('==============> ', this.state.eventFilterState);
    //     if(this.state.eventFilterState == "today") {
    //         this.setState({
    //             startDateTimeFrom : today.setHours(0, 0, 0, 0),
    //             startDateTimeTo : today.setHours(24, 0, 0, 0)
    //         })
    //     }
    // }

    componentWillReceiveProps(nextProps) {
        if (this.props.event.eventFilterState !== nextProps.event.eventFilterState) {
            this.setState({ eventFilterState: nextProps.event.eventFilterState });
        }

        if (this.props.event.startDateTimeFrom !== nextProps.event.startDateTimeFrom) {
            this.setState({
                startDateTimeFrom: nextProps.event.startDateTimeFrom,
                dateStart: moment(nextProps.event.startDateTimeFrom)
            });
        }
        if (this.props.event.startDateTimeTo !== nextProps.event.startDateTimeTo) {
            this.setState({
                startDateTimeTo: nextProps.event.startDateTimeTo,
                dateEnd: moment(nextProps.event.startDateTimeTo)
            });
        }

    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeaderAds()}
                <FullLine />
                {this._renderFilterBody()}
            </View>
        );
    }

    _renderFilterBody() {
        // let filterItems = [];
        // let eventFilterKeys = Object.keys(DanhMuc.eventFilter);
        // eventFilterKeys.forEach((value) => {
        //     let typeFilter = DanhMuc.eventFilter[value];
        //
        //     filterItems.push(
        //         <CheckDotEvent name={value} key={value}
        //                   onPress={this._onFilterPress.bind(this)}
        //                   selected={this.state.eventFilterState == value}
        //                   mainProps={[styles.mainProps]}>{typeFilter}</CheckDotEvent>
        //     );
        // });
        return (
            <View style={styles.viewDotFilter}>
                <CheckDotEvent name={'today'}
                    onPress={this._onFilterPress.bind(this)}
                    selected={this.state.eventFilterState == 'today'}
                    mainProps={[styles.mainProps]}>Hôm nay</CheckDotEvent>
                <FullLine />
                <CheckDotEvent name={'1day'}
                    onPress={this._onFilterPress.bind(this)}
                    selected={this.state.eventFilterState == '1day'}
                    mainProps={[styles.mainProps]}>Ngày mai</CheckDotEvent>
                <FullLine />
                <CheckDotEvent name={'7day'}
                    onPress={this._onFilterPress.bind(this)}
                    selected={this.state.eventFilterState == '7day'}
                    mainProps={[styles.mainProps]}>7 ngày tiếp theo</CheckDotEvent>
                <FullLine />
                <CheckDotEvent name={'30day'}
                    onPress={this._onFilterPress.bind(this)}
                    selected={this.state.eventFilterState == '30day'}
                    mainProps={[styles.mainProps]}>30 ngày tiếp theo</CheckDotEvent>
                <FullLine />
                <CheckDotEvent name={'distance'}
                    onPress={this._onFilterPress.bind(this)}
                    selected={this.state.eventFilterState == 'distance'}
                    mainProps={[styles.mainProps]}>Chọn khoảng thời gian</CheckDotEvent>
                {this._renderDistance()}
            </View>
        )
    }

    _renderDistance() {
        if (this.state.eventFilterState == 'distance') {
            let textTu = '23/11/2017';
            let textDen = '30/01/2018';
            return (
                <View style={styles.viewDistance}>
                    <View style={styles.timeFrom}>
                        <Text style={styles.textFrom}>Từ</Text>
                        <TouchableOpacity style={styles.viewChooseDay}>
                            <DatePicker
                                style={{
                                    width: width / 2 - 30,
                                }}
                                customStyles={{
                                    dateInput: {
                                        borderWidth: 0,
                                        alignItems: 'flex-start'
                                    },
                                    placeholderText: {
                                        color: gui.mainTextColor,
                                        fontWeight: '500'
                                    },
                                    dateText: {
                                        color: gui.mainTextColor,
                                        fontWeight: '500'
                                    }
                                }}
                                showIcon={false}
                                date={this.state.dateStart}
                                mode="date"
                                placeholder="Chọn ngày"
                                format="DD/MM/YYYY"
                                minDate="01/01/1900"
                                maxDate="31/12/2050"
                                confirmBtnText="Chọn"
                                cancelBtnText="Hủy"
                                onDateChange={this._onDateStartChange.bind(this)}
                            />
                            <View style={styles.viewIcon}>
                                <FontAwesome name={'calendar'}
                                    size={16}
                                    color={'rgba(82,97,115,1)'} />
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={[styles.timeFrom, { marginLeft: 4 }]}>
                        <Text style={styles.textFrom}>Đến</Text>
                        <TouchableOpacity style={styles.viewChooseDay}>
                            <DatePicker
                                style={{
                                    width: width / 2 - 30,
                                }}
                                customStyles={{
                                    dateInput: {
                                        borderWidth: 0,
                                        alignItems: 'flex-start'
                                    },
                                    placeholderText: {
                                        color: gui.mainTextColor,
                                        fontWeight: '500'
                                    },
                                    dateText: {
                                        color: gui.mainTextColor,
                                        fontWeight: '500'
                                    }
                                }}
                                showIcon={false}
                                date={this.state.dateEnd}
                                mode="date"
                                placeholder="Chọn ngày"
                                format="DD/MM/YYYY"
                                minDate="01/01/1900"
                                maxDate="31/12/2050"
                                confirmBtnText="Chọn"
                                cancelBtnText="Hủy"
                                onDateChange={this._onDateEndChange.bind(this)}
                            />
                            <View style={styles.viewIcon}>
                                <FontAwesome name={'calendar'}
                                    size={16}
                                    color={'rgba(82,97,115,1)'} />
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            )
        } else return null;
    }

    _onDateStartChange(date) {
        let eventStartDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState({ dateStart: eventStartDate });
        // this.props.actions.onEventFieldChange('startDateTimeFrom', moment(eventStartDate).toDate());
    }

    _onDateEndChange(date) {
        let eventEndDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState({ dateEnd: eventEndDate });
        // this.props.actions.onEventFieldChange('startDateTimeTo', moment(eventEndDate).toDate());
    }

    _onFilterPress(value) {
        this.setState({
            eventFilterState: value
        });
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity style={styles.viewEdit} onPress={this._onBackPress.bind(this)}>
                    <Text style={styles.textHuy}>Hủy</Text>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, { fontWeight: '500' }]}>Lọc</Text>
                </View>
                <TouchableOpacity onPress={this.onApplyFilter.bind(this)} style={styles.viewEdit}>
                    <Text style={[styles.textHuy, { fontWeight: '500' }]}>Xong</Text>
                </TouchableOpacity>
            </View>

        );
    }

    _timeSetup = async () => {
        let today = new Date();
        let startDateTimeFrom, startDateTimeTo;
        let { eventFilterState } = this.state;
        this.props.actions.onEventFieldChange('eventFilterState', eventFilterState);
        if (eventFilterState == "today") {
            startDateTimeFrom = today.setHours(0, 0, 0, 0);
            startDateTimeTo = today.setHours(23, 59, 59, 999);
        }
        if (eventFilterState == "1day") {
            startDateTimeFrom = moment(today).add(1, 'days').toDate().setHours(0, 0, 0, 0);
            startDateTimeTo = moment(today).add(1, 'days').toDate().setHours(23, 59, 59, 999);
        }
        if (eventFilterState == "7day") {
            startDateTimeFrom = today.setHours(0, 0, 0, 0);
            startDateTimeTo = moment(today).add(7, 'days').toDate().setHours(23, 59, 59, 999);
        }
        if (eventFilterState == "30day") {
            startDateTimeFrom = today.setHours(0, 0, 0, 0);
            startDateTimeTo = moment(today).add(30, 'days').toDate().setHours(23, 59, 59, 999);
        }
        if (eventFilterState == "distance") {
            startDateTimeFrom = moment(this.state.dateStart).toDate().setHours(0, 0, 0, 0);
            startDateTimeTo = moment(this.state.dateEnd).toDate().setHours(23, 59, 59, 999);
        }
        await this.setState({
            startDateTimeFrom: startDateTimeFrom,
            startDateTimeTo: startDateTimeTo
        })

    }

    onApplyFilter = async () => {
        await this._timeSetup();
        let { startDateTimeFrom, startDateTimeTo, eventFilterState } = this.state;

        if (eventFilterState == "distance" && this.state.dateStart.diff(this.state.dateEnd) > 0) {
            Alert.alert("Thông báo", 'Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        this.props.actions.onEventFieldChange('startDateTimeFrom', startDateTimeFrom);
        this.props.actions.onEventFieldChange('startDateTimeTo', startDateTimeTo);

        // this.props.actions.onEventFieldChange('eventList', []);

        this.props.actions.getAllCalendarEvent(
            {
                'userID': this.props.global.currentUser.userID,
                'startDateTimeFrom': this.state.startDateTimeFrom,
                'startDateTimeTo': this.state.startDateTimeTo
            }
            , (res) => {
                // console.log('server res: =====>>>>>', res)
            }
            , (error) => {
                console.log('server respond data: =====>>>>>', error)
            });
        Actions.pop()
    }

    _onBackPress() {
        Actions.pop();
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    pageHeader: {
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width,
        flexDirection: 'row'
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: 'bold'
    },
    textHuy: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainAgentColor,
        fontWeight: 'normal'
    },
    mainProps: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        margin: 0,
        marginLeft: 0,
        marginRight: 0,
        width: width - 32,
        height: 41,
    },
    viewDotFilter: {
        marginLeft: 16,
        marginRight: 16
    },
    viewDistance: {
        marginTop: 14,
        width: width - 32,
        flexDirection: 'row',
        height: 60,
        backgroundColor: '#fff'
    },
    timeFrom: {
        width: (width - 32) / 2,
        height: 60,
        justifyContent: 'center'
    },
    textFrom: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
    },
    viewChooseDay: {
        marginTop: 11,
        width: (width - 32) / 2 - 4,
        height: 37,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(246,246,246,1)',
        paddingLeft: 10
    },
    viewIcon: {
        position: 'absolute',
        right: 11
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(EventFilter);