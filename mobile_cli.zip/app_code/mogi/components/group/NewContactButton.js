
const newContactButton = {
    name:"newContact",
    size: {width: 56, height: 56},
    animationTypes: ['IDLE'],
    frames: []
};

export default newContactButton;
