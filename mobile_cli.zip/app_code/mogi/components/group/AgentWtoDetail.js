'use strict';
import React, { Component } from 'react';

import type, {
    StyleObj
} from 'react-native/Libraries/StyleSheet/StyleSheetTypes';

import {
    View, Text, StyleSheet, TextInput, ScrollView, ListView, TouchableOpacity, ViewPropTypes, StatusBar,
    ImageBackground, Alert, NetInfo, Image
} from 'react-native';
import Button from 'react-native-button';
import { Actions } from 'react-native-router-flux';
import ScalableText from 'react-native-text';

import moment from 'moment';
import { bindActionCreators } from 'redux';
import LinearGradient from 'react-native-linear-gradient';
import { connect } from 'react-redux';
import NonEditTag from './NonEditTag';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Modal from 'react-native-modalbox';
import SummaryText from '../SummaryText';
import CommonUtils from '../../lib/CommonUtils';
import Icon from 'react-native-vector-icons/FontAwesome';
import GiftedSpinner from "../GiftedSpinner";

import apiUtils from '../../lib/ApiUtils';
import Camera from 'react-native-camera';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Toast, { DURATION } from '../toast/Toast';


import Communications from 'react-native-communications';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as chatActions from '../../reducers/chat/chatActions';
import DanhMuc from '../../assets/DanhMuc';
import { Map } from 'immutable';
import FullLine from '../line/FullLine';
import gui from "../../lib/gui";
import log from "../../lib/logUtil";
import utils from '../../lib/utils';
const { width, height } = utils.getDimensions();
import OfflineBar from '../line/OfflineBar';
const actions = [
    globalActions,
    meActions,
    groupActions,
    chatActions,
    searchActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class AgentWtoDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            data: props.data,
            boundary: []
        }
    }

    componentWillMount() {
        let data = this.state.data;
        this._loadRegionBoundary(data.content.place)
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this.renderHeaderDetail()}
                <FullLine />
                {this.renderBodyWtoDetail()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    }

    renderBodyWtoDetail() {
        let { data } = this.state;
        // log.info('renderBodyWtoDetail data to render ****', data)
        return (
            <ScrollView
                contentContainerStyle={styles.scrollView}
                automaticallyAdjustContentInsets={true}
                style={styles.viewBodyWtoDetail}>
                {this.renderTitleWto(data)}
                {this.renderWtoContent(data)}
                {this.renderVitri(data)}
                {this.renderThoiHan(data)}
                {this.renderDaChiaSe(data)}
                {this.renderGhiChu(data)}                
                {this.renderLienHe(data)}
            </ScrollView>
        );
    }

    renderTitleWto(data) {

        let typePost = DanhMuc.loaiTinWTo[data.loaiTin];
        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;
        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;

        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))
        let date = moment(data.timeModified).format("DD/MM/YYYY");
        let dateFmt = `Ngày đăng : ${date}`;
        return (
            <View>
                <View style={styles.viewTitleWto}>
                    <Text style={styles.textTieuDe}>{diaChiFullname}</Text>
                    <View style={styles.viewLabel}>
                        <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                            <Text style={styles.textTypePost}>{priority}</Text>
                        </View>
                        <Text style={styles.textDatePost}>{dateFmt}</Text>
                    </View>
                </View>
                <FullLine style={{ marginLeft: 12 }} />
            </View>
        )
    }

    renderWtoContent(data) {
        let giaNha = this._getGiaText(data);
        let diaChiFullName = data.content.place.fullName || ' ';
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;
        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;

        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;
        let soTangValue = data.content.soTang;
        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let detailItems = [];
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(<View style={styles.iconLeft} key={"dienTich_" + uuid}>
                {this.getDienTich(areaValue)}
            </View>)
        }
        if (!!bedroomValue) {
            detailItems.push(<View style={styles.iconLeft} key={"phongNgu_" + uuid}>
                {this._renderPhongNgu(bedroomValue, (!areaValue && areaValue == DanhMuc.KHONG_RO) ? 0 : 0)}
            </View>)
        }
        if (!!bathroomValue) {
            detailItems.push(<View style={styles.iconLeft} key={"phongTam_" + uuid}>
                {this._renderPhongTam(bathroomValue, (!bedroomValue && areaValue == DanhMuc.KHONG_RO) ? 0 : 0)}
            </View>)
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(<View style={styles.iconLeft} key={"huongNha_" + uuid}>
                {this._renderHuongNha(huongNhaValue, (!bathroomValue && areaValue == DanhMuc.KHONG_RO) ? 0 : 0)}
            </View>)
        }
        if (!!soTangValue) {
            detailItems.push(<View style={styles.iconLeft} key={"tang_" + uuid}>
                {this._renderSoTang(soTangValue, (!soTangValue && areaValue == DanhMuc.KHONG_RO) ? 0 : 0)}
            </View>)
        }
        return (
            <View>
                <View style={styles.viewTitleWto}>
                    <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>{giaNha}</Text>
                    <View style={[styles.viewLabel, { marginTop: 5, alignItems: 'flex-start' }]}>
                        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} />
                        <View style={{width:width-48}}>
                            <Text style={[styles.textDatePost, { fontSize: 15, color: gui.textPostAds }]}>{diaChiFullName}</Text>
                        </View>
                    </View>
                    <Text style={[styles.textGiaNha, { color: '#898989', marginTop: 1 }]}>{loaiNhaDatText}</Text>
                    <View style={styles.viewLabel}>
                        {detailItems}
                    </View>
                </View>
                <FullLine style={{ marginLeft: 12 }} />
            </View>
        )
    }

    renderVitri(data) {

        let region = apiUtils.getRegionByViewport(data.content.place.viewport);
        let lat = region.latitude;
        let lon = region.longitude;
        let mapWidth = width - 24;
        let mapHeight = 190;
        let zoom = this._calcZoomValue(mapWidth, data.content.place.viewport);
        let imgUrl = 'http://maps.google.com/maps/api/staticmap?zoom=' + zoom + '&size=' + mapWidth + 'x' + mapHeight + '&markers=color:red|' + lat + ',' + lon + '&sensor=false';
        imgUrl = imgUrl + '&key=AIzaSyDCGmWrUyarAz5iIUeOX3X8eI3S7Qvfo3g';

        let boundary = this.state.boundary;
        log.info('boundary ****', boundary)
        if (boundary && boundary.length > 0) {
            // if (!lat || !lon) {
            //     let geoBox = apiUtils.getWToPolygonBox(boundary);
            //     let region = apiUtils.getRegion(geoBox);
            //     lat = region.latitude;
            //     lon = region.longitude;
            // }    

            imgUrl = 'http://maps.google.com/maps/api/staticmap?center=' + lat + ',' + lon + '&size=' + mapWidth + 'x' + mapHeight + '&sensor=false'
                + '&path=color:0x00a8e6ff|weight:2|fillcolor:0x00a8e64c' + this._getPolygonLatLon(boundary[0]);
            imgUrl = imgUrl + '&key=AIzaSyDCGmWrUyarAz5iIUeOX3X8eI3S7Qvfo3g';
            log.info('renderVitri imgurl ***', imgUrl)
        }

        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imgUrl) {
            imageGroup = defaultCover;
        }

        if (!data.content.place.codeDuAn && this.props.search.loadingBoundary)
            return (<View>
                <View style={styles.viewTitleWto}>
                    <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>Bản đồ</Text>
                    <Text style={[styles.textGiaNha, { color: '#898989', marginTop: 1 }]}>Vị trí cần mua trên bản đồ</Text>
                    <View style={[styles.viewImageVitri, {alignItems:'center', justifyContent:'center'}]}>
                        <GiftedSpinner size='large' color={'#d3d3d3'} />
                    </View>
                </View>
                <FullLine style={{ marginLeft: 12 }} />
            </View>)
        else
            return (
                <View>
                    <View style={styles.viewTitleWto}>
                        <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>Bản đồ</Text>
                        <Text style={[styles.textGiaNha, { color: '#898989', marginTop: 1 }]}>Vị trí cần mua trên bản đồ</Text>
                        <View style={styles.viewImageVitri}>
                            <ImageBackground style={styles.imgItem}
                                source={imageGroup} defaultSource={defaultCover}>
                            </ImageBackground>
                        </View>
                    </View>
                    <FullLine style={{ marginLeft: 12 }} />
                </View>
            )
    }

    _getPolygonLatLon(polygon) {
        let latLonValue = '';
        let detail = Math.ceil(polygon.length / 180);
        let i = 0;
        // log.info('=====polygonLatlon', polygon.length);
        polygon && polygon.map((one) => {
            if (polygon.length <= 180 || i % detail == 0) {
                latLonValue += '|' + one.latitude + ',' + one.longitude
            }
            i++;
        });
        if (polygon && polygon.length > 0) {
            let one = polygon[0];
            latLonValue += '|' + one.latitude + ',' + one.longitude;
        }
        return latLonValue;
    }

    _loadRegionBoundary(diaChinh) {
        // let {diaChinh} = this.props.search.form.fields;
        if (diaChinh && !diaChinh.codeDuAn && (diaChinh.codeTinh || diaChinh.codeHuyen || diaChinh.codeXa)) {
            let diaChinhDto = {
                codeTinh: diaChinh.codeTinh || undefined, codeHuyen: diaChinh.codeHuyen || undefined,
                codeXa: diaChinh.codeXa || undefined, codeDuong: diaChinh.codeDuong || undefined
            };
            this.props.actions.getBoundary(diaChinhDto,
                (boundary) => { this.setState({ boundary: boundary }) });
        }
    }

    _calcZoomValue(mapWidth, viewport) {
        let GLOBE_WIDTH = 256; // a constant in Google's map projection
        let west = viewport.southwest.lon;
        let east = viewport.northeast.lon;
        let angle = east - west;
        let north = viewport.southwest.lat;
        let south = viewport.northeast.lat;
        let angle2 = north - south;
        let zoomfactor;
        let delta = 0;

        if (angle2 > angle) {
            angle = angle2;
            delta = 3;
        }

        if (angle < 0) {
            angle += 360;
        }

        zoomfactor = Math.floor(Math.log(mapWidth * 360 / angle / GLOBE_WIDTH) / Math.LN2) - delta;
        return zoomfactor;
    }

    renderThoiHan(data) {
        let date = (data.dateStart && data.dateEnd) ? (moment(data.dateStart).format("DD/MM/YYYY") + '-' + moment(data.dateEnd).format("DD/MM/YYYY")) : moment(data.timeModified).format("DD/MM/YYYY");
        return (
            <View>
                <View style={styles.viewThoiHanTin}>
                    <View style={styles.viewTimeLeft}>
                        <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>Thời hạn tin</Text>
                    </View>
                    <View style={[styles.viewTimeLeft, { alignItems: 'flex-end' }]}>
                        <Text style={[styles.textGiaNha, { color: gui.mainColor }]} numberOfLines={1}>{date}</Text>
                    </View>
                </View>
                <FullLine style={{ marginLeft: 12 }} />
            </View>
        )
    }    

    renderDaChiaSe(data) {
        // let textShare = data.groupID && data.groupID.length > 0 ? 'Đã chia sẻ với ' + data.groupID.length + ' sàn' : "Không chia sẻ";
        let textShare = data.groupID && data.groupID.length > 0 ? 'Đã chia sẻ': "Không chia sẻ";
        let iconShareName = data.groupID && data.groupID.length > 0 ? "share-variant" : "lock";
        //
        let relatedGroup = this.props.group.searchResult.listRelatedGroup;
        let sharedGroup = [];
        if (!!data.groupID) {
            relatedGroup.forEach((e) => {
                if (data.groupID.filter((f) => { return f == e.groupID }).length > 0) {
                    sharedGroup.push(e)
                }
            });
        }
        let tags = sharedGroup.map((tag, index) => (
            <NonEditTag
                type="DuAn"
                index={index}
                label={tag.name}
                isLastTag={sharedGroup.length === index + 1}
                onLayoutLastTag={this.onLayoutLastTag}
                removeIndex={this.removeIndex.bind(this)}
                tagContainerStyle={{ marginBottom: 1 }}
                tagColor='rgba(246,246,246,1)'
                tagTextColor={gui.textAgentSolid}
                key={index}
            />
        ))
        let marginTop = !!data.groupID ? 12 : 0;
        return (
            <View>
                <View style={styles.viewThoiHanTin}>
                    <View style={styles.viewTimeLeft}>
                        <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>Chia sẻ</Text>
                    </View>
                    <View style={styles.viewTimeRight}>
                        <Text style={[styles.textGiaNha, { marginRight: 8, color: '#898989' }]}>{textShare}</Text>
                        <MaterialCommunityIcons
                            name={iconShareName}
                            color={"rgba(85,85,85,1)"}
                            size={18}
                        />
                    </View>
                </View>
                <View style={styles.tagInputContainer}>{tags}</View>
                <FullLine style={{ marginLeft: 12, marginTop: marginTop }} />
            </View>
        )
    }

    renderGhiChu(data) {        
        let ghiChu = data.content.ghiChu;
        if (ghiChu)
            return (
                <View>
                    <View style={styles.viewThoiHanTin}>
                        <View style={styles.viewTimeLeft}>
                            <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>Ghi chú</Text>
                        </View>                    
                    </View>
                    <View style={styles.viewGhiChu}>
                        <Text style={{fontSize:15, color: gui.textPostAds}}>{ghiChu}</Text>
                    </View>
                    <FullLine style={{ marginTop: 12,   marginLeft: 12 }} />
                </View>
            )
        else return <View></View>;
    }

    onLayoutLastTag = (endPosOfTag: number) => {
        const margin = 3;
        this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
        const inputWidth = AgentWtoDetail.inputWidth(
            this.state.text,
            this.spaceLeft,
            this.wrapperWidth,
        );
        if (inputWidth !== this.state.inputWidth) {
            this.setState({ inputWidth });
        }
    }

    static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
        if (text === "") {
            return 90;
        } else if (spaceLeft >= 100) {
            return spaceLeft - 10;
        } else {
            return wrapperWidth;
        }
    }

    removeIndex = (index: number) => {
    }


    renderLienHe(data) {
        let partner = data.userID ? { userID: data.userID } : { userID: data.member };
        if (this.props.global.currentUser.userID == partner.userID) {
            return;
        }
        let imgUrl = data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imgUrl) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }
        let name = data.fullName;
        let phone = data.phone;
        return (
            <View style={{ marginBottom: 15 }}>
                <View style={styles.viewTitleWto}>
                    <Text style={[styles.textTieuDe, { fontSize: 17 }]} numberOfLines={1}>Liên hệ</Text>
                </View>
                <View style={styles.viewDetailUser}>
                    <View style={styles.viewButtons}>
                        <Image
                            resizeMode={"cover"}
                            source={imageGroup}
                            defaultSource={defaultCover}
                            style={styles.adsCover} />
                        <View style={styles.viewPhoneContact}>
                            <Text style={[styles.textGiaNha, { color: gui.textAgentSolid }]}>{name}</Text>
                            <Text style={[styles.textGiaNha, { color: gui.textComment }]}>{phone}</Text>
                        </View>
                    </View>
                    <View style={[styles.viewButtons, { justifyContent: 'flex-end' }]}>
                        <TouchableOpacity style={styles.viewCallButton}
                            onPress={this.onPhoneDetail.bind(this, data.phone)}
                        >
                            <FontAwesomeSolid name="phone" size={18} color={'#fff'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.viewCallButton, { marginLeft: 20 }]}
                            onPress={this.onChat.bind(this, data)}
                        >
                            <FontAwesomeSolid name="comment-dots" size={18} color={'#fff'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.viewCallButton, { marginLeft: 18 }]}
                            onPress={this.onSms.bind(this, data.phone)}
                        >
                            <FontAwesomeSolid name="envelope" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={{height: 20, width: width}}></View>
            </View>
        )
    }


    onChat(data) {
        log.info('=============> data', data);
        let partner = data.userID ? { userID: data.userID } : { userID: data.member };
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');
        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);                        
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
                this.setState({
                    isloadingPressRow: false
                })
            });
    }

    onSms(phone) {
        if (!phone) {
            return;
        }
        Communications.text(phone, '');
    }

    onPhoneDetail(phone) {
        if (!phone) {
            return;
        }

        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(phone, true);
    }


    renderHeaderDetail() {
        return (
            <View style={styles.viewHeaderMember}>
                <TouchableOpacity style={styles.viewBackButton}
                    onPress={this._onCancelClicked.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewHeaderContent}>
                    <Text style={[styles.headerText]}>Chi tiết tin cần mua/thuê</Text>
                </View>
                <View style={styles.viewPlusButton}
                //onPress={this._onMorePress.bind(this)}
                >
                    {/*<FontAwesomeLight name="ellipsis-h" size={32} color={gui.mainColor} noAction={true} iconOnly={true} />*/}
                </View>
            </View>
        )
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="compass" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let bathFmt = `${bathroomValue} phòng tắm`;
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true}
                        name="bath" color={gui.textPostAds}
                        mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathFmt}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let bedFmt = `${bedroomValue} phòng ngủ`;
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedFmt}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderSoTang(soTangValue, marginLeft) {
        let soTangFmt = `${soTangValue} tầng`;
        let uuid = new Date().getTime();
        if (!!soTangValue)
            return (
                <View key={"tang_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true}
                        name="warehouse" color={gui.textPostAds}
                        mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{soTangFmt}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostAds} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }


    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }


    _onCancelClicked() {
        Actions.pop();
    }

    _onMorePress() {
        log.info('=========> _onMorePress');
    }

}
export default connect(mapStateToProps, mapDispatchToProps)(AgentWtoDetail);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderMember: {
        width: width,
        height: 64,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewPlusButton: {
        width: 60,
        height: 64,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 12,
        paddingTop: gui.marginTopAgent
    },
    viewBackButton: {
        width: 60,
        height: 64,
        justifyContent: 'center',
        paddingLeft: 16,
        paddingTop: gui.marginTopAgent
    },
    viewHeaderContent: {
        width: width - 120,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },

    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    scrollView: {
        alignItems: 'center',
        marginBottom: 40
    },
    viewBodyWtoDetail: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewTitleWto: {
        width: width,
        height: 'auto',
        justifyContent: 'center',
        paddingVertical: 12,
        paddingHorizontal: 12
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
    },
    viewLabel: {
        flexDirection: 'row',
        marginTop: 6,
        alignItems: 'center',
        flexWrap: 'wrap'
    },
    iconLeft: {
        height: 21,
        width: (width - 24) / 2,
        justifyContent: 'center',
        marginTop: 8
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 8
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        marginLeft: 0
    },
    viewImageVitri: {
        height: 190,
        width: width - 24,
        backgroundColor: '#dcdcdc',
        marginTop: 11
    },
    imgItem: {
        height: 190,
        width: width - 24,
    },
    viewThoiHanTin: {
        height: 44,
        flexDirection: 'row',
        width: width,
        paddingLeft: 12
    },
    viewTimeLeft: {
        height: 44,
        width: (width - 24) / 2,
        justifyContent: 'center'
    },
    viewTimeRight: {
        height: 44,
        width: (width - 24) / 2,
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexDirection: 'row'
    },
    tagInputContainer: {
        height: 'auto',
        width: width,
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingHorizontal: 12
    },
    viewDetailUser: {
        height: 60,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 12
    },
    viewButtons: {
        height: 60,
        width: (width - 24) / 2,
        flexDirection: 'row',
        alignItems: 'center',
    },
    adsCover: {
        width: 60,
        height: 60,
        marginLeft: 0,
        borderRadius: 30
    },
    viewPhoneContact: {
        height: 60,
        width: (width - 24) / 2 - 60,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewCallButton: {
        height: 36,
        width: 36,
        borderRadius: 18,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewGhiChu: {
        paddingLeft: 12,
        width: width-16,
        height: 'auto'
    }
});