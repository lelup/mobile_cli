import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    ListView,
    ScrollView,
    Image,
    TextInput,
    Alert
} from 'react-native';


import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { Actions } from 'react-native-router-flux';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import OfflineBar from '../line/OfflineBar';
import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import CheckBox from './CheckBox';
import { Map } from 'immutable';
import Modal from 'react-native-modalbox';
import GiftedSpinner from "../GiftedSpinner";

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';


import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';


const actions = [
    globalActions,
    meActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_listInviteFriend = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

class InviteFriends extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            value: '',
            checkBox: false,
            loaded: false,
            userList: props.group.userList
        }
    }

    componentWillReceiveProps(nextProps) {
        console.log('receiving new props========');
        if (nextProps.group.userList !== this.props.group.userList) {
            this.setState({ userList: nextProps.group.userList })
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                <View style={styles.viewHeadInvite}>
                    <TouchableOpacity style={styles.viewCloseIcon}
                        onPress={this._onPressClose.bind(this)}
                    >
                        <MaterialCommunityIcons name="close" size={24} color={gui.mainTextColor} style={{ marginRight: 0 }} />
                    </TouchableOpacity>

                </View>
                <View style={styles.viewInviteText}>
                    <Text style={styles.textAddFriends}>Mời bạn bè</Text>
                </View>
                <FullLine style={{ marginTop: 18 }} />
                {this._renderContentInvite()}
                {this._renderButtonAdd()}
                {this._renderLoadingView()}
            </View>
        );
    }

    _renderContentInvite() {
        return (
            <View style={styles.viewContentInvite}>
                <View style={styles.inputFilterFriend}>
                    <View style={styles.viewIconSearch}>
                        <Icon name="search" size={18} color={gui.mainTextColor} style={{ marginRight: 0 }} />
                    </View>
                    <View style={styles.viewTextInput}>
                        <TextInput
                            autoFocus={false}
                            autoCorrect={false}
                            returnKeyType='done'
                            underlineColorAndroid='rgba(0,0,0,0)'
                            style={styles.viewInputContent}
                            placeholder="Tìm theo số điện thoại, email" placeholderTextColor={gui.colorMainBlur}
                            onChangeText={(text) => this._onChangeSearchFriend(text)}
                            value={this.state.value}
                            onSubmitEditing={this._onSearch.bind(this)}
                        />
                    </View>
                </View>
                <View style={styles.lineDangNhap} />
                {this._renderListContentInvite()}
            </View>
        )
    }

    _onChangeSearchFriend(text) {
        this.setState({
            value: text
        })
    }

    _onSearch() {
        if (!this.state.value || this.state.value == '') {
            Alert.alert('Thông báo', 'Yêu cầu nhập email/số điện thoại',
                [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }
        dismissKeyboard();

        this.props.actions.setLoadingUser();
        this.props.actions.onGroupFieldChange("userList", []);
        this.setState({
            'userList': [],
        });

        this.props.actions.getUserToInvite(
            {
                'phoneOrEmail': this.state.value,
                'groupID': this.props.groupID
            }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
                if (res.data.length == 0) {
                    Alert.alert('Thông báo', 'Email/số điện thoại không tồn tại trong hệ thống',
                        [{ text: 'Đóng', onPress: () => { } }]);
                }
                this.refreshRowData(res.data || []);
            }
            , (error) => {
                Alert.alert('Thông báo', 'Email/số điện thoại không tồn tại trong hệ thống',
                    [{ text: 'Đóng', onPress: () => { } }]);
                this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _renderLoadingView() {
        if (this.props.group.fetchingUser || this.props.group.invitingJoin) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.props.actions.onGroupFieldChange("userList", data);
        this.setState({
            'userList': data,
            loaded: true
        });
    }

    _renderListContentInvite() {
        let dsListInvite = ds_listInviteFriend.cloneWithRows(this.state.userList);
        return (
            <View style={{ flex: 1 }}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsListInvite}
                    renderRow={this._renderRowContentInvite.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowContentInvite(data) {

        let imageChildUser = { uri: data.avatar };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        let nameFriend = data.fullName;
        let contactInfo = "";
        if (data.phone && data.email)
            contactInfo = data.phone + ' - ' + data.email;
        if (data.phone && !data.email)
            contactInfo = data.phone;
        if (!data.phone && data.email)
            contactInfo = data.email;
        return (
            <View style={styles.viewListFriends}>
                <View style={styles.viewEachRow}>
                    <Image
                        resizeMode={"cover"}
                        source={imageChildUser}
                        defaultSource={defaultCover}
                        style={styles.mainUserChild} />
                    <View style={styles.contentEachFriend}>
                        <Text style={styles.textFriendAdd}>{nameFriend}</Text>
                        <Text style={[styles.textDeny, { color: gui.colorMainBlur }]}>{contactInfo}</Text>
                    </View>
                    {this._renderInviteButton(data)}
                </View>
            </View>
        );
    }

    _renderInviteButton(data) {

        if (data.canInvite)
            return (
                <CheckBox
                    selected={data.checked}
                    onPress={this._onPressCheckBox.bind(this, data)} />
            )
        else return (
            <Icon name="ban" size={18} color={gui.mainColor} />
        )
    }

    _onPressCheckBox(data) {
        // this.setState({
        //     checkBox: !this.state.checkBox
        // })        

        let currentList = this.state.userList;
        currentList.map((e) => {
            if (e.id == data.id)
                e.checked = !e.checked;
        })
        // console.log('new currentList ====>', currentList);
        this.props.actions.onGroupFieldChange("userList", currentList);
        this.setState({ userList: currentList });
    }


    _renderButtonAdd() {
        let totalFriendAdd = 0;
        this.state.userList.forEach((e) => {
            if (e.checked)
                totalFriendAdd++;
        });

        totalFriendAdd = 'MỜI ' + totalFriendAdd + ' NGƯỜI';
        return (
            <View style={styles.viewButtonInvite}>
                <TouchableOpacity
                    onPress={this._onInvite.bind(this)}
                    style={styles.buttonInviteFriend}>
                    <Text style={styles.textButtonInvite}>{totalFriendAdd}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _onPressClose() {
        this.props.actions.onGroupFieldChange("userList", []);
        this.setState({
            'userList': [],
        });
        this.props.actions.getAllMember(
            { 'groupID': this.props.groupID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
            }
            , (error) => {
                console.log('server respond error: =====>>>>>', error)
            });

        this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
        Actions.pop();
    }

    _onInvite() {
        let userList = this.state.userList ? this.state.userList.filter((e) => e.checked) : [];

        if (!userList || userList.length == 0) {
            Alert.alert(
                "Thông báo",
                "Tích chọn để mời bạn bè tham gia sàn của bạn.",
                [{ text: 'Đóng', onPress: () => { } }])
            return;
        }

        let members = [];
        let memberIDs = [];
        userList.forEach((e) => {
            memberIDs.push(e.id)
            members.push(
                {
                    member: e.id,
                    memberName: e.fullName,
                    memberAvatar: e.avatar
                })
        });

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let inviteAllToJoinDto = {
            "requester": currentUser.userID || undefined,
            "approver": members || undefined,
            "members": members || undefined,
            "memberIDs": memberIDs || undefined,
            "groupID": this.props.groupID || undefined,
            "groupName": this.props.groupData.name || undefined,
            "groupImage": this.props.groupData.image || undefined
        };

        this.props.actions.inviteAllToJoin(inviteAllToJoinDto, token)
            .then(res => {
                // console.log("server respond: ", res);
                this.setState({
                    loading: false,
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    let newState = this.state.userList;
                    userList.forEach((e) => {
                        newState.reduce(function (filtered, oldValue) {
                            if (oldValue.id == e.id) {
                                var newValue = oldValue;
                                newValue.canInvite = false;
                                newValue.checked = false;
                                filtered.push(newValue);
                            } else {
                                filtered.push(oldValue);
                            }
                            return filtered;
                        }, []);
                    });
                    this.setState({ userList: newState });
                    let userID = this.props.global.currentUser.userID || undefined;
                    let token = this.props.global.currentUser.token || undefined;
                    this.props.actions.getRelatedGroup({ userID: userID }, token, () => { });
                    setTimeout(() => Alert.alert(
                        "Thông báo",
                        "Thành viên đã được thêm vào nhóm.",
                        [{ text: 'Đóng', onPress: () => { } }]), 1000);
                }
            });
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeadInvite: {
        marginTop: 10,
        height: 38,
        width: width,
        flexDirection: 'row'
    },
    viewCloseIcon: {
        width: 50,
        height: 38,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 21
    },
    viewTextDeny: {
        width: width - 50,
        height: 38,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    textDeny: {
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontSize: 15
    },
    viewInviteText: {
        height: 36,
        marginTop: 23,
        width: width,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    textAddFriends: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewContentInvite: {
        flex: 1,
        backgroundColor: gui.groupBackground,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    inputFilterFriend: {
        height: 50,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 16,
        paddingRight: 16
    },
    viewIconSearch: {
        width: 18,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextInput: {
        width: width - 50,
        height: 50,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewInputContent: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        backgroundColor: gui.groupBackground,
        width: width - 50,
        height: 38,
        paddingLeft: 10,
        color: gui.mainTextColor
    },
    viewListFriends: {
        flex: 1,
        paddingVertical: 7
    },
    viewEachRow: {
        width: width - 32,
        height: 48,
        marginTop: 16,
        marginLeft: 16,
        marginRight: 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    mainUserChild: {
        height: 48,
        width: 48,
        borderRadius: 24
    },
    viewCheckFriends: {
        height: 48,
        width: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
    contentEachFriend: {
        height: 48,
        width: width - 104,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    textFriendAdd: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainTextColor,
        fontSize: 17
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 32,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 16
    },
    viewListContainer: {
        paddingBottom: 82
    },
    viewButtonInvite: {
        width: width,
        height: 80,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        position: 'absolute',
        bottom: 0, //0
        borderTopWidth: 1,
        borderColor: '#dcdcdc'
    },
    buttonInviteFriend: {
        height: 48,
        width: width - 32,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    textButtonInvite: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#fff',
        fontSize: 15
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(InviteFriends);