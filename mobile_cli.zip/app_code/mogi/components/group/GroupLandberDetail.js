'use strict';
import React, { Component } from 'react';

import type, {
    StyleObj
} from 'react-native/Libraries/StyleSheet/StyleSheetTypes';

import {
    View, Text, StyleSheet, TextInput, ScrollView, ListView, TouchableOpacity, ViewPropTypes, StatusBar,
    ImageBackground, Alert, NetInfo, Image, FlatList,
    ActivityIndicator
} from 'react-native';
import Button from 'react-native-button';
import { Actions } from 'react-native-router-flux';
import ScalableText from 'react-native-text';

import { bindActionCreators } from 'redux';
import LinearGradient from 'react-native-linear-gradient';
import { connect } from 'react-redux';
import NonEditTag from './NonEditTag';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Modal from 'react-native-modalbox';
import SummaryText from '../SummaryText';
import CommonUtils from '../../lib/CommonUtils';
import Icon from 'react-native-vector-icons/FontAwesome';
import Communications from 'react-native-communications';
import GiftedSpinner from "../GiftedSpinner";
import UserModal from '../UserModal';
import userApi from '../../lib/userApi';

import Camera from 'react-native-camera';
var Analytics = require('react-native-firebase-analytics');

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const Permissions = require('react-native-permissions');
import Toast, { DURATION } from '../toast/Toast';
import OfflineBar from '../line/OfflineBar';
import FontAwesomeLight from '../font/FontAwesomeLight';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as wallActions from '../../reducers/wall/wallActions';
import DanhMuc from '../../assets/DanhMuc';
import { Map } from 'immutable';
import FullLine from '../line/FullLine';
import gui from "../../lib/gui";
import log from "../../lib/logUtil";
import utils from '../../lib/utils';
const { width, height } = utils.getDimensions();

let ds_groupRequest = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

const actions = [
    globalActions,
    meActions,
    groupActions,
    chatActions,
    wallActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupDetail extends React.Component {
    constructor(props) {
        super(props);
        let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(props.group.searchResult.listRelatedGroup);
        this.state = {
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null,
            'data': null,
            loaded: false,
            modal: false,
            headerColor: 'transparent',
            headerButtonColor: 'white',
            sendButtonColor: 'white',
            backButtonColor: 'white',
            heartBgColor: '#4A443F',
            isChatLoading: false,
            diaBans: [],
            duAns: [],
            isOpenModalJoin: false,
            hashRelatedGroupStatus: hashRelatedGroupStatus,
            textToChuSan: props.group.textToChuSan,
            isModalContent: false,
            memberPageNo: props.wall.memberPageNo,
            isMounted: false
        }
        
    }


    _getHashRelatedGroupStatus(listRelatedGroup) {
        let hashRelatedGroupStatus = {};
        listRelatedGroup && listRelatedGroup.forEach((one) => {
            hashRelatedGroupStatus[one.groupID] = one.joinStatus;
        });
        return hashRelatedGroupStatus;
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.groupID !== this.props.groupID) {
            this.fetchData(nextProps);
        }

        if (nextProps.group.searchResult.listGroup !== this.props.group.searchResult.listGroup) {
            let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(nextProps.group.searchResult.listRelatedGroup);
            this.setState({
                hashRelatedGroupStatus: hashRelatedGroupStatus
            });
        }

        if (nextProps.group.textToChuSan !== this.props.group.textToChuSan) {
            this.setState({
                textToChuSan: nextProps.group.textToChuSan
            });
        }

        if (nextProps.group.searchResult.listRelatedGroup !== this.props.group.searchResult.listRelatedGroup) {
            let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(nextProps.group.searchResult.listRelatedGroup);
            this.setState({
                hashRelatedGroupStatus: hashRelatedGroupStatus
            });
        }
    }

    componentWillMount() {
        this.fetchData(this.props);
    }

    componentDidMount() {
        this.setState({isMounted: true});
    }

    fetchData(props) {
        // this.props.actions.getAllMember(
        //     {
        //         'limit': 25,
        //         'pageNo': this.state.memberPageNo,
        //         "groupID":this.props.groupID,
        //         "isIncludeCountInResponse":true
        //     }
        //     , (res) => {
        //         // console.log('server respond data: =====>>>>>', res);
        //     }
        //     , (error) => {
        //     });

        if (props.groupData) {
            this.refreshRowData(props.groupData);
            return;
        }

        this.setState({ data: null, loaded: false });
        props.actions.getGroupDetail(
            { 'groupID': props.groupID }
            , (res) => {
                this.refreshRowData(res.data)
            }
            , (error) => {
                this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });

    }


    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {
            this.setState({ msgType: 'fadeOutUp' })
        }, 5000);
    }

    refreshRowData(group) {
        let duAns = group.diaBan && group.diaBan.filter((e) => e.type == DanhMuc.placeType.DU_AN);
        let diaBans = group.diaBan && group.diaBan.filter((e) => e.type == DanhMuc.placeType.TINH || e.type == DanhMuc.placeType.HUYEN);

        this.setState({
            'data': group,
            duAns: duAns,
            diaBans: diaBans,
            loaded: true
        });

    }

    render() {
        let groupData = this.state.data;
        let dataForRender = [];
        let dataMember = this.props.wall.memberList.filter((e) => {
            return e.member != groupData.userID
        })
        return (
            <View style={{ flex: 1 }}>
                <OfflineBar />
                {this.renderHeaderDetail()}
                <View style={{flex: 1}}>
                    <FlatList
                        enableEmptySections={true}
                        data={dataMember}
                        keyExtractor={(item, index) => 'list_' + index}
                        renderItem={(data) => this._renderRowMember(data.item)}
                        style={styles.viewListContainer}
                        showsVerticalScrollIndicator={false}
                        initialNumToRender={25}
                        onEndReachedThreshold={0}
                        onEndReached={this.loadNextPage.bind(this)}
                        ListHeaderComponent={this._renderHeaderContent()}
                        ListFooterComponent={() =>
                            !this.state.loaded
                                ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
                                : null}
                    />
                </View>
                {this._renderLoadingView()}
                {this._openModalJoin()}
                {this._openModalDetail()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    };

    _renderHeaderContent() {
        return(
            <View style={{width: width, height: 'auto'}}>
                <View style={styles.lineSuggest} />
                {this._renderChuSan()}
                <View style={styles.lineSuggest} />
                <View style={styles.blockView}>
                <Text style={[styles.titleText]}>Thành viên</Text>
                    <FullLine style={{ marginTop: 6 }} />
                </View>
            </View>
        )
    }

    _openModalDetail() {
        return (
            <Modal isOpen={this.state.isModalContent}
                   onClosed={this.outModalDetail.bind(this)}
                   style={styles.viewModalDetail}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={true}
                   animationDuration={200}
            >
                <UserModal groupName={this.state.data && this.state.data.name ? this.state.data.name : ''}
                           data={this.state.dataContent}
                           onClosePress={this.outModalContent.bind(this)} />
            </Modal>
        );
    }

    outModalDetail() {
        this.setState({
            isModalContent: false,
            dataContent: null
        })
    }

    outModalContent() {
        this.setState({
            isModalContent: false
        })
    }

    onDetailContent(data) {
        this.onLogEvent('Xem chi tiết','listItem')
        this.setState({
            isModalContent: true,
            dataContent: data
        })
    }

    renderHeaderDetail() {
        let group = this.state.data;
        let groupName = group && group.name || '';
        let countMember = this.props.wall.numOfMember;
        //add fake number theo yeu cau Marketing
        countMember = countMember + 2000

        let textMember = `${utils.addCommas(countMember)} thành viên`;

        return <View style={styles.customPageHeader}>
            <View style={[styles.viewThongTinSan, {left:36, right:36, width: width-72,
                marginTop: 22, marginBottom: 10, paddingVertical: 0, position: 'absolute'}]}>
                <View style={[styles.viewNameMain, {width: width-72}]}>
                    <Text style={[styles.textCommon, { fontWeight: '500', fontSize: 18, color: gui.textAgentSolid }]} numberOfLines={2}>{groupName}</Text>
                </View>
                <Text style={[styles.textCommon, { fontSize: 12, color: gui.textShare, marginTop: 0 }]} numberOfLines={1}>{textMember}</Text>
            </View>
            <TouchableOpacity style={styles.viewPlusPost}
                              onPress={this._onBack.bind(this)}
            >
                <MaterialCommunityIcons name="arrow-left" size={26} color={gui.mainColor} />
            </TouchableOpacity>
        </View>
    }

    _onBack() {
        Actions.pop();
    }

    renderImage() {
        let rowData = this.state.data;
        if (!rowData) {
            return this._renderLoadingView();
        }

        let imageUri = { uri: rowData.image };
        if (!imageUri) {
            imageUri = require('../../assets/image/photo_detail_blank.jpg');
        }
        return (
            <Image style={styles.imgItem2}
                source={imageUri} defaultSource={CommonUtils.getNoCoverImage()}>
            </Image>
        );
    }

    // renderThongTinSan() {
    //     let group = this.state.data;
    //     let groupName = group && group.name || '';
    //     let countMember = this.props.groupData.countMember ? this.props.groupData.countMember : this.props.group.numOfMember

    //     //add fake number theo yeu cau Marketing
    //     countMember = countMember + 2000
        
    //     let textMember = group.groupType == 'private' ? `Nhóm riêng tư - ${countMember} thành viên`
    //         : `Nhóm công khai - ${countMember} thành viên`;
    //     return (
    //         <View style={styles.viewThongTinSan}>
    //             <View style={styles.viewNameMain}>
    //                 <Text style={[styles.textCommon, { fontWeight: '500', fontSize: 18, color: gui.textAgentSolid }]} numberOfLines={2}>{groupName}</Text>
    //             </View>
    //             <Text style={[styles.textCommon, { fontSize: 12, color: gui.textShare, marginTop: 8 }]} numberOfLines={1}>{textMember}</Text>
    //         </View>
    //     )
    // }

    _renderLoadingView() {
        if (this.props.group.requestingJoin) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    onLayoutLastTag = (endPosOfTag: number) => {
        const margin = 3;
        this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
        const inputWidth = GroupDetail.inputWidth(
            this.state.text,
            this.spaceLeft,
            this.wrapperWidth,
        );
        if (inputWidth !== this.state.inputWidth) {
            this.setState({ inputWidth });
        }
    }

    static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
        if (text === "") {
            return 90;
        } else if (spaceLeft >= 100) {
            return spaceLeft - 10;
        } else {
            return wrapperWidth;
        }
    }

    removeDiaBan = (index: number) => {

    }

    removeDuAn = (index: number) => {
    }


    _renderMoTa() {
        let rowData = this.state.data;
        if (!rowData) {
            return this._renderLoadingView();
        }
        let joinStatus = this.state.hashRelatedGroupStatus[rowData.groupID];
        return (
            <View style={styles.blockView}>
                <View style={styles.viewTopJoin}>
                    <View>
                        <Text style={styles.titleText}>Mô tả</Text>
                    </View>
                    <View style={styles.viewButtonJoin}>
                        {/*joinStatus != 1 && joinStatus != 2 ?
                            (<TouchableOpacity style={styles.touchJoinGroup}
                                onPress={this._onJoinGroupPress.bind(this)}
                            >
                                <Text style={styles.groupStatus}>Tham gia</Text>
                            </TouchableOpacity>)
                            : (
                                joinStatus == 1 ?
                                    <View style={styles.touchJoinGroup}
                                    >
                                        <Text style={styles.groupStatus}>Chờ duyệt</Text>
                                    </View>
                                    : null
                            )
                        */}
                    </View>
                </View>
                <FullLine style={{ marginTop: 6 }} />
                <View style={{ marginTop: 11 }}>
                    <SummaryText
                        style={{ color: gui.colorMainBlur }}
                        textProps={{
                            fontWeight: 'normal',
                            fontFamily: gui.fontFamily,
                            color: gui.textAgentSolid,
                            fontSize: 15
                        }}
                        longText={rowData.chiTiet}
                        expanded={false}
                        maxLength={200}
                        width={width - 43}>
                    </SummaryText>
                </View>
            </View >
        )
    }

    _onJoinGroupPress() {
        this.setState({
            isOpenModalJoin: true
        });
    }

    _onContentModal() {
        this.setState({
            isOpenModalJoin: false
        });
    }

    _openModalJoin() {
        return (
            <Modal isOpen={this.state.isOpenModalJoin}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle2}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                {this._renderJoinContent()}
            </Modal>
        );

    }

    _renderJoinContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={{ marginTop: 18, marginLeft: 0, width: width - 80, height: 108 }}>
                    <TextInput
                        autoFocus={false}
                        autoCapitalize='none'
                        autoCorrect={false}
                        returnKeyType='done'
                        multiline={true}
                        style={styles.viewTextInput}
                        placeholder="Để lại ghi chú cho chủ sàn…" placeholderTextColor={gui.arrowColor}
                        onChangeText={(text) => { this.onValueChange("textToChuSan", text) }}
                        value={this.state.textToChuSan}

                    />
                </View>
                {this._renderButtonJoin()}
            </View>
        )
    }

    onValueChange(key, value) {
        this.setState({ textToChuSan: value })
    }

    _renderButtonJoin() {
        if (this.props.group.requestingJoin)
            return (<View style={styles.searchButtonView}>
                <View
                    style={styles.searchButton}
                >
                    <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                </View>
            </View>)
        return (
            <View style={styles.searchButtonView}>
                <TouchableOpacity
                    style={styles.searchButton}
                    onPress={this.onRequestJoin.bind(this)}
                >
                    <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                </TouchableOpacity>
            </View>
        )

    }

    onRequestJoin() {
        let rowData = this.props.groupData;

        if (!rowData)
            return;

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let requestJoinDto = {
            "requester": currentUser.userID || undefined,
            "requesterName": currentUser.fullName || currentUser.phone || currentUser.email || undefined,
            "approver": rowData.userID || rowData.createdBy || undefined,
            "member": currentUser.userID || undefined,
            "memberName": currentUser.fullName || undefined,
            "memberNameKhongDau": utils.locDauV2(utils.standardlizeName(currentUser.fullName)),
            "memberAvatar": currentUser.avatar || undefined,
            "groupID": rowData.groupID || undefined,
            "groupName": rowData.name || undefined,
            "groupImage": rowData.image || undefined,
            "message": this.state.textToChuSan
        };

        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let fetchRelatedGroupSuccess = this.props.actions.fetchRelatedGroupSuccess;

        this.props.actions.requestToJoin(requestJoinDto, token)
            .then(res => {
                this.setState({
                    loading: false,
                    isOpenModalJoin: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    rowData.joinStatus = 1;
                    let found = listRelatedGroup.find((one) => {
                        return one.groupID == rowData.groupID
                    });
                    if (found) {
                        listRelatedGroup = listRelatedGroup.filter((one) => {
                            return one.groupID != rowData.groupID
                        });
                    }
                    listRelatedGroup = [...listRelatedGroup, rowData];
                    fetchRelatedGroupSuccess(listRelatedGroup);

                    this.props.actions.onGroupFieldChange("textToChuSan", "");
                    this.setState({ textToChuSan: '' });

                    setTimeout(
                        () =>
                            this.refs.toastTop && this.refs.toastTop.show("Xác nhận yêu cầu tham gia sàn được gửi thành công và đang chờ duyệt.", DURATION.LENGTH_LONG), 500)
                        ;
                }
            });
    }

    _renderChuSan() {
        let rowData = this.state.data;
        if (!rowData) {
            return this._renderLoadingView();
        }
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarUri = rowData.thumbnailAvatar ? { uri: rowData.thumbnailAvatar } :
            (rowData.avatar ? { uri: rowData.avatar } : defaultAvatar)  ;

        return (
            <View style={styles.blockView}>
                <Text style={[styles.titleText]}>Quản trị</Text>
                <FullLine style={{ marginTop: 6 }} />
                <TouchableOpacity
                    onPress={this.onDetailContent.bind(this, rowData)}
                    style={[styles.viewChuSan]}
                >
                    <View style={styles.iconChuSan}>
                        <Image style={styles.iconChuSan} source={avatarUri}
                            defaultSource={defaultAvatar} />
                    </View>
                    <View style={styles.tenChuSan}>
                        <View style={styles.viewTen}>
                            <Text numberOfLines={1} style={styles.textTen}>{rowData.fullNameChuSan}</Text>
                        </View>
                        {rowData.phoneChuSan ?
                            <View style={styles.viewPhone}>
                                <Text numberOfLines={1} style={styles.textPhone}>{rowData.phoneChuSan}</Text>
                            </View> : null
                        }
                    </View>
                    <View style={styles.phoneChuSan}>
                        <TouchableOpacity onPress={this._onPhoneClicked.bind(this)}>
                            <FontAwesomeLight name="phone" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.chatChuSan}>
                        <TouchableOpacity onPress={this._onChatClicked.bind(this)}>
                            <FontAwesomeLight name="comment-dots" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                </TouchableOpacity>

            </View>
        )
    }

    renderThanhVien() {
        // let countMember = this.props.groupData.countMember ? this.props.groupData.countMember : this.props.group.memberList.length
        // return (
        //     <TouchableOpacity style={styles.viewThanhVien}
        //         onPress={this.onAllThanhVien.bind(this)}
        //     >
        //         <View style={styles.iconUsers}>
        //             <FontAwesomeLight name="users" size={14} color={gui.mainTextColor} noAction={true} iconOnly={true} />
        //         </View>
        //         <View style={styles.tenChuSan}>
        //             <View style={[styles.viewTen, { marginLeft: 2 }]}>
        //                 <Text numberOfLines={1} style={styles.textTen}>Thành Viên</Text>
        //             </View>
        //         </View>
        //         <View style={styles.viewArrowRight}>
        //             <Text numberOfLines={1} style={[styles.textTen, { color: gui.textShare, marginRight: 8 }]}>{countMember}</Text>
        //             {/*<FontAwesomeLight name="chevron-right" size={14} color={gui.textShare} noAction={true} iconOnly={true} />*/}
        //         </View>
        //     </TouchableOpacity>
        // )
        return (
            <View style={{flex: 1}}>
                {this._renderMemberList()}
            </View>
        )
    }

    // _renderMemberList() {
    //     let groupData = this.state.data;
    //     let dataForRender = [];
    //     let dataMember = this.props.wall.memberList.filter((e) => {
    //         return e.member != groupData.userID
    //     })       
    //     return (
    //         <View style={{ flex: 1 }}>
    //             <View style={styles.blockView}>
    //                 <Text style={[styles.titleText]}>Thành viên</Text>
    //                 <FullLine style={{ marginTop: 6 }} />
    //             </View>
    //             <FlatList
    //                 enableEmptySections={true}
    //                 data={dataMember}
    //                 keyExtractor={(item, index) => 'list_' + index}
    //                 renderItem={(data) => this._renderRowMember(data.item)}
    //                 style={styles.viewListContainer}
    //                 showsVerticalScrollIndicator={false}
    //                 initialNumToRender={25}
    //                 onEndReachedThreshold={0}                    
    //                 onEndReached={this.loadNextPage.bind(this)}
    //                 ListHeaderComponent={this._renderHeaderContent()}
    //                 ListFooterComponent={() =>
    //                     !this.state.loaded
    //                        ? <ActivityIndicator size="small" animating style={{ marginTop: 8, marginBottom: 8 }} />
    //                         : null}
    //                 />
    //         </View>
    //     );
    // }

    loadNextPage() {
        console.log('===========> loadNextPage');
        if (!this.state.isMounted || !this.state.loaded) {
            return;
        }
        let currentPageNo = this.state.memberPageNo;
        let totalPages = this.props.wall.numOfMember / 25;
        if (totalPages && currentPageNo < totalPages) {
            this.props.actions.onWallFieldChange("memberPageNo", currentPageNo + 1)
            this.setState(state => ({ memberPageNo: state.memberPageNo + 1 }), () => this.getNextMemberPage());
        }
    };

    getNextMemberPage = () => {
        this.setState({ loaded: false });

        this.props.actions.getAllMember({
                'limit': 25,
                'pageNo': this.state.memberPageNo,
                "groupID":this.props.groupID,
                "isIncludeCountInResponse":true
            }
            , (res) => {
                log.info(' server respond data: =====>>>>> ', res.data);
                this.setState({
                    loaded: true
                });
            }
            , (error) => {
                this.setState({
                    loaded: true
                });
            }
        );
    }


    _renderRowMember(data) {
        let imgUrl = data.thumbnail //|| data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }

        let member = data.fullName;
        let phone = data.phone;
        let approveTime = data.approveTime;

        return (
            <View style={styles.viewRowContent}
            >
                <View>
                    <TouchableOpacity
                        onPress={this.onDetailContent.bind(this, data)}
                        style={styles.viewContent}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageGroup}
                            defaultSource={defaultCover}
                            style={styles.adsCover} />
                        <View style={styles.viewBodyContent}>
                            <View style={styles.viewNameGroup}>
                                <Text style={[styles.textNameGroup, { marginLeft: 8 }]} numberOfLines={1}>{member}</Text>
                            </View>
                            <View style={styles.viewTimeGroup}>
                                <Text style={[styles.textNameAvatar, { marginLeft: 8 }]}>Tham gia {utils.getDiffTime(approveTime)}</Text>
                            </View>
                        </View>
                        <TouchableOpacity style={styles.approve}
                                          onPress={this.onPhoneDetail.bind(this, phone)}>
                            <FontAwesomeLight name="phone" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.reject}
                                          onPress={this.onChat.bind(this, data)}>
                            <FontAwesomeLight name="comment-dots" size={20} color={gui.mainColor} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </TouchableOpacity>
                    <FullLine />
                </View>
            </View>
        )
    }

    onPhoneDetail(phone) {
        if (!phone) {
            return;
        }
        this.onLogEvent('Gọi điện','button')
        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(phone, true);
        Analytics.logEvent('GROUPMEMBER_USER_DIALING', { deviceID: deviceID, userID: userID, phone: phone });
    }

    onLogEvent(title, componentType) {
        let eventDto = {
            scene: "GroupLandberDetail",
            parentScene: undefined,  //truyen owner neu co
            componentType: componentType,
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,            
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    onChat(data) {
        this.onLogEvent('Chat','button')
        let partner = data.userID ? { userID: data.userID } : { userID: data.member };
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');
        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);            
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
            let isSpam = false;
            if (e.partners)
                e.partners.forEach((pn) => {
                    if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                        isSpam = true;
                })
            Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
            this.setState({
                isloadingPressRow: false
            })
        });
    }

    // onAllThanhVien() {
    //     let rowData = this.state.data;
    //     this.props.actions.getAllMember(
    //         {
    //             'limit': 25,
    //             'pageNo': this.state.memberPageNo,
    //             "groupID":this.props.groupID,
    //             "isIncludeCountInResponse":true
    //         }
    //         , (res) => {
    //             // console.log('server respond data: =====>>>>>', res)
    //             Actions.GroupMember({ groupData: rowData, groupID: rowData.groupID, groupName: rowData.name });
    //         }
    //         , (error) => {
    //         });

    // }

    _onPhoneClicked() {
        let rowData = this.state.data;
        if (!rowData.phoneChuSan) {
            return;
        }
        this.onLogEvent('Gọi điện','button')
        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(rowData.phoneChuSan, true);
        Analytics.logEvent('DETAIL_DIALING', { deviceID: deviceID, userID: userID, phone: rowData.phoneChuSan });
    }

    _onChatClicked() {
        this.onLogEvent('Chat','button')
        let data = this.state.data;
        let partnerID = data.userID || data.member || data.createdBy;
        let partner = { userID: partnerID };
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');
        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
            });
    }

    _renderKhuVuc() {

        let tags = this.state.diaBans && this.state.diaBans.map((tag, index) => (
            <NonEditTag
                type="DiaChinh"
                index={index}
                label={tag.placeName}
                isLastTag={this.state.diaBans.length === index + 1}
                tagContainerStyle={{ marginBottom: 1 }}
                onLayoutLastTag={this.onLayoutLastTag}
                removeIndex={this.removeDiaBan.bind(this)}
                tagColor='rgba(246,246,246,1)'
                tagTextColor={gui.textAgentSolid}
                key={index}
            />
        ))

        return (
            <View style={styles.blockView2}>
                <View style={styles.titleView}>
                    <Text style={[styles.titleText]}>Khu vực</Text>
                </View>
                <FullLine style={{ marginTop: 3 }} />
                <View style={styles.tagInputContainer}>{tags}</View>
            </View>
        )
    }

    _renderDuAn() {
        let tags = this.state.diaBans && this.state.duAns.map((tag, index) => (
            <NonEditTag
                type="DuAn"
                index={index}
                label={tag.placeName}
                isLastTag={this.state.duAns.length === index + 1}
                onLayoutLastTag={this.onLayoutLastTag}
                removeIndex={this.removeDuAn.bind(this)}
                tagContainerStyle={{ marginBottom: 1 }}
                tagColor='rgba(246,246,246,1)'
                tagTextColor={gui.textAgentSolid}
                key={index}
            />
        ))
        return (
            <View style={styles.blockView2}>
                <View style={styles.titleView}>
                    <Text style={[styles.titleText]}>Dự án</Text>
                </View>
                <FullLine style={{ marginTop: 3 }} />
                {this.state.duAns.length > 0 ?
                    <View style={styles.tagInputContainer}>{tags}</View> :
                    <View>
                        <Text style={[styles.titleText, { fontSize: 14, fontWeight: 'normal', marginTop: 8 }]}>Nhóm hiện tại chưa thuộc dự án nào</Text>
                    </View>
                }
            </View>
        )
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(GroupDetail);

const styles = StyleSheet.create({
    joiningView: {
        backgroundColor: '#FFFFFFFF',
        height: 56,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        shadowColor: '#1A526173',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0,
        borderBottomWidth: 1,
    },
    joiningView2: {
        backgroundColor: 'transparent',
        height: 24,
        width: 128,
        marginLeft: 10
    },
    contentView: {
        flex: 1
    },
    cancelView: {
        backgroundColor: 'transparent',
        marginTop: 40,
        marginLeft: 16,
        width: 24,
        height: 24
    },
    joinButton: {
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
        width: 20,
        height: 20
    },
    headerView2: {
        backgroundColor: 'transparent',
        marginTop: 10,
        marginLeft: 16,
        width: width - 32,
    },
    headerView3: {
        backgroundColor: 'transparent',
        marginTop: 4,
        marginLeft: 16,
        width: width - 16,
        height: 20
    },
    headerText2: {
        fontSize: 15,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: '#FFFFFFFF'
    },
    headerText: {
        fontSize: 24,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#FFFFFFFF'
    },
    joinText: {
        fontSize: 17,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    viewTen: {
        width: width - 170
    },
    viewPhone: {
        width: width - 170
    },
    textTen: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid
    },
    textPhone: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textShare
    },
    titleView: {
        height: 24
    },
    titleText: {
        fontSize: 16,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid
    },
    blockView: {
        width: width - 32,
        marginTop: 12,
        marginLeft: 16,
        paddingBottom: 8
    },
    blockView2: {
        width: width - 32,
        marginTop: 12,
        marginLeft: 16,
        height: 'auto',
        paddingBottom: 8
    },
    viewChuSan: {
        marginTop: 17,
        marginLeft: 0,
        height: 48,
        width: width - 32,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    scrollView: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'stretch',
    },
    tagInputContainer: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    header: {
        backgroundColor: gui.mainColor,
        height: 64
    },
    iconChuSan: {
        width: 38,
        height: 38,
        borderRadius: 19
    },
    tenChuSan: {
        flex: 1,
        flexDirection: 'column',
        marginLeft: 8
    },
    phoneChuSan: {
        width: 21,
        height: 21,
        backgroundColor: 'transparent',
    },
    iconUsers: {
        width: 18,
        height: 16,
        backgroundColor: '#fff'
    },
    chatChuSan: {
        width: 21,
        height: 21,
        marginLeft: 15,
        backgroundColor: 'transparent',
    },
    viewArrowRight: {
        width: 40,
        height: 40,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row'
    },
    imgItem2: {
        width: width,
        height: 183,
        alignSelf: 'auto'
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    linearGradient: {
        flexGrow: 1,
        width: width,
        height: 188,
    },
    viewTopJoin: {
        alignItems: 'center',
        flexDirection: 'row'
    },
    touchJoinGroup: {
        borderRadius: 3,
        borderColor: gui.mainAgentColor,
        borderWidth: 1,
        height: 24,
        width: 72,
        justifyContent: 'center',
        alignItems: 'center'
    },
    groupStatus: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainAgentColor,
        textAlign: 'center'
    },
    viewButtonJoin: {
        position: 'absolute',
        right: 0
    },
    viewThongTinSan: {
        height: 'auto',
        width: width,
        backgroundColor: '#fff',
        alignItems: 'center',
        paddingVertical: 12
    },
    textCommon: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        textAlign: 'center'
    },
    viewNameMain: {
        height: 'auto',
        width: width - 64,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    viewBottomSpace: {
        width: width,
        height: 34,
        backgroundColor: '#fff'
    },
    viewThanhVien: {
        height: 'auto',
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewModalStyle2: {
        justifyContent: 'center',
        height: 210,
        width: width - 30,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexGrow: 1,
        borderRadius: 8
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        width: width - 80
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 48,
        bottom: 17,
        width: width,
        backgroundColor: 'transparent',
    },
    searchButton: {
        height: 48,
        width: width - 64,
        backgroundColor: gui.mainColor,
        borderRadius: 24,
        alignItems: 'center',
        justifyContent: 'center'
    },
    searchButtonText: {
        color: '#FFFFFFFF',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#fff',
        height: 64
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        // paddingRight: 21,
        marginTop: 22,
        marginLeft: 16
    },
    viewListContainer: {
        // paddingBottom: 50
        flex: 1
    },
    viewRowContent: {
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent'
    },
    viewContent: {
        width: width - 32,
        height: 60,
        marginTop: 10,
        marginBottom: 10,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row',
    },
    adsCover: {
        width: 60,
        height: 60,
        marginLeft: 0,
        borderRadius: 30
    },
    viewBodyContent: {
        backgroundColor: 'transparent',
        height: 48,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginRight: 6
    },
    viewNameGroup: {
        backgroundColor: 'transparent',
        height: 24,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    viewTimeGroup: {
        backgroundColor: 'transparent',
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.textShare,
        fontWeight: 'normal'
    },
    approve: {
        width: 21,
        height: 21,
        backgroundColor: 'transparent',
    },
    reject: {
        width: 21,
        height: 21,
        marginLeft: 15,
        backgroundColor: 'transparent',
    },
    viewModalDetail: {
        justifyContent: 'flex-start',
        height: 'auto',
        backgroundColor: 'transparent',
        alignItems: 'center',
    },
});