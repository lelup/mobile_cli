import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableHighlight,
    Alert
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';

import { Map } from 'immutable';
import gui from '../../lib/gui';
import utils from '../../lib/utils';

import Toast, {DURATION} from '../toast/Toast';
import Modal from 'react-native-modalbox';
import Communications from 'react-native-communications';
var Analytics = require('react-native-firebase-analytics');

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as chatActions from '../../reducers/chat/chatActions';


import ScalableText from 'react-native-text';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

const actions = [
    globalActions,
    meActions,
    groupActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_groupRequest = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

let { width, height } = utils.getDimensions();

class GroupMember_old extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            searchText: '',
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null,
            loaded: false,
            isOpenMoreModal: false,
            selectedMember: null
        }
    }

    componentWillMount() {
        setTimeout(() => this.fetchData(this.props), 300);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        
        //Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.groupID !== this.props.groupID) {
            this.fetchData(nextProps);
        }
    }

    fetchData(props) {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.props.actions.getAllMember(
            { 'groupID': props.groupID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
                this.refreshRowData(res.data)
            }
            , (error) => {
                this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });

    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'memberList': data,
            loaded: true
        });

    }

    render() {
        let groupData = this.props.groupData;        
        let dataForRender = [];
        this.props.group.memberList.forEach((e)=>{
            if (e.member != groupData.userID)
                dataForRender.push(e);    
        })
        let extRowItem = (
            dataForRender.length == 0 ? <View>
                <View style={styles.headerView3}>
                    <Text style={[styles.headerText2]}>Chủ sàn</Text>
                </View>
                {this._renderRowAdmin()}
            </View> : null
        )
        return (
            <View style={styles.container}>
                {this._renderHeader()}

                <ScrollView
                    //contentContainerStyle={{ width: width, height: height - 80 - 135.4 }}
                    automaticallyAdjustContentInsets={false}
                    showsVerticalScrollIndicator={false}
                    vertical={true}
                    style={styles.scrollView}>
                    {extRowItem}
                    {this._renderMemberList()}
                </ScrollView>
                {this._openMoreModal()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
            </View>
        );
    }

    _onMoreButtonPress(data) {
        let groupData = this.props.groupData;
        let userID = this.props.global.currentUser.userID;

        if(userID != groupData.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Tính năng này chỉ dành cho chủ sàn',DURATION.LENGTH_LONG);
        } else  {
            this.setState({selectedMember: data, isOpenMoreModal: true});
        }
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {        
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                   onClosed={this._outMoreModal.bind(this)}
                   style={[styles.viewModalStyle, {height: 116}]}
                   position={"bottom"}
                   swipeToClose={false}
                   animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {
        let mainItems = null;        
        
            mainItems = <View style={[styles.viewSwipeButton, {height: 52}]}>
                <TouchableOpacity onPress={this._onLeaveGroupPress.bind(this)} style={styles.viewButtonModal}>
                    <Text style={styles.textMoreButton}>Xoá khỏi sàn</Text>
                </TouchableOpacity>
            </View>;
        
        return(
            <View style={styles.viewShowModal}>
                {mainItems}        
            </View>
        )
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn xoá thành viên khỏi sàn ?');
    }

    _doLeaveOrCall(title) {
        let selectedMember = this.state.selectedMember;
        if (!selectedMember) {
            return;
        }        
        if (this.props.global.currentUser.userID != this.props.groupData.userID) {
            Alert.alert('Thông báo', 'Bạn không phải là quản trị của sàn \'' + this.props.groupData.name + '\' ?');
            this._outMoreModal(); 
            return;
        }
        Alert.alert('Thông báo', title,
            [   { text: 'Hủy', onPress: () => {this._outMoreModal()}
            },
                {
                    text: 'Đồng ý', onPress: () => {
                    let groupID = this.props.groupID;
                    let groupData = this.props.groupData;
                    let userID = selectedMember.member;
                    let admin = this.props.groupData.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.kickMember({groupID: groupID, groupData: groupData, userID: userID, admin: admin}, token);
                    this._outMoreModal();
                }
                }
            ]);        
    }

    _renderHeader() {

        return (
            <View style={styles.headerView}>
                <View style={styles.cancelView}>
                    <View style={{ width: width - 24 - 24 - 20 }}>
                        <TouchableOpacity
                            onPress={this._onCancelClicked.bind(this)}>
                            <MaterialCommunityIcons name="close" size={24} color={gui.mainTextColor} />
                        </TouchableOpacity>
                    </View>

                    {/* <TouchableOpacity onPress={this._onAddMemberPress.bind(this)}>
                        <Icon name="plus" size={20} color="#526173" />
                    </TouchableOpacity> */}

                    <TouchableOpacity
                            style={{ flexDirection: 'row' }}
                            onPress={this._onAddMemberPress.bind(this)}>
                            <View style={{ justifyContent: 'center', alignItems: 'flex-end' }}>
                                <MaterialCommunityIcons name="plus" size={24} color={gui.mainTextColor} />
                            </View>
                    </TouchableOpacity>
                </View>
                <View style={styles.headerView2}>
                    <Text style={[styles.headerText]}>Thành viên</Text>
                </View>

            </View>
        );

    }

    _onCancelClicked() {        
        Actions.pop();
    }

    _onAddMemberPress() {
        Actions.InviteFriends({ groupData: this.props.groupData, groupID: this.props.groupID });
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }
    _renderMemberList() {
        let groupData = this.props.groupData;
        let dataForRender = [];
        this.props.group.memberList.forEach((e)=>{
            if (e.member != groupData.userID)
                dataForRender.push(e);    
        })
        let dsRequest = ds_groupRequest.cloneWithRows(dataForRender);
        return (
            <View style={{ flex: 1 }}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsRequest}
                    renderRow={(rowData, sectionID, rowID) => this._renderRowMember(rowData, (rowID == 0))}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                    //scrollEnabled={false}
                />
            </View>
        );
    }

    _renderRowMember(data, isFirstRow) {
        let imgUrl = data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }

        let member = data.fullName;
        let phone = data.phone;
        let approveTime = data.approveTime;
        // if (data.username == this.props.groupData.usernameChuSan)
        //     return null;

        let extControl = null;
        if (isFirstRow) {
            extControl = <View>
                <View style={styles.headerView3}>
                    <Text style={[styles.headerText2]}>Chủ sàn</Text>
                </View>
                {this._renderRowAdmin()}
                <View style={[styles.headerView3, {marginBottom: 15}]}>
                    <Text style={[styles.headerText2]}>Thành viên</Text>
                </View>
            </View>
        }
        return (
            <View style={styles.viewRowContent}>
                {extControl}
                <View style={styles.viewContent}>
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsCover} />
                    <View style={styles.viewBodyContent}>
                        <View style={styles.viewNameGroup}>
                            <Text style={[styles.textNameGroup, { marginLeft: 16 }]} numberOfLines={1}>{member}</Text>
                        </View>
                        <View style={styles.viewTimeGroup}>
                            <Text style={[styles.textNameAvatar, { marginLeft: 16 }]}>Tham gia {utils.getDiffTime(approveTime)}</Text>
                        </View>
                    </View>
                    <View style={styles.approve}>
                        <TouchableOpacity onPress={this.onChat.bind(this, data)}>
                            <Icon name="comments" size={18} color="#526173" />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.reject}>
                        <TouchableOpacity onPress={this._onMoreButtonPress.bind(this, data)}>
                            <Icon name="ellipsis-v" size={18} color="#526173" />
                        </TouchableOpacity>
                    </View>
                </View>

            </View>
        )
    }

    _renderRowAdmin() {
        // let data = {
        //     avatar: "https://s3-ap-southeast-1.amazonaws.com/dev.landber/eef2fefe-6605-421a-b461-69ed7a101102.JPG",
        //     member: "admin quyen luc",
        //     phone: "0911111111"
        // }
        let data = this.props.groupData;
        let imgUrl = data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }

        let member = data.fullNameChuSan;
        let phone = data.phoneChuSan;

        return (
            <View style={styles.viewRowContent}>
                <View style={styles.viewContent}>
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsCover} />
                    <View style={styles.viewBodyContent}>
                        <View style={styles.viewNameGroup}>
                            <Text style={[styles.textNameGroup, { marginLeft: 16 }]} numberOfLines={1}>{member}</Text>
                        </View>
                        <View style={styles.viewTimeGroup}>
                            <Text style={[styles.textNameAvatar, { marginLeft: 16 }]}>{phone}</Text>
                        </View>
                    </View>
                    <View style={styles.approve}>
                        <TouchableOpacity onPress={this.onPhone.bind(this, data)}>
                            <Icon name="phone" size={18} color="#526173" />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.reject}>
                        <TouchableOpacity onPress={this.onChat.bind(this, data)}>
                            <Icon name="comments" size={18} color="#526173" />
                        </TouchableOpacity>
                    </View>
                </View>

            </View>
        )
    }

    onChat(data) {
        // console.log('onChat data ======>>>>', data);
        let partner = data.userID ? { userID: data.userID } : { userID: data.member };
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');
        if (this.props.global.currentUser.userID == partner.userID) {
            Alert.alert("Thông báo", 'Bạn không thể chat với chính mình.', [{ text: 'Đóng', onPress: () => { } }]);
            return; 
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if(e.partners)
                e.partners.forEach((pn) => {
                    if (pn.userID==this.props.global.currentUser.userID && pn.spamStatus==2)  
                    isSpam=true;
                })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
                this.setState({
                    isloadingPressRow: false
                })
            });
    }

    onPhone(rowData) {        
        if (!rowData.phoneChuSan) {
          return;
        }
    
        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
          let currentUser = this.props.global.currentUser;
          userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(rowData.phoneChuSan, true);
        Analytics.logEvent('DETAIL_DIALING', { deviceID: deviceID, userID: userID, phone: rowData.phoneChuSan });
    }

    _renderDatePicker(){
        return (
            <View style={[style.rowIconContainer, {paddingRight: 15}]}>
                <Text style={[style.contentLabel]}>
                    Thời gian
                </Text>
                <View style={style.arrowIcon}>
                    {/*<Text style={style.label}>{this._getNgaySinh()}</Text>*/}
                    <DatePicker
                        style={{
                            width: width/2 - 30,
                            marginRight: 10,
                            borderColor: '#dcdcdc',
                            borderWidth: 1
                        }}
                        showIcon={false}
                        date={this._getNgaySinh()}
                        mode="datetime"
                        placeholder="Chọn ngày"
                        format="DD/MM/YYYY"
                        minDate="01/01/2017"
                        maxDate="31/12/2018"
                        confirmBtnText="Chọn"
                        cancelBtnText="Hủy"
                        onDateChange={this._onNgaySinhChange.bind(this)}
                    />
                    {/*<TruliaIcon name={"arrow-down"} color={gui.arrowColor} size={18} />*/}
                </View>
            </View>
        );
    }

    _onApprove(data, newStatus) {
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let approveJoinDto = {
            "approver": currentUser.userID || undefined,
            "newStatus": newStatus,
            "groupMemberID": data.id || undefined,
            "member": data.member || undefined,
            "groupID": this.props.groupID,
            "groupName": this.props.groupData.name,
            "groupImage": this.props.groupData.image
        };

        this.props.actions.approve(approveJoinDto, token)
            .then(res => {
                // console.log("server respond: ", res);
                this.setState({
                    loading: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    // Actions.popTo('root');
                    // Actions.AdsMgmt();

                    let groupID = this.state.groupID;
                    if (groupID && groupID.length > 0) {
                        setTimeout(() => Alert.alert("Thông báo", "Thay đổi thành công."), 1000);
                    } else {
                        setTimeout(() => Alert.alert(
                            "Thông báo",
                            "Phê duyệt hoàn tất.",
                            [{ text: 'Đóng', onPress: () => { } }]), 1000);
                    }
                }
            });
    }

    _onReject() { }

    _renderButtonChat() {
        let totalMessages = '23';
        return (
            <TouchableOpacity style={styles.viewButtonChat}>
                <View style={styles.viewCircleChat}>
                    <Icon name="comments-o" size={22} color={'#fff'} style={{ marginLeft: 0 }} />
                </View>
                <View style={styles.viewNumberMessage}>
                    <Text style={[styles.textNameAvatar, { fontSize: 8, color: '#fff' }]}>{totalMessages}</Text>
                </View>
            </TouchableOpacity>
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        flex: 1,
        backgroundColor: gui.groupBackground,
        paddingBottom: 50
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewIntroduce: {
        width: width,
        height: 100,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 19
    },
    viewTextTop: {
        width: width - 32,
        height: 60,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    viewTextEnd: {
        width: width - 32,
        height: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
    },
    textTopPattern: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontSize: 15
    },
    viewContent: {
        width: width - 40,
        height: 48,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewDetailEachGroup: {
        width: width - 104,
        // height: 32,
        marginTop: 6,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        marginLeft: 64
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 0,
        borderRadius: 24
    },
    viewBodyContent: {
        backgroundColor: 'transparent',
        height: 48,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 81,//31
        height: 81,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 19
    },
    viewNameGroup: {
        backgroundColor: 'transparent',
        height: 24,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeGroup: {
        backgroundColor: 'transparent',
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    textMessage: {
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        fontSize: 12
    },
    viewRowContent: {
        // height: 84,
        // borderWidth: 1,
        marginTop: 16,//14
        // borderColor: 'rgba(82,97,115,0.3)',
        width: width - 40,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
        marginLeft: 16,
        marginRight: 24
    },
    lineEachGroup: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 64,
        opacity: 0.8
    },
    viewListContainer: {
        paddingBottom: 50
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    headerView: {
        backgroundColor: 'transparent',
        height: 135.4,
        width: width
    },
    cancelView: {
        backgroundColor: 'transparent',
        marginTop: 45,
        marginLeft: 21,
        width: 24,
        height: 24,
        flexDirection: 'row'
    },
    headerView2: {
        backgroundColor: 'transparent',
        marginTop: 23,
        marginLeft: 16,
        width: width - 16,
        height: 36
    },
    headerView3: {
        backgroundColor: 'transparent',
        marginTop: 23,
        marginLeft: 16,
        width: width - 32,
        height: 24
    },
    headerText: {
        fontSize: 24,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    headerText2: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    approve: {
        width: 18,
        height: 18,
        backgroundColor: 'transparent',
    },
    reject: {
        width: 18,
        height: 18,
        marginLeft: 24,
        backgroundColor: 'transparent',
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 72,
        bottom: 49,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row'
        //borderRadius: 24
    },
    searchButton: {
        height: 41,
        width: (width - 52) / 2,
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1
    },
    searchButtonText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewModalStyle : {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal:{
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton:{
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal:{
        height: 52,
        width: width -28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color:gui.mainColor,
        fontSize:17,
        fontFamily:gui.fontFamily,
        fontWeight:'400'
    },
    rowIconContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: 'white',
        marginTop: 6,
        marginBottom: 6,
        paddingLeft: 15
    },
    arrowIcon: {
        flexDirection: "row",
        alignItems: "flex-end",
        paddingRight: 15
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupMember_old);