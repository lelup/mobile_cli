'use strict';

import React, { Component } from 'react';
import FullLine from '../line/FullLine';
import {
    Text, View, ListView, Image
    , TextInput, StyleSheet, RecyclerViewBackedScrollView
    , TouchableHighlight, StatusBar,
    TouchableOpacity,
    ScrollView
} from 'react-native';

import _ from 'lodash';
import { Actions } from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SearchInput from './SearchInputAgent';

import TabGroupMain from './TabGroupMain';
import gui from "../../lib/gui";
import log from "../../lib/logUtil";
import cfg from '../../cfg';
import localStorage from '../../lib/localStorage';

import GroupApi from '../../lib/GroupApi';

import HTML from 'react-native-render-html';

import utils from '../../lib/utils';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import DanhMuc from '../../assets/DanhMuc';
import OfflineBar from '../line/OfflineBar';
import Button from 'react-native-button';

import AlphabetListView from 'react-native-alphabetlistview'

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions'

import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

const { width, height } = utils.getDimensions();
const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    adsMgmtActions,
    groupSearchActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MainAutoComplete extends React.Component {
    constructor(props) {
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: function rowHasChanged(r1, r2) {
                return r1 !== r2;
            }
        });

        let listGroup = this._getListGroupFromFTS(props.group.searchResult.listGroup);

        this.state = {
            focused: false,
            dataSource: ds.cloneWithRows(this.buildRowsFromResults(listGroup)),
            listAdmin: [],
            listGroup: listGroup,
            text: props.group.mainSearchFields.name,
            toggleKeyboard: false,
            dataToRender: {},
            endReached: false,
            phanLoai: props.group.selectedMainSearchTab,
            phanLoaiWall: props.group.selectedMainSearchWallTab,
            lastMainSearch: props.groupSearch.lastMainSearch || []
        };
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.group.selectedMainSearchTab !== nextProps.group.selectedMainSearchTab) {
            this.setState({ phanLoai: nextProps.group.selectedMainSearchTab });
        }

        if (this.props.group.selectedMainSearchWallTab !== nextProps.group.selectedMainSearchWallTab) {
            this.setState({ phanLoaiWall: nextProps.group.selectedMainSearchWallTab });
        }

        if (nextProps.group.mainSearchFields.name !== this.props.group.mainSearchFields.name) {
            this.setState({
                text: nextProps.group.searchFields.name
            });
        }

        if (nextProps.groupSearch.lastMainSearch !== this.props.groupSearch.lastMainSearch) {
            this.setState({
                lastMainSearch: nextProps.groupSearch.lastMainSearch || []
            })
        }
    }

    _prepareDataToRender(data, pageNo, limit, isAppend) {

        let showLimit = this.state.phanLoai == 'all' ? 3 : limit * pageNo
        let dataToRender = isAppend ? this.state.dataToRender : {};

        let groupArray = [];
        if (isAppend && dataToRender[DanhMuc.mainTextSearchHeader.group]) {
            groupArray = dataToRender[DanhMuc.mainTextSearchHeader.group]
            if (groupArray[groupArray.length - 1] && groupArray[groupArray.length - 1].footer == 'footer')
                groupArray = groupArray.slice(0, groupArray.length - 1)
        }

        let contactArray = [];
        if (isAppend && dataToRender[DanhMuc.mainTextSearchHeader.contact]) {
            contactArray = dataToRender[DanhMuc.mainTextSearchHeader.contact]
            if (contactArray[contactArray.length - 1] && contactArray[contactArray.length - 1].footer == 'footer')
                contactArray = contactArray.slice(0, contactArray.length - 1)
        }

        let wallArray = [];
        if (isAppend && dataToRender[DanhMuc.mainTextSearchHeader.wall]) {
            wallArray = dataToRender[DanhMuc.mainTextSearchHeader.wall]
            if (wallArray[wallArray.length - 1] && wallArray[wallArray.length - 1].footer == 'footer')
                wallArray = wallArray.slice(0, wallArray.length - 1)
        }

        if (!data || data.length == 0) {
            return dataToRender;
        }
        data.forEach((one) => {
            if (one.type == 'Group' && groupArray.length < showLimit)
                groupArray.push(one);
            if (one.type == 'Contact' && contactArray.length < showLimit)
                contactArray.push(one);
            if (one.type == 'GroupWall' && wallArray.length < showLimit)
                wallArray.push(one);
        });

        //add footer item for each section
        if (groupArray.length > 0)
            groupArray.push({ type: 'Group', footer: 'footer' })
        if (contactArray.length > 0)
            contactArray.push({ type: 'Contact', footer: 'footer' })
        if (wallArray.length > 0)
            wallArray.push({ type: 'GroupWall', footer: 'footer' })

        if (groupArray.length > 0)
            dataToRender[DanhMuc.mainTextSearchHeader.group] = groupArray;
        if (contactArray.length > 0)
            dataToRender[DanhMuc.mainTextSearchHeader.contact] = contactArray;
        if (wallArray.length > 0)
            dataToRender[DanhMuc.mainTextSearchHeader.wall] = wallArray;

        return dataToRender;
    }

    _getListGroupFromFTS(data) {
        let listContact = [];
        let listGroup = [];
        let listWall = [];
        if (!data || data.length == 0) {
            return listGroup;
        }
        let index = 0;
        listGroup.push({
            key: index,
            name: 'Sàn BĐS',
            type: 'Group'
        });

        data.forEach((one) => {
            if (one.type == 'Group')
                listGroup.push(one);
            if (one.type == 'Contact')
                listContact.push(one);
            if (one.type == 'GroupWall')
                listWall.push(one);
        });

        return listGroup;
    }

    buildRowsFromResults(results) {
        return [...results];
    }

    componentWillMount() {
        setTimeout(() => this.focusInputSearch(), 300);
    }

    render() {
        let data = this.state.dataToRender;

        return (
            <View style={styles.container}>
                <OfflineBar />
                <View style={styles.pageHeader}>
                    <TouchableOpacity style={styles.backButton}
                        onPress={this._onBackPress.bind(this)}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                    </TouchableOpacity>
                    <View style={styles.pageHeaderWrapper}>
                        <SearchInput ref="searchInput"
                            placeholder="Tìm kiếm" textValue={this.state.text}
                            loadSearchFilter={(fields) => this._loadSearchFilter(fields)}
                            onSuggestPress={this._onSuggestPress.bind(this)}
                            onChangeText={this._onChangeText.bind(this)}
                            onFocus={this._onFocus.bind(this)}
                            showCloseButton={this.state.focused && this.state.text != ''}
                            searchContainer={{ marginRight: 16 }}
                            editable={true} />
                    </View>
                </View>
                {this.state.phanLoai == 'all' || this.state.phanLoai == 'wall' ? <FullLine style={{marginBottom: 8}} /> : null}
                {this.state.phanLoai == 'all' && data && Object.keys(data).length > 0 ? this._renderNewTabHeader() : null}
                
                {this.state.phanLoai == 'wall' ? this.renderTapFilterWall() : null}
                {this._renderMainContent()}
                {this.state.toggleKeyboard && data && Object.keys(data).length > 0 ?
                    <Button onPress={() => {
                        dismissKeyboard();
                        //write local storage
                        let lastMainSearch = this.props.groupSearch.lastMainSearch || [];
                        if (this.state.text.length > 0 && lastMainSearch.indexOf(this.state.text)==-1) {

                            if (lastMainSearch.length>=10)
                                lastMainSearch = lastMainSearch.slice(1, lastMainSearch.length)
                              
                            lastMainSearch.push(this.state.text);

                            this.props.actions.updateLastMainSearch(lastMainSearch);
                            this.setState({ 'lastMainSearch': lastMainSearch })
                        }
                    }
                    }
                        style={{
                            paddingRight: 17, fontFamily: gui.fontFamily, fontWeight: 'normal', textAlign: 'right',
                            color: gui.mainColor, backgroundColor: '#f0f1f3', height: 40, paddingTop: 8
                        }}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)} />

            </View>
        );
    }

    renderTapFilterWall() {
        let filterWall = [
            { code: 'post', text: 'Tất cả' },
            { code: 'ads', text: 'Tin BĐS' },
            { code: 'image', text: 'Ảnh' },
            // { code: 'file', text: 'File' },
        ].map((e) => {
            e.tabColor = this.state.phanLoaiWall == e.code ? styles.selectedButtonTab : {};
            e.textColor = this.state.phanLoaiWall == e.code ? styles.selectedButtonText : {};
            return e;
        });

        return (
            <View style={styles.tabHeaderWall}>
                <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    scrollEnabled={true}
                >
                    {
                        filterWall.map((e, index) => {
                            let marginLeft = index == 0 ? 0 : 8;
                            return (<TouchableOpacity style={[styles.viewEachButtonTab, e.tabColor, { marginLeft: marginLeft }]}
                                key={e.code}
                                onPress={this.onWallSubTabChange.bind(this, e.code)}
                                disabled={false}
                            >
                                <Text style={[styles.textButtonTab, e.textColor]}>{e.text}</Text>
                            </TouchableOpacity>)
                        })
                    }
                </ScrollView>
            </View>
        )
    }

    onWallSubTabChange(value) {
        this.setState({ phanLoaiWall: value });
        this.props.actions.onGroupFieldChange('selectedMainSearchWallTab', value);
        //search with current text
        let pre = this.state.text;

        this.props.actions.onMainSearchFieldChange('pageNo', 1)
        setTimeout(() => {
            this._request(pre, 1, this.props.group.mainSearchFields.limit, false);
        }, 100);
    }

    _renderNewTabHeader() {
        return (
            <View style={styles.tabHeader}>
                <View style={styles.viewTabSelect}>
                    {/* <TouchableOpacity style={styles.touchNewTab}
                        onPress={this.onNewTabMain.bind(this, "group")}
                    >
                        <Text style={styles.textButtonTab}>Sàn</Text>
                    </TouchableOpacity> */}
                    <TouchableOpacity style={styles.touchNewTab}
                        onPress={this.onNewTabMain.bind(this, "wall")}
                    >
                        <Text style={styles.textButtonTab}>Bài viết</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.touchNewTab}
                        onPress={this.onNewTabMain.bind(this, "contact")}
                    >
                        <Text style={styles.textButtonTab}>Liên hệ</Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _onTabChange(value) {
        this.setState({ phanLoai: value });
        this.props.actions.onGroupFieldChange('selectedMainSearchTab', value);
        //search with current text
        let pre = this.state.text;

        this.props.actions.onMainSearchFieldChange('pageNo', 1);
        setTimeout(() => {
            this._request(pre, 1, this.props.group.mainSearchFields.limit, false);
        }, 100);
    }

    onNewTabMain(value) {
        //console.log('==========. value', value);
        this.setState({ phanLoai: value });
        this.props.actions.onGroupFieldChange('selectedMainSearchTab', value);
        //search with current text
        let pre = this.state.text;

        this.props.actions.onMainSearchFieldChange('pageNo', 1);
        setTimeout(() => {
            this._request(pre, 1, this.props.group.mainSearchFields.limit, false);
        }, 100);
    }

    focusInputSearch() {
        this.refs.searchInput && this.refs.searchInput.focusInputSearch();
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    _request(text, pageNo, limit, isAppend) {
        if (text && text.trim().length >= 0) {
            this._requestAll(text, pageNo, limit, isAppend);
        } else {
            this.setState({
                dataToRender: {},
                endReached: true
            })
        }
    }

    _requestAll(text, pageNo, limit, isAppend) {
        let fields = utils.cloneRecord(this.props.group.mainSearchFields);
        // fields.name = text ? utils.locDauV2(utils.standardlizeName(text)) : undefined;
        fields.name = text || undefined;
        fields.userID = this.props.global.currentUser.userID;
        fields.dataType = this.state.phanLoai
        fields.subType = this.state.phanLoaiWall
        fields.pageNo = pageNo
        fields.limit = limit
        fields.groupIDs = [];

        let relatedGroup = this.props.group.searchResult.listRelatedGroup;
        relatedGroup.forEach((e) => {
            if (e.status == 1 || e.status == 2 && e.joinStatus == 2 && fields.groupIDs.length < 30)
                fields.groupIDs.push(e.groupID)
        });

        //ko search Wall neu chua join group nao.
        if (fields.dataType=='wall' && fields.groupIDs.length==0) {
            this.setState({
                dataToRender: {},
                endReached: true
            })
            return;
        }

        if (fields.name)
            GroupApi.searchFTSHome(fields).then((res) => {
                if (res.status == 0) {
                    let dataToRender = this._prepareDataToRender(res.data, pageNo, limit, isAppend)
                    this.setState({
                        dataToRender: dataToRender,
                        endReached: res.data.length == 0
                    })
                }
            });
    }

    _resetToFirstPage() {
        this.props.actions.onMainSearchFieldChange('pageNo', 1)
    }

    _onChangeText(text) {
        if (text == '')
            this._resetToFirstPage();
        this.currentText = text;

        let pre = text;
        this.props.actions.onMainSearchFieldChange('pageNo', 1)

        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre, 1, this.props.group.mainSearchFields.limit, false);
            }
        }, 100);

        this.setState({
            text: text
        });
    }

    _onFocus() {
        !this.state.focused && this.setState({ focused: true });
    }

    _renderMainContent() {
        let data = this.state.dataToRender;
        let lastMainSearch = this.props.groupSearch.lastMainSearch || [];

        let lastMainSearchFilter = lastMainSearch;
        log.info('==============> data', data);
        if (data && Object.keys(data).length > 0)
            return (
                <View style={styles.alphabetListView}>
                    <AlphabetListView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        data={data}
                        cell={Cell}
                        cellProps={{
                            phanLoai: this.state.phanLoai,
                            phanLoaiWall: this.state.phanLoaiWall,
                            endReached: this.state.endReached,
                            onContactPress: (data) => this._onContactPress(data),
                            onGroupDetailPress: (data) => this._onGroupDetailPress(data),
                            onWallCommentPress: (data) => this._onWallCommentPress(data),
                            onViewAllPress: (data) => this._onViewAllPress(data),
                            onLoadMorePress: (data) => this._onLoadMorePress(data)
                        }}
                        cellHeight={33}
                        sectionListItem={SectionItem}
                        sectionHeader={SectionHeader}
                        sectionHeaderHeight={33}
                        style={styles.listContent}
                        contentContainerStyle={{ paddingBottom: 15 }}
                    />
                </View>
            )
        
        else if (!this.state.text || this.state.text.length == 0) {
            return (
                <ScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="on-drag"
                    style={styles.viewLastSearch}
                >
                    {
                        lastMainSearchFilter && lastMainSearchFilter.length > 0 ?
                            (lastMainSearchFilter.map((e, index) => {
                                return (
                                    <TouchableOpacity
                                        onPress={this.onLastSearchPress.bind(this, e)}
                                        key={index}
                                    >
                                        <View style={styles.viewRowLastSearch}>
                                            <View style={styles.viewIconLast}>
                                                <Ionicons name="ios-search" size={20} color={gui.mainTextColor} />
                                            </View>
                                            <View style={styles.lastSearchContent}>
                                                <Text style={[styles.textViewAll, { fontWeight: '500' }]}>{e}</Text>
                                            </View>
                                        </View>
                                        <FullLine style={{ marginLeft: 16 }} />
                                    </TouchableOpacity>
                                )
                            })) : null
                    }
                </ScrollView>
            );
        } else
            return (
                <View style={styles.viewNoData}>
                    {this.state.phanLoai && this.state.phanLoai != 'all' ? this._renderDataTitle() : null}
                    <View style={{marginTop: 8}}>
                        <Text style={styles.textNoData}>Không tìm thấy kết quả nào!</Text>
                    </View>
                </View>
            );
    }

    _renderDataTitle() {
        let title = DanhMuc.mainTextSearchHeader[this.state.phanLoai]
        let name = DanhMuc.getTypeMainAvt(title);
        return (
            <View style={{ height: 38, width: width, backgroundColor: '#fff' }}>
                <View style={styles.viewLineHeader} />
                <View style={styles.viewStyle}>
                    <View style={styles.avtHeader}>
                        <FontAwesome size={11} color={"#fff"} name={name} />
                    </View>
                    <View style={styles.viewTitleChild}>
                        <Text style={styles.textStyle}>{title}</Text>
                    </View>
                </View>
                <FullLine />
            </View>
        );
    }

    onLastSearchPress(value) {
        this.setState( {text: value})
        this._request(value, 1, this.props.group.mainSearchFields.limit, false)
    }

    _onContactPress(data) {
        // log.info('_onContactPress *******', data);

        this.props.actions.onGroupContactFieldChange('selectedContact', data);
        // this.props.actions.onGroupFieldChange('contactHistoryList', [])
        this.props.actions.getContactHistory(
            {
                'userID': this.props.global.currentUser.userID,
                'contactID': data.contactID
            }
            , (res) => {

            }
            , (error) => {
                log.info('getContactHistory server respond error: =====>>>>>', error)
            });

        Actions.NewDetailContact();
    }

    _onViewAllPress(data) {

        this.setState({ phanLoai: DanhMuc.hashDataTypeToTabHeader[data.type] });
        this.props.actions.onGroupFieldChange('selectedMainSearchTab', DanhMuc.hashDataTypeToTabHeader[data.type]);
        //search with current text
        let pre = this.state.text;

        this.props.actions.onMainSearchFieldChange('pageNo', 1)
        setTimeout(() => {
            this._request(pre, 1, this.props.group.mainSearchFields.limit, false);
        }, 100);

    }

    _onLoadMorePress(data) {
        let nextPageNum = this.props.group.mainSearchFields.pageNo + 1;
        this.props.actions.onMainSearchFieldChange('pageNo', nextPageNum)
        let pre = this.state.text;

        setTimeout(() => {
            this._request(pre, nextPageNum, this.props.group.mainSearchFields.limit, true);
        }, 100);
    }

    _onGroupDetailPress(rowData, joinStatus) {

        this.props.actions.onSearchGroupFieldChange('name', rowData.name || undefined);
        let fields = utils.cloneRecord(this.props.group.searchFields);
        fields.name = rowData ? rowData.name : undefined;

        this.props.actions.searchGroup(false, fields, (res) => {
            if (res.status == 0) {
                Actions.GroupDetail({ groupData: res.data[0], groupID: res.data[0].groupID, owner: 'MainSearch', joinStatus: joinStatus });
            }
        });
    }

    _onWallCommentPress(data) {
        log.info('==========> data', data);
        if (data.ads && data.ads.indexOf('Ads')>-1) {
            this.props.actions.loadAdsByID(data.ads
                , (res) => {
                    log.info('_onWallCommentPress : server respond res: =====>>>>>', res)
                    data.adsList = []
                    if (res.data && res.data.length > 0)
                        data.adsList.push(res.data[0])
                    this.props.actions.onGroupFieldChange('watchingWallID', data.id)
                    Actions.GroupComment({ parentContent: data, groupID: data.groupID, groupWallID: data.id, owner: 'MainAutoComplete' });
                }
                , (error) => {
                    log.info('_onWallCommentPress : server respond error: =====>>>>>', error)                    
                });
        } else if (data.ads && data.ads.indexOf('WTo')>-1) {
            this.props.actions.loadWtoByID(data.ads
                , (res) => {
                    log.info('_onWallCommentPress : server respond res: =====>>>>>', res)
                    data.wtoList = []
                    if (res.data && res.data.length > 0)
                        data.wtoList.push(res.data[0])
                    this.props.actions.onGroupFieldChange('watchingWallID', data.id)
                    Actions.GroupComment({ parentContent: data, groupID: data.groupID, groupWallID: data.id, owner: 'MainAutoComplete' });
                }
                , (error) => {
                    log.info('_onWallCommentPress : server respond error: =====>>>>>', error)                    
                });
        } else {
            this.props.actions.onGroupFieldChange('watchingWallID', data.id)
            Actions.GroupComment({ parentContent: data, groupID: data.groupID, groupWallID: data.id, owner: 'MainAutoComplete' });
        }

    }

    _onBackPress() {
        let phanLoai = this.state.phanLoai;
        //console.log('=============> this.state.phanLoai',phanLoai );
        if (phanLoai == 'all') {
            Actions.pop();
        } else {
            this.props.actions.onGroupFieldChange('selectedMainSearchTab', 'all');
            let pre = this.state.text;

            this.props.actions.onMainSearchFieldChange('pageNo', 1);
            setTimeout(() => {
                this._request(pre, 1, this.props.group.mainSearchFields.limit, false);
            }, 100);
        }
    }

    _loadSearchFilter(fields) {

    }

    _onSuggestPress() {
    }
}

class SectionHeader extends React.Component {

    constructor(props) {
        super(props);
    }
    render() {
        let title = this.props.title;
        let name = DanhMuc.getTypeMainAvt(title);
        return (
            <View style={{ height: 38, width: width, backgroundColor: '#fff' }}>
                <View style={styles.viewLineHeader} />
                <View style={styles.viewStyle}>
                    <View style={styles.avtHeader}>
                        <FontAwesome size={11} color={"#fff"} name={name} />
                    </View>
                    <View style={styles.viewTitleChild}>
                        <Text style={styles.textStyle}>{this.props.title}</Text>
                    </View>
                </View>
                <FullLine />
            </View>
        );
    }
}

class SectionItem extends React.Component {

    render() {
        return null
    }
}

class Cell extends React.Component {
    render() {
        let data = this.props.item;

        let title = data.type == 'Group' ? data.name
            : (data.type == 'Contact' ? data.contactName
                : (data.type == 'GroupWall' ? data.highlight || data.content : ''));

        let nameKhongDau = data.type == 'Group' ? data.chiTiet : '';
        let contactPhone = data.type == 'Contact' ? data.contactPhone : '';
        let contactEmail = data.type == 'Contact' ? data.contactEmail : '';

        let userName = data.type == 'GroupWall' ? data.createdByName : '';
        let timePost = data.type == 'GroupWall' ? utils.getDiffTime(data.timeModified) : '';

        // style="color:#526173;"

        let htmlContent = title ? '<div>' + '<p>' + title.replaceAll('<mark>', '<span style="background-color: rgba(56,150,241,0.6);color:#526173">').replaceAll('</mark>', '</span>') + '</p>' + '</div>'
            : '<div></div>';

        // data for each cell
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let userAvatar = data.type == 'Group' && data.image ? { uri: data.image } : defaultAvatar;
        let contactAvt = data.type == 'Contact' && data.avatar ? { uri: data.avatar } : defaultAvatar;
        let userPostAvt = data.type == 'GroupWall' && data.createdByAvatar ? { uri: data.createdByAvatar } : defaultAvatar;
        
        let userPostImg = data.type == 'GroupWall' && data.image && data.image.cover 
        ? (typeof data.image.cover == 'string' ? { uri: data.image.cover } : { uri: data.image[0] }) 
        : defaultAvatar;

        console.log('***************bachtv userPostImg', userPostImg)

        let coverWidth = data.image && data.image.cover ? width - 92 : width - 16;
        if (data.footer == 'footer') {
            let footerText = this.props.phanLoai == 'all' ? 'Xem tất cả'
                : (this.props.endReached ? 'Đã hiển thị tất cả' : 'Xem thêm kết quả')

            return (
                <TouchableOpacity
                    onPress={() => {
                        this.props.phanLoai == 'all' ?
                            (this.props.onViewAllPress && this.props.onViewAllPress(data))
                            : (!this.props.endReached ? (this.props.onLoadMorePress && this.props.onLoadMorePress(data)) : () => { })
                    }}
                    style={styles.touchItemGroup2}>
                    {this.props.phanLoai != 'all' && this.props.endReached
                        ? (<View style={styles.viewViewAll}>
                            <View style={[styles.viewContentChild, { width: 'auto' }]}>
                                <Text numberOfLines={1} style={styles.textEndReached}>{footerText}</Text>
                            </View>
                        </View>)
                        : (<View style={styles.viewViewAll}>
                            <View style={[styles.viewContentChild, { width: 'auto' }]}>
                                <Text numberOfLines={1} style={styles.textViewAll}>{footerText}</Text>
                            </View>
                            <View style={[styles.viewIconLeft, { alignItems: 'flex-start', marginLeft: 8 }]}>
                                <FontAwesome size={20} color={gui.mainTextColor} name={"angle-right"} />
                            </View>
                        </View>)
                    }
                    {/*<FullLine style={{ marginLeft: 8 }} />*/}
                </TouchableOpacity>
            )
        }
        if (data.type == 'GroupWall')
            return (
                <TouchableOpacity style={{ height: 'auto', width: width }}
                    onPress={() => {
                        this.props.onWallCommentPress && this.props.onWallCommentPress(data)
                    }}
                >
                    <View style={styles.viewItemGroup}>
                        <Image style={styles.viewChildAvt}
                            resizeMode={"cover"}
                            source={userPostAvt}
                            defaultSource={defaultAvatar}
                        />
                        <View style={styles.viewContentChild}>
                            <Text numberOfLines={1} style={styles.textTopStyle}>{userName}</Text>
                            <Text numberOfLines={1} style={[styles.textStyle, { fontWeight: 'normal' }]}>{timePost}</Text>
                        </View>
                        <View style={styles.viewIconLeft}>
                            <FontAwesome size={20} color={gui.mainTextColor} name={"angle-right"} />
                        </View>
                    </View>
                    <View style={styles.viewHighlight}>
                        <View style={[styles.viewCoverHtml, { width: coverWidth }]}>
                            <HTML
                                html={htmlContent}
                            />
                        </View>

                        {data.image && data.image.cover ?
                            (
                                <View style={styles.viewImageComment}>
                                    <Image style={styles.viewChildPostImg}
                                        resizeMode={"cover"}
                                        source={userPostImg}
                                        defaultSource={defaultAvatar}
                                    />
                                </View>
                            ) : null}

                    </View>
                    <View style={styles.viewHighlight}>
                        {data.adsTitle ? (
                            <View style={styles.viewAdsTitle}>
                                <View style={styles.viewTextAdsTile}>
                                    <Text numberOfLines={2} style={[styles.textTopStyle, { fontWeight: '400', }]}>{data.adsTitle}</Text>
                                </View>
                                <View style={styles.viewIconAds}>
                                    <Ionicons size={28} color={'#fff'} name={"ios-paper-outline"} />
                                </View>

                            </View>
                        ) : null}
                    </View>
                    <FullLine style={{ marginLeft: 8 }} />
                </TouchableOpacity>);
        if (data.type == 'Contact')
            return (
                <TouchableOpacity
                    onPress={() => {
                        this.props.onContactPress && this.props.onContactPress(data)
                    }}
                    style={styles.touchItemGroup}>
                    <View style={styles.viewItemGroup}>
                        <Image style={styles.viewChildAvt}
                            resizeMode={"cover"}
                            source={contactAvt}
                            defaultSource={defaultAvatar}
                        />
                        <View style={styles.viewContentChild}>
                            <Text numberOfLines={1} style={styles.textTopStyle}>{title}</Text>
                            {this._renderPhoneEmail(contactPhone, contactEmail)}
                        </View>
                        <View style={styles.viewIconLeft}>
                            <FontAwesome size={20} color={gui.mainTextColor} name={"angle-right"} />
                        </View>
                    </View>
                    <FullLine style={{ marginLeft: 8 }} />
                </TouchableOpacity>
            );
        if (data.type == 'Group') {
            // log.info('render cell full text search ***', data)
            return (
                <TouchableOpacity
                    onPress={() => {
                        this.props.onGroupDetailPress && this.props.onGroupDetailPress(data)
                    }}
                    style={styles.touchItemGroup}>
                    <View style={styles.viewItemGroup}>
                        <Image style={styles.viewChildAvt}
                            resizeMode={"cover"}
                            source={userAvatar}
                            defaultSource={defaultAvatar}
                        />
                        <View style={styles.viewContentChild}>
                            <Text numberOfLines={1} style={styles.textTopStyle}>{title}</Text>
                            <Text numberOfLines={1} style={[styles.textStyle, { fontWeight: 'normal' }]}>{nameKhongDau}</Text>
                        </View>
                        <View style={styles.viewIconLeft}>
                            <FontAwesome size={20} color={gui.mainTextColor} name={"angle-right"} />
                        </View>
                    </View>
                    <FullLine style={{ marginLeft: 8 }} />
                </TouchableOpacity>
            );

        }
    }
    _renderPhoneEmail(phone, email) {
        if (phone && email)
            return (
                <View style={styles.viewNameTop}>
                    <View style={styles.viewTextPhone}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{phone}</Text>
                    </View>
                    {email ? <View style={styles.viewThinLine} /> : null}
                    <View style={[styles.viewTextPhone, { width: width - 181 }]}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{email}</Text>
                    </View>
                </View>
            )
        if (phone && !email)
            return (
                <View style={styles.viewNameTop}>
                    <View style={styles.viewTextPhone}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{phone}</Text>
                    </View>
                </View>
            )

        if (!phone && email)
            return (
                <View style={styles.viewNameTop}>
                    <View style={styles.viewTextPhone}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{email}</Text>
                    </View>
                </View>
            )
    }
}


const styles = StyleSheet.create({
    container: {
        paddingTop: 0,
        backgroundColor: "white",
        flex: 1
    },
    pageHeader: {
        backgroundColor: '#fff',
        width: width,
        height: 68,
        flexDirection: 'row'
    },
    pageHeaderWrapper: {
        height: 64,
        width: width - 50,
        
    },
    backButton: {
        height: 64,
        width: 50,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent + 3,
    },
    lineView: {
        borderTopWidth: 1,
        height: 1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    labelText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    adminAvatar: {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 8
    },
    alphabetListView: {
        flex: 1
    },
    listContent: {
        flex: 1
    },
    tabHeader: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 33,
        backgroundColor: '#fff'
    },
    tabHeaderWall: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 32,
        height: 30,
        // paddingTop: 9,
        marginBottom: 5,
        marginLeft: 16,
        marginRight: 16
    },
    selectedButtonTab: {
        backgroundColor: gui.mainColor,
        borderWidth: 0
    },
    selectedButtonText: {
        color: '#fff'
    },
    viewTabSelect: {
        height: 32,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row'
    },
    touchNewTab: {
        backgroundColor: '#fff',
        borderRadius: 4,
        marginTop: 0,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 11,
        width: 'auto',
        height: 28,
        borderColor: 'rgba(37,37,37,0.3)',
        borderWidth: 1,
        marginLeft: 8
    },
    viewLineHeader: {
        height: 6,
        width: width,
        backgroundColor: 'rgba(215,215,215,1)'
    },
    viewStyle: {
        backgroundColor: '#fff',
        height: 31,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 8
    },
    textStyle: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500',
        fontSize: 12
    },
    textTopStyle: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '600',
        fontSize: 15
    },
    textViewAll: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: 'normal',
        fontSize: 15
    },
    textEndReached: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: 'normal',
        fontSize: 12
    },
    avtHeader: {
        height: 22,
        width: 22,
        backgroundColor: gui.mainAgentColor,
        borderRadius: 11,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTitleChild: {
        width: width - 38,
        paddingLeft: 8,
        justifyContent: 'center'
    },
    touchItemGroup: {
        height: 51,
        width: width
    },
    touchItemGroup2: {
        height: 36,
        width: width
    },
    viewItemGroup: {
        height: 50,
        width: width - 16,
        alignItems: 'center',
        marginLeft: 8,
        marginRight: 8,
        flexDirection: 'row'
    },
    viewViewAll: {
        height: 35,
        width: width - 16,
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 8,
        marginRight: 8,
        flexDirection: 'row'
    },
    viewChildAvt: {
        height: 34,
        width: 34,
        borderRadius: 17
    },
    viewChildPostImg: {
        height: 66,
        width: 66
    },
    viewContentChild: {
        height: 50,
        width: width - 70,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewPhoneEmail: {
        height: 50,
        width: width - 70,
        flexDirection: 'row',
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewIconLeft: {
        height: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        width: 20
    },
    viewHighlight: {
        height: 'auto',
        width: width - 16,
        marginLeft: 8,
        marginRight: 8,
        paddingBottom: 8,
        flexDirection: 'row'
    },
    viewCoverHtml: {
        height: 'auto',
        width: width - 16
    },
    viewAdsTitle: {
        width: width - 16,
        height: 45,
        flexDirection: 'row',
        borderWidth: 1,
        borderColor: 'rgba(211,211,211,0.7)',
        backgroundColor: '#F6F6F6',
        alignItems: 'center'
    },
    viewTextAdsTile: {
        width: width - 16 - 45,
        height: 44,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewIconAds: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(37,37,37,0.3)'
    },
    viewImageComment: {
        height: 66,
        width: 76,
        justifyContent: 'center',
        alignItems: 'flex-end',        
    },
    viewThinLine: {
        height: 14,
        width: 1,
        backgroundColor: gui.mainTextColor,
        marginLeft: 5,
        marginRight: 5,
        // backgroundColor: '#fff'
    },
    viewNameTop: {
        height: 14,
        width: width - 91,
        flexDirection: 'row',
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewTextPhone: {
        height: 14,
        width: 79,
        backgroundColor: '#fff',
        justifyContent: 'center'
    },
    textPhoneTop: {
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    viewEachButtonTab: {
        // paddingHorizontal: 12,
        // paddingVertical: 9,
        backgroundColor: '#fff',
        borderRadius: 4,
        marginLeft: 8,
        marginTop: 0,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        width: (width - 48) / 3,
        height: 28,
        borderColor: 'rgba(37,37,37,0.3)',
        borderWidth: 1
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: 'rgba(37,37,37,0.8)',
        textAlign: 'center'
    },
    viewLastSearch: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewRowLastSearch: {
        height: 36,
        width: width,
        flexDirection: 'row'
    },
    viewIconLast: {
        width: 48,
        height: 36,
        paddingLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    lastSearchContent: {
        width: width - 48,
        height: 36,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewNoData: {
        // marginTop: 20,
        width: width,
        height: 'auto',
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textNoData: {
        fontSize: 17,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(MainAutoComplete);