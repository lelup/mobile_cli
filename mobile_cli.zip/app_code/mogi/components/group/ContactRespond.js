import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    FlatList,
    TouchableOpacity,
    ListView,
    ScrollView,
    Alert
} from 'react-native';

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import FullLine from '../line/FullLine';
import RelandIcon from '../RelandIcon';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import GiftedSpinner from "../GiftedSpinner";
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
let { width, height } = utils.getDimensions();
import { Actions } from 'react-native-router-flux';
import MLikeTapButton3 from '../MLikeTapButton3';
import TextInputAuto from '../postAds/TextInputAuto';

import KeyboardSpacer from 'react-native-keyboard-spacer';
import Button from 'react-native-button';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Toast, {DURATION} from '../toast/Toast';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import moment from 'moment'

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    adsMgmtActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var errorMessage = '';

class ContactRespond extends Component {
    constructor(props) {
        super(props);
        let data = []
        this.state = {
            data: data,
            likeStatus: props.groupContact.likeStatus,
            namePostLine: false,
            contactRespondAds: props.groupContact.contactRespondAds,
            toggleState: false,
        }
    }

    componentWillMount() {
        // setTimeout(() => this.fetchData(), 300);        
    }

    componentWillReceiveProps(nextProps) {

        if (nextProps.groupContact.contactRespondAds !== this.props.groupContact.contactRespondAds) {
            this.setState({
                contactRespondAds: nextProps.groupContact.contactRespondAds
            });
        }

        if (nextProps.groupContact.likeStatus !== this.props.groupContact.likeStatus) {
            this.setState({
                likeStatus: nextProps.groupContact.likeStatus,
            });
        }
    }

    fetchData(props) {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
    }

    refreshRowData(data) {
        this.setState({
            'matchingAdsList': data,
        });
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                <KeyboardAwareScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="none"
                    ref='scroll'
                    extraScrollHeight={30}
                >

                    {this._renderBody()}
                    {this._renderLoadingView()}
                    {this._renderRefreshingView()}
                </KeyboardAwareScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                    style={[styles.searchButtonText2, {
                        textAlign: 'right', color: gui.mainColor,
                        backgroundColor: gui.doneKeyButton
                    }]}>Xong</Button> : null}
                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />

                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
            </View>
        )
    }
    onKeyboardToggle(toggleState) {
        this.setState({ toggleState });
    }

    _renderRefreshingView() {
        if (this.props.group.loadingContactWto || this.props.group.loadingMatchingAds || this.props.group.loadingContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderBody() {
        return (
            <ScrollView
                automaticallyAdjustContentInsets={false}
                showsVerticalScrollIndicator={false}
                vertical={true}
                keyboardShouldPersistTaps="always"
                keyboardDismissMode="on-drag"
                ref={(scrollView) => { this._scrollView = scrollView; }}
                style={styles.viewBody}>

                {this._renderRelatedAdsPicker()}
                {this._renderRelatedAds()}
                {this._renderPersonConnect()}
                {this._renderLikeStatus()}
                {this._renderNameTodo()}
            </ScrollView>
        )
    }

    _renderLikeStatus() {
        return (

            <View style={styles.blockView}>

                <View style={[styles.viewTabInterest]}>
                    <MLikeTapButton3 name={'like'}
                        onPress={this._onLikeStatusClicked.bind(this)}
                        selected={this.state.likeStatus == 'like'}
                        mainProps={styles.tab1}
                        line1="Thích"></MLikeTapButton3>

                    <MLikeTapButton3 name={'normal'}
                        onPress={this._onLikeStatusClicked.bind(this)}
                        selected={this.state.likeStatus == 'normal'}
                        mainProps={styles.tab2}
                        line1="Bình thường"
                    ></MLikeTapButton3>

                    <MLikeTapButton3 name={'dislike'}
                        onPress={this._onLikeStatusClicked.bind(this)}
                        selected={this.state.likeStatus == 'dislike'}
                        mainProps={styles.tab3}
                        line1="Không thích"
                    ></MLikeTapButton3>
                </View>
            </View>
        )
    }

    _renderNameTodo() {
        let borderColor = this.state.namePostLine ? gui.mainTextColor : 'lightgray';
        let border = this.state.namePostLine ? 1 : 0.5;
        return (
            <View style={styles.viewNamePost}>
                {/* <Text style={styles.textBaiDang}>Tên công việc</Text> */}
                <View style={styles.viewInputPost}>
                    <TextInputAuto
                        onBlur={() => this.onBlurComment()}
                        onFocus={() => this.onFocusComment()}
                        placeholder="Viết bình luận"
                        // keyboardType="twitter"
                        placeholderTextColor={gui.colorMainBlur}
                        style={styles.viewTextInput}
                        autoFocus={false}
                        autoCorrect={false}
                        underlineColorAndroid='rgba(0,0,0,0)'
                        // onChangeText={(value) => this._onNamePostChange(value)}
                        // value={this.state.nameToto}
                        onChangeText={(text) => { this._onCommentChange(text) }}
                        value={this.props.groupContact.contactRespondComment}
                        maxLength={150}
                    />
                </View>
                <FullLine style={[styles.lineStyle, { marginTop: 11, borderColor: borderColor, borderTopWidth: border }]} />
            </View>
        );
    }

    _onCommentChange(value) {
        this.props.actions.onGroupContactFieldChange('contactRespondComment', value);
    }

    onFocusComment() {
        this.setState({
            namePostLine: true
        })
    }

    onBlurComment() {
        this.setState({
            namePostLine: false
        })
    }

    _onLikeStatusClicked(value) {
        this.setState({
            likeStatus: value
        });
        this.props.actions.onGroupContactFieldChange('likeStatus', value);
    }

    _renderRelatedAdsPicker() {
        let disableAdsPicker = this.props.disableAdsPicker;
        return (
            <View style={[styles.viewEachInfo, { height: 'auto' }]}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>BĐS của bạn</Text>
                    <TouchableOpacity onPress={this._onChooseAdsPost.bind(this)}
                                      style={styles.touchKieuNha}
                                      disabled={disableAdsPicker}
                    >
                        <Text numberOfLines={1} style={styles.dienTichInput}>Nhấn để chọn</Text>
                    </TouchableOpacity>
                    <View style={styles.dotStyle} />
                </View>
                <FullLine style={styles.lineStyle} />
            </View>

        );

    }

    _renderRelatedAds() {
        if (this.state.contactRespondAds) {
            let data = this.state.contactRespondAds;
            // console.log('_renderRelatedAdsList data to render', data)
            let image = data.image ? data.image.cover : '';
            let uriImage = { uri: image };
            let defaultSource = require('../../assets/image/no_cover.jpg');
            let giaFmt = utils.getPriceDisplay(data.gia, data.loaiTin);
            let textDienTich =  data.dienTich && data.dienTich > 0 ? data.dienTich + ' m2' : '';
            let textPhongNgu = data.soPhongNgu ? data.soPhongNgu + 'p.ngủ' : '';
            let content = data.title || data.diaChi;
            return (
                <TouchableOpacity style={[styles.viewRowDemand, { marginTop: 16, marginLeft: 16 }]}>
                    <Image style={styles.imageStyle}
                        source={uriImage}
                        defaultSource={defaultSource}
                        resizeMode={'cover'}
                    />
                    <Text style={styles.textGiaDemand}>{giaFmt}</Text>
                    <View style={[styles.viewContentChild, { height: 18 }]}>
                        {textDienTich ? <Text style={styles.textDienTich}>{textDienTich}</Text> : null}
                        <Text style={[styles.textDienTich, { marginLeft: textDienTich ? 18 : 0 }]}>{textPhongNgu}</Text>
                    </View>
                    <View style={styles.viewContent}>
                        <Text style={styles.textContent} numberOfLines={1}>{content}</Text>
                    </View>
                </TouchableOpacity>
            )
        }
        else return (<View></View>)
    }

    _onChooseAdsPost() {
        //console.log('========> _onChooseAdsPost');
        this.props.actions.onGroupContactFieldChange('loadingAdsForContactRespond', true);
        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        Actions.NewAgentPostViewOnly({ owner: 'ContactRespond' });
    }

    _renderPersonConnect() {
        let contactName = this.props.groupContact.contactOfRespond ? this.props.groupContact.contactOfRespond.contactName : '';
        return (
            <View style={[styles.viewEachInfo, { height: 'auto' }]}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>Người xem</Text>
                    <TouchableOpacity onPress={this._onPersonContactPress.bind(this)} style={styles.touchKieuNha}>

                        <Text numberOfLines={1} style={styles.dienTichInput}>{contactName}</Text>
                    </TouchableOpacity>
                    <View style={styles.dotStyle} />
                </View>
                <FullLine style={styles.lineStyle} />
            </View>

        );
    }

    _onPersonContactPress() {
        this.props.actions.getAllContact(
            { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.group.orderBy }
            , (res) => {
            }
            , (error) => {
                console.log('server respond error: =====>>>>>', error)
            });
        Actions.Contact({ owner: 'ContactRespond' });
    }

    _renderLoadingView() {
        if (this.props.groupContact.loadingMatchingAds || this.props.groupContact.savingContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }


    _renderLoadingAdsView() {
        if (this.props.groupContact.loadingAdsForContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _onBackPress() {
        Actions.pop();
    }

    _renderHeader() {
        let title = 'Thêm nhà đã xem';
        return (
            <View style={styles.viewHeader}>
                <TouchableOpacity style={styles.viewIconLeft}
                    onPress={this._onBackPress.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} style={{ marginLeft: 0 }} />
                </TouchableOpacity>
                <View style={styles.viewTextProfile}>
                    <Text style={styles.textProfile}>{title}</Text>
                </View>

                {this.props.groupContact.savingContactRespond ?
                    <View style={styles.viewTextLeft}>
                        <Text style={styles.textCommon}>Lưu</Text>
                    </View>
                    :
                    <TouchableOpacity onPress={this._onSaveButton.bind(this)} style={styles.viewTextLeft}>
                        <Text style={styles.textCommon}>Lưu</Text>
                    </TouchableOpacity>                    
                }

            </View>
        )
    }

    isValidInputData() {
        let errors = '';
        errorMessage = '';
        let { contactRespondAds, contactOfRespond, likeStatus, contactRespondComment } = this.props.groupContact;

        if (!contactRespondAds) {
            errors += ' (nhà)';
        }

        if (!contactOfRespond) {
            errors += ' (người xem)';
        }

        if (errors != '') {
            errorMessage = 'Bạn chưa chọn' + errors + '!';
            return false;
        }
        return true;
    }

    _onSaveButton() {
        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
            return;
        }

        let { contactRespondAds, contactOfRespond, likeStatus, contactRespondComment, contactRespondID, contactRespondEventID } = this.props.groupContact;

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let contactRespondDto = {
            "id": contactRespondID,
            "contactID": contactOfRespond.contactID,
            "adsID": contactRespondAds.adsID,
            "userID": this.props.global.currentUser.userID,
            "likeStatus": likeStatus,
            "comment": contactRespondComment.trim(),
            "eventID": contactRespondEventID
        }

        this.props.actions.saveContactRespond(contactRespondDto, token)
            .then(res => {

                let userID = this.props.global.currentUser.userID || undefined;
                let token = this.props.global.currentUser.token || undefined;

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {

                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);

                    //refresh danh sach nha da xem
                    setTimeout(() => {
                        if (this.props.owner == 'CalendarEvent') {
                            this.props.actions.onGroupContactFieldChange('contactRespondList', [])
                            this.props.actions.getContactRespondByEvent(
                                {
                                    'userID': this.props.global.currentUser.userID,
                                    'eventID': this.props.selectedEvent.id
                                }
                                , (res) => {
                                    console.log('getContactRespondByEvent : server respond res: =====>>>>>', res)
                                    Actions.ContactAdsViewed({ owner: 'CalendarEvent', selectedEvent: this.props.selectedEvent })
                                }
                                , (error) => {
                                    console.log('getContactRespondByEvent : server respond error: =====>>>>>', error)
                                    // Actions.ContactAdsViewed()
                                });
                        }
                        else {
                            let selectedContact = this.props.groupContact.selectedContact;
                            this.props.actions.onGroupContactFieldChange('contactRespondList', [])
                            this.props.actions.getContactRespond(
                                {
                                    'userID': this.props.global.currentUser.userID,
                                    'contactID': selectedContact.contactID
                                }
                                , (res) => {
                                    Actions.pop()
                                }
                                , (error) => {
                                    console.log('getContactRespond : server respond error: =====>>>>>', error)
                                    Actions.pop()
                                });
                        }
                    }, 1000);
                }
            });
    }

    _renderSquareIcon(value) {
        return (
            <View style={styles.viewSquare}>
                <RelandIcon name='acreage-b' color='rgba(169,183,200,1)' size={11}
                    mainProps={{ paddingLeft: 0, paddingRight: 0, marginTop: 14 }}
                    noAction={true}
                />
                <Text style={styles.textIcon}>{value}</Text>
            </View>
        )
    }

    _renderItemIcon = (name, value, size) => {
        return (
            <View style={[styles.viewItemIcon]}>
                <FontAwesome name={name} color='rgba(169,183,200,1)' size={size} />
                <Text style={styles.textIcon}>{value}</Text>
            </View>
        )
    }
    _renderRowMatchingAds(data) {

        let image = data.image ? data.image.cover : '';
        let uriImage = { uri: image };
        let defaultSource = require('../../assets/image/no_cover.jpg');
        let giaFmt = data.giaFmt;
        let textDienTich = data.dienTich ? data.dienTich + ' m2' : '';
        let textPhongNgu = data.soPhongNgu ? data.soPhongNgu + 'p.ngủ' : '';
        let content = data.title;
        return (
            <TouchableOpacity style={styles.viewRowDemand}>
                <Image style={styles.imageStyle}
                    source={uriImage}
                    defaultSource={defaultSource}
                    resizeMode={'cover'}
                />
                <Text style={styles.textGiaDemand}>{giaFmt}</Text>
                <View style={styles.viewContentChild}>
                    <Text style={styles.textDienTich}>{textDienTich}</Text>
                    <Text style={[styles.textDienTich, { marginLeft: 20 }]}>{textPhongNgu}</Text>
                </View>
                <View style={styles.viewContent}>
                    <Text style={styles.textContent} numberOfLines={1}>{content}</Text>
                </View>
            </TouchableOpacity>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewRowCover: {
        height: 'auto', //380
        width: width - 12,
        marginLeft: 6,
        marginRight: 6,
        paddingLeft: 10,
        marginTop: 6,
        backgroundColor: '#fff'
    },
    viewTitle: {
        width: width - 22,
        //paddingLeft: 16,
        height: 61,
        //paddingTop: 6,
        justifyContent: 'center'
    },
    textCommon: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor
    },
    viewDetailDemand: {
        height: 83,
        width: width - 22,
        //marginLeft: 16,
        justifyContent: 'center'
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        color: gui.mainAgentColor,
        fontWeight: 'bold'
    },
    viewIcons: {
        height: 14,
        width: width - 22,
        flexDirection: 'row',
        alignItems: 'flex-end',
        marginTop: 10
    },
    viewItemIcon: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 20,
        height: 14
    },
    textIcon: {
        color: 'rgba(82,97,115,1)',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewSquare: {
        flexDirection: 'row',
        height: 14,
        marginLeft: 0,
        alignItems: 'center'
    },
    textDemand: {
        color: gui.mainTextColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        marginTop: 12
    },
    title2: {
        color: gui.mainTextColor,
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        marginTop: 12,
        marginBottom: 12,
        alignSelf: 'center'
    },
    viewListContainer: {
        flex: 1
    },
    viewRowDemand: {
        width: (width - 55) / 2,
        height: 'auto',
        marginRight: 10
    },
    imageStyle: {
        width: (width - 55) / 2,
        height: 114,
    },
    textGiaDemand: {
        fontSize: 15,
        fontWeight: '500',
        color: gui.mainAgentColor,
        marginTop: 10,
        fontFamily: gui.fontFamily
    },
    viewContentChild: {
        width: (width - 55) / 2,
        height: 14,
        marginTop: 5,
        flexDirection: 'row'
    },
    textDienTich: {
        color: gui.mainTextColor,
        fontSize: 12,
        fontFamily: gui.fontFamily,
    },
    viewContent: {
        width: (width - 55) / 2,
        height: 12,
        marginTop: 7
    },
    textContent: {
        color: gui.mainTextColor,
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: '600'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewEachInfo: {
        height: 55,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    touchKieuNha: {
        position: 'absolute',
        right: 16,
        marginRight: 8
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    dotStyle: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: gui.dotColor,
        position: 'absolute',
        right: 8
    },
    viewKieuNha: {
        height: 41,
        width: width - 32,
        flexDirection: 'row',
        marginTop: 13,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textSavePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    touchKieuNha: {
        position: 'absolute',
        right: 16,
        marginRight: 8
    },
    dienTichInput: {
        marginTop: 8,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 30,
        borderColor: gui.mainTextColor,
        width: width / 2,
        textAlign: 'right',
        alignSelf: 'center',
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewHeader: {
        height: 46,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        marginTop: gui.marginTopAgent,
        flexDirection: 'row',
        alignItems: 'flex-end',
        paddingBottom: 15
    },
    viewIconLeft: {
        height: 26,
        width: 38,
        justifyContent: 'flex-end',
        paddingTop: 2
    },
    viewTextLeft: {
        height: 26,
        width: 38,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom: 2
    },
    viewTextProfile: {
        width: width - 108,
        height: 26,
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: 2
    },

    textProfile: {
        fontSize: 17,
        fontWeight: '500',
        color: gui.textAgentSolid
    },
    viewBody: {
        flex: 1,
        // width: width,
        // height: 'auto',
        backgroundColor: gui.groupBackground,
        //marginBottom: 72 // why me can't scroll to end
    },
    tab1: {
        height: 30,
        width: (width - 48) / 3,
        //borderColor: '#1A526173',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderRadius: 15
    },
    tab2: {
        height: 30,
        width: (width - 48) / 3,
        //borderColor: '#1A526173',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderRadius: 15,
        marginLeft: 8
    },
    tab3: {
        height: 30,
        width: (width - 48) / 3,
        //borderColor: '#1A526173',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderRadius: 15,
        marginLeft: 8
    },
    viewTabInterest: {
        flexGrow: 1,
        flexDirection: 'row',
        width: width - 32,
        height: 30,
        marginTop: 23.6,
        marginLeft: 16,
    },
    viewNamePost: {
        marginTop: 31,
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginRight: 16
    },
    textBaiDang: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewInputPost: {
        width: width - 32,
        height: 'auto',
        marginTop: 18,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        backgroundColor: gui.groupBackground,
        width: width - 70,
        color: gui.mainTextColor,
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
})
export default connect(mapStateToProps, mapDispatchToProps)(ContactRespond);