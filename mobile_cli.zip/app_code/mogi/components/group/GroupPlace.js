'use strict';

import React, { Component } from 'react';

import {
    Text, View, ListView
    , TextInput, StyleSheet, RecyclerViewBackedScrollView
    , TouchableHighlight, TouchableOpacity, ScrollView
} from 'react-native'

import gui from "../../lib/gui";
import log from "../../lib/logUtil";
import cfg from '../../cfg';
import OfflineBar from '../line/OfflineBar';
import RelandIcon from '../RelandIcon';

import SearchInput from './SearchInputAgent';

import { Actions } from 'react-native-router-flux';

import utils from '../../lib/utils';

import dismissKeyboard from 'react-native-dismiss-keyboard';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Button from 'react-native-button';
var { width, height } = utils.getDimensions();

class GroupPlace extends React.Component {
    _results = [];
    _requests = [];

    constructor(props) {
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: function rowHasChanged(r1, r2) {
                if (typeof r1.isLoading !== 'undefined') {
                    return true;
                }
                return r1 !== r2;
            }
        });
        let selectedDiaChinh = this.getDiaChinhList(props.selectedDiaChinh);
        this.state = {
            focused: false,
            loading: false,
            mounted: false,
            dataSource: ds.cloneWithRows(this.buildRowsFromResults(props.allTinh || [])),
            diaChinh: props.allTinh || [],
            selectedDiaChinh: selectedDiaChinh || [],
            text: '',
            toggleKeyboard: false,
            listViewDisplayed: false
        }
    }

    getDiaChinhList(selectedDiaChinh) {
        let diaChinhList = [];
        if (selectedDiaChinh) {
            selectedDiaChinh.forEach((one) => {
                let placeType = 'T';
                if (one.codeHuyen)
                    placeType = 'H';
                if (one.codeXa)
                    placeType = 'X';

                diaChinhList.push({
                    placeType: placeType,
                    name: one.name || one.placeName,
                    tinhName: one.tinh,
                    tinh: one.codeTinh,
                    huyenName: one.huyen,
                    huyen: one.codeHuyen,
                    xaName: one.xa,
                    xa: one.codeXa
                });
            });
        }
        return diaChinhList;
    }

    buildRowsFromResults(results) {
        let data = [];
        let uuid = new Date().getTime();
        results.forEach((one) => {
            let row = { ...one };
            row.key = row.id + '_' + uuid;
            data.push(row);
        });
        return data;
    }

    componentWillMount() {
        setTimeout(() => this.focusInputSearch(), 300);
    }

    componentDidMount() {
        this.setState({ mounted: true });
    }

    componentWillUnmount() {
        this._abortRequests();
        this.setState({ mounted: false });
    }

    _abortRequests() {
        for (let i = 0; i < this._requests.length; i++) {
            this._requests[i].abort();
        }
        this._requests = [];
    }

    render() {
        let { onChangeText, onFocus } = this.props.textInputProps || {};
        let searchInputWidth = width - 32;
        let headerText = 'Khu vực'
        let placeHolderText = 'Tìm kiếm khu vực'

        return (

            <View style={{ flex: 1 }}>
                <OfflineBar />
                <View style={styles.headerView}>

                    <View style={styles.subHeader2}>

                        <TouchableOpacity onPress={this._onBackPress.bind(this)}
                            style={[styles.viewSortAlphabet, { marginLeft: 8 }]}
                        >
                            <Text style={styles.headerFunctionText}>Hủy</Text>
                        </TouchableOpacity>

                        <View style={[styles.viewSortAlphabet, { width: width / 2 }]}>
                            <Text style={styles.headerText}>{headerText}</Text>
                        </View>

                        <TouchableOpacity onPress={this._onApplyPress.bind(this)}
                            style={[styles.viewSortAlphabet, { marginRight: 8 }]}
                        >
                            <Text style={styles.headerFunctionText}>Chọn</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={[styles.viewTextInput, { marginTop: 4, marginLeft: 16, width: searchInputWidth, height: 36 }]}>

                        <SearchInput ref="searchInput"
                            placeholder={placeHolderText} textValue={this.state.text}
                            loadSearchFilter={(fields) => this._loadSearchFilter(fields)}
                            onSuggestPress={this._onSuggestPress.bind(this)}
                            onChangeText={onChangeText ? text => { this._onChangeText(text); onChangeText(text) } : this._onChangeText.bind(this)}
                            onFocus={onFocus ? () => { this._onFocus(); onFocus() } : this._onFocus.bind(this)}
                            showCloseButton={this.state.focused && this.state.text != ''}
                            editable={true}
                            searchContainer={styles.searchContainer}
                        />

                    </View>
                </View>
                {this._renderContent()}
            </View>
        );
    }

    focusInputSearch() {
        this.refs.searchInput && this.refs.searchInput.focusInputSearch();
    }

    _request(text) {
        this._abortRequests();
        if (text && text.trim().length >= this.props.minLength) {
            if (this.props.clientSearch) {
                this._onClientSearch(text.trim());
            } else {
                this._requestDiaChinh(text.trim());
            }
        } else {
            this._results = [];
            this.setState({
                dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(this.props.allTinh || [])),
                diaChinh: this.props.allTinh || []
            });
        }
    }

    _onClientSearch(text) {
        this.setState({ loading: false });
        let textKhongDau = utils.locDauV2(text);
        let allToken = textKhongDau.split(' ');
        let diaChinh = [];
        let allTinh = this.props.allTinh;
        allTinh.forEach((tinh) => {
            let tinhTokens = tinh.tinhKhongDau.split('-');
            let matched = undefined;
            let matchedHash = {};
            allToken.forEach((token) => {
                let found = tinhTokens.find((tinhToken) => {
                    return tinhToken == token;
                });
                if (found) {
                    matchedHash[token] = true;
                    if (matched === undefined) {
                        matched = true;
                    }
                }
                else {
                    matched = false;
                }
            });
            if (matched) {
                diaChinh.push(tinh);
            } else if (Object.keys(matchedHash).length == (allToken.length - 1) && !matchedHash[allToken[allToken.length - 1]]) {
                let item = allToken[allToken.length - 1];
                let found = tinhTokens.length >= allToken.length && tinhTokens[allToken.length - 1].indexOf(item) == 0;
                if (found) {
                    diaChinh.push(tinh);
                }
            }
        });
        this.setState({
            dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(diaChinh)),
            diaChinh: diaChinh
        });
    }

    _requestDiaChinh(text) {
        const request = new XMLHttpRequest();
        this._requests.push(request);
        request.timeout = this.props.timeout || 20000;
        request.ontimeout = () => log.warn('Places autocomplete: request timeout');
        request.onreadystatechange = () => {
            if (request.readyState !== 4) {
                return;
            }
            if (request.status === 200) {
                this.setState({ loading: false, dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([])) });
                const responseJSON = JSON.parse(request.responseText);
                if (typeof responseJSON.predictions !== 'undefined') {
                    if (this.state.mounted) {
                        this._results = responseJSON.predictions;
                        let predictions = responseJSON.predictions;

                        let diaChinh = predictions && predictions.filter((e) => {
                            return e.placeType == 'T' || e.placeType == 'H';
                        });

                        let data = [];
                        if (diaChinh && diaChinh.length > 0) {
                            data = [...data, {
                                title: "ĐỊA CHÍNH",
                                desc: "Thành phố, quận tìm thấy"
                            }, ...diaChinh]
                        }

                        this.setState({
                            dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([...data])),
                            diaChinh: data
                        });
                    }
                }
                if (typeof responseJSON.error_message !== 'undefined') {
                    log.warn('GooglePlacesAutocomplete._requestDiaChinh: ' + responseJSON.error_message);
                }
            } else {
                // console.warn("google places autocomplete: request could not be completed or has been aborted");
            }
        };
        this.setState({ loading: true });
        request.open('GET', cfg.rootUrl + "/place/autocomplete?input=" + encodeURI(text));
        request.send();
    }

    _enableRowLoader(rowData) {

        let rows = this.buildRowsFromResults(this._results);
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].place_id === rowData.place_id) {
                rows[i].isLoading = true;
                this.setState({
                    dataSource: this.state.dataSource.cloneWithRows(rows),
                });
                break;
            }
        }
    }

    _disableRowLoaders() {
        if (this.state.mounted) {
            for (let i = 0; i < this._results.length; i++) {
                if (this._results[i].isLoading === true) {
                    this._results[i].isLoading = false;
                }
            }
            this.setState({
                dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(this._results)),
            });
        }
    }

    _onChangeText(text) {
        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            text: text,
            listViewDisplayed: true,
        });
    }

    _onBlur() {
        this.setState({ listViewDisplayed: false });
    }

    _onFocus() {
        this.setState({ listViewDisplayed: true, focused: true });
    }

    _renderContent() {
        return (
            <View style={styles.mainView}>
                {this._renderMainView()}
                {this.state.toggleKeyboard ? <Button onPress={() => dismissKeyboard()}
                    style={{
                        paddingRight: 17, fontFamily: gui.fontFamily, fontWeight: 'normal', textAlign: 'right',
                        color: gui.mainColor, backgroundColor: '#f0f1f3', height: 40, paddingTop: 8
                    }}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)} />

            </View>
        )
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    _renderListResult() {
        // if (this.state.text !== '' && this.state.listViewDisplayed === true) {
        return (
            <View style={styles.listResultView}>
                <ListView style={styles.placeListView}
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="on-drag"
                    ref={(listView) => { this._listView = listView; }}
                    dataSource={this.state.dataSource}
                    renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0))}
                    stickyHeaderIndices={[]}
                    enableEmptySections={true} />
            </View>
        );
        // }
    }

    _isSelectedDiaChinh(rowData) {
        return this.state.selectedDiaChinh.find((one) => {
            let name = rowData.name || rowData.shortName;
            return one.name == name;
        });
    }

    _renderRow(rowData = {}, sectionID, rowID, isFirstRow) {
        let isSelectedDiaChinh = this._isSelectedDiaChinh(rowData);
        if (rowData.isRecent) {
            return (
                <TouchableOpacity onPress={this._onSelectedPlacePress.bind(this, rowData)}>
                    <View style={styles.placeResultView}>
                        <View style={styles.placeSubView}>
                            <Text style={styles.placeNameText} numberOfLines={1}>{rowData.name}</Text>
                            <Text style={styles.diaChiText} numberOfLines={1}>{rowData.desc}</Text>
                        </View>
                        {isSelectedDiaChinh ?
                            <RelandIcon noAction={true}
                                name="check-icon" color={'#64B35B'}
                                size={20}
                                mainProps={{ paddingTop: 14, paddingRight: 15 }}
                            /> :
                            <RelandIcon noAction={true}
                                name="plus" color={'#526173'}
                                size={22}
                                mainProps={{ paddingTop: 14, paddingRight: 21 }}
                            />
                        }
                    </View>
                </TouchableOpacity>
            )
        }

        if (rowData.title && rowData.title.length > 0) {
            return (
                <View style={styles.placeResultView}>
                    <View style={styles.placeSubView}>
                        <Text style={styles.placeNameText} numberOfLines={1}>{rowData.title}</Text>
                        <Text style={styles.diaChiText} numberOfLines={1}>{rowData.desc}</Text>
                    </View>
                </View>
            )
        }

        return (
            <TouchableOpacity onPress={this._onSelectedPlacePress.bind(this, rowData)}>
                <View style={styles.placeResultView}>
                    <View style={styles.placeSubView}>
                        <Text style={styles.placeNameText} numberOfLines={1}>{rowData.shortName}</Text>
                    </View>
                    {isSelectedDiaChinh ?
                        <RelandIcon noAction={true}
                            name="check-icon" color={'#64B35B'}
                            size={20}
                            mainProps={{ paddingTop: 14, paddingRight: 15 }}
                        /> :
                        <RelandIcon noAction={true}
                            name="plus" color={'#526173'}
                            size={22}
                            mainProps={{ paddingTop: 14, paddingRight: 21 }}
                        />
                    }
                </View>
            </TouchableOpacity>
        )
    }

    _onSelectedPlacePress(rowData) {
        let name = rowData.name || rowData.shortName;
        let selectedDiaChinh = [...this.state.selectedDiaChinh];
        let found = selectedDiaChinh.filter((one) => {
            return one.name == name;
        });
        if (!found || found.length == 0) {
            selectedDiaChinh.push({ ...rowData, name: name });
        } else {
            selectedDiaChinh = selectedDiaChinh.filter((one) => {
                return one.name != name;
            });
        }
        this.setState({
            selectedDiaChinh: selectedDiaChinh,
            dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(this.state.diaChinh))
        });
        // this.props.onApply(selectedDiaChinh);
    }

    _renderMainView() {
        let daChonItems = [];
        let index = 0;

        this.state.selectedDiaChinh.forEach((one) => {
            // let extStyle = index > 0 ? {marginLeft: 16} : {marginLeft: 0};
            let extStyle = { marginLeft: 16 };
            daChonItems.push(<View key={index} style={[styles.khuVucSubView, extStyle]}>
                <Text style={styles.khuVucText}>{one.name}</Text>
                <RelandIcon onPress={this._onBoChonKhuVucPress.bind(this, index)}
                    name="close" color="#526173"
                    size={10}
                    iconProps={{ style: { marginRight: 3 } }}
                    textProps={{ paddingLeft: 0 }}
                    mainProps={{ flexDirection: 'row', paddingLeft: 7, paddingTop: 4 }}>
                </RelandIcon>
            </View>);
            index++;
        });

        return (
            <ScrollView
                keyboardShouldPersistTaps="always"
                keyboardDismissMode="none"
                style={{ flex: 1 }}>
                <View style={styles.daChonView}>
                    <Text style={styles.daChonText}>Đã chọn</Text>
                </View>
                <View style={styles.daChonSubView}>
                    {/*<ScrollView horizontal={true} contentContainerStyle={styles.daChonScrollView}>*/}
                    {daChonItems}
                    {/*</ScrollView>*/}
                </View>
                <View style={[styles.lineView, { margin: 16, marginBottom: 8 }]} />
                {this._renderListResult()}
            </ScrollView>
        )
    }

    _onBoChonKhuVucPress(index) {
        let selectedDiaChinh = this.state.selectedDiaChinh;
        selectedDiaChinh = [...selectedDiaChinh.slice(0, index), ...selectedDiaChinh.slice(index + 1)];
        this.setState({
            selectedDiaChinh: selectedDiaChinh,
            dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(this.state.diaChinh))
        });
        // this.props.onApply(selectedDiaChinh);
    }


    _onApplyPress() {
        this.props.onApply(this.state.selectedDiaChinh);
        Actions.pop();
    }

    _onBackPress() {
        //clear result

        Actions.pop();
    }

    _loadSearchFilter(fields) {

    }

    _onSuggestPress() {

    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white"
    },
    pageHeader: {
        flexDirection: 'row',
        top: 0,
        position: 'absolute',
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width,
        height: 64
    },
    pageHeaderWrapper: {
        position: 'absolute',
        left: 50,
        right: 6,
        top: 0,
        height: 64
    },
    backButton: {
        height: 64,
        width: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: gui.marginTopAgent
    },
    titleView: {
        width: width - 100,
        height: 64
    },
    titleText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#526173',
        textAlign: 'left'
    },
    mainView: {
        position: 'absolute',
        top: 108,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: '#F2F2F2',
        borderTopWidth: 1,
        borderTopColor: 'rgba(82,97,115,0.1)'
    },
    daChonView: {
        marginTop: 16,
        marginLeft: 15
    },
    daChonText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    daChonSubView: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginLeft: 16,
        marginRight: 16,
        flexWrap: 'wrap',
        flex: 1
    },
    daChonScrollView: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start'
    },
    khuVucSubView: {
        flexDirection: 'row',
        padding: 7,
        marginTop: 9,
        justifyContent: 'center',
        backgroundColor: '#fff'
    },
    khuVucText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    listResultView: {
        flex: 1,
        marginLeft: 16,
        marginRight: 16,
        marginBottom: 10
    },
    lineView: {
        borderTopWidth: 1,
        height: 1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    placeListView: {
        flex: 1
    },
    placeResultView: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(82,97,115,0.1)',
        marginTop: 8
    },
    placeSubView: {
        flex: 1,
        marginLeft: 12,
        marginTop: 8
    },
    placeNameText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#526173',
        textAlign: 'left'
    },
    diaChiText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left',
        opacity: 0.5
    },
    buttonView: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        height: 80,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonSubView: {
        margin: 16,
        borderRadius: 24,
        backgroundColor: gui.mainColor,
        width: width - 32,
        height: 48,
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#fff',
        textAlign: 'left'
    },
    headerView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: width,
        //borderBottomWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)'
    },
    subHeader: {
        backgroundColor: 'transparent',
        marginTop: 40,
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 24,
        flexDirection: 'row'
    },
    subHeader2: {
        backgroundColor: 'transparent',
        width: width,
        height: 64,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    viewSortAlphabet: {
        height: 64,
        width: 50,
        paddingTop: gui.marginTopAgent + 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: 'rgba(35,35,35,1)',
        // marginLeft: 8
    },
    viewTextInput: {
        width: width - 70,
        height: 64
    },
    headerFunctionText: {
        fontSize: 18,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: 'rgba(56,151,241,1)',
    },
    searchContainer: {
        marginTop: 0,
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0
    },
});

export default GroupPlace;