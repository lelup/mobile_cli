'use strict';
import React, { Component } from 'react';
import {
    View, Text, StyleSheet, Image, TouchableOpacity, TouchableHighlight,
    ScrollView, TextInput, Alert, Keyboard, FlatList, TouchableWithoutFeedback
} from 'react-native';

import FullLine from '../line/FullLine';
import gui from "../../lib/gui";
import log from '../../lib/logUtil';
import utils from "../../lib/utils";
import Toast, { DURATION } from '../toast/Toast';
import cfg from '../../cfg';

import { Actions } from 'react-native-router-flux';
const { width, height } = utils.getDimensions();
import OfflineBar from '../line/OfflineBar';
import CheckDot from '../detail/CheckDot';
import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
const actions = [
    globalActions,
    registerActions,
    searchActions,
    adsMgmtActions,
    postAdsActions,
    needToBuyActions,
    adsMgmtActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}


class ShareAdsOnWall2 extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            title: '',
            checkShared : this.props.checkShared,
            dataTypeSelected: this.props.dataTypeSelected,
            selectedAds: this.props.selectedAds,
            selectedWto: this.props.selectedWto
        }
    }

    _renderHeader() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <Text style={[styles.textTypePost, { color: gui.mainColor }]}>Hủy</Text>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={styles.textEdit}>Chia sẻ với cộng đồng</Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }
    render() {
        return (
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                      style={{flex: 1}}
            >
            <View style={{ flex: 1 }}>
                <OfflineBar />
                {this._renderHeader()}
                <FullLine />
                {this.renderShareAds()}
                <FullLine />
                {this.renderSharedContent()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={45}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
            </TouchableWithoutFeedback>
        );
    }

    renderSharedContent() {
        if(this.state.checkShared === 'shared') {
            return(
                <View style={{flex: 1}}>
                    {this.renderInputTitle()}
                    <FullLine />
                    {this.renderButtonShare()}
                </View>
            )
        } else if (this.state.checkShared === 'unshared'){
            return(
                <View style={{flex: 1}}>
                    {this.renderButtonXacNhan()}
                </View>
            )
        }
    }

    renderInputTitle() {
        let titleLength = this.state.title && this.state.title.length || 0;
        let textLength = `${titleLength}/99`;
        return(
            <View style={styles.viewInputTitle}>
                <TextInput
                    placeholder={"Nhập tiêu đề chia sẻ"}
                    autoCorrect={false}
                    style={styles.viewTextInput}
                    onChangeText={(value) => this.onTitleChange(value)}
                    // onBlur={() => Keyboard.dismiss()}
                    value={this.state.title}
                    secureTextEntry={false}
                    autoCapitalize='none'
                    returnKeyType='done'
                    maxLength={99}
                    multiline={true}
                />
                <View  style={{  position: 'absolute', right: 16, width: 32, height: 12, alignItems: 'flex-end'}}>
                    <Text style={[styles.tieuDeLength, {textAlign: 'right'}]}>{textLength}</Text>
                </View>
            </View>
        )
    }

    onTitleChange(value) {
        this.setState({
            title: value
        })
    }

    renderButtonShare() {
        return(
            <View style={[styles.viewBottomUnshared]}>
                <TouchableOpacity
                    onPress={this._onShare.bind(this)}
                    style={styles.viewTouchSharePost}>
                    <Text style={[styles.textNormal, { color: '#fff' }]}>Chia sẻ</Text>
                </TouchableOpacity>
            </View>
        )
    }

    renderButtonXacNhan() {
        return(
            <View style={[styles.viewBottomUnshared]}>
                <TouchableOpacity
                    onPress={this._onUnShareConfirm.bind(this)}
                    style={styles.viewTouchSharePost}>
                    <Text style={[styles.textNormal, { color: '#fff' }]}>Xác nhận</Text>
                </TouchableOpacity>
            </View>
        )
    }

    _onUnShareConfirm() {

        if (this.state.dataTypeSelected == 'ads') {
            if (this.state.selectedAds) {
                let token = this.props.global.currentUser.token;
                let dto = {
                    adsID: this.state.selectedAds.adsID,
                    groupID: [],
                    userID: this.props.global.currentUser.userID
                }
                this.props.actions.shareAds(dto, token)
                    .then(res => {
                        //log.info('shareAds ****', res)
                        if (res.status != 0) {
                            this.refs.toastTop && this.refs.toastTop.show(res.msg, DURATION.LENGTH_LONG);
                        } else {
                            this.refs.toastTop && this.refs.toastTop.show("Cập nhật thành công!", DURATION.LENGTH_LONG);
                            this._onBackPress();
                        }
                    });
            }
        }
        else if (this.state.dataTypeSelected == 'wto') {
            if (this.state.selectedWto) {

                let token = this.props.global.currentUser.token;
                let dto = {
                    wtoID: this.state.selectedWto.wtoID,
                    groupID: [],
                    userID: this.props.global.currentUser.userID
                }
                this.props.actions.shareWto(dto, token)
                    .then(res => {
                        // log.info('shareWto ****', res)
                        if (res.status != 0) {
                            this.refs.toastTop && this.refs.toastTop.show(res.msg, DURATION.LENGTH_LONG);
                        } else {
                            this.refs.toastTop && this.refs.toastTop.show("Cập nhật thành công!", DURATION.LENGTH_LONG);
                            this._onBackPress();
                        }
                    });
            }
        }

        this._onBackPress();
    }

    renderShareAds() {
        return (
            <View style={styles.viewShareAds}>
                <View style={styles.viewShareContent}
                >
                    <View style={styles.checkAds}>
                        <CheckDot name={'unshared'}
                                  onPress={this.checkShareValue.bind(this)}
                                  selected={this.state.checkShared === 'unshared'}
                                  mainProps={styles.viewSaleState}></CheckDot>
                    </View>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15, marginLeft: 8 }]}>Không chia sẻ</Text>
                </View>
                <FullLine />
                <View style={styles.viewShareContent}>
                    <View style={styles.checkAds}>
                        <CheckDot name={'shared'}
                                  onPress={this.checkShareValue.bind(this)}
                                  selected={this.state.checkShared === 'shared'}
                                  mainProps={styles.viewSaleState}></CheckDot>
                    </View>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15, marginLeft: 8 }]}>Chia sẻ với cộng đồng</Text>
                </View>
            </View>
        )
    }

    checkShareValue(value) {
         this.setState({
             checkShared: value
         })
    }

    _onShare() {
        let groupID = [cfg.groupLandberID];

        let token = this.props.global.currentUser.token;
        let title = this.state.title ? this.state.title.trim() : '';
        if (this.props.dataTypeSelected == 'ads') {
            let dto = {
                adsID: this.props.selectedAds.adsID,
                groupID: groupID,
                userID: this.props.global.currentUser.userID,
                fullName: this.props.global.currentUser.fullName,
                avatar: this.props.global.currentUser.avatar,
                username: this.props.global.currentUser.username,
                title: title
            }
            this.props.actions.shareAds(dto, token)
                .then(res => {

                    if (res.status != 0) {
                        log.info('=============> res.status != 0');
                        this.refs.toastTop && this.refs.toastTop.show(res.msg, DURATION.LENGTH_LONG);
                    } else {
                        this.refs.toastTop && this.refs.toastTop.show("Cập nhật thành công!", DURATION.LENGTH_LONG);
                        this._onBackPress();
                    }
                });
        } else if (this.props.dataTypeSelected == 'wto') {
            let dto = {
                wtoID: this.props.selectedWto.wtoID,
                groupID: groupID,
                userID: this.props.global.currentUser.userID,
                fullName: this.props.global.currentUser.fullName,
                avatar: this.props.global.currentUser.avatar,
                username: this.props.global.currentUser.username,
                title: title
            }
            this.props.actions.shareWto(dto, token)
                .then(res => {
                    if (res.status != 0) {
                        this.refs.toastTop && this.refs.toastTop.show(res.msg, DURATION.LENGTH_LONG);
                    } else {
                        this.refs.toastTop && this.refs.toastTop.show("Cập nhật thành công!", DURATION.LENGTH_LONG);
                        this._onBackPress();
                    }
                });
        }

    }

    _onBackPress= async() => {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        // await this.props.actions.loadMySellRentList(userID);
        // await this.props.actions.loadMyWto(userID, token)
        this.props.request && this.props.request(this.props.textSearch);
        Actions.pop()
    }
}

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: 'white'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        marginLeft: 16,
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64,
        marginRight: 16,
    },
    viewEditHome: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
    },
    textCommon: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        color: "rgba(112,112,112,1)",
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewButtons: {
        height: 49,
        width: width,
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    viewCheckAll: {
        paddingLeft: 16,
        width: width / 2,
        height: 49,
        alignItems: 'center',
        flexDirection: 'row'
    },
    textNormal: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: "rgba(112,112,112,1)",
        fontWeight: 'normal'
    },
    viewTouchSharePost: {
        width: width / 2 - 32,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: gui.mainColor
    },
    viewBottomContent: {
        position: 'absolute',
        bottom: 0,
        width: width,
        height: 50
    },
    viewBottomUnshared: {
        position: 'absolute',
        bottom: 0,
        width: width,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center'
    },
    rowShareAds: {
        width: width,
        height: 54
    },
    viewChildGroup: {
        width: width,
        height: 53,
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewCheckBox: {
        height: 53,
        width: 50,
        paddingLeft: 14,
        justifyContent: 'center'
    },
    viewDetailShare: {
        height: 53,
        width: width - 50,
        //paddingLeft: 16,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewAvatar: {
        height: 36,
        width: 36,
        borderRadius: 18
    },
    viewContentRow: {
        height: 53,
        width: width - 50 - 36,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewInputTitle: {
        height: 55,
        width: width,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        backgroundColor: '#fff',
        width: width - 60,
        height: 40,
        color: gui.textPostAds,
        paddingLeft: 16,
        paddingTop: 5,
        textAlign: 'left'
    },
    viewShareAds: {
        width: width,
        height: 88,
        backgroundColor: '#fff',
    },
    viewShareTitle: {
        height: 31,
        width: width - 16,
        paddingLeft: 12,
        justifyContent: 'center'
    },
    viewShareContent: {
        width: width,
        height: 44,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 12,
    },
    checkAds: {
        height: 44,
        width: 32,
        justifyContent: 'center'
    },
    viewIcon: {
        height: 44,
        width: 22,
        justifyContent: 'center',
        position: 'absolute',
        right: 15
    },
    viewSaleState: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        paddingTop: 12,
        margin: 0
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    tieuDeLength: {
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        fontSize: 11,
        color: gui.mainAgentColor,
    },
})

export default connect(mapStateToProps, mapDispatchToProps)(ShareAdsOnWall2);