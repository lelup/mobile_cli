import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    StatusBar,
    ImageBackground,
    TextInput,
    ListView,
    TouchableHighlight,
    Alert,
    RefreshControl,
    FlatList
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { Actions } from 'react-native-router-flux';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import OfflineBar from '../line/OfflineBar';
import Modal from 'react-native-modalbox';
import ScalableText from 'react-native-text';

import ImagePreview from './ImagePreview';
import GiftedSpinner from "../GiftedSpinner";
import { Map } from 'immutable';
import DanhMuc from '../../assets/DanhMuc';

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import LinearGradient from 'react-native-linear-gradient';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as wallActions from '../../reducers/wall/wallActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as chatActions from '../../reducers/chat/chatActions';

import dismissKeyboard from 'react-native-dismiss-keyboard';

let { width, height } = utils.getDimensions();

let imageGroup = 188;

const actions = [
    globalActions,
    meActions,
    wallActions,
    inboxActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_myGroup = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

class GroupWall extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        this.state = {
            loading: false,
            headerColor: 'transparent',
            backgroundInput: '#fff',
            microButtonColor: gui.colorMainBlur,
            backButtonColor: '#fff',
            inputBorderColor: 'transparent',
            textInputColor: gui.colorMainBlur,
            valuePost: '',
            loaded: false,
            countedRequest: false,
            textSearch: this.props.wall.textSearch,
            pickedRow: {},
            pendingRequest: 0,
            wallList: [],
            isOpenMoreModal: false,
            isOpenFunctionModal: false,
            groupData: props.groupData,
            selectedPost: null,
        }
    }

    componentWillMount() {
        // setTimeout(() => this.fetchData(), 300);
        setTimeout(() => this.getPendingRequest(), 300);

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        //Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

    componentDidMount() {
        StatusBar.setBarStyle('light-content');
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.wall.requestList !== this.props.wall.requestList) {
            this.setState({ pendingRequest: nextProps.group.requestList.length });
        }

        if (nextProps.wall.wallList !== this.props.wall.wallList) {
            this.setState({ wallList: nextProps.group.wallList });
        }

        if (nextProps.wall.textSearch !== this.props.wall.textSearch) {
            this.setState({ textSearch: nextProps.group.textSearch });
        }

        if (nextProps.groupData !== this.props.groupData) {
            this.setState({ groupData: nextProps.groupData });
        }
    }

    fetchData() {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.setState({ 'pendingRequest': 0 });
        // this.props.actions.onWallFieldChange('requestList', [])
        this.props.actions.onWallFieldChange("pageNo", 1);
        let textSearch = this.state.textSearch ? this.state.textSearch.trim() : '' //this.props.wall.textSearch ? this.props.wall.textSearch.trim() : '';

        this.props.actions.getNextWall(
            {
                'groupID': [this.props.groupID],
                'limit': this.props.wall.limit,
                'pageNo': 1,
                'textSearch': textSearch
            }
            , (res) => {
                // console.log('getNextWall: =====>>>>>', res)

                this.props.actions.getPendingRequest(
                    { 'groupID': this.props.groupID }
                    , (res) => {                        
                        this.setState({ pendingRequest: res.data.length })
                    }
                    , (error) => {                        
                        this._updateMessageProcessing(error, '#fa4916', 'white');
                    });
                setTimeout(() => this.props.actions.onWallFieldChange('fetchingPendingRequest', false), 300);
            }
            , (error) => {
                // this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
    }

    getPendingRequest() {
        this.setState({ 'pendingRequest': 0 });
        // this.props.actions.onWallFieldChange('requestList', [])
        this.props.actions.getPendingRequest(
            { 'groupID': this.props.groupID }
            , (res) => {
                // console.log('pendingRequest: =====>>>>>', res)
                this.setState({ pendingRequest: res.data.length })
            }
            , (error) => {
                // this.setState({ countedRequest: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
        setTimeout(() => this.props.actions.onWallFieldChange('fetchingPendingRequest', false), 1000);
    }

    _renderLoadingView() {
        if (this.props.wall.fetchingPendingRequest) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'wallList': [...this.props.wall.wallList, ...data],
            loaded: true
        });

    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {/*<ScrollView
                    automaticallyAdjustContentInsets={false}
                    vertical={true}
                    style={styles.scrollView}
                    scrollEventThrottle={200}
                    onScroll={this.handleScroll.bind(this)}
                    onStartShouldSetResponder={(evt) => false}
                    onMoveShouldSetResponder={(evt) => false}
                >*/}
                {this._renderBodyMyGroup()}

                {/*</ScrollView>*/}
                {this._renderHeaderBar()}
                {this.props.wall.showImagePreview ? this._renderImagePreviewModal(this.state.pickedRow) : null}
                {this._renderLoadingView()}
                {this._openMoreModal()}
                {this._openFunctionModal()}
            </View>
        );
    }

    _onMoreButtonPress(data) {
        this.setState({ isOpenMoreModal: true });
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        let currentUser = this.props.global.currentUser;
        let modalHeight = currentUser.userID == this.state.groupData.userID ? 169 : 116;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: modalHeight }]}
                position={"bottom"}
                swipeToClose={false}
               animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {
        let mainItems = null;
        let currentUser = this.props.global.currentUser;

        if (currentUser.userID == this.state.groupData.userID)
            mainItems = <View style={styles.viewSwipeButton}>
                <TouchableOpacity onPress={this._onEditGroupPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                    <Text style={styles.textMoreButton}>Sửa sàn</Text>
                </TouchableOpacity>
                <View style={styles.lineSpaceButton} />
                <TouchableOpacity onPress={this._onDeleteGroupPress.bind(this)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                    <Text style={styles.textMoreButton}>Xóa sàn</Text>
                </TouchableOpacity>
            </View>;
        else
            mainItems = <View style={[styles.viewSwipeButton, { height: 52 }]}>
                <TouchableOpacity onPress={this._onLeaveGroupPress.bind(this)} style={styles.viewButtonModal}>
                    <Text style={styles.textMoreButton}>Rời khỏi sàn</Text>
                </TouchableOpacity>
            </View>;
        // }
        return (
            <View style={styles.viewShowModal}>
                {mainItems}
                {/*<TouchableOpacity onPress={() => this._outMoreModal()} style={styles.viewSwipeButton2}>
                    <Text style={[styles.textMoreButton, {fontWeight: '500', fontSize: 18}]}>Hủy</Text>
                </TouchableOpacity>*/}
            </View>
        )
    }

    _onFunctionButtonPress(data) {
        this.setState({ isOpenFunctionModal: true, selectedPost: data });
    }

    _outFunctionModal() {
        this.setState({
            isOpenFunctionModal: false
        });
    }

    _openFunctionModal() {
        let currentUser = this.props.global.currentUser;
        let selectedPost = this.state.selectedPost;
        let modalHeight = selectedPost && selectedPost.userID == currentUser.userID ? 229 : 169;
        return (
            <Modal isOpen={this.state.isOpenFunctionModal}
                onClosed={this._outFunctionModal.bind(this)}
                style={[styles.viewModalStyle, { height: modalHeight, marginBottom: 100 }]}
                position={"bottom"}
                swipeToClose={false}
               animationDuration={200}
            >
                {this._renderFunctionContent()}
            </Modal>
        );
    }

    _renderFunctionContent() {
        let selectedPost = this.state.selectedPost;
        let mainItems;
        let currentUser = this.props.global.currentUser;
        if (selectedPost && selectedPost.userID == currentUser.userID)
            mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>
                <TouchableOpacity onPress={this._onEditPostPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                    <Text style={styles.textMoreButton}>Sửa bài</Text>
                </TouchableOpacity>
                <View style={styles.lineSpaceButton} />
                <TouchableOpacity onPress={this._onDeletePostPress.bind(this)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                    <Text style={styles.textMoreButton}>Xóa bài</Text>
                </TouchableOpacity>
                
            </View>
        else
            mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>                
                <TouchableOpacity onPress={this.onChat.bind(this)} style={[styles.viewButtonModal]}>
                    <Text style={styles.textMoreButton}>Chat với người đăng</Text>
                </TouchableOpacity>
            </View>

        return (
            <View style={styles.viewShowModal}>
                {mainItems}
            </View>
        )
    }

    _onEditGroupPress() {
        let selectedGroup = this.state.groupData;
        if (!selectedGroup) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        if (userID != selectedGroup.createdBy) {
            Alert.alert('Thông báo', 'Bạn không phải là quản trị của sàn \'' + selectedGroup.name + '\' ?');
            return;
        }
        this.props.actions.onGroupFieldChange('groupID', selectedGroup.groupID);
        this.props.actions.onGroupFieldChange('name', selectedGroup.name);
        this.props.actions.onGroupFieldChange('groupType', selectedGroup.groupType);
        this.props.actions.onGroupFieldChange('chiTiet', selectedGroup.chiTiet);
        this.props.actions.onGroupFieldChange('photos', selectedGroup.image ? [{ uri: selectedGroup.image }] : []);
        this.props.actions.onGroupFieldChange('allDiaChinh', selectedGroup.diaBan);
        Actions.Group({ doAfterSaveGroup: this._outMoreModal.bind(this), doRefreshGroupInfo: this._doRefreshGroupInfo.bind(this) });
        this._outMoreModal();
    }

    _onEditPostPress() {
        let selectedPost = this.state.selectedPost;
        // log.info('_onEditPostPress ******', selectedPost)
        if (!selectedPost) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let images = []
        if (selectedPost.image && selectedPost.image.length > 0)
            selectedPost.image.forEach((e) => {
                images.push({ uri: e })
            })

        // this.props.actions.onWallFieldChange('postID', selectedPost.id)
        // this.props.actions.onWallFieldChange('postContent', selectedPost.content)
        // this.props.actions.onWallFieldChange('postWallPhotos', images);
        // this.props.actions.onWallFieldChange('postWallAds', selectedPost.adsList ? selectedPost.adsList[0] : {});
        let editDto = {
            postID: selectedPost.id,
            postContent: selectedPost.content,
            postWallPhotos: images,
            postWallAds: selectedPost.adsList ? selectedPost.adsList[0] : {}
        }
        this.props.actions.onWallAllFieldChange(editDto);

        Actions.GroupPostAds({ groupData: this.state.groupData, groupID: this.props.groupID });
        this._outFunctionModal();
    }

    _doRefreshGroupInfo(groupData) {
        if (groupData) {
            this.setState({ groupData: groupData })
        }
    }

    _onDeleteGroupPress() {
        let selectedGroup = this.state.groupData;
        if (!selectedGroup) {
            return;
        }
        Alert.alert('Thông báo', 'Bạn muốn xóa sàn \'' + selectedGroup.name + '\' ?',
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedGroup.groupID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.deleteGroup(groupID, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            } else {
                                let userID = this.props.global.currentUser.userID || undefined;
                                // this.props.actions.onRefreshGroupInbox(userID);
                            }
                        });
                    this._outMoreModal();
                }
            }
            ]);
        Actions.GroupMain();
    }


    _onDeletePostPress() {
        let selectedPost = this.state.selectedPost;
        if (!selectedPost) {
            return;
        }
        Alert.alert('Thông báo', 'Bạn muốn xóa bài viết ?',
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let postID = selectedPost.id;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.deletePost(postID, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            }
                            else {
                                setTimeout(() => Alert.alert("Thông báo", "Xoá bài viết thành công.", [{
                                    text: 'Đóng', onPress: () => {

                                        this.props.actions.getNextWall(
                                            {
                                                'groupID': [this.props.groupID],
                                                'limit': this.props.wall.limit,
                                                'pageNo': this.props.wall.pageNo,
                                                'textSearch': this.props.wall.textSearch ? this.props.wall.textSearch.trim() : ''
                                            }
                                            , (res) => {
                                                // console.log('server respond data: =====>>>>>', res)
                                                this.refreshRowData(res.data)
                                            }
                                            , (error) => {
                                                this.setState({ loaded: true });
                                                this._updateMessageProcessing(error, '#fa4916', 'white');
                                            });
                                    }
                                }]), 1000);
                            }
                        });
                    this._outFunctionModal();
                }
            }
            ]);
        // Actions.GroupMain();
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn rời khỏi sàn ?');
    }

    _doLeaveOrCall(title) {

        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = this.props.groupID;
                    let userID = this.props.global.currentUser.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.leaveGroup({ groupID: groupID, userID: userID }, token);
                    this._outMoreModal();
                }
            }
            ]);
        Actions.GroupMain();
    }

    _renderNameGroup() {
        let group = this.state.groupData;
        let groupName = group && group.name || '';
        return (
            <View style={styles.viewNameGroup}>
                <ScalableText style={styles.textNameGroup} numberOfLines={2}>{groupName}</ScalableText>
            </View>
        );
    }

    _renderTotalMembers() {
        let group = this.state.groupData;
        let countMember = group && group.countMember || 0;
        return (
            <View style={styles.viewTotalMembers}>
                <Text style={styles.textTotalMembers} numberOfLines={1}>{countMember} Thành viên</Text>
            </View>
        );
    }


    _renderHeaderBar() {
        let { headerColor, microButtonColor, inputBorderColor, textInputColor, backgroundInput, backButtonColor } = this.state;
        return (
            <View style={headerColor != 'transparent' ? styles.headerContainer : {}}>
                <LinearGradient colors={['rgba(0, 0, 0, 0.9)', 'transparent']}
                    style={styles.linearGradient}>
                    <View style={{ height: 72 }}></View>
                    <View style={[styles.customPageHeader, { backgroundColor: headerColor }]}>
                        <TouchableOpacity style={styles.viewBackMyGroup}
                            onPress={this._onPressBack.bind(this)}
                        >
                            <MaterialCommunityIcons name="arrow-left" size={24} color={backButtonColor} style={{ marginLeft: 0 }} />
                        </TouchableOpacity>
                        <View style={styles.inputMainView}>
                            <TouchableOpacity style={[styles.viewInputMyGroup, { borderColor: inputBorderColor, backgroundColor: backgroundInput }]}
                                onPress={this._onPressSearch.bind(this)}
                            >
                                {/* <View style={styles.viewTextInput}>
                                    {<Text style={[styles.textSearch, { color: textInputColor }]}>Tìm trong sàn</Text>}                                    
                                </View> */}
                                <TextInput
                                    autoFocus={false}
                                    autoCapitalize='none'
                                    autoCorrect={false}
                                    returnKeyType='done'
                                    underlineColorAndroid='rgba(0,0,0,0)'
                                    style={styles.viewTextInput}
                                    placeholder="Tìm trong sàn" placeholderTextColor={gui.arrowColor}
                                    onChangeText={(text) => { this.onValueChange("textSearch", text) }}
                                    value={this.state.textSearch}
                                    onSubmitEditing={this._onSearchInputSubmitEditting.bind(this)}
                                />

                                {/*<View style={styles.viewIconMicro}>
                                    <Icon name="microphone" size={24} color={microButtonColor} style={{ marginLeft: 0 }} />
                                </View>*/}
                            </TouchableOpacity>
                        </View>
                    </View>
                </LinearGradient>
            </View>
        );
    }

    _onSearchInputSubmitEditting() {
        dismissKeyboard();
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.setState({ 'pendingRequest': 0 });
        // this.props.actions.onWallFieldChange('requestList', [])
        this.props.actions.onWallFieldChange("pageNo", 1);
        let textSearch = this.state.textSearch ? this.state.textSearch.trim() : '' //this.props.wall.textSearch ? this.props.wall.textSearch.trim() : '';

        this.props.actions.getNextWall(
            {
                'groupID': [this.props.groupID],
                'limit': this.props.wall.limit,
                'pageNo': 1,
                'textSearch': textSearch
            }
            , (res) => {
            }
            , (error) => {
                // this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
    }

    handleScroll(event) {
        if (event.nativeEvent.contentOffset.y <= imageGroup && this.state.headerColor != 'transparent') {
            StatusBar.setBarStyle('light-content');
            this.setState({
                headerColor: 'transparent',
                backgroundInput: '#fff',
                microButtonColor: gui.colorMainBlur,
                backButtonColor: '#fff',
                inputBorderColor: 'transparent',
                textInputColor: gui.colorMainBlur
            });
        } else if (event.nativeEvent.contentOffset.y > imageGroup && this.state.headerColor != gui.mainColor) {
            StatusBar.setBarStyle('default');
            this.setState({
                headerColor: '#fff',
                backgroundInput: gui.mainColor,
                microButtonColor: '#fff',
                backButtonColor: gui.mainColor,
                inputBorderColor: gui.mainColor,
                textInputColor: '#fff'
            });
        }
    }

    _renderButtonGroups() {
        return (
            <View style={styles.viewButtonGroup}>
                <TouchableOpacity onPress={this._onMoreButtonPress.bind(this)}>
                    <View style={[styles.viewEachButton, { marginLeft: 16 }]}>
                        <Icon name="check" size={22} color={gui.mainAgentColor} style={{ marginLeft: 0 }} />
                        <Icon name="sort-desc" size={14} color={gui.mainAgentColor} style={styles.sortDescIcon} />
                        <Text style={styles.textBottonGroup} numberOfLines={1}>Đã tham gia</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity onPress={this._onGroupFilterPress.bind(this)}>
                    <View style={styles.viewEachButton}>
                        <Icon name="home" size={22} color={gui.mainAgentColor} style={{ marginLeft: 0 }} />
                        <Text style={styles.textBottonGroup} numberOfLines={1}>Nguồn hàng</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity onPress={this._onMemberPress.bind(this)}>
                    <View style={styles.viewEachButton}>
                        <Icon name="users" size={19} color={gui.mainAgentColor} style={{ marginLeft: 0 }} />
                        <Text style={styles.textBottonGroup} numberOfLines={1}>Thành viên</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity onPress={this._onGroupDetail.bind(this)}>
                    <View style={[styles.viewEachButton, { marginRight: 16 }]}>
                        <Icon name="exclamation-circle" size={22} color={gui.mainAgentColor} style={{ marginLeft: 0 }} />
                        <Text style={styles.textBottonGroup} numberOfLines={1}>Thông tin</Text>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderNewRequest() {
        if (this.state.pendingRequest == 0)
            return (<View style={{ marginTop: 0 }}><FullLine /></View>);
        return (
            <TouchableOpacity style={styles.viewNewRequest}
                onPress={this._onPressNewRequest.bind(this)}
            >
                <Text style={[styles.textBottonGroup, { color: '#fff' }]}>{this.state.pendingRequest} yêu cầu tham gia mới</Text>
            </TouchableOpacity>
        );
    }

    _renderBodyMyGroup() {
        return (
            <View style={styles.scrollView}>
                {this._renderListMyGroup()}
            </View>
        )
    }

    _renterPostSource() {
        let imgUrl = this.props.global.currentUser.avatar;
        let imageMyPost = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!imgUrl) {
            imageMyPost = defaultAvatar;
        }
        return (
            <View style={styles.postSourceStyle}>
                <View style={styles.viewPostSource}>
                    <Image
                        resizeMode={"cover"}
                        source={imageMyPost}
                        defaultSource={defaultCover}
                        style={styles.myAvatarPost} />
                    {/* <TextInput
                        autoFocus={false}
                        autoCorrect={false}
                        returnKeyType='done'
                        underlineColorAndroid='rgba(0,0,0,0)'
                        style={styles.viewTextInputPost}
                        placeholder="Chia sẻ thông tin…" placeholderTextColor={gui.colorMainBlur}

                    /> */}
                    <TouchableOpacity style={styles.viewTextInputPost} onPress={this._onPostWall.bind(this)}>
                        <Text style={styles.textInputPost}>Chia sẻ thông tin…</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _refreshGroupPostAds() {
        // this.props.actions.onWallFieldChange('postID', null)
        // this.props.actions.onWallFieldChange('postContent', '')
        // this.props.actions.onWallFieldChange('postWallPhotos', []);
        // this.props.actions.onWallFieldChange('postWallAds', {});

        let emptyDto = {
            postID: null,
            postContent: '',
            postWallPhotos: [],
            postWallAds: {}
        }
        this.props.actions.onWallAllFieldChange(emptyDto);

    }

    _onPostWall() {
        this._refreshGroupPostAds();
        Actions.GroupPostAds({ groupData: this.state.groupData, groupID: this.props.groupID });
    }

    _onChangeText(text) {
        this.setState({
            valuePost: text
        })
    }

    _onMemberPress() {
        this.props.actions.getAllMember(
            { 'groupID': this.props.groupID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
            }
            , (error) => {
                console.log('server respond error: =====>>>>>', error)
                // this.setState({ loaded: true });
                // this._updateMessageProcessing(error, '#fa4916', 'white');
            });
        Actions.GroupMember({ groupData: this.state.groupData, groupID: this.props.groupID });
    }

    _onGroupDetail() {
        Actions.GroupDetail2({ groupData: this.state.groupData, groupID: this.props.groupID, owner: 'GroupWall' });
    }

    _onGroupFilterPress() {
        Actions.GroupFilterResult({ groupData: this.state.groupData, groupID: this.props.groupID });
    }

    _onPressAdsRow(ads) {
        Actions.GroupAdsDetail({ adsID: ads.id || ads.adsID, imageDetail: ads.image.cover, owner: 'GroupWall' });
    }

    _renderListMyGroup() {
        let group = this.state.groupData;
        let mySourceImg = group && group.image || '';
        let imageUriGroup = { uri: mySourceImg };
        let defaultCover = require('../../assets/image/photo_detail_blank.jpg');
        if (!mySourceImg) {
            imageUriGroup = defaultCover;
        }
        let userID = this.props.global.currentUser.userID;
        let showNewRequest = (userID == group.userID);
        let firstItem = (
            <View style={{ marginBottom: 0 }} >
                <ImageBackground style={styles.imgItemHeader}
                    source={imageUriGroup} defaultSource={defaultCover}>
                    <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                        style={styles.linearGradient2}>
                        {this._renderNameGroup()}
                        {this._renderTotalMembers()}

                    </LinearGradient>
                </ImageBackground>
                {this._renderButtonGroups()}
                {showNewRequest ? this._renderNewRequest() : null}
                {this._renterPostSource()}
            </View>
        );
        let dsMyGroup = ds_myGroup.cloneWithRows([firstItem, ...this.props.wall.wallList]);       

        return (
            <View style={{ flex: 1 }}>
                <FlatList
                    refreshControl={
                        <RefreshControl
                            refreshing={false}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                    ref={(ref) => this.scrollView = ref}
                    data={this.props.wall.wallList}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRowMyGroup(data.item)}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                    onEndReachedThreshold={200}
                    ListHeaderComponent={this._renderHeaderContent()}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.listContent}
                    contentContainerStyle={{ paddingBottom: 50 }}
                    onEndReached={this.loadNextPage.bind(this)}
                />
            </View>
        );
    }

    _renderHeaderContent() {
        let group = this.state.groupData;
        let mySourceImg = group && group.image || '';
        let imageUriGroup = { uri: mySourceImg };
        let defaultCover = require('../../assets/image/photo_detail_blank.jpg');
        if (!mySourceImg) {
            imageUriGroup = defaultCover;
        }
        let userID = this.props.global.currentUser.userID;
        let showNewRequest = (userID == group.userID);
        return (
            <View style={{ marginBottom: 0 }} >
                <ImageBackground style={styles.imgItemHeader}
                                 source={imageUriGroup} defaultSource={defaultCover}>
                    <LinearGradient colors={['rgba(50, 50, 50, 0.5)', 'rgba(50, 50, 50, 0.5)']}
                                    style={styles.linearGradient2}>
                        {this._renderNameGroup()}
                        {this._renderTotalMembers()}

                    </LinearGradient>
                </ImageBackground>
                {this._renderButtonGroups()}
                {showNewRequest ? this._renderNewRequest() : null}
                {this._renterPostSource()}
            </View>
        );
    }

    _onRefresh() {
        this.fetchData();
    }

    onValueChange(key: string, value: string) {
        // this.props.actions.onWallFieldChange(key, value);
        this.setState({ textSearch: value });
    }

    onChat() {
        this._outFunctionModal();
        let data = this.state.selectedPost
        let partner = data.userID ? { userID: data.userID } : undefined;
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');

        if (!partner) {
            Alert.alert("Thông báo", 'Có lỗi xảy ra. Không thể bắt đầu trò chuyện.', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        if (this.props.global.currentUser.userID == partner.userID) {
            Alert.alert("Thông báo", 'Bạn không thể chat với chính mình.', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
                this.setState({
                    isloadingPressRow: false
                })
            });
    }

    _renderRowMyGroup(value, isFirstRow, isLastRow) {
        let data = value;
        if (isFirstRow) {
            return data;
        }
        if (data.adsList && data.adsList.length > 0 && (data.adsList[0].id || data.adsList[0].adsID))

            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderAdsImagePost(data)}
                    {this._renderDetailPost(data)}
                </View>
            );
        if (data.image && data.image.length > 0)
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderSimpleImagePost(data)}
                    {this._renderCommentCount(data)}

                </View>
            );
        return (
            <View style={styles.viewListMyGroup}>
                {this._renderRowTopContent(data)}
                {this._renderCommentCount(data)}

            </View>
        );
    }

    _renderRowTopContent(data) {
        let userAvatar = { uri: data.avatar };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!data.avatar) {
            userAvatar = defaultAvatar;
        }
        let textPromote = data.content || '';
        let nameMainUser = data.fullName || '';
        let timePost = utils.getDiffTime(data.timeModified) || '';


        return (
            <View style={styles.viewRowTopContent}>
                <View style={styles.viewMainUser}>
                    <Image
                        resizeMode={"cover"}
                        source={userAvatar}
                        defaultSource={defaultCover}
                        style={styles.mainUserAvatar} />

                    <View style={{ width: (width - 16) / 2 - 5, height: 24 }}>
                        <ScalableText numberOfLines={2} style={[styles.textMainUser, { marginLeft: 8, fontSize: 13 }]}>{nameMainUser}</ScalableText>
                    </View>

                    <View style={{ height: 24 }}>
                        <ScalableText style={[styles.textMainMinute, { fontSize: 13 }]}>{timePost}</ScalableText>
                    </View>
                    <TouchableOpacity onPress={this._onFunctionButtonPress.bind(this, data)} style={styles.viewIconBubble}>
                        <MaterialIcons name="more-vert" size={19} color={gui.mainTextColor} />
                    </TouchableOpacity>

                </View>
                <Text style={[styles.textSearch, { marginTop: 16, color: gui.mainTextColor }]}>{textPromote}</Text>
            </View>
        );
    }

    _renderAdsImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let adsCoverPhoto = { uri: ads.image ? ads.image.cover : '' };
        if (!ads.image || !ads.image.cover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <ImageBackground style={[styles.imgItem, { height: 156 }]}
                source={adsCoverPhoto} defaultSource={defaultCover}>
                <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}>
                    <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                        style={styles.linearGradientMain}>
                        {this._renderUserLogo(data)}
                        {this._renderNamePrice(data)}
                    </LinearGradient>
                </TouchableOpacity>
            </ImageBackground>
        )
    }

    _renderSimpleImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let imageCover = {};
        if (data.image && data.image.length > 0) {
            imageCover = data.image[0];
        }
        let adsCoverPhoto = { uri: imageCover };
        if (!imageCover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <View>
                <TouchableOpacity onPress={this._onImagePreviewPressed.bind(this, data)} underlayColor="transparent" >
                    <View>
                        <ImageBackground style={[styles.imgItem, { height: 156 }]}
                            source={adsCoverPhoto} defaultSource={defaultCover}>
                            <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                                style={styles.linearGradientMain}>
                            </LinearGradient>
                            {this._renderTotalPhoto(data)}
                        </ImageBackground>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _renderImagePreviewModal(data) {
        if (!data)
            return null;

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image) {
            for (let i = 0; i < data.image.length; i++) {
                imageUrl = data.image[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }

        let userID = null;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        return (
            <ImagePreview images={imageDataItems}
                closeModal={() => this.props.actions.onWallFieldChange('showImagePreview', false)} ads={data} userID={userID}
                loggedIn={this.props.global.loggedIn}
            />
        );
    }

    _renderTotalPhoto(data) {
        if (!data) {
            return null;
        }

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image) {
            for (let i = 0; i < data.image.length; i++) {
                imageUrl = data.image[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }
        let total = imageDataItems.length;
        return (
            <View style={{
                position: 'absolute',
                bottom: 20,
                left: 16
            }}>
                <RelandIcon name="camera-o" color="#fff"
                    iconProps={{ style: styles.pagingIcon }} size={16}
                    textProps={styles.pagingText}
                    mainProps={styles.pagingView}
                    text={(total) + ' ảnh'}
                >
                </RelandIcon>
            </View>
        );
    }

    _onImagePreviewPressed(data) {
        if (!data.image) {
            return;
        }
        if (this.props.wall.showImagePreview) {
            return;
        }
        this.props.actions.onWallFieldChange('showImagePreview', true);
        this.setState({
            pickedRow: data
        });
    }



    loadNextPage() {
        let myProps = this.props.wall;
        // console.log('props =======>>', myProps);

        if (myProps.loadingWall) {
            return;
        }

        let pageNo = myProps.pageNo;
        let totalPages = myProps.totalWallCount / myProps.limit;

        if (totalPages && pageNo < totalPages) {
            pageNo = pageNo + 1;
            this.props.actions.onWallFieldChange("pageNo", pageNo);
            let textSearch = this.state.textSearch ? this.state.textSearch.trim() : '' //this.props.wall.textSearch ? this.props.wall.textSearch.trim() : ''
            this.props.actions.getNextWall(
                {
                    'groupID': [this.props.groupID],
                    'limit': this.props.wall.limit,
                    'pageNo': pageNo,
                    'textSearch': textSearch
                }
                , (res) => {
                    // console.log('server respond data: =====>>>>>', res)
                    this.refreshRowData(res.data)
                }
                , (error) => {
                    this.setState({ loaded: true });
                    this._updateMessageProcessing(error, '#fa4916', 'white');
                });
        }
    }

    _renderPagination(index, total, context) {
        return (
            <View style={{
                position: 'absolute',
                bottom: 20,
                left: 20,
            }}>
                <RelandIcon name="camera-o" color="black"
                    iconProps={{ style: styles.pagingIcon }} size={16}
                    textProps={styles.pagingText}
                    mainProps={styles.pagingView}
                    text={(index + 1) + '/' + (total)}
                >
                </RelandIcon>
            </View>
        )
    }

    _renderUserLogo(data) {
        let ads;
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let logoItems = [];
        let index = 0;

        if (ads && ads.banGap) {
            let marginLeft = index == 0 ? 0 : 8;
            let banGapText = ads.loaiTin ? DanhMuc.THUE_GAP : DanhMuc.BAN_GAP;
            logoItems.push(
                <View key={'logoBanGap'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{banGapText}</Text>
                </View>
            );
            index++;
        }


        if (ads && ads.chinhChuDangTin) {
            let marginLeft = index == 0 ? 0 : 8;
            logoItems.push(
                <View key={'logoChinhChuDangTin'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{DanhMuc.CHINH_CHU}</Text>
                </View>
            );
            index++;
        }

        return (
            <View style={styles.viewUserLogo}>
                {logoItems}
            </View>
        );
    }

    _renderNamePrice(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let imageChildUser = { uri: ads.avatar };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        let nameUserChild = ads.fullName;
        return (
            <View style={styles.viewNamePrice}>
                <View style={styles.viewPrice}>
                    <Text style={[styles.textNameGroup, { fontSize: 20 }]} numberOfLines={1}>{priceValue}</Text>
                </View>
                {/* <View style={styles.viewUserPostChild}>
                    <View style={styles.viewNameUserChild}>
                        <Text style={[styles.textNameChild, { color: '#fff' }]} numberOfLines={1}>{nameUserChild}</Text>
                    </View>
                    <Image
                        resizeMode={"cover"}
                        source={imageChildUser}
                        defaultSource={defaultCover}
                        style={styles.mainUserChild} />
                </View> */}
            </View>
        );
    }

    _renderDetailPost(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let areaValue = utils.getDienTichDisplay(ads.dienTich);
        let bedroomValue = ads.soPhongNgu;
        let bathroomValue = ads.soPhongTam;
        let addressValue = '';
        let textMotionValue = '';
        if (ads.place) {
            addressValue = ads.place.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail(ads);
        } else {
            
            addressValue = ads.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail2(ads);
        }
        let timePostValue = ads.ngayDangTin ? utils.formatDate(ads.ngayDangTin) : '';
        let commentCount = data.commentCount || 0;
        let commentValue = commentCount + ' Bình luận';
        return (
            <View style={styles.viewDetailPost}>
                <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}>
                    <View style={styles.viewMainTextPost}>
                        <Text style={styles.textMainPost} numberOfLines={2}>{textMotionValue}</Text>
                    </View>
                    <View style={styles.lineDangNhap} />
                    <View style={styles.viewContentSource}>
                        {this._renderDienTich(areaValue)}
                        {this._renderPhongNgu(bedroomValue, (areaValue != DanhMuc.KHONG_RO) ? 15 : 0)}
                        {this._renderPhongTam(bathroomValue, (!bedroomValue && areaValue == DanhMuc.KHONG_RO) ? 0 : 12)}

                        <Text style={styles.textTimePost} numberOfLines={1}>{timePostValue}</Text>
                    </View>
                    <View style={styles.viewTextAddress}>
                        <Text style={[styles.textMainMinute, { marginLeft: 0 }]} numberOfLines={1}>{addressValue}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.lineDangNhap} />
                <TouchableOpacity style={styles.viewLikeComment} onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textMainUser, { fontWeight: 'normal' }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{commentValue}</Text>
                    <Text style={styles.textMainUser}>Bình luận</Text>
                </TouchableOpacity>
                {this._renderLastComment(data)}
            </View>
        )
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        if (bathroomValue)
            return (
                <View style={{ height: 36, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <RelandIcon noAction={true}
                        name="bath-b" color={gui.mainTextColor}
                        mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        if (bedroomValue)
            return (
                <View style={{ height: 36, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <Icon name="bed" size={15} color={gui.mainTextColor} style={{ marginLeft: marginLeft }} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderDienTich(areaValue) {
        if (areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View style={{ height: 36, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <Icon name="square-o" size={15} color={gui.mainTextColor} style={{ marginLeft: 0 }} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderCommentCount(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let commentCount = data.commentCount || 0;
        let commentValue = commentCount + ' Bình luận';
        let viewsValue = data.viewsValue;

        return (
            <View style={styles.viewDetailPost}>

                <View style={styles.lineDangNhap} />
                <TouchableOpacity style={[styles.viewLikeComment]}
                    onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textMainUser, { fontWeight: 'normal' }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >
                        {commentValue}
                    </Text>
                    <Text style={styles.textMainUser}>Bình luận</Text>
                </TouchableOpacity>
                {this._renderLastComment(data)}
            </View>
        )
    }

    _renderLastComment(data) {
        let lastComment = data.lastComment;
        if (lastComment) {
            let imageUserComment
            if (lastComment.createdByAvatar)
                imageUserComment = { uri: lastComment.createdByAvatar };
            else {
                imageUserComment = require('../../assets/image/register_avatar_icon.png');
            }
            let defaultCover = require('../../assets/image/register_avatar_icon.png');

            let nameUser = lastComment.createdByName ? lastComment.createdByName : '';
            let commentContent = lastComment.content ? lastComment.content : '';

            return (
                <View>
                    <View style={styles.lineDangNhap} />
                    <TouchableOpacity style={styles.viewRowComment}
                        onPress={() => this._onPressComment(data)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageUserComment}
                            defaultSource={defaultCover}
                            style={styles.mainUserAvatar} />
                        <View style={styles.viewContentComment}>
                            <Text style={styles.nameUserComment} numberOfLines={1}>{nameUser}</Text>
                            <Text style={styles.textContentChat} numberOfLines={1}>{commentContent}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }
        else return (<View></View>)
    }


    _onPressComment(data) {
        Actions.GroupComment({ parentContent: data, groupID: data.groupID, groupWallID: data.id });
    }

    _onPressBack() {
        if (this.props.owner == 'MyAlert')
            Actions.MyAlert();
        else {
            this.setState({ 'pendingRequest': 0 });
            // this.props.actions.onWallFieldChange('requestList', []);
            Actions.GroupMain();
            StatusBar.setBarStyle('default');
        }
    }

    _onPressSearch() {
        console.log('============> _onPressSearch');
    }
    _onPressNewRequest() {
        log.info('============> _onPressNewRequest');
        Actions.GroupRequest({ groupData: this.state.groupData, groupID: this.props.groupID });
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        flexGrow: 1,
        position: 'absolute',
        height: height - 44
    },
    viewListContainer: {
        paddingBottom: 50
    },
    linearGradient: {
        flexGrow: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    customPageHeader: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: width,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        height: 72
    },
    inputMainView: {
        width: width - 112,
        height: 72,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom: 5
    },
    viewBackMyGroup: {
        height: 72,
        width: 56,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 12
    },
    viewInputMyGroup: {
        height: 40,
        width: width - 112,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row',
        borderRadius: 2,
        borderWidth: 1
    },
    viewIconMicro: {
        width: 27,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextInput: {
        width: width - 118,
        height: 40,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    imgItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 16,
        height: imageGroup,
        alignSelf: 'auto',
        marginLeft: 8,
        marginRight: 8
    },
    imgItemHeader: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: imageGroup,
        alignSelf: 'auto',
    },
    imgItem2: {
        width: width,
        height: imageGroup,
        alignSelf: 'auto'
    },
    viewNameGroup: {
        marginTop: 74,
        marginLeft: 16,
        // height: 36,
        width: width - 32,
        backgroundColor: 'transparent'
    },
    viewTotalMembers: {
        marginTop: 4,
        marginLeft: 16,
        height: 20,
        width: width - 180,
        backgroundColor: 'transparent'
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: '#fff',
        fontWeight: '500'
    },
    textTotalMembers: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: 'rgba(255,255,255,0.75)',
        fontWeight: 'normal'
    },
    linearGradient2: {
        marginTop: 0,
        height: imageGroup,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    linearGradientMain: {
        marginTop: 0,
        height: 156,
        width: width - 16,
        marginLeft: 0,
        marginRight: 0,
        backgroundColor: "transparent"
    },
    viewButtonGroup: {
        width: width,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    viewEachButton: {
        height: 56,
        width: (width - 32) / 4,
        backgroundColor: '#fff',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: 5
    },
    textBottonGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: 'normal'
    },
    sortDescIcon: {
        position: 'absolute',
        top: 14,
        right: 18
    },
    viewNewRequest: {
        height: 32,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    viewBodyMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    postSourceStyle: {
        height: 66,
        width: width,
        backgroundColor: gui.groupBackground,
        paddingTop: 8
    },
    viewPostSource: {
        height: 58,
        marginLeft: 8,
        marginRight: 8,
        width: width - 16,
        flexDirection: 'row',
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2
    },
    myAvatarPost: {
        width: 32,
        height: 32,
        borderRadius: 16,
        marginLeft: 13
    },
    viewTextInputPost: {
        height: 38,
        backgroundColor: '#fff',
        width: width - 80,
        paddingLeft: 12,
        justifyContent: 'center'
    },
    textInputPost: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        color: gui.colorMainBlur
    },
    viewListMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 8, //14,
        backgroundColor: gui.groupBackground
    },
    viewRowTopContent: {
        marginLeft: 8,
        marginRight: 8,
        paddingTop: 16,
        paddingBottom: 12,
        paddingLeft: 16,
        paddingRight: 16,
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderBottomWidth: 0,
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
        backgroundColor: '#fff',
        width: width - 16,
        height: 'auto'
    },
    viewMainUser: {
        height: 24,
        width: width - 48,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    mainUserAvatar: {
        height: 24,
        width: 24,
        borderRadius: 12
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 0, //8
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        marginLeft: 5
    },
    viewIconBubble: {
        position: 'absolute',
        right: 0,
        top: 0
    },
    viewUserLogo: {
        position: 'absolute',
        left: 17,
        bottom: 52,
        height: 24,
        // width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 16, //23
        bottom: 13,
        height: 32,
        width: width - 46,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent'
    },
    viewUserPostChild: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    mainUserChild: {
        height: 26,
        width: 26,
        borderRadius: 13
    },
    viewNameUserChild: {
        height: 32,
        width: width - 48 - 24 - 8 - 16,
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundColor: 'transparent',
    },
    textNameChild: {
        fontSize: 12,
        color: '#fff',
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewDetailPost: {
        // height: 145,
        width: width - 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderTopWidth: 0,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        backgroundColor: '#fff',
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 12,
        paddingLeft: 16,
        paddingRight: 16,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 46,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 16
    },
    viewContentSource: {
        height: 36,
        width: width - 12,
        paddingLeft: 16,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTextAddress: {
        height: 28,
        width: width - 12,
        paddingLeft: 16,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    textTimePost: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        position: 'absolute',
        right: 17
    },
    viewLikeComment: {
        height: 39,
        width: width - 12,
        paddingLeft: 16,
        paddingRight: 16,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 3,
        bottom: 32
    },
    pagingText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#fff',
        marginRight: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingIcon: {
        borderRadius: 0,
        marginLeft: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingView: {
        flexDirection: 'row',
        backgroundColor: '#5b5c61',
        borderRadius: 5,
        opacity: 0.75
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent',
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewRowComment: {
        height: 60,
        width: width - 16,
        paddingLeft: 16,
        paddingRight: 16,
        paddingTop: 8,
        flexDirection: 'row',
        marginBottom: 4
    },
    myAvatarCommnent: {
        width: 32,
        height: 32,
        borderRadius: 16
    },
    viewContentComment: {
        justifyContent: 'center',
        marginLeft: 8,
        backgroundColor: '#f0f1f3',
        width: width - 48 - 24 - 8,
        height: 48,
        borderRadius: 12,
        paddingHorizontal: 8,
        paddingVertical: 8
    },
    viewNameComment: {
        justifyContent: 'center',
        width: width - 48 - 24 - 8 - 12,
        height: 18
    },
    viewDetailLastContent: {
        width: width - 48 - 24 - 8 - 12,
        height: 42
    },
    viewNameUser: {
        height: 20,
        width: width - 64,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        paddingLeft: 8
    },
    nameUserComment: {
        fontSize: 12,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
    },
    timeMinuteComment: {
        fontSize: 12,
        color: gui.colorMainBlur,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        position: 'absolute',
        right: 0,
        top: 0
    },
    textContentChat: {
        fontSize: 12,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
    },
    listContent: {
        height: height - 50,
        width: width,
        backgroundColor: gui.groupBackground
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupWall);
