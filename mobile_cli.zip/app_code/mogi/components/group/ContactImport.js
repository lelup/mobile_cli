import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    FlatList,
    RefreshControl
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import GiftedSpinner from "../GiftedSpinner";
import SearchInput from './SearchInputAgent';
import Contacts from 'react-native-contacts';
import CheckBox from './CheckBox';
import RangeUtils from "../../lib/RangeUtils"

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import cfg from "../../cfg";
const minLength = 0;

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    groupContactActions,
    inboxActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class ContactImport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            laoding: false,
            searchText: '',
            isOpenMoreModal: false,
            focused: false,
            text: props.groupContact.searchContact,
            orderByKey: '',
            deviceContactList: props.groupContact.filteredDeviceContactList,
            isCheckAll: false
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.deviceContactList !== nextProps.groupContact.filteredDeviceContactList) {
            this.setState({ deviceContactList: nextProps.groupContact.filteredDeviceContactList });
        }

    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                {this._renderBodyGroupMgmt()}
                {this._renderButtonImport()}
                {this._renderLoadingView()}
            </View>
        );
    }

    _renderHeader() {
        let hideBackButton = this.props.hideBackButton;

        return (
            <View style={styles.headerView}>
                <View style={styles.subHeader}>

                    {hideBackButton ? null :
                        <TouchableOpacity style={styles.viewBackIcon}
                            onPress={this._onBackButton.bind(this)}>
                            <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                        </TouchableOpacity>
                    }

                    <View style={{ width: hideBackButton ? width - 55 : width - 80 }}>
                        <Text style={[styles.headerText, { marginLeft: hideBackButton ? 0 : 8 }]}>Danh bạ điện thoại</Text>
                    </View>

                </View>

                <View style={styles.subHeader2}>
                    <View style={styles.viewTextInput}>
                        <SearchInput ref="searchInput"
                            owner='Contacts'
                            placeholder="Tìm trong danh bạ"
                            placeholderTextColor={gui.arrowColor}
                            textValue={this.state.text}
                            searchContainer={{ marginRight: 0 }}
                            onChangeText={this._onChangeText.bind(this)}
                            onFocus={this._onFocus.bind(this)}
                            showCloseButton={this.state.focused && this.state.text != ''}
                            editable={true} />

                    </View>

                </View>

            </View>
        );

    }

    _renderButtonImport() {
        let totalFriendAdd = 0;
        this.state.deviceContactList.forEach((e) => {
            if (e.checked && e.canInvite)
                totalFriendAdd++;
        });

        totalFriendAdd = 'Tải ' + totalFriendAdd + ' danh bạ';
        return (
            <View style={styles.viewButtonInvite}>
                <TouchableOpacity
                    onPress={this._onImport.bind(this)}
                    style={styles.buttonInviteFriend}>
                    <Text style={styles.textButtonInvite}>{totalFriendAdd}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _onImport() {
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let checkedDeviceContactList = this.state.deviceContactList ? this.state.deviceContactList.filter((e) => e.checked && e.canInvite) : [];

        if (!checkedDeviceContactList || checkedDeviceContactList.length == 0) {
            Alert.alert(
                "Thông báo",
                "Tích chọn để tải liên hệ của bạn.",
                [{ text: 'Đóng', onPress: () => { } }])
            return;
        }

        let contacts = [];
        checkedDeviceContactList.forEach((e) => {
            let contactPhone = e.phoneNumbers && e.phoneNumbers.length > 0 ? utils.standardlizePhone(e.phoneNumbers[0].number) : '';
            contactPhone = contactPhone.replace(/\D/g, '')
            if (contactPhone.startsWith('84'))
                contactPhone = '0' + contactPhone.slice(2, contactPhone.length);
            let oneDto = {
                contactName: e.givenName
                    + (e.middleName ? (" " + e.middleName) : '')
                    + (e.familyName ? (" " + e.familyName) : ''),
                contactPhone: contactPhone,
                contactEmail: e.emailAddresses && e.emailAddresses.length > 0 ? e.emailAddresses[0].email : ''
            }

            // this._requestZaloInfo(oneDto.contactPhone);

            contacts.push(oneDto)
        })

        let importContactDto = {
            "userID": currentUser.userID || undefined,
            "contacts": contacts,
        };
        
        this.resetAgentWto();
        Actions.ContactImportDetail({ 
            contacts: contacts, 
            checkedDeviceContactList: checkedDeviceContactList,
            text: this.props.text, 
            request: this.props.request });        
    }


    resetAgentWto() {
        let defaultMua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        // this.setState({
        //     onModalPostAds: false
        // })
        this.props.actions.onNhuCauFieldChange("mua", defaultMua);
        this.props.actions.onNhuCauFieldChange("thue", defaultThue);
        this.props.actions.onNhuCauFieldChange("soTangSelectedIdx", 0);
        this.props.actions.onNhuCauFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onNhuCauFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onNhuCauFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onNhuCauFieldChange("huongNha", 0);
        this.props.actions.onNhuCauFieldChange("place", {});
        this.props.actions.onNhuCauFieldChange("ghiChu", '');
        this.props.actions.onNhuCauFieldChange('id', null);
        this.props.actions.onNhuCauFieldChange('priority', 'hot');
        this.props.actions.onNhuCauFieldChange('dateStart', null);
        this.props.actions.onNhuCauFieldChange('dateEnd', null);
    }

    _requestZaloInfo(phone) {
        const request = new XMLHttpRequest();
        // this._requests.push(request);
        request.timeout = this.props.timeout || 20000;
        request.ontimeout = () => console.warn('_requestZaloInfo: request timeout');
        request.onreadystatechange = () => {
            if (request.readyState !== 4) {
                return;
            }
            if (request.status === 200) {
                // this.setState({loading: false, dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([]))});
                const responseJSON = JSON.parse(request.responseText);
                log.info('_requestZaloInfo ******* respondJson', responseJSON)
                if (typeof responseJSON.predictions !== 'undefined') {
                    if (this.state.mounted) {
                        this._results = responseJSON.predictions;
                        let predictions = responseJSON.predictions;
                    }
                }
                if (typeof responseJSON.error_message !== 'undefined') {
                    log.warn('ContactImport _requestZaloInfo: ' + responseJSON.error_message);
                }
            } else {
                // console.warn("google places autocomplete: request could not be completed or has been aborted");
            }
        };
        this.setState({ loading: true });
        request.open('GET', cfg.rootUrl + "/zaloProfile?phone=" + encodeURI(phone));
        request.send();
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );
    }

    _onFocus() {
        !this.state.focused && this.setState({ focused: true });
    }

    _onChangeText(text) {

        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            text: text
        });
    }

    _request(text) {
        if (text.length > minLength) {
            this._requestContact(text);
        } else {
            // this.setState({ 'deviceContactList': [] });

            Contacts.requestPermission((err, permission) => {
                Contacts.getAll((err, contacts) => {
                    if (err === 'denied') {
                        // error
                    } else {
                                                
                        contacts = contacts.filter((e) => {return e.phoneNumbers && e.phoneNumbers.length>0})

                        //reupdate canInvite
                        contacts.forEach(e => {
                            e.checked = this.state.isCheckAll;

                            let contactInReducer = this.props.groupContact.allDeviceContactList.filter((f) => { return f.recordID == e.recordID })

                            if (contactInReducer && contactInReducer.length > 0) {
                                e.canInvite = contactInReducer[0].canInvite
                            }
                            else e.canInvite = true;
                        })

                        this.setState({ 'deviceContactList': contacts })
                        this.props.actions.onGroupContactFieldChange('allDeviceContactList', contacts)
                        this.props.actions.onGroupContactFieldChange('filteredDeviceContactList', contacts)
                    }
                })
            })
        }
    }

    _requestContact(text) {
        let searchContact = text || undefined;
        // this.setState({ 'deviceContactList': [] });

        Contacts.requestPermission((err, permission) => {
            Contacts.getContactsMatchingString(searchContact, (err, contacts) => {
                if (err === 'denied') {
                } else {
                    contacts = contacts.filter((e) => {return e.phoneNumbers && e.phoneNumbers.length>0})
                    contacts.forEach(e => {
                        e.checked = this.state.isCheckAll;
                        let contactInReducer = this.props.groupContact.filteredDeviceContactList.filter((f) => { return f.recordID == e.recordID })

                        if (contactInReducer && contactInReducer.length > 0) {
                            e.canInvite = contactInReducer[0].canInvite
                        }
                        else e.canInvite = true;
                    })

                    this.setState({ 'deviceContactList': contacts })
                    this.props.actions.onGroupContactFieldChange('filteredDeviceContactList', contacts)
                }
            })
        })
    }

    _onBackButton() {
        Actions.pop();
    }

    _renderBodyGroupMgmt() {
        return (
            <View style={styles.viewBody}>
                {this._renderRowView()}
            </View>
        );
    }


    _renderRowView() {
        let viewSanThamGia = [styles.viewSanThamGia];
        return (
            <View style={viewSanThamGia}>
                {this._renderHeaderContent()}
                {this._renderListAll()}
            </View>
        );
    }

    _renderListAll() {
        let listContact = this.state.deviceContactList;
        return this._renderContactList(listContact);
    }

    _renderContactList(listContact) {
        let dataContactList = listContact;
        return (
            <View style={styles.toDoView}>
                <FlatList
                    refreshControl={
                        <RefreshControl
                            refreshing={false}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                    data={dataContactList}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(item) => this._renderRowContact(item)}
                    //ListHeaderComponent={this._renderHeaderContent()}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={{ flex: 1 }}
                    contentContainerStyle={{ paddingBottom: 80 }}
                />
            </View>
        )
    }

    _renderHeaderContent() {
        let data = this.state.deviceContactList;
        return (
            <View style={{ width: width, height: 64 }}>
                <View style={styles.viewHeaderImport}>
                    <TouchableOpacity style={styles.touchCheckAll}
                        onPress={this.onCheckAll.bind(this)}
                    >
                        <Text style={styles.textCheckAll}>Chọn tất cả</Text>
                        <CheckBox
                            selected={this.state.isCheckAll}
                            onPress={this.onCheckAll.bind(this)} />
                    </TouchableOpacity>
                </View>
                <FullLine />
            </View>
        )
    }

    onCheckAll() {
        let currentList = this.state.deviceContactList;
        let currentCheckAll = this.state.isCheckAll;
        this.setState({
            isCheckAll: !currentCheckAll
        });
        currentList.map((e) => {
            e.checked = !currentCheckAll;
        });

        this.props.actions.onGroupContactFieldChange("filteredDeviceContactList", currentList);
        this.setState({ deviceContactList: currentList });
    }

    _onRefresh() {
        log.info('==============> dataContactList _onRefresh');
    }


    _renderRowContact(value, sectionID, rowID) {

        let data = value.item;
        let imgUrl = data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }
        let contactName = data.givenName
            + (data.middleName ? (" " + data.middleName) : '')
            + (data.familyName ? (" " + data.familyName) : '');
        return (
            <View style={{ flex: 1 }}>
                <TouchableOpacity onPress={this._onPressCheckBox.bind(this, data)}
                >
                    <View style={styles.viewToDoRow}>
                        <View style={[styles.dotView]}>
                            <Image
                                resizeMode={"cover"}
                                source={imageGroup}
                                defaultSource={defaultCover}
                                style={styles.adsCover} />
                        </View>
                        <View style={styles.viewNameContact}>
                            <Text style={styles.toDoContentText}>{contactName}</Text>
                        </View>
                        <View style={[styles.nameCellphone, { right: 65 }]}>
                            <MaterialCommunityIcons name={"cellphone-basic"} size={22} color={gui.mainTextColor} />
                        </View>
                        {this._renderImportButton(data)}
                    </View>
                </TouchableOpacity>
                <FullLine />
            </View>
        );
    }

    _renderImportButton(data) {

        if (data.canInvite)
            return (
                <View style={styles.nameCellphone}>
                    <CheckBox
                        selected={data.checked}
                        onPress={this._onPressCheckBox.bind(this, data)} />
                </View>
            )
        else return (
            <View style={styles.nameCellphone}>
                <Icon name="ban" size={18} color={gui.mainColor} />
            </View>
        )
    }

    _onPressCheckBox(data) {

        let currentList = this.state.deviceContactList;;
        currentList.map((e) => {
            if (e.recordID == data.recordID)
                e.checked = !e.checked;
        })

        this.props.actions.onGroupContactFieldChange("filteredDeviceContactList", currentList);
        this.setState({ deviceContactList: currentList });

    }

    // _onContactPress(data) {

    //     let contactName = data.givenName
    //         + (data.middleName ? (" " + data.middleName) : '')
    //         + (data.familyName ? (" " + data.familyName) : '');
    //     let phone = data.phoneNumbers && data.phoneNumbers.length > 0 ? data.phoneNumbers[0].number : ''
    //     let email = data.emailAddresses && data.emailAddresses.length > 0 ? data.emailAddresses[0].email : ''

    //     this.props.actions.onGroupContactFieldChange('contactID', null);
    //     this.props.actions.onGroupContactFieldChange('contactSource', 'device');
    //     this.props.actions.onGroupContactFieldChange('contactName', contactName);
    //     this.props.actions.onGroupContactFieldChange('contactPhone', phone);
    //     this.props.actions.onGroupContactFieldChange('contactEmail', email);
    //     this.props.actions.onGroupContactFieldChange('contactType', 1);
    //     this.props.actions.onGroupContactFieldChange('contactSaleState', 2);
    //     this.props.actions.onGroupContactFieldChange('contactPhotos', []);
    //     this.props.actions.onGroupContactFieldChange('recordID', null);
    //     this.props.actions.onGroupContactFieldChange('listContactNhucau', []);

    //     this._onSaveInitialContact();

    //     Actions.ModifyContact({ owner: 'ContactImport' });
    // }

    _onSaveInitialContact() {
        // local storage initialContact
        this.props.actions.onHelpedModalChange('initialContact', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialContact = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _renderLoadingView() {
        if (this.props.group.loadingContact) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewTextInput: {
        width: width - 32,
        height: 40,
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    viewBody: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewSanThamGia: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    toDoView: {
        flex: 1
    },
    viewNameContact: {
        height: 32,
        width: width - 40 - 90,
        justifyContent: 'center'
    },
    toDoContentText: {
        textAlign: 'left',
        marginLeft: 8,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '600',
        color: '#526173'
    },
    nameCellphone: {
        width: 32,
        height: 32,
        justifyContent: 'center',
        alignItems: 'flex-end',
        right: 16,
        position: 'absolute'
    },
    viewHeaderImport: {
        backgroundColor: '#fff',
        width: width,
        height: 63,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    touchCheckAll: {
        backgroundColor: '#fff',
        paddingVertical: 6,
        //paddingHorizontal: 8,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textCheckAll: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainAgentColor,
        marginRight: 8
    },
    viewToDoRow: {
        backgroundColor: '#FFFFFF',
        marginTop: 17,
        marginBottom: 15,
        width: width,
        height: 32,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotView: {
        width: 32,
        borderRadius: 16,
        height: 32,
        marginLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    headerView: {
        backgroundColor: '#fff',
        height: 118,
        width: width,
        borderBottomWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)'
    },
    subHeader: {
        backgroundColor: 'transparent',
        marginTop: 40,
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 24,
        flexDirection: 'row'
    },
    subHeader2: {
        backgroundColor: 'transparent',
        marginTop: 8,
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 40,
        flexDirection: 'row'
    },
    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    viewBackIcon: {
        height: 25,
        width: 25,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    adsCover: {
        width: 32,
        height: 32,
        marginLeft: 0,
        borderRadius: 16
    },
    textSapxep: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewButtonInvite: {
        width: width,
        height: 80,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        position: 'absolute',
        bottom: 0, //0
        borderTopWidth: 1,
        borderColor: '#dcdcdc'
    },
    buttonInviteFriend: {
        height: 48,
        width: width - 32,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    textButtonInvite: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#fff',
        fontSize: 15
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(ContactImport);