import React, { Component} from 'react';
import {
    Text,
    View,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    Image,
    ScrollView,
    Linking,
    WebView,
    PixelRatio
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import HTMLView from 'react-native-htmlview';

import DanhMuc from '../../assets/DanhMuc';
import FontAwesomeLight from '../font/FontAwesomeLight';
import utils from '../../lib/utils';
const {width, height} = utils.getDimensions();
import FullLine from '../line/FullLine'
import gui from "../../lib/gui";

let dataNews = {
    "address": "Tây Hồ, Hà Nội",
    "alias": "nong-cung-ngay-he-voi-khu-biet-thu-lien-ke-starlake-tay-ho-tay",
    "cate": "du-an",
    "content": "<div style=\"text-align: justify;\">\r\n\tKhu biệt thự liền kề Starlake Tây Hồ Tây là khu đô thị hoàn hảo từ không gian sống lí tưởng đến chất lượng cơ sở hạ tầng hiện đại, khu văn phòng chuyên nghiệp, khu mua sắm, vui chơi, giải trí sang trọng cho bạn và gia đình bạn. Đây là một trong những dự án bất động sản có chủ đầu tư nước ngoài Deawoo E&amp;C nên rất đáng để mong chờ và trải nghiệm trong ngày hè.</div>\r\n<div style=\"text-align: center;\">\r\n\t<img alt=\"Tổng quan dự án khu biệt thự starlake\" src=\"http://news.landber.com/uploads/images/du-an-biet-thu-lien-ke-starlake2.jpg\" style=\"width: 750px; height: 493px;\" /></div>\r\n<h2>\r\n\tNhững lợi thế “ có một không hai” của Starlake Tây Hồ Tây</h2>\r\n<div style=\"text-align: justify;\">\r\n\tVị trí vàng của khu biệt thự: Starlake Tây Hồ Tây là một trong những dự án hiếm hoi được thực hiện ở gần Hồ Tây, thuộc vị trí địa giới của 3 quận nội thành: Bắc Từ Liêm, Cầu Giấy và Tây Hồ. Đây là vị trí chiến lược được nhiều chuyên gia bất động sản đánh giá sẽ là tâm điểm chú ý, làm mưa, làm gió trên thị trường trong thời gian sắp tới. Đồng thời, nó cũng ảnh hưởng đến tiềm năng phát triển của khu đô thị Tây Hồ nhờ:<br />\r\n\t&nbsp;+ Khoảng cách lí tưởng của Starlake khi chỉ cách trung tâm thành phố 5km. Di chuyển thuận lợi đến Sân bay quốc tế Nội Bài, đến cầu Nhật Tân chỉ 14km. Giao thông đi lại trên các tuyến đường rất thuận tiện.<br />\r\n\t&nbsp;+ Là nơi kết nối với các trung tâm hành chính cấp cao như trụ sở của các Bộ ngành, khu ngoại giao. Hứa hẹn trở thành trung tâm hành chính mới của Hà Nội, cũng như là điểm đến của các sự kiện giao thương văn hóa, kinh tế của đất nước.<br />\r\n\t&nbsp;+ Chưa hết, theo các chuyên gia phong thủy thì vị trí của Starlake chính là huyệt phong thủy của Hà Nội, được bao bọc bởi núi lớn Tam Đảo và Ba Vì. Thế nên, dự án là nơi linh khí hội tụ, mang lại cuộc sống mạnh khỏe, tài vượng cho chủ sở hữu.</div>\r\n<div style=\"text-align: center;\">\r\n\t<img alt=\"vị trí vàng của starlake\" src=\"http://news.landber.com/uploads/images/du-an-biet-thu-lien-ke-starlake1.jpg\" style=\"width: 650px; height: 447px;\" /></div>\r\n<h2 style=\"text-align: justify;\">\r\n\tKhám phá phong cách thiết kế chủ đạo của Starlake</h2>\r\n<div style=\"text-align: justify;\">\r\n\tVới lợi thế vượt trội về vị trí phong thủy, cùng với tổng diện tích khá rộng 11.6 ha với 207 căn hộ biệt thự chủ đầu tư đã thỏa sức sáng tạo hệ thống sản phẩm thiết kế hoàn hảo theo phong cách hiện đại, sang trọng, phù hợp với khách hàng.<br />\r\n\t<br />\r\n\t<em><strong>Xem thêm:</strong></em></div>\r\n<ul>\r\n\t<li style=\"text-align: justify;\">\r\n\t\t<a href=\"https://landber.com/chi-tiet-tin/ven-man-suc-hap-dan-cua-khu-do-thi-sinh-thai-xuan-phuong-tasco.html\">Vén màn sức hấp dẫn của khu đô thị sinh thái Xuân Phương Tasco</a></li>\r\n\t<li style=\"text-align: justify;\">\r\n\t\t<a href=\"https://landber.com/chi-tiet-tin/gia-tri-song-duoc-tao-boi-chung-cu-green-tower-sai-dong.html\">Giá trị sống được tạo bởi chung cư Green Tower Sài Đồng</a></li>\r\n</ul>\r\n<div style=\"text-align: justify;\">\r\n\t<br />\r\n\tĐiểm nhấn nổi bật trong thiết kế khu biệt thự liền kề đẳng cấp Starlake là thiết kế không gian mở, hòa quyện với thiên nhiên tạo nên phong cách sống hiện đại, độc đáo, quý tộc. Starlake sẽ là viên ngọc nằm trong lòng thủ đô để bạn và gia đình có thể thư giãn và trải nghiệm không gian sống thời thượng, vương giả, khiến bạn có thể hãnh diện.</div>\r\n<div style=\"text-align: center;\">\r\n\t<img alt=\"Không gian mở của starlake\" src=\"http://news.landber.com/uploads/images/du-an-biet-thu-lien-ke-starlake3.jpg\" style=\"width: 750px; height: 529px;\" /></div>\r\n",
    "createdtime": "1 năm trước",
    "dateTimeCreated": 1496912814,
    "description": "<div style=\"text-align: justify;\">\r\n\tKhu biệt thự liền kề Starlake Tây Hồ Tây là khu đô thị hoàn hảo từ không gian sống lí tưởng đến chất lượng cơ sở hạ tầng hiện đại, khu văn phòng chuyên nghiệp, khu mua sắm, vui chơi, giải trí sang trọng cho bạn và gia đình bạn. Đây là một trong những dự án bất động sản có chủ đầu tư nước ngoài Deawoo E&amp;C nên rất đáng để mong chờ và trải nghiệm trong ngày hè.</div>\r\n",
    "focus_box": null,
    "id": "News_101",
    "image": "https://news.landber.com/upload/post/101/w600_hauto_du-an-biet-thu-lien-ke-starlake3jpg.jpg",
    "meta_desc": "Khu biệt thự liền kề Starlake Tây Hồ Tây là khu đô thị hoàn hảo từ không gian sống lí tưởng đến chất lượng cơ sở hạ tầng hiện đại, khu văn phòng chuyên nghiệp, khu mua sắm, vui chơi, giải trí sang trọng cho bạn và gia đình bạn.",
    "meta_keyword": "biệt thự liền kề, Starlake Tây Hồ Tây, Biệt thự liền kề sang trọng, biệt thự liền kề đẳng cấp",
    "newsType": "news",
    "other_cate": "du-an,biet-thu-lien-ke",
    "parent_cate": "",
    "price": "Đang cập nhật",
    "title": "Nóng cùng ngày hè với khu biệt thự liền kề STARLAKE Tây Hồ Tây",
    "type": "News",
    "url": "http://news.landber.com/du-an/nong-cung-ngay-he-voi-khu-biet-thu-lien-ke-starlake-tay-ho-tay.html"
};

const IMAGES_MAX_WIDTH = width - 32;
const CUSTOM_STYLES = {};
const CUSTOM_RENDERERS = {};
const DEFAULT_PROPS = {
    htmlStyles: CUSTOM_STYLES,
    renderers: CUSTOM_RENDERERS,
    imagesMaxWidth: IMAGES_MAX_WIDTH,
    onLinkPress: (evt, href) => { Linking.openURL(href); },
    debug: true
}

class NewsDetail extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data
        }
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                <FullLine/>
                {this._renderListDetail()}
            </View>
        )
    }

    _renderHeader() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontSize: 17}]}>Tin tức</Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    renderNode(node, index, siblings, parent, defaultRenderer) {
        if (node.name == 'img') {
            const { src, height } = node.attribs;
            let style = node.attribs.style && node.attribs.style.split(';');
            let imageWidth = width - 32;
            let imageHeight = 320;
            if (style && style.length >= 2) {
                let one = style.find((e) => e.indexOf('width') >= 0);
                if (one) {
                    imageWidth = Number(one.split(':')[1].replace('px','').replace('%',''));
                }
                one = style.find((e) => e.indexOf('height') >= 0);
                if (one) {
                    imageHeight = Number(one.split(':')[1].replace('px','').replace('%',''));
                }
            }
            let ratio = (width - 32)/imageWidth;
            if (ratio < 1) {
                imageWidth = width - 32;
                imageHeight = ratio * imageHeight;
            }
            return (
                <View style={{alignItems: 'center',
                    width: width - 32,
                    height: imageHeight + 20,
                    paddingVertical: 10}}
                    key={index}
                >
                    <Image
                        key={index}
                        style={{ width: imageWidth, height: imageHeight}}
                        source={{ uri: src }}
                        resizeMode={'contain'}
                    />
                </View>
            );
        }
    }

    _renderListDetail() {
        let data = this.state.data;
        const htmlContent = data && data.content.replace(/(\t|\r\n|\n|\r)/g, '')
        .replaceAll("<li", "\r\n<li");
        return(
            <ScrollView style={{ flex: 1 }}>
                {this.renderTopContent(data)}
                <View style={styles.viewWrapHtml}>
                    {/*<HTML*/}
                        {/*{...DEFAULT_PROPS}*/}
                        {/*html={htmlContent}*/}
                        {/*imagesMaxWidth={ width - 32}*/}
                        {/*staticContentMaxWidth={ width - 32}*/}
                        {/*ignoredStyles={['font-weight', 'display', 'font-family']}*/}
                    {/*/>*/}
                    {/*<WebView*/}
                        {/*source={{uri: data.url}}*/}
                        {/*style={{width: width, height: height-64, top: -112}}*/}
                        {/*automaticallyAdjustContentInsets={false}*/}
                        {/*javaScriptEnabled={true}*/}
                        {/*domStorageEnabled={true}*/}
                        {/*decelerationRate="normal"*/}
                        {/*startInLoadingState={true}*/}
                        {/*scalesPageToFit={true}*/}
                    {/*/>*/}
                    <HTMLView
                        value={htmlContent}
                        stylesheet={styles}
                        paragraphBreak={null}
                        lineBreak={null}
                        addLineBreaks={false}
                        bullet={null}
                        textComponentProps={ styles }
                        renderNode={this.renderNode}
                        nodeComponentProps={styles}
                    />
                </View>
            </ScrollView>
        )
    }

    renderTopContent(data) {
        let category = DanhMuc.allCategoryName[data.parent_cate || data.cate];
        let newsTitle = data.title;
        let timeStamp = data.createdtime;
        return(
            <View style={styles.viewTitle}>
                <Text style={styles.textTitleNews}>{newsTitle}</Text>
                <View style={styles.viewTimeStamp}>
                    <View style={styles.sourceNews}>
                        <FontAwesomeLight name="user-alt"
                                          size={14}
                                          color={gui.textShare}
                                          noAction={true}
                                          iconOnly={true}
                                          mainProps={{marginBottom: 4}}/>
                        <Text style={styles.textTime}>{category}</Text>
                    </View>
                    <View style={{flexDirection:'row', justifyContent:'center', alignItems:'center'}}>
                        <FontAwesomeLight name="clock"
                                        size={14}
                                        color={gui.textShare}
                                        noAction={true}
                                        iconOnly={true}
                                        mainProps={{marginBottom: 3}} />
                        <Text style={styles.textTime}>{timeStamp}</Text>
                    </View>
                </View>
            </View>
        )
    }


    _onBackPress() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        paddingLeft: 16,
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewListNews: {
        flex: 1
    },
    viewRowNews: {
        height: 80,
        width: width - 32,
        marginTop: 16,
        marginBottom: 4,
        marginLeft: 16,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    textTitle: {
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    viewTimeStamp: {
        flexDirection: 'row',
        height: 20,
        width: width - 32,
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        marginTop: 6
    },
    sourceNews: {
        flexDirection: 'row',
        height: 20,
        // width: 100,
        flex: 1,
        alignItems: 'flex-end'
    },
    textTime: {
        fontSize: 15,
        fontFamily:gui.fontFamily,
        color: gui.textShare,
        fontWeight: '300',
        marginLeft: 5
    },
    viewTitle: {
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginTop: 16
    },
    textTitleNews: {
        fontSize: 20,
        fontFamily:gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '600'
    },
    viewWrapHtml: {
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginRight: 16,
        marginTop: 16,
        overflow: 'hidden'
    },
    // span: {
    //     fontWeight: '300',
    //     color: gui.textPostAds,
    //     fontFamily:gui.fontFamily
    // },
    // p: {
    //     fontWeight: '300',
    //     color: gui.textPostAds,
    //     fontFamily:gui.fontFamily
    // },
    // a: {
    //     fontWeight: '300',
    //     color: gui.mainColor, // make links coloured pink
    // },
    img: {
        width: width - 32,
        height: 'auto', // make links coloured pink
        marginTop: 5,
        marginBottom: 5
    },
    p: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        fontSize: 17,
        // textAlign: 'justify'
    },
    // span: {
    //     textAlign: 'justify'
    // },
    // strong: {
    //     textInden: 'justify'
    // },
    ul: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        fontSize: 17,
    },
    ol: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        fontSize: 17,
    },
    em : {
        marginTop: 5,
        marginBottom: 5,
        fontSize: 17,
        fontFamily:gui.fontFamily
    },
    span: {
        fontSize: 17,
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        // textAlign: 'justify'
    },
    a: {
        marginTop: 5,
        marginBottom: 5,
        fontFamily:gui.fontFamily,
        color: gui.mainColor,
        fontSize: 17,
    },
    strong: {
        fontFamily:gui.fontFamily,
        textAlign: 'justify',
        fontSize: 17,
    },
    h2: {
        fontSize: 17,
        fontFamily:gui.fontFamily
    },
    div: {
        fontSize: 17,
        fontFamily:gui.fontFamily
    }
    // style: { textAlign:'justify'}
});

export default NewsDetail;