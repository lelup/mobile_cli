import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ListView,
    TextInput
} from 'react-native';

import FontAwesomeSolid from '../font/FontAwesomeSolid';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
let {width, height} = utils.getDimensions();

class GroupSearchHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            laoding: false,
        }
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderHeader()}
            </View>
        );
    }

    _renderHeader() {
        return(
            <View style={styles.viewHeaderContent}>
                <TouchableOpacity
                    accessible={true}
                    onPress={() => {this.props.onGroupSearchPress && this.props.onGroupSearchPress()}}
                >
                    <View style={styles.viewSearchContent}>
                        <View style={styles.viewIconSearch}>
                            <FontAwesomeLight name="search" size={15} color={gui.colorMainBlur} noAction={true} iconOnly={true} />
                        </View>
                        <View
                            style={styles.viewInputSearch}
                            onStartShouldSetResponder={(evt) => false}
                            onMoveShouldSetResponder={(evt) => false}
                            pointerEvents="none">
                            <TextInput
                                autoFocus={false}
                                autoCorrect={false}
                                returnKeyType='done'
                                underlineColorAndroid='rgba(0,0,0,0)'
                                style={styles.viewTextInput}
                                placeholder="Tìm kiếm sàn BĐS"
                                onChangeText={this.props.onChangeText}
                                placeholderTextColor={gui.colorMainBlur}
                                value={this.props.value}
                                editable={false}
                            />
                        </View>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.viewPlusSearch}
                                  onPress={this.props.onPressChat}>
                    <FontAwesomeSolid name="comment-dots" size={24} color={gui.mainColor} noAction={true} iconOnly={true} />
                    {this.props.numberInbox ?
                        <View style={styles.numberOfMessage2}>
                            <Text style={styles.numberInbox}>{this.props.numberInbox}</Text>
                        </View>
                        : null
                    }
                </TouchableOpacity>
            </View>
        );
    }

}

const styles =  StyleSheet.create({
    container: {
        backgroundColor: '#fff'
    },
    viewHeaderContent: {
        marginTop: gui.marginTopAgent,
        height: 48,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        // paddingLeft: 10,
        // paddingRight: 21
    },
    viewIconSearch: {
        // height: 48,
        width: 30,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewPlusSearch: {
        height: 48,
        width: 46,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 5
    },
    viewInputSearch: {
        height: 48,
        // width: width - 98,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        backgroundColor:'transparent',
        // width: width - 78,
        // height: 46,
        paddingLeft: 6,
        color: gui.mainTextColor
    },
    viewSearchContent: {
        flexDirection: 'row',
        width: width - 70,
        height: 36,
        marginTop: 10,
        marginBottom: 10,
        backgroundColor: gui.groupBackground,
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 16
    },
    numberOfMessage2: {
        height: 16,
        width: 16,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 9,
        right: 8,
        backgroundColor: '#ff0000'
    },
    numberInbox: {
        fontSize: 8,
        color: '#fff',
        backgroundColor: 'transparent'
    },
});

export default GroupSearchHeader;