import React, { Component } from 'react';
import {
    Text,
    View,
    Image,
    StyleSheet,
    TouchableOpacity,
    FlatList,
    ListView,
    ScrollView,
    Keyboard,
    Alert,
    TextInput,
    RefreshControl,
    TouchableHighlight
} from 'react-native';
import { Actions } from 'react-native-router-flux';

import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import TextInputAuto from '../postAds/TextInputAuto';
import FullLine from '../line/FullLine';
import RelandIcon from '../RelandIcon';
import Modal from 'react-native-modalbox';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();
import Toast, { DURATION } from '../toast/Toast';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import moment from 'moment'
import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';
let ds_listNote = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class ContactNote extends Component {
    constructor(props) {
        super(props);
        this.state = {
            noteID: '',
            notes: '',
            namePostLine: false,
            isEditable: false,
            textFocus: false,
            isOpenModalGhiChu: false,
            contactNoteList: props.group.contactNoteList
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.group.contactNoteList !== this.props.group.contactNoteList) {
            this.setState({ contactNoteList: nextProps.group.contactNoteList });
        }
    }

    render() {
        let listNote = this.state.contactNoteList
        let data = ds_listNote.cloneWithRows(listNote);
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                <View style={styles.viewBodyAlert}>
                    <SwipeListView
                        refreshControl={
                            <RefreshControl
                                refreshing={false}
                                onRefresh={this._onRefresh.bind(this)}
                            />
                        }
                        ref={ref => this._swipeListView = ref}
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        enableEmptySections={true}
                        dataSource={data}
                        // renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, (rowID == 0), (rowID == (listNote.length - 1)), listNote.length)}
                        style={styles.listView}
                        contentContainerStyle={{ backgroundColor: gui.newLineFacebook }}
                        renderRow={(rowData, sectionID, rowID, rowMap) =>
                            (
                                <SwipeRow
                                    disableRightSwipe={true}
                                    disableLeftSwipe={false}
                                    rightOpenValue={-134}
                                >
                                    <View style={[styles.rowBack, {
                                        alignItems: (rowID == 0) ? 'flex-start' : (rowID == (listNote.length - 1)) ? 'flex-start' : 'center'
                                    }]}>

                                        <TouchableOpacity onPress={() => {rowMap[`${sectionID}${rowID}`].closeRow(); this._onEdit(rowData)}}
                                            style={[styles.viewDeleteInbox, { backgroundColor: 'rgba(146,141,147,1)' }]}
                                        >
                                            {this.props.me.loadingDeleteMyNotify ?
                                                <View><GiftedSpinner color="#fff" /></View> :
                                                (<View>
                                                    <Text style={[styles.saveText, { marginBottom: 6 }]}>Sửa</Text>
                                                    <FontAwesomeLight
                                                        name="edit"
                                                        size={16}
                                                        color={'#fff'}
                                                        noAction={true}
                                                        iconOnly={true}
                                                    />
                                                </View>)

                                            }
                                        </TouchableOpacity>

                                        <TouchableOpacity onPress={() => {rowMap[`${sectionID}${rowID}`].closeRow(); this._onDelete(rowData)}}
                                            style={[styles.viewDeleteInbox]}
                                        >
                                            {this.props.me.loadingDeleteMyNotify ?
                                                <View><GiftedSpinner color="#fff" /></View> :
                                                (<View>
                                                    <Text style={[styles.saveText, { marginBottom: 6 }]}>Xóa</Text>
                                                    <FontAwesomeLight
                                                        name="trash-alt"
                                                        size={16}
                                                        color={'#fff'}
                                                        noAction={true}
                                                        iconOnly={true}
                                                    />
                                                </View>)
                                            }
                                        </TouchableOpacity>
                                    </View>

                                    {this._renderRow(rowData, (rowID == 0), (rowID == (listNote.length - 1)), listNote.length)}
                                </SwipeRow>
                            )}
                        disableRightSwipe={true}
                        rightOpenValue={-134}
                        swipeRowStyle={{ marginBottom: 1 }}
                    />
                </View>


                {this._openModalGhiChu()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    }

    _renderRow(data) {
        let timeModified = data && data.timeModified ? moment(data.timeModified).format('DD/MM hh:mm') : '';

        return (
            <View>
                <TouchableHighlight
                    underlayColor="rgba(255,255,255,1)"
                    onPress={() => this._onViewDetail(data)} style={styles.viewRowNote}>
                    <View style={{ height: 56, width: width - 32, backgroundColor: '#FFFFFF', }}>
                        <Text numberOfLines={2} style={styles.textCommon}>{data.content}</Text>
                        <Text style={[styles.textCommon, { color: 'rgba(111,111,111,1)' }]}>{timeModified}</Text>
                    </View>
                </TouchableHighlight>
                <FullLine />
            </View>
            
        );
    }

    _onRefresh() { }

    _onEdit(data) {
        // this.setState({ noteID:data.id, notes: data.content, isOpenModalGhiChu: true })
        Actions.ContactNoteDetail({ action: 'edit', noteID: data.id, notes: data.content });
    }

    _onViewDetail(data) {
        // this.setState({ noteID:data.id, notes: data.content, isOpenModalGhiChu: true })
        Actions.ContactNoteDetail({ action: 'view', noteID: data.id, notes: data.content });
    }

    _onDelete(data) {
        let token = this.props.global.currentUser.token;
        let dto = {
            id: data.id,
            userID: this.props.global.currentUser.userID
        }

        this.props.actions.deleteContactNote(dto, token)
            .then(res => {
                let userID = this.props.global.currentUser.userID || undefined;
                let token = this.props.global.currentUser.token || undefined;

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                        }
                    }]);
                } else {
                    //clear input
                    // this.setState({ noteID:'', notes: '', isOpenModalGhiChu: false })
                    Keyboard.dismiss();

                    this.refs.toastTop && this.refs.toastTop.show(
                        "Xoá dữ liệu thành công!", DURATION.LENGTH_LONG);

                    this.props.actions.getContactNote(
                        {
                            'userID': this.props.global.currentUser.userID,
                            'contactID': this.props.groupContact.selectedContact.contactID,
                        }
                        , (res) => {
                        }
                        , (error) => {
                        });
                }
            });

    }

    _renderHeader() {
        return (
            <View>
                <TouchableOpacity onPress={this._themGhiChu.bind(this)} style={styles.touchAdd}>
                    <MaterialCommunityIcons name={'plus'} size={16} color={gui.mainAgentColor} />
                    <Text style={styles.textThemNha}>Thêm ghi chú</Text>
                </TouchableOpacity >
                <FullLine style={{ marginLeft: 6, marginRight: 6, marginBottom: 0 }} />
            </View>
        )
    }

    _themGhiChu() {
        // this._onModalGhiChu()
        Actions.ContactNoteDetail({ action: 'edit' });
    }

    _onModalGhiChu() {
        this.setState({ isOpenModalGhiChu: true });
    }

    _onContentModal() {
        this.setState({
            isOpenModalGhiChu: false
        });
    }

    _openModalGhiChu() {
        return (
            <Modal isOpen={this.state.isOpenModalGhiChu}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle2}
                position={"top"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                {this._renderGhiChuContent()}
            </Modal>
        );

    }

    _renderGhiChuContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={{ marginTop: 18, marginLeft: 17, width: width - 64, flex: 1 }}>
                    <TextInput
                        autoFocus={false}
                        autoCapitalize='none'
                        autoCorrect={false}
                        returnKeyType='done'
                        multiline={true}
                        //underlineColorAndroid='rgba(0,0,0,0)'
                        style={styles.viewTextInput2}
                        placeholder="Nhập ghi chú cho liên hệ…" placeholderTextColor={gui.arrowColor}
                        onChangeText={(text) => { this._onNoteChange(text) }}
                        value={this.state.notes}

                    />
                </View>
                {this._renderButtonSave()}
            </View>
        )
    }

    _onNoteChange(value) {
        this.setState({
            notes: value
        })
    }

    _renderButtonSave() {
        if (this.props.group.requestingJoin)
            return (<View style={styles.searchButtonView}>
                <View
                    style={styles.searchButton}
                >
                    <Text style={styles.searchButtonText}>LƯU</Text>
                </View>
            </View>)
        return (
            <View style={styles.searchButtonView}>
                <TouchableOpacity
                    style={styles.searchButton}
                    onPress={this.onSaveNote.bind(this)}
                >
                    <Text style={styles.searchButtonText}>LƯU</Text>
                </TouchableOpacity>
            </View>
        )
    }

    onSaveNote() {
        if (!this.state.notes.trim())
            return

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let contactDto = {
            "contactID": this.props.groupContact.selectedContact.contactID,
            "userID": currentUser.userID,
            "content": this.state.notes,
            "id": this.state.noteID
        }

        this.props.actions.saveContactNote(contactDto, token)
            .then(res => {
                let userID = this.props.global.currentUser.userID || undefined;
                let token = this.props.global.currentUser.token || undefined;

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                            this.setState({ noteID: '', notes: '', isOpenModalGhiChu: false })
                            Keyboard.dismiss();
                        }
                    }]);
                } else {
                    //clear input
                    this.setState({ noteID: '', notes: '', isOpenModalGhiChu: false })
                    Keyboard.dismiss();

                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);

                    this.props.actions.getContactNote(
                        {
                            'userID': this.props.global.currentUser.userID,
                            'contactID': this.props.groupContact.selectedContact.contactID,
                        }
                        , (res) => {
                        }
                        , (error) => {
                        });
                }
            });
    }

    _renderTextInput() {
        let borderColor = this.state.namePostLine ? gui.mainTextColor : 'lightgray';
        let border = this.state.namePostLine ? 1 : 0.5;
        return (
            <View style={styles.viewInputNote}>
                <TextInputAuto
                    onBlur={() => this.onBlurNamePost()}
                    onFocus={() => this.onFocusNamePost()}
                    placeholder="Nhập ghi chú"
                    keyboardType="twitter"
                    placeholderTextColor={gui.colorMainBlur}
                    style={styles.viewTextInput}
                    // autoFocus={false}
                    autoCorrect={false}
                    underlineColorAndroid='rgba(0,0,0,0)'
                    onChangeText={(value) => this._onNoteChange(value)}
                    value={this.state.notes}
                    maxLength={1000}
                    editable={this.state.isEditable}
                    ref="ghiChuText"
                />
                <FullLine style={[styles.lineStyle, { borderColor: borderColor, borderTopWidth: border }]} />
            </View>
        )
    }


    enableEdit() {
        this.setState({ isEditable: true, textFocus: true })
        setTimeout(() => { this.refs.ghiChuText._requestFocus() }, 300)
    }

    _onDoneNotePress() {

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let contactDto = {
            "contactID": this.props.groupContact.selectedContact.contactID,
            "ghiChu": this.state.notes
        }

        this.props.actions.updateGhiChuContact(contactDto, token)
            .then(res => {
                let userID = this.props.global.currentUser.userID || undefined;
                let token = this.props.global.currentUser.token || undefined;

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                            this.setState({ isEditable: false, textFocus: false })
                            Keyboard.dismiss();
                        }
                    }]);
                } else {
                    //clear input
                    this.setState({ isEditable: false, textFocus: false })
                    Keyboard.dismiss();

                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);
                }
            });
    }


    onFocusNamePost() {
        this.setState({
            namePostLine: true
        })
    }

    onBlurNamePost() {
        this.setState({
            namePostLine: false
        })
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewInputNote: {
        marginTop: 10,
        height: 80,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        backgroundColor: '#fff',
        width: width - 32,
        color: gui.mainTextColor
    },
    lineStyle: {
        marginTop: 11
    },
    viewButtonNote: {
        marginTop: 20,
        height: 30,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row'
    },
    textDoneNote: {
        fontSize: 17,
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    touchNoteDone: {
        paddingVertical: 8,
        paddingHorizontal: 11,
        backgroundColor: gui.mainTextColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 3,
        marginLeft: 5
    },
    touchAdd: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textThemNha: {
        fontSize: 15,
        color: gui.mainColor,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewModalStyle2: {
        justifyContent: 'center',
        height: 210,
        width: width - 30,
        marginVertical: 16,
        // paddingVertical: 50,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 48,
        bottom: 17,
        width: width,
        backgroundColor: 'transparent',
        //borderRadius: 24
    },
    searchButton: {
        height: 48,
        width: width - 64,
        backgroundColor: gui.mainColor,
        borderRadius: 24,
        alignItems: 'center',
        justifyContent: 'center'
    },
    scrollView: {
        backgroundColor: gui.groupBackground,
        paddingBottom: 50,
        justifyContent: 'flex-start',
        alignItems: 'stretch',
    },

    searchButtonText: {
        color: '#FFFFFFFF',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    viewTextInput2: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        width: width - 32
    },
    viewBodyAlert: {
        flex: 1,
        flexDirection: 'column',
    },
    listView: {
        paddingTop: 0,
        backgroundColor: 'white',
        borderColor: '#e6e6e6',
        borderBottomWidth: 0,
    },
    rowBack: {
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingLeft: 0,
    },
    viewDeleteInbox: {
        right: 0,
        width: 67,
        backgroundColor: 'rgba(254,57,53,1)',
        height: 55,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewRowNote: {
        height: 56,
        width: width,
        justifyContent: 'center',
        paddingLeft: 12,
        backgroundColor: '#fff'
    },
    textCommon: {
        color: gui.textPostAds,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    saveText: {
        fontSize: 13,
        fontFamily: gui.fontFamily,
        color: "#fff",
        textAlign: 'center',
    },
});


export default connect(mapStateToProps, mapDispatchToProps)(ContactNote);