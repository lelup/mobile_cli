import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    FlatList,
    RefreshControl
} from 'react-native';

import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();
import GroupDetail from './GroupDetail';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupDetail2 extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <GroupDetail {...this.props} />
        );
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(GroupDetail2);