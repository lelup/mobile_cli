import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    TouchableHighlight,
    StyleSheet,
    ScrollView,
    StatusBar,
    ImageBackground,
    TextInput,
    ListView,
    PanResponder,
    Easing,
    SegmentedControlIOS,
    Alert
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Actions } from 'react-native-router-flux';

import Modal from 'react-native-modalbox';

import GroupPlacesAutoComplete from './GroupPlacesAutoComplete';

import GroupWToFilter from './GroupWToFilter';

import ScalableText from 'react-native-text';

import GiftedSpinner from "../GiftedSpinner";

var FlipView = require('../flip/FlipView');

import MMessage from '../message/MMessage';
import OfflineBar from '../line/OfflineBar';
var Analytics = require('react-native-firebase-analytics');

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';
import FontAwesomeLight from '../font/FontAwesomeLight';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();

import DanhMuc from '../../assets/DanhMuc';

import RangeUtils from "../../lib/RangeUtils";

import apiUtils from '../../lib/ApiUtils';

import CommonUtils from '../../lib/CommonUtils';

import findApi from '../../lib/FindApi';

var imageHeight = 143;

import Tag from './Tag';

import moment from 'moment';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as groupActions from '../../reducers/group/groupActions';

import { Map } from 'immutable';

const actions = [
    globalActions,
    authActions,
    searchActions,
    groupSearchActions,
    postAdsActions,
    adsMgmtActions,
    groupActions
];

function mapStateToProps(state) {
    let currentUser = state.global.currentUser;
    let maxAdsInMapView = state.global.setting.maxAdsInMapView;
    let diaChinh = state.groupSearch.wtoForm.fields.diaChinh;
    return {
        ...state,
        wtoList: state.groupSearch.result.listWTo,
        loading: state.groupSearch.loadingFromServer,
        errorMsg: state.groupSearch.result.errorMsg,
        adsLikes: currentUser && currentUser.adsLikes,
        loggedIn: state.global.loggedIn,
        userID: currentUser && currentUser.userID,
        deviceID: state.global.deviceInfo.deviceID,
        token: currentUser && currentUser.token,
        fields: state.groupSearch.wtoForm.fields,
        totalCount: state.groupSearch.result.totalCount,
        polygons: state.groupSearch.map.polygons,
        listScrollPos: state.groupSearch.listScrollPos,
        limit: maxAdsInMapView,
        uploadingLikedAds: state.search.uploadingLikedAds,
        //******* DIFF MAP *******//
        diaChinhFullName: diaChinh && diaChinh.fullName,
        maxAdsInMapView: maxAdsInMapView,
        //******* DIFF MAP END *******//
        // recentSearchList: recentSearchList,
        searchView: state.groupSearch.searchView,
        currentUser: currentUser
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let imageGroup = 168;

let ds_filterGroup = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

const ASPECT_RATIO = width / (height - 168);

const LATITUDE = 15.91246021276861;
const LONGITUDE = 105.7527299557314;
const LATITUDE_DELTA = 15.43258937437489;
const MIN_LATITUDE = 5.196165;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

const delayDuration = 500;

class GroupFilterResult extends Component {

    constructor(props) {
        super(props);

        this.editing = null;

        let { loaiTin, ngayDaDang, huongNha, dienTich, mua, thue } = this.props.groupSearch.wtoForm.fields;

        let { initDienTich, fromDienTich, toDienTich } = this._initDienTich(dienTich);

        let { initGia, fromGia, toGia } = this._initGia(loaiTin, this.props.groupSearch.wtoForm.fields[loaiTin].gia);

        this.state = {
            firstTime: true,
            textMessage: '',
            isSuggestionFlipped: false,
            msgType: '',
            sorting: false,
            onHelpFilter: false,
            onFilterComplete: !props.global.help.mapFilterHelped,

            //******* MAP **********//
            modal: false,
            isOpenModalSapxep: false,
            isOpenModalLoaiTin: false,
            isOpenModalLoaiNhaDat: false,
            isOpenModalMucGia: false,
            isOpenModalDienTich: false,
            // pageNo: 1,
            mounting: true,
            searchTime: moment().toDate().getTime(),
            searchFilter2Actived: false,

            showNgayDaDang: false,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            initNgayDaDang: ngayDaDang,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            inputNgayDaDang: ngayDaDang,
            toggleState: false,
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            huongNha: huongNha,
            ngayDaDang: ngayDaDang
        };
    }

    _initDienTich(dienTich) {
        let initDienTich = [];
        Object.assign(initDienTich, dienTich);
        let dienTichVal = RangeUtils.dienTichRange.toValRange(initDienTich);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        return { initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich };
    }

    _initGia(loaiTin, gia) {
        let initGia = [];
        Object.assign(initGia, gia);
        let giaStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(initGia);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if (DanhMuc.loaiTinFilter.mua === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if (DanhMuc.loaiTinFilter.mua === loaiTin) {
            toGia = toGia / 1000;
        }
        return { initGia: initGia, fromGia: fromGia, toGia: toGia };
    }

    componentWillReceiveProps(nextProps) {
        // if (nextProps.wtoList !== this.props.wtoList) {
        //     this._onShowMessage();
        // }
        if (nextProps.global.help.mapFilterHelped !== this.props.global.help.mapFilterHelped) {
            this.setState({ onFilterComplete: !nextProps.global.help.mapFilterHelped })
        }
    }

    componentWillMount() {
        setTimeout(this._initWToList.bind(this), 300);
    }

    _initWToList() {
        let myProps = this.props;
        // if (myProps.listAds.length > 0) {
        //     return;
        // }
        let { diaChinh } = myProps.fields;
        let fields = utils.cloneRecord(myProps.fields);
        fields.limit = myProps.global.setting.maxAdsInMapView;
        fields.isIncludeCountInResponse = true;

        //TODO: need to verify logic of updating last search
        if (myProps.global.currentUser && myProps.global.currentUser.userID) {
            fields.userID = myProps.global.currentUser.userID;
        }
        fields.updateLastSearch = diaChinh && diaChinh.tinhKhongDau && diaChinh.tinhKhongDau != '';

        // for counting active device
        if (myProps.global.deviceInfo && myProps.global.deviceInfo.deviceID) {
            fields.deviceID = myProps.global.deviceInfo.deviceID;
        }

        fields.groupID = myProps.groupID;

        myProps.actions.wtoSearch(
            fields
            , () => { this.setState({mounting: false}) }
            , (error) => { this.setState({mounting: false}) });
    }

    _getNumberOfWTo() {
        let { wtoList } = this.props;
        return wtoList && wtoList.length;
    }

    _refreshListData(newViewport, refreshCallback, excludeCount, newDiaChinh, newPageNo, isAppend) {
        log.info("Call GroupFilterResult._refreshListData");
        var {
            viewport, diaChinh, pageNo
        } = this.props.groupSearch.wtoForm.fields;
        let limit = this.props.maxAdsInMapView;
        var isHavingCount = !excludeCount;

        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.viewport = newViewport || viewport;
        fields.diaChinh = newDiaChinh || diaChinh;
        fields.pageNo = !isAppend ? 1 : newPageNo || pageNo;
        fields.limit = limit;
        fields.isIncludeCountInResponse = isHavingCount;

        // add userID, deviceID for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            fields.userID = this.props.global.currentUser.userID;
        }

        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            fields.deviceID = this.props.global.deviceInfo.deviceID;
        }

        var ms = moment().toDate().getTime();
        var previousSearchTime = this.state.searchTime;
        this.setState({ searchTime: ms });
        if (ms - previousSearchTime > delayDuration) {
            fields.updateLastSearch = false;
            fields.groupID = this.props.groupID;

            this.setState({textMessage: ''});

            this.props.actions.wtoSearch(
                fields
                , refreshCallback
                , (error) => {
                    this.props.actions.changeLoadingGroupSearchResult(false);
                    // this._onShowMessage();
                });

            if (!isAppend) {
                this.setState({ mounting: false });
            }
        }
    }

    componentDidMount() {
        StatusBar.setBarStyle('default');
        // let numberOfWTo = this._getNumberOfWTo();
        // if (numberOfWTo > 0) {
        //     this._onShowMessage();
        // }
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    _loadSearchFilter(fields) {
        let { loaiTin, ngayDaDang, huongNha, dienTich, mua, thue } = fields;
        let { initDienTich, fromDienTich, toDienTich } = this._initDienTich(dienTich);
        let { initGia, fromGia, toGia } = this._initGia(loaiTin, fields[loaiTin].gia);
        this.setState({
            showNgayDaDang: false,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            initNgayDaDang: ngayDaDang,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            inputNgayDaDang: ngayDaDang,
            toggleState: false,
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            huongNha: huongNha,
            ngayDaDang: ngayDaDang
        });
    }

    render() {
        log.info("Call GroupFilterResult render");
        if (this.state.isSuggestionFlipped) {
            return this._renderPlaceAutoComplete();
        } else {
            return this._renderMainView();
        }
    }

    _renderPlaceAutoComplete() {
        let predefinedPlaces = [
            // ...this.props.search.saveSearchList,
            // ...this.props.search.recentSearchList
        ];
        return (
            <View style={styles.fullWidthContainer}>
                <GroupPlacesAutoComplete
                    ref={'placeSuggestion'}
                    onSelectPress={this._onPlacePress.bind(this)}
                    onCancelPress={this._onCancelPress.bind(this)}
                    predefinedPlaces={predefinedPlaces}
                    allPlace={true}
                />
            </View>
        )
    }

    _onCancelPress() {
        this._flipSuggestion();
    }

    _onPlacePress(data) {
        log.enter("GroupFilterResult._onPlacePress", data);

        this.props.actions.onGroupWToSearchFieldChange("viewport", {});
        this.props.actions.onGroupWToSearchFieldChange("orderBy", '');
        // this.props.actions.onResetGroupAdsList();
        // this.props.actions.changeLoadingGroupSearchResult(true);

        if (data.isRecent || data.isSaveSearch) {
            this.props.actions.loadSavedSearch(data);
        } else {
            data.fullName = data.shortName || data.fullName;

            if (data.fullName != gui.TAT_CA_KHU_VUC) {
                this.props.actions.onGroupWToSearchFieldChange("viewport", data.viewport);
                this.props.actions.onGroupWToSearchFieldChange("diaChinhViewport", data.viewport);
            } else {
                let region = {
                    latitude: LATITUDE,
                    longitude: LONGITUDE,
                    latitudeDelta: LATITUDE_DELTA,
                    longitudeDelta: LONGITUDE_DELTA
                };
                let viewport = apiUtils.getViewport(region);
                this.props.actions.onGroupWToSearchFieldChange("viewport", viewport);
                this.props.actions.onGroupWToSearchFieldChange("diaChinhViewport", viewport);
            }
            let diaChinh = {
                tinhKhongDau: data.tinh, huyenKhongDau: data.huyen,
                xaKhongDau: data.xa, duAnKhongDau: data.duAn, duongKhongDau: data.duong, fullName: data.fullName
            };

            this.props.actions.onGroupWToSearchFieldChange("diaChinh", diaChinh);
        }

        // this.props.actions.changeLoadingGroupSearchResult(true);
        this.props.actions.onChangeGroupListScrollPos(0);
        this._flipSuggestion();
        setTimeout(() => {
            this._handleSearchAction();
        }, 1000);
    }

    _flipSuggestion() {
        this.setState({ isSuggestionFlipped: !this.state.isSuggestionFlipped });
    };

    _handleSearchAction() {
        // this.props.actions.onResetGroupAdsList();
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);
        this.doSearchWTo();
    }

    doSearchWTo() {
        let { diaChinh } = this.props.groupSearch.wtoForm.fields;

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;

        //TODO: need to verify logic of updating last search
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            fields.userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            fields.deviceID = this.props.global.deviceInfo.deviceID;
        }
        fields.updateLastSearch = diaChinh && diaChinh.tinhKhongDau && diaChinh.tinhKhongDau != '';

        this._loadSearchFilter(fields);

        fields.groupID = this.props.groupID;

        if (!this.state.searchFilter2Actived) {

            this.setState({textMessage: ''});

            this.props.actions.wtoSearch(
                fields
                , () => {
                    // this._onShowMessage();
                }
                , (error) => {
                    this.props.actions.changeLoadingGroupSearchResult(false)
                });

        } else {
            this.props.actions.changeLoadingGroupSearchResult(false);
        }
    }

    _renderMainView() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderFilterResult()}
                <View style={{ width: width, height: height - 60 }}>
                    {this.state.searchFilter2Actived ? this._renderSearchFilter2() : this._renderSearchMainView()}
                    {this._openModalSapxep()}
                    {this._openModalLoaiTin()}
                    {this._openModalLoaiNhaDat()}
                    {this._openModalMucGia()}
                    {this._openModalDienTich()}
                </View>
            </View>
        );
    }

    _renderSearchFilter2() {
        let placeName = this._getHeaderTitle();
        return (
            <GroupWToFilter
                placeName={placeName} onShowMessage={() => this._onShowMessage()}
                isHeaderLoading={() => this._isHeaderLoading()}
                loadHomeData={this.props.actions.loadHomeData}
                owner={'list'}
                refreshRegion={() => {
                    this.props.actions.onChangeGroupListScrollPos(0);
                    this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);
                }}
                onSuggestPress={() => { this.refs.placeSuggestion && this.refs.placeSuggestion.focusInputSearch(); this._flipSuggestion() }}
                activeView={'SearchResult'}
                userID={this.props.userID}
                deviceID={this.props.deviceID}
                onBackToSearchMain={this._onBackToSearchMain.bind(this)}
                fields={this.props.groupSearch.wtoForm.fields}
                getHeaderTitle={this._getHeaderTitle.bind(this)}
                onLoaiTinChange={this._onLoaiTinChange.bind(this)}
                filterState={this.state}
                updateSearchFilterState={this._updateSearchFilterState.bind(this)}
                onGiaChanged={this._onGiaChanged.bind(this)}
                doChangeGia={this._doChangeGia.bind(this)}
                onDienTichChanged={this._onDienTichChanged.bind(this)}
                onNgayDaDangChanged={this._onNgayDaDangChanged.bind(this)}
                getGiaValue={this._getGiaValue.bind(this)}
                getDienTichValue={this._getDienTichValue.bind(this)}
                getLoaiNhatDatValue={this._getLoaiNhatDatValue.bind(this)}
                getHuongNhaValue={this._getHuongNhaValue.bind(this)}
                getNgayDaDangValue={this._getNgayDaDangValue.bind(this)}
                onKeyboardToggle={this.onKeyboardToggle.bind(this)}
                onSearchFilterApply={this.onSearchFilterApply.bind(this)}
                onResetFilters={this.onResetFilters.bind(this)}
                onPropertyTypesPressed={this._onPropertyTypesPressed.bind(this)}
                onHuongNhaPressed={this._onHuongNhaPressed.bind(this)}
                onNgayDaDangInputChange={this._onNgayDaDangInputChange.bind(this)}
                onSearchFieldChange={this.props.actions.onGroupWToSearchFieldChange} />
        );
    }

    _onPropertyTypesPressed() {
        let { loaiTin } = this.state;
        Actions.GroupWToPropertyTypes({
            func: 'search', loaiTin: loaiTin, loaiNhaDat: this.state[loaiTin].loaiNhaDat,
            onLoaiNhaDatChange: (loaiNhaDat) => this._onLoaiNhaDatChange(loaiNhaDat)
        });
    }

    _onLoaiNhaDatChange(loaiNhaDat) {
        let { loaiTin } = this.state;
        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = loaiNhaDat;
        if (loaiTin == DanhMuc.loaiTinFilter.mua) {
            this.setState({ mua: loaiNhaDatParent });
        } else {
            this.setState({ thue: loaiNhaDatParent });
        }
    }

    _onHuongNhaPressed() {
        Actions.HuongNha({ huongNha: this.state.huongNha, onHuongNhaChange: (huongNha) => this._onHuongNhaChange(huongNha) });
    }

    _onHuongNhaChange(huongNha) {
        this.setState({ huongNha: huongNha });
    }

    _onNgayDaDangInputChange(value) {
        this.setState({ inputNgayDaDang: value, ngayDaDang: value });
    }

    onResetFilters() {
        let defaultMua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onGroupWToSearchFieldChange("mua", defaultMua);
        this.props.actions.onGroupWToSearchFieldChange("thue", defaultThue);
        this.props.actions.onGroupWToSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onGroupWToSearchFieldChange("huongNha", 0);
        this.props.actions.onGroupWToSearchFieldChange("ngayDaDang", '');

        this.setState({
            initGia: RangeUtils.BAT_KY_RANGE, initDienTich: RangeUtils.BAT_KY_RANGE, initNgayDaDang: 0,
            fromDienTich: '', toDienTich: '', fromGia: '', toGia: '', inputNgayDaDang: '',
            showGia: false, showDienTich: false, showNgayDaDang: false,
            mua: defaultMua, thue: defaultThue, dienTich: RangeUtils.BAT_KY_RANGE,
            huongNha: 0, ngayDaDang: ''
        });
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    onSearchFilterApply() {
        log.info("Call Search.onSearchFilter2Apply");
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);
        // this.props.actions.onResetGroupAdsList();
        // this.props.actions.changeLoadingGroupSearchResult(true);

        let { loaiTin } = this.state;
        this.props.actions.setGroupSearchLoaiTin(loaiTin);

        this.doSearchFilterAds(false);
    }

    doSearchFilterAds(reloadDiaChinhViewport) {
        let { loaiTin, dienTich, huongNha, ngayDaDang } = this.state;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        let mua = null;
        let thue = null;
        if (loaiTin == DanhMuc.loaiTinFilter.mua) {
            mua = this.state[DanhMuc.loaiTinFilter.mua];
        } else {
            thue = this.state[DanhMuc.loaiTinFilter.thue];
        }

        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;
        this.props.actions.onGroupWToSearchFieldChange(loaiTin, loaiNhaDatParent);

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);
        this.props.actions.onGroupWToSearchFieldChange("dienTich", newDienTich);
        this.props.actions.onGroupWToSearchFieldChange("huongNha", huongNha);
        this.props.actions.onGroupWToSearchFieldChange("ngayDaDang", ngayDaDang);
        this.props.actions.onGroupWToSearchFieldChange("orderBy", '');

        let maxItem = this.props.global.setting.maxAdsInMapView;
        this._handleSearchFilterAction(loaiTin, mua, thue, '', 1, maxItem, newGia, newDienTich,
            huongNha, ngayDaDang, reloadDiaChinhViewport);
        // if (this.props.needBack) {
        //     Actions.pop();
        // } else {
        //     log.info("Call open SearchResultList in reset mode");
        //
        //     Actions.SearchResultList({type: "reset"});
        // }
        this._onBackToSearchMain();
        this.props.actions.onChangeGroupListScrollPos(0);
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);
        // this._onShowMessage();
    }

    _handleSearchFilterAction(newLoaiTin, newMua, newThue, newOrderBy, newPageNo, newLimit, newGia, newDienTich,
        newHuongNha, newNgayDaDang, reloadDiaChinhViewport) {
        var { loaiTin, mua, thue, orderBy, diaChinh, viewport, pageNo, diaChinhViewport } = this.props.groupSearch.wtoForm.fields;
        if (newGia) {
            if (loaiTin == DanhMuc.loaiTinFilter.mua) {
                mua.gia = newGia;
            } else {
                thue.gia = newGia;
            }
        }

        let newViewport = viewport;
        if (reloadDiaChinhViewport) {
            newViewport = diaChinhViewport || viewport;
            this.props.actions.onGroupWToSearchFieldChange("viewport", newViewport);
        }

        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.loaiTin = newLoaiTin || loaiTin;
        fields.mua = newMua || mua;
        fields.thue = newThue || thue;
        fields.dienTich = newDienTich;
        fields.orderBy = newOrderBy == null ? orderBy : newOrderBy;
        fields.huongNha = newHuongNha;
        fields.ngayDaDang = newNgayDaDang;
        fields.pageNo = newPageNo || pageNo;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;

        //TODO: need to verify logic of updating last search
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            fields.userID = this.props.global.currentUser.userID;
        }
        fields.updateLastSearch = diaChinh && diaChinh.tinhKhongDau && diaChinh.tinhKhongDau != '';

        // for counting active device
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            fields.deviceID = this.props.global.deviceInfo.deviceID;
        }

        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.wtoSearch(
            fields
            , () => {/*setTimeout(() => this.props.actions.loadHomeData(), 100)*/ }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) });


        Analytics.logEvent('GROUP_SEARCH_FILTER', { deviceID: this.props.deviceID, userID: this.props.userID });
    }

    _getGiaValue() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        return RangeUtils.getFromToDisplay(newGia, giaStepValues.getUnitText());
    }

    _getDienTichValue() {
        let { dienTich } = this.state;
        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        return RangeUtils.getFromToDisplay(newDienTich, RangeUtils.dienTichRange.getUnitText());
    }

    _getHuongNhaValue() {
        let { huongNha } = this.state;
        if (!huongNha || huongNha.length == 0 || huongNha[0] == 0) {
            return RangeUtils.BAT_KY;
        }
        return utils.getHuongNhaText(huongNha, 20);
    }

    _getNgayDaDangValue() {
        var { ngayDaDang } = this.state;
        if (!ngayDaDang || ngayDaDang == 0) {
            return RangeUtils.BAT_KY;
        }
        return ngayDaDang + " ngày";
    }

    _onGiaChanged(pickedValue) {
        let { loaiTin } = this.state;
        let giaStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = pickedValue.split('_');
        let value = giaStepValues.rangeVal2Display(giaVal);
        this._doChangeGia(loaiTin, value);
        var initGia = [];
        Object.assign(initGia, value);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if (DanhMuc.loaiTinFilter.mua === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if (DanhMuc.loaiTinFilter.mua === loaiTin) {
            toGia = toGia / 1000;
        }
        this.setState({ initGia: initGia, fromGia: fromGia, toGia: toGia });
    }

    _doChangeGia(loaiTin, giaVal) {
        var parent = {};
        Object.assign(parent, this.state[loaiTin]);
        parent.gia = giaVal;
        if (loaiTin == DanhMuc.loaiTinFilter.mua) {
            this.setState({ mua: parent });
        } else {
            this.setState({ thue: parent });
        }
    }

    _onDienTichChanged(pickedValue) {
        let dienTichVal = pickedValue.split('_');
        let value = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        let initDienTich = [];
        Object.assign(initDienTich, value);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({ initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value });
    }

    _onNgayDaDangChanged(pickedValue) {
        let value = pickedValue;
        this.setState({ initNgayDaDang: value, inputNgayDaDang: value, ngayDaDang: value });
    }

    _updateSearchFilterState(newState) {
        this.setState(newState);
    }

    _onLoaiTinChange(value) {
        if (value == DanhMuc.loaiTinFilter.duAn) {
            this.setState({ loaiTin: value });
            return;
        }

        let { initGia, fromGia, toGia } = this._initGia(value);
        this.setState({
            loaiTin: value,
            initGia: initGia,
            fromGia: fromGia,
            toGia: toGia,
            showGia: false,
            showDienTich: false
        });
    }

    _onBackToSearchMain() {
        this.setState({ searchFilter2Actived: false });
    }

    _onShowMessage() {
        let { loading, errorMsg } = this.props;
        let { mounting } = this.state;
        let numberOfWTo = this._getNumberOfWTo();

        if ((!errorMsg && numberOfWTo == 0) || loading || mounting) {
            return null;
        }

        let textMessage = errorMsg || this.getPagingTitle();

        this.setState({
            textMessage: textMessage,
            showMessage: true, mounting: false
        });
        this._onMsgAnimationStart();
    }

    _isHeaderLoading() {
        return this.props.loading;
    }

    _renderSearchMainView() {
        return (
            <View style={{ flex: 1 }}>
                <View style={styles.mainContainer}>
                    {this._renderFront()}
                </View>
                {this._renderMessageItem()}
                <View style={styles.tabFilterContainer}>
                    {this._renderTapFilter()}
                    <View style={styles.lineDangNhap} />
                </View>
            </View>
        );
    }

    _renderMessageItem() {
        let textValue = this.state.textMessage;
        if (this.props.loading || textValue == '' || this.state.msgType == '') {
            return null;
        }
        return (
            <MMessage mainStyle={{ top: 92 }}
                // barStyle="light-content"
                animation={this.state.msgType}
                duration={500}
                onAnimationEnd={this._onAnimationEnd.bind(this)}
                textValue={textValue} />
        );
    }

    _updateMessageProcessing(textMessage) {
        this.setState({ textMessage: textMessage });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => { this.setState({ textMessage: '', msgType: '' }) }, 2000);
        }
    }

    _renderFront() {
        return (
            <View style={[styles.fullWidthContainer, { backgroundColor: 'white' }]}>
                {this._renderTapList()}
                {this._renderBodyContent()}
            </View>
        );

    };

    getDieuKienLoc() {
        let fields = this.props.fields;
        return fields ? findApi.convertQuery2String(findApi.convertFieldsToQueryParams(fields)) : "";
    }

    getShortedText(text) {
        if (!text) {
            return null;
        }
        var maxDiaChiLength = width * 7 / 40;
        var index = text.indexOf(',', maxDiaChiLength - 5);
        var length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = text.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        let shortedText = text.substring(0, length);
        if (shortedText.length < text.length) {
            shortedText = shortedText + '...';
        }
        return shortedText;
    }

    isDisplayTwoLinesMsg() {
        let diaChinh = this.props.fields.diaChinh;

        let placeName;
        if (diaChinh && diaChinh.tinhKhongDau) {
            placeName = diaChinh.fullName;
        } else if (diaChinh && diaChinh.fullName) {
            placeName = diaChinh.fullName;
        } else { //others: banKinh or currentLocation
            placeName = gui.KHUNG_NHIN_HIEN_TAI;
        }

        return placeName != gui.KHUNG_NHIN_HIEN_TAI && placeName != gui.VI_TRI_HIEN_TAI;
    }

    _renderNotFoundLine2() {
        let buttonText = gui.INF_KhongCoKetQuaL2;
        let fontWeight = '600';
        let textColor = gui.mainColor;
        return (
            <ScalableText style={[styles.resultIcon,
            { fontWeight: fontWeight, color: textColor }]}>{buttonText}
            </ScalableText>
        );
    }

    _renderLoadingView() {
        if (this.props.loading) {
            return (
                <View style={styles.loadingContent}>
                    <GiftedSpinner size="large" color={gui.mainTextColor} />
                </View>
            );
        }
    }

    _getTotalCount() {
        return this.props.totalCount;
    }

    _doPreviousPage() {
        log.info("Call SearchResultMap._doPreviousPage");
        let { pageNo } = this.props.groupSearch.wtoForm.fields;

        if (pageNo > 1) {
            pageNo = pageNo - 1;
            this._onUpdateChangePageStatus(pageNo);
            this._refreshListData(null, () => {
                // this._onShowMessage()
            }, null, null, pageNo, true);
            Analytics.logEvent('GROUP_MAP_PAGINATION', {
                deviceID: this.props.deviceID, userID: this.props.userID,
                pageNo: pageNo
            });
        }
    }

    _doNextPage() {
        log.info("Call SearchResultMap._doNextPage");
        let { pageNo } = this.props.groupSearch.wtoForm.fields;
        let limit = this.props.maxAdsInMapView;
        let totalCount = this._getTotalCount();
        let totalPages = totalCount / limit;

        if (pageNo < totalPages) {
            pageNo = pageNo + 1;
            this._onUpdateChangePageStatus(pageNo);
            this._refreshListData(null, () => {
                // this._onShowMessage()
            }, null, null, pageNo, true);
            Analytics.logEvent('GROUP_MAP_PAGINATION', {
                deviceID: this.props.deviceID, userID: this.props.userID,
                pageNo: pageNo
            });
        }
    }

    _onUpdateChangePageStatus(pageNo) {
        this.props.actions.onGroupWToSearchFieldChange("pageNo", pageNo);
        this.setState({ mounting: false });
    }

    _renderBodyContent() {
        let myProps = this.props;
        if (myProps.loading) {
            let imageUriHome = require('../../assets/image/default_cover/no_cover_03.jpg');
            return (
                <View style={styles.container}>
                    <View style={styles.viewLoaderAds}>
                        {/*<Text> Loading ... </Text>*/}
                        {/*<GiftedSpinner size="large"/>*/}
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                    </View>
                </View>
            );
        }

        return (
            <View style={styles.container}>
                <View
                    style={{ width: width, height: height - 152 }}
                >
                    <ScrollView
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
                    >
                        {/*this._renderNumberResult()*/}
                        {this._renderListGroupSearch()}
                    </ScrollView>
                    {this._renderBottomControls()}
                </View>
            </View>
        );
    }

    _onModalSapXep() {
        this.setState({ isOpenModalSapxep: true });
    }

    _onContentModal() {
        this.setState({
            isOpenModalSapxep: false,
            isOpenModalLoaiTin: false,
            isOpenModalLoaiNhaDat: false,
            isOpenModalMucGia: false,
            isOpenModalDienTich: false
        });
    }

    _openModalSapxep() {
        return (
            <Modal isOpen={this.state.isOpenModalSapxep}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle}
                position={"center"}
                swipeToClose={false}
                animationDuration={200}
                backdropPressToClose={false}
            >
                {this._renderSapXepContent()}
            </Modal>
        );

    }

    _renderSapXepContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    {this._renderTextSapxep()}
                    {this._renderTextCancel()}
                </View>
                {
                    DanhMuc.getSearchWToOrderValues().map((e, index) => {
                        let orderByKey = this.props.groupSearch.wtoForm.fields.orderBy || '';
                        let orderByValue = DanhMuc.searchOrder[orderByKey];
                        let checked = e == orderByValue;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep,{ borderTopWidth: borderTopWidth }]}
                                key={e}
                                onPress={() => this._onChooseSearchOrder(e)}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        )
    }

    _renderTextSapxep() {
        return (
            <View style={styles.viewSortModal}>
                <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Sắp xếp</Text>
            </View>
        );
    }

    _onChooseSearchOrder(searchOrderValue) {
        this.setState({
            isOpenModalSapxep: false
        });

        let newOrderBy = DanhMuc.findSearchOrderKey(searchOrderValue);
        this.props.actions.onGroupWToSearchFieldChange("orderBy", newOrderBy);
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);
        this.setState({ sorting: true });

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.orderBy = newOrderBy;
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.wtoSearch(
            fields
            , () => {
                this.setState({ sorting: false })
            }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_LIST_SORT', { deviceID: deviceID, userID: userID, orderBy: newOrderBy });
    }

    _openModalLoaiTin() {
        return (
            <Modal isOpen={this.state.isOpenModalLoaiTin}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiTinStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderLoaiTinContent()}
            </Modal>
        );
    }

    _renderLoaiTinContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Loại tin</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {
                    DanhMuc.findLoaiTinWToValues().map((e, index) => {
                        let { loaiTin } = this.state;
                        let orderLoaiTin = DanhMuc.LoaiTinWToType[loaiTin];
                        let checked = e == orderLoaiTin;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                key={e}
                                onPress={() => { this._onTabLoaiTinChange(e) }}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }

            </View>
        )
    }

    _onTabLoaiTinChange(value) {

        let loaiTinPress = value == 'Cần mua' ? 'mua' : 'thue';

        let { loaiTin } = this.state;

        if (loaiTin == loaiTinPress) {
            this.setState({
                isOpenModalLoaiTin: false
            });
            return;
        }
        let newLoaiTin = (value == 'Cần mua') ? 'mua' : 'thue';
        let defaultMua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onGroupWToSearchFieldChange("loaiTin", newLoaiTin);
        this.props.actions.onGroupWToSearchFieldChange("mua", defaultMua);
        this.props.actions.onGroupWToSearchFieldChange("thue", defaultThue);
        this.props.actions.onGroupWToSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);

        this.setState({
            initGia: RangeUtils.BAT_KY_RANGE,
            initDienTich: RangeUtils.BAT_KY_RANGE,
            initNgayDaDang: 0,
            fromDienTich: '',
            toDienTich: '',
            fromGia: '',
            toGia: '',
            inputNgayDaDang: '',
            showGia: false,
            showDienTich: false,
            showNgayDaDang: false,
            mua: defaultMua,
            thue: defaultThue,
            dienTich: RangeUtils.BAT_KY_RANGE,
            huongNha: [0],
            ngayDaDang: '',
            isOpenModalLoaiTin: false,
            loaiTin: newLoaiTin
        });

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.loaiTin = newLoaiTin;
        fields.mua = defaultMua;
        fields.thue = defaultThue;
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.wtoSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );

        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _openModalLoaiNhaDat() {
        return (
            <Modal isOpen={this.state.isOpenModalLoaiNhaDat}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderLoaiNhaDatContent()}
            </Modal>
        );
    }

    _renderLoaiNhaDatContent() {
        let { loaiTin } = this.state;
        let loaiNhaDatType = loaiTin == 'mua' ? DanhMuc.findLoaiNhaCanMuaValues() : DanhMuc.findLoaiNhaCanThueValues();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Loại nhà đất</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {
                    loaiNhaDatType.map((e, index) => {
                        let orderLoaiNhaDat = this._getLoaiNhatDatFullValue();
                        let checked = e == orderLoaiNhaDat;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                key={e}
                                onPress={() => { this._onTabLoaiNhaDatChange(e) }}>
                                <Text style={[styles.textSapxep, { width: width - 110 }]} numberOfLines={1}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        )
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );

    }

    _onTabLoaiNhaDatChange(value) {
        let { loaiTin } = this.state;
        let hashLoaiNhaDat = loaiTin == 'mua' ? DanhMuc.LoaiNhaCanMua : DanhMuc.LoaiNhaCanThue;
        let loaiNhaDatKey = utils.getKeyByValue(hashLoaiNhaDat, value);

        let loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = Number(loaiNhaDatKey) || undefined;
        if (loaiTin == DanhMuc.loaiTinFilter.mua) {
            this.setState({ mua: loaiNhaDatParent, isOpenModalLoaiNhaDat: false });
        } else {
            this.setState({ thue: loaiNhaDatParent, isOpenModalLoaiNhaDat: false });
        }
        this.props.actions.onGroupWToSearchFieldChange(loaiTin, loaiNhaDatParent);
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields[loaiTin] = loaiNhaDatParent;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.wtoSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );


        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _openModalMucGia() {
        return (
            <Modal isOpen={this.state.isOpenModalMucGia}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderMucGiaContent()}
            </Modal>
        );
    }

    _renderMucGiaContent() {
        let { loaiTin } = this.state;
        let rangeStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let pickerRange = rangeStepValues.getAllRangeVal();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Mức giá</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>
                <ScrollView>
                    {
                        pickerRange.map((value, index) => {
                            let label = RangeUtils.getFromToDisplay(
                                rangeStepValues.rangeVal2Display(value), rangeStepValues.getUnitText()
                            );
                            let orderMucGia = this._getGiaValue();
                            let checked = label == orderMucGia;
                            let borderTopWidth = index == 0 ? 0 : 1;
                            return (
                                <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                    key={label}
                                    onPress={() => { this._onTabMucGiaChange(value) }}>
                                    <Text style={styles.textSapxep}>{label}</Text>
                                    <View style={styles.viewTickSapxep}>
                                        {
                                            checked ?
                                                <TruliaIcon
                                                    name="check" color={gui.mainColor} size={20}
                                                    mainProps={styles.viewCheckIcon}
                                                /> : null
                                        }

                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                </ScrollView>
            </View>
        )
    }

    _onTabMucGiaChange(value) {

        let { loaiTin } = this.state;

        let loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);

        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = value;
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;
        if (loaiTin == DanhMuc.loaiTinFilter.mua) {
            this.setState({ mua: loaiNhaDatParent, isOpenModalMucGia: false });
        } else {
            this.setState({ thue: loaiNhaDatParent, isOpenModalMucGia: false });
        }
        this.props.actions.onGroupWToSearchFieldChange(loaiTin, loaiNhaDatParent);
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields[loaiTin] = loaiNhaDatParent;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.wtoSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );


        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });

    }

    _openModalDienTich() {
        return (
            <Modal isOpen={this.state.isOpenModalDienTich}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderDienTichContent()}
            </Modal>
        );
    }

    _renderDienTichContent() {

        let rangeStepValues = RangeUtils.dienTichRange;
        let pickerRange = rangeStepValues.getAllRangeVal();
        let orderDienTich = this._getDienTichValue();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Diện tích</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>
                <ScrollView>
                    {
                        pickerRange.map((value, index) => {
                            let label = RangeUtils.getFromToDisplay(
                                rangeStepValues.rangeVal2Display(value), rangeStepValues.getUnitText()
                            );
                            let checked = label == orderDienTich;
                            let borderTopWidth = index == 0 ? 0 : 1;
                            return (
                                <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                    key={label}
                                    onPress={() => { this._onTabDienTichChange(value) }}>
                                    <Text style={styles.textSapxep}>{label}</Text>
                                    <View style={styles.viewTickSapxep}>
                                        {
                                            checked ?
                                                <TruliaIcon
                                                    name="check" color={gui.mainColor} size={20}
                                                    mainProps={styles.viewCheckIcon}
                                                /> : null
                                        }

                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                </ScrollView>
            </View>
        )
    }

    _onTabDienTichChange(value) {
        let dienTichVal = value;
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        this.props.actions.onGroupWToSearchFieldChange("dienTich", newDienTich);
        this.props.actions.onGroupWToSearchFieldChange("pageNo", 1);
        this.setState({
            isOpenModalDienTich: false,
            dienTich: newDienTich
        });

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.wtoForm.fields);
        fields.dienTich = newDienTich;
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.wtoSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );


        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _renderHeaderFilterResult() {
        let btnDisabled = this.props.loading;
        let backButtonItem = null;
        let filterButtonItem = null;
        if (!this.state.searchFilter2Actived) {
            backButtonItem = (
                <TouchableOpacity style={styles.viewBackButton}
                    onPress={this._onBackPress.bind(this)}>
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
            );
        } else {
            filterButtonItem = (
                <TouchableOpacity style={styles.viewBackButton}
                    onPress={this._onFilterPress.bind(this)}
                    disabled={btnDisabled}
                >
                    <Text style={styles.titleText}>Hủy</Text>
                </TouchableOpacity>
            );
        }
        return (
            <View style={styles.viewFilterHeader}>
                {backButtonItem}
                {this._renderInputFilter(btnDisabled)}
                {filterButtonItem}
            </View>
        );
    }

    _onArraySort(a, b) {
        if (a === '') {
            return 1;
        }
        if (b === '') {
            return -1;
        }
        return a - b;
    }

    _getLoaiTinValue() {
        let { loaiTin } = this.state;
        let loaiTinValue = DanhMuc.getLoaiTinWToTypeValue(loaiTin);
        return loaiTinValue;
    }

    _getGiaValue() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.mua === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        return RangeUtils.getFromToDisplay(newGia, giaStepValues.getUnitText());
    }

    _getDienTichValue() {
        let { dienTich } = this.state;
        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        return RangeUtils.getFromToDisplay(newDienTich, RangeUtils.dienTichRange.getUnitText());
    }

    _getLoaiNhatDatValue() {
        let { loaiTin } = this.state;

        return DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat).substring(0, 25);
    }

    _getLoaiNhatDatFullValue() {
        let { loaiTin } = this.state;

        return DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat);
    }

    _renderTapFilter() {
        let filterValue = 'Lọc';
        let filterBgColor = gui.mainColor;
        let filterTextColor = '#fff';
        let loaiTinValue = this._getLoaiTinValue();
        let loaiTinBgColor = gui.mainColor;
        let loaiTinTextColor = '#fff';
        let filterCount = 1;
        let loaiNhaDatIndex = this._getLoaiNhatDatValue();
        let loaiNhaDatValue = (loaiNhaDatIndex == 'Bất kỳ') ? 'Loại nhà đất - Bất kỳ' : loaiNhaDatIndex;
        let loaiNhaDatBgColor = (loaiNhaDatIndex == 'Bất kỳ') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let loaiNhaDatTextColor = (loaiNhaDatIndex == 'Bất kỳ') ? '#526173' : '#fff';
        filterCount = (loaiNhaDatIndex == 'Bất kỳ') ? filterCount : filterCount+1;
        let loaiGiaIndex = this._getGiaValue();
        let loaiGiaValue = (loaiGiaIndex == 'Bất kỳ') ? 'Mức giá - Bất kỳ' : loaiGiaIndex;
        let loaiGiaBgColor = (loaiGiaIndex == 'Bất kỳ') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let loaiGiaTextColor = (loaiGiaIndex == 'Bất kỳ') ? '#526173' : '#fff';
        filterCount = (loaiGiaIndex == 'Bất kỳ') ? filterCount : filterCount+1;
        let loaiDienTichIndex = this._getDienTichValue();
        let loaiDienTichValue = (loaiDienTichIndex == 'Bất kỳ') ? 'Diện tích - Bất kỳ' : loaiDienTichIndex;
        let loaiDienTichBgColor = (loaiDienTichIndex == 'Bất kỳ') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let loaiDienTichTextColor = (loaiDienTichIndex == 'Bất kỳ') ? '#526173' : '#fff';
        filterCount = (loaiDienTichIndex == 'Bất kỳ') ? filterCount : filterCount+1;
        let btnDisabled = this.props.loading;

        return (
            <View style={styles.viewTabFilter}>
                <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    scrollEnabled={!btnDisabled}
                >

                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: filterBgColor, marginLeft: 0, paddingLeft: 8 }]}
                                      onPress={this._onFilterPress.bind(this)}
                                      disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={styles.totalView}>
                                <Text style={styles.totalText}>{filterCount}</Text>
                            </View>
                            <Text style={[styles.textButtonTab, { color: filterTextColor }]}>{filterValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={filterTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiTinBgColor }]}
                        onPress={this._onModalMua.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiTinTextColor }]}>{loaiTinValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiTinTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiNhaDatBgColor }]}
                        onPress={this._onModalKieuNha.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiNhaDatTextColor }]}>{loaiNhaDatValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiNhaDatTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiGiaBgColor }]}
                        onPress={this._onModalMucGia.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiGiaTextColor }]}>{loaiGiaValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiGiaTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiDienTichBgColor }]}
                        onPress={this._onModalDienTich.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiDienTichTextColor }]}>{loaiDienTichValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiDienTichTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>

                </ScrollView>
            </View>
        );
    }

    _renderTapList() {
        if (this.props.loading || this.state.mounting) {
            return null;
        }
        let orderByKey = this.props.groupSearch.wtoForm.fields.orderBy || '';
        let textSort = DanhMuc.searchWToOrderSort[orderByKey];
        let iconName = this._getIconValue(orderByKey);
        let sortValue = iconName == 'sort';
        let btnDisabled = this.props.loading;
        return (
            <View style={styles.viewTabList}>
                {/*<TouchableOpacity style={[styles.viewTabListContent, { width: width / 2 - 1 }]}
                    onPress={this._onModalSapXep.bind(this)}
                    disabled={btnDisabled}
                >
                    /!*<Text style={styles.textButtonMap}>Giá:</Text>
                    <Text style={[styles.textButtonMap,{marginLeft: 5}]}>{textSort}</Text>*!/
                    <Text style={styles.textButtonMap}>{textSort}</Text>
                    {!sortValue ? (<Icon name={iconName} size={15} color={gui.mainTextColor} style={{ marginLeft: 4, marginRight: 5 }} />) : null}
                    <Icon name="sort" size={15} color={gui.mainTextColor} style={{ marginLeft: 10 }} />
                </TouchableOpacity>*/}
                {this._renderNumberResult()}
            </View>
        );
    }

    _getIconValue(value) {
        let iconName = 'sort';
        let upValues = ['giaASC', 'giaM2ASC', 'dienTichASC'];
        let downValues = ['giaDESC', 'giaM2DESC', 'dienTichDESC'];
        if (upValues.includes(value)) {
            iconName = 'long-arrow-up';
        } else if (downValues.includes(value)) {
            iconName = 'long-arrow-down';
        }
        return iconName;

    }

    _renderNumberResult() {
        let result = this.getPagingTitle();
        return (
            <View style={styles.viewNumberResult}>
                <Text style={styles.textResult}>
                    {result}
                </Text>
            </View>
        );
    }

    getPagingTitle() {
        let myProps = this.props;
        let numberOfWTo = myProps.wtoList.length;
        let { diaChinh } = myProps.fields;
        let totalCount = myProps.totalCount;
        let pageNo = myProps.fields.pageNo;
        let limit = myProps.limit;
        let totalPages = totalCount / limit;
        let endAdsIndex = (pageNo - 1) * limit + numberOfWTo;
        if (totalCount < endAdsIndex) {
            totalCount = endAdsIndex;
        }
        if (pageNo == totalPages) {
            totalCount = endAdsIndex;
        }
        let title = totalCount + ' kết quả';
        if (diaChinh.tinhKhongDau) {
            title += ' cho "' + diaChinh.fullName + '"';
        }
        return title;
    }

    _renderBottomControls() {
        let myProps = this.props;
        let totalCount = myProps.totalCount;
        let pageNo = myProps.fields.pageNo;
        let limit = myProps.limit;
        let totalPages = Math.ceil(totalCount / limit);
        if (totalPages == 0) {
            totalPages = 1;
        }
        let hasPreviousPage = pageNo > 1;
        let previousColor = hasPreviousPage ? gui.mainColor : gui.colorMainBlur;

        let hasNextPage = pageNo < totalPages;
        let nextColor = hasNextPage ? gui.mainColor : gui.colorMainBlur;

        let numberItems =
            <View style={styles.viewNumberNext}>
                <Text style={styles.textButtonMap}>{pageNo}</Text>
                <Text style={[styles.textButtonMap, { color: gui.colorMainBlur }]}>{` / ` + totalPages}</Text>
                <Icon name="sort" size={9} color={gui.mainTextColor} style={{ marginLeft: 6 }} />
            </View>;

        return (
            <View style={styles.viewNextButtonResult}>
                <View style={styles.nextButtonContent}>
                    <TouchableOpacity style={styles.viewNextLeft}
                        onPress={this._doPreviousPage.bind(this)}
                        disabled={!hasPreviousPage}
                    >
                        <Icon name="chevron-left" size={16} color={previousColor} style={{ marginRight: 0 }} />
                    </TouchableOpacity>
                    <View style={styles.lineTab} />
                    {numberItems}
                    <View style={styles.lineTab} />
                    <TouchableOpacity style={styles.viewNextLeft}
                        onPress={this._doNextPage.bind(this)}
                        disabled={!hasNextPage}
                    >
                        <Icon name="chevron-right" size={16} color={nextColor} style={{ marginRight: 0 }} />
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _renderListGroupSearch() {
        let dsFilterGroup = ds_filterGroup.cloneWithRows(this.props.wtoList);
        return (
            <View style={styles.viewListGroupSearch}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsFilterGroup}
                    renderRow={this._renderRowFilterGroup.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowFilterGroup(data) {
        let date = (data.dateStart && data.dateEnd) ? (moment(data.dateStart).format("DD/MM/YYYY") + '-' + moment(data.dateEnd).format("DD/MM/YYYY")) : moment(data.timeModified).format("DD/MM/YYYY");

        return (
            <View
                style={styles.viewRowPostNormal}>
                <TouchableHighlight
                    onPress={this.onDetailWto.bind(this, data)}
                    underlayColor="rgba(220,220,220,1)">
                    <View style={styles.viewRowPostWto}>
                        {this._renderDetailWtoPost(data)}
                    </View>
                </TouchableHighlight>
                <View style={styles.viewLineParent}>
                    <FullLine style={{ marginLeft: 8, marginRight: 8 }} />
                </View>

                <View style={styles.viewTimeShare}>
                    <View style={styles.viewTimeLeft}>
                        <MaterialCommunityIcons name={"clock"} color={gui.textShare} size={17} />
                        <Text style={[styles.textDatePost, { fontSize: 14 }]}>{date}</Text>
                    </View>
                </View>
            </View>
        );
    }

    _renderDetailWtoPost(data) {
        let typePost = DanhMuc.loaiTinWTo[data.loaiTin];
        let titleTextFull = utils.getTitleWtoDetail2(data.content);
        if (data.dataType=='dummy')
            titleTextFull = '[Dữ liệu mẫu] ' + titleTextFull;
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;
        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;

        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))
        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }
        let diaChiFullName = data.content.place.fullName || ' ';
        let date = moment(data.timeModified).format("DD/MM/YYYY");
        let dateWtoFmt = `Ngày đăng: ${date}`

        let contactLinked = `Đã gắn với khách: ${data.contactName} - ${data.contactPhone}`;

        return (
            <View style={styles.viewNewPost}>
                <View style={[styles.viewTieuDe, { width: width - 24, alignItems: 'flex-start' }]}>
                    <View style={styles.viewTextTieuDe}>
                        <Text style={[styles.textTieuDe, { marginLeft: 0, fontWeight: 'normal' }]} numberOfLines={2}>{titleTextFull}</Text>
                    </View>
                </View>
                <View style={[styles.viewTieuDe, { width: width - 24, marginTop: 5 }]}>
                    <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                        <Text style={styles.textTypePost}>{priority}</Text>
                    </View>
                    <Text style={[styles.textDatePost, { fontSize: 13 }]}>{dateWtoFmt}</Text>
                </View>
                <FullLine style={{ marginTop: 12, marginBottom: 2 }} />
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { fontSize: 17, fontWeight: '500', }]} numberOfLines={1}>{giaNha}</Text>
                </View>
                <View style={[styles.viewLabel, { alignItems: 'flex-start', marginTop: 6 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 48 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { color: gui.textPostCommon }]}>{diaChiFullName}</Text>
                    </View>
                </View>
                {detailItems && detailItems.length > 0 ?
                    (<View style={[styles.viewPercentDraft, { flexDirection: 'row', marginTop: 3 }]}>
                        {detailItems}
                    </View>) : null}
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { color: '#898989', fontWeight: 'normal', fontSize: 13 }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                </View>
                {data.contactName
                    ? <View style={[styles.viewPercentDraft, {marginTop: 0}]}>
                    <Text style={[styles.textGiaNha, { color: '#898989', fontWeight: 'normal', fontSize: 13 }]} numberOfLines={1}>{contactLinked}</Text>
                </View>
                    : null }
            </View>
        );
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                                      name="compass" color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                                      name="bath" color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostCommon} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    onDetailWto(data) {
        if (!data.phone) {
            this.props.actions.getUserInfo(data.userID)
                .then(res => {
                    if (res.status != 0) {
                        // Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                        this.refs.toastTop && this.refs.toastTop.show(res.msg, DURATION.LENGTH_LONG);
                    } else {
                        if (res.userInfo) {
                            data.phone = res.userInfo.phone
                            data.email = res.userInfo.email
                            data.fullName = res.userInfo.fullName
                            data.avatar = res.userInfo.avatar
                        }
                        Actions.AgentWtoDetail({ data: data });
                    }
                });
        } else Actions.AgentWtoDetail({ data: data });

        // let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        // let userID = this.props.global.currentUser.userID || undefined;
        // Analytics.logEvent('AGENT_STORE_WTO_DETAIL', { deviceID: deviceID, userID: userID });
    }

    _onPressFilterGroup(ads) {
        Actions.GroupAdsDetail({ adsID: ads.adsID, imageDetail: ads.image.cover });
    }


    _onModalMua() {
        this.setState({
            isOpenModalLoaiTin: true
        });
    }

    _onModalKieuNha() {
        this.setState({
            isOpenModalLoaiNhaDat: true
        })
    }
    _onModalMucGia() {
        this.setState({
            isOpenModalMucGia: true
        })
    }

    _onModalDienTich() {
        this.setState({
            isOpenModalDienTich: true
        })
    }

    _onBackPress() {
        Actions.pop();
    }

    _onFilterPress() {
        if (this.state.searchFilter2Actived) {
            this._loadSearchFilter(this.props.fields);
        }
        this.setState({ searchFilter2Actived: !this.state.searchFilter2Actived });
    }

    _getHeaderTitle() {
        let diaChinh = this.props.fields.diaChinh;

        let placeName;
        //2. Search by Polygon: name is just center
        if (diaChinh && diaChinh.tinhKhongDau) {
            placeName = diaChinh.fullName;
        } else if (diaChinh && diaChinh.fullName && diaChinh.fullName != gui.VI_TRI_HIEN_TAI) {
            placeName = diaChinh.fullName;
        } else { //others: banKinh or currentLocation
            placeName = gui.KHUNG_NHIN_HIEN_TAI;
        }

        return placeName;
    }

    _renderInputFilter(btnDisabled) {
        let placeName = this._getHeaderTitle();
        let inputWidth = this.state.searchFilter2Actived ? width - 77 : width - 65;
        let textWidth = this.state.searchFilter2Actived ? width - 107 : width - 95;
        let marginLeft = this.state.searchFilter2Actived ? 17 : 0;
        return (
            <TouchableOpacity style={{ height: 36, width: inputWidth, marginLeft: marginLeft, backgroundColor: '#fff' }}
                              onPress={() => {
                    this.refs.placeSuggestion && this.refs.placeSuggestion.focusInputSearch();
                    this._flipSuggestion();
                }
                }
                              disabled={btnDisabled}
            >
                <View style={styles.viewInputFilter}>
                    <View style={styles.viewConditions}>
                        {placeName ?
                            <View style={styles.diaChiView}>
                                <View style={{ width: textWidth }}>
                                    <Text style={styles.diaChiText} numberOfLines={1}>{placeName}</Text>
                                </View>
                            </View>
                            : null}
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    mainContainer: {
        position: 'absolute',
        top: 52,
        left: 0,
        right: 0,
        height: height - 96
    },
    scrollView: {
        flexGrow: 1,
        position: 'absolute',
        height: height - 44
    },
    viewFilterHeader: {
        marginTop: 10,
        height: 50,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 14,
        backgroundColor: '#fff'
    },
    viewBackButton: {
        width: 56,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewInputFilter: {
        flex: 1,
        borderRadius: 5,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: gui.groupBackground,
        paddingLeft: 7
    },
    speachIcon: {
        position: 'absolute',
        top: 10,
        right: 17
    },
    viewConditions: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start'
    },
    tabFilterContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 64,
        flexDirection: 'column'
    },
    viewTabFilter: {
        height: 52,
        paddingVertical: 8,
        paddingHorizontal: 8,
        width: width,
    },
    viewDownIcon: {
        marginBottom: 0,
        justifyContent: 'flex-end',
        height: 21,
        marginTop: 30
    },
    viewEachButtonTab: {
        paddingHorizontal: 12,
        paddingVertical: 9,
        // height: 32,
        borderRadius: 4,
        marginLeft: 8,
        marginTop: 0,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: 'rgba(82,97,115,0.25)'
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainTextColor,
        textAlign: 'left',
        marginRight: 8,
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 16,
        opacity: 0.8,
        marginLeft: 8,
        marginRight: 8
    },
    viewTabList: {
        height: 40,
        width: width,
        borderBottomWidth: 1,
        borderColor: '#dcdcdc',
        flexDirection: 'row',
        justifyContent: 'flex-end'
    },
    viewTabListContent: {
        width: width / 3,
        height: 40,
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexDirection: 'row',
        marginRight: 15
    },
    lineTab: {
        width: 1,
        backgroundColor: '#dcdcdc',
        height: 24,
        opacity: 0.8,
        marginTop: 8,
        marginBottom: 8
    },
    textButtonMap: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainTextColor,
    },
    viewNumberResult: {
        width: width,
        // height: 64,
        marginTop: 8,
        marginBottom: 8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textResult: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.colorMainBlur,
    },
    viewListGroupSearch: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewListContainer: {
        paddingBottom: 15
    },
    viewListMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginBottom: 8
    },
    imgItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 16,
        height: imageGroup,
        alignSelf: 'auto'
    },
    viewNameGroup: {
        position: 'absolute',
        left: 16,
        bottom: 50,
        height: 36,
        width: width - 180,
        backgroundColor: 'transparent'
    },
    viewTotalMembers: {
        position: 'absolute',
        left: 16,
        bottom: 26,
        height: 20,
        width: width - 180,
        backgroundColor: 'transparent'
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: gui.textPostAds,
        fontWeight: '500',
    },
    textTotalMembers: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: 'rgba(255,255,255,0.75)',
        fontWeight: 'normal'
    },
    linearGradient2: {
        marginTop: 0,
        height: imageGroup,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    linearGradientMain: {
        marginTop: 0,
        height: 216,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewButtonGroup: {
        width: width,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewEachButton: {
        height: 56,
        width: (width - 16) / 4,
        backgroundColor: '#fff',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: 5
    },
    textBottonGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: 'normal'
    },
    sortDescIcon: {
        position: 'absolute',
        top: 14,
        right: 18
    },
    viewNewRequest: {
        height: 32,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    viewBodyMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 8
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    viewUserLogo: {
        position: 'absolute',
        left: 15,
        bottom: 17,
        height: 24,
        // width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 15,
        bottom: 13,
        height: 32,
        width: width - 30,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 28,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        width: width - 18,
        paddingLeft: 17,
        paddingRight: 17
    },
    viewUserPostChild: {
        height: 32,
        width: (width - 30) / 2,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    mainUserChild: {
        height: 26,
        width: 26,
        borderRadius: 13
    },
    viewNameUserChild: {
        height: 32,
        width: (width - 30) / 2 - 33,
        marginRight: 7,
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundColor: 'transparent',
    },
    textNameChild: {
        fontSize: 12,
        color: '#fff',
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewDetailPost: {
        // height: 105,
        width: width - 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderTopWidth: 0,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 15,
        color: gui.textPostAds,
        fontFamily: gui.fontFamily
    },
    viewContentSource: {
        height: 24,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 4
    },
    viewTextAddress: {
        // height: 28,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 4
    },
    textTimePost: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        position: 'absolute',
        right: 17
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewNextButtonResult: {
        height: 40,
        width: 156,
        justifyContent: 'flex-start',
        alignItems: 'center',
        position: 'absolute',
        bottom: 11,
        left: width / 2 - 78,
        backgroundColor: 'transparent'
    },
    nextButtonContent: {
        height: 38,
        width: 154,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 4,
        borderColor: gui.colorMainBlur,
        borderWidth: 1,
        backgroundColor: '#fff',
        opacity: 0.9
    },
    viewNextLeft: {
        height: 38,
        width: 41,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewNumberNext: {
        height: 38,
        width: 70,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewLoaderAds: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    viewChildRow: {
        width: width,
        height: gui.ADS_IMAGE_RATIO*width,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingLeft: 17,
        borderBottomWidth: 1,
        borderColor: '#eaebed'
    },
    viewLineLoaderRow: {
        height: 14,
        width: width / 3,
        backgroundColor: 'rgba(234, 234, 234, 0.5)',
        marginBottom: 8
    },
    diaChiText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    diaChiView: {
        backgroundColor: gui.groupBackground,
        paddingVertical: 5,
        paddingHorizontal: 8
    },
    viewModalStyle: {
        justifyContent: 'center',
        height: 120,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewLoaiTinStyle: {
        justifyContent: 'center',
        height: 120,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewLoaiNhaDatStyle: {
        justifyContent: 'center',
        height: 409,
        width: width - 60,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    textSapxep: {
        fontSize: 17,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    fullWidthContainer: {
        flexGrow: 1,
        flexDirection: 'column',
        alignItems: 'stretch',
        backgroundColor: 'transparent'
    },
    map: {
        flex: 1,
        position: 'absolute',
        top: 40,
        left: 0,
        right: 0,
        bottom: 0
    },
    mapView: {
        flex: 1,
        marginTop: 0,
        marginBottom: 0
    },
    bubble: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 2,
        paddingVertical: 2,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 5
    },
    bubble2: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 2,
        paddingVertical: 2,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 13
    },
    button: {
        width: 43,
        height: 38,
        paddingVertical: 2,
        alignItems: 'center',
        marginVertical: 2,
        backgroundColor: 'white',
        opacity: 0.75,
        marginLeft: 15
    },
    viewIconDiaDiem: {
        flex: 1,
        backgroundColor: 'transparent',
        justifyContent: 'flex-end'
    },
    textIconDiaDiem: {
        backgroundColor: 'white',
        fontSize: 8
    },
    drawIconText: {
        fontSize: 8,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'center'
    },
    refreshButton: {
        position: 'absolute',
        bottom: 13,
        left: width / 2 - 21,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    previousButton: {
        position: 'absolute',
        bottom: 13,
        left: width / 2 - 79,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    nextButton: {
        position: 'absolute',
        bottom: 13,
        left: width / 2 + 37,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    helpButton: {
        position: 'absolute',
        bottom: 13,
        left: width - 56,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    imageHelp: {
        backgroundColor: 'transparent'
    },
    pagingView: {
        paddingTop: 0,
        width: 35,
        height: 32,
        backgroundColor: 'transparent'
    },
    viewToastMap: {
        width: width,
        height: 118,
        backgroundColor: 'transparent',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom: 50,
        borderRadius: 5,
        borderWidth: 0
    },
    viewModalTop: {
        width: 240,
        height: 69,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'rgba(169, 168, 168, 0.01)',
        paddingTop: 10,
        paddingRight: 6
    },
    viewBoxTop: {
        width: 240,
        height: 69,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'rgba(169, 168, 168, 0.01)',
        paddingTop: 10
    },
    viewAnimatable: {
        width: 240,
        height: 60,
        backgroundColor: '#fff',
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 6
    },
    viewIconClose: {
        height: 20,
        width: 20,
        borderRadius: 10,
        backgroundColor: '#b6b6b6',
        left: 106,
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        marginTop: -20
    },
    textContent: {
        color: '#5f5f5f',
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    triangle: {
        width: 0,
        height: 0,
        backgroundColor: 'transparent',
        borderStyle: 'solid',
        borderLeftWidth: 6,
        borderRightWidth: 6,
        borderBottomWidth: 9,
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderBottomColor: '#fff',
        transform: [
            { rotate: '180deg' }
        ],
        marginLeft: 10
    },
    detailAdsModal: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
        height: imageHeight,
        width: width
    },
    detailAdsModalThumb: {
        justifyContent: 'flex-end',
        alignItems: 'stretch',
        height: imageHeight,
        width: width,
        alignSelf: 'auto'
    },
    detailAdsModalLinearGradient: {
        flex: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    detailAdsModalPrice: {
        fontSize: 17,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 10,
        color: 'white'
    },
    detailAdsModalText: {
        fontSize: 15,
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 10,
        marginBottom: 15,
        margin: 5,
        color: 'white'
    },
    detailAdsModalTextHeartButton: {
        marginBottom: 10
    },
    detailAdsModalDetail: {
        backgroundColor: 'transparent',
        flexDirection: 'row',
        justifyContent: 'space-between',
        top: 83,
        width: width
    },
    adsModal: {
        justifyContent: 'center',
        alignItems: 'center',
        height: imageHeight,
        width: width,
        marginVertical: 0,
    },
    searchListView: {
        marginTop: 0,
        margin: 0,
        backgroundColor: 'white'
    },
    adsNoPosContainer: {
        position: 'absolute',
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        bottom: 10,
        right: 14,
        width: 55,
        backgroundColor: 'transparent'
    },
    searchListButton2: {
        flexDirection: 'column',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: 'transparent',
        height: 100,
        borderTopWidth: 1,
        borderColor: 'lightgray'
    },
    backButton: {
        width: 60,
        paddingTop: 5,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingRight: 18,
        paddingLeft: 5
    },
    backButtonText: {
        color: gui.mainColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 5
    },
    viewTopNav: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        backgroundColor: 'white',
        height: 30,
        width: width
    },
    textSpaceTop: {
        fontSize: 15,
        color: '#333333',
        textAlign: 'center',
        alignItems: 'center',
    },
    viewCenterNav: {
        backgroundColor: 'white',
        height: 40,
        width: width - 30,
        right: 15,
        left: 15,
        alignItems: 'stretch',
        justifyContent: 'center',
        flexDirection: 'column'
    },
    track: {
        height: 2,
        borderRadius: 1,
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: gui.mainColor,
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    viewBottomNav: {
        backgroundColor: 'white',
        height: 30,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewTextBottom: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'row',
        backgroundColor: 'transparent'
    },
    textBottomLeft: {
        fontSize: 13,
        flex: 1,
        color: '#676769',
        textAlign: 'right',
        marginBottom: 5,
        paddingRight: 3,
    },
    textBottomCenter: {
        fontSize: 13,
        flex: 5,
        color: '#676769',
        textAlign: 'left',
        marginBottom: 5,
    },
    textBottomRight: {
        fontSize: 13,
        flex: 1,
        color: '#676769',
        textAlign: 'right',
        paddingRight: 15,
        marginBottom: 5
    },
    customPageRightTitle: {
        alignItems: 'flex-end',
        justifyContent: 'center',
        height: 25,
        width: 60,
        paddingTop: 5,
        paddingRight: 5,
        backgroundColor: 'transparent'
    },
    customPageRightTitleText: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        textAlign: 'right',
        fontWeight: '500'
    },
    viewMeasure: {
        backgroundColor: 'transparent',
        height: 5,
        width: width - 30,
        right: 15,
        left: 15,
        bottom: 8,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row'
    },
    sliderDotOne: {
        backgroundColor:gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        left: 6
    },
    sliderDotTwo: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        marginLeft: (width - 30) / 10
    },
    sliderDotThree: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        marginLeft: (width - 30) / 10 - 7
    },
    sliderDotFour: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        marginLeft: (width - 30) / 10 - 6
    },
    modal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        height: 150,
        width: width - 40,
        marginVertical: 0,
        borderRadius: 5
    },
    modalHeader: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'center',
        alignItems: 'center',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 10,
        paddingBottom: 10,
        borderTopWidth: 1,
        marginVertical: 0,
        width: width - 40,
        borderTopColor: '#f8f8f8',
        borderRadius: 5
    },
    modalHeaderText: {
        fontSize: 17,
        fontWeight: '600',
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 0,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    modalTitle: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 8,
        paddingBottom: 8,
        borderTopWidth: 1,
        marginVertical: 0,
        width: width - 40,
        borderTopColor: '#f8f8f8',
        backgroundColor: '#f8f8f8'
    },
    modalTitleText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 0,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    viewModalHelp: {
        justifyContent: 'center',
        height: height - 180,
        width: width - 30,
        marginVertical: 0,
        borderRadius: 8
    },
    viewContentHelp: {
        flex: 1,
        marginBottom: 10
    },
    textFullWidth: {
        textAlign: 'justify',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#9c9c9c',
        marginTop: 6,
        marginBottom: 6,
        marginLeft: 32
    },
    mapButtonContainer: {
        position: 'absolute',
        bottom: 10,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginVertical: 5,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    loadingContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        width: width,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent',
    },
    resultText: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        width: width,
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor: 'transparent',
        opacity: 0.85
    },
    resultIcon: {
        color: '#03a0da',
        fontSize: gui.capitalizeFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'center'
    },
    titleText: {
        backgroundColor: 'transparent',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600'
    },
    totalView: {
        width: 24,
        height: 24,
        marginRight: 8,
        borderRadius: 4,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    },
    totalText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainColor,
        textAlign: 'left'
    },
    heartButton: {
        marginTop: 6
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare
    },
    viewRowPostNormal: {
        width: width,
        height: 'auto',
        paddingBottom: 8,
        backgroundColor: gui.newLineFacebook
    },
    viewRowPostWto: {
        width: width,
        height: 'auto',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingTop: 6,
        paddingBottom: 3,
        backgroundColor: '#fff'
    },
    viewLineParent: {
        height: 1,
        backgroundColor: "#fff",
        width: width,
    },
    viewTimeShare: {
        height: 36,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewTimeLeft: {
        height: 36,
        width: width / 2,
        paddingLeft: 8,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeRight: {
        height: 36,
        width: width / 2,
        paddingRight: 8,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row'
    },
    viewNewPost: {
        justifyContent: 'center',
        backgroundColor: '#fff',
        paddingHorizontal: 12,
        height: 'auto',
        width: width
    },
    viewTieuDe: {
        flexDirection: 'row',
        height: 'auto',
        width: width - 138 + 34,
        alignItems: 'center',
    },
    viewTextTieuDe: {
        justifyContent: 'center',
        width: width - 38 - 24,
        height: 'auto',
        paddingTop: 8

    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: '500',
        color: gui.textPostAds,
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        width: width - 24,
        height: 20,
        backgroundColor: '#fff'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupFilterResult);