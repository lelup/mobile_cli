import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    ListView,
    TextInput,
    ImageBackground,
    Alert,
    StatusBar,
    TouchableWithoutFeedback,
    Keyboard,
    ActivityIndicator
} from 'react-native';

import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import { Actions } from 'react-native-router-flux';
import Button from 'react-native-button';
import OfflineBar from '../line/OfflineBar';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import Camera from 'react-native-camera';
import { Map } from 'immutable';
import Modal from 'react-native-modalbox';
import dismissKeyboard from 'react-native-dismiss-keyboard';
const Permissions = require('react-native-permissions');
import ImageResizer from 'react-native-image-resizer';
import moment from 'moment';
import cfg from "../../cfg";
import TextInputAuto from '../postAds/TextInputAuto';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import Toast, { DURATION } from '../toast/Toast';
import DanhMuc from '../../assets/DanhMuc';
import FullLine from '../../components/line/FullLine';
import FunctionModal from '../FunctionModal'
import userApi from '../../lib/userApi';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as wallActions from '../../reducers/wall/wallActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

let { width, height } = utils.getDimensions();
let imageGroup = 188;
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';


const actions = [
    globalActions,
    meActions,
    wallActions,
    adsMgmtActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var count = 0;
var uploadFiles = [];
var errorMessage = '';

class GroupPostAds extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            postContent: props.wallContent.postContent,
            postID: props.wallContent.postID,
            isOpenImagePicker: false,
            uploadUrls: [],
            thumbnailUrl: null,
            postWallPhotos: props.wallContent.postWallPhotos,
            postWallAds: props.wallContent.postWallAds,
            toggleState: false,
            wallImageIndex: 0,
            // wallContent: props.wallContent
            postingToWall: false
        }
    }

    componentWillMount() {
        // this.props.actions.onHideChatIconChange(true);
        StatusBar.setBarStyle('default');
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.wallContent !== this.props.wallContent) {
            this.setState({
                postContent: nextProps.wallContent.postContent,
                postID: nextProps.wallContent.postID,
                postWallPhotos: nextProps.wallContent.postWallPhotos,
                postWallAds: nextProps.wallContent.postWallAds
            });

        }
    }

    render() {
        return (
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                style={{ flex: 1 }}
            >
                <View style={styles.container}>
                    <OfflineBar />
                    <ScrollView contentContainerStyle={styles.scrollView}>
                        {this._renderHeaderPost()}
                        {this._renderInputPost()}
                        {this._renderPhoto()}
                        {this._renderAds()}
                        {this._renderDetailPost()}
                        {this.renderLoadingRequest()}
                    </ScrollView>
                    {this._renderTabPost()}
                    {/*{this.state.toggleState ? <Button onPress={() => dismissKeyboard()}*/}
                    {/*style={[styles.searchButtonText2, {*/}
                    {/*textAlign: 'right', color: gui.mainColor,*/}
                    {/*backgroundColor: gui.doneKeyButton*/}
                    {/*}]}>Xong</Button> : null}*/}
                    <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />

                    {this._openImagePicker()}

                    <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={height / 2}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{ color: '#fff' }}
                    />
                </View>
            </TouchableWithoutFeedback>
        );
    }

    renderLoadingRequest() {
        if (this.state.postingToWall){
            return (
                <View style={styles.viewSpinLoading}>
                    <ActivityIndicator size="large" color="gray" />
                </View>
            )
        }
    }

    _renderDetailPost(data) {
        let { postWallAds } = this.state;
        if (!postWallAds) return (<View></View>)

        if (postWallAds.adsID || (postWallAds.id && postWallAds.id.indexOf('Ads') > -1)) {
            let areaValue = utils.getDienTichDisplay(postWallAds.dienTich);
            let bedroomValue = postWallAds.soPhongNgu;
            let bathroomValue = postWallAds.soPhongTam;
            let addressValue = postWallAds.diaChi ? postWallAds.diaChi : (postWallAds.place ? postWallAds.place.diaChi : '');
            let now = moment();
            let ngayDangTin = moment(postWallAds.ngayDangTin, 'YYYYMMDD');
            let soNgayDaDangTin = now.diff(ngayDangTin, 'days');
            let huongNha = postWallAds.huongNha ? DanhMuc.HuongNha[postWallAds.huongNha] : '';
            let timePostValue = soNgayDaDangTin > 0 ? soNgayDaDangTin + ' ngày trước' : 'hôm nay';
            let textMotionValue = postWallAds.title ? postWallAds.title : utils.getTitleAdsDetail2(postWallAds);

            let detailItems = [];
            if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
                detailItems.push(this.getDienTich(areaValue));
            }
            if (!!bedroomValue) {
                detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
            }
            if (!!bathroomValue) {
                detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
            }
            if (!!huongNha) {
                detailItems.push(this._renderHuongNha(huongNha, (detailItems.length == 0) ? 0 : 12));
            }
            return (
                <View style={styles.viewDetailPost}>
                    <View style={styles.viewMainTextPost}>
                        <Text style={[styles.textMainPost, { color: gui.textAgentSolid }]} numberOfLines={2}>{textMotionValue}</Text>
                        <Text style={[styles.textTimePost, { color: gui.textComment, marginTop: 2 }]} numberOfLines={1}>{timePostValue}</Text>
                    </View>
                    <View style={styles.lineDangNhap} />
                    {this._renderGiaFmt(postWallAds)}
                    <View style={styles.viewTextAddress}>
                        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
                        <Text style={[styles.textMainMinute, { marginLeft: 8, color: gui.textPostAds, fontSize: 15 }]} numberOfLines={1}>{addressValue}</Text>
                    </View>
                    <View style={styles.viewContentSource}>
                        {detailItems}
                    </View>
                </View>
            )
        }
        return (<View></View>)
    }

    _renderGiaFmt(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        let giaFmt = `Giá: ${priceValue}`;
        return (
            <View style={styles.viewGiaFmt}>
                <Text style={styles.textPriceFmt}>{giaFmt}</Text>
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _renderHeaderPost() {
        let imageUserUrl = this.props.groupData.thumbnail || this.props.groupData.image;

        let imageUserPost = { uri: imageUserUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageUserUrl) {
            imageUserPost = defaultCover;
        }
        let group = this.props.groupData;
        let groupName = group && group.name || '';
        return (
            <View style={styles.viewHeaderPost}>
                <TouchableOpacity style={styles.viewCloseIcon}
                    onPress={this._onBackPost.bind(this)}>
                    <FontAwesomeLight name="times" size={24} color={gui.mainColor} noAction={true} iconOnly={true} />
                </TouchableOpacity>
                <View style={styles.viewHeaderContent}>
                    <FontAwesomeSolid
                        name="users"
                        size={15}
                        color={gui.textPostAds}
                        noAction={true}
                        iconOnly={true}
                        mainProps={{ marginRight: 6, marginBottom: 4 }}
                    />
                    <View style={{ marginBottom: 2 }}>
                        <Text style={[styles.textNameGroup, {color: gui.textPostAds, fontWeight: '500', fontSize: 16}]} numberOfLines={1}>{groupName}</Text>
                    </View>
                </View>
            </View>
        )
    }

    onBlurTextInput() {
        dismissKeyboard();
        this.onKeyboardToggle(false);
    }

    _renderInputPost() {
        return (
            <View style={styles.viewInputPost}>
                <TextInputAuto
                    autoFocus={true}
                    autoCorrect={false}
                    //blurOnSubmit={true}
                    onBlur={() => this.onBlurTextInput()}
                    multiline={true}
                    maxLength={2000}
                    underlineColorAndroid='rgba(0,0,0,0)'
                    style={styles.viewTextInput}
                    placeholder="Bạn muốn chia sẻ điều gì?"
                    placeholderTextColor={gui.colorMainBlur}
                    onChangeText={(text) => { this.onValueChange("postContent", text) }}
                    value={this.state.postContent}
                />
            </View>
        )
    }

    onValueChange(key: string, value: string) {
        this.setState({ postContent: value })
        // this.props.actions.onGroupFieldChange(key, value);
    }


    _renderTabPost() {
        let iconAdd = require('../../assets/image/iconThemTin.png');
        return (
            <View style={styles.viewTabPost}>
                <TouchableOpacity onPress={this._onChooseImage.bind(this)}>
                    <FontAwesomeLight name="image" size={26} color={gui.mainTextColor} noAction={true} iconOnly={true} />
                </TouchableOpacity >
                <TouchableOpacity style={{ marginLeft: 26 }}
                    onPress={this._onChooseAdsPost.bind(this)}>
                    {/*<Image
                        source={iconAdd}
                        resizeMode={'cover'}
                        style={styles.viewImageAdd}
                    />*/}
                    <FontAwesomeLight name="newspaper" size={26} color={gui.mainTextColor} noAction={true} iconOnly={true} />
                </TouchableOpacity>
                {this._renderDangTinButton()}
            </View>
        )
    }

    _renderDangTinButton() {
        if (this.state.postingToWall)
            return (
                <View
                    style={styles.viewButtonPost}>
                    <Text style={styles.textPost}>Đăng bài</Text>
                </View>
            )
        return (
            <TouchableOpacity
                onPress={this._onPostToWall.bind(this)}
                style={styles.viewButtonPost}>
                <Text style={styles.textPost}>Đăng bài</Text>
            </TouchableOpacity>
        )
    }

    _onBackPost() {
        // this.props.actions.onHideChatIconChange(false);
        StatusBar.setBarStyle('default');
        Actions.pop();
    }

    _onChooseImage() {
        //console.log('========> _onChooseImage');
        if (this.state.postWallAds && (this.state.postWallAds.adsID || this.state.postWallAds.id || this.state.postWallAds.wtoID)) {
            Alert.alert('Thông báo', 'Không thể đăng ảnh và tin bất động sản cùng lúc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        } else {
            let { postWallPhotos } = this.state;
            if (!postWallPhotos) {
                postWallPhotos = [];
            }
            let imageIndex = postWallPhotos.length;

            // this.props.actions.onGroupFieldChange('wallImageIndex', imageIndex);
            this.setState({ wallImageIndex: imageIndex })
            this._openModalImagePicker();
        }
    }

    _onChooseAdsPost() {
        //console.log('========> _onChooseAdsPost');
        if (this.state.postWallPhotos.length == 0) {
            // this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
            Actions.NewAgentPostViewOnly({
                groupData: this.props.groupData,
                groupID: this.props.groupID,
                owner: 'GroupPostAds',
                onAdsPicked: (value) => this._onAdsPicked(value)
            })

        }
        else {
            Alert.alert('Thông báo', 'Không thể đăng ảnh và tin bất động sản cùng lúc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }
    }

    _onAdsPicked(value) {
        this.setState({ postWallAds: value })
    }

    _openImagePicker() {
        return (
            <Modal isOpen={this.state.isOpenImagePicker}
                onClosed={this._outModalImagePicker.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderModalImagePicker()}
            </Modal>
        );
    }

    _renderModalImagePicker() {

        let items = [
            { _text: 'Máy ảnh', _function: () => this.onCamera() },
            { _text: 'Bộ sưu tập', _function: () => this.onCameraRollView() },
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outModalImagePicker.bind(this)} />
        )
    }

    onCamera() {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {
                if (e) {
                    Permissions.requestPermission('photo')
                        .then(response => {
                            if (response == 'authorized') {
                                Actions.GroupPostAds2(
                                    {
                                        onTakePhoto: this._outModalImagePicker.bind(this),
                                        owner: this.props.owner,
                                        wallImageIndex: this.state.wallImageIndex,
                                        photos: this.state.postWallPhotos,
                                        onPhotosChange: (value) => this._onPhotosChange(value)
                                    });
                            } else {
                                Alert.alert("Thông báo", gui.INF_PhotoAccess);
                            }
                        });

                } else {
                    Alert.alert("Thông báo", gui.INF_CameraAccess);
                }
            });
    }

    _onPhotosChange(value) {
        this.setState({ postWallPhotos: value })
    }

    onCameraRollView() {
        Permissions.requestPermission('photo')
            .then(response => {
                if (response == 'authorized') {
                    Actions.CameraRollView4({
                        onTakePhoto: this._outModalImagePicker.bind(this),
                        owner: this.props.owner,
                        wallImageIndex: this.state.wallImageIndex,
                        photos: this.state.postWallPhotos,
                        onPhotosChange: (value) => this._onPhotosChange(value)
                    });
                } else {
                    Alert.alert("Thông báo", gui.INF_PhotoAccess);
                }
            });
    }

    _outModalImagePicker() {
        this.setState({
            isOpenImagePicker: false
        });
    }

    _renderAds() {
        let { postWallAds } = this.state;
        if (!postWallAds)
            return (<View></View>)
        //console.log('GroupPostAds _renderAds *****************', postWallAds)
        if (postWallAds.adsID || (postWallAds.id && postWallAds.id.indexOf('Ads') > -1)) {
            let defaultCover = require('../../assets/image/no_cover.jpg');
            let adsCoverPhoto = { uri: postWallAds.image ? postWallAds.image.cover : '' };
            if (!postWallAds.image || !postWallAds.image.cover) {
                adsCoverPhoto = defaultCover;
            }

            return (
                <ImageBackground style={[styles.imgAdsItem, { height: gui.ADS_IMAGE_RATIO * width, marginTop: 8 }]}
                    source={adsCoverPhoto} defaultSource={defaultCover}>

                    {/*<LinearGradient colors={['rgba(50, 50, 50, 0.6)', 'rgba(50, 50, 50, 0.6)']}
                        style={styles.linearGradientMain}>*/}
                    {this._renderUserLogo(postWallAds)}
                    {/*{this._renderNamePrice(postWallAds)}*/}
                    {/*</LinearGradient>*/}
                    {this._renderDeleteAdsButton()}
                </ImageBackground>


            )
        }
        if (postWallAds.wtoID || (postWallAds.id && postWallAds.id.indexOf('WTo') > -1)) {

            let content = postWallAds.content;
            let priceRange = 'Giá:'

            let giaTuFmt = utils.getPriceDisplay(content.giaTu, content.loaiTin);
            if (giaTuFmt != DanhMuc.THOA_THUAN) {
                title += `${giaTuFmt}`;
            }

            let giaDenFmt = utils.getPriceDisplay(content.giaDen, content.loaiTin);
            if (giaDenFmt != DanhMuc.THOA_THUAN) {
                title += ` - ${giaDenFmt}`;
            }

            let diaChi = '';
            let title = utils.getTitleWtoDetail(postWallAds.content)

            return (
                <View style={styles.viewRowPostWto}>
                    {this._renderDetailWtoPost(postWallAds)}
                    <TouchableOpacity
                        style={[styles.deleteContent, { backgroundColor: gui.mainTextColor }]}
                        onPress={this.onDeleteAds.bind(this)} >

                        <View style={styles.deleteButton}>
                            <FontAwesomeLight name="times" color={'#fff'}
                                mainProps={styles.captureIcon}
                                size={16} textProps={{ paddingLeft: 0 }}
                                noAction={true}
                            />
                        </View>
                    </TouchableOpacity>
                </View>
            )
        }
        return (<View></View>)
    }

    _renderDetailWtoPost(data) {
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))
        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;

        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;

        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        let diaChiFullName = data.content.place.fullName || ' ';
        return (
            <View style={[styles.viewDetailPost2, { height: 'auto' }]}>
                <View style={styles.viewTieuDe}>
                    <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                        <Text style={styles.textTypePost}>{priority}</Text>
                    </View>
                    <View style={styles.viewTextTieuDe}>
                        <Text style={[styles.textTieuDe, { color: gui.textPostCommon }]} numberOfLines={1}>{diaChiFullname}</Text>
                    </View>
                </View>
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { color: gui.textPostCommon, fontWeight: '500' }]} numberOfLines={1}>{giaNha}</Text>
                </View>
                <View style={[styles.viewLabel, { marginTop: 6 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 34 - 32 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { color: gui.textPostCommon, fontSize: 15 }]}>{diaChiFullName}</Text>
                    </View>
                </View>
                {
                    detailItems && detailItems.length > 0 ?
                        <View style={[styles.viewPercentDraft, { flexDirection: 'row' }]}>
                            {detailItems}
                        </View> : null
                }
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { color: gui.textPostCommon }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                </View>
            </View>
        );
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="compass" color={gui.textPostCommon}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6, color: gui.textPostCommon }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="bath" color={gui.textPostCommon}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6, color: gui.textPostCommon }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostCommon}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6, color: gui.textPostCommon }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostCommon} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6, color: gui.textPostCommon }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _renderDeleteAdsButton() {

        return (
            <TouchableOpacity
                style={styles.deleteContent}
                onPress={this.onDeleteAds.bind(this)} >

                <View style={styles.deleteButton}>
                    <FontAwesomeLight name="times" color={'black'}
                        mainProps={styles.captureIcon}
                        size={16} textProps={{ paddingLeft: 0 }}
                        noAction={true}
                    />
                </View>
            </TouchableOpacity>
        )
    }

    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    onDeleteAds(imageIndex) {
        this.setState({ postWallAds: {} });
        this.props.actions.onWallFieldChange('postWallAds', {});
    }

    _renderUserLogo(data) {
        var logoList = [];
        if (data.goiLogo && data.goiLogo.length > 0) {
            logoList = data.goiLogo;
        }
        var logos = logoList.map((tag, index) => {
            let marginLeft = index == 0 ? 0 : 8;
            return (
                <View key={index} style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}>{tag.text}</Text>
                </View>
            )
        })

        return (
            <View style={styles.viewUserLogo}>{logos}</View>
        );
    }

    _renderNamePrice(data) {
        let ads = data;

        let defaultCover = require('../../assets/image/no_cover.jpg');
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        return (
            <View style={styles.viewNamePrice}>
                <View style={styles.viewPrice}>
                    <Text style={[styles.textNameGroup2, { fontSize: 20, color: gui.textPostCommon }]} numberOfLines={1}>{priceValue}</Text>
                </View>
            </View>
        );
    }

    _renderPhoto() {
        let { postWallPhotos } = this.state;
        // log.info('_renderPhoto *****', postWallPhotos)
        if (!postWallPhotos) {
            postWallPhotos = [];
        }
        let numOfPhoto = postWallPhotos.length;
        let indexArr = [];
        for (let i = 0; i <= postWallPhotos.length; i++) {
            if (i < 20) {
                indexArr.push(i)
            }
        }

        if (numOfPhoto == 0)
            return null
        else
            return (
                <View>
                    <View style={[styles.mimgList, { marginTop: 10, marginBottom: 5, paddingLeft: 17, paddingRight: 15 }]} >
                        {indexArr.map((e) => { if (e < 4) return this._renderPhotoItem(e) })}
                    </View>
                    <View style={[styles.mimgList, { marginTop: numOfPhoto >= 4 ? 5 : 0, marginBottom: numOfPhoto >= 4 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                        {indexArr.map((e) => { if (e >= 4 && e < 8) return this._renderPhotoItem(e) })}
                    </View>
                    <View style={[styles.mimgList, { marginTop: numOfPhoto >= 8 ? 5 : 0, marginBottom: numOfPhoto >= 8 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                        {indexArr.map((e) => { if (e >= 8 && e < 12) return this._renderPhotoItem(e) })}
                    </View>
                    <View style={[styles.mimgList, { marginTop: numOfPhoto >= 12 ? 5 : 0, marginBottom: numOfPhoto >= 12 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                        {indexArr.map((e) => { if (e >= 12 && e < 16) return this._renderPhotoItem(e) })}
                    </View>
                    <View style={[styles.mimgList, { marginTop: numOfPhoto >= 16 ? 5 : 0, marginBottom: numOfPhoto >= 16 ? 10 : 0, paddingLeft: 17, paddingRight: 15 }]} >
                        {indexArr.map((e) => { if (e >= 16 && e < 20) return this._renderPhotoItem(e) })}
                    </View>
                </View>
            );
    }

    _renderPhotoItem(imageIndex) {
        let { postWallPhotos } = this.state;
        // console.log('photos =========>>>', postWallPhotos);
        if (!postWallPhotos) {
            postWallPhotos = [];
        }
        let photo = postWallPhotos[imageIndex];

        return (
            <ImageItem imageIndex={imageIndex}
                key={imageIndex}
                photo={photo}
                onTakePhoto={this.onTakePhoto.bind(this)}
                onDeletePhoto={this.onDeletePhoto.bind(this)} />
        )
    }

    onTakePhoto(imageIndex) {
        if (this.state.postWallAds && (this.state.postWallAds.adsID || this.state.postWallAds.id || this.state.postWallAds.wtoID)) {
            Alert.alert('Thông báo', 'Không thể đăng ảnh và tin bất động sản cùng lúc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        } else {
            // this.props.actions.onGroupFieldChange('wallImageIndex', imageIndex);
            this.setState({ wallImageIndex: imageIndex })
            this._openModalImagePicker();
        }
    }

    _openModalImagePicker() {
        dismissKeyboard();
        this.setState({ isOpenImagePicker: true });
    }

    onDeletePhoto(imageIndex) {
        let { postWallPhotos } = this.state;
        postWallPhotos.splice(imageIndex, 1);
        this.setState({ deletedPhoto: imageIndex });
        this.props.actions.onWallFieldChange('postWallPhotos', postWallPhotos);
    }

    _onLogEvent() {
        let eventDto = {
            scene: "GroupPostAds",
            parentScene: this.props.owner,  //truyen owner neu co            
            componentType: "button",
            component: "Đăng tin",
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onPostToWall() {
        this.setState({postingToWall: true});
        this._onLogEvent();

        this.props.actions.onWallFieldChange('postContent', this.state.postContent);
        // this.props.actions.onWallFieldChange('postingToWall', true);
        let { postWallPhotos } = this.state;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < postWallPhotos.length; i++) {
            let filepath = postWallPhotos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }
        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
            this.props.actions.onWallFieldChange('error', errorMessage);
            // this.props.actions.onWallFieldChange('postingToWall', false);
            this.setState({postingToWall: false});
            return;
        }

        this.onPostToWallChecked();

    }

    isValidInputData() {
        let errors = '';
        // console.log("==============>", this.props.group);
        let postContent = this.state.postContent.trim();

        if (!postContent) {
            errors += ' (nội dung bài đăng)';
        }

        if (errors != '') {
            errorMessage = 'Bạn chưa chọn' + errors + '!';
            return false;
        }
        return true;
    }

    onPostToWallChecked() {
        let { postWallPhotos } = this.state;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < postWallPhotos.length; i++) {
            let filepath = postWallPhotos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }

        this.props.actions.onWallFieldChange("uploading", true);

        let countUpdateFiles = this.countNeedUploadFiles();
        if (!countUpdateFiles) {
            this.onSavePost();
            return;
        }

        count = 0;
        const userID = this.props.global.currentUser.userID;


        if (uploadFiles && uploadFiles.length > 0) {
            let indexThumbnail = uploadFiles[0].index;
            let filepathThumbnail = uploadFiles[0].filepath;
            //bachtv: always reupload thumbnail - Need review later if impact performance.
            ImageResizer.createResizedImage(filepathThumbnail, cfg.adsThumbWidth, cfg.adsThumbHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let thumbnailFilename = 'GroupWall_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadWallImage(indexThumbnail, thumbnailFilename, resizedImageUri, this.uploadCallBack.bind(this), 'thumbnail');
            }).catch((err) => {
                // this.props.actions.onWallFieldChange("postingToWall", false);
                this.setState({postingToWall: false});
                log.error(err)
            });
        }

        for (let i = 0; i < uploadFiles.length; i++) {
            if (errorMessage != '') {
                Alert.alert('Thông báo', errorMessage);
                this.props.actions.onWallFieldChange('error', errorMessage);
                // this.props.actions.onWallFieldChange('postingToWall', false);
                this.setState({postingToWall: false});
                return;
            }
            let needUpload = uploadFiles[i].needUpload;
            if (!needUpload) {
                continue;
            }
            let index = uploadFiles[i].index;
            let filepath = uploadFiles[i].filepath;
            ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let filename = 'GroupWall_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadWallImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this), 'normal');
            }).catch((err) => {
                // this.props.actions.onWallFieldChange("postingToWall", false);
                this.setState({postingToWall: false});
                log.error(err);
            });
        }
    }

    countNeedUploadFiles() {
        let count = 0;
        for (let i = 0; i < uploadFiles.length; i++) {
            let file = uploadFiles[i];
            if (file.needUpload) {
                count++;
            }
        }
        //count 1 more for cover image
        if (count>0)
            count++;
            
        return count;
    }

    uploadCallBack = function (err, result, index, type) {
        let data = result && result.data ? result.data : '';
        if (err || data == '') {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onWallFieldChange('error', errorMessage);
            this.props.actions.onWallFieldChange("uploading", false);
            return;
        }
        try {
            let { success, file } = JSON.parse(data);
            if (success) {
                let { url } = file;

                if (type=='normal')
                    this.state.uploadUrls.push({ index: index, url: url });
                if (type=='thumbnail')
                    this.state.thumbnailUrl = { index: index, url: url };

                count++;
                if (count == this.countNeedUploadFiles()) {
                    this.onSavePost();
                }
            } else {
                errorMessage = 'Upload ảnh không thành công!';
                this.props.actions.onWallFieldChange('error', errorMessage);
                this.props.actions.onWallFieldChange("uploading", false);
            }
        } catch (error) {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onWallFieldChange('error', errorMessage);
            this.props.actions.onWallFieldChange("uploading", false);
        }
    }

    onSavePost() {
        let { uploadUrls, thumbnailUrl } = this.state;
        let postContent = this.state.postContent;
        let { postID, postWallPhotos } = this.state;

        let imageUrls = [];
        for (let i = 0; i < postWallPhotos.length; i++) {
            let photo = postWallPhotos[i];
            imageUrls.push(photo.uri);
        }
        for (let i = 0; i < uploadUrls.length; i++) {
            let uploadUrl = uploadUrls[i];
            let index = uploadUrl.index;
            if (index >= 0) {
                imageUrls[index] = uploadUrl.url;
            }
        }
        let image = { cover: '', images: [] };
        if (imageUrls.length > 0) {
            image.cover = thumbnailUrl ? thumbnailUrl.url : imageUrls[0];            
            image.images = imageUrls;
        }
        // let image = [];
        // if (imageUrls.length > 0) {
        //     image = imageUrls;
        // }

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let adsList = [];
        let contentKhongDau = postContent
        let adsTitle = '';
        if (this.state.postWallAds && this.state.postWallAds.adsID) {
            adsTitle = this.state.postWallAds.title ? this.state.postWallAds.title : utils.getTitleAdsDetail2(this.state.postWallAds)
            adsList.push(this.state.postWallAds.adsID)
            contentKhongDau += " " + adsTitle;
        } else if (this.state.postWallAds && this.state.postWallAds.id && this.state.postWallAds.id.indexOf('Ads') > -1) {
            adsList.push(this.state.postWallAds.id)
            adsTitle = this.state.postWallAds.title ? this.state.postWallAds.title : utils.getTitleAdsDetail2(this.state.postWallAds)
            contentKhongDau += " " + adsTitle;
        } else if (this.state.postWallAds && this.state.postWallAds.wtoID) {
            adsTitle = utils.getTitleWtoDetail(this.state.postWallAds.content)
            adsList.push(this.state.postWallAds.wtoID)
            contentKhongDau += " " + adsTitle;
        } else if (this.state.postWallAds && this.state.postWallAds.id && this.state.postWallAds.id.indexOf('WTo') > -1) {
            adsTitle = utils.getTitleWtoDetail(this.state.postWallAds.content)
            adsList.push(this.state.postWallAds.id)
            contentKhongDau += " " + adsTitle;
        }


        let groupWallDto = {
            "groupID": this.props.groupID,
            "groupName": this.props.groupData.name,
            "id": postID || undefined,
            "content": postContent || undefined,
            "adsTitle": adsTitle || undefined,
            "contentKhongDau": utils.locDauV2(contentKhongDau) || undefined,
            "createdBy": currentUser.userID,
            "username": currentUser.username,
            "fullName": currentUser.fullName,
            "avatar": currentUser.thumbnail,
            "image": image,
            "ads": adsList,
            "groupWallOwner": this.props.groupData.createdBy
        };

        this.props.actions.postToWall(groupWallDto, token)
            .then(res => {

                // console.log("server respond: ", res);

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    //clear search text
                    this.refs.toastTop && this.refs.toastTop.show('Đăng bài thành công', DURATION.LENGTH_LONG);
                    //
                    if (this.props.owner == 'GroupLandberWall') {
                        this.props.actions.onWallFieldChange("pageNo", 1);
                        this.props.actions.onWallFieldChange("textSearch", '');
                        this.props.actions.getNextWall(
                            {
                                'groupID': [this.props.groupID],
                                'limit': this.props.wall.limit,
                                'pageNo': 1,
                                'textSearch': '',
                            }
                            , (res) => {
                                // this.props.actions.onHideChatIconChange(false);
                                StatusBar.setBarStyle('default');
                                Actions.pop();
                                this.props.scrollToTop && this.props.scrollToTop()
                            }
                            , (error) => {
                                // this.setState({ loaded: true });
                                // this.props.actions.onHideChatIconChange(false);
                                StatusBar.setBarStyle('default');
                                this._updateMessageProcessing(error, '#fa4916', 'white');
                            })
                    }
                    if (this.props.owner == 'NewHomeAgent') {
                        let dto = {
                            'userID': this.props.global.currentUser.userID,
                            'limit': 5,
                            'pageNo': 1,
                            'textSearch': ''
                        }
                        this.props.actions.newFeedWall(dto
                            , (res) => {
                                // log.info('_loadNewFeed server respond data: =====>>>>> ', res.data);
                                Actions.pop();
                            }
                            , (error) => {
                                console.info('_loadNewFeed server respond error: =====>>>>> ', error);
                            }
                        );

                    }

                    // setTimeout(() => Alert.alert(
                    //     "Thông báo",
                    //     "Đăng bài thành công.",
                    //     [{
                    //         text: 'Đóng', onPress: () => {
                    //             if (this.props.owner == 'GroupWall') {
                    //                 this.props.actions.onWallFieldChange("pageNo", 1);
                    //                 this.props.actions.onWallFieldChange("textSearch", '');
                    //                 this.props.actions.getNextWall(
                    //                     {
                    //                         'groupID': [this.props.groupID],
                    //                         'limit': this.props.wall.limit,
                    //                         'pageNo': 1,
                    //                         'textSearch': '',
                    //                     }
                    //                     , (res) => {
                    //                         // this.props.actions.onHideChatIconChange(false);
                    //                         StatusBar.setBarStyle('default');
                    //                         Actions.pop();
                    //                         this.props.scrollToTop && this.props.scrollToTop()
                    //                     }
                    //                     , (error) => {
                    //                         // this.setState({ loaded: true });
                    //                         // this.props.actions.onHideChatIconChange(false);
                    //                         StatusBar.setBarStyle('default');
                    //                         this._updateMessageProcessing(error, '#fa4916', 'white');
                    //                     })
                    //             }
                    //             if (this.props.owner == 'NewHomeAgent') {
                    //                 let dto = {
                    //                     'userID': this.props.global.currentUser.userID,
                    //                     'limit': 5,
                    //                     'pageNo': 1,
                    //                     'textSearch': ''
                    //                 }
                    //                 this.props.actions.newFeedWall(dto
                    //                     , (res) => {
                    //                         // log.info('_loadNewFeed server respond data: =====>>>>> ', res.data);
                    //                         Actions.pop();
                    //                     }
                    //                     , (error) => {
                    //                         console.info('_loadNewFeed server respond error: =====>>>>> ', error);
                    //                     }
                    //                 );

                    //             }
                    //         }
                    //     }]), 300);
                }
            });
    }
}

class ImageItem extends React.Component {
    constructor(props) {
        super(props);
    }

    _onPhotoPressed() {
        this.props.onTakePhoto(`${this.props.imageIndex}`);
    }

    _onDeletePhoto() {
        this.props.onDeletePhoto(`${this.props.imageIndex}`);
    }

    _renderCoverTitle() {
        if (this.props.imageIndex == 0)
            return (
                <View style={[styles.coverContent, {}]}>

                </View>
            )
    }

    _renderDeleteButton() {
        // if (this.props.imageIndex !=0)
        return (
            <TouchableOpacity
                style={styles.deleteContent}
                onPress={this._onDeletePhoto.bind(this)} >

                <View style={styles.deleteButton}>
                    <FontAwesomeLight name="times" color={'black'}
                        mainProps={styles.captureIcon}
                        size={16} textProps={{ paddingLeft: 0 }}
                        noAction={true}
                    />
                </View>
            </TouchableOpacity>
        )
    }


    render() {
        log.info("Group.render ");
        let photo = this.props.photo;

        if (photo && photo.uri) {
            return (
                <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
                    <ImageBackground style={styles.imgItem} source={photo} >
                        {this._renderDeleteButton()}
                    </ImageBackground>
                </TouchableOpacity>
            );
        } else {
            return (
                <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
                    <View style={styles.imgItem}>
                        <FontAwesomeLight name="plus" color={gui.mainTextColor}
                            mainProps={styles.captureIcon}
                            size={26} textProps={{ paddingLeft: 0 }}
                            noAction={true}
                        />
                        {this._renderCoverTitle()}
                    </View>
                </TouchableOpacity>
            );

        }

    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderPost: {
        height: 38,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 10
    },
    viewCloseIcon: {
        height: 38,
        width: 35,
        backgroundColor: '#fff',
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    viewHeaderContent: {
        height: 38,
        width: width - 60,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    mainUserPost: {
        height: 16,
        width: 16,
        marginRight: 8,
        marginBottom: 5
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.colorMainBlur
    },
    textNameGroup2: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: '#fff',
        fontWeight: '500'
    },
    viewInputPost: {
        height: 'auto', //48,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        marginTop: 28
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        backgroundColor: '#fff',
        width: width - 32,
        height: 48,
        color: gui.mainTextColor
    },
    viewTabPost: {
        height: 58,
        width: width,
        flexDirection: 'row',
        paddingLeft: 16,
        paddingRight: 16,
        // position: 'absolute',
        justifyContent: 'flex-start',
        alignItems: 'center',
        // bottom: 0,
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderColor: gui.colorMainBlur
    },
    viewButtonPost: {
        height: 32,
        width: 96,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor,
        borderRadius: 16,
        position: 'absolute',
        right: 16
    },
    textPost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: '#fff'
    },
    imgItem: {
        width: (width - 50) / 4,
        height: (width - 50) / 4,
        backgroundColor: 'rgba(82,97,115,0.25)',
        justifyContent: 'center',
        borderWidth: 0,
        marginRight: 4,
        borderColor: gui.separatorLine,
    },
    mimgList: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        // paddingLeft: 12,
        // paddingRight: 10,
        backgroundColor: 'white'
    },
    coverContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.8,
        bottom: 2,
        left: 2,
        alignSelf: 'auto'
    },
    coverText: {
        alignItems: 'center',
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    deleteContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.5,
        top: 2,
        right: 2,
        alignSelf: 'auto'
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 180,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        position: 'absolute',
        bottom: 50,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent',

    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 106,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textDelete: {
        color: '#f43838',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    deleteContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.5,
        top: 2,
        right: 2,
        alignSelf: 'auto'
    },
    deleteButton: {
        alignItems: 'center'
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    scrollView: {
        backgroundColor: 'transparent',
        paddingBottom: 60,
    },
    imgAdsItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 32,
        marginLeft: 16,
        height: imageGroup,
        alignSelf: 'auto'
    },
    linearGradientMain: {
        marginTop: 0,
        height: 216,
        width: width - 32,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 23,
        bottom: 13,
        height: 32,
        width: width - 46,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent'
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewUserLogo: {
        position: 'absolute',
        left: 17,
        bottom: 17,
        height: 24,
        width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewDetailPost: {
        // height: 106,
        marginLeft: 16,
        width: width - 32,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderTopWidth: 0,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 32,
        paddingLeft: 17,
        paddingRight: 17,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 64,
        opacity: 0.8,
        marginLeft: 17,
        marginRight: 17
    },
    viewContentSource: {
        // height: 20,
        width: width - 32,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 8
    },
    viewTextAddress: {
        // height: 28,
        width: width - 32,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        marginTop: 2
    },
    textTimePost: {
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        marginLeft: 0, //8
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    viewImageAdd: {
        width: 20,
        height: 20
    },
    viewRowPostNormal: {
        width: width,
        height: 'auto'
    },
    viewRowPost: {
        width: width,
        height: 83,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 8,
        paddingRight: 8,
        backgroundColor: '#fff'
    },
    viewTimeShare: {
        height: 31,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewLineParent: {
        height: 1,
        backgroundColor: "#fff",
        width: width,
    },
    viewTimeLeft: {
        height: 31,
        width: width / 2,
        paddingLeft: 8,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeRight: {
        height: 31,
        width: width / 2,
        paddingRight: 8,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row'
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewDetailPost2: {
        height: 65,
        // width: width - 146 + 34,
        width: width - 34,
        justifyContent: 'center',
        backgroundColor: '#fff',
        paddingLeft: 6
    },
    viewTieuDe: {
        flexDirection: 'row',
        width: width - 34 - 16,
        alignItems: 'center',
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewTextTieuDe: {
        height: 24,
        width: width - 62 - 32 - 16 - 27,
        // flex: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
        marginLeft: 9
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textPercentDraft: {
        color: gui.colorMainBlur,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        fontSize: 15
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
    },
    viewTimePost: {
        marginTop: 3,
        height: 16,
        width: width - 110
    },
    textMainUser2: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: '#2C394C',
        fontWeight: 'normal',
        marginLeft: 0, //8
    },
    viewRowPostNormalWto: {
        width: width - 32,
        height: 'auto',
        marginTop: 8,
        marginLeft: 16,
        marginRight: 16
    },
    viewRowPostWto: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingRight: 8,
        paddingTop: 6,
        paddingBottom: 3,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        width: width - 32,
        height: 'auto',
        marginTop: 8,
        marginLeft: 16,
        marginRight: 16
    },
    viewGiaFmt: {
        height: 28,
        width: width - 32,
        paddingLeft: 17,
        justifyContent: 'flex-end',
    },
    textPriceFmt: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.textPostAds
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        width: width - 34 - 16,
        height: 20,
        backgroundColor: '#fff'
    },
    viewSpinLoading: {
        position: 'absolute',
        top: 250,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    }
});
export default connect(mapStateToProps, mapDispatchToProps)(GroupPostAds);