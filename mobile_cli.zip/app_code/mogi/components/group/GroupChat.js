import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Keyboard,
    StatusBar
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { Actions } from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import Modal from 'react-native-modalbox';
import Toast, { DURATION } from '../toast/Toast';
import localStorage from '../../lib/localStorage';
import OfflineBar from '../line/OfflineBar';
import FontAwesomeLight from '../font/FontAwesomeLight'
import FontAwesomeSolid from '../font/FontAwesomeSolid'
import FunctionModal from '../FunctionModal';

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import DanhMuc from '../../assets/DanhMuc';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import CheckBox from './CheckBox';
import GroupChatContent from '../groupChat/GroupChatContent'
import * as globalActions from '../../reducers/global/globalActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as chatActions from '../../reducers/chat/chatActions';


const actions = [
    globalActions,
    chatActions,
    inboxActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupChat extends Component {
    constructor(props) {
        StatusBar.setBarStyle('dark-content');
        super(props);
        this.state = {
            loading: false,
            isOpenMoreModal: false,
        }
    }

    componentWillMount() {
        this.props.actions.onHideChatIconChange(true);
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderGroupChatHeader()}
                <FullLine />
                <GroupChatContent />
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={300}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
                {this._openMoreModal()}
            </View>
        )
    }

    _onMoreButtonPress() {
        Keyboard.dismiss();
        this.setState({ isOpenMoreModal: true });
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]} // 52*2 + 16
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {
       
        let items = [
            this.props.isSpam ? { _text: 'Đánh dấu không phải Spam', _function: () => this._onMarkDone(DanhMuc.hashInboxType['all']) }
            : { _text: 'Đánh dấu Spam', _function: () => this._onMarkDone(DanhMuc.hashInboxType['spam']) } ,            
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outMoreModal.bind(this)} />
        )
    }

    _renderGroupChatHeader() {
        return (
            <View style={styles.viewGroupChatHeader}>
                <TouchableOpacity style={styles.viewCloseLeft}
                    onPress={this._onPressClose.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor}/>
                </TouchableOpacity>
                <View style={styles.headerText}>
                    <Text numberOfLines={1} style={styles.textNameFriend}>{this.props.chatTitle}</Text>
                </View>
                <TouchableOpacity style={styles.viewCloseIcon}
                    onPress={this._onMoreButtonPress.bind(this)}
                >
                    <FontAwesomeSolid name={'ellipsis-h'}
                                      size={19}
                                      color={gui.mainColor}
                                      noAction={true}
                                      iconOnly={true}/>
                </TouchableOpacity>
            </View>
        );
    }

    _onMarkDone(spamStatus) {
        let userID = this.props.global.currentUser.userID;
        let token = this.props.global.currentUser.token;
        this.props.actions.markChatIsDoneOrSpam(this.props.chat.chatGroupID, userID, token, spamStatus)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {

                    if (spamStatus == DanhMuc.hashInboxType['all']) {
                        this.refs.toastTop && this.refs.toastTop.show(`Đã chuyển khỏi mục 'Spam'!`, DURATION.LENGTH_SHORT);
                    }
                    if (spamStatus == DanhMuc.hashInboxType['spam']) {
                        this.refs.toastTop && this.refs.toastTop.show(`Đã chuyển vào mục 'Spam'!`, DURATION.LENGTH_SHORT);
                    }
                }
            });
        this._outMoreModal();
    }

    _onPressClose() {
        //set lastSeen time for group inbox

        let lastSeen = this.props.inbox.lastSeen;
        if (lastSeen && lastSeen.length > 0) {
            lastSeen = lastSeen.filter((e) => { return e.chatGroupID != this.props.chat.chatGroupID })
            lastSeen.push({ chatGroupID: this.props.chat.chatGroupID, timestamp: new Date().getTime() })
        } else {
            lastSeen = [];
            lastSeen.push({ chatGroupID: this.props.chat.chatGroupID, timestamp: new Date().getTime() })
        }
        this.props.actions.updateLocalLastSeen(lastSeen);

        //clear unread message count of group inbox
        this.props.actions.clearUnreadCount({ chatGroupID: this.props.chat.chatGroupID });

        this.props.onGroupInbox && this.props.onGroupInbox(this.props.global.currentUser.userID);

        Actions.pop();
        // setTimeout(() => {
        //     this.props.actions.onHideChatIconChange(false);
        //     Actions.pop();
        // }, 300);
    }

    _onOpenMoreModal() { }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewGroupChatHeader: {
        height: 64,
        width: width,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewCloseLeft: {
        width: 40,
        height: 64,
        justifyContent: 'center',
        paddingLeft: 16,
        paddingTop: gui.marginTopAgent
    },
    viewCloseIcon: {
        width: 40,
        height: 64,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16,
        paddingTop: gui.marginTopAgent
    },
    headerText: {
        width: width - 80,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    textNameFriend: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.textPostAds,
        fontSize: 17
    },
    moreHeader: {
        position: 'absolute',
        right: 26
    },
    checkHeader: {
        position: 'absolute',
        right: 59
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupChat);