import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    TextInput,
    Switch,
    Keyboard,
    ScrollView,
    ImageBackground,
    Alert,
    FlatList,
    ListView
} from 'react-native';
import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/FontAwesome';
import GiftedSpinner from "../GiftedSpinner";
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Actions } from 'react-native-router-flux';
import DanhMuc from '../../assets/DanhMuc';
import FullLine from '../line/FullLine';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
var Contacts = require('react-native-contacts')
import CheckDot from '../detail/CheckDot';
import RangeUtils from '../../lib/RangeUtils';
import TextInputAuto from '../postAds/TextInputAuto';

import KeyboardSpacer from 'react-native-keyboard-spacer';
import Button from 'react-native-button';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import log from "../../lib/logUtil";
import Camera from 'react-native-camera';
import moment from 'moment';
const Permissions = require('react-native-permissions');
import ImageResizer from 'react-native-image-resizer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import RelandIcon from '../RelandIcon';
import cfg from "../../cfg";
import Toast, { DURATION } from '../toast/Toast';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';

import gui from '../../lib/gui';
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();


const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
class ModifyContact extends Component {
    constructor(props) {
        super(props);
        this.state = {
            notes: props.notes,
            toggleState: false,
        }
    }

    componentWillReceiveProps(nextProps) {
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeaderButton()}
                <FullLine/>
                <KeyboardAwareScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="none"
                    ref='scroll'
                    extraScrollHeight={30}
                >

                    <View style={{ backgroundColor:  gui.groupBackground, flex: 1 }}>
                        {this._renderContent()}
                        {this._renderLoadingView()}
                    </View>

                </KeyboardAwareScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                    style={[styles.searchButtonText2, {
                        textAlign: 'right', color: gui.mainColor,
                        backgroundColor: gui.doneKeyButton
                    }]}>Xong</Button> : null}
                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />

                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    }
    onKeyboardToggle(toggleState) {
        this.setState({ toggleState });
    }

    _renderLoadingView() {
        if (this.props.groupContact.savingContact) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderHeaderButton() {
        let addContact = this.props.action == 'edit' ? (this.props.noteID ? 'Sửa ghi chú' : 'Thêm ghi chú') : 'Ghi chú' ;
        let saveText = 'Lưu';
        let cancelText = 'Quay lại';
        if (this.props.groupContact.savingContact)
            return (
                <View style={styles.viewHeaderButton}>

                    <View style={styles.viewLeftIcon}>
                        <TouchableOpacity
                            onPress={this._onBackButton.bind(this)}
                        >
                            <Text style={styles.textSave}>{cancelText}</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.titleText}>
                        <Text style={styles.textContact}>{addContact}</Text>
                    </View>

                    <View style={styles.viewRightIcon}>
                        <Text style={styles.textSave}>{saveText}</Text>
                    </View>
                </View>
            )
        else
            return (
                <View style={styles.viewHeaderButton}>

                    <View style={styles.viewLeftIcon}>
                        <TouchableOpacity
                            onPress={this._onBackButton.bind(this)}
                        >
                            <Text style={styles.textSave}>{cancelText}</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.titleText}>
                        <Text style={styles.textContact}>{addContact}</Text>
                    </View>
                    <View style={styles.viewRightIcon}>
                        <TouchableOpacity onPress={this.onSaveNote.bind(this)}>
                            <Text style={styles.textSave}>{saveText}</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            );
    }


    onSaveNote() {
        if (!this.state.notes || !this.state.notes.trim()) {
            this.refs.toastTop && this.refs.toastTop.show(
                "Yêu cầu nhập nội dung ghi chú!", DURATION.LENGTH_LONG);
            return;
        }
            

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let contactDto = {
            "contactID": this.props.groupContact.selectedContact.contactID,
            "userID": currentUser.userID,
            "content": this.state.notes.trim(),
            "id": this.props.noteID
        }

        this.props.actions.saveContactNote(contactDto, token)
            .then(res => {
                let userID = this.props.global.currentUser.userID || undefined;
                let token = this.props.global.currentUser.token || undefined;

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                            this.setState({ noteID: '', notes: '', isOpenModalGhiChu: false })
                            Keyboard.dismiss();
                        }
                    }]);
                } else {
                    //clear input
                    // this.setState({ noteID:'', notes: '', isOpenModalGhiChu: false })
                    Keyboard.dismiss();

                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);
                    Actions.pop();
                    this.props.actions.getContactNote(
                        {
                            'userID': this.props.global.currentUser.userID,
                            'contactID': this.props.groupContact.selectedContact.contactID,
                        }
                        , (res) => {
                        }
                        , (error) => {
                        });
                }
            });
    }

    _renderContent() {
        return (
            <View style={styles.viewContent}>
                {this._renderNameInput()}
                <View style={styles.lineContent} />
            </View>
        );
    }

    _renderNameInput() {
        return (
            <View style={styles.viewNameInput}>
                <TextInputAuto
                    autoFocus={true}
                    autoCapitalize='none'
                    multiline={true}
                    autoCorrect={false}
                    returnKeyType='done'
                    underlineColorAndroid='rgba(0,0,0,0)'
                    secureTextEntry={false}
                    style={styles.nameInput}
                    placeholderTextColor={gui.colorMainBlur}
                    placeholder={'Nhập ghi chú'}
                    value={this.state.notes}
                    onChangeText={(text) => this._onNoteChange(text)}
                    onBlur={() => this.onBlurNamePost()}
                    maxLength={2000}
                />
            </View>
        )
    }


    onBlurNamePost() {
        Keyboard.dismiss();
    }


    _onNoteChange(value) {
        this.setState({
            notes: value
        })
    }

    _onBackButton() {
        Actions.pop();
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderButton: {
        height: 64,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewLeftIcon: {
        height: 64,
        width: 100,
        paddingTop: gui.marginTopAgent,
        paddingLeft: 16,
        justifyContent: 'center'
    },
    viewRightIcon: {
        height: 64,
        width: 100,
        paddingTop: gui.marginTopAgent,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'flex-end',
    },
    titleText: {
        height: 64,
        width: width - 200,
        paddingTop: gui.marginTopAgent,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textContact: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        color: gui.mainColor,
        fontWeight: '500',
    },
    viewTouchClose: {
        marginTop: 3
    },
    textSave: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor,
        fontWeight: 'normal'
    },
    viewAvatarContact: {
        height: 120,
        width: width,
        marginTop: 32,
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchAvatar: {
        height: 120,
        width: 120,
        borderRadius: 60,
        backgroundColor: 'rgba(82,97,115,0.1)',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewContent: {
        flex: 1,
        width: width,
        height: 'auto',
        marginTop: 8,
        backgroundColor: gui.groupBackground,
    },
    viewNameInput: {
        height: 'auto', //48,
        width: width - 32,
        backgroundColor: gui.groupBackground,
        flexDirection: 'row',
        marginLeft: 16,
        marginRight: 16,
        alignItems: 'center'
    },
    viewIcon: {
        height: 48,
        width: 48,
        justifyContent: 'center'
    },
    nameInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 48,
        borderColor: gui.mainTextColor,
        width: width - 32,
        textAlign: 'left',
        alignSelf: 'center',
        fontWeight: 'normal',
        color: gui.mainTextColor,
        marginBottom: 10
    },
    viewDotRight: {
        height: 48,
        width: 16,
        justifyContent: 'center'
    },
    dotContent: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: gui.dotColor
    },
    lineContent: {
        height: 1,
        width: width - 32,
        backgroundColor: 'rgba(211,211,211, 0.6)',
        marginLeft: 16,
        marginRight: 16
    },
    viewPotential: {
        height: 63,
        width: width,
        backgroundColor: gui.groupBackground,
        justifyContent: 'flex-end'
    },
    switchPotential: {
        height: 33,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        position: 'absolute',
        right: 0,
        bottom: 8
    },
    mimgList: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        // paddingLeft: 12,
        // paddingRight: 10,
        backgroundColor: 'white'
    },
    coverContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.8,
        bottom: 2,
        left: 2,
        alignSelf: 'auto'
    },
    coverText: {
        alignItems: 'center',
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    imgItem: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: "#1A526173",
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0
        // opacity: 0.8
        // marginLeft: 5,
        //borderColor: gui.separatorLine,
    },
    deleteContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.5,
        top: 10,
        right: 10,
        alignSelf: 'auto'
    },
    deleteButton: {
        alignItems: 'center'
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 180,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        position: 'absolute',
        bottom: 10,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent',

    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 106,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(ModifyContact);