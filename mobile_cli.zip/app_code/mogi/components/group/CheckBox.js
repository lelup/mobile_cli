import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

export default class CheckBox extends Component {
    render() {
        let selected = this.props.selected;
        let iconName =  selected ? 'check-box' : 'check-box-outline-blank';
        let iconColor = selected ? gui.mainColor : gui.mainTextColor;

        return (
            <TouchableOpacity onPress={() => this.props.onPress()} style={[styles.viewCheckFriends, this.props.checkBoxStyle]}>
                <MaterialIcons name={iconName} size={22} color={iconColor} />
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    viewCheckFriends: {
        height: 48,
        width: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
});