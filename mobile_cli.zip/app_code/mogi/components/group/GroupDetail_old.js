'use strict';
import React, { Component } from 'react';

import type, {
  StyleObj
} from 'react-native/Libraries/StyleSheet/StyleSheetTypes';

import {
  View, Text, StyleSheet, TextInput, ScrollView, ListView, TouchableOpacity, ViewPropTypes, StatusBar,
  ImageBackground, Alert, NetInfo, Image
} from 'react-native';
import Button from 'react-native-button';
import { Actions } from 'react-native-router-flux';
import ScalableText from 'react-native-text';

import { bindActionCreators } from 'redux';
import LinearGradient from 'react-native-linear-gradient';
import { connect } from 'react-redux';
import NonEditTag from './NonEditTag';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Modal from 'react-native-modalbox';
import SummaryText from '../SummaryText';
import CommonUtils from '../../lib/CommonUtils';
import Icon from 'react-native-vector-icons/FontAwesome';
import Communications from 'react-native-communications';
import GiftedSpinner from "../GiftedSpinner";

import Camera from 'react-native-camera';
var Analytics = require('react-native-firebase-analytics');

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const Permissions = require('react-native-permissions');
import ImageResizer from 'react-native-image-resizer';
import moment from 'moment';
import cfg from "../../cfg";
import Toast, { DURATION } from '../toast/Toast';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as chatActions from '../../reducers/chat/chatActions';
import DanhMuc from '../../assets/DanhMuc';
import MLikeTapButton2 from '../MLikeTapButton2';

import { GooglePlacesAutocomplete3 } from '../GooglePlacesAutocomplete3';
import RelandIcon from '../RelandIcon';


import { Map } from 'immutable';

import gui from "../../lib/gui";
import log from "../../lib/logUtil";

import HomeHeader from '../home/HomeHeader';

import MeContent from "../me/MeContent";
import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const actions = [
  globalActions,
  meActions,
  groupActions,
  chatActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

let hisTopUPDs = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
var count = 0;
var uploadFiles = [];
var errorMessage = '';

class GroupDetail_old extends React.Component {
  constructor(props) {
    super(props);
    let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(props.group.searchResult.listRelatedGroup);
    this.state = {
      textMessage: '',
      msgType: '',
      msgBgColor: null,
      msgTextColor: null,
      'data': null,
      loaded: false,
      modal: false,
      headerColor: 'transparent',
      headerButtonColor: 'white',
      sendButtonColor: 'white',
      backButtonColor: 'white',
      heartBgColor: '#4A443F',
      isChatLoading: false,
      diaBans: [],
      duAns: [],
      isOpenModalJoin: false,
      hashRelatedGroupStatus: hashRelatedGroupStatus,
      //joinStatus: props.joinStatus
      textToChuSan: props.group.textToChuSan
    }
  }


  _getHashRelatedGroupStatus(listRelatedGroup) {
    let hashRelatedGroupStatus = {};
    listRelatedGroup && listRelatedGroup.forEach((one) => {
      hashRelatedGroupStatus[one.groupID] = one.joinStatus;
    });
    return hashRelatedGroupStatus;
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.groupID !== this.props.groupID) {
      this.fetchData(nextProps);
    }

    if (nextProps.group.searchResult.listGroup !== this.props.group.searchResult.listGroup) {
      let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(nextProps.group.searchResult.listRelatedGroup);
      this.setState({
        hashRelatedGroupStatus: hashRelatedGroupStatus
      });
    }

    if (nextProps.group.textToChuSan !== this.props.group.textToChuSan) {
      this.setState({
        textToChuSan: nextProps.group.textToChuSan
      });
    }
  }

  componentWillMount() {

    this.fetchData(this.props);
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    let userID = this.props.global.currentUser.userID || undefined;
    //Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
  }

  fetchData(props) {
    if (props.groupData) {
      this.refreshRowData(props.groupData);
      return;
    }
    this.setState({ data: null, loaded: false });
    let deviceID = props.global.deviceInfo.deviceID || undefined;
    let userID = props.global.currentUser.userID || undefined;
    props.actions.getGroupDetail(
      { 'groupID': props.groupID }
      , (res) => {
        // console.log('server respond data: =====>>>>>', res)
        this.refreshRowData(res.data)
      }
      , (error) => {
        this.setState({ loaded: true });
        this._updateMessageProcessing(error, '#fa4916', 'white');
      });

  }


  _updateMessageProcessing(textMessage, bgColor, textColor) {
    this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
    this._onMsgAnimationStart();
  }

  _onMsgAnimationStart() {
    this.setState({ msgType: 'fadeInDown' });
    clearTimeout(this.msgTimer);
    this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
  }

  refreshRowData(group) {
    // console.log('bbbbbbb ========>', group.diaBan)
    let duAns = group.diaBan && group.diaBan.filter((e) => e.type == DanhMuc.placeType.DU_AN);
    let diaBans = group.diaBan && group.diaBan.filter((e) => e.type == DanhMuc.placeType.TINH || e.type == DanhMuc.placeType.HUYEN);

    this.setState({
      'data': group,
      duAns: duAns,
      diaBans: diaBans,
      loaded: true
    });

  }

  // state = {
  //   diaBans: [],
  //   duAns: [],
  //   allDiaChinh: []
  // };

  onChangeDiaBans = (diaBans) => {
    this.setState({
      diaBans,
    });
  };

  onChangeDuAns = (duAns) => {
    this.setState({
      duAns,
    });
  };

  // renderTabBar() {
  //   return <AdsMgmtTabBar />
  // }

  render() {

    // if (this.props.global.loggedIn) {

    return (
      <View style={{ flex: 1 }}>
        {this._renderHeader()}

        {this._renderJoining()}

        {this._renderContent()}

        {this._openImagePicker()}
        {this._openModalJoin()}
        {this._renderLoadingView()}
        <Toast
          ref="toastTop"
          position='top'
          positionValue={height / 2}
          fadeInDuration={850}
          fadeOutDuration={1400}
          opacity={0.56}
          textStyle={{ color: '#fff' }}
        />
      </View>
    )
    // } else {
    //   return (
    //     <Login />
    //   );
    // }
  };

  _renderHeader() {
    let rowData = this.state.data;
    if (!rowData) {
      return this._renderLoadingView();
    }

    let imageUri = { uri: rowData.image };
    if (!imageUri) {
      imageUri = require('../../assets/image/photo_detail_blank.jpg');
    }
    return (
      <View style={styles.headerView}>
        <ImageBackground style={styles.imgItem2}
          source={imageUri} defaultSource={CommonUtils.getNoCoverImage()}>
          <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
            style={styles.linearGradient}>
            <View style={styles.cancelView}>
              <TouchableOpacity onPress={this._onBackPress.bind(this)}>
                <MaterialCommunityIcons name="close" size={24} color={'#fff'} />
              </TouchableOpacity>
            </View>
            <View style={styles.headerView2}>
              <ScalableText style={[styles.headerText]} numberOfLines={2}>{rowData.name}</ScalableText>
            </View>
            <View style={styles.headerView3}>
              <Text style={[styles.headerText2]}>{rowData.countMember} Thành viên</Text>
            </View>
          </LinearGradient>
        </ImageBackground>

      </View>
    );
  }
  _onBackPress() {
    Actions.pop();
  }

  _renderLoadingView() {
    if (this.props.group.requestingJoin) {
      return (<View style={styles.resultContainer}>
        <GiftedSpinner size='large' color="grey" />
      </View>)
    }
  }

  _renderJoining() {
    if (this.props.owner == 'GroupMgmt') {
      if (this.props.group.selectedGroupTab == 'sanQuanLy') {
        return null;
      }
      if (this.props.group.selectedGroupTab == 'sanYeuCau') {
        return (
          <TouchableOpacity onPress={this._onCancelJoin.bind(this)}>
            <View style={styles.joiningView}>

              <View style={styles.joinButton}>
                <Icon name="plus-circle" size={20} color="#526173" />
              </View>
              <View style={styles.joiningView2}>
                <Text style={[styles.joinText]}>Hủy yêu cầu</Text>
              </View>


            </View>
          </TouchableOpacity>
        );
      }
      if (this.props.group.selectedGroupTab == 'sanThamGia') {
        return (
          <TouchableOpacity onPress={this._onLeaveGroup.bind(this)}>
            <View style={styles.joiningView}>

              <View style={styles.joinButton}>
                <Icon name="plus-circle" size={20} color="#526173" />
              </View>
              <View style={styles.joiningView2}>
                <Text style={[styles.joinText]}>Rời khỏi sàn</Text>
              </View>


            </View>
          </TouchableOpacity>
        );
      }
    }
    return null;
  }

  labelExtractor = (tag) => tag;

  onLayoutLastTag = (endPosOfTag: number) => {
    const margin = 3;
    this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
    const inputWidth = GroupDetail.inputWidth(
      this.state.text,
      this.spaceLeft,
      this.wrapperWidth,
    );
    if (inputWidth !== this.state.inputWidth) {
      this.setState({ inputWidth });
    }
  }

  static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
    if (text === "") {
      return 90;
    } else if (spaceLeft >= 100) {
      return spaceLeft - 10;
    } else {
      return wrapperWidth;
    }
  }

  removeDiaBan = (index: number) => {

  }

  removeDuAn = (index: number) => {
  }

  _renderLoaiNhom() {
    let rowData = this.state.data;
    if (!rowData) {
      return this._renderLoadingView();
    }
    return (
      <View style={styles.blockView}>
        <Text style={[styles.titleText]}>Loại nhóm</Text>
        <View style={{ marginTop: 11 }}>
          <Text style={[styles.headerText2, { color: gui.colorMainBlur }]}>{DanhMuc.groupType[rowData.groupType]}</Text>

        </View>
      </View>
    )
  }

  _renderMoTa() {
    let rowData = this.state.data;
    if (!rowData) {
      return this._renderLoadingView();
    }


    let joinStatus = this.state.hashRelatedGroupStatus[rowData.groupID];
    let statusFmt = DanhMuc.groupStatus[joinStatus] || '';

    // let joinStatus = this.props.joinStatus;
    // let statusFmt = DanhMuc.groupStatus[joinStatus] || '';
    return (
      <View style={styles.blockView}>
        <View style={styles.viewTopJoin}>
          <View>
            <Text style={[styles.titleText]}>Mô tả</Text>
          </View>
          <View style={styles.viewButtonJoin}>
            {joinStatus != 1 && joinStatus != 2 ?
              (<TouchableOpacity style={styles.touchJoinGroup}
                onPress={this._onJoinGroupPress.bind(this)}
              >
                <Text style={styles.groupStatus}>Tham gia</Text>
              </TouchableOpacity>)
              : null
            }
          </View>
        </View>
        <View style={{ marginTop: 11 }}>
          <SummaryText
            style={{ color: gui.colorMainBlur }}
            textProps={{
              fontWeight: 'normal',
              fontFamily: gui.fontFamily,
              color: gui.colorMainBlur,
              fontSize: 15
            }}
            //longText="Cong hoa xa hoi chu nghia viet na. doc lap tu do hanh phich. linh nhan ngauyen bach. Cong hoa xa hoi chu nghia viet na. doc lap tu do hanh phich. linh nhan ngauyen bachong hoa xa hoi chu nghia viet na. doc lap tu do hanh phich. linh nhan nga. oc lap tu do hanh phich. linh nhan ngauyen bach. Cong hoa xa hoi chu nghia viet na. doc lap tu do hanh phich. linh nhan ngauyen bachong hoa xa hoi chu nghia viet na. doc lap tu do hanh phich. linh nhan ngao ngao"
            longText={rowData.chiTiet}
            expanded={false}
            maxLength={130}
            width={width - 43}>
          </SummaryText>
        </View>
      </View>
    )
  }

  _onJoinGroupPress() {
    this.setState({
      isOpenModalJoin: true
    });
  }

  _onLeaveGroup() {

  }

  _onCancelJoin() {

  }

  _onModalJoin() {
    //this.refs.modalSapxep.open();
    // if (this.state.isFront) {
    this.setState({ isOpenModalJoin: true });
    // }
  }

  _onContentModal() {
    this.setState({
      isOpenModalJoin: false
    });
  }

  _openModalJoin() {
    return (
      <Modal isOpen={this.state.isOpenModalJoin}
        onClosed={this._onContentModal.bind(this)}
        style={styles.viewModalStyle2}
        position={"center"}
        swipeToClose={false}
        backdropPressToClose={true}
        animationDuration={200}
      >
        {this._renderJoinContent()}
      </Modal>
    );

  }

  _renderChuSan() {
    let rowData = this.state.data;
    if (!rowData) {
      return this._renderLoadingView();
    }
    let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
    let avatarUri = rowData.avatar ? { uri: rowData.avatar } :
      defaultAvatar;

    return (
      <View style={styles.blockView}>
        <Text style={[styles.titleText]}>Chủ sàn</Text>
        <View style={[styles.viewChuSan]}>
          <View style={styles.iconChuSan}>
            <Image style={styles.iconChuSan} source={avatarUri}
              defaultSource={defaultAvatar} />
          </View>
          <View style={styles.tenChuSan}>
            <View style={styles.viewTen}>
              <Text numberOfLines={1} style={styles.textTen}>{rowData.fullNameChuSan}</Text>
            </View>
            {rowData.phoneChuSan ?
              <View style={styles.viewPhone}>
                <Text numberOfLines={1} style={styles.textPhone}>{rowData.phoneChuSan}</Text>
              </View> : null
            }
          </View>
          <View style={styles.phone}>
            <TouchableOpacity onPress={this._onPhoneClicked.bind(this)}>
              <Icon name="phone" size={18} color="#526173" />
            </TouchableOpacity>
          </View>
          <View style={styles.chat}>
            <TouchableOpacity onPress={this._onChatClicked.bind(this)}>
              <Icon name="comments" size={18} color="#526173" />
            </TouchableOpacity>
          </View>
        </View>

      </View>
    )
  }

  _onPhoneClicked() {
    let rowData = this.state.data;
    if (!rowData.phoneChuSan) {
      return;
    }

    let userID = null;
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    if (this.props.global.loggedIn) {
      let currentUser = this.props.global.currentUser;
      userID = currentUser && currentUser.userID;
    }
    Communications.phonecall(rowData.phoneChuSan, true);
    Analytics.logEvent('DETAIL_DIALING', { deviceID: deviceID, userID: userID, phone: rowData.phoneChuSan });
  }

  _onChatClicked() {
    let data = this.state.data;
    // console.log('GroupDetail._onChatClicked: data ===============>>>>', data);
    let partnerID = data.userID || data.member || data.createdBy;
    let partner = { userID: partnerID };
    let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');
    if (this.props.global.currentUser.userID == partner.userID) {
      Alert.alert("Thông báo", 'Bạn không thể chat với chính mình.', [{ text: 'Đóng', onPress: () => { } }]);
      return;
    }
    this.props.actions.startFriendChat(this.props.global.currentUser,
      partner).then((e) => {
        // console.log('GroupDetail startFriendChat ee: ',e)
        let isSpam = false;
        if (e.partners)
          e.partners.forEach((pn) => {
            if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
              isSpam = true;
          })
        Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
      });
  }

  _onTypeClicked(value) {
    this.setState({
      groupType: value
    });
  }

  _renderKhuVuc() {
    // console.log('aaaaaaa=========>', this.state.diaBans)
    var tags = this.state.diaBans && this.state.diaBans.map((tag, index) => (
      <NonEditTag
        type="DiaChinh"
        index={index}
        label={tag.placeName}
        isLastTag={this.state.diaBans.length === index + 1}
        tagContainerStyle={{ marginBottom: 3 }}
        onLayoutLastTag={this.onLayoutLastTag}
        removeIndex={this.removeDiaBan.bind(this)}
        tagColor='#dddddd'
        tagTextColor='#777777'
        //tagContainerStyle={ViewPropTypes.style}
        //tagTextStyle={Text.propTypes.style}
        key={index}
      />
    ))

    return (
      <View style={styles.blockView2}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Khu vực</ScalableText>
        </View>

        <View style={styles.tagInputContainer}>{tags}</View>


      </View>
    )
  }

  _renderPhoto() {
    let { photos } = this.state;
    if (!photos) {
      photos = [];
    }
    let numOfPhoto = photos.length;
    let indexArr = [];
    for (let i = 0; i <= photos.length; i++) {
      if (i < 1) {
        indexArr.push(i)
      }
    }

    return (
      <View>
        <View style={[styles.mimgList, { marginTop: 10, marginBottom: 5, paddingLeft: 17, paddingRight: 15 }]} >
          {indexArr.map((e) => { if (e < 1) return this._renderPhotoItem(e) })}
        </View>
      </View>
    );
  }

  _outModalImagePicker() {
    this.setState({
      isOpenImagePicker: false
    });
  }

  _openImagePicker() {
    return (
      <Modal isOpen={this.state.isOpenImagePicker}
        onClosed={this._outModalImagePicker.bind(this)}
        style={styles.viewModalStyle}
        position={"bottom"}
        swipeToClose={false}
        animationDuration={200}
      >
        {this._renderModalImagePicker()}
      </Modal>
    );
  }

  _renderModalImagePicker() {
    return (
      <View style={styles.viewShowModal}>
        <View style={styles.viewSwipeButton}>
          <TouchableOpacity onPress={this.onCamera.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
            <Text style={[styles.textDelete, { color: gui.mainColor }]}>Máy ảnh</Text>
          </TouchableOpacity>
          <View style={styles.lineSpaceButton}></View>
          <TouchableOpacity onPress={this.onCameraRollView.bind(this)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
            <Text style={[styles.textDelete, { color: gui.mainColor }]}>Bộ sưu tập</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={this._outModalImagePicker.bind(this)} style={styles.viewSwipeButton2}>
          <Text style={[styles.textDelete, { color: gui.mainColor, fontWeight: '500', fontSize: 18 }]}>Hủy</Text>
        </TouchableOpacity>
      </View>
    )
  }

  _renderJoinContent() {
    return (
      <View style={styles.viewDetailModal}>
        <View style={{ marginTop: 18, marginLeft: 0, width: width - 80, height: 108 }}>
          <TextInput
            autoFocus={false}
            autoCapitalize='none'
            autoCorrect={false}
            returnKeyType='done'
            multiline={true}
            style={styles.viewTextInput}
            placeholder="Để lại ghi chú cho chủ sàn…" placeholderTextColor={gui.arrowColor}
            onChangeText={(text) => { this.onValueChange("textToChuSan", text) }}
            value={this.state.textToChuSan}

          />
        </View>
        {this._renderButtonJoin()}
      </View>
    )
  }

  _renderButtonJoin() {
    if (this.props.group.requestingJoin)
      return (<View style={styles.searchButtonView}>
        <View
          style={styles.searchButton}
        >
          <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
        </View>
      </View>)
    return (
      <View style={styles.searchButtonView}>
        <TouchableOpacity
          style={styles.searchButton}
          onPress={this.onRequestJoin.bind(this)}
        >
          <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
        </TouchableOpacity>
      </View>
    )

  }

  onRequestJoin() {

    let rowData = this.state.data;
    if (!rowData) {
      return;
    }

    let currentUser = this.props.global.currentUser;
    let token = currentUser.token;

    let requestJoinDto = {
      "requester": currentUser.userID || undefined,
      "requesterName": currentUser.fullName || currentUser.phone || currentUser.email || undefined,
      "approver": rowData.userID || rowData.createdBy || undefined,
      "member": currentUser.userID || undefined,
      "memberName": currentUser.fullName || undefined,
      "memberNameKhongDau": utils.locDauV2(utils.standardlizeName(currentUser.fullName)),
      "memberAvatar": currentUser.avatar || undefined,
      "groupID": rowData.groupID || undefined,
      "groupName": rowData.name || undefined,
      "groupImage": rowData.image || undefined,
      "message": this.state.textToChuSan
    };

    let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
    let fetchRelatedGroupSuccess = this.props.actions.fetchRelatedGroupSuccess;

    this.props.actions.requestToJoin(requestJoinDto, token)
      .then(res => {
        // console.log("server respond: ", res);
        this.setState({
          loading: false,
          isOpenModalJoin: false
        });

        if (res.status != 0) {
          Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
        } else {
          // Actions.popTo('root');
          // Actions.AdsMgmt();

          rowData.joinStatus = 1;
          let found = listRelatedGroup.find((one) => {
            return one.groupID == rowData.groupID
          });
          if (found) {
            listRelatedGroup = listRelatedGroup.filter((one) => {
              return one.groupID != rowData.groupID
            });
          }
          listRelatedGroup = [...listRelatedGroup, rowData];
          fetchRelatedGroupSuccess(listRelatedGroup);

          let hashRelatedGroupStatus = this.state.hashRelatedGroupStatus;
          hashRelatedGroupStatus[rowData.groupID] = 1;
          this.setState({ hashRelatedGroupStatus: hashRelatedGroupStatus });

          setTimeout(
            () =>
              this.refs.toastTop && this.refs.toastTop.show("Xác nhận yêu cầu tham gia sàn được gửi thành công và đang chờ duyệt.", DURATION.LENGTH_LONG), 500)
            ;
        }
      });
  }

  onCamera() {
    Camera.checkDeviceAuthorizationStatus().then(
      (e) => {
        if (e) {
          Actions.Group2({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
        } else {
          Alert.alert("Thông báo", gui.INF_CameraAccess);
        }
      });
  }

  onCameraRollView() {
    Permissions.requestPermission('photo')
      .then(response => {
        if (response == 'authorized') {
          Actions.CameraRollView3({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
        } else {
          Alert.alert("Thông báo", gui.INF_PhotoAccess);
        }
      });
  }

  _renderPhotoItem(imageIndex) {
    let { photos } = this.state;
    // console.log('photos =========>>>', photos);
    if (!photos) {
      photos = [];
    }
    let photo = photos[imageIndex];

    return (
      <ImageItem imageIndex={imageIndex}
        key={imageIndex}
        photo={photo}
        onTakePhoto={this.onTakePhoto.bind(this)}
        onDeletePhoto={this.onDeletePhoto.bind(this)} />
    )
  }

  _renderDuAn() {
    var tags = this.state.diaBans && this.state.duAns.map((tag, index) => (
      <NonEditTag
        type="DuAn"
        index={index}
        label={tag.placeName}
        isLastTag={this.state.duAns.length === index + 1}
        onLayoutLastTag={this.onLayoutLastTag}
        removeIndex={this.removeDuAn.bind(this)}
        tagColor='#dddddd'
        tagTextColor='#777777'
        key={index}
      />
    ))
    return (
      <View style={styles.blockView2}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Dự án</ScalableText>
        </View>

        <View style={styles.tagInputContainer}>{tags}</View>
      </View>
    )
  }

  _renderContent() {
    return (
      <ScrollView
        contentContainerStyle={styles.scrollView}
        automaticallyAdjustContentInsets={true}
        style={styles.contentView}>

        {/* ======== */}
        {this._renderMoTa()}

        {/* ======== */}
        {this._renderLoaiNhom()}


        {/* ======== */}
        {this._renderKhuVuc()}

        {/* ======== */}
        {this._renderDuAn()}

        {this._renderChuSan()}

      </ScrollView>

    )
  }

  _onPress(data) {
    // log.enter("DinhGiaPlacesAutocomplete._onPress", data);
    this._collectSuggestionInfo(data);
    Actions.pop();
  }

  _updateBarColor() {
    // if (this.props.owner != 'home') {
    //   StatusBar.setBarStyle('light-content');
    // }
    StatusBar.setBarStyle('default');
  }

  _onCancelPress() {
    Actions.pop();
    this._updateBarColor();
  }

  _renderPlaceAutoComplete() {
    let predefinedPlaces = [
      ...this.props.search.saveSearchList,
      ...this.props.search.recentSearchList
    ];
    return (
      <View style={[styles.fullWidthContainer, { backgroundColor: 'black' }]}>
        <MPlacesAutoComplete
          ref={'placeSuggestion'}
          onSelectPress={this._onPlacePress.bind(this)}
          onCancelPress={this._onCancelPress.bind(this)}
          predefinedPlaces={predefinedPlaces}
        />
      </View>
    )
  }

  onValueChange(key: string, value: string) {
    // this.props.actions.onGroupFieldChange(key, value);
    this.setState({ textToChuSan: value })
  }

  onDiaBanChange(diaBan) {
    // let newDiaBan = this.props.group.diaBan;
    // newDiaBan.push(...diaBan);
    // this.props.actions.onGroupFieldChange('diaBan', newDiaBan);
  }

  _renderLine() {
    return (
      <View style={styles.viewLine}></View>
    );
  }

  _renderButton() {
    return (
      <View style={styles.searchButtonView}>
        <TouchableOpacity
          style={styles.searchButton}
          onPress={this.onPostGroup.bind(this)}
        >
          <Text style={styles.searchButtonText}>HOÀN TẤT</Text>
        </TouchableOpacity>
      </View>
    )
  }

  onPostGroup() {
    let { photos, place } = this.props.group;
    errorMessage = '';
    uploadFiles = [];
    for (let i = 0; i < photos.length; i++) {
      let filepath = photos[i].uri;
      if (filepath == '') {
        continue;
      }
      uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
    }
    if (!this.isValidInputData()) {
      this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
      this.props.actions.onGroupFieldChange('error', errorMessage);
      return;
    }

    this.onPostGroupChecked();

  }

  isValidInputData() {
    let errors = '';
    // if (uploadFiles.length === 0) {
    //     errors += ' (ảnh)';
    // }
    // console.log("picaso==============>", this.props.group);

    let { name, groupType } = this.props.group;

    //let geo = place && place.geo;    
    // if (!geo || !geo.lat || isNaN(geo.lat)
    //     || !geo.lon || isNaN(geo.lon)) {
    //     errors += ' (địa điểm/dự án)';
    // }

    if (!name) {
      errors += ' (tên)';
    }
    if (!groupType) {
      errors += ' (loại nhóm)';
    }

    if (errors != '') {
      errorMessage = 'Bạn chưa chọn' + errors + '!';
      return false;
    }
    // if (gia && isNaN(gia)) {
    //     errors += ' (giá)';
    // }

    // if (errors != '') {
    //     errorMessage = 'Sai kiểu giá trị:' + errors + '!';
    //     return false;
    // }
    return true;
  }

  onPostGroupChecked() {
    let { photos } = this.props.group;
    errorMessage = '';
    uploadFiles = [];
    for (let i = 0; i < photos.length; i++) {
      let filepath = photos[i].uri;
      if (filepath == '') {
        continue;
      }
      uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
    }

    this.props.actions.onGroupFieldChange("uploading", true);

    let countUpdateFiles = this.countNeedUploadFiles();
    if (!countUpdateFiles) {
      this.onSaveGroup();
      return;
    }

    count = 0;
    const userID = this.props.global.currentUser.userID;
    for (let i = 0; i < uploadFiles.length; i++) {
      if (errorMessage != '') {
        Alert.alert('Thông báo', errorMessage);
        this.props.actions.onGroupFieldChange('error', errorMessage);
        return;
      }
      let needUpload = uploadFiles[i].needUpload;
      if (!needUpload) {
        continue;
      }
      let index = uploadFiles[i].index;
      let filepath = uploadFiles[i].filepath;
      ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
        let ms = moment().toDate().getTime();
        let filename = 'Group_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
        this.props.actions.onUploadGroupImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this));
      }).catch((err) => {
        this.props.actions.onGroupFieldChange("uploading", false);
        log.error(err);
      });
    }
  }

  countNeedUploadFiles() {
    let count = 0;
    for (let i = 0; i < uploadFiles.length; i++) {
      let file = uploadFiles[i];
      if (file.needUpload) {
        count++;
      }
    }
    return count;
  }

  uploadCallBack = function (err, result, index) {
    let data = result && result.data ? result.data : '';
    if (err || data == '') {
      errorMessage = 'Upload ảnh không thành công!';
      this.props.actions.onGroupFieldChange('error', errorMessage);
      this.props.actions.onGroupFieldChange("uploading", false);
      return;
    }
    try {
      let { success, file } = JSON.parse(data);
      if (success) {
        let { url } = file;
        this.state.uploadUrls.push({ index: index, url: url });
        count++;
        if (count == this.countNeedUploadFiles()) {
          this.onSaveGroup();
        }
      } else {
        errorMessage = 'Upload ảnh không thành công!';
        this.props.actions.onGroupFieldChange('error', errorMessage);
        this.props.actions.onGroupFieldChange("uploading", false);
      }
    } catch (error) {
      errorMessage = 'Upload ảnh không thành công!';
      this.props.actions.onGroupFieldChange('error', errorMessage);
      this.props.actions.onGroupFieldChange("uploading", false);
    }
  }

  onSaveGroup() {
    let { uploadUrls } = this.state;
    let { name, chiTiet, photos, allDiaChinh } = this.props.group;

    let imageUrls = [];
    for (let i = 0; i < photos.length; i++) {
      let photo = photos[i];
      imageUrls.push(photo.uri);
    }
    for (let i = 0; i < uploadUrls.length; i++) {
      let uploadUrl = uploadUrls[i];
      let index = uploadUrl.index;
      if (index >= 0) {
        imageUrls[index] = uploadUrl.url;
      }
    }
    let image = undefined;
    if (imageUrls.length > 0) {
      image = imageUrls[0];
    }

    let currentUser = this.props.global.currentUser;
    let token = currentUser.token;


    let ngayDangTin = moment().format('YYYYMMDD');

    let groupDto = {
      "name": name || undefined,
      "groupType": this.state.groupType,
      "chiTiet": chiTiet,
      "createdBy": currentUser.userID,
      "image": image,
      "diaBan": this.state.allDiaChinh
    };

    this.props.actions.postGroup(groupDto, token)
      .then(res => {
        // console.log("server respond: ", res);
        this.setState({
          loading: false
        });

        if (res.status != 0) {
          Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
        } else {
          // Actions.popTo('root');
          // Actions.AdsMgmt();

          let groupID = this.state.groupID;
          if (groupID && groupID.length > 0) {
            setTimeout(() => Alert.alert("Thông báo", "Thay đổi thành công."), 1000);
          } else {
            setTimeout(() => Alert.alert(
              "Thông báo",
              "Xác nhận tạo nhóm môi giới thành công và đang chờ duyệt trước khi được đưa lên landber.",
              [{ text: 'Đóng', onPress: () => { } }]), 1000);
          }
        }
      });
  }

  _renderListDiaBan() {
    let topup = this.props.group.diaBan;
    let data = topup;
    let dsUp = hisTopUPDs.cloneWithRows(data);
    return (
      <ListView
        style={styles.listStyle}
        scrollEnabled={false}
        horizontal={true}
        enableEmptySections={true}
        dataSource={dsUp}
        renderRow={this._renderRowDiaBan.bind(this)}
        contentContainerStyle={styles.viewListContainer}
      />
    )
  }

  _renderRowDiaBan(data) {
    return (
      <View style={styles.rowDiaBan}>
        <Text style={[{ textAlign: 'right', marginRight: 5 }]}>{data}</Text>
      </View>
    )
  }

  _getPlaceByLocation(lat, lon, callback) {
    findApi.getPlaceByLocation(lat, lon).then((res) => {
      if (res.success) {
        callback(res.result);
      }
    });
  }

  _collectSuggestionInfo(position) {
    if (position.placeType == DanhMuc.placeType.DIA_DIEM) {
      this._getPlaceByLocation(position.location.lat, position.location.lon, (res) => {
        if (res) {
          let diaChinh = {
            codeDuAn: undefined,
            codeDuong: undefined,
            codeXa: res.codeXa || undefined,
            codeHuyen: res.codeHuyen || undefined,
            codeTinh: res.codeTinh || undefined,
            duAn: undefined,
            duong: undefined,
            xa: res.xa || position.xaName || undefined,
            huyen: res.huyen || position.huyenName || undefined,
            tinh: res.tinh || position.tinhName || undefined,
          };
          this._updateDiaChinhDuAn(position, diaChinh);
        }
      });
    } else {
      let diaChinh = {
        codeDuAn: position.duAn || undefined,
        codeDuong: position.duong || undefined,
        codeXa: position.xa || undefined,
        codeHuyen: position.huyen || undefined,
        codeTinh: position.tinh || undefined,
        duAn: position.duAnName || undefined,
        duong: position.duongName || undefined,
        xa: position.xaName || undefined,
        huyen: position.huyenName || undefined,
        tinh: position.tinhName || undefined,
        type: position.placeType,
        placeName: position.placeName
      };
      this._updateDiaChinhDuAn(position, diaChinh);
    }
  }

  _updateDiaChinhDuAn(position, diaChinh) {
    let codeDuAn = position.duAn || '';
    let fullName = codeDuAn ? 'Dự Án ' + position.fullName : position.fullName;
    // console.log('==== position, ', position);
    // console.log('==== diaChinh, ', diaChinh);

    this.setState({ allDiaChinh: [...this.state.allDiaChinh, diaChinh] });
    // console.log('neew diachinh added', this.state.allDiaChinh);

    if (diaChinh.type == DanhMuc.placeType.DU_AN)
      this.setState({ duAns: [...this.state.duAns, diaChinh] });
    if (diaChinh.type == DanhMuc.placeType.TINH
      || diaChinh.type == DanhMuc.placeType.HUYEN
      || diaChinh.type == DanhMuc.placeType.XA)
      this.setState({ diaBans: [...this.state.diaBans, diaChinh] });

    // this.setState({
    //   codeDuAn: diaChinh.codeDuAn,
    //   codeDuong: diaChinh.codeDuong,
    //   codeXa: diaChinh.codeXa,
    //   codeHuyen: diaChinh.codeHuyen,
    //   codeTinh: diaChinh.codeTinh,
    //   duAn: diaChinh.duAn,
    //   duong: diaChinh.duong,
    //   xa: diaChinh.xa,
    //   huyen: diaChinh.huyen,
    //   tinh: diaChinh.tinh
    // });
  }
  onTakePhoto(imageIndex) {
    this.props.actions.onGroupFieldChange('imageIndex', imageIndex);
    // Actions.PostAds();
    this._openModalImagePicker();
  }

  _openModalImagePicker() {
    dismissKeyboard();
    this.setState({ isOpenImagePicker: true });
  }

  onDeletePhoto(imageIndex) {
    let { photos } = this.state;
    photos.splice(imageIndex, 1);
    this.setState({ deletedPhoto: imageIndex });
    this.props.actions.onGroupFieldChange('photos', photos);
  }

}

class ImageItem extends React.Component {
  constructor(props) {
    super(props);
  }

  _onPhotoPressed() {
    this.props.onTakePhoto(`${this.props.imageIndex}`);
  }

  _onDeletePhoto() {
    this.props.onDeletePhoto(`${this.props.imageIndex}`);
  }

  _renderCoverTitle() {
    if (this.props.imageIndex == 0)
      return (
        <View style={styles.coverContent}>
          <Text style={styles.coverText}>
            Ảnh nhóm
              </Text>
        </View>
      )
  }

  _renderDeleteButton() {
    if (this.props.imageIndex != 0)
      return (
        <TouchableOpacity
          style={styles.deleteContent}
          onPress={this._onDeletePhoto.bind(this)} >

          <View style={styles.deleteButton}>
            <RelandIcon name="close" color={'black'}
              mainProps={styles.captureIcon}
              size={10} textProps={{ paddingLeft: 0 }}
              noAction={true}
            />
          </View>
        </TouchableOpacity>
      )
  }

  render() {
    log.info("Group.render ");
    let photo = this.props.photo;

    if (photo && photo.uri) {
      return (
        <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
          <ImageBackground style={styles.imgItem} source={photo} >
            {this._renderDeleteButton()}
            {this._renderCoverTitle()}
          </ImageBackground>
        </TouchableOpacity>
      );
    } else {
      return (
        <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
          <View style={[styles.imgItem, { borderStyle: 'dashed', borderColor: gui.mainColor, borderWidth: 1 }]}>
            <RelandIcon name="plus" color={gui.mainColor}
              mainProps={styles.captureIcon}
              size={22} textProps={{ paddingLeft: 0 }}
              noAction={true}
            />
            {this._renderCoverTitle()}
          </View>
        </TouchableOpacity>
      );
    }

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(GroupDetail_old);

var styles = StyleSheet.create({
  headerView: {
    backgroundColor: 'green',
    height: 188,
    width: width
  },
  joiningView: {
    backgroundColor: '#FFFFFFFF',
    height: 56,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    shadowColor: '#1A526173',
    shadowOffset: { width: 0, height: 1 },
    // shadowRadius: 2,
    shadowOpacity: 0,
    borderBottomWidth: 1,
  },
  joiningView2: {
    backgroundColor: 'transparent',
    height: 24,
    width: 128,
    marginLeft: 10
  },
  contentView: {
    width: width,
    height: height - 80 - 135.4 - 49,
    backgroundColor: "#f2f2f2",
    flexGrow: 1
  },
  scrollView2: {
    flexGrow: 1,
    position: 'absolute',
    height: height - 44
  },
  cancelView: {
    backgroundColor: 'transparent',
    marginTop: 40,
    marginLeft: 16,
    width: 24,
    height: 24
  },
  joinButton: {
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    width: 20,
    height: 20
  },
  dotView: {
    backgroundColor: 'lightgrey',
    // marginRight: 8,
    // marginTop: 6,
    width: 8,
    borderRadius: 4,
    height: 8
  },
  parentDotView: {
    width: 56,
    paddingRight: 8,
    height: 20,
    justifyContent: 'center',
    alignItems: 'flex-end'
  },
  headerView2: {
    backgroundColor: 'transparent',
    marginTop: 10,
    marginLeft: 16,
    width: width - 32,
    // height: 36
  },
  headerView3: {
    backgroundColor: 'transparent',
    marginTop: 4,
    marginLeft: 16,
    width: width - 16,
    height: 20
  },
  headerText2: {
    fontSize: 15,
    fontWeight: 'normal',
    fontFamily: gui.fontFamily,
    color: '#FFFFFFFF'
  },
  headerText: {
    fontSize: 24,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#FFFFFFFF'
  },
  joinText: {
    fontSize: 17,
    fontWeight: 'normal',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  viewTen: {
    // height: 24,
    width: width - 170
  },
  viewPhone: {
    // height: 20,
    width: width - 170
  },
  textTen: {
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  textPhone: {
    fontSize: 15,
    fontWeight: 'normal',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  titleView: {
    height: 24
  },
  titleText: {
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  pickCard: {
    height: 57,
    width: (width - 32) / 2,
    borderWidth: 1,
    borderColor: '#1BA7DF',
    justifyContent: 'center',
    alignItems: 'center'
  },
  blockView: {
    width: width - 32,
    // height: 97,
    marginTop: 23,
    marginLeft: 16,
    //backgroundColor: 'lightgrey'
  },
  blockView2: {
    width: width - 32,
    marginTop: 23.6,
    marginLeft: 16,
    height: 'auto',
    //backgroundColor: 'lightgrey'
  },
  viewTags: {
    marginTop: 18,
    marginLeft: 0,
    height: 'auto',
    width: width - 32
  },
  viewChuSan: {
    marginTop: 17,
    marginLeft: 0,
    height: 48,
    width: width - 32,
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row'
  },
  viewTextInput: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    width: width - 80
  },
  viewLine: {
    borderTopWidth: 0.5,
    height: 1,
    borderColor: "#99526173",
    marginLeft: 0,
    marginTop: 11,
    width: width - 32,
    opacity: 0.6
  },
  searchButtonView: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    height: 48,
    bottom: 17,
    width: width,
    backgroundColor: 'transparent',
    //borderRadius: 24
  },
  searchButton: {
    height: 48,
    width: width - 64,
    backgroundColor: '#1BA7DF',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center'
  },
  scrollView: {
    backgroundColor: gui.groupBackground,
    paddingBottom: 50,
    justifyContent: 'flex-start',
    alignItems: 'stretch',
  },

  searchButtonText: {
    color: '#FFFFFFFF',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  container: {
    backgroundColor: "#f2f2f2",
    flex: 1
  },

  label: {
    fontSize: 15,
    fontWeight: "bold"
  },
  tagInputContainer: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  header: {
    backgroundColor: gui.mainColor,
    height: 64
  },
  viewListContainer: {
    // paddingBottom: 50
  },
  listStyle: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  rowDiaBan: {
    flex: 1,
    justifyContent: 'flex-start',
    // height: 100,

    // flexDirection: 'column'
  },

  input: {
    fontSize: 15,
    width: 200,
    height: 30,
    borderWidth: 1,
    alignSelf: 'center',
    padding: 5

  },
  viewTabInterest: {
    flexGrow: 1,
    flexDirection: 'row',
    width: width - 32,
    height: 57,
    marginTop: 23.6,
    //marginLeft: 16,
  },
  tab1: {
    height: 57,
    width: (width - 32) / 2,
    //borderColor: '#1A526173',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderLeftWidth: 1,

  },
  tab2: {
    height: 57,
    width: (width - 32) / 2,
    //borderColor: '#1A526173',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderRightWidth: 1,
  },
  mimgList: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    paddingLeft: 12,
    paddingRight: 10,
    backgroundColor: 'white'
  },
  coverContent: {
    position: 'absolute',
    backgroundColor: 'white',
    opacity: 0.8,
    bottom: 2,
    left: 2,
    alignSelf: 'auto'
  },
  coverText: {
    alignItems: 'center',
    fontFamily: gui.fontFamily,
    fontSize: 12
  },
  deleteContent: {
    position: 'absolute',
    backgroundColor: 'white',
    opacity: 0.5,
    top: 2,
    right: 2,
    alignSelf: 'auto'
  },
  deleteButton: {
    alignItems: 'center'
  },
  captureIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
    padding: 5
  },
  imgItem: {
    width: (width - 50) / 4,
    height: (width - 50) / 4,
    backgroundColor: "white",
    justifyContent: 'center',
    borderWidth: 0,
    marginLeft: 5,
    borderColor: gui.separatorLine,
  },
  viewModalStyle: {
    justifyContent: 'flex-start',
    height: 180,
    width: width - 28,
    marginVertical: 0,
    backgroundColor: 'transparent',
    alignItems: 'center'
  },
  viewShowModal: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    flex: 1,
    backgroundColor: 'transparent'
  },
  viewSwipeButton: {
    backgroundColor: 'transparent',
    height: 106,
    width: width - 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewButtonModal: {
    height: 52,
    width: width - 28,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12
  },
  textDelete: {
    color: '#f43838',
    fontSize: 17,
    fontFamily: gui.fontFamily,
    fontWeight: '400'
  },
  lineSpaceButton: {
    width: width - 28,
    backgroundColor: 'rgba(80,80,80,0.6)',
    borderColor: '#fff',
    borderTopWidth: 0.5,
    height: 1
  },
  viewSwipeButton2: {
    backgroundColor: 'white',
    height: 52,
    width: width - 28,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    marginTop: 8
  },
  iconChuSan: {
    width: 48,
    height: 48,
    borderRadius: 24
  },
  tenChuSan: {
    flex: 1,
    flexDirection: 'column',
    marginLeft: 16
  },
  phone: {
    width: 18,
    height: 18,
    backgroundColor: 'transparent',
  },
  chat: {
    width: 18,
    height: 18,
    marginLeft: 22,
    backgroundColor: 'transparent',
  },
  imgItem2: {

    width: width,
    height: 188,
    alignSelf: 'auto'
  },
  viewModalStyle2: {
    justifyContent: 'center',
    height: 210,
    width: width - 30,
    marginVertical: 0,
    borderRadius: 8
  },
  viewDetailModal: {
    backgroundColor: '#fff',
    justifyContent: 'flex-start',
    alignItems: 'center',
    //paddingLeft: 8,
    flexGrow: 1,
    borderRadius: 8
  },
  resultContainer: {
    position: 'absolute',
    // top: height/2,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center'
  },
  linearGradient: {
    flexGrow: 1,
    width: width,
    height: 188,
  },
  viewTopJoin: {
    alignItems: 'center',
    flexDirection: 'row'
  },
  touchJoinGroup: {
    borderRadius: 3,
    borderColor: gui.mainAgentColor,
    borderWidth: 1,
    height: 24,
    width: 72,
    justifyContent: 'center',
    alignItems: 'center'
  },
  groupStatus: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: gui.mainAgentColor,
    textAlign: 'center'
  },
  viewButtonJoin: {
    position: 'absolute',
    right: 0
  }
});