import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    Switch,
    ScrollView,
    ListView
} from 'react-native';

import Communications from '../detail/MCommunications';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Actions } from 'react-native-router-flux';

import gui from '../../lib/gui';
import GiftedSpinner from "../GiftedSpinner";
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();

import moment from 'moment'

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { findAllWebsiteService } from '../../reducers/adsMgmt/adsMgmtActions';
import FullLine from '../line/FullLine';
import DanhMuc from '../../assets/DanhMuc';

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

const ds_eachListTodo = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
const ds_eachListNew = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
const ds_eachListRespond = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
class DetailContact extends Component {
    constructor(props) {
        super(props);
        let data = [
            { 'typeTodo' : 'Công việc', 'todoDetail' : 'Dẫn anh Bách đi xem nhà' , 'dateDetail' :'Dec 22'},
            { 'typeTodo' : 'Công việc', 'todoDetail' : 'Dẫn anh Thanh đi xem ruộng' , 'dateDetail' :'Dec 25'},
            { 'typeTodo' : 'Công việc', 'todoDetail' : 'Dẫn anh Nguyên đi xem đất' , 'dateDetail' :'Dec 29'},
            { 'typeTodo' : 'Công việc', 'todoDetail' : 'Dẫn anh Nhan đi xem vợ' , 'dateDetail' :'Dec 31'},
        ];
        let dataNew = [
            { 'nameTodo': 'Gọi điện cho anh Bách', 'dateTodo' : '15 Tháng 12', 'levelNoteKey' : 0},
            { 'nameTodo': 'Nhắn tin cho anh Bách', 'dateTodo' : '17 Tháng 12', 'levelNoteKey' : 1},
            { 'nameTodo': 'Gọi điện cho anh Bách', 'dateTodo' : '20 Tháng 12', 'levelNoteKey' : 2},
        ];
        this.state = {
            potential: true,
            data: data,
            dataNew: dataNew,
            selectedContact: this.props.group.selectedContact,
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.group.selectedContact !== nextProps.group.selectedContact) {
            this.setState({ selectedContact: nextProps.group.selectedContact });
        }
    }

    render() {
        return(
            <ScrollView style={styles.container}
                        contentContainerStyle={{ backgroundColor: '#fff'}}>
                {this._renderHeaderButton()}
                {this._renderAvatarContact()}
                {this._renderPhoneContact()}
                {this._renderEmailContact()}
                {this._renderContactType()}
                {this._renderPotential()}
                
                {this._renderListNew()}
                <FullLine style={{  marginLeft: 16, marginRight: 16}}/>
                {this._renderListRespond()}
                <FullLine style={{  marginLeft: 16, marginRight: 16}}/>
                {this._renderHistoryTodo()}
                {this._renderLoadingView()}
            </ScrollView>
        )
    }

    _renderLoadingView() {
        if (this.props.group.loadingContactHistory && this.props.group.loadingContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderHeaderButton() {
        let nameContact = this.props.group.selectedContact.contactName;
        let saveText = 'Sửa';
        return(
            <View style={styles.viewHeaderButton}>
                <View style={styles.viewLeftIcon}>
                    <TouchableOpacity style={styles.viewTouchClose}
                                      onPress={this._onCloseButton.bind(this)}
                    >
                        <Ionicons name={"md-close"} size={24} color={gui.mainTextColor}/>
                    </TouchableOpacity>
                    <View style={{width: width/2 -24, height:24, justifyContent:'center'}}>
                        <Text style={styles.textContact} numberOfLines={1}>{nameContact}</Text>
                    </View>
                </View>
                <View style={styles.viewRightIcon}>
                    <TouchableOpacity onPress={this._onEditButton.bind(this)}>
                        <Text style={styles.textSave}>{saveText}</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _onEditButton() {        
        if (!this.props.group.selectedContact) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let selectedContact = this.props.group.selectedContact
        
        // console.log('_onEditButton will update this contact ******', selectedContact);
        this.props.actions.onGroupFieldChange('contactID', selectedContact.id);
        this.props.actions.onGroupFieldChange('contactName', selectedContact.contactName);
        this.props.actions.onGroupFieldChange('contactSource', selectedContact.contactSource);
        this.props.actions.onGroupFieldChange('contactPhone', selectedContact.contactPhone);
        this.props.actions.onGroupFieldChange('contactEmail', selectedContact.contactEmail);
        this.props.actions.onGroupFieldChange('contactType', selectedContact.contactType);
        this.props.actions.onGroupFieldChange('contactSaleState', selectedContact.contactSaleState);
        this.props.actions.onGroupFieldChange('recordID', selectedContact.recordID);
        this.props.actions.onGroupFieldChange('listContactNhucau', selectedContact.nhuCau);
        this.props.actions.onGroupFieldChange('contactPhotos', selectedContact.avatar ? [{ uri: selectedContact.avatar }] 
                                        : ( selectedContact.zaloAvatar ? [{ uri: selectedContact.zaloAvatar }] : []) );

        this._onSaveInitialContact();

        Actions.ModifyContact();
    }

    _onSaveInitialContact() {
        // local storage initialContact
        this.props.actions.onHelpedModalChange('initialContact', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialContact = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _renderAvatarContact() {
        let myAvatar = this.props.group.selectedContact.avatar;
        let uriAvatar = { uri: myAvatar };
        let defaultSource = require('../../assets/image/register_avatar_icon.png');
        return(
            <Image
                source={uriAvatar}
                style={styles.myAvatar}
                defaultSource={defaultSource}
            />
        )
    }

    _renderEmailContact() {
        let emailAddress = this.props.group.selectedContact.contactEmail;
        return(
            <View style={[styles.viewPhoneContact, {borderTopWidth: 0, height:60, marginTop: 0}] }>
                <TouchableOpacity style={styles.viewDetailPhone}
                                //   onPress={this._onPhoneCall.bind(this,emailAddress)}
                >
                    <Ionicons name={"ios-mail"} size={24} color={gui.mainTextColor}/>
                    <Text style={[styles.textSave, {position: 'absolute', left: 64}]}>{emailAddress}</Text>
                </TouchableOpacity>
                <View style={styles.lineContent}/>
            </View>
        );
    }

    _renderPhoneContact() {
        let phoneNumber = this.props.group.selectedContact.contactPhone;
        return(
            <View style={styles.viewPhoneContact}>
                <TouchableOpacity style={styles.viewDetailPhone}
                                  onPress={this._onPhoneCall.bind(this,phoneNumber)}
                >
                    <Ionicons name={"md-call"} size={24} color={gui.mainTextColor}/>
                    <Text style={[styles.textSave, {position: 'absolute', left: 64}]}>{phoneNumber}</Text>
                </TouchableOpacity>
                <View style={styles.lineContent}/>
            </View>
        );
    }

    _onPhoneCall(phoneNumber) {
        if (!phoneNumber) {
            return;
        }
        Communications.phonecall(phoneNumber, true);
    }

    _renderContactType() {
        let phanLoai = this.props.group.selectedContact.contactType==1? 'Khách hàng' : 'Môi giới';
        return(
            <View style={[styles.viewPhoneContact, {borderTopWidth: 0, height:60, marginTop: 0}] }>
                <TouchableOpacity style={styles.viewDetailPhone}
                                //   onPress={this._onPhoneCall.bind(this,emailAddress)}
                >
                    <Ionicons name={"ios-bookmark"} size={24} color={gui.mainTextColor}/>
                    <Text style={[styles.textSave, {position: 'absolute', left: 64}]}>{phanLoai}</Text>
                </TouchableOpacity>
                <View style={styles.lineContent}/>
            </View>
        );
    }

    _renderPotential() {
        let potentialCustomer = 'Khách hàng tiềm năng';
        return(
            <View style={styles.viewPotential}>
                <View style={styles.switchPotential}>
                    <Text style={styles.textSave}>{potentialCustomer}</Text>
                    <Switch
                        disabled={true}                        
                        value={this.props.group.selectedContact.contactSaleState}
                        onTintColor={'#78BC61'}
                        tintColor={'rgba(82,97,115,0.1)'}
                        style={styles.viewAswitch}
                    />
                </View>
                <View style={[styles.lineContent, {width: width - 32 ,marginLeft: 16}]}/>
            </View>
        )
    }

    _renderRowTodo(data) {
        let nameTodo = data.title;
        let dateTodo = utils.showChatTime(data.startDate);
        let colorLevel = this._getLevelColor(data.level);
        return(
            <View style={styles.viewNameTodo}>
                <View style={styles.todoContent}>
                    <View style={[styles.dotStyle, {backgroundColor: colorLevel}]}/>
                    <View style={{height: 55, width: width-130, justifyContent:'center'}}>
                        <Text style={[styles.textSave, {fontWeight: '500', marginLeft: 8 }]}
                            numberOfLines={2}>{nameTodo}</Text>
                    </View>
                    <Text style={styles.textDateTodo}>{dateTodo}</Text>
                </View>
                <View style={[styles.lineContent, {width: width - 32 ,marginLeft: 16}]}/>
            </View>
        );
    }

    _getLevelColor(level) {        
        if (level == 0) {
            return 'rgba(255,94,91,1)';
        } else if (level == 1) {
            return 'rgba(120,188,97,1)';
        } else if (level == 2) {
            return 'rgba(82,97,115,0.2)';
        } else return 'rgba(82,97,115,0.2)';
    }

    _renderListNew() {
        let historyTodo = 'Công việc liên quan';
        let dataToRender = this.props.group.eventListByContact;
        dataToRender = dataToRender.filter((one) => {
            return one.status == 1 //not done yet
        }) || [];
        if (dataToRender.length>0)
            return(
                <View style={[styles.contentHistory,{paddingLeft:0, paddingRight:0} ]}>                    
                    <Text style={[styles.textRelated, {marginTop: 32, marginBottom: 21, marginLeft:16}]}>{historyTodo}</Text>
                    <ListView contentContainerStyle={styles.listTodo}
                            enableEmptySections={true}
                            dataSource={ds_eachListNew.cloneWithRows(dataToRender)}
                            renderRow={this._renderRowTodo.bind(this)} />
                </View>
            )
        else 
        return(
            <View style={[styles.contentHistory,{paddingLeft:0, paddingRight:0} ]}>
                <Text style={[styles.textRelated, {marginTop: 32, marginBottom: 21, marginLeft:16}]}>{historyTodo}</Text>
                <Text style={[styles.textRelated, {alignSelf:'center'}]}>Không có công việc liên quan</Text>
            </View>
        )
    }

    _renderListRespond() {
        let historyTodo = 'Phản hồi của khách hàng';
        let dataToRender = this.props.group.contactRespondList;
        
        if (dataToRender.length>0)
            return(
                <View style={[styles.contentHistory,{paddingLeft:0, paddingRight:0} ]}>                    
                    <Text style={[styles.textRelated, {marginTop: 32, marginBottom: 21, marginLeft:16}]}>{historyTodo}</Text>
                    <ListView contentContainerStyle={styles.listTodo}
                            enableEmptySections={true}
                            dataSource={ds_eachListRespond.cloneWithRows(dataToRender)}
                            renderRow={this._renderRowRespond.bind(this)} />
                </View>
            )
        else 
        return(
            <View style={[styles.contentHistory,{paddingLeft:0, paddingRight:0} ]}>
                <Text style={[styles.textRelated, {marginTop: 32, marginBottom: 21, marginLeft:16}]}>{historyTodo}</Text>
                <Text style={[styles.textRelated, {alignSelf:'center'}]}>Chưa có phản hồi từ khách hàng</Text>
            </View>
        )
    }

    _renderRowRespond(data) {
        
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        
        let addressValue = data.diaChi ? data.diaChi : '';        
        let priceValue = utils.getPriceDisplay(data.gia, data.loaiTin);
        let likeStatus = DanhMuc.likeStatus[data.likeStatus];
        let comment = data.comment;
        return (
            <View style={[styles.imgAdsItem, { height: 60}]}>                                                        
                {/* <TouchableOpacity onPress={this._onPressAdsRow.bind(this,data)}> */}
                    <View style={[styles.viewToDoRow, {marginBottom: 0}]}>
                        <View style={[styles.dotView]}>
                            
                        </View>
                        <View style={{width: width-136, height:24, justifyContent:'center'}}>
                            <Text style={[styles.textMainMinute, {marginLeft: 6}]} numberOfLines={1}>{addressValue}</Text>
                        </View>
                        <View style={{position:'absolute', right:0}}>
                            <Text style={[styles.textMainMinute]} numberOfLines={1}>{priceValue}</Text>
                        </View>
                    </View>
                    <View style={[styles.viewToDoRow, {marginTop:0}]}>
                        <View style={[styles.respondIconView]}>
                            <MaterialCommunityIcons name="reply" size={22} color="#526173" />
                        </View>
                        <View style={{width: width-136, height:24, justifyContent:'center'}}>
                            <Text style={[styles.textMainMinute, {marginLeft: 6}]} numberOfLines={1}>{comment}</Text>
                        </View>
                        <View style={{position:'absolute', right:0}}>
                            <Text style={[styles.textMainMinute]} numberOfLines={1}>{likeStatus}</Text>
                        </View>
                    </View>
                {/* </TouchableOpacity>                         */}
            </View>            
        )
    }

    _renderHistoryTodo() {
        let historyTodo = 'Lịch sử hoạt động';
        let dataToRender = this.props.group.eventListByContact;
        dataToRender = dataToRender.filter((one) => {
            return one.status == 2 //done
        }) || [];
        if (dataToRender.length>0)
            return(
                <View style={styles.contentHistory}>
                    <Text style={[styles.textRelated, {marginTop: 32, marginBottom: 21}]}>{historyTodo}</Text>
                    <ListView contentContainerStyle={styles.listTodo}
                            enableEmptySections={true}
                            dataSource={ds_eachListTodo.cloneWithRows(dataToRender)}
                            renderRow={this._renderRowDone.bind(this)} />
                </View>
            );
        else 
            return(
                <View style={[styles.contentHistory]}>
                    <Text style={[styles.textRelated, {marginTop: 32, marginBottom: 21}]}>{historyTodo}</Text>
                    <Text style={[styles.textRelated, {alignSelf:'center'}]}>Không có lịch sử hoạt động</Text>
                </View>
            )
    }

    _renderRowDone(data) {
        let typeTodo = 'Công việc';
        let todoDetail = data.title;
        let dateDetail = utils.showChatTime(data.startDate);
        return(
            <View style={styles.rowContent}>
                <View style={styles.viewRowTodo}>
                    <TouchableOpacity style={styles.touchCheckmark}>
                        <Ionicons name={"md-checkmark"} size={24} color={gui.mainTextColor}/>
                    </TouchableOpacity>
                    <View style={styles.viewDetailTodo}>
                        <View style={{height: 20, width: width - 32 - 48 - 80, justifyContent:'center'}}>
                            <Text style={styles.textSave} numberOfLines={1} >{todoDetail}</Text>
                        </View>
                        
                        <Text style={styles.textRelated}>{dateDetail}</Text>
                    </View>
                    <View style={styles.viewTodoType}>
                        <Text style={styles.textDateTodo}>{typeTodo}</Text>
                    </View>
                </View>
                <View style={[styles.lineContent, {marginLeft: 48}]}/>
            </View>
        )
    }

    _potentialChanged() {
        let { potential } = this.state;
        this.setState({
            potential: !potential
        })
    }
    _onCloseButton() {
        this.props.actions.onGroupFieldChange('eventListByContact', []);        
        Actions.pop();
    }

}

const styles = StyleSheet.create({
    container: {
        width: width,
        height: height,
        flex: 1
    },
    viewHeaderButton: {
        height: 24,
        width: width,
        marginTop: 16 + gui.marginTopAgent,
        flexDirection: 'row'
    },
    viewLeftIcon: {
        height: 24,
        width: width/2,
        paddingLeft: 16,
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewRightIcon: {
        height: 24,
        width: width/2,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'flex-end',
    },
    textContact: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 13
    },
    viewTouchClose: {
        marginTop: 3
    },
    textSave: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor,
    },
    viewAvatarContact: {
        width: width,
        height: 120,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 72 + gui.marginTopAgent,
        backgroundColor: '#fff'
    },
    viewPhoneContact: {
        width: width,
        height: 132,
        justifyContent: 'flex-end',
        backgroundColor: gui.groupBackground,
        marginTop: 96,
        borderTopWidth: 1,
        borderColor: 'rgba(211,211,211, 0.5)'
    },
    myAvatar: {
        width: 120,
        height: 120,
        borderRadius: 60,
        zIndex: 1,
        position: 'absolute',
        top: 72 + gui.marginTopAgent,
        alignSelf: 'center'
    },
    viewDetailPhone: {
        width: width,
        height: 52,
        backgroundColor: gui.groupBackground,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 16,
        paddingRight: 16
    },
    lineContent: {
        height: 1,
        width: width - 80,
        backgroundColor: 'rgba(211,211,211, 0.5)',
        marginLeft: 64,
        marginRight: 16
    },
    viewPotential: {
        height: 63,
        width: width,
        backgroundColor: gui.groupBackground,
        justifyContent: 'flex-end'
    },
    switchPotential: {
        height: 33,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row'
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        position: 'absolute',
        right: 0,
        marginBottom: 8
    },
    viewRelatedWork: {
        height: 63,
        width: width,
        paddingTop: 15,
        paddingLeft: 16,
        backgroundColor: gui.groupBackground,
        justifyContent: 'center'
    },
    textRelated: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur
    },
    viewNameTodo: {
        height: 56,
        width: width,
        backgroundColor: '#fff'
    },
    todoContent: {
        height: 55,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    dotStyle: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: 'rgba(255,94,91,1)'
    },
    textDateTodo: {
        fontSize: 10,
        color: gui.colorMainBlur,
        fontFamily: gui.fontFamily,
        position: 'absolute',
        right: 0
    },
    contentHistory: {
        flex: 1,
        backgroundColor: gui.groupBackground,
        paddingLeft: 16,
        paddingRight: 16
    },
    rowContent: {
        height: 51,
        width: width - 32,
    },
    viewRowTodo: {
        height: 50,
        width: width - 32,
        backgroundColor: gui.groupBackground,
        flexDirection: 'row',
        alignItems: 'center'
    },
    touchCheckmark: {
        height: 50,
        width: 48,
        justifyContent: 'center'
    },
    viewDetailTodo: {
        height: 50,
        width: width - 32 - 48 - 80,
        justifyContent: 'center',
    },
    viewTodoType: {
        height: 50,
        width: 80,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    listTodo: {
        flex: 1
    },
    imgAdsItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 188,
        alignSelf: 'auto'
    },
    viewToDoRow: {
        // backgroundColor: '#FFFFFF',
        marginTop: 17,
        marginBottom: 15,
        width: width-32,
        marginLeft: 16,
        marginRight: 16,
        height: 24,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotView: {        
        width: 8,
        borderRadius: 4,
        height: 8,
        marginLeft: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(82,97,115,0.2)'
    },
    respondIconView: {        
        width: 8,        
        height: 8,
        marginLeft: 8,
        justifyContent: 'center',
        alignItems: 'center',
        
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(DetailContact);