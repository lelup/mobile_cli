'use strict';
import React, { Component } from 'react';

import type, {
  StyleObj
} from 'react-native/Libraries/StyleSheet/StyleSheetTypes';

import {
  View, Text, StyleSheet, TextInput, ScrollView, ListView, TouchableOpacity, ViewPropTypes, StatusBar,
  ImageBackground, Alert, TouchableWithoutFeedback
} from 'react-native';
import Button from 'react-native-button';
import { Actions } from 'react-native-router-flux';
import ScalableText from 'react-native-text';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Tag from '../group/Tag';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import GiftedSpinner from "../GiftedSpinner";
import TextInputAuto from '../postAds/TextInputAuto';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import Camera from 'react-native-camera';

const Permissions = require('react-native-permissions');
import ImageResizer from 'react-native-image-resizer';
import moment from 'moment';
import cfg from "../../cfg";
import OfflineBar from '../line/OfflineBar';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import DanhMuc from '../../assets/DanhMuc';
import MLikeTapButton2 from '../MLikeTapButton2';
import Toast, { DURATION } from '../toast/Toast';

import { GooglePlacesAutocomplete3 } from '../GooglePlacesAutocomplete3';
import RelandIcon from '../RelandIcon';
import FunctionModal from '../FunctionModal'


import { Map } from 'immutable';

import gui from "../../lib/gui";
import log from "../../lib/logUtil";
import findApi from '../../lib/FindApi';

import HomeHeader from '../home/HomeHeader';

import MeContent from "../me/MeContent";
import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const actions = [
  globalActions,
  meActions,
  searchActions,
  groupActions,
  inboxActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

let hisTopUPDs = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
var count = 0;
var uploadFiles = [];
var errorMessage = '';

class Group extends React.Component {
  constructor(props) {
    super(props);
    let allDiaChinh = props.group.allDiaChinh;
    let duAns = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.DU_AN);
    let diaBans = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.TINH || e.type == DanhMuc.placeType.HUYEN);
    this.state = {
      groupType: props.group.groupType,
      photos: props.group.photos,
      isOpenImagePicker: false,
      diaBans: diaBans,
      duAns: duAns,
      allDiaChinh: allDiaChinh,
      uploadUrls: [],      
      toggleState: false,
      name: props.group.name,
      chiTiet: props.group.chiTiet,
    }
  }

  componentWillMount() {
    this.props.actions.onHideChatIconChange(true);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.group.photos !== this.props.group.photos) {
      this.setState({
        photos: nextProps.group.photos
      });
    }
    if (nextProps.group.allDiaChinh !== this.props.group.allDiaChinh) {
      let allDiaChinh = nextProps.group.allDiaChinh;
      let duAns = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.DU_AN);
      let diaBans = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.TINH || e.type == DanhMuc.placeType.HUYEN);
      this.setState({
        diaBans: diaBans,
        duAns: duAns,
        allDiaChinh: allDiaChinh
      });
    }
    if (nextProps.group.groupType !== this.props.group.groupType) {
      this.setState({
        groupType: nextProps.group.groupType,
      });
    }

    if (nextProps.group.name !== this.props.group.name) {
      this.setState({
        name: nextProps.group.name,
      });
    }

    if (nextProps.group.chiTiet !== this.props.group.chiTiet) {
      this.setState({
        chiTiet: nextProps.group.chiTiet,
      });
    }
  }

  // state = {
  //   diaBans: [],
  //   duAns: [],
  //   allDiaChinh: []
  // };

  onChangeDiaBans = (diaBans) => {
    this.setState({
      diaBans,
    });
  };

  onChangeDuAns = (duAns) => {
    this.setState({
      duAns,
    });
  };

  // renderTabBar() {
  //   return <AdsMgmtTabBar />
  // }

  render() {

    // if (this.props.global.loggedIn) {

    // <View>
    // <ScrollView
    //   keyboardShouldPersistTaps="always"
    //   keyboardDismissMode="on-drag"
    //   ref={(scrollView) => { this._scrollView = scrollView; }}
    //   automaticallyAdjustContentInsets={false}
    //   vertical={true}
    //   style={{flex: 1}}>

    return (

      <View style={{ flex: 1 }}>
        <OfflineBar />
        {this._renderHeader()}

        {this._renderContent()}

        {this._renderButton()}

        {this._openImagePicker()}

        {this._renderLoadingView()}

        <Toast
          ref="toastTop"
          position='top'
          positionValue={45}
          fadeInDuration={850}
          fadeOutDuration={1400}
          opacity={0.56}
          textStyle={{ color: '#fff' }}
        />
      </View>


    )
    // } else {
    //   return (
    //     <Login />
    //   );
    // }
  };

  onKeyboardToggle(toggleState) {
    this.setState({ toggleState: toggleState });
  }

  _renderLoadingView() {
    if (this.props.group.postingGroup) {
      return (<View style={styles.resultContainer}>
        <GiftedSpinner size='large' color="grey" />
      </View>)
    }
  }

  _renderHeader() {
    let title = this.props.group.groupID ? 'Cập nhật Sàn' : 'Tạo Sàn mới';
    return (
      <View style={styles.headerView}>
        <TouchableOpacity onPress={this._onBack.bind(this)} style={styles.cancelView}>
          <MaterialCommunityIcons name="close" size={24} color={gui.mainColor} />
        </TouchableOpacity>
        <View style={styles.headerView2}>
          <ScalableText style={[styles.headerText]}>{title}</ScalableText>
        </View>
      </View>
    );
  }

  labelExtractor = (tag) => tag;

  onLayoutLastTag = (endPosOfTag: number) => {
    const margin = 3;
    this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
    const inputWidth = Group.inputWidth(
      this.state.text,
      this.spaceLeft,
      this.wrapperWidth,
    );
    if (inputWidth !== this.state.inputWidth) {
      this.setState({ inputWidth });
    }
  }

  static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
    if (text === "") {
      return 90;
    } else if (spaceLeft >= 100) {
      return spaceLeft - 10;
    } else {
      return wrapperWidth;
    }
  }

  removeDiaBan = (index: number) => {
    const tags = [...this.state.diaBans];
    const allDiaChinh = [...this.state.allDiaChinh];

    let toRemove = tags[index];
    tags.splice(index, 1);
    this.setState({ diaBans: tags });

    const indexInDiaChinh = allDiaChinh.indexOf(toRemove);
    allDiaChinh.splice(indexInDiaChinh, 1);
    this.setState({ allDiaChinh: allDiaChinh });
  }

  removeDuAn = (index: number) => {
    const tags = [...this.state.duAns];
    const allDiaChinh = [...this.state.allDiaChinh];

    let toRemove = tags[index];
    tags.splice(index, 1);
    this.setState({ duAns: tags });

    const indexInDiaChinh = allDiaChinh.indexOf(toRemove);
    allDiaChinh.splice(indexInDiaChinh, 1);
    this.setState({ allDiaChinh: allDiaChinh });
  }


  _renderTenSan() {
    return (

      <View style={{ width: width - 48 - 48, height: 48 }} >
        {/* <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Tên Sàn</ScalableText>
        </View> */}
        <View style={[styles.viewInput, { flexDirection: 'row', marginLeft: 16, marginTop: 9, width: width - 48 - 48 }]}>

          <View onPress={this.onBlurNamePost.bind(this)} style={{ width: width - 56 - 48 - 48 }}>
            <TextInput
              blurOnSubmit={true}
              onBlur={() => this.onBlurNamePost()}
              //onFocus = {() => this.onBlurNamePost()}
              autoFocus={false}
              maxLength={60}
              autoCapitalize='none'
              autoCorrect={false}
              returnKeyType='done'
              //underlineColorAndroid='rgba(0,0,0,0)'
              style={[styles.viewTextInput, { width: width - 56 - 64 }]}
              placeholder="Đặt tên cho sàn" placeholderTextColor={gui.arrowColor}
              onChangeText={(text) => { this.onValueChange("name", text) }}
              value={this.state.name}
            />
          </View>


          <View style={styles.parentDotView}>
            <View style={styles.dotView}></View>
          </View>
        </View>

        {this._renderShortLine()}

      </View >

    )
  }

  onBlurNamePost() {
    dismissKeyboard();
    this.onKeyboardToggle(false);
    // this.setState({
    //     namePostLine: false
    // })
  }

  _renderMoTa() {
    return (
      <View style={[styles.blockView, { height: 'auto', paddingBottom: 4 }]}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Mô tả</ScalableText>
        </View>
        <View style={[styles.viewInput, { height: 'auto', flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }]}>
          <TextInputAuto
            autoFocus={false}
            blurOnSubmit={true}
            onBlur={() => this.onBlurNamePost()}
            autoCapitalize='none'
            maxLength={250}
            autoCorrect={false}
            returnKeyType='done'
            style={[styles.viewTextInput, { width: width - 32 - 16, height: 'auto' }]}
            placeholder="Hoạt động, quy định của sàn" placeholderTextColor={gui.arrowColor}
            onChangeText={(text) => { this.onMoTaChange("chiTiet", utils.normalizeName(text)) }}
            value={this.state.chiTiet}
            multiline={true}

          />
          <View style={[styles.dotView, styles.dotContent]}></View>
        </View>
        <View style={[styles.viewLine, { marginTop: -4 }]}></View>

      </View>
    )
  }

  _renderLoaiNhom() {
    return (
      <View style={styles.blockView}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Loại nhóm</ScalableText>
        </View>
        <View style={[styles.viewTabInterest]}>
          <MLikeTapButton2 name={'public'}
            onPress={this._onTypeClicked.bind(this)}
            selected={this.state.groupType == 'public'}
            mainProps={styles.tab1}
            line1="Công khai"></MLikeTapButton2>

          <MLikeTapButton2 name={'private'}
            onPress={this._onTypeClicked.bind(this)}
            selected={this.state.groupType == 'private'}
            mainProps={styles.tab2}
            line1="Riêng tư"
            line2="Cần được mời để tham gia"
          ></MLikeTapButton2>
        </View>
      </View>
    )
  }

  _onTypeClicked(value) {
    this.setState({
      groupType: value
    });
  }

  _onPressDiaChinhColection() {
    dismissKeyboard();
    let diaChinhDto = {
      placeType: DanhMuc.placeType.TINH
    };
    findApi.getDiaChinhByCondition(diaChinhDto).then(
      (e) => {
        let allTinh = [];
        if (e && e.status === 0 && e.predictions) {
          allTinh = e.predictions.slice(0);
          allTinh.forEach((one) => {
            one.description = one.fullName;
            one.shortName = one.fullName;
          });
        }
        this._onLoadDiaChinh(allTinh);
      }
    );
  }

  _onLoadDiaChinh(allTinh) {
    Actions.NewLoginAutoComplete(
      {
        onSuggestionBuyPressed: (location) => this._collectSuggestionInfo(location),
        allTinh: allTinh,
        category: ["DIA_CHINH"],
        placeHolder: 'Nhập tên thành phố, quận'
      });
  }


  _onPressDuAnColection() {
    dismissKeyboard();

    let limit = this.props.global.setting.maxAdsInMapView;
    findApi.findDuAn({ limit: limit, pageNo: 1, isIncludeCountInResponse: false }).then((data) => {
      let allDuAn = [];
      if (data) {
        data.list.forEach((one) => {
          let duAn = {};
          duAn.id = one.duAnID;
          duAn.duAn = one.codeDuAn;
          duAn.duAnName = one.tenDuAn;
          duAn.placeName = one.tenDuAn;
          duAn.placeType = 'A';
          duAn.name = one.tenDuAn;
          let diaChinh = one.place.diaChinh;
          duAn.tinh = diaChinh.codeTinh;
          duAn.tinhName = diaChinh.tinh;
          duAn.huyen = diaChinh.codeHuyen;
          duAn.huyenName = diaChinh.huyen;
          duAn.description = one.tenDuAn;
          duAn.shortName = one.tenDuAn;
          allDuAn.push(duAn);
        });
      }
      this._onLoadDuAn(allDuAn);
    });
  }

  _onLoadDuAn(allDuAn) {
    Actions.NewLoginAutoComplete(
      {
        onSuggestionBuyPressed: (location) => this._collectSuggestionInfo(location),
        allTinh: allDuAn,
        category: ["DU_AN"],
        placeHolder: 'Nhập tên dự án'
      });
  }

  _renderKhuVuc() {
    var tags = this.state.diaBans.map((tag, index) => (
      <Tag
        type="DiaChinh"
        index={index}
        label={tag.placeName}
        isLastTag={this.state.diaBans.length === index + 1}
        onLayoutLastTag={this.onLayoutLastTag}
        removeIndex={this.removeDiaBan.bind(this)}
        tagColor='#dddddd'
        tagTextColor='#777777'
        //tagContainerStyle={ViewPropTypes.style}
        //tagTextStyle={Text.propTypes.style}
        key={index}
        tagContainerStyle={{ marginBottom: 3 }}
      />
    ))

    return (
      <View style={styles.blockView2}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Khu vực</ScalableText>
        </View>

        <View style={styles.tagInputContainer}>{tags}</View>

        <View style={[styles.viewTags, { flexDirection: 'row' }]}>
          <View style={[{ width: width - 48 }]}>
            <TouchableOpacity
              style={styles.viewTypeCountry}
              onPress={this._onPressDiaChinhColection.bind(this)}>
              <Text style={[styles.textDeny, { color: gui.colorMainBlur }]}>Nhập khu vực hoạt động</Text>
            </TouchableOpacity>
          </View>


          <View style={[styles.dotView, { marginTop: 8 }]}></View>
        </View>

        {this._renderLine()}

      </View>
    )
  }

  _renderPhoto() {
    let { photos } = this.state;
    if (!photos) {
      photos = [];
    }
    let numOfPhoto = photos.length;
    let indexArr = [];
    for (let i = 0; i <= photos.length; i++) {
      if (i < 1) {
        indexArr.push(i)
      }
    }

    return (
      <View>
        <View style={[styles.mimgList]} >
          {indexArr.map((e) => { if (e < 1) return this._renderPhotoItem(e) })}
        </View>
      </View>
    );
  }

  _outModalImagePicker() {
    this.setState({
      isOpenImagePicker: false
    });
  }

  _openImagePicker() {
    return (
      <Modal isOpen={this.state.isOpenImagePicker}
        onClosed={this._outModalImagePicker.bind(this)}
        style={[styles.viewModalStyle, { height: 'auto' }]}
        position={"bottom"}
        swipeToClose={false}
        animationDuration={200}
      >
        {this._renderModalImagePicker()}
      </Modal>
    );
  }

  _renderModalImagePicker() {

    let items = [
      { _text: 'Máy ảnh', _function: () => this.onCamera() },
      { _text: 'Bộ sưu tập', _function: () => this.onCameraRollView() },
    ]
    return (
      <FunctionModal
        // data={data}
        items={items}
        onCloseModal={this._outModalImagePicker.bind(this)} />
    )
  }


  onCamera() {
    Camera.checkDeviceAuthorizationStatus().then(
      (e) => {
        console.log('onCamera ********', e);
        if (e) {
          Permissions.requestPermission('photo')
            .then(response => {
              if (response == 'authorized') {
                Actions.Group2({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
              } else {
                Alert.alert("Thông báo", gui.INF_PhotoAccess);
              }
            });
        } else {
          Alert.alert("Thông báo", gui.INF_CameraAccess);
        }
      });
  }

  onCameraRollView() {
    Permissions.requestPermission('photo')
      .then(response => {
        if (response == 'authorized') {
          Actions.CameraRollView3({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
        } else {
          Alert.alert("Thông báo", gui.INF_PhotoAccess);
        }
      });
  }

  _renderPhotoItem(imageIndex) {
    let { photos } = this.state;
    if (!photos) {
      photos = [];
    }
    let photo = photos[imageIndex];

    return (
      <ImageItem imageIndex={imageIndex}
        key={imageIndex}
        photo={photo}
        onTakePhoto={this.onTakePhoto.bind(this)}
        onDeletePhoto={this.onDeletePhoto.bind(this)} />
    )
  }

  _renderDuAn() {
    var tags = this.state.duAns.map((tag, index) => (
      <Tag
        type="DuAn"
        index={index}
        label={tag.placeName}
        isLastTag={this.state.duAns.length === index + 1}
        onLayoutLastTag={this.onLayoutLastTag}
        removeIndex={this.removeDuAn.bind(this)}
        tagColor='#dddddd'
        tagTextColor='#777777'
        //tagContainerStyle={ViewPropTypes.style}
        //tagTextStyle={Text.propTypes.style}
        key={index}
        tagContainerStyle={{ marginBottom: 3 }}
      />
    ))
    return (
      <View style={styles.blockView2}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Các dự án đang bán</ScalableText>
        </View>

        <View style={styles.tagInputContainer}>{tags}</View>

        <View style={[styles.viewTags, { flexDirection: 'row' }]}>
          <View style={[{ width: width - 48 }]}>
            <TouchableOpacity
              style={styles.viewTypeCountry}
              onPress={this._onPressDuAnColection.bind(this)}>
              <Text style={[styles.textDeny, { color: gui.colorMainBlur }]}>Dự án</Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.dotView, { marginTop: 8 }]}></View>
        </View>

        {this._renderLine()}

      </View>
    )
  }

  _renderContent() {
    return (
      <View style={{ flex: 1 }}>

        <KeyboardAwareScrollView
          contentContainerStyle={styles.scrollView}
          automaticallyAdjustContentInsets={false}
          style={styles.contentView}
          keyboardDismissMode='on-drag'
          keyboardShouldPersistTaps="always"
          extraScrollHeight={180}
        >

          {/* <View> */}
          {/* ======== */}
          <View style={{ flexDirection: 'row', marginLeft: 16, marginTop: 24.6 }}>
            {this._renderPhoto()}
            {this._renderTenSan()}
          </View>

          {/* ======== */}
          {this._renderMoTa()}

          {/* ======== */}
          {this._renderLoaiNhom()}

          {/* ======== */}
          {this._renderKhuVuc()}

          {/* ======== */}
          {this._renderDuAn()}
          {/* </View> */}
        </KeyboardAwareScrollView>

        {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
          style={[styles.searchButtonText2, {
            textAlign: 'right', color: gui.mainColor,
            backgroundColor: gui.doneKeyButton
          }]}>Xong</Button> : null}
        <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />
      </View>

    )
  }

  _onPress(data) {
    log.enter("DinhGiaPlacesAutocomplete._onPress", data);
    this._collectSuggestionInfo(data);
    // Actions.pop();
  }

  _updateBarColor() {
    // if (this.props.owner != 'home') {
    //   StatusBar.setBarStyle('light-content');
    // }
    StatusBar.setBarStyle('default');
  }

  _onCancelPress() {
    // Actions.pop();
    this._updateBarColor();
  }

  _onBack() {
    this.props.actions.onHideChatIconChange(false);
    Actions.pop();
  }

  _renderPlaceAutoComplete() {
    let predefinedPlaces = [
      ...this.props.search.saveSearchList,
      ...this.props.search.recentSearchList
    ];
    return (
      <View style={[styles.fullWidthContainer, { backgroundColor: 'black' }]}>
        <MPlacesAutoComplete
          ref={'placeSuggestion'}
          onSelectPress={this._onPlacePress.bind(this)}
          onCancelPress={this._onCancelPress.bind(this)}
          predefinedPlaces={predefinedPlaces}
        />
      </View>
    )
  }

  onValueChange(key: string, value: string) {
    // this.props.actions.onGroupFieldChange(key, value);
    this.setState({ name: value })
  }

  onMoTaChange(key: string, value: string) {
    // this.props.actions.onGroupFieldChange(key, value);
    this.setState({ chiTiet: value })
  }

  onDiaBanChange(diaBan) {
    // let newDiaBan = this.props.group.diaBan;
    // newDiaBan.push(...diaBan);
    // this.props.actions.onGroupFieldChange('diaBan', newDiaBan);
  }

  _renderLine() {
    return (
      <View style={styles.viewLine}></View>
    );
  }

  _renderShortLine() {
    return (
      <View style={styles.viewLine2}></View>
    );
  }

  _renderButton() {
    if (this.props.group.postingGroup)
      return (
        <View style={styles.searchButtonView}>
          <View
            style={styles.searchButton}
          >
            <Text style={styles.searchButtonText}>HOÀN TẤT</Text>
          </View>
        </View>
      )
    return (
      <View style={styles.searchButtonView}>
        <TouchableOpacity
          style={styles.searchButton}
          onPress={this.onPostGroup.bind(this)}
        >
          <Text style={styles.searchButtonText}>HOÀN TẤT</Text>
        </TouchableOpacity>
      </View>
    )
  }

  onPostGroup() {
    let { photos, place } = this.props.group;
    errorMessage = '';
    uploadFiles = [];
    for (let i = 0; i < photos.length; i++) {
      let filepath = photos[i].uri;
      if (filepath == '') {
        continue;
      }
      uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
    }
    if (!this.isValidInputData()) {
      this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
      this.props.actions.onGroupFieldChange('error', errorMessage);
      return;
    }

    this.onPostGroupChecked();

  }

  isValidInputData() {
    let errors = '';
    // if (uploadFiles.length === 0) {
    //     errors += ' (ảnh)';
    // }
    // console.log("picaso==============>", this.props.group);

    let { name, chiTiet } = this.state;
    let { groupType } = this.props.group;

    //let geo = place && place.geo;    
    // if (!geo || !geo.lat || isNaN(geo.lat)
    //     || !geo.lon || isNaN(geo.lon)) {
    //     errors += ' (địa điểm/dự án)';
    // }

    if (!name || !name.trim()) {
      errors += ' (tên)';
    }

    if (!chiTiet || !chiTiet.trim()) {
      errors += ' (mô tả)';
    }

    if (!groupType) {
      errors += ' (loại nhóm)';
    }

    if (errors != '') {
      errorMessage = 'Bạn chưa nhập' + errors + '!';
      return false;
    }
    // if (gia && isNaN(gia)) {
    //     errors += ' (giá)';
    // }

    // if (errors != '') {
    //     errorMessage = 'Sai kiểu giá trị:' + errors + '!';
    //     return false;
    // }
    return true;
  }

  onPostGroupChecked() {
    let { photos } = this.props.group;
    errorMessage = '';
    uploadFiles = [];
    for (let i = 0; i < photos.length; i++) {
      let filepath = photos[i].uri;
      if (filepath == '') {
        continue;
      }
      uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
    }

    this.props.actions.onGroupFieldChange("uploading", true);

    let countUpdateFiles = this.countNeedUploadFiles();
    if (!countUpdateFiles) {
      this.onSaveGroup();
      return;
    }

    count = 0;
    const userID = this.props.global.currentUser.userID;

    //upload thumbnail image
    if (uploadFiles.length > 0) {
      let thumbnailfilepath = uploadFiles[0].filepath;
      ImageResizer.createResizedImage(thumbnailfilepath, cfg.thumbWidth, cfg.thumbHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
        let ms = moment().toDate().getTime();
        let filename = 'Thumbnail_Group_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
        this.props.actions.onUploadGroupImage(0, filename, resizedImageUri, this.uploadCallBack.bind(this), 'thumbnail');
      }).catch((err) => {
        this.props.actions.onGroupFieldChange("uploading", false);
        log.error(err);
      });
    }

    for (let i = 0; i < uploadFiles.length; i++) {
      if (errorMessage != '') {
        Alert.alert('Thông báo', errorMessage);
        this.props.actions.onGroupFieldChange('error', errorMessage);
        return;
      }
      let needUpload = uploadFiles[i].needUpload;
      if (!needUpload) {
        continue;
      }
      let index = uploadFiles[i].index;
      let filepath = uploadFiles[i].filepath;

      ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
        let ms = moment().toDate().getTime();
        let filename = 'Group_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
        this.props.actions.onUploadGroupImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this), 'normal');
      }).catch((err) => {
        this.props.actions.onGroupFieldChange("uploading", false);
        log.error(err);
      });

    }
  }

  countNeedUploadFiles() {
    let count = 0;
    let thumbnailCount = 0;
    for (let i = 0; i < uploadFiles.length; i++) {
      let file = uploadFiles[i];
      if (file.needUpload) {
        count++;
        thumbnailCount = 1;
      }
    }
    return count + thumbnailCount;
  }

  uploadCallBack = function (err, result, index, type) {
    let data = result && result.data ? result.data : '';
    if (err || data == '') {
      errorMessage = 'Upload ảnh không thành công!';
      this.props.actions.onGroupFieldChange('error', errorMessage);
      this.props.actions.onGroupFieldChange("uploading", false);
      return;
    }
    try {
      let { success, file } = JSON.parse(data);
      if (success) {
        let { url } = file;
        this.state.uploadUrls.push({ index: index, url: url, type: type });      
        count++;
        if (count == this.countNeedUploadFiles()) {
          this.onSaveGroup();
        }
      } else {
        errorMessage = 'Upload ảnh không thành công!';
        this.props.actions.onGroupFieldChange('error', errorMessage);
        this.props.actions.onGroupFieldChange("uploading", false);
      }
    } catch (error) {
      errorMessage = 'Upload ảnh không thành công!';
      this.props.actions.onGroupFieldChange('error', errorMessage);
      this.props.actions.onGroupFieldChange("uploading", false);
    }
  }

  onSaveGroup() {
    let { name, chiTiet, uploadUrls, allDiaChinh} = this.state;
    this.props.actions.onGroupFieldChange('name', name);
    this.props.actions.onGroupFieldChange('chiTiet', chiTiet);

    let { groupID, photos } = this.props.group;

    let imageUrls = [];
    let thumbnailUrls = '';

    for (let i = 0; i < photos.length; i++) {
      let photo = photos[i];
      imageUrls.push(photo.uri);
    }
    
    for (let i = 0; i < uploadUrls.length; i++) {
      let uploadUrl = uploadUrls[i];
      let index = uploadUrl.index;
      if (index >= 0 && uploadUrl.type == 'normal') {
        imageUrls[index] = uploadUrl.url;
      }

      if (index >= 0 && uploadUrl.type == 'thumbnail') {
        thumbnailUrls = uploadUrl.url;
      }

    }
    
    let image = undefined;
    if (imageUrls.length > 0) {
      image = imageUrls[0];
    }

    let currentUser = this.props.global.currentUser;
    let token = currentUser.token;

    let groupNameStandardlized = utils.standardlizeName(name);

    let diaBanString = '';

    if (allDiaChinh && allDiaChinh.length > 0) {
      allDiaChinh.forEach((e) => {
        if (e.type == 'T')
          diaBanString = diaBanString + e.type + '-' + e.codeTinh + "_"
        if (e.type == 'H')
          diaBanString = diaBanString + e.type + '-' + e.codeHuyen + "_"
        if (e.type == 'A')
          diaBanString = diaBanString + e.type + '-' + e.codeDuAn + "_"
      })
    }

    let groupDto = {
      "groupID": groupID || undefined,
      "name": name || undefined,
      "nameKhongDau": utils.locDauV2(groupNameStandardlized) || undefined,
      "groupType": this.state.groupType,
      "chiTiet": chiTiet,
      "createdBy": currentUser.userID,
      "createdByName": currentUser.fullName,
      "createdByAvatar": currentUser.avatar,
      "image": image,
      "thumbnail": thumbnailUrls || undefined,
      "diaBan": allDiaChinh,
      "diaBanString": diaBanString.length > 0 ? diaBanString.slice(0, diaBanString.length - 1) : ''
      // "diaBanString": diaBanString.slice(0,diaBanString.length-1)
    };

    // console.log('bachtv log token here *************', token)
    this.props.actions.postGroup(groupDto, token)
      .then(res => {

        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.getRelatedGroup({ userID: userID }, token, () => {
          let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
          listRelatedGroup = listRelatedGroup.filter((e) => {
            return e.groupID == groupID
          })
          this.props.doRefreshGroupInfo && this.props.doRefreshGroupInfo(listRelatedGroup[0]);
        });

        this.props.actions.onGroupFieldChange("postingGroup", false);

        if (res.status != 0) {
          Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
        } else {

          this.props.doAfterSaveGroup && this.props.doAfterSaveGroup();

          const dto = { userID: userID, limit: this.props.inbox.chatMessageLimit, pageNo: 1, phamViChat: 0 };

          //bachtv: sao lai refresh inbox o day nhi??
          // this.props.actions.onRefreshGroupInbox(userID, dto);
          //clear input
          this.props.actions.onGroupFieldChange('selectedGroupTab', 'sanThamGia');
          // this.props.actions.onHideChatIconChange(false);

          this.refs.toastTop && this.refs.toastTop.show(
            groupID ? "Cập nhật sàn môi giới thành công!" :
              "Xác nhận tạo sàn môi giới thành công!",
            DURATION.LENGTH_LONG);

          setTimeout(() => Actions.pop(), 300);
        }
      });
  }

  _renderRowDiaBan(data) {
    return (
      <View style={styles.rowDiaBan}>
        <Text style={[{ textAlign: 'right', marginRight: 5 }]}>{data}</Text>
      </View>
    )
  }

  _getPlaceByLocation(lat, lon, callback) {
    findApi.getPlaceByLocation(lat, lon).then((res) => {
      if (res.success) {
        callback(res.result);
      }
    });
  }

  _collectSuggestionInfo(position) {
    //dismisskeyboard
    this.onBlurNamePost();

    if (position.placeType == DanhMuc.placeType.DIA_DIEM) {
      this._getPlaceByLocation(position.location.lat, position.location.lon, (res) => {
        if (res) {
          let diaChinh = {
            codeDuAn: undefined,
            codeDuong: undefined,
            codeXa: res.codeXa || undefined,
            codeHuyen: res.codeHuyen || undefined,
            codeTinh: res.codeTinh || undefined,
            duAn: undefined,
            duong: undefined,
            xa: res.xa || position.xaName || undefined,
            huyen: res.huyen || position.huyenName || undefined,
            tinh: res.tinh || position.tinhName || undefined,
          };
          this._updateDiaChinhDuAn(diaChinh);
        }
      });
    } else {
      let diaChinh = {};
      if (position.codeTinh) {
        diaChinh = {
          codeTinh: position.codeTinh || undefined,
          tinh: position.tinh || undefined,
          type: position.placeType,
          viewport: position.viewport || undefined,
          placeName: position.placeName
        };
      } else {
        diaChinh = {
          codeDuAn: position.duAn || undefined,
          codeDuong: position.duong || undefined,
          codeXa: position.xa || undefined,
          codeHuyen: position.huyen || undefined,
          codeTinh: position.tinh || undefined,
          duAn: position.duAnName || undefined,
          duong: position.duongName || undefined,
          xa: position.xaName || undefined,
          huyen: position.huyenName || undefined,
          tinh: position.tinhName || undefined,
          type: position.placeType,
          viewport: position.viewport || undefined,
          placeName: position.placeName
        };
      }
      this._updateDiaChinhDuAn(diaChinh);
    }
  }

  _updateDiaChinhDuAn(diaChinh) {

    if (diaChinh.type == DanhMuc.placeType.DU_AN && !this.containsDuAn(diaChinh, this.state.duAns)) {
      this.setState({ duAns: [...new Set([...this.state.duAns, diaChinh])] });
      this.setState({ allDiaChinh: [...new Set([...this.state.allDiaChinh, diaChinh])] });
    }

    if (diaChinh.type == DanhMuc.placeType.TINH && !this.containsTinh(diaChinh, this.state.diaBans)) {
      this.setState({ diaBans: [...new Set([...this.state.diaBans, diaChinh])] });
      this.setState({ allDiaChinh: [...new Set([...this.state.allDiaChinh, diaChinh])] });
    }

    if (diaChinh.type == DanhMuc.placeType.HUYEN && !this.containsHuyen(diaChinh, this.state.diaBans)) {
      this.setState({ diaBans: [...new Set([...this.state.diaBans, diaChinh])] });
      this.setState({ allDiaChinh: [...new Set([...this.state.allDiaChinh, diaChinh])] });
    }
  }

  containsTinh(obj, list) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].type === obj.type && list[i].codeTinh === obj.codeTinh) {
        return true;
      }
    }
    return false;
  }

  containsHuyen(obj, list) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].type === obj.type && list[i].codeHuyen === obj.codeHuyen) {
        return true;
      }
    }
    return false;
  }

  containsDuAn(obj, list) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].type === obj.type && list[i].codeDuAn === obj.codeDuAn) {
        return true;
      }
    }
    return false;
  }

  stringifyDiaBan(diaBan) {
    let result = '';
    // console.log('stringifyDiaBan ****', diaBan)
    if (diaBan & diaBan.length > 0)
      diaBan.forEach((e) => {
        if (e.type == 'T')
          result += e.type + '-' + e.codeTinh + "_"
        if (e.type == 'H')
          result += e.type + '-' + e.codeHuyen + "_"
        if (e.type == 'A')
          result += e.type + '-' + e.codeDuAn + "_"
      })
    return result.slice(0, -1);
  }

  onTakePhoto(imageIndex) {
    this.props.actions.onGroupFieldChange('imageIndex', imageIndex);
    // Actions.PostAds();
    this._openModalImagePicker();
  }

  _openModalImagePicker() {
    dismissKeyboard();
    this.setState({ isOpenImagePicker: true });
  }

  onDeletePhoto(imageIndex) {
    let { photos } = this.state;
    photos.splice(imageIndex, 1);
    this.setState({ deletedPhoto: imageIndex });
    this.props.actions.onGroupFieldChange('photos', photos);
  }

}

class ImageItem extends React.Component {
  constructor(props) {
    super(props);
  }

  _onPhotoPressed() {
    this.props.onTakePhoto(`${this.props.imageIndex}`);
  }

  _onDeletePhoto() {
    this.props.onDeletePhoto(`${this.props.imageIndex}`);
  }

  _renderCoverTitle() {
    if (this.props.imageIndex == 0)
      return (
        <View style={[styles.coverContent, { backgroundColor: 'red' }]}>
          <Text style={styles.coverText}>
            Ảnh nhóm
              </Text>
        </View>
      )
  }

  _renderDeleteButton() {
    // if (this.props.imageIndex !=0)
    return (
      <TouchableOpacity
        style={styles.deleteContent}
        onPress={this._onDeletePhoto.bind(this)} >

        <View style={styles.deleteButton}>
          <RelandIcon name="close" color={'black'}
            mainProps={styles.captureIcon}
            size={10} textProps={{ paddingLeft: 0 }}
            noAction={true}
          />
        </View>
      </TouchableOpacity>
    )
  }

  render() {
    log.info("Group.render ");
    let photo = this.props.photo;

    if (photo && photo.uri) {
      return (
        <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
          <ImageBackground style={styles.imgItem} source={photo} >
            {this._renderDeleteButton()}
          </ImageBackground>
        </TouchableOpacity>
      );
    } else {
      return (
        <TouchableOpacity onPress={this._onPhotoPressed.bind(this)} >
          <View style={[styles.imgItem, {}]}>
            <RelandIcon name="camera" color="#526173"
              mainProps={styles.captureIcon}
              size={20} textProps={{ paddingLeft: 0 }}
              noAction={true}
            />
          </View>
        </TouchableOpacity>
      );
    }

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Group);

var styles = StyleSheet.create({
  headerView: {
    backgroundColor: '#FFFFFFFF',
    height: 135.4,
    width: width
  },
  contentView: {
    flex: 1,
    // width: width,
    // height: height - 80 - 135.4 - 49,
    backgroundColor: gui.groupBackground,
  },
  cancelView: {
    backgroundColor: 'transparent',
    marginTop: 45,
    marginLeft: 21,
    width: 18,
    height: 18
  },
  dotView: {
    backgroundColor: 'lightgrey',
    // marginRight: 8,
    // marginTop: 6,
    width: 8,
    borderRadius: 4,
    height: 8
  },
  parentDotView: {
    width: 56,
    paddingRight: 8,
    height: 20,
    justifyContent: 'center',
    alignItems: 'flex-end'
  },
  headerView2: {
    backgroundColor: 'transparent',
    marginTop: 23,
    marginLeft: 16,
    width: 208,
    height: 36
  },
  headerText: {
    fontSize: 24,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  titleView: {
    height: 24
  },
  titleText: {
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  pickCard: {
    height: 57,
    width: (width - 32) / 2,
    borderWidth: 1,
    borderColor: gui.mainColor,
    justifyContent: 'center',
    alignItems: 'center'
  },
  blockView: {
    width: width - 32,
    // height: 97,
    height: 'auto',
    marginTop: 23.6,
    marginLeft: 16,
    //backgroundColor: 'lightgrey'
  },
  blockView2: {
    width: width - 32,
    marginTop: 23.6,
    marginLeft: 16,
    height: 'auto',
    //backgroundColor: 'lightgrey'
  },
  viewTags: {
    marginTop: 18,
    marginLeft: 0,
    height: 'auto',
    width: width - 32
  },
  viewInput: {
    marginTop: 18,
    marginLeft: 0,
    height: 'auto',
    width: width - 32,
  },
  viewTextInput: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    width: width - 32,
    paddingBottom: 8
  },
  viewLine: {
    borderTopWidth: 0.5,
    height: 1,
    borderColor: "#99526173",
    marginLeft: 0,
    marginTop: 11,
    width: width - 32,
    opacity: 0.6
  },
  viewLine2: {
    borderTopWidth: 0.5,
    height: 1,
    borderColor: "#99526173",
    marginLeft: 16,
    marginTop: 11,
    width: width - 48 - 48,
    opacity: 0.6
  },
  searchButtonView: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    height: 80,
    bottom: 0,
    width: width,
    backgroundColor: '#fff',
    //borderRadius: 24
  },
  searchButton: {
    height: 48,
    width: width - 32,
    backgroundColor: gui.mainColor,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center'
  },
  scrollView: {
    backgroundColor: 'transparent',
    paddingBottom: 130,
  },
  searchButtonText: {
    color: '#FFFFFFFF',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: '500'
  },
  container: {
    backgroundColor: "#f2f2f2",
    flex: 1
  },

  label: {
    fontSize: 15,
    fontWeight: "500"
  },
  tagInputContainer: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  header: {
    backgroundColor: gui.mainColor,
    height: 64
  },
  viewListContainer: {
    // paddingBottom: 50
  },
  listStyle: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  rowDiaBan: {
    flex: 1,
    justifyContent: 'flex-start',
    // height: 100,

    // flexDirection: 'column'
  },

  input: {
    fontSize: 15,
    width: 200,
    height: 30,
    borderWidth: 1,
    alignSelf: 'center',
    padding: 5

  },
  viewTabInterest: {
    flexGrow: 1,
    flexDirection: 'row',
    width: width - 32,
    height: 57,
    marginTop: 23.6,
    //marginLeft: 16,
  },
  tab1: {
    height: 57,
    width: (width - 32) / 2,
    //borderColor: '#1A526173',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderLeftWidth: 1,

  },
  tab2: {
    height: 57,
    width: (width - 32) / 2,
    //borderColor: '#1A526173',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderRightWidth: 1,
  },
  mimgList: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    // paddingLeft: 12,
    // paddingRight: 10,
    backgroundColor: 'white'
  },
  coverContent: {
    position: 'absolute',
    backgroundColor: 'white',
    opacity: 0.8,
    bottom: 2,
    left: 2,
    alignSelf: 'auto'
  },
  coverText: {
    alignItems: 'center',
    fontFamily: gui.fontFamily,
    fontSize: 12
  },
  deleteContent: {
    position: 'absolute',
    backgroundColor: 'white',
    opacity: 0.5,
    top: 2,
    right: 2,
    alignSelf: 'auto'
  },
  deleteButton: {
    alignItems: 'center'
  },
  captureIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
    padding: 5
  },
  imgItem: {
    width: 48,
    height: 48,
    backgroundColor: "#1A526173",
    justifyContent: 'center',
    borderWidth: 0,
    opacity: 0.5
    // marginLeft: 5,
    //borderColor: gui.separatorLine,
  },
  viewModalStyle: {
    justifyContent: 'flex-start',
    height: 180,
    width: width - 28,
    marginVertical: 0,
    backgroundColor: 'transparent',
    alignItems: 'center'
  },
  viewShowModal: {
    position: 'absolute',
    bottom: 50,
    justifyContent: 'flex-start',
    alignItems: 'center',
    flex: 1,
    backgroundColor: 'transparent',

  },
  viewSwipeButton: {
    backgroundColor: 'transparent',
    height: 106,
    width: width - 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewButtonModal: {
    height: 52,
    width: width - 28,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12
  },
  textDelete: {
    color: '#f43838',
    fontSize: 17,
    fontFamily: gui.fontFamily,
    fontWeight: '400'
  },
  lineSpaceButton: {
    width: width - 28,
    backgroundColor: 'rgba(80,80,80,0.6)',
    borderColor: '#fff',
    borderTopWidth: 0.5,
    height: 1
  },
  viewSwipeButton2: {
    backgroundColor: 'white',
    height: 52,
    width: width - 28,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    marginTop: 8
  },
  loadingContent: {
    position: 'absolute',
    top: -23,
    left: width / 2,
    alignItems: 'center',
    justifyContent: 'center'
  },
  resultContainer: {
    position: 'absolute',
    // top: height/2,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center'
  },
  textDeny: {
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: gui.mainAgentColor,
    fontSize: 15
  },
  searchButtonText2: {
    margin: 0,
    padding: 10,
    paddingRight: 17,
    color: 'white',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  dotContent: {
    position: 'absolute',
    right: 6,
    top: 10
  }
});