import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableHighlight,
    TextInput,
    Alert
} from 'react-native';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Actions} from 'react-native-router-flux';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import {Map} from 'immutable';

import DanhMuc from '../../assets/DanhMuc';

import placeUtil from '../../lib/PlaceUtil';

import CommonUtils from '../../lib/CommonUtils';

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import GroupSearchHeader from './GroupSearchHeader';
import NewLogin from '../../components/loginGroup/NewLogin';

import * as globalActions from '../../reducers/global/globalActions';
import * as groupActions from '../../reducers/group/groupActions';

import Modal from 'react-native-modalbox';

import GroupMgmt2 from './GroupMgmt2';

import RowSuggest from './RowSuggest';
import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

let ds_groupMain = new ListView.DataSource({rowHasChanged : (r1,r2) => r1 != r2});

let {width, height} = utils.getDimensions();

const actions = [
    globalActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupMain extends Component {
    constructor(props){
        super(props);
        let listRequestedGroup = props.group.searchResult.listRelatedGroup;
        listRequestedGroup = listRequestedGroup.filter((one) => {
            return one.joinStatus == 1
        }) || [];
        let listGroup = props.group.searchResult.listGroup;
        listGroup = this._removeRequestedGroupInSearchResult(listGroup, listRequestedGroup);
        let joinedGroup = props.global.currentUser.joinedGroup;
        if (this.props.global.currentUser.joinedGroup) {
            this._onSaveInitialGroup();
        }
        this.state = {
            // searchText: props.group.searchFields.name,
            searchText: '',
            listGroup: listGroup,
            listRequestedGroup: listRequestedGroup,
            isOpenModalJoin: false,
            joinedGroup: joinedGroup,
            hideGroupGuide: false,
            textToChuSan: ''
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.group.searchResult.listGroup !== this.props.group.searchResult.listGroup) {
            let joinedGroup = this.state.joinedGroup || nextProps.global.currentUser.joinedGroup;
            let listRequestedGroup = nextProps.group.searchResult.listRelatedGroup;
            listRequestedGroup = listRequestedGroup.filter((one) => {
                return one.joinStatus == 1
            }) || [];
            let listGroup = nextProps.group.searchResult.listGroup;
            listGroup = this._removeRequestedGroupInSearchResult(listGroup, listRequestedGroup);
            if (joinedGroup) {
                this._onSaveInitialGroup();
            }
            this.setState({
                // searchText: nextProps.group.searchFields.name,
                listGroup: listGroup,
                listRequestedGroup: listRequestedGroup,
                joinedGroup: joinedGroup});
        }
    }

    componentWillMount() {
        setTimeout(() => this.fetchData(), 300);
    }

    fetchData() {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.getRelatedGroup({userID: userID}, token, () => {
            this._loadGroupList();
        });
    }

    _loadGroupList() {
        this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
    }

    _removeRequestedGroupInSearchResult(listGroup, listRequestedGroup) {
        let hashRelatedGroup = {};
        listRequestedGroup.forEach((one) => {
            if (one.joinStatus == 1) {
                hashRelatedGroup[one.groupID] = true;
            }
        });
        return listGroup.filter((one) => {
            return !hashRelatedGroup[one.groupID]
        });
    }

    render() {
        if (this.props.global.loggedIn) {
            let {initialGroup} = this.props.global.help;
            if (initialGroup || this.props.global.currentUser.joinedGroup) {
                return (
                    <GroupMgmt2 {...this.props} />
                );
            } else {
                // let textTop = 'Tạo hoặc tham gia vào sàn môi giới để có thể chia sẻ bài đăng, thảo luận và nhiều hơn nữa.';
                let {hideGroupGuide} = this.state;
                return (
                    <View style={styles.container}>
                        {this._renderHeader()}
                        <FullLine />
                        <ScrollView
                            automaticallyAdjustContentInsets={false}
                            showsVerticalScrollIndicator={false}
                            vertical={true}
                            style={[styles.scrollView, {backgroundColor: '#fff'}]}>
                            {hideGroupGuide ? null : this._renderGroupGuide()}
                            {/*<View style={styles.viewDangNhap}>
                                <Text style={styles.textDangNhap}>Sàn Môi giới</Text>
                            </View>
                            <View style={styles.viewIntroduce}>
                                <View style={styles.viewTextTop}>
                                    <Text style={styles.textTopPattern}>{textTop}</Text>
                                </View>
                            </View>*/}
                            {/*this._renderRequestedGroupView()*/}
                            {this._renderListGroupWall()}
                        </ScrollView>
                        {this._openModalJoin()}
                    </View>
                );
            }
        } else {
            return (
                <View style={styles.container} >
                    <NewLogin />
                </View>
            )
        }
    }

    _renderGroupGuide() {
        let title = '';
        let content = 'Tạo sàn của riêng bạn để trao đổi\nvà liên kết các môi giới';
        let addGroupTitle = 'Tạo sàn';
        let nearGroupTitle = 'Sàn gần bạn';
        return (
            <View style={[styles.container, {alignItems: 'center', backgroundColor: '#fff'}]}>
                <View style={[styles.viewGroupContent, {marginBottom: 13}]}>
                    <View style={styles.viewTitleGroup}>
                        <View style={styles.viewCloseButton}/>
                        <View style={styles.titleGroupContent}>
                            <Text style={styles.textTitleGroup}>{title}</Text>
                        </View>
                        <TouchableOpacity style={styles.viewCloseButton}
                                          onPress={this._onGroupGuideClose.bind(this)}
                        >
                            <MaterialCommunityIcons name="close" size={22} color={gui.mainTextColor} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewMoreGroup}>
                        <Text style={styles.textGroupGuide}>
                            {content}
                        </Text>
                    </View>
                    <View style={styles.viewIconButton}>
                        {/*<View style={{width: width/2-26, alignItems: 'flex-end', paddingRight: 8}}>
                        <TouchableOpacity style={styles.touchButtonGroup}
                                          onPress={this._onAddGroup.bind(this)}
                        >
                            <Text style={styles.textButtonGroup}> {addGroupTitle} </Text>
                        </TouchableOpacity>
                        </View>
                        <View style={{width: width/2-26, alignItems: 'flex-start', paddingLeft: 8}}>
                        <TouchableOpacity style={[styles.touchButtonGroup, {backgroundColor: gui.mainAgentColor}]}
                                          onPress={this._onNearGroup.bind(this)}
                        >
                            <Text style={[styles.textButtonGroup, {color: '#fff'}]}> {nearGroupTitle} </Text>
                        </TouchableOpacity>
                        </View>*/}
                        <TouchableOpacity style={styles.touchButtonGroup}
                                          onPress={this._onAddGroup.bind(this)}
                        >
                            <Text style={styles.textButtonGroup}> {addGroupTitle} </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    _onGroupGuideClose() {
        this.setState({
            hideGroupGuide: true
        })
    }

    _onNearGroup() {

    }

    _renderRequestedGroupView() {
        if (this.state.listRequestedGroup &&
            this.state.listRequestedGroup.length == 0) {
            return null;
        }
        let label = 'Đã yêu cầu tham gia';
        return (
            <View style={styles.requestedGroupView}>
                <View style={styles.viewIntroduce}>
                    <View style={styles.viewTextTop}>
                        <Text style={styles.textTopPattern}>{label}</Text>
                    </View>
                </View>
                {this._renderListRequestedGroup()}
            </View>
        )
    }

    _renderListRequestedGroup() {
        let listRequestedGroup = this.state.listRequestedGroup || [];
        let dsRequestedGroup = ds_groupMain.cloneWithRows(listRequestedGroup);
        return(
            <ListView
                style={[styles.groupListView, {marginTop: 12}]}
                enableEmptySections={true}
                dataSource={dsRequestedGroup}
                renderRow={this._renderRowRequestedGroup.bind(this)}
                showsVerticalScrollIndicator={false}
            />
        );
    }

    _renderRowRequestedGroup(data) {
        let statusFmt = DanhMuc.TIN_CHO_DUYET;

        let allDuAn = data.diaBan.filter((one) => {
            return one.type == 'A'
        });
        let allKhuVuc = data.diaBan.filter((one) => {
            return one.type != 'A'
        });
        let duAn = '';
        if (allDuAn && allDuAn.length > 0) {
            let oneDuAn = allDuAn[0];
            duAn = oneDuAn.duAn;
            if (allDuAn.length > 1) {
                duAn += ', +' + (allDuAn.length-1) + ' dự án khác';
            }
        }
        let khuVuc = '';
        if (allKhuVuc && allKhuVuc.length > 0) {
            let oneKhuVuc = allKhuVuc[0];
            khuVuc = placeUtil.getKhuVucFullName(oneKhuVuc);
            if (allKhuVuc.length > 1) {
                khuVuc += ', +' + (allKhuVuc.length-1) + ' khu vực khác';
            }
        }

        let showDiaBanItems = allKhuVuc && allKhuVuc.length > 0 && allDuAn && allDuAn.length > 0;

        let duAnItem = duAn ? <View style={{flexDirection: 'row'}}>
            <RelandIcon noAction={true}
                        name="suggest-project" color={'#526173'}
                        size={16} iconProps={{style: styles.diaBanIcon}}>
            </RelandIcon>
            <Text style={styles.diaBanText}>{duAn}</Text>
        </View> : null;

        let khuVucItem = khuVuc ? <View style={{flexDirection: 'row'}}>
            <RelandIcon noAction={true}
                        name="suggest-location" color={'#526173'}
                        size={16} iconProps={{style: styles.diaBanIcon}}>
            </RelandIcon>
            <Text style={styles.diaBanText}>{khuVuc}</Text>
        </View> : null;

        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarImage = {uri: data.avatar};
        if (!data.avatar) {
            avatarImage = defaultAvatar;
        }

        let defaultGroupImage = CommonUtils.getNoCoverImage();
        let groupImage = {uri: data.image};
        if (!data.image) {
            groupImage = defaultGroupImage;
        }

        return (
            <TouchableOpacity onPress={this._onGroupDetailPress.bind(this, data)}>
                <View style={{flex: 1, marginLeft: 15, marginRight: 15, marginBottom: 15, borderWidth: 1, borderColor: 'rgba(82,97,115,0.3)', backgroundColor: '#fff'}}>
                    <View style={styles.groupMainView}>
                        <Image style={styles.groupImage} source={groupImage} defaultSource={defaultGroupImage}/>
                        <View style={{flex: 1, flexDirection: 'row'}}>
                            <View style={styles.chiTietView}>
                                <View style={{flex: 1, paddingLeft: 16, paddingRight: 16, justifyContent: 'flex-start'}}>
                                    <Text style={styles.groupName} numberOfLines={1}>{data.name}</Text>
                                </View>
                                <View style={{flex: 1, flexDirection: 'row', paddingLeft: 17, paddingTop: 5}}>
                                    <View style={{flexDirection: 'row'}}>
                                        <Image style={styles.createByImage} source={avatarImage} defaultSource={defaultAvatar}/>
                                        <Text style={[styles.groupStatus, {marginLeft: 12}]}>{data.fullNameChuSan}</Text>
                                    </View>
                                    <View style={{flexDirection: 'row', paddingLeft: 17}}>
                                        <RelandIcon noAction={true}
                                                    name="group-two" color={'#526173'}
                                                    size={16} iconProps={{style: [styles.diaBanIcon, {marginTop: 1}]}}>
                                        </RelandIcon>
                                        <Text style={styles.groupStatus}>{data.countMember || 0}</Text>
                                    </View>
                                </View>
                            </View>
                            <Text style={styles.groupStatus}>{statusFmt}</Text>
                        </View>
                    </View>
                    {showDiaBanItems ? <View>
                        <View style={[styles.lineView, {marginLeft: 17, marginRight: 17}]}/>
                        <View style={styles.diaBanView}>
                            {duAnItem}
                            {khuVucItem}
                        </View>
                    </View> : null}
                </View>
            </TouchableOpacity>
        );
    }

    _openModalJoin() {
        return (
            <Modal isOpen={this.state.isOpenModalJoin}
                   onClosed={this._onContentModal.bind(this)}
                   style={styles.viewModalStyle2}
                   position={"center"}
                   swipeToClose={false}
                   backdropPressToClose={true}
                   animationDuration={200}
            >
                {this._renderJoinContent()}
            </Modal>
        );
    }

    _onContentModal() {
        this.setState({
            isOpenModalJoin: false
        });
    }

    _renderJoinContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={{ marginTop: 18, marginLeft: 0, width: width - 80, height:108 }}>
                    <TextInput
                        autoFocus={false}
                        autoCapitalize='none'
                        autoCorrect={false}
                        returnKeyType='done'
                        multiline={true}
                        style={styles.viewTextInput}
                        placeholder="Để lại ghi chú cho chủ sàn…" placeholderTextColor={gui.arrowColor}
                        onChangeText={(text) => { this.onValueChange("textToChuSan", text) }}
                        value={this.state.textToChuSan}

                    />
                </View>

                <View style={styles.searchButtonView}>
                    <TouchableOpacity
                        style={styles.searchButton}
                        onPress={this.onRequestJoin.bind(this)}
                    >
                        <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    onValueChange(key: string, value: string) {
        // this.props.actions.onGroupFieldChange(key, value);
        this.setState({textToChuSan: value})
    }

    onRequestJoin() {

        let rowData = this.state.data;
        if (!rowData) {
            return;
        }

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let requestJoinDto = {
            "requester": currentUser.userID || undefined,
            "requesterName": currentUser.fullName || currentUser.phone || currentUser.email || undefined,
            "approver": rowData.userID || rowData.createdBy || undefined,
            "member": currentUser.userID || undefined,
            "memberName": currentUser.fullName || undefined,
            "memberNameKhongDau": utils.locDauV2(utils.standardlizeName(currentUser.fullName)),
            "memberAvatar": currentUser.avatar || undefined,
            "groupID": rowData.groupID || undefined,
            "groupName": rowData.name || undefined,
            "groupImage": rowData.image || undefined,
            "message": this.state.textToChuSan
        };

        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let fetchRelatedGroupSuccess = this.props.actions.fetchRelatedGroupSuccess;

        this.props.actions.requestToJoin(requestJoinDto, token)
            .then(res => {
                // console.log("server respond: ", res);
                this.setState({
                    loading: false,
                    isOpenModalJoin: false,
                    textToChuSan: ''
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    // Actions.popTo('root');
                    // Actions.AdsMgmt();

                    rowData.joinStatus = 1;
                    let found = listRelatedGroup.find((one) => {
                        return one.groupID == rowData.groupID
                    });
                    if (found) {
                        listRelatedGroup = listRelatedGroup.filter((one) => {
                            return one.groupID != rowData.groupID
                        });
                    }
                    listRelatedGroup = [...listRelatedGroup, rowData];
                    fetchRelatedGroupSuccess(listRelatedGroup);

                    let listGroup = this.state.listGroup.filter((one) => {
                        return one.groupID != rowData.groupID
                    });
                    this.setState({listGroup: listGroup, listRequestedGroup: [...this.state.listRequestedGroup, rowData]});

                    setTimeout(() => Alert.alert(
                        "Thông báo",
                        "Xác nhận yêu cầu tham gia sàn được gửi thành công và đang chờ duyệt.",
                        [{ text: 'Đóng', onPress: () => { } }]), 1000);
                }
            });
    }

    _renderHeader() {
        return(
            <GroupSearchHeader
                onChangeText={(text) => {this._onUserSearchChange(text)}}
                value={this.state.searchText}
                onGroupSearchPress={this._onGroupSearchPress.bind(this)}
                onAddGroup={this._onAddGroup.bind(this)}
            />
        );
    }

    _onAddGroup() {
        this._onRefreshGroup();

        this._onSaveInitialGroup();

        Actions.Group();
    }

    _onSaveInitialGroup() {
        if (this.props.global.help.initialGroup) {
            return;
        }
        // local storage initialEvent
        this.props.actions.onHelpedModalChange('initialGroup', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialGroup = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _onRefreshGroup() {
        this.props.actions.onGroupFieldChange('groupID', null);
        this.props.actions.onGroupFieldChange('name', '');
        this.props.actions.onGroupFieldChange('groupType', 'public');
        this.props.actions.onGroupFieldChange('chiTiet', '');
        this.props.actions.onGroupFieldChange('photos', []);
        this.props.actions.onGroupFieldChange('allDiaChinh', []);
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({searchText: text});
    }
    _renderListGroupWall() {
        let listGroup = this.state.listGroup || [];
        if (listGroup.length == 0) {
            return null;
        }
        let dsGroupWall = ds_groupMain.cloneWithRows(listGroup);
        let textEnd = 'SÀN GỢI Ý CHO BẠN';
        return(
            <View style={{flex: 1, backgroundColor: '#fff'}}>
                <FullLine style={{ marginLeft: 8 }} />
                <View style={styles.viewIntroduce}>
                    <View style={styles.viewTextEnd}>
                        <Text style={[styles.textTopPattern, {color: gui.mainTextColor, fontSize: 10}]}>{textEnd}</Text>
                    </View>
                </View>
                <ListView
                    style={[styles.groupListView, {marginTop: 2}]}
                    enableEmptySections={true}
                    dataSource={dsGroupWall}
                    renderRow={this._renderRowGoiY.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowGoiY(data) {
        // data cua san goi y
        return (
            <View>
                <RowSuggest data={data}
                            status={1}
                            onRequestJoin={this._onJoinGroupPress.bind(this)}
                            onPressRow={this._onGroupDetailPress.bind(this)}
                            {...this.props} />
                <FullLine style={{ marginLeft: 48 }} />
            </View>
        )
    }

    _renderRowGroupWall(data) {
        let statusFmt = DanhMuc.groupStatus[data.status] || '';

        let allDuAn = data.diaBan && data.diaBan.filter((one) => {
            return one.type == 'A'
        }) || [];
        let allKhuVuc = data.diaBan && data.diaBan.filter((one) => {
            return one.type != 'A'
        }) || [];
        let duAn = '';
        if (allDuAn && allDuAn.length > 0) {
            let oneDuAn = allDuAn[0];
            duAn = oneDuAn.duAn;
            if (allDuAn.length > 1) {
                duAn += ', +' + (allDuAn.length-1) + ' dự án khác';
            }
        }
        let khuVuc = '';
        if (allKhuVuc && allKhuVuc.length > 0) {
            let oneKhuVuc = allKhuVuc[0];
            khuVuc = placeUtil.getKhuVucFullName(oneKhuVuc);
            if (allKhuVuc.length > 1) {
                khuVuc += ', +' + (allKhuVuc.length-1) + ' khu vực khác';
            }
        }

        let showDiaBanItems = (allKhuVuc && allKhuVuc.length > 0) || (allDuAn && allDuAn.length > 0);

        let duAnItem = duAn ? <View style={{flexDirection: 'row'}}>
            <RelandIcon noAction={true}
                        name="suggest-project" color={'#526173'}
                        size={16} iconProps={{style: styles.diaBanIcon}}>
            </RelandIcon>
            <Text style={styles.diaBanText} numberOfLines={1}>{duAn}</Text>
        </View> : null;

        let khuVucItem = khuVuc ? <View style={{flexDirection: 'row'}}>
            <RelandIcon noAction={true}
                        name="suggest-location" color={'#526173'}
                        size={16} iconProps={{style: styles.diaBanIcon}}>
            </RelandIcon>
            <Text style={styles.diaBanText} numberOfLines={1}>{khuVuc}</Text>
        </View> : null;

        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarImage = {uri: data.avatar};
        if (!data.avatar) {
            avatarImage = defaultAvatar;
        }

        let defaultGroupImage = CommonUtils.getNoCoverImage();
        let groupImage = {uri: data.image};
        if (!data.image) {
            groupImage = defaultGroupImage;
        }

        return (
            <TouchableOpacity onPress={this._onGroupDetailPress.bind(this, data)}>
                <View style={{flex: 1, marginLeft: 15, marginRight: 15, marginBottom: 15, borderWidth: 1, borderColor: 'rgba(82,97,115,0.3)', backgroundColor: '#fff'}}>
                    <View style={styles.groupMainView}>
                        <Image style={styles.groupImage} source={groupImage} defaultSource={defaultGroupImage}/>
                        <View style={{flex: 1, flexDirection: 'row'}}>
                            <View style={styles.chiTietView}>
                                <View style={{flex: 1, paddingLeft: 16, paddingRight: 16, justifyContent: 'flex-start'}}>
                                    <ScalableText style={styles.groupName} numberOfLines={2}>{data.name}</ScalableText>
                                </View>
                                <View style={{width: width-210, flexDirection: 'row', paddingLeft: 17, paddingTop: 5}}>
                                    <View style={{flexDirection: 'row'}}>
                                        <Image style={styles.createByImage} source={avatarImage} defaultSource={defaultAvatar}/>
                                        <Text style={[styles.groupStatus, {marginLeft: 12}]} numberOfLines={1}>{data.fullNameChuSan}</Text>
                                    </View>
                                    <View style={{flexDirection: 'row', paddingLeft: 17}}>
                                        <RelandIcon noAction={true}
                                                    name="group-two" color={'#526173'}
                                                    size={16} iconProps={{style: [styles.diaBanIcon, {marginTop: 1}]}}>
                                        </RelandIcon>
                                        <Text style={styles.groupStatus}>{data.countMember || 0}</Text>
                                    </View>
                                </View>
                            </View>
                            {data.joinStatus != 1 && data.joinStatus != 2 ?
                                <TouchableOpacity style={styles.touchJoinGroup}
                                                  onPress={this._onJoinGroupPress.bind(this, data)}
                                >
                                    <Text style={[styles.groupStatus, {color: gui.mainAgentColor}]}>Tham gia</Text>
                                </TouchableOpacity>
                                : <Text style={styles.groupStatus}>{statusFmt}</Text>
                            }
                        </View>
                    </View>
                    {showDiaBanItems ? <View>
                        <View style={[styles.lineView, {marginLeft: 17, marginRight: 17}]}/>
                        <View style={styles.diaBanView}>
                            {duAnItem}
                            {khuVucItem}
                        </View>
                    </View> : null}
                </View>
            </TouchableOpacity>
        );
    }

    _onGroupDetailPress(data) {
        this.props.actions.getGroupDetail({ 'groupID': data.groupID }, (res) => {
            Actions.GroupDetail2({groupData: res.data, groupID: data.groupID, owner: 'GroupMain'});                    
        });
        
    }

    _onJoinGroupPress(data) {
        // this.onValueChange("textToChuSan", '');
        this.setState({textToChuSan: '', data: data, groupID: data.groupID, isOpenModalJoin: true});
    }

    _renderButtonChat() {
        let totalMessages = '23';
        return(
            <TouchableOpacity style={styles.viewButtonChat}
                              onPress={() => this.onPressChat()}
            >
                <View style={styles.viewCircleChat}>
                    <Icon name="comments-o" size={22} color={'#fff'} style={{marginLeft: 0}} />
                </View>
                {/* <View style={styles.viewNumberMessage}>
                    <Text style={[styles.textNameAvatar, {fontSize: 8, color: '#fff'}]}>{totalMessages}</Text>
                </View> */}
            </TouchableOpacity>
        );
    }

    onPressChat() {
        Actions.GroupInbox();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
      flex: 1
    },
    lineFullWidth: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width,
        opacity: 0.8
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewIntroduce: {
        width: width,
        // height: 100,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 9
    },
    viewTextTop: {
        width: width - 32,
        // height: 60,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    viewTextEnd: {
        width: width - 16,
        // height: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
    },
    textTopPattern: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontSize: 15
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight : 'normal'
    },
    viewListContainer: {
        paddingBottom: 50
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    groupListView: {
        flex: 1,
        backgroundColor: '#fff'
    },
    groupMainView: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 17,
        paddingLeft: 17,
        paddingRight: 17,
        paddingBottom: 10
    },
    chiTietView: {
        flex: 1
    },
    groupImage: {
        width: 48,
        height: 48
    },
    groupName: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight : '500',
        color: '#526173',
        textAlign: 'left'
    },
    groupStatus: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        color: 'rgba(82,97,115,0.5)',
        textAlign: 'center'
    },
    diaBanView: {
        flex: 1,
        paddingTop: 17,
        paddingRight: 17,
        paddingLeft: 17
    },
    diaBanText: {
        fontSize: gui.capitalizeFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        color: '#526173',
        textAlign: 'left',
        marginBottom: 17
    },
    diaBanIcon: {
        marginRight: 12
    },
    createByImage: {
        width: 16,
        height: 16,
        borderRadius: 8
    },
    lineView: {
        borderTopWidth: 1,
        height:1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    viewModalStyle2: {
        justifyContent: 'center',
        height: 210,
        width: width - 30,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        width: width - 80
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 48,
        bottom: 17,
        width: width,
        backgroundColor: 'transparent',
        //borderRadius: 24
    },
    searchButton: {
        height: 48,
        width: width - 64,
        backgroundColor: gui.mainColor,
        borderRadius: 24,
        alignItems: 'center',
        justifyContent: 'center'
    },
    searchButtonText: {
        color: '#FFFFFFFF',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    requestedGroupView: {
        flex: 1
    },
    touchJoinGroup: {
        // paddingVertical: 2,
        // paddingHorizontal: 5,
        borderRadius: 3,
        borderColor: gui.mainAgentColor,
        borderWidth: 1,
        height: 24,
        width: 72,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewGroupContent: {
        height: 'auto',
        width: width - 16,
        alignItems: 'center',
        marginTop: 10,
        // paddingBottom: 13,
        paddingTop: 13,
        backgroundColor: '#fff',
        shadowColor: '#000',
        // shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.1,
        shadowRadius: 8
    },
    viewTitleGroup: {
        height: 18,
        width: width - 16,
        flexDirection: 'row'
    },
    titleGroupContent: {
        height: 18,
        width: width - 76,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewCloseButton: {
        height: 18,
        width: 30,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 13
    },
    textTitleGroup: {
        color: gui.mainTextColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewMoreGroup: {
        marginTop: 3,
        marginBottom: 11,
        width: width - 16,
        paddingLeft: 10,
        paddingRight: 10,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textGroupGuide: {
        color   :'#262626',
        fontFamily: gui.fontFamily,
        fontSize: 15,
        textAlign: 'center',
        backgroundColor: 'transparent',
        marginLeft: 0
    },
    viewIconButton: {
        // height: 60,
        width: width - 16,
        marginBottom: 15,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchButtonGroup: {
        width: 120,
        paddingVertical: 4,
        borderWidth: 1,
        borderColor: gui.mainAgentColor,
        borderRadius: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textButtonGroup: {
        color: gui.mainAgentColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupMain);