import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    StatusBar,
    FlatList,
    ImageBackground
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';
import LinearGradient from 'react-native-linear-gradient';

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import TabGroupMgmt from './TabGroupMgmt';
import GroupSearchHeader from './GroupSearchHeader';
import danhMuc from '../../assets/DanhMuc';
import ScalableText from 'react-native-text';
import GiftedSpinner from "../GiftedSpinner";
import Ionicons from 'react-native-vector-icons/Ionicons';
import FunctionModal from '../FunctionModal'

import FontAwesomeLight from '../font/FontAwesomeLight'
import FontAwesomeSolid from '../font/FontAwesomeSolid'
import RowSuggest from './RowSuggest';
import OfflineBar from '../line/OfflineBar';
import apiUtils from '../../lib/ApiUtils';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';

import Toast, { DURATION } from '../toast/Toast';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';
const actions = [
    globalActions,
    meActions,
    groupSearchActions,
    groupActions,
    inboxActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupMgmt2 extends Component {
    constructor(props) {
        super(props);

        let listRequestedGroup = props.group.searchResult.listRelatedGroup;
        listRequestedGroup = listRequestedGroup.filter((one) => {
            return one.joinStatus == 1 || one.joinStatus == 2
        }) || [];

        let listGroup = props.group.searchResult.listGroup;
        listGroup = this._removeRequestedGroupInSearchResult(listGroup, listRequestedGroup);

        this.state = {
            laoding: false,
            searchText: '',
            loaiSan: props.group.selectedGroupTab,
            isOpenMoreModal: false,
            selectedGroup: null,
            listRelatedGroup: props.group.searchResult.listRelatedGroup,
            listGroup: listGroup,
            isOpenModalJoin: false,
            rowRequest: null,
            textToChuSan: '',
            listSuggestGroup: props.group.listSuggestGroup
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.group.selectedGroupTab !== nextProps.group.selectedGroupTab) {
            this.setState({ loaiSan: nextProps.group.selectedGroupTab });
        }

        if (this.props.group.listSuggestGroup !== nextProps.group.listSuggestGroup) {
            this.setState({ listSuggestGroup: nextProps.group.listSuggestGroup });
        }

        if (this.props.group.searchResult.listRelatedGroup !== nextProps.group.searchResult.listRelatedGroup) {
            this.setState({ listRelatedGroup: nextProps.group.searchResult.listRelatedGroup })
        }

        if (nextProps.group.searchResult.listGroup !== this.props.group.searchResult.listGroup) {
            let joinedGroup = this.state.joinedGroup || nextProps.global.currentUser.joinedGroup;
            let listRequestedGroup = nextProps.group.searchResult.listRelatedGroup;
            listRequestedGroup = listRequestedGroup.filter((one) => {
                return one.joinStatus == 1 || one.joinStatus == 2
            }) || [];
            let listGroup = nextProps.group.searchResult.listGroup;
            listGroup = this._removeRequestedGroupInSearchResult(listGroup, listRequestedGroup);
            this.setState({
                listGroup: listGroup,
                listRequestedGroup: listRequestedGroup,
                joinedGroup: joinedGroup
            });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeader()}
                {this._renderBodyGroupMgmt()}
                {this._renderLoadingView()}
                {this._openMoreModal()}
                {this._openModalJoin()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        );
    }

    _openModalJoin() {
        return (
            <Modal isOpen={this.state.isOpenModalJoin}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle2}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                {this._renderJoinContent()}
            </Modal>
        )
    }

    _renderJoinContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={{ marginTop: 18, marginLeft: 0, width: width - 80, height:108 }}>
                    <TextInput
                        autoFocus={false}
                        autoCapitalize='none'
                        autoCorrect={false}
                        returnKeyType='done'
                        multiline={true}
                        style={styles.viewTextInput}
                        placeholder="Để lại ghi chú cho chủ sàn…" placeholderTextColor={gui.arrowColor}
                        onChangeText={(text) => { this.onValueChange("textToChuSan", text) }}
                        value={this.state.textToChuSan}

                    />
                </View>
                {this._renderButtonJoin()}
            </View>
        )
    }

    _renderButtonJoin() {
        if (this.props.group.requestingJoin)
            return (<View style={styles.searchButtonView}>
                <View
                    style={styles.searchButton}
                >
                    <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                </View>
            </View>)
        return (
            <View style={styles.searchButtonView}>
                <TouchableOpacity
                    style={styles.searchButton}
                    onPress={this.onRequestJoin.bind(this)}
                >
                    <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                </TouchableOpacity>
            </View>
        )

    }

    onValueChange(key, value) {
        // this.props.actions.onGroupFieldChange(key, value);
        this.setState({ textToChuSan: value })
    }

    _onContentModal() {
        this.setState({
            isOpenModalJoin: false
        });
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        let modalHeight = this.state.loaiSan == "sanQuanLy" ? 173 : 120;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {
        
        let items = []
        if (this.state.loaiSan == "sanYeuCau") {
            items.push({_text: 'Hủy yêu cầu tham gia', _function: () => this._onCancelJoinPress()})
        }
        if (this.state.loaiSan == "sanQuanLy") {
            items.push({_text: 'Sửa sàn', _function: () => this._onEditGroupPress()})
            items.push({_text: 'Xóa sàn', _function: () => this._onDeleteGroupPress()})
        }
        if (this.state.loaiSan == "sanThamGia") {
            items.push({_text: 'Rời khỏi sàn', _function: () => this._onLeaveGroupPress()})
        }

        return (
            <FunctionModal 
                // data={data}
                items={items}
                onCloseModal={this._outMoreModal.bind(this)} />
        )
    }

    _onCancelJoinPress(data) {
        this._doLeaveOrCall('Bạn muốn hủy yêu cầu tham gia ?', data);
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn rời khỏi sàn ?');
    }

    _doLeaveOrCall(title, data) {
        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = data.groupID;
                    let userID = this.props.global.currentUser.userID;
                    let token = this.props.global.currentUser.token;
                    log.info('_doLeaveOrCall', data)
                    this.props.actions.leaveGroup({ groupID: groupID, userID: userID }, token);

                    this._outMoreModal();
                }
            }
            ]);
    }

    _onEditGroupPress() {
        let selectedGroup = this.state.selectedGroup;
        if (!selectedGroup) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        if (userID != selectedGroup.createdBy) {
            Alert.alert('Thông báo', 'Bạn không phải là quản trị của sàn \'' + selectedGroup.name + '\' ?');
            this._outMoreModal();
            return;
        }
        this.props.actions.onGroupFieldChange('groupID', selectedGroup.groupID);
        this.props.actions.onGroupFieldChange('name', selectedGroup.name);
        this.props.actions.onGroupFieldChange('groupType', selectedGroup.groupType);
        this.props.actions.onGroupFieldChange('chiTiet', selectedGroup.chiTiet);
        this.props.actions.onGroupFieldChange('photos', selectedGroup.image ? [{ uri: selectedGroup.image }] : []);
        this.props.actions.onGroupFieldChange('allDiaChinh', selectedGroup.diaBan);
        Actions.Group({ doAfterSaveGroup: this._doAfterSaveGroup.bind(this) });
        this._outMoreModal();
    }

    _doAfterSaveGroup() {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.getRelatedGroup({ userID: userID }, token, () => {
            this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
        });
    }

    _onDeleteGroupPress() {
        let selectedGroup = this.state.selectedGroup;
        if (!selectedGroup) {
            return;
        }
        Alert.alert('Thông báo', 'Bạn muốn xóa sàn \'' + selectedGroup.name + '\' ?',
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedGroup.groupID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.deleteGroup(groupID, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            } else {
                                let userID = this.props.global.currentUser.userID || undefined;
                            }
                        });
                    this._outMoreModal();
                }
            }
            ]);
    }

    _renderHeader() {
        let numberInbox = 0;
        if (this.props.inbox.listHomeInbox) {
            let allGroupInboxDS = this.props.inbox.listHomeInbox.filter((one) => {
                    let valid = one.content != undefined && (!one.spamStatus || (one.spamStatus != 1 && one.spamStatus != 2));
                    return valid && !!one.numOfUnreadMessage;
                }) || [];
            numberInbox = allGroupInboxDS.length;
        }
        return (
            <GroupSearchHeader
                onChangeText={(text) => { this._onUserSearchChange(text) }}
                value={this.state.searchText}
                onGroupSearchPress={this._onGroupSearchPress.bind(this)}
                onPressChat={this.onPressChat.bind(this)}
                numberInbox={numberInbox}
            />
        );
    }

    onPressChat() {
        Actions.GroupInbox();
    }

    _onAddGroup() {
        this._onRefreshGroup();
        Actions.Group();
    }

    _onRefreshGroup() {
        this.props.actions.onGroupFieldChange('groupID', null);
        this.props.actions.onGroupFieldChange('name', '');
        this.props.actions.onGroupFieldChange('groupType', 'public');
        this.props.actions.onGroupFieldChange('chiTiet', '');
        this.props.actions.onGroupFieldChange('photos', []);
        this.props.actions.onGroupFieldChange('allDiaChinh', []);
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }

    _renderBodyGroupMgmt() {
        return (
            <View style={styles.viewBody}>
                {this._renderTabSelected()}
                <FullLine style={{ marginTop: 2 }} />
                {this._renderContentBody()}
            </View>
        );
    }

    _renderTabSelected() {
        return (
            <View style={styles.viewTab}>
                <FullLine />
                <View style={styles.viewTabSelect}>
                    <View style={styles.viewTabChild}>
                        <TabGroupMgmt name={'sanThamGia'}
                            onPress={this._onLoaiSanChange.bind(this)}
                            selected={this.state.loaiSan == 'sanThamGia'}>Sàn</TabGroupMgmt>
                    </View>
                    <View style={styles.lineVertical} />
                    <View style={[styles.viewTabChild, { width: width / 2 - 1 }]}>
                        <TabGroupMgmt name={'sanKhamPha'}
                            onPress={this._onLoaiSanChange.bind(this)}
                            selected={this.state.loaiSan == 'sanKhamPha'}>Khám phá</TabGroupMgmt>
                    </View>
                </View>
                <FullLine style={{ marginTop: 3 }} />
            </View>
        );
    }

    _onLoaiSanChange(value) {
        this.props.actions.onGroupFieldChange('selectedGroupTab', value);
        this.setState({
            loaiSan: value
        });
    }

    _renderContentBody() {
        let imageNoGroup = require('../../assets/image/none_san.png');
        let textNoneGroup = 'Quản lý thành viên và các thông tin chia sẻ trên sàn. Tra cứu nguồn hàng trên sàn dễ dàng';
        let textNoneAds = ''
        let content;
        let listGroup = this.state.listGroup;
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;

        let userID = this.props.global.currentUser.userID;

        let listDaThamGia = listRelatedGroup.filter((one) => {
            return one.createdBy != userID && one.joinStatus == 2
        }) || [];
        let listSanCuaBan = listRelatedGroup.filter((one) => {
            return one.createdBy == userID && one.joinStatus == 2
        }) || [];
        let listSanDaYeuCau = listRelatedGroup.filter((one) => {
            return one.createdBy != userID && one.joinStatus == 1
        }) || [];


        let listSanGoiY = listGroup.filter((one) => {
            return one.createdBy != userID && one.joinStatus != 1 && one.joinStatus != 2
        }) || [];
        switch (this.state.loaiSan) {
            case "sanThamGia": {
                content = (
                    <View style={{ flex: 1 }}>
                        {
                            listDaThamGia.length==0 && listSanCuaBan.length==0 && listSanDaYeuCau.length==0 ?
                            (
                                <View style={styles.viewNoAds}>
                                    <Image
                                        source={imageNoGroup}
                                        resizeMode={"cover"}
                                        style={styles.imageNoGroup}
                                    />
                                    <Text style={[styles.textNoneAds, {fontWeight: '500', marginTop: 22}]}>
                                            Tạo sàn trên Landber Agent
                                    </Text>
                                    
                                    <Text style={[styles.textNoneAds, {}]}>
                                        {textNoneGroup}
                                    </Text>
                                    <TouchableOpacity style={styles.viewAddGroup}
                                                      onPress={this._onAddGroup.bind(this)}
                                    >
                                        <Text style={[styles.textNoneAds, {color: '#fff'}]}>
                                            Tạo sàn
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            ) :
                            <FlatList
                            ref={(ref) => this.scrollView = ref}
                            data={listDaThamGia}
                            keyExtractor={(item, index) => "list" + index}
                            renderItem={(listDaThamGia) => this._renderRowDaThamGia(listDaThamGia.item)}
                            onEndReachedThreshold={200}
                            ListHeaderComponent={this._renderHeaderListCuaBan(2,listDaThamGia )}
                            removeClippedSubviews={false}
                            initialListSize={25}
                            enableEmptySections={true}
                            showsHorizontalScrollIndicator={false}
                            showsVerticalScrollIndicator={false}
                            // style={{ height: height - 97, width: width}}
                            style={{ flex: 1 }}
                            contentContainerStyle={{ paddingBottom: 50 }}
                        />
                        }
                    </View>
                );
                break;
            }

            case "sanKhamPha": {
                content = (
                    <View style={{ flex: 1 }}>
                        {
                            listSanGoiY.length == 0 ?
                                (
                                    <View style={styles.viewNoAds}>
                                        <Image
                                            source={imageNoGroup}
                                            resizeMode={"cover"}
                                            style={styles.imageNoGroup}
                                        />
                                        <Text style={[styles.textNoneAds, {fontWeight: '500', marginTop: 22}]}>
                                            Tạo sàn trên Landber Agent
                                        </Text>
                                        <Text style={styles.textNoneAds}>
                                            {textNoneGroup}
                                        </Text>
                                        <TouchableOpacity style={styles.viewAddGroup}
                                                          onPress={this._onAddGroup.bind(this)}
                                        >
                                            <Text style={[styles.textNoneAds, {color: '#fff'}]}>
                                                Tạo sàn
                                            </Text>
                                        </TouchableOpacity>
                                    </View>
                                ) :
                                <FlatList
                                    ref={(ref) => this.scrollView = ref}
                                    data={listSanGoiY}
                                    keyExtractor={(item, index) => "list" + index}
                                    renderItem={(listSanGoiY) => this._renderRowGoiY(listSanGoiY.item)}
                                    ListHeaderComponent={this._renderHeaderListKhamPha(2)}
                                    removeClippedSubviews={false}
                                    initialListSize={25}
                                    enableEmptySections={true}
                                    showsHorizontalScrollIndicator={false}
                                    showsVerticalScrollIndicator={false}
                                    style={{ height: height - 97, width: width }}
                                    contentContainerStyle={{ paddingBottom: 50 }}
                                />
                        }

                    </View>
                );
                break;
            }

            default: {
                content = (
                    <View style={styles.viewSanThamGia} />
                );
            }
        }
        return content;
    }

    _onSeeAllRegion(dataKhuVuc, dataType) {
        Actions.GroupSuggestPlace({dataType: dataType , listKhuVuc: dataKhuVuc, onPressSuggestGroup: (value) => this._onPressSuggestGroup(value)});
    }

    _removeRequestedGroupInSearchResult(listGroup, listRequestedGroup) {
        let hashRelatedGroup = {};
        listRequestedGroup.forEach((one) => {
            if (one.joinStatus == 1 || one.joinStatus == 2) {
                hashRelatedGroup[one.groupID] = true;
            }
        });
        return listGroup.filter((one) => {
            return !hashRelatedGroup[one.groupID]
        });
    }

    _renderHeaderListKhamPha() {
        let dataKhuVuc = this.state.listSuggestGroup ? this.state.listSuggestGroup.filter((e) => { return e.type == 'T' }) : [];
        
        let dataDuAn = this.state.listSuggestGroup ? this.state.listSuggestGroup.filter((e) => { return e.type == 'A' }) : [];
        
        let userID = this.props.global.currentUser.userID;


        let textKhuVuc = 'SÀN THEO KHU VỰC';
        let textDuAn = 'SÀN PHÂN PHỐI CÁC DỰ ÁN HOT';
        let textGoiY = 'SÀN GỢI Ý CHO BẠN';
        return (
            <View style={{ width: width, height: 'auto' }}>
                {this.renderKhuVucContent(textKhuVuc, dataKhuVuc, 'T')}
                {this.renderKhuVucContent(textDuAn, dataDuAn, 'A')}
                {/* { this.renderSanDaYeuCau(textYeuCau,listSanDaYeuCau) } */}
                {this._renderHeaderRelated(textGoiY)}
            </View>
        )
    }

    renderKhuVucContent(titleText, dataKhuVuc, dataType) {
        if (dataKhuVuc.length == 0) {
            return;
        }
        let dataToRender = dataKhuVuc.slice(0, 15)
        return (
            <View>
                {this._renderHeaderRelated(titleText)}
                <View style={styles.viewSearchKhuVuc}>
                    <FlatList
                        data={dataToRender}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(dataToRender) => this._renderRowKhuVuc(dataToRender.item)}
                        removeClippedSubviews={false}
                        initialListSize={25}
                        horizontal={true}
                        enableEmptySections={true}
                        showsHorizontalScrollIndicator={false}
                        showsVerticalScrollIndicator={false}
                        style={styles.listKhuVuc}
                    />
                    {dataKhuVuc && dataKhuVuc.length > 0 ?
                        (<View>
                            <FullLine style={{ marginLeft: 8, marginRight: 8, marginTop: 8 }} />
                            <TouchableOpacity style={styles.viewMoreTodo}
                                onPress={this._onSeeAllRegion.bind(this, dataKhuVuc, dataType)}
                                underlayColor='transparent'
                            >
                                <Text style={styles.xemThemText}>Xem thêm</Text>
                                <Ionicons name={"ios-arrow-round-forward-outline"}
                                    color={gui.mainColor}
                                    size={20}
                                    style={{ marginLeft: 6, marginTop: 2 }} />
                            </TouchableOpacity>
                        </View>)
                        : null}
                </View>
                <FullLine style={{ marginLeft: 8, marginTop: 0 }} />
            </View>
        )
    }

    renderSanDaYeuCau(textYeuCau, listSanDaYeuCau) {
        if (listSanDaYeuCau.length == 0) {
            return;
        }
        return (
            <View>
                {this._renderHeaderRelated(textYeuCau)}
                <View style={styles.viewDaYeuCau}>
                    <FlatList
                        ref={(ref) => this.scrollView = ref}
                        data={listSanDaYeuCau}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(listSanDaYeuCau) => this.renderRowDaYeuCau(listSanDaYeuCau.item)}
                        removeClippedSubviews={false}
                        initialListSize={25}
                        horizontal={true}
                        enableEmptySections={true}
                        showsHorizontalScrollIndicator={false}
                        showsVerticalScrollIndicator={false}
                        style={styles.listGoiY}
                        contentContainerStyle={styles.viewListContainer}
                    />
                </View>
                <FullLine style={{ marginLeft: 8, marginTop: 2 }} />
            </View>
        )
    }

    _calcZoomValue(mapWidth, viewport) {
        let GLOBE_WIDTH = 256; // a constant in Google's map projection
        let west = viewport.southwest.lon;
        let east = viewport.northeast.lon;
        let angle = east - west;
        let north = viewport.southwest.lat;
        let south = viewport.northeast.lat;
        let angle2 = north - south;
        let zoomfactor;
        let delta = 0;

        if (angle2 > angle) {
            angle = angle2;
            delta = 3;
        }

        if (angle < 0) {
            angle += 360;
        }

        zoomfactor = Math.floor(Math.log(mapWidth * 360 / angle / GLOBE_WIDTH) / Math.LN2) - delta;
        return zoomfactor;
    }

    _renderRowKhuVuc(data) {
        let nameKhuVuc = data.type == 'A' ? 'DỰ ÁN ' + data.placeName.toUpperCase() : 'SÀN KHU VỰC ' + data.placeName.toUpperCase();
        let imgUrl = data.coverImage;
        if (data.type != 'A' && data.viewport) {
            let region = apiUtils.getRegionByViewport(data.viewport);
            let lat = region.latitude;
            let lon = region.longitude;
            let mapWidth = 248;
            let mapHeight = 120;
            let zoom = this._calcZoomValue(mapWidth, data.viewport);
            imgUrl = 'http://maps.google.com/maps/api/staticmap?zoom=' + zoom + '&size=' + mapWidth + 'x' + mapHeight + '&markers=color:red|' + lat + ',' + lon + '&sensor=false';
            imgUrl = imgUrl + '&key=AIzaSyDCGmWrUyarAz5iIUeOX3X8eI3S7Qvfo3g';
        }
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imgUrl) {
            imageGroup = defaultCover;
        }
        return (
            <TouchableOpacity onPress={this._onPressSuggestGroup.bind(this, data)} style={styles.viewRowKhuVuc}>
                <ImageBackground style={styles.imgItem2}
                    source={imageGroup} defaultSource={defaultCover}>
                    <LinearGradient colors={['rgba(37,37,37,0.3)', 'rgba(37,37,37,0.3)']}
                        style={styles.linearGradient}>
                        <View style={styles.imgItem2}>
                            <Text numberOfLines={3} style={styles.textKhuVuc}>{nameKhuVuc}</Text>
                        </View>
                    </LinearGradient>
                </ImageBackground>
            </TouchableOpacity>
        )
    }

    _onPressSuggestGroup(data) {
        let diaBan = [];
        diaBan.push(data)
        let fields = utils.cloneRecord(this.props.group.searchFields);

        if (data.type == 'A') {
            this.props.actions.onSearchGroupFieldChange('duAn', diaBan);
            this.props.actions.onSearchGroupFieldChange('khuVuc', []);
            fields.duAn = diaBan;
            fields.khuVuc = []
        } else if (data.type == 'H') {
            //need remove Tinh info before search
            diaBan[0].codeTinh = undefined;
            diaBan[0].tinh = undefined;
            this.props.actions.onSearchGroupFieldChange('khuVuc', diaBan);
            this.props.actions.onSearchGroupFieldChange('duAn', []);
            fields.khuVuc = diaBan;
            fields.duAn = []
        } else if (data.type == 'T') {
            this.props.actions.onSearchGroupFieldChange('khuVuc', diaBan);
            this.props.actions.onSearchGroupFieldChange('duAn', []);
            fields.khuVuc = diaBan;
            fields.duAn = []
        }

        this.props.actions.searchGroup(false, fields, (res) => {
            if (data.type == 'T') {
                let payload = { userID: this.props.global.currentUser.userID, codeTinh: data.codeTinh }
                this.props.actions.suggestGroupCollectionInRegion(payload, () => {
                    Actions.GroupSuggestCapTinh({ tinh: data })
                });
            } else
                Actions.GroupSuggestCapHuyen({ owner: 'GroupMgmt', duAn: data })
        });


    }

    _renderHeaderListCuaBan(joinStatus, listDaThamGia) {
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let userID = this.props.global.currentUser.userID;
        let listSanCuaBan = listRelatedGroup.filter((one) => {
            return one.createdBy == userID && one.joinStatus == joinStatus
        }) || [];
        let listSanDaYeuCau = listRelatedGroup.filter((one) => {
            return one.createdBy != userID && one.joinStatus == 1
        }) || [];
        return this.renderSanCuaBanSanDaYeuCau(listSanCuaBan, listSanDaYeuCau, listDaThamGia);
    }

    renderSanCuaBanSanDaYeuCau(listSanCuaBan, listSanDaYeuCau, listDaThamGia) {
        let text = "SÀN CỦA BẠN";
        let textRequest = 'SÀN BẠN YÊU CẦU THAM GIA'
        let textDaThamGia = "SÀN BẠN ĐÃ THAM GIA";
        let textNoneGroup = 'Quản lý thành viên và các thông tin chia sẻ trên sàn. Tra cứu nguồn hàng trên sàn dễ dàng';
        if (listSanCuaBan.length > 0 && listSanDaYeuCau.length == 0)
            return (
                <View style={styles.viewRelatedList}>

                    {this._renderHeaderRelated(text)}
                    <FlatList
                        ref={(ref) => this.scrollView = ref}
                        data={listSanCuaBan}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderRowSanCuaBan(data.item)}
                        ListHeaderComponent={this.renderAddGroup()}
                        removeClippedSubviews={false}
                        initialListSize={25}
                        horizontal={true}
                        enableEmptySections={true}
                        showsHorizontalScrollIndicator={false}
                        showsVerticalScrollIndicator={false}
                        style={styles.listContent}
                        contentContainerStyle={styles.viewListContainer}
                    />

                    {listDaThamGia && listDaThamGia.length > 0 ? this._renderHeaderRelated2(textDaThamGia) : null}
                </View>
            )
        else if (listSanDaYeuCau.length > 0 && listSanCuaBan.length == 0)
            return (
                <View style={[styles.viewRelatedList, { height: 'auto' }]}>
                    <View style={styles.viewNoGroup}>
                        <Text style={[styles.textNoneAds, {fontWeight: '500'}]}>
                            Tạo sàn trên Landber Agent
                        </Text>
                        <Text style={styles.textNoneAds}>
                            {textNoneGroup}
                        </Text>
                        <TouchableOpacity style={styles.viewAddGroup}
                                          onPress={this._onAddGroup.bind(this)}
                        >
                            <Text style={[styles.textNoneAds, {color: '#fff'}]}>
                                Tạo sàn
                            </Text>
                        </TouchableOpacity>
                    </View>
                    {this._renderHeaderRelated(textRequest)}
                    <FlatList
                        ref={(ref) => this.scrollView = ref}
                        data={listSanDaYeuCau}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(listSanDaYeuCau) => this.renderRowDaYeuCau(listSanDaYeuCau.item)}
                        removeClippedSubviews={false}
                        initialListSize={25}
                        horizontal={true}
                        enableEmptySections={true}
                        showsHorizontalScrollIndicator={false}
                        showsVerticalScrollIndicator={false}
                        style={[styles.listContent, { height: 172 }]} //listGoiY
                        contentContainerStyle={styles.viewListContainer}
                    />

                    {listDaThamGia && listDaThamGia.length > 0 ? this._renderHeaderRelated2(textDaThamGia) : null}
                </View>
            )
        else if (listSanDaYeuCau.length > 0 && listSanCuaBan.length > 0)
            return (
                <View style={[styles.viewRelatedList, { height: 'auto' }]}>

                    {this._renderHeaderRelated(text)}
                    <FlatList
                        ref={(ref) => this.scrollView = ref}
                        data={listSanCuaBan}
                        keyExtractor={(item, index) => "list" + index}
                        ListHeaderComponent={this.renderAddGroup()}
                        renderItem={(data) => this._renderRowSanCuaBan(data.item)}
                        removeClippedSubviews={false}
                        initialListSize={25}
                        horizontal={true}
                        enableEmptySections={true}
                        showsHorizontalScrollIndicator={false}
                        showsVerticalScrollIndicator={false}
                        style={styles.listContent}
                        contentContainerStyle={styles.viewListContainer}
                    />


                    {this._renderHeaderRelated2(textRequest)}
                    <FlatList
                        ref={(ref) => this.scrollView = ref}
                        data={listSanDaYeuCau}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(listSanDaYeuCau) => this.renderRowDaYeuCau(listSanDaYeuCau.item)}
                        removeClippedSubviews={false}
                        initialListSize={25}
                        horizontal={true}
                        enableEmptySections={true}
                        showsHorizontalScrollIndicator={false}
                        showsVerticalScrollIndicator={false}
                        style={[styles.listContent, { height: 172 }]}
                        contentContainerStyle={styles.viewListContainer}
                    />

                    {listDaThamGia && listDaThamGia.length > 0 ? this._renderHeaderRelated2(textDaThamGia) : null}
                </View>
            )
        else return (
            <View style={{ height: 'auto', width: width }}>
                {listDaThamGia && listDaThamGia.length > 0 ?
                    (<View>
                        <View style={styles.viewNoGroup}>
                            <Text style={[styles.textNoneAds, {fontWeight: '500'}]}>
                                Tạo sàn trên Landber Agent
                            </Text>
                            <Text style={styles.textNoneAds}>
                                {textNoneGroup}
                            </Text>
                            <TouchableOpacity style={styles.viewAddGroup}
                                              onPress={this._onAddGroup.bind(this)}
                            >
                                <Text style={[styles.textNoneAds, {color: '#fff'}]}>
                                    Tạo sàn
                                </Text>
                            </TouchableOpacity>
                        </View>
                        {this._renderHeaderRelated(textDaThamGia)}
                    </View>)
                    : null}
            </View>
        );
    }

    renderAddGroup() {
        let addGroupText = 'Tạo sàn'
        return(
             <TouchableOpacity onPress={this._onAddGroup.bind(this)}
                               style={styles.viewRelatedWall}>
                <View style={styles.viewAddGroupIcon}>
                    <FontAwesomeLight name={'plus'}
                                      size={46}
                                      color={gui.mainColor}
                                      noAction={true}
                                      iconOnly={true}
                                      mainProps={{marginBottom: 0}}
                    />
                </View>
                <View style={styles.viewChildRelated}>
                    <Text style={[styles.textNameWall, {color: gui.mainColor, fontWeight: 'normal' }]}>
                        {addGroupText}
                    </Text>
                </View>
            </TouchableOpacity>
        )
    }

    _renderRowGoiY(data) {
        // data cua san goi y
        return (
            <View>
                <RowSuggest data={data}
                    status={1}
                    onPressRow={this._onOpenGroupWallPress.bind(this, data)}
                    onRequestJoin={this.onOpenRequestJoinModal.bind(this, data)}
                    {...this.props} />
                <FullLine style={{ marginLeft: 48 }} />
            </View>
        )
    }

    _renderRowDaThamGia(data) {
        // data cua san da tham gia
        return (
            <View>
                <RowSuggest
                    data={data}
                    onPressRow={this._onOpenGroupWallPress.bind(this, data)}
                    {...this.props} />
                <FullLine style={{ marginLeft: 48 }} />
            </View>
        )
    }

    onOpenRequestJoinModal(data) {
        this.setState({
            isOpenModalJoin: true,
            rowRequest: data
        })
    }

    _renderHeaderRelated(text) {
        return (
            <View style={[styles.viewHeaderRelated, {marginTop: 12}]}>
                <Text style={styles.textHeader}>
                    {text}
                </Text>
            </View>
        );
    }

    _renderHeaderRelated2(text) {
        return (
            <View style={{ width: width, marginLeft: 0, marginTop: 8 }}>
                <FullLine style={{}} />
                <View style={[styles.viewHeaderRelated, {marginTop: 12}]}>
                    <Text style={styles.textHeader}>
                        {text}
                    </Text>
                </View>
            </View>
        );
    }


    // San ban yeu cau tham gia
    renderRowDaYeuCau(data) {
        let imgUrl = data.thumbnail || data.image;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageGroup) {
            imageGroup = defaultCover;
        }
        let adminAvatarUrl = data.avatar;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let adminSource = adminAvatarUrl ? { uri: adminAvatarUrl } : defaultAvatar;
        let groupName = data.name;
        let nameAdmin = data.fullNameChuSan;
        let totalMember = data.countMember || 0;
        let groupStatus = danhMuc.groupStatus[data.status];
        let setColor = 'rgba(149,149,149,1)';
        let widthButton = 91;
        return (
            <TouchableOpacity onPress={this._onOpenGroupWallPress.bind(this, data)}
                style={[styles.viewRelatedWall, { height: 178 + 3, width: 91 }]}
            >
                <Image
                    resizeMode={"cover"}
                    source={imageGroup}
                    defaultSource={defaultCover}
                    style={styles.adsCoverRelated} />
                <View style={styles.viewChildRelated}>
                    <Text style={[styles.textNameWall, { fontSize: 15 }]}
                        numberOfLines={2}
                    >
                        {groupName}
                    </Text>
                </View>
                <TouchableOpacity style={[styles.touchJoinGroup, { borderColor: setColor, width: widthButton }]}
                    onPress={this._onCancelJoinPress.bind(this, data)}
                >
                    <Text style={[styles.textThamGiaStatus, { color: setColor }]}>HỦY THAM GIA</Text>
                </TouchableOpacity>
            </TouchableOpacity>
        )
    }



    _renderRowSanCuaBan(data) {
        let imgUrl = data.thumbnail || data.image;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageGroup) {
            imageGroup = defaultCover;
        }
        let adminAvatarUrl = data.avatar;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let groupName = data.name;

        return (
            <TouchableOpacity onPress={this._onOpenGroupWallPress.bind(this, data)}
                style={styles.viewRelatedWall}
            >
                <Image
                    resizeMode={"cover"}
                    source={imageGroup}
                    defaultSource={defaultCover}
                    style={styles.adsCoverRelated} />
                <View style={styles.viewChildRelated}>
                    <Text style={styles.textNameWall}
                        numberOfLines={2}
                    >
                        {groupName}
                    </Text>
                </View>
            </TouchableOpacity>
        )
    }

    _onMoreButtonPress(data) {
        this.setState({ selectedGroup: data, isOpenMoreModal: true });
    }

    _onOpenGroupWallPress(data) {
        log.info('_onOpenGroupWallPress ******', data)
        if (this.state.loaiSan == "sanKhamPha" || data.joinStatus == 1 || data.joinStatus == 3) {
            this.props.actions.getGroupDetail({ 'groupID': data.groupID }, (res) => {
                Actions.GroupDetail2({ groupData: res.data, groupID: data.groupID, owner: 'GroupMgmt' });
            })
        } else {
            this.props.actions.onGroupFieldChange("pageNo", 1);
            this.props.actions.getNextWall(
                {
                    'groupID': [data.groupID],
                    'limit': this.props.group.limit,
                    'pageNo': 1,
                    'textSearch': this.props.group.textSearch ? this.props.group.textSearch.trim() : ''
                }
                , (res) => {
                    StatusBar.setBarStyle('default');
                    Actions.GroupWall2({ groupData: data, groupID: data.groupID });                    
                }
                , (error) => {
                    // this._updateMessageProcessing(error, '#fa4916', 'white');
                    Alert.alert("Thông báo", error, [{ text: 'Đóng', onPress: () => { } }]);
                })
        }
    }

    canAccessGroupWall(groupID) {

    }

    onRequestJoin() {
        let rowData = this.state.rowRequest;
        //log.info('GroupMgmt2 onrequestjoin data', rowData)

        if (!rowData)
            return;

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let requestJoinDto = {
            "requester": currentUser.userID || undefined,
            "requesterName": currentUser.fullName || currentUser.phone || currentUser.email || undefined,
            "approver": rowData.userID || rowData.createdBy || undefined,
            "member": currentUser.userID || undefined,
            "memberName": currentUser.fullName || undefined,
            "memberNameKhongDau": utils.locDauV2(utils.standardlizeName(currentUser.fullName)),
            "memberAvatar": currentUser.avatar || undefined,
            "groupID": rowData.groupID || undefined,
            "groupName": rowData.name || undefined,
            "groupImage": rowData.thumbnail || undefined,
            "message": this.state.textToChuSan
        };

        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let fetchRelatedGroupSuccess = this.props.actions.fetchRelatedGroupSuccess;

        this.props.actions.requestToJoin(requestJoinDto, token)
            .then(res => {
                this.setState({
                    loading: false,
                    isOpenModalJoin: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    rowData.joinStatus = 1;
                    let found = listRelatedGroup.find((one) => {
                        return one.groupID == rowData.groupID
                    });
                    if (found) {
                        listRelatedGroup = listRelatedGroup.filter((one) => {
                            return one.groupID != rowData.groupID
                        });
                    }
                    listRelatedGroup = [...listRelatedGroup, rowData];
                    fetchRelatedGroupSuccess(listRelatedGroup);

                    this.props.actions.onGroupFieldChange("textToChuSan", "");
                    this.setState({ textToChuSan: '' })

                    setTimeout(
                        () =>
                            this.refs.toastTop && this.refs.toastTop.show("Xác nhận yêu cầu tham gia sàn được gửi thành công và đang chờ duyệt.", DURATION.LENGTH_LONG), 500)
                        ;
                }
            });
    }

    _renderLoadingView() {
        if (this.props.group.loadingWall) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderContent: {
        height: 72,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 19,
        paddingRight: 21
    },
    viewIconSearch: {
        height: 72,
        width: 18,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPlusSearch: {
        height: 72,
        width: 20,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewInputSearch: {
        height: 72,
        width: width - 78,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    lineFullWidth: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width,
        opacity: 0.8
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewBody: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewTabSelect: {
        height: 32,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewTabChild: {
        height: 30,
        width: width / 2,
        backgroundColor: 'white',
    },
    viewTab: {
        height: 34,
        width: width,
        marginTop: 1
    },
    viewSanThamGia: {
        backgroundColor: '#fff',
        flex: 1,
        // height: height - 137,
        // width: width,
        marginTop: 3
    },
    viewKhuVuc: {
        flex: 1,
        // height: height - 137,
        // width: width,
        backgroundColor: '#fff',
    },
    viewContent: {
        marginTop: 15,
        width: width - 30,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 18
    },
    adsCoverRelated: {
        height: 90,
        width: 90,
        borderRadius: 45,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewAddGroupIcon: {
        height: 90,
        width: 90,
        borderRadius: 45,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: gui.mainColor,
        borderWidth: 1,
        borderStyle: 'dashed',
        backgroundColor: 'rgba(217,235,235,1)'

    },
    viewChildRelated: {
        height: 30,
        width: 90,
        marginTop: 6
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        // height: 80,
        width: width - 208,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 100,
        // height: 82,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 16,
        paddingBottom: 22
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 198,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    viewTextAdmin: {
        width: width - 198 - 90,
        height: 24,
        justifyContent: 'center'
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    textNameWall: {
        color: 'rgba(70,70,70,1)',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        alignSelf: 'center',
        textAlign: 'center'
    },
    textNoneAds: {
        color: gui.textPostAds,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        alignSelf: 'center',
        textAlign: 'center'
    },
    viewAddGroup: {
        width: 158,
        height: 40,
        backgroundColor: gui.mainColor,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 24
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    listContent: {
        height: 136,
        width: width,
        marginTop: 20
    },
    viewRelatedList: {
        height: 196 + 28,
        width: width,
        backgroundColor: '#fff',
        alignItems: 'flex-start'
    },
    viewListContainer: {
        paddingBottom: 0
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    textTotalMember: {
        height: 24,
        width: 30,
        justifyContent: 'center'
    },
    textTotalIcon: {
        height: 24,
        width: 20,
        marginBottom: 1,
        justifyContent: 'center'
    },
    lineVertical: {
        height: 26,
        width: 1,
        backgroundColor: 'rgba(211,211,211,0.7)',
    },
    viewRelatedWall: {
        height: 136,
        width: 90,
        marginLeft: 8,
        marginRight: 8
    },
    viewHeaderRelated: {
        height: 20,
        justifyContent: 'flex-end',
        paddingLeft: 8
    },
    textHeader: {
        color: gui.mainTextColor,
        fontSize: 13,
        fontFamily: gui.fontFamily
    },
    listGoiY: {
        backgroundColor: '#fff',
        flex: 1
        // height: height - 137 - 196,
        // width: width,
    },
    viewSearchKhuVuc: {
        height: 90 + 45,
        width: width,
        justifyContent: 'flex-end'
    },
    viewRowKhuVuc: {
        marginLeft: 8,
        width: 124,
        height: 80
    },
    textKhuVuc: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 12,
        fontFamily: gui.fontFamily,
        alignSelf: 'center',
        marginLeft: 10,
        marginRight: 10
    },
    linearGradient: {
        borderRadius: 6,
        flexGrow: 1
    },
    imgItem2: {
        width: 124,
        height: 80,
        borderRadius: 6,
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        backgroundColor: 'transparent'
    },
    listKhuVuc: {
        width: width,
        height: 60,
        marginTop: 10
    },
    viewDaYeuCau: {
        height: 198,
        width: width,
        paddingTop: 20
    },
    touchJoinGroup: {
        borderRadius: 3,
        borderColor: gui.mainTextColor,
        borderWidth: 1,
        height: 22,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 12
    },
    textThamGiaStatus: {
        fontSize: 10,
        fontFamily: gui.fontFamily,
        fontWeight: 'bold',
        textAlign: 'center',
        color: gui.mainTextColor
    },
    viewModalStyle2: {
        justifyContent: 'center',
        height: 210,
        width: width - 30,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexGrow: 1,
        borderRadius: 8
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        width: width - 80
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 48,
        bottom: 17,
        width: width,
        backgroundColor: 'transparent',
    },
    searchButton: {
        height: 48,
        width: width - 64,
        backgroundColor: gui.mainColor,
        borderRadius: 24,
        alignItems: 'center',
        justifyContent: 'center'
    },
    searchButtonText: {
        color: '#FFFFFFFF',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    viewMoreTodo: {
        height: 36,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    xemThemText: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainAgentColor
    },
    viewNoGroup: {
        height: 160,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        borderBottomWidth: 1,
        borderColor: 'rgba(211,211,211,0.5)'
    },
    viewNoAds: {
        flex: 1,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
    },
    imageNoGroup: {
        width: 123,
        height: 133
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupMgmt2);