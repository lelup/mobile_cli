import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';

export default class TabGroupMgmt extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';

        return (
            <View style={styles.wrapper}>
                <TouchableOpacity
                    onPress={() => this.props.onPress(this.props.name)}>
                    <ScalableText style={styles[myStyle]} >
                        {this.props.children}
                    </ScalableText>
                </TouchableOpacity>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    wrapper: {
        flexGrow: 1,
        flexDirection: 'column',
        justifyContent: 'center'

    },
    buttonText: {
        flexGrow: 1,
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        paddingVertical: 7,
        paddingHorizontal: 10,
        color: gui.mainTextColor,
        fontWeight : 'normal'
    },
    buttonTextSelected: {
        flexGrow: 1,
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        paddingVertical: 7,
        paddingHorizontal: 10,
        color: gui.mainAgentColor,
        fontWeight : '500'
    }
});