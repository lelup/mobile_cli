
const circleChatButton = {
    name:"circleChat",
    size: {width: 56, height: 56},
    animationTypes: ['IDLE'],
    frames: [
        require('../../assets/image/me/6.png')
    ],
    animationIndex: function getAnimationIndex (animationType) {
        switch (animationType) {
            case 'IDLE':
                return [0];
        }
    },
};

export default circleChatButton;
