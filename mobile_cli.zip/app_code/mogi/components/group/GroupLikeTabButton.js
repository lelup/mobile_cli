import React, {Component} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';

export default class GroupLikeTabButton extends React.Component {
  render() {
    let selected = this.props.selected;
    let myStyle = selected? 'buttonTextSelected' : 'buttonText';

    return (
      <View style={styles.wrapper}>
        <TouchableOpacity
          style = {{marginRight: 23}}
          onPress={() => this.props.onPress(this.props.name)}>
          <ScalableText style={styles[myStyle]} >
            {this.props.children}
          </ScalableText>
        </TouchableOpacity>
        <View style = {[styles.lineunder, {borderBottomWidth:selected ? 2:0 }]}  />
      </View>
    );
  }
}


let styles = StyleSheet.create({
  lineunder: {
    flexGrow: 1,
    borderBottomColor: gui.mainColor,
    borderStyle: "solid",
    height: 3,
    marginRight: 22
  },

  wrapper: {
    flexGrow: 1,
    flexDirection: 'column',
    justifyContent: 'center'

  },

  buttonText: {
    flexGrow: 1,
    alignSelf:'center',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    paddingBottom: 11,
    paddingTop: 2,
    color: '#898989',
    fontWeight : 'normal'
  },

  buttonTextSelected: {
    flexGrow: 1,
    alignSelf:'center',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    paddingBottom: 11,
    paddingTop: 2,
    color: gui.mainColor,
    fontWeight : '500'
  }
});