import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    FlatList,
    TouchableOpacity,
    TouchableHighlight,
    ListView,
    ScrollView
} from 'react-native';

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import FullLine from '../line/FullLine';
import LineFacebook from '../line/LineFacebook';
import RelandIcon from '../RelandIcon';
import gui from '../../lib/gui';
import log from '../../lib/logUtil';
import utils from '../../lib/utils';
import GiftedSpinner from "../GiftedSpinner";
let { width, height } = utils.getDimensions();
import RangeUtils from '../../lib/RangeUtils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Actions } from 'react-native-router-flux';
import DanhMuc from "../../assets/DanhMuc"
import Modal from 'react-native-modalbox';
import FunctionModal from '../FunctionModal'

import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import moment from 'moment'

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions,
    adsMgmtActions,
    postAdsActions
];

const ds_listSourceAds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class ContactWishList extends Component {
    constructor(props) {
        super(props);
        let data = []

        this.state = {
            data: data,
            listAdsMatchingWto: props.group.listAdsMatchingWto,
            selectedWto: null,
            isOpenMoreModal: false
        }
    }

    componentWillMount() {
        // setTimeout(() => this.fetchData(), 300);        
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.group.listAdsMatchingWto !== this.props.group.listAdsMatchingWto) {
            this.setState({ listAdsMatchingWto: nextProps.group.listAdsMatchingWto });
        }
        // if (nextProps.forceUpdate !== this.props.forceUpdate) {
        //     console.log('bachtv forceupdtea *************', nextProps.forceUpdate)
        //     this.forceUpdate();
        // }
        
    }

    fetchData(props) {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
    }

    render() {
        let data = this.props.group.contactWtoList;
        let adsWishEmpty = 'Nơi viết lại nhu cầu của khách từ đó sẽ gợi ý nhà phù hợp mà bạn đã đăng với khách';
        let sourceEmpty = require('../../assets/image/icon_nhu_cau.png');
        return (
            <View style={styles.container}>
                <TouchableOpacity onPress={this._onMoreButtonPress.bind(this)} style={styles.touchAdd}>
                    <MaterialCommunityIcons name={'plus'} size={16} color={gui.mainAgentColor} />
                    <Text style={styles.textThemNha}>Thêm nhu cầu</Text>
                </TouchableOpacity >

                <FullLine style={{ marginLeft: 6, marginRight: 6, marginBottom: 0 }} />

                {data && data.length > 0
                    ? <FlatList
                        data={data}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderWtoPost(data.item)}
                        removeClippedSubviews={false}
                        enableEmptySections
                        showsVerticalScrollIndicator={false}
                        style={styles.viewListContainer}
                    />
                    : <View style={[styles.contentHistory]}>
                        <Image style={styles.imageEmptyHistory}
                            source={sourceEmpty}
                            defaultSource={sourceEmpty}
                            resizeMode={'cover'}
                        />
                        <Text style={[styles.textPhone, { marginTop: 44 }]}>{adsWishEmpty}</Text>
                    </View>}
                {this._renderLoadingView()}
                {this._openMoreModal()}
            </View>
        )
    }

    _onMoreButtonPress(data) {
        this.setState({ isOpenMoreModal: true });
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"top"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {

        let items = [
            { _text: 'Nhập mới', _function: () => this._themNhuCau() },
            { _text: 'Chọn từ danh sách tin cần mua', _function: () => this._pickFromWtoList() },
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outMoreModal.bind(this)} />
        )
    }

    _pickFromWtoList() {
        this._outMoreModal();
        this.props.actions.onPostAdsFieldChange('inboxType', 'wto');
        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        Actions.NewAgentPostViewOnly({ owner: 'ContactWishList', contactID: this.props.groupContact.selectedContact.contactID, onWtoPicked:  (value) => this._onWtoPicked(value) });
    }

    _onWtoPicked(value) {
        this.setState({ selectedWto: value })
    }

    _renderWtoPost(data) {
        // log.info('===========> groupwal2 _renderRowWto',status);

        let content = data.content;
        let priceRange = 'Giá:'

        let giaTuFmt = utils.getPriceDisplay(content.giaTu, content.loaiTin);
        if (giaTuFmt != DanhMuc.THOA_THUAN) {
            title += `${giaTuFmt}`;
        }

        let giaDenFmt = utils.getPriceDisplay(content.giaDen, content.loaiTin);
        if (giaDenFmt != DanhMuc.THOA_THUAN) {
            title += ` - ${giaDenFmt}`;
        }

        let diaChi = '';
        let title = utils.getTitleWtoDetail(data.content)

        return (
            <View style={styles.viewAdsWto}>
                <View style={styles.viewRowPostWto}>
                    {this._renderDetailWtoPost(data)}
                </View>
                <LineFacebook/>
            </View>
        )
    }

    _renderDetailWtoPost(data) {
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))

        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;
        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;

        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;

        //
        // let matchingAds = this.state.matchingAdsList.filter((e) => { return e.id == data.id });
        // let adsListToRender = matchingAds[0] ? matchingAds[0].adsList : [];

        let listAdsMatching = this.props.group.listAdsMatchingWto.filter((e) => { return e.wtoID == data.id });
        // console.log('hello _renderDetailWtoPost &&&&&&&&&&&&&&&&&&&&&&&&', listAdsMatching)
        
        let yourOwn = listAdsMatching[0] && listAdsMatching[0].data.filter((e) => { return e.userID == this.props.global.currentUser.userID })
        let others = listAdsMatching[0] && listAdsMatching[0].data.filter((e) => { return e.userID != this.props.global.currentUser.userID })
        
        let titleDemand = 'Nhà phù hợp với nhu cầu';
        let title2 = 'Chưa tìm thấy nhà phù hợp';
        let date = (data.dateStartTime && data.dateEndTime) ? (moment(data.dateStartTime).format("DD/MM/YY") + '-' + moment(data.dateEndTime).format("DD/MM/YY")) : moment(data.timeModified).format("DD/MM/YY");
        let textShare = 'Nhà phù hợp';

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        let diaChiFullName = data.content.place.fullName || ' ';

        return (
            <View style={[styles.viewDetailPost3, { height: 'auto' }]}>
                <TouchableOpacity onPress={this._onEditNhuCau.bind(this, data)} style={styles.touchableView}>
                    <View style={styles.viewTieuDe}>
                        <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                            <Text style={styles.textTypePost}>{priority}</Text>
                        </View>
                        <View style={styles.viewTextTieuDe}>
                            <Text style={styles.textTieuDe} numberOfLines={1}>{diaChiFullname}</Text>
                        </View>
                    </View>
                    <View style={styles.viewPercentDraft}>
                        <Text style={[styles.textGiaNha, {fontSize: 15}]} numberOfLines={1}>{giaNha}</Text>
                    </View>
                    <View style={[styles.viewLabel, { alignItems: 'flex-start', marginTop: 6 }]}>
                        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
                        <View style={{ width: width - 48 - 8 }}>
                            <Text numberOfLines={1} style={[styles.textDatePost, { color: gui.textPostAds }]}>{diaChiFullName}</Text>
                        </View>
                    </View>
                    <View style={[styles.viewPercentDraft, { flexDirection: 'row' }]}>
                        {detailItems}
                    </View>
                    <View style={[styles.viewPercentDraft, {marginBottom: 3}]}>
                        <Text style={[styles.textGiaNha, { color: '#898989', fontWeight: 'normal' }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.viewLineParent}>
                    <FullLine />
                </View>
                <View style={styles.viewTimeShare}>
                    <View style={styles.viewTimeLeft}>
                        <MaterialCommunityIcons name={"clock"} color={gui.textShare} size={17} />
                        <Text style={styles.textDatePost}>{date}</Text>
                    </View>
                    {yourOwn && yourOwn.length > 0 ?
                        <TouchableHighlight
                            underlayColor="rgba(220,220,220,1)"
                            onPress={this.onMyAds.bind(this, data, yourOwn[0])}>
                            <View style={styles.viewTimeRight}>
                                <Text style={[styles.textDatePost, { color:gui.mainColor, marginLeft: 0, marginRight: 0 }]}>{textShare}</Text>
                                <MaterialCommunityIcons
                                    name={"arrow-right"}
                                    color={gui.mainColor}
                                    size={19}
                                />
                            </View>
                        </TouchableHighlight>
                        : null}
                </View>
                { others && others.length != 0 ? <View style={styles.viewLineParent}>
                    <FullLine />
                </View> : null }
                {others && others.length != 0 ? (<View style={styles.viewMoiGioiPhuHop}>
                    <View style={styles.viewHeaderWto}>
                        <Text style={[styles.textHeaderWto, {fontSize: 13}]}>MÔI GIỚI PHÙ HỢP</Text>
                    </View>
                    <ListView contentContainerStyle={{alignItems: 'center', paddingRight: 20, marginBottom: 8, marginTop: 2}}
                              style={styles.listSource}
                              horizontal={true}
                              enableEmptySections={true}
                              legacyImplementation={true}
                              showsHorizontalScrollIndicator={false}
                              showsVerticalScrollIndicator={false}
                              dataSource={ds_listSourceAds.cloneWithRows(others)}
                              renderRow={this._renderRowMoiGioiCoTinPhuHop.bind(this, data)} />

                </View>) : null}
            </View>
        );
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="location-arrow" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser2, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostAds} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser2, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="bath" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6}]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }



    _themNhuCau() {
        this._outMoreModal();
        this.resetContactWto();
        Actions.ContactNhuCau();
    }    

    resetContactWto() {
        let defaultMua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };

        let nhuCauDto = {
            loaiTin: 'mua',
            mua: defaultMua,
            thue: defaultThue,
            soTangSelectedIdx: 0,
            soPhongNguSelectedIdx: 0,
            soNhaTamSelectedIdx: 0,
            dienTich: RangeUtils.BAT_KY_RANGE,
            huongNha: 0,
            place: {},
            ghiChu: '',
            id: null,
            contactID: this.props.groupContact.selectedContact.contactID,
            priority: 'hot',
            dateStart: null,
            dateEnd: null,
            ketNoiCungCau: false
        };
        this.props.actions.onNhuCauAllFieldChange(nhuCauDto)
    }

    _renderLoadingView() {
        // loadingMatchingAds
        if (this.props.group.loadingContactWto || this.props.group.loadingAdsMatchingWto) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    _renderRowMoiGioiCoTinPhuHop(rowData, data) {

        let image = data && data.avatar ? data.avatar : '';
        let uriImage = { uri: image };
        let defaultSource = require('../../assets/image/no_cover.jpg');
        let name = data && data.name ? data.name : '';
        let phone = data && data.phone ? data.phone : '';
        return (
            <TouchableOpacity style={styles.viewRowMoiGioi}
                onPress={this._onPressRowMoiGioiCoTinPhuHop.bind(this, rowData, data)}>

                <Image style={styles.imageWtoStyle}
                     source={uriImage}
                    defaultSource={defaultSource}
                    resizeMode={'cover'}
                 />
                <Text style={[styles.textNameWto, {marginTop: 16}]}>{name}</Text>
                <Text style={[styles.textHeaderWto, {fontWeight: 'normal', marginTop: 3}]}>{phone}</Text>
            </TouchableOpacity>
        )
    }

    onMyAds(data, listAds) {
        // log.info('onMyAds *****', listAds)        
        Actions.AdsMatchingWtoDetail({ data: data, moiGioiMatching: listAds });
    }

    _onPressRowMoiGioiCoTinPhuHop(data, listAds) {
        Actions.AdsMatchingWtoDetail({ data: data, moiGioiMatching: listAds });
    }

    _onEditNhuCau(rowNhuCau) {
        this._onUpdateContactWto(rowNhuCau);
        Actions.ContactNhuCau({ owner: 'ModifyContact' });
    }

    _onUpdateContactWto(data) {        
        let needToBuy = data;
        let content = needToBuy.content;
        let mua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let thue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let loaiTin = needToBuy.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = content.loaiNhaDat;
        let giaTu = content.giaTu;
        let giaDen = content.giaDen;
        let gia = giaTu && giaDen ? RangeUtils.sellPriceRange.rangeVal2Display([giaTu, giaDen]) : RangeUtils.BAT_KY_RANGE;
        if (loaiTin == 'mua') {
            mua = { loaiNhaDat: loaiNhaDat ? loaiNhaDat : '', gia: gia }
        } else {
            thue = { loaiNhaDat: loaiNhaDat ? loaiNhaDat : '', gia: gia }
        }
        let dienTichTu = content.dienTichTu;
        let dienTichDen = content.dienTichDen;
        let dienTich = dienTichTu && dienTichDen ? RangeUtils.dienTichRange.rangeVal2Display([dienTichTu, dienTichDen]) :
            RangeUtils.BAT_KY_RANGE;

        let dateStart = data.dateStart ? moment(new Date(Number(data.dateStart.slice(0, 4)), Number(data.dateStart.slice(4, 6)) - 1, Number(data.dateStart.slice(6, 8)))) : undefined;
        let dateEnd = data.dateEnd ? moment(new Date(Number(data.dateEnd.slice(0, 4)), Number(data.dateEnd.slice(4, 6)) - 1, Number(data.dateEnd.slice(6, 8)))) : undefined;

        let nhuCauDto = {
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            soTangSelectedIdx: DanhMuc.getIdx(DanhMuc.SoTang, content.soTang),
            soPhongNguSelectedIdx: DanhMuc.getIdx(DanhMuc.SoPhongNgu, content.soPhongNgu),
            soNhaTamSelectedIdx: DanhMuc.getIdx(DanhMuc.SoPhongTam, content.soPhongTam),
            dienTich: dienTich,
            huongNha: content.huongNha,
            place: content.place || {},
            ghiChu: content.ghiChu,
            id: needToBuy.id,
            contactID: needToBuy.contactID,
            priority: data.priority,
            dateStart: dateStart,
            dateEnd: dateEnd,
            ketNoiCungCau: needToBuy.ketNoiCungCau
        };
        this.props.actions.onNhuCauAllFieldChange(nhuCauDto)
    }

    _renderSquareIcon(value) {
        if (!!value) {
            return (
                <View style={styles.viewSquare}>
                    <RelandIcon name='acreage-b' color='rgba(169,183,200,1)' size={11}
                        mainProps={{ paddingLeft: 0, paddingRight: 0, marginTop: 14 }}
                        noAction={true}
                    />
                    <Text style={styles.textIcon}>{value}</Text>
                </View>
            )
        }
    }

    _renderItemIcon = (name, value, size) => {
        if (!!value) {
            return (
                <View style={[styles.viewItemIcon]}>
                    <FontAwesome name={name} color='rgba(169,183,200,1)' size={size} />
                    <Text style={styles.textIcon}>{value}</Text>
                </View>
            )
        }
    }
    // _renderRowMatchingAds(data) {
    //     // console.log('=============> _renderRowMatchingAds', data);
    //     let image = data.image ? data.image.cover : '';
    //     let uriImage = { uri: image };
    //     let defaultSource = require('../../assets/image/no_cover.jpg');
    //     let giaFmt = data.giaFmt;
    //     let textDienTich = data.dienTich ? data.dienTich + ' m2' : '';
    //     let textPhongNgu = data.soPhongNgu ? data.soPhongNgu + 'p.ngủ' : '';
    //     let content = data.place.diaChi;
    //     return (
    //         <TouchableOpacity style={styles.viewRowDemand}
    //             onPress={this._onPressRowMoiGioiCoTinPhuHop.bind(this, data)}
    //         >
    //             <Image style={styles.imageStyle}
    //                 source={uriImage}
    //                 defaultSource={defaultSource}
    //                 resizeMode={'cover'}
    //             />
    //             <Text style={styles.textGiaDemand}>{giaFmt}</Text>
    //             <View style={styles.viewContentChild}>
    //                 <Text style={styles.textDienTich}>{textDienTich}</Text>
    //                 <Text style={[styles.textDienTich, { marginLeft: 20 }]}>{textPhongNgu}</Text>
    //             </View>
    //             <View style={styles.viewContent}>
    //                 <Text style={styles.textContent} numberOfLines={1}>{content}</Text>
    //             </View>
    //         </TouchableOpacity>
    //     )
    // }

    // _onPressRowMoiGioiCoTinPhuHop(ads) {
    //     if (ads.adsID && ads.adsID.length > 0 && ads.adsID != "EMPTY")
    //         Actions.GroupAdsDetail({ adsID: ads.adsID, imageDetail: ads.image.cover });
    // }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        minHeight: height/2 + 40,
    },
    viewRowCover: {
        height: 'auto', //380
        width: width - 12,
        marginLeft: 6,
        marginRight: 6,
        paddingLeft: 10,
        marginBottom: 6,
        backgroundColor: '#fff'
    },
    viewTitle: {
        width: width - 22,
        //paddingLeft: 16,
        height: 61,
        //paddingTop: 6,
        justifyContent: 'center'
    },
    textCommon: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor
    },
    viewDetailDemand: {
        height: 83,
        width: width - 22,
        //marginLeft: 16,
        justifyContent: 'center'
    },
    viewIcons: {
        height: 14,
        width: width - 22,
        flexDirection: 'row',
        alignItems: 'flex-end',
        marginTop: 10
    },
    viewItemIcon: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 12,
        height: 14
    },
    textIcon: {
        color: 'rgba(82,97,115,1)',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewSquare: {
        flexDirection: 'row',
        height: 14,
        marginLeft: 0,
        alignItems: 'center'
    },
    textDemand: {
        color: gui.mainTextColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        marginTop: 12
    },
    title2: {
        color: gui.mainTextColor,
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        marginTop: 12,
        marginBottom: 12,
        alignSelf: 'center'
    },
    viewListContainer: {
        flex: 1
    },
    viewRowDemand: {
        width: (width - 55) / 2,
        height: 'auto',
        marginRight: 10
    },
    imageStyle: {
        width: (width - 55) / 2,
        height: 114,
    },
    imageWtoStyle: {
        width: 60,
        height: 60,
        borderRadius: 30,
        marginTop: 16
    },
    textNameWto: {
        color: gui.textPostAds,
        fontWeight: '500',
        fontSize: 15,
        fontFamily: gui.fontFamily
    },
    textGiaDemand: {
        fontSize: 15,
        fontWeight: 'bold',
        color: gui.mainAgentColor,
        marginTop: 10,
        fontFamily: gui.fontFamily
    },
    viewContentChild: {
        width: (width - 55) / 2,
        // height: 14,
        marginTop: 5,
        flexDirection: 'row'
    },
    textDienTich: {
        color: gui.mainTextColor,
        fontSize: 12,
        fontFamily: gui.fontFamily,
    },
    viewContent: {
        width: (width - 55) / 2,
        // height: 12,
        marginTop: 7,
        marginBottom: 2
    },
    textContent: {
        color: gui.mainTextColor,
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight: '600'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    textThemNha: {
        fontSize: 15,
        color: gui.mainColor,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    touchAdd: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    textPhone: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        alignSelf: 'center',
        textAlign: 'center'
    },
    textHeaderWto: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15
    },
    imageEmptyHistory: {
        width: 144,
        height: 145,
        marginTop: 24
    },
    contentHistory: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewDetailPost3: {
        height: 'auto', // 65
        width: width,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        paddingLeft: 8
    },
    touchableView: {
        width: width - 32,
        height: 'auto',
        justifyContent: 'center',
        backgroundColor: '#fff',
    },
    viewTieuDe: {
        flexDirection: 'row',
        width: width - 32,
        alignItems: 'center',
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textAgentSolid,
        marginLeft: 9
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
    },
    viewTextTieuDe: {
        height: 24,
        width: width - 62 - 32,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textMainUser2: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        fontWeight: 'normal',
        marginLeft: 0, //8
    },
    viewAdsWto: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff',
    },
    viewRowPostWto: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        // paddingRight: 8,
        paddingTop: 8,
        // paddingBottom: 3,
        backgroundColor: '#fff',
        // borderWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)',
        width: width - 16,
        height: 'auto',
        // marginBottom: 8,
        marginLeft: 8,
        marginRight: 8
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        marginLeft: 8
    },
    viewMoiGioiPhuHop: {
        height: 188,
        width: width,
        backgroundColor: '#fff'
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewRowMoiGioi: {
        height: 150,
        width: 120,
        borderWidth: 1,
        borderRadius: 5,
        borderColor: ('rgba(211, 211, 211, 0.5)'),
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginRight: 8
    },
    viewLineParent: {
        height: 1,
        backgroundColor: "#fff",
        width: width - 32,
    },
    viewTimeShare: {
        height: 36,
        width: width - 32,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewTimeLeft: {
        height: 36,
        width: (width - 34) / 2,
        // paddingLeft: 8,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeRight: {
        height: 33,
        width: (width - 34) / 2,
        paddingRight: 0,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row'
    },
    viewHeaderWto: {
        height: 32,
        width: width - 16,
        backgroundColor: '#fff',
        justifyContent: 'center'
    },
    listSource: {
        flex: 1,
        backgroundColor: '#fff'

    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        width: width - 32,
        height: 20,
        backgroundColor: '#fff'
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center',
        marginTop: height/4 - 30
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(ContactWishList);