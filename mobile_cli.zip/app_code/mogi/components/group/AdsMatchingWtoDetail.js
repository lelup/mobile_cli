'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, TouchableHighlight,
    ScrollView, TextInput, Alert, Keyboard, FlatList} from 'react-native';

import FullLine from '../line/FullLine';
import gui from "../../lib/gui";
import log from '../../lib/logUtil';
import utils from "../../lib/utils";
import placeUtil from '../../lib/PlaceUtil';
import DanhMuc from "../../assets/DanhMuc";
import Toast, {DURATION} from '../toast/Toast';

import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';
import moment from 'moment';
import Button from 'react-native-button';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
const {width, height} = utils.getDimensions();
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon from 'react-native-vector-icons/FontAwesome';
import Communications from '../detail/MCommunications';
let Analytics = require('react-native-firebase-analytics');
import FontAwesomeLight from '../font/FontAwesomeLight';

import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import { Actions } from 'react-native-router-flux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as chatActions from '../../reducers/chat/chatActions';

const actions = [
    globalActions,
    meActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state,
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class AdsMatchingWtoDetail extends React.Component {
    constructor(props) {
        super(props);
        let dataMoiGioi = [
            {   "name" : "Cristiano ronaldo",
                "phone" : "0976 522 336",
                "avatar" : "https://instagram.fhan3-2.fna.fbcdn.net/vp/4680b42d4f04548bb3da5229f2d31fa7/5B6252B5/t51.2885-15/sh0.08/e35/p640x640/30592071_1789223344719777_242206305471692800_n.jpg"
            },
            {   "name" : "Ashley Cole",
                "phone" : "016789 253 641",
                "avatar" : "https://instagram.fhan3-2.fna.fbcdn.net/vp/2d75f05f7a1944452794e28f685a8712/5B6F2AEC/t51.2885-15/sh0.08/e35/p640x640/29400662_1528538097257099_7645434072012947456_n.jpg"
            },
            {   "name" : "Lampard",
                "phone" : "0123 695 236",
                "avatar" :"https://instagram.fhan3-2.fna.fbcdn.net/vp/20e70c0c3b9629c76ed46045ef0ba702/5B6DD8DF/t51.2885-15/sh0.08/e35/p640x640/28753075_167654720622037_374886353575346176_n.jpg"
            }
        ];

        this.state = {
            dataMoiGioi : dataMoiGioi
        }
    }

    _renderHeader() {
        let title = this.props.data.loaiTin==0 ? 'Tin bán phù hợp' : 'Tin cho thuê phù hợp';
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={styles.textEdit}>{title}</Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }
    render() {
        let data = this.props.data;
        let moiGioiMatching = this.props.moiGioiMatching
        return (
            <View style={{flex: 1}}>
                {this._renderHeader()}
                <FullLine/>
                {this._renderBody(data)}
                { this.props.global.currentUser.userID == moiGioiMatching.userID 
                    || this.props.global.currentUser.userID == moiGioiMatching.createdBy 
                    ? null :  this.renderButtonsContact() }
                <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={45}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{ color: '#fff' }}
                    />
            </View>
        );
    }

    _renderBody(data) {
        let textTitle = data.loaiTin==0 ? 'Tin cần mua của bạn' : 'Tin cần thuê của bạn';
        return(
            <View style={styles.viewBody}>
                <View style={styles.viewContentTop}>
                    <View style={styles.viewAdsMatching}>
                        <View style={styles.viewCanMuaTitle}>
                            <Text style={styles.textCommon}>{textTitle}</Text>
                        </View>
                        <FullLine/>
                        {this.renderContentTop(data)}
                    </View>
                </View>
                {this.renderListAdsMatching()}
            </View>
        );
    }

    renderListAdsMatching() {
        let currentUser = this.props.global.currentUser;
        let listWto = this.props.moiGioiMatching;
        let userName = currentUser.userID == listWto.userID || currentUser.userID == listWto.createdBy ? 'bạn' : listWto.name;
        let titleList = this.props.data.loaiTin==0 ? 'TIN BÁN PHÙ HỢP CỦA ' + userName.toUpperCase() : 'TIN CHO THUÊ PHÙ HỢP CỦA ' + userName.toUpperCase() ;
        return(
            <View style={styles.viewListMoiGioi}>
                <View style={styles.viewListTitle}>
                    <Text style={styles.textCommon}>{titleList}</Text>
                </View>
                <FullLine/>
                <View style={styles.listMoiGioiDetail}>
                    <FlatList
                        data={this.props.moiGioiMatching.data}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderRowAdsMatchingWto(data.item)}
                        removeClippedSubviews={false}
                        enableEmptySections
                        style={{ height: 252, width: width }}
                        contentContainerStyle={{ paddingBottom: 65 }}
                    />
                </View>
            </View>
        )
    }

    renderButtonsContact() {
        
        let data = this.props.moiGioiMatching
        let name = data.name;
        let phone = data.phone;
        let titleButton = `Liên hệ bằng cách gọi hoặc nhắn tin với ${name}`;
        let chatStyle = this.props.global.currentUser.userID == data.userID 
        || this.props.global.currentUser.userID == data.createdBy 
        ? styles.buttonContactGrey : styles.buttonContact;
        return(
            <View style={styles.viewButtonsContact}>
                <FullLine/>
                <View style={styles.viewContentButton}>
                    <TouchableOpacity
                        style={[styles.buttonContact, {backgroundColor: 'rgba(49,207,100,1)', marginRight: 10}]}
                        onPress={this._onPhoneCall.bind(this, phone)}
                    >
                        <FontAwesomeLight name="phone" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                        <Text style={[styles.textCommon, {fontSize: 15, marginLeft: 5, color: '#fff'}]}>Gọi</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={chatStyle}                                      
                                        onPress={this.props.global.currentUser.userID == data.userID || this.props.global.currentUser.userID == data.createdBy
                                            ? null : this._onChat.bind(this, data)}
                    >
                        <FontAwesomeLight name="comment-dots" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                        <Text style={[styles.textCommon, {fontSize: 15, marginLeft: 5, color: '#fff'}]}>Chat</Text>
                    </TouchableOpacity>
                </View>
                <Text style={[styles.textCommon, {color: '#959595', marginTop: 6, fontSize: 12, fontWeight: '300'}]}>{titleButton}</Text>
            </View>
        )
    }

    _renderRowAdsMatchingWto(data) {
        let imgUrl = data.image.cover;
        let imagePost = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imgUrl) {
            imagePost = require('../../assets/image/no_cover.jpg');
        }

        let loaiTinText = data.loaiTin == 0 ? 'ban' : 'thue';
        let loaiNhaDat = DanhMuc.getLoaiNhaDatForDisplay(loaiTinText, data.loaiNhaDat);
        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;
        let diaChiFullName = data.diaChi ? data.diaChi : (data.place ? data.place.diaChi : ' ');

        return (
                <View style={styles.viewRowPostNormal}>
                        <View style={[styles.viewRowPost,{height: 'auto', paddingTop: 6}]}>
                            <Image
                                resizeMode={"cover"}
                                source={imagePost}
                                defaultSource={defaultCover}
                                style={styles.imagePost} />
                            {this._renderDetailDone(data)}
                        </View>
                        <View style={[styles.viewLabel, { alignItems: 'flex-start', width: width - 16, marginTop: 5,paddingLeft: 8 }]}>
                            <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                            <View style={{ width: width - 48 }}>
                                <Text numberOfLines={1} style={[styles.textDatePost, { color: '#898989', fontWeight: 'normal'}]}>{diaChiFullName}</Text>
                            </View>
                        </View>
                        <View style={[styles.viewPercentDraft, {paddingLeft: 8,  paddingBottom: 3, marginTop: 0}]}>
                            <Text style={[styles.textGiaNha, {color: '#898989', fontWeight: 'normal'}]} numberOfLines={1}>{loaiNhaDatText}</Text>
                        </View>
                         <View style={styles.lineSuggest}/>
                </View>
        );
    }

    _onPhoneCall(phoneNumber) {
        let propsData = this.props.data;
        if (propsData && propsData.dataType=='dummy') {
            this.refs.toastTop && this.refs.toastTop.show('Đây là dữ liệu mẫu giúp bạn hiểu hệ thống. Không cho phép trao đổi trên dữ liệu không có thật.', DURATION.LENGTH_LONG);
            return;
        }

        if (!phoneNumber) {
            return;
        }

        let phone = phoneNumber;

        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(phone, true);
        Analytics.logEvent('USER_DIALING', { deviceID: deviceID, userID: userID, phone: phone });
    }

    _onChat(data) {
        log.info('==================> data', data);
        let propsData = this.props.data;
        if (propsData && propsData.dataType=='dummy') {
            this.refs.toastTop && this.refs.toastTop.show('Đây là dữ liệu mẫu giúp bạn hiểu hệ thống. Không cho phép trao đổi trên dữ liệu không có thật.', DURATION.LENGTH_LONG);
            return;
        }

        let phone = data.phone;
        if (!phone) {
            return;
        }

        let partner = data.userID ? { userID: data.userID } : { userID: data.member };
        let chatTitle = data.name ? data.name : (data.phone ? data.phone : '');
        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);            
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
            let isSpam = false;
            if (e.partners)
                e.partners.forEach((pn) => {
                    if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                        isSpam = true;
                });
            Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
        });

    }

    renderContentTop(data) {
        let date = moment(data.timeModified).format("DD/MM/YYYY");
        let textShare = data.groupID && data.groupID.length > 0 ? 'Đã chia sẻ với ' + data.groupID.length + ' sàn' : "Không chia sẻ";
        let iconShareName = data.groupID && data.groupID.length > 0 ? "share-variant" : "lock";
        return(
            <View>
                <View style={styles.viewRowPostNormal}>
                    
                        <View style={styles.viewRowPostWto}>
                            {this._renderDetailWtoPost(data)}
                        </View>
                        <View style={styles.viewLineParent}>
                            <FullLine style={{ marginLeft: 8, marginRight: 8 }} />
                        </View>

                        <View style={styles.viewTimeShare}>
                            <View style={styles.viewTimeLeft}>
                                <MaterialCommunityIcons name={"clock"} color={gui.textShare} size={17} />
                                <Text style={styles.textDatePost}>{date}</Text>
                            </View>
                            <View style={styles.viewTimeRight}>
                                <Text style={[styles.textDatePost, { marginLeft: 0, marginRight: 8 }]}>{textShare}</Text>
                                <MaterialCommunityIcons
                                    name={iconShareName}
                                    color={"rgba(85,85,85,1)"}
                                    size={18}
                                />
                                <MaterialCommunityIcons
                                    name={"chevron-down"}
                                    color={gui.textShare}
                                    size={22}
                                />
                            </View>
                        </View>
                    
                </View>
            </View>
        )
    }

    _renderDetailWtoPost(data) {
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority=='hot' ? 'rgba(255,81,81,1)' : (data.priority=='warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)' ))

        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        // let textTieuDe = data.title || utils.getTitleAdsDetail2(data);
        // let address = data.content.place.fullName || '';
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;
        let huongNhaValue = data.content.huongNha && data.content.huongNha.length>0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';        
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length>0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;
        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;
        let diaChiFullName = data.content.place.fullName || ' ';
        if (data.dataType=='dummy')
            diaChiFullname = '[Dữ liệu mẫu] ' + diaChiFullname;

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        return (
            <View>
                <View style={[styles.viewDetailPost, { height: 'auto', width: width - 32 }]}>
                    <View style={[styles.viewTieuDe, { width: width - 32 }]}>
                        <View style={[styles.viewTypePost, {backgroundColor:backGroudTypePost}]}>
                            <Text style={styles.textTypePost}>{priority}</Text>
                        </View>
                        <View style={styles.viewTextTieuDe}>
                            <Text style={styles.textTieuDe} numberOfLines={1}>{diaChiFullname}</Text>
                        </View>
                    </View>
                    <View style={styles.viewPercentDraft}>
                        <Text style={styles.textGiaNha} numberOfLines={1}>{giaNha}</Text>
                    </View>
                    <View style={[styles.viewLabel, {alignItems: 'flex-start'}]}>
                        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} />
                        <Text style={[styles.textDatePost, {fontSize: 14, color: gui.textPostCommon}]}>{diaChiFullName}</Text>
                    </View>
                    <View style={[styles.viewPercentDraft, { flexDirection: 'row' }]}>
                        {detailItems}
                    </View>
                    <View style={styles.viewPercentDraft}>
                        <Text style={[styles.textGiaNha, { color: '#898989', fontWeight: 'normal' }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                    </View>
                </View>
            </View>
        );
    }

    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row'}}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                                      name="location-arrow" color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                                      name="bath" color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostCommon}
                                      mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }
    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={"#2C394C"} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }
    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _renderDetailDone(data) {
        let typePost = DanhMuc.LoaiTin[data.loaiTin];
        let textTieuDe = data.title || utils.getTitleAdsDetail2(data);
        let giaFmt = data ? utils.getPriceDisplay(data.gia, data.loaiTin) : '';
        let giaContent = `Giá: ${giaFmt}`;
        let areaValue = utils.getDienTichDisplay(data.dienTich);
        let bedroomValue = data.soPhongNgu;
        let bathroomValue = data.soPhongTam;
        let huongNhaValue = DanhMuc.getHuongNhaForDisplay(data.huongNha);

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        return (
            <View>
                <View style={[styles.viewDetailPost, { height: 'auto' ,  width: width - 130 + 34 , paddingLeft: 8 }]}>
                    <View style={styles.viewTieuDe}>
                        <View style={styles.viewTypePost}>
                            <Text style={styles.textTypePost}>{typePost}</Text>
                        </View>
                        <View style={styles.viewTextTieuDe}>
                            <Text style={styles.textTieuDe} numberOfLines={1}>{textTieuDe}</Text>
                        </View>
                    </View>
                    <View style={styles.viewPercentDraft}>
                        <Text style={styles.textGiaNha} numberOfLines={1}>{giaContent}</Text>
                    </View>
                    <View style={[styles.viewPercentDraft, {flexDirection:'row'}]}>
                        {detailItems}
                    </View>
                </View>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop()
    }
}

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: 'white'
    },
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize: 17,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
    },
    textCommon: {
        fontSize: 13,
        fontFamily:gui.fontFamily,
        color: "rgba(112,112,112,1)",
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewAdsMatching: {
        height: 155 + 12 + 20,
        width: width - 16,
        marginVertical: 8,
        marginHorizontal: 8,
        backgroundColor: '#fff',
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.1,
        shadowRadius: 2
    },
    viewContentTop: {
        height: 171 + 12 + 20,
        width: width,
        backgroundColor: gui.groupBackground,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewCanMuaTitle: {
        height: 23,
        width: width - 16,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewRowPostNormal: {
        width: width - 16,
        height: 'auto',

    },
    viewRowPost: {
        width: width - 16,
        height: 83,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 8,
        paddingRight: 8,
        backgroundColor: '#fff'
    },
    viewTimeShare: {
        height: 31,
        width: width - 16,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewTimeLeft: {
        height: 31,
        width: (width - 16)/2,
        paddingLeft: 8,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeRight: {
        height: 31,
        width: (width - 16)/2,
        paddingRight: 8,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row'
    },
    viewMoiGioiPhuHop: {
        height: 44,
        width: width - 16,
        paddingLeft: 8,
        paddingRight: 8,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    imagePost: {
        height: 65,
        width: 64
    },
    viewDetailPost: {
        height: 65,
        width: width - 146 + 34,
        justifyContent: 'center',
        backgroundColor: '#fff',
        // paddingLeft: 8
    },
    viewTieuDe: {
        flexDirection: 'row',
        width: width - 138 + 34 - 16,
        alignItems: 'center',
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
        marginLeft: 9
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: '500',
        color: gui.textPostAds,
    },
    viewTextTieuDe: {
        flex: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    viewDetailWto: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textContent: {
        color: gui.textPostAds,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        fontSize: 12,
        textAlign: 'center'
    },
    viewTimePost: {
        marginTop: 3,
        height: 16,
        width: width - 110 - 16
    },
    viewListMoiGioi: {
        flex: 1
    },
    viewListTitle: {
        height: 44,
        width: width,
        paddingLeft: 8,
        justifyContent: 'center'
    },
    listMoiGioiDetail: {
        flex: 1
    },
    viewRowMoiGioi: {
        height: 53,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 8
    },
    viewAvatar: {
        height: 36,
        width: 36,
        borderRadius: 18
    },
    viewContentRow: {
        height: 44,
        width: width - 52 - 22,
        justifyContent: 'center',
        paddingLeft: 8
    },
    textName: {
        color: 'rgba(34,34,34,1)',
        fontWeight: '600',
        fontFamily: gui.fontFamily,
        fontSize: 13
    },
    viewIcon: {
        height: 44,
        width: 22,
        justifyContent: 'center',
        //alignItems: 'flex-end'
    },
    viewButtonsContact: {
        width: width,
        height: 80,
        position: 'absolute',
        bottom: 0,
        alignItems: 'center',
        backgroundColor: '#F8F8F8'
    },
    viewContentButton: {
        width: width,
        height: 52,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-end',
    },
    buttonContact: {
        height: 40,
        width: (width - 60)/2,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 20
    },
    buttonContactGrey: {
        height: 40,
        width: (width - 60)/2,
        backgroundColor: gui.textShare,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 20
    },
    viewRowPostNormalWto: {
        width: width,
        height: 'auto'
    },
    viewRowPostWto: {
        width: width-16,
        height: 'auto',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 6,
        paddingBottom: 3,
        backgroundColor: '#fff'
    },
    viewLineParent: {
        height: 1,
        backgroundColor: "#fff",
        width: width,
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 14,
        color: '#2C394C',
        fontWeight: 'normal',
        marginLeft: 0, //8
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        width: width - 32,
        height: 20,
        paddingLeft: 0,
        backgroundColor: '#fff'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(AdsMatchingWtoDetail);