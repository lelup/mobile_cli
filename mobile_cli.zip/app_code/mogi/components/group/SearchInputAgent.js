'use strict';

import React, {Component} from 'react';


import {
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View,
    ScrollView,
    TouchableHighlight
} from 'react-native';

import gui from "../../lib/gui";
import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import util from "../../lib/utils";
const {width, height} = util.getDimensions();

import GiftedSpinner from 'react-native-gifted-spinner';


export default class SearchInputAgent extends Component {
    render() {
        let btnColor = this.props.disabled ? '#C5C2BA' : '#526173';
        //bachtv them activeView = 'Home'
        let editable = this.props.editable;
        let textValue = this.props.textValue;
        let textAlign = 'left';
        let justifyContent = 'flex-start';
        let textFlex = 1;
        let textWidth = undefined;
        let marginTop = this.props.owner=='Contacts' ? 0 :26;
        let searchContainer = this.props.searchContainer;
        return(
            <View style={styles.container}>
                <View style={[styles.searchContainer, {marginTop : marginTop}, searchContainer]}>
                <TouchableOpacity
                    accessible={true}
                    onPress={() => {this.props.onSuggestPress && this.props.onSuggestPress(); this.refs.textInput.focus()}}
                    disabled={this.props.disabled}
                    style={{flex: 1}}>
                <View style={{flexDirection: 'row', justifyContent: justifyContent, paddingLeft: 16, paddingRight: 16}}
                      onStartShouldSetResponder={(evt) => false}
                      onMoveShouldSetResponder={(evt) => false}
                      pointerEvents="none">
                    {/*<View style={styles.viewIconChange}>
                        {this._renderSearchButton()}
                    </View>*/}
                    <TextInput ref="textInput"
                               autoCorrect={false}
                               autoFocus={this.props.autoFocus}
                               onChangeText={this.props.onChangeText}
                               style={[styles.titleText, {color: btnColor, textAlign: textAlign, flex: textFlex, width: textWidth}]}
                               editable={editable} value={textValue}
                               placeholder={this.props.placeholder}
                               onFocus={this.props.onFocus}
                               onBlur={this.props.onBlur}
                               placeholderTextColor={gui.colorMainBlur}
                               selectionColor={'rgba(82,97,115,0.5)'}
                               clearButtonMode="never"
                               selectTextOnFocus={true}
                               allowFontScaling={false}
                               blurOnSubmit={false}
                               autoCapitalize={'none'}
                               onSubmitEditing={this.props.onSubmitEditing && this.props.onSubmitEditing()}
                               returnKeyType={this.props.returnKeyType}
                    />
                </View>
                </TouchableOpacity>
                {this._renderCloseButton()}
                </View>
            </View>
        )
    }

    _renderCloseButton() {
        return (
            this.props.showCloseButton ? <RelandIcon name="close-circle-f" size={18} color={'#526173'}
                                                     mainProps={{flexDirection: 'row', paddingTop: 1, paddingLeft: 5, paddingRight: 7}}
                                                     textProps={{paddingLeft: 0}}
                                                     onPress={() => {this.props.onChangeText('')}} /> : null
        );
    }

    focusInputSearch() {
        this.refs.textInput.focus();
    }

    _renderSearchButton() {
        if (this.props.isHeaderLoading && this.props.isHeaderLoading()){
            return (
                <View style={{paddingRight: 7, marginLeft: 10, marginTop: 3, backgroundColor: 'transparent', width: 22, alignItems: 'center'}}>
                    <GiftedSpinner size="small" color="#fff" />
                </View>
            )
        } else {
            let btnColor = this.props.disabled ? '#C5C2BA' : '#526173';
            return (
                <RelandIcon name="search-b" size={15} color={btnColor}
                            iconProps={{marginRight: 0}}
                            mainProps={[styles.searchIcon, {flexDirection: 'row'}]}
                            textProps={{paddingLeft: 0}}/>
            )
        }

    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'transparent',
        top: 0,
        position: 'absolute',
        left:0,
        right:0,
        height: 50
    },
    searchIcon: {
        marginLeft: 8,
        marginRight: 0,
        marginTop: 6
    },
    searchContainer: {
        marginTop: 26,
        marginBottom: 20,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: gui.groupBackground,
        borderRadius: 5,
        marginLeft: 0,
        marginRight: 10,
        height: 36, // 30
    },
    textInput : {
        fontSize: 15,
        height: 30,
        borderRadius: 5
    },
    autocompleteContainer: {
        flex: 1,
        left: 0,
        position: 'absolute',
        right: 0,
        top: 15

    },
    inputContainerStyle: {
        borderRadius:5
    },

    itemText: {
        fontSize: 15,
        margin: 2
    },
    info: {
        paddingTop: 60,
        flex:4
    },
    infoText: {
        textAlign: 'center'
    },
    titleText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        // paddingLeft: 5,
        color: 'white',
        backgroundColor: 'transparent',
        flex: 1,
        paddingVertical: 0
    },
    directorText: {
        color: 'grey',
        fontSize: 12,
        marginBottom: 10,
        textAlign: 'center'
    },
    openingText: {
        textAlign: 'left'
    },
    viewIconChange: {
        width: 26,
        height: 26,
        backgroundColor: 'transparent'
    }

});
