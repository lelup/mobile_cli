import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableHighlight,
    Alert,
    StatusBar
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';

import { Map } from 'immutable';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import SummaryText from '../SummaryText';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Toast, { DURATION } from '../toast/Toast';

import LinearGradient from 'react-native-linear-gradient';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as wallActions from '../../reducers/wall/wallActions';


import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';


const actions = [
    globalActions,
    meActions,
    groupActions, 
    wallActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_groupRequest = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

let { width, height } = utils.getDimensions();

class GroupRequest extends Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            searchText: '',
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null,
            loaded: false,
        }
    }

    componentWillMount() {
        StatusBar.setBarStyle('light-content');
        setTimeout( () =>{this.fetchData()}, 300 )
        
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        //Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

    fetchData() {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.props.actions.onGroupFieldChange('requestList', [])
        
        this.props.actions.getPendingRequest(
            { 'groupID': this.props.groupID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)
                this.refreshRowData(res.data)
            }
            , (error) => {
                this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });

    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'requestList': data,
            loaded: true
        });

    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}

                <ScrollView
                    contentContainerStyle={{ width: width, height: height - 80 - 135.4 }}
                    automaticallyAdjustContentInsets={false}
                    showsVerticalScrollIndicator={false}
                    vertical={true}
                    style={styles.scrollView}>
                    <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={100}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{ color: '#fff' }}
                    />

                    {this._renderListRequest()}
                </ScrollView>

                {this._renderButton()}
            </View>
        );
    }

    _renderButton() {
        return (
            <View style={styles.searchButtonView}>
                <TouchableOpacity
                    style={[styles.searchButton, { borderColor: gui.mainColor }]}
                    onPress={() => this._onApproveAll(2)}
                >
                    <Text style={[styles.searchButtonText, { color: gui.mainColor }]}>Chấp nhận tất cả</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.searchButton, { marginLeft: 20, borderColor: gui.mainTextColor }]}
                    onPress={() => this._onApproveAll(3)}
                >
                    <Text style={[styles.searchButtonText, { color: gui.mainTextColor }]}>Từ chối tất cả</Text>
                </TouchableOpacity>
            </View>
        )
    }

    _onApproveAll(newStatus) {
        let groupData = this.props.groupData;
        let userID = this.props.global.currentUser.userID;

        if(userID != groupData.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Tính năng này chỉ dành cho chủ sàn', DURATION.LENGTH_LONG);
            return;
        }
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let requestList = this.props.wall.requestList;
        ids = [];
        members = []
        requestList.forEach((e) => {
            ids.push(e.id);
            members.push(e.member);
        })

        if (members.length == 0) {
            Alert.alert(
                "Thông báo",
                "Không có yêu cầu cần phê duyệt.",
                [{ text: 'Đóng', onPress: () => {
                    if (this.props.owner == 'MyAlert') {
                        // Actions.MyAlert();
                        StatusBar.setBarStyle('default');
                        Actions.pop();
                    } else {
                        StatusBar.setBarStyle('default');                        
                        Actions.pop();
                    }
                } }]);
            return;
        }

        let approveJoinDto = {
            "approver": groupData.userID || undefined,
            "newStatus": newStatus,
            "groupMemberIDs": ids || undefined,
            "memberIDs": members || undefined,
            "groupID": this.props.groupID,
            "groupName": this.props.groupData.name,
            "groupImage": this.props.groupData.image
        };

        this.props.actions.approveAll(approveJoinDto, token)
            .then(res => {
                // console.log("server respond: ", res);
                this.setState({
                    loading: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    // Actions.popTo('root');
                    // Actions.AdsMgmt();
                    Alert.alert(
                        "Thông báo",
                        "Phê duyệt hoàn tất.",
                        [{ text: 'Đóng', onPress: () => {
                            if (this.props.owner == 'MyAlert') {
                                // Actions.MyAlert();
                                Actions.pop();
                            } else {
                                StatusBar.setBarStyle('default');                                
                                Actions.pop();
                            }
                        } }]);
                    this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
                }
            });
    }


    _renderHeader() {
        let image = this.props.groupData && this.props.groupData.image || '';
        let defaultImage = require('../../assets/image/no_cover.jpg');
        let imageSource = {uri: image};
        if (!image) {
            imageSource = defaultImage;
        }
        return (
            <View style={styles.headerView}>
                <Image source={imageSource} defaultSource={defaultImage} style={styles.groupImage}>
                    <LinearGradient colors={['rgba(0, 0, 0, 0.9)', 'transparent']}
                                    style={styles.linearGradient}>
                    <View style={styles.cancelView}>
                        <TouchableOpacity onPress={this._onCancelClicked.bind(this)}>
                            <MaterialCommunityIcons name="close" size={24} color={'#fff'}/>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.headerView2}>
                        <Text style={[styles.headerText, {color: '#fff'}]}>Yêu cầu tham gia</Text>
                    </View>
                    </LinearGradient>
                </Image>
            </View>
        );

    }

    _onCancelClicked() {
        if (this.props.owner == 'MyAlert') {
            StatusBar.setBarStyle('default');
            // Actions.MyAlert();
            Actions.pop();
        } else {
            StatusBar.setBarStyle('default');            
            Actions.pop();
        }
    }

    _onGroupSearchPress() {
        StatusBar.setBarStyle('default');
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }
    _renderListRequest() {
        if (this.props.wall.requestList.length == 0) {
            return (
                <View style={styles.viewNoneRequest}>
                    <Text style={styles.textNoneRequest}>Không có yêu cầu chờ duyệt</Text>
                </View>
            )
        }
        let dsRequest = ds_groupRequest.cloneWithRows(this.props.wall.requestList);
        let groupData = this.props.groupData;
        
        return (
            <View style={{ flex: 1, marginTop: 12 }}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsRequest}
                    renderRow={this._renderRowRequest.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowRequest(data) {
        let imgUrl = data.avatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = defaultCover;
        }

        let requester = data.fullName;
        let message = data.message;
        let requestTime = data.requestTime;

        return (
            <View style={styles.viewRowContent}>
                <View style={styles.viewContent}>
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsCover} />
                    <View style={styles.viewBodyContent}>
                        <View style={styles.viewNameGroup}>
                            <Text style={[styles.textNameGroup, { marginLeft: 16 }]} numberOfLines={1}>{requester}</Text>
                        </View>
                        <View style={styles.viewTimeGroup}>
                            <Text style={[styles.textNameAvatar, { marginLeft: 16 }]}>{utils.getDiffTime(requestTime)}</Text>
                        </View>
                    </View>
                    <View style={styles.approve}>
                        <TouchableOpacity onPress={() => this._onApprove(data, 2)}>
                            <Icon name="check" size={18} color={gui.mainColor} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.reject}>
                        <TouchableOpacity onPress={() => this._onApprove(data, 3)}>                            
                            <MaterialCommunityIcons name="close" size={24} color={gui.mainTextColor}/>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.viewDetailEachGroup}>
                    <SummaryText
                        style={styles.textMessage}
                        textProps={{
                            fontWeight: 'normal',
                            fontFamily: gui.fontFamily,
                            color: gui.colorMainBlur,
                            fontSize: 12
                        }}
                        longText={message}
                        expanded={false}
                        maxLength={60}
                        width={width - 104}>
                    </SummaryText>
                </View>
            </View>
        )
    }

    _onApprove(data, newStatus) {
        let groupData = this.props.groupData;
        let userID = this.props.global.currentUser.userID;

        if(userID != groupData.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Tính năng này chỉ dành cho chủ sàn', DURATION.LENGTH_LONG);
            return;
        }
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        let approveJoinDto = {
            "approver": groupData.userID || undefined, // chu san moi duoc duyet
            "newStatus": newStatus,
            "groupMemberID": data.id || undefined,
            "member": data.member || undefined,
            "groupID": this.props.groupID,
            "groupName": this.props.groupData.name,
            "groupImage": this.props.groupData.image
        };

        this.props.actions.approve(approveJoinDto, token)
            .then(res => {
                // console.log("server respond: ", res);
                this.setState({
                    loading: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {                    
                    if (newStatus == 2)
                        this.refs.toastTop && this.refs.toastTop.show(data.fullName ? data.fullName + ' đã được phê duyệt!' : data.phone + ' đã được phê duyệt!', DURATION.LENGTH_SHORT);
                    else if (newStatus == 3)
                        this.refs.toastTop && this.refs.toastTop.show(data.fullName ? data.fullName + ' đã bị từ chối!' : data.phone + 'đã bị từ chối!', DURATION.LENGTH_SHORT);
                    this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
                
                }
            });
    }

    _onReject() { }

    _renderButtonChat() {
        let totalMessages = '23';
        return (
            <TouchableOpacity style={styles.viewButtonChat}>
                <View style={styles.viewCircleChat}>
                    <Icon name="comments-o" size={22} color={'#fff'} style={{ marginLeft: 0 }} />
                </View>
                <View style={styles.viewNumberMessage}>
                    <Text style={[styles.textNameAvatar, { fontSize: 8, color: '#fff' }]}>{totalMessages}</Text>
                </View>
            </TouchableOpacity>
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        flex: 1,
        backgroundColor: gui.groupBackground,
        paddingBottom: 130
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewIntroduce: {
        width: width,
        height: 100,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 19
    },
    viewTextTop: {
        width: width - 32,
        height: 60,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    viewTextEnd: {
        width: width - 32,
        height: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
    },
    textTopPattern: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontSize: 15
    },
    viewContent: {
        width: width - 40,
        height: 48,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewDetailEachGroup: {
        width: width - 104,
        // height: 32,
        marginTop: 6,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        marginLeft: 64
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 0,
        borderRadius: 24
    },
    viewBodyContent: {
        backgroundColor: 'transparent',
        height: 48,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 81,//31
        height: 81,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 19
    },
    viewNameGroup: {
        backgroundColor: 'transparent',
        height: 24,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeGroup: {
        backgroundColor: 'transparent',
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    textMessage: {
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        fontSize: 12
    },
    viewRowContent: {
        // height: 84,
        // borderWidth: 1,
        marginTop: 22,//14
        // borderColor: 'rgba(82,97,115,0.3)',
        width: width - 40,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
        marginLeft: 16,
        marginRight: 24
    },
    lineEachGroup: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 64,
        opacity: 0.8
    },
    viewListContainer: {
        paddingBottom: 50
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    headerView: {
        backgroundColor: 'transparent',
        height: 135.4,
        width: width
    },
    cancelView: {
        backgroundColor: 'transparent',
        marginTop: 45,
        marginLeft: 21,
        width: 24,
        height: 24
    },
    headerView2: {
        backgroundColor: 'transparent',
        marginTop: 23,
        marginLeft: 16,
        width: width - 16,
        height: 36
    },
    headerText: {
        fontSize: 24,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    approve: {
        width: 18,
        height: 18,
        backgroundColor: 'transparent',
    },
    reject: {
        width: 18,
        height: 18,
        marginLeft: 24,
        backgroundColor: 'transparent',
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 72,
        bottom: 49,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row'
        //borderRadius: 24
    },
    searchButton: {
        height: 41,
        width: (width - 52) / 2,
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1
    },
    searchButtonText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewNoneRequest: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    textNoneRequest: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontSize,
        color: gui.mainTextColor,
        fontWeight: '400'
    },
    groupImage: {
        height: 135.4,
        width: width,
        alignSelf: 'auto'
    },
    linearGradient: {
        flexGrow: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupRequest);