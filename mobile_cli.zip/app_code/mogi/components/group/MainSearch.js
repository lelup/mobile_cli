import React, { Component } from 'react';
import {
    Text,
    View,
    Alert,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    ListView,
    Image,
    TextInput
} from 'react-native';
import gui from '../../lib/gui';
import Button from 'react-native-button';
import SearchInput from './SearchInputAgent';
import GiftedSpinner from "../GiftedSpinner";
import KeyboardSpacer from 'react-native-keyboard-spacer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Actions } from 'react-native-router-flux';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import { Map } from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as groupActions from '../../reducers/group/groupActions';

import log from '../../lib/logUtil';

import utils from '../../lib/utils';

import CommonUtils from '../../lib/CommonUtils';

import DanhMuc from '../../assets/DanhMuc';

import RangeUtils from "../../lib/RangeUtils";

import placeUtil from '../../lib/PlaceUtil';

import RelandIcon from '../RelandIcon';
import OfflineBar from '../line/OfflineBar';
import Modal from 'react-native-modalbox';

import ScalableText from 'react-native-text';

var { width, height } = utils.getDimensions();

var myDs = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

const actions = [
    globalActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MainSearch extends React.Component {
    constructor(props) {
        super(props);
        let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(props.group.searchResult.listRelatedGroup);
        this.state = {
            toggleState: false,
            text: props.group.searchFields.name,
            mainSearchResult: props.group.mainSearchResult,
            isOpenModalJoin: false,
            hashRelatedGroupStatus: hashRelatedGroupStatus,
            textToChuSan: ''            
        };
    }

    _getHashRelatedGroupStatus(listRelatedGroup) {
        let hashRelatedGroupStatus = {};
        listRelatedGroup && listRelatedGroup.forEach((one) => {
            hashRelatedGroupStatus[one.groupID] = one.joinStatus;
        });
        return hashRelatedGroupStatus;
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.group.searchResult.listGroup !== this.props.group.searchResult.listGroup) {
            let hashRelatedGroupStatus = this._getHashRelatedGroupStatus(nextProps.group.searchResult.listRelatedGroup);
            this.setState({
                text: nextProps.group.searchFields.name,
                listGroup: nextProps.group.searchResult.listGroup,
                hashRelatedGroupStatus: hashRelatedGroupStatus
            });
        }
    }

    render() {
        let placeholder = 'Tìm kiếm';
        return (
            <View style={styles.container}>
                <OfflineBar />
                {/* {this._renderTabFilter()} */}
                {this._renderGroupContent()}
                <View style={styles.pageHeader}>
                    <TouchableOpacity style={styles.backButton}
                                      onPress={this._onBackPress.bind(this)}>
                                      <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor} />
                    </TouchableOpacity>
                    <View style={styles.pageHeaderWrapper}>
                        <SearchInput placeholder={placeholder} textValue={this.state.text}
                            loadSearchFilter={(fields) => this._loadSearchFilter(fields)}
                            onSuggestPress={this._onSuggestPress.bind(this)}
                            editable={false} />
                    </View>
                </View>

                {this._openModalJoin()}
                {this._renderLoadingView()}

            </View>
        );
    }

    _openModalJoin() {
        return (
            <Modal isOpen={this.state.isOpenModalJoin}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle2}
                position={"center"}
                swipeToClose={true}
                backdropPressToClose={true}
            >
                <View style={{ flex: 1 }}>
                    {/* <ScrollView style={{ flex: 1 }}> */}
                        {this._renderJoinContent()}
                    {/* </ScrollView> */}

                    <KeyboardSpacer topSpacing={-240} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />
                </View>

            </Modal>
        );
    }

    _onContentModal() {
        this.setState({
            isOpenModalJoin: false
        });
    }

    _renderJoinContent() {
        return (
            <View style={styles.viewDetailModal}>

                {this.state.toggleState ?
                    <Button onPress={() => dismissKeyboard()}
                        style={[styles.searchButtonText2, {
                            textAlign: 'right', color: gui.mainColor,
                            backgroundColor: 'transparent',
                            height: 35, width: width,
                        }]}>Xong</Button>
                    : null}

                <View style={{ marginTop: 18, marginLeft: 17, width: width - 64}}>
                    <TextInput
                        autoFocus={false}
                        autoCapitalize='none'
                        autoCorrect={false}
                        returnKeyType='done'
                        //underlineColorAndroid='rgba(0,0,0,0)'
                        style={styles.viewTextInput}
                        placeholder="Để lại ghi chú cho chủ sàn…" placeholderTextColor={gui.arrowColor}
                        onChangeText={(text) => { this.onValueChange("textToChuSan", utils.normalizeName(text)) }}
                        value={ utils.normalizeName(this.state.textToChuSan) }
                        multiline={true}
                        maxLength={150}
                        numberOfLines={3}
                    />
                </View>
                {this._renderButtonJoin()}
            </View>
        )
    }

    _renderLoadingView() {
        if (this.props.group.requestingJoin) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderButtonJoin() {
        if (this.props.group.requestingJoin)
            return (
                <View style={styles.searchButtonView}>
                    <View
                        style={styles.searchButton}
                    >
                        <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                    </View>
                </View>
            )
        return (
            <View style={styles.searchButtonView}>
                <TouchableOpacity
                    style={styles.searchButton}
                    onPress={this.onRequestJoin.bind(this)}
                >
                    <Text style={styles.searchButtonText}>GỬI YÊU CẦU</Text>
                </TouchableOpacity>
            </View>
        )
    }

    onValueChange(key: string, value: string) {
        this.setState({'textToChuSan': value})
        // this.props.actions.onGroupFieldChange(key, value);
    }

    onRequestJoin() {

        let rowData = this.state.data;
        if (!rowData) {
            return;
        }

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;


        let requestJoinDto = {
            "requester": currentUser.userID || undefined,
            "requesterName": currentUser.fullName || currentUser.phone || currentUser.email || undefined,
            "approver": rowData.userID || rowData.createdBy || undefined,
            "member": currentUser.userID || undefined,
            "memberName": currentUser.fullName || undefined,
            "memberNameKhongDau": utils.locDauV2(utils.standardlizeName(currentUser.fullName)),
            "memberAvatar": currentUser.avatar || undefined,
            "groupID": rowData.groupID || undefined,
            "groupName": rowData.name || undefined,
            "groupImage": rowData.image || undefined,
            "message": this.state.textToChuSan
        };


        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let fetchRelatedGroupSuccess = this.props.actions.fetchRelatedGroupSuccess;

        this.props.actions.requestToJoin(requestJoinDto, token)
            .then(res => {
                // console.log("server respond: ", res);
                this.setState({
                    loading: false,
                    isOpenModalJoin: false
                });

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    // Actions.popTo('root');
                    // Actions.AdsMgmt();

                    rowData.joinStatus = 1;
                    let found = listRelatedGroup.find((one) => {
                        return one.groupID == rowData.groupID
                    });
                    if (found) {
                        listRelatedGroup = listRelatedGroup.filter((one) => {
                            return one.groupID != rowData.groupID
                        });
                    }
                    listRelatedGroup = [...listRelatedGroup, rowData];
                    fetchRelatedGroupSuccess(listRelatedGroup);

                    let hashRelatedGroupStatus = this.state.hashRelatedGroupStatus;
                    hashRelatedGroupStatus[rowData.groupID] = 1;
                    this.setState({ hashRelatedGroupStatus: hashRelatedGroupStatus });

                    setTimeout(() => Alert.alert(
                        "Thông báo",
                        "Xác nhận yêu cầu tham gia sàn được gửi thành công và đang chờ duyệt.",
                        [{ text: 'Đóng', onPress: () => { } }]), 1000);
                }
            });
    }

    _onBackPress() {
        if (this.props.owner == 'NewHomeAgent') {
            Actions.NewHomeAgent();
        } else {
            Actions.GroupMgmt2();
        }
    }

    _renderGroupContent() {
        let listResult = this.state.mainSearchResult || [];
        let ds = myDs.cloneWithRows(listResult);

        return (
            <View style={{ flex: 1, position: 'absolute', top: 108, left: 0, right: 0, bottom: 0, backgroundColor: '#F2F2F2' }}>
                <View style={styles.lineView} />
                <View style={styles.groupTitleView}>
                    <Text style={styles.groupTitleText}>KẾT QUẢ TÌM ĐƯỢC</Text>
                </View>
                <ListView style={styles.groupListView}
                    contentContainerStyle={styles.viewListContainer}
                    ref={(listView) => { this._listView = listView; }}
                    dataSource={ds}
                    renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0), (rowID == (ds._dataBlob.s1.length - 1)))}
                    stickyHeaderIndices={[]}
                    enableEmptySections={true} />
            </View>
        );
    }

    _renderRow(rowData = {}, sectionID, rowID, isFirstRow, isLastRow) {
        let allDuAn = rowData.diaBan.filter((one) => {
            return one.type == 'A'
        });
        let allKhuVuc = rowData.diaBan.filter((one) => {
            return one.type != 'A'
        });
        let duAn = '';
        if (allDuAn && allDuAn.length > 0) {
            let oneDuAn = allDuAn[0];
            duAn = oneDuAn.duAn;
            if (allDuAn.length > 1) {
                duAn += ', +' + (allDuAn.length - 1) + ' dự án khác';
            }
        }
        let khuVuc = '';
        if (allKhuVuc && allKhuVuc.length > 0) {
            let oneKhuVuc = allKhuVuc[0];
            khuVuc = placeUtil.getKhuVucFullName(oneKhuVuc);
            if (allKhuVuc.length > 1) {
                khuVuc += ', +' + (allKhuVuc.length - 1) + ' khu vực khác';
            }
        }
        let showDiaBanItems = (allKhuVuc && allKhuVuc.length > 0) || (allDuAn && allDuAn.length > 0);

        let duAnItem = duAn ? <View style={{ flexDirection: 'row' }}>
            <RelandIcon noAction={true}
                name="suggest-project" color={'#526173'}
                size={16} iconProps={{ style: styles.diaBanIcon }}>
            </RelandIcon>
            <Text style={styles.diaBanText} numberOfLines={1}>{duAn}</Text>
        </View> : null;

        let khuVucItem = khuVuc ? <View style={{ flexDirection: 'row' }}>
            <RelandIcon noAction={true}
                name="suggest-location" color={'#526173'}
                size={16} iconProps={{ style: styles.diaBanIcon }}>
            </RelandIcon>
            <Text style={styles.diaBanText} numberOfLines={1}>{khuVuc}</Text>
        </View> : null;

        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let avatarImage = { uri: rowData.avatar };
        if (!rowData.avatar) {
            avatarImage = defaultAvatar;
        }

        let defaultGroupImage = CommonUtils.getNoCoverImage();
        let groupImage = { uri: rowData.image };
        if (!rowData.image) {
            groupImage = defaultGroupImage;
        }

        let joinStatus = this.state.hashRelatedGroupStatus[rowData.groupID];
        let statusFmt = DanhMuc.groupStatus[joinStatus] || '';

        return (
            <TouchableOpacity onPress={this._onGroupDetailPress.bind(this, rowData)}>
                <View style={{ flex: 1, marginLeft: 15, marginRight: 15, marginBottom: 15, borderWidth: 1, borderColor: 'rgba(82,97,115,0.3)', backgroundColor: '#fff' }}>
                    <View style={styles.groupMainView}>
                        <Image style={styles.groupImage} source={groupImage} defaultSource={defaultGroupImage} />
                        <View style={{flex: 1, justifyContent: 'center'}}>
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                                <View style={styles.chiTietView}>
                                    <View style={{ flex: 1, paddingLeft: 16, paddingRight: 16, justifyContent: 'flex-start' }}>
                                        <ScalableText style={styles.groupName} numberOfLines={2}>{rowData.name}</ScalableText>
                                    </View>
                                </View>
                                {joinStatus != 1 && joinStatus != 2 ?
                                    <RelandIcon onPress={this._onJoinGroupPress.bind(this, rowData)}
                                        name="plus-circle-o" color={'#526173'}
                                        size={20}
                                        mainProps={{ paddingRight: 2 }}
                                    />
                                    : <Text style={styles.groupStatus}>{statusFmt}</Text>
                                }
                            </View>
                            <View style={{ width: width - 188, flexDirection: 'row', paddingLeft: 17, paddingTop: 5 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={styles.createByImage} source={avatarImage} defaultSource={defaultAvatar} />
                                    <Text style={[styles.groupStatus, { marginLeft: 12 }]} numberOfLines={1}>{rowData.fullNameChuSan}</Text>
                                </View>
                                <View style={{ flexDirection: 'row', paddingLeft: 17 }}>
                                    <RelandIcon noAction={true}
                                                name="group-two" color={'#526173'}
                                                size={16} iconProps={{ style: [styles.diaBanIcon, { marginTop: 1 }] }}>
                                    </RelandIcon>
                                    <Text style={styles.groupStatus}>{rowData.countMember || 0}</Text>
                                </View>
                            </View>
                        </View>
                    </View>
                    {showDiaBanItems ? <View>
                        <View style={[styles.lineView, { marginLeft: 17, marginRight: 17 }]} />
                        <View style={styles.diaBanView}>
                            {duAnItem}
                            {khuVucItem}
                        </View>
                    </View> : null}
                </View>
            </TouchableOpacity>
        );
    }

    _onGroupDetailPress(data) {
        Actions.GroupDetail({ groupData: data, groupID: data.groupID, owner: 'GroupSearch' });
    }

    _onJoinGroupPress(data) {
        this.onValueChange("textToChuSan", '');
        this.setState({ data: data, groupID: data.groupID, isOpenModalJoin: true });
    }

    _loadSearchFilter(fields) {

    }

    _onSuggestPress() {
        Actions.MainAutoComplete({            
            placeholder: 'Tìm kiếm', 
            userID: this.props.global.currentUser.userID, 
            listRelatedGroup: this.props.group.searchResult.listRelatedGroup,
            searchAgent: this.props.actions.searchAgent,
            minLength: 0, mainSearchResult: this.props.group.mainSearchResult, 
            onPress: this._doSuggestGroupFinal.bind(this),
            loadingMain: this.props.group.loadingMain, 
            mainSearchFields: this.props.group.mainSearchFields
        });
    }

    _doSuggestGroupFinal(rowData) {
        this.setState({ text: rowData.name });
        this.props.actions.onSearchMainFieldChange('name', rowData.name || undefined);

        let fields = utils.cloneRecord(this.props.group.mainSearchFields);
        fields.name = rowData? rowData.name : undefined;
        
        this.props.actions.searchAgent(true, fields, (res) => {
            if (res.status == 0) {
                this.setState({ listGroup: res.data });
            }
            Actions.pop();
        });
    }

    _renderTabFilter() {
        let khuVucValue = this._getKhuVucValue();
        let duAnValue = this._getDuAnValue();
        let totalKhuVuc = this.props.group.searchFields.khuVuc.length;
        let totalDuAn = this.props.group.searchFields.duAn.length;
        let khuVucBgColor = totalKhuVuc ? '#1BA7DF' : 'rgba(82,97,115,0.25)';
        let khuVucTextColor = totalKhuVuc ? '#fff' : '#526173';
        let duAnBgColor = totalDuAn ? '#1BA7DF' : 'rgba(82,97,115,0.25)';
        let duAnTextColor = totalDuAn ? '#fff' : '#526173';
        return (
            <View style={[styles.tabbar, styles.viewTabFilter]}>
                <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                >
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: khuVucBgColor, marginLeft: 0 }]}
                        onPress={this._onModalKhuVuc.bind(this)}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            {totalKhuVuc ? <View style={styles.totalView}>
                                <Text style={styles.totalText}>{totalKhuVuc}</Text>
                            </View> : <View style={{ margin: 4 }} />
                            }
                            <Text style={[styles.textButtonTab, { marginLeft: 4, color: khuVucTextColor }]}>{khuVucValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={khuVucTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                        {/*<TruliaIcon
                            name="arrow-down" color={'#fff'} size={20}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />*/}
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: duAnBgColor }]}
                        onPress={this._onModalDuAn.bind(this)}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            {totalDuAn ? <View style={styles.totalView}>
                                <Text style={styles.totalText}>{totalDuAn}</Text>
                            </View> : <View style={{ margin: 4 }} />
                            }
                            <Text style={[styles.textButtonTab, { marginLeft: 4, color: duAnTextColor }]}>{duAnValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={duAnTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                        {/*<TruliaIcon
                            name="arrow-down" color={'#526173'} size={20}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />*/}
                    </TouchableOpacity>
                </ScrollView>
            </View>
        )
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _getKhuVucValue() {
        return 'Khu vực';
    }

    _getDuAnValue() {
        return 'Dự án';
    }

    _onModalDuAn() {
        Actions.GroupDuAn({
            selectedDiaChinh: this.props.group.searchFields.duAn, placeholder: 'Tìm theo tên dự án', minLength: 2,
            onApply: (duAnFilter) => {
                let duAn = [];
                duAnFilter.forEach((one) => {
                    let diaChinh = {};
                    diaChinh.tinh = one.tinhName;
                    diaChinh.codeTinh = one.tinh;
                    diaChinh.huyen = one.huyenName;
                    diaChinh.codeHuyen = one.huyen;
                    diaChinh.duAn = one.duAnName;
                    diaChinh.codeDuAn = one.duAn;
                    diaChinh.name = one.name;
                    duAn.push(diaChinh);
                });
                this.props.actions.onSearchGroupFieldChange('duAn', duAn);
                let fields = utils.cloneRecord(this.props.group.searchFields);
                fields.duAn = duAn;
                this.props.actions.searchGroup(false, fields, (res) => {
                    if (res.status == 0) {
                        this.setState({ listGroup: res.data });
                    }
                });
            }
        });
    }

    _onModalKhuVuc() {
        Actions.GroupPlace({
            selectedDiaChinh: this.props.group.searchFields.khuVuc, placeholder: 'Tìm theo khu vực', minLength: 2,
            onApply: (khuVucFilter) => {
                let khuVuc = [];
                khuVucFilter.forEach((one) => {
                    let placeType = one.placeType;
                    let diaChinh = {};
                    if (placeType == 'T') {
                        diaChinh.tinh = one.tinhName;
                        diaChinh.codeTinh = one.tinh;
                    }
                    if (placeType == 'H') {
                        diaChinh.huyen = one.huyenName;
                        diaChinh.codeHuyen = one.huyen;
                    }
                    if (placeType == 'X') {
                        diaChinh.xa = one.xaName;
                        diaChinh.codeXa = one.xa;
                    }
                    diaChinh.name = one.name;
                    khuVuc.push(diaChinh);
                });
                this.props.actions.onSearchGroupFieldChange('khuVuc', khuVuc);
                let fields = utils.cloneRecord(this.props.group.searchFields);
                fields.khuVuc = khuVuc;
                this.props.actions.searchGroup(false, fields, (res) => {
                    if (res.status == 0) {
                        this.setState({ listGroup: res.data });
                    }
                });
            }
        });
    }
};

const styles = StyleSheet.create({
    container: {
        paddingTop: 0,
        backgroundColor: "white",
        flex: 1
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width,
        height: 64
    },
    pageHeaderWrapper: {
        position: 'absolute',
        left: 50,
        right: 6,
        top: 0,
        height: 64
    },
    tabbar: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        // bottom: 0
    },
    viewTabFilter: {
        height: 44,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingTop: 2,
        paddingBottom: 2
    },
    viewEachButtonTab: {
        // padding: 3,
        // paddingLeft: 15,
        // paddingRight: 15,
        width: width / 2 - 25,
        height: 32,
        backgroundColor: '#fff',
        // borderColor: gui.mainColor,
        // borderWidth: 1,
        borderRadius: 4,
        marginLeft: 10,
        marginTop: 0,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainColor,
        textAlign: 'left'
    },
    viewDownIcon: {
        marginBottom: 0,
        justifyContent: 'flex-end',
        height: 21,
        // width: 21,
        marginTop: 30,
        marginRight: 10
    },
    groupTitleView: {
        marginTop: 10,
        marginBottom: 10
    },
    groupTitleText: {
        fontSize: gui.capitalizeFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: 'rgba(82,97,115,0.5)',
        textAlign: 'center'
    },
    groupListView: {
        flex: 1
    },
    groupMainView: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 17,
        paddingLeft: 17,
        paddingRight: 17,
        paddingBottom: 10
    },
    chiTietView: {
        flex: 1
    },
    groupImage: {
        width: 48,
        height: 48
    },
    groupName: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#526173',
        textAlign: 'left'
    },
    groupStatus: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: 'rgba(82,97,115,0.5)',
        textAlign: 'center'
    },
    diaBanView: {
        flex: 1,
        paddingTop: 17,
        paddingRight: 17,
        paddingLeft: 17
    },
    diaBanText: {
        fontSize: gui.capitalizeFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left',
        marginBottom: 17
    },
    diaBanIcon: {
        marginRight: 12
    },
    createByImage: {
        width: 16,
        height: 16,
        borderRadius: 8
    },
    backButton: {
        height: 64,
        width: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: gui.marginTopAgent
    },
    totalView: {
        width: 24,
        height: 24,
        marginLeft: 4,
        marginRight: 4,
        borderRadius: 4,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    },
    totalText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: '#1BA7DF',
        textAlign: 'left'
    },
    lineView: {
        borderTopWidth: 1,
        height: 1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    viewListContainer: {
        paddingBottom: 50
    },
    viewModalStyle2: {
        justifyContent: 'center',
        height: 210,
        width: width - 30,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8,
        height: 210
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        width: width - 48 - 32
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 48,
        bottom: 17,
        width: width,
        backgroundColor: 'transparent',
        //borderRadius: 24
    },
    searchButton: {
        height: 48,
        width: width - 64,
        backgroundColor: '#1BA7DF',
        borderRadius: 24,
        alignItems: 'center',
        justifyContent: 'center'
    },
    searchButtonText: {
        color: '#FFFFFFFF',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 5,
        paddingRight: 20,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(MainSearch);