import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    Switch,
    StatusBar,
    KeyboardAvoidingView
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
let {width, height} = utils.getDimensions();

const Permissions = require('react-native-permissions');
import FontAwesomeLight from '../font/FontAwesomeLight';
import dismissKeyboard from 'react-native-dismiss-keyboard';

class DieuKhoanAgent extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderHeader()}
                <FullLine />
                {this._renderBody()}
            </View>
        );
    }

    _renderHeader() {
        return (
            <View style={styles.viewGroupChatHeader}>
                <TouchableOpacity style={styles.viewCloseLeft}
                                  onPress={this._onPressClose.bind(this)}
                >
                    <FontAwesomeLight name="times"
                                      size={23}
                                      color={gui.mainColor}
                                      mainProps={{marginTop: 3}}
                                      noAction={true}
                                      iconOnly={true}
                    />
                </TouchableOpacity>
                <View style={styles.headerText}>
                    <Text numberOfLines={1} style={styles.textNameFriend}>Quy định của Landber Agent</Text>
                </View>
                <View style={styles.viewCloseIcon}>
                </View>
            </View>
        );
    }

    _renderBody() {
        let title1 = 'I. Điều khoản cam kết';
        let title2 = 'II. Điều khoản áp dụng';
        let title3 = 'III. Khi có lỗi phát sinh';
        let title4 = 'IV. Trách nhiệm của LANDBER AGENT';
        let title5 = 'V. Trách nhiệm của khách hàng';
        let title6 = 'VI. Quy định chung';
        let titleChild1 = 'VI.1. Tài khoản';
        let titleChild2 = 'VI.2. Đăng tin';
        let titleChild3 = 'VI.3. Tin đăng bị từ chối';
        let content1 = `1. Công Ty Cổ Phần Reway Group, LandberAgent.com cam kết tuân thủ các qui định và các điều khoản trong Quy Định này.

2. LandberAgent không khuyến khích các hành vi sai trái. Mọi sự vi phạm Quy Định này đều sẽ phải chịu trách nhiệm trước Công Ty Cổ Phần Reway Group và pháp luật.

Mọi thông tin, liên lạc, trao đổi, xin gửi về:

Kênh thông tin tìm kiếm BĐS LandberAgent.com
Công Ty Cổ Phần Reway Group
Địa chỉ: Tòa nhà Handico, Đường Phạm Hùng, Mễ Trì, Nam Từ Liêm, Hà Nội.
Điện thoại: 096.100.46.91
Email: info@landber.com
3. Trước khi sử dụng dịch vụ của LandberAgent, bao gồm nhưng không giới hạn việc sử dụng các dịch vụ hay công cụ trên website, người dùng và khách hàng phải đồng ý với các điều khoản và điều kiện cụ thể được qui định tại trang web, và được dẫn chiếu ví dụ tại phần Quy Định này. Trong trường hợp người dùng có bất kỳ thắc mắc nào về những điều khoản và điều kiện này, vui lòng liên hệ trực tiếp với đôi ngũ dịch vụ và chăm sóc khách hàng của LandberAgent để được hướng dẫn cụ thể!`

        let content2 = `Quy Định này sẽ được làm cơ sở để xây dựng quy định hoạt động của Kênh thông tin bất động sản LandberAgent và sẽ được áp dụng đối với tất cả các đối tượng là cá nhân, tổ chức, doanh nghiệp sử dụng dịch vụ trên LandberAgent.com và ứng dụng LandberAgent.`

        let content3 = `1. LandberAgent cam kết xử lý lỗi kỹ thuật, lỗi đường truyền phát sinh trên app LandberAgent và trang web LandberAgent.com trong thời hạn 72 giờ kể từ thời điểm nhận được thông tin phản hồi của khách hàng.

2. Khi phát sinh lỗi kỹ thuật, đội ngũ kỹ thuật sẽ tự đánh giá nguyên nhân để xử lý nội bộ trong vòng 24 giờ kể từ thời điểm phát sinh.

3. Trong trường hợp lỗi kỹ thuật có liên quan đến đường truyền, hay các hoạt động hỗ trợ khác từ bên thứ ba, đội ngũ kỹ thuật sẽ phối kết hợp với các đơn vị liên quan đó để cùng xem xét giải quyết vấn đề, đảm bảo lỗi kỹ thuật sẽ được khắc phục nhanh nhất trong thời hạn 72 giờ kể từ thời điểm khách hàng phản hồi.

4. Trong trường hợp, lỗi kỹ thuật không thể khắc phục, hoặc kéo dài thời gian xử lý, Ban quản trị LandberAgent sẽ thông báo về việc tạm thời ngừng cung cấp dịch vụ bị ảnh hưởng bởi lỗi kỹ thuật đó, và thông tin rõ thời gian dự kiến khắc phục.

5. Tuy nhiên, LandberAgent sẽ không chịu trách nhiệm giải quyết trong trường hợp các lỗi khác phát sinh không do hệ thống phần mềm của LandberAgent gây ra.`

        let content4 = `1. LandberAgent tiếp nhận khiếu nại tranh chấp của khách hàng thông qua hình thức email, gọi điện đến số hotline hoặc trực tiếp tại văn phòng LandberAgent

2. Việc giải quyết tranh chấp sẽ được LandberAgent tiến hành kể từ khi tiếp nhận các bằng chứng đối chấp của các bên. Việc tranh chấp sẽ được giải quyết trên cơ sở thương lượng giữa các bên, hòa giải, trọng tài hoặc tòa án theo các thủ tục, quy định hiện hành về giải quyết tranh chấp. Cụ thể như sau:

3. LandberAgent có trách nhiệm tạm ngưng đăng tin đang có tranh chấp giữa bên bán và bên mua. Bên bán và bên mua, đối tác có trách nhiệm cung cấp các tài liệu, thông tin bổ sung, để xác thực, chứng minh cho yêu cầu, hoặc chứng minh tính xác thực của thông tin mình khiếu nại. Thành viên, Khách hàng tự chịu trách nhiệm các vấn đề phát sinh do khách hàng cung cấp thông tin sai lệch, nhầm lẫn. LandberAgent có trách nhiệm tiếp thu, xử lý thông tin và yêu cầu các khoản chi phí phát sinh ( nếu có) trong quá trình giải quyết.`

        let content5 = `1. Khách hàng và thành viên có hành vi vi phạm phải bồi thường, và bồi hoàn cho LandberAgent toàn bộ các tổn thất, chi phí (bao gồm chi phí luật sư và tòa án, nếu có) mà LandberAgent có thể đã phải gánh chịu do có hậu quả, tranh chấp phát sinh từ bất kỳ vi phạm pháp luật, hay vi phạm sở hữu trí tuệ, vi phạm bản quyền nào được hình thành do hành vi, lỗi của khách hàng, thành viên sử dụng đó.

2. Nếu xảy ra bất kỳ khiếu nại, tranh chấp nào giữa khách hàng, hoặc thành viên của LandberAgent và người có chủ quyền liên quan đến nội dung đã đăng tải trên LandberAgent, thì khách hàng, hoặc thành viên đó sẽ phải chủ động giải quyết, dàn xếp với người có chủ quyền liên quan đó, và tự chịu trách nhiệm trong việc giải quyết khiếu nại, và phải chịu trách nhiệm chi trả cho bất kỳ thiệt hại phát sinh do bản quyền, thương hiệu, và hành vi xâm phạm sở hữu trí tuệ, để đảm bảo hoạt động kinh doanh của LandberAgent không bị ảnh hưởng.`

        let contentChild1 = `1. Không đăng kí và sử dụng các tài khoản giả mạo, sử dụng thông tin sai sự thật, lừa đảo…; Nick ảo bắt chước thành viên khác, người nổi tiếng,....

2. Không được xâm phạm đời tư, thóa mạ, văng tục hay sử dụng những từ ngữ thiếu văn hóa đối với thành viên khác.

3. Không lơi dụng website để tuyên truyền, kích động, lôi kéo thành viên khác tham gia các hội nhóm phản động, những hội nhóm có mục đích xấu, không lành mạnh.

4. Khi Thành viên đồng ý đăng kí các dịch vụ hoặc tính năng liên quan, Thành viên phải cung cấp thông tin xác thực về bản thân và phải cập nhật nếu có bất kỳ thay đổi nào. Mỗi cá nhân sử dụng dịch vụ của LandberAgent phải có trách nhiệm giữ bí mật mật khẩu và các thông tin định danh tài khoản. Chủ tài khoản phải hoàn toàn chịu trách nhiệm cho mọi hoạt động được thực hiện dưới tên tài khoản và mật khẩu đã đăng kí.

5. Thành viên phải thông báo cho LandberAgent biết khi tài khoản và mật khẩu bị truy cập trái phép. LandberAgent không chịu bất kỳ trách nhiệm nào, dù trực tiếp hay gián tiếp, đối với những thiệt hại hoặc mất mát gây ra do Thành viên không tuân thủ các quy định tại Quy Định này.

6 .Mọi tài khoản có dấu hiệu vi phạm các quy định trên đều bị khóa mà không báo trước!`

        let contentChild2 = `1. Tin đăng rõ ràng, không sai chính tả, sử dụng ngôn ngữ phổ thông, hạn chế dùng ngôn ngữ vùng miền, nghiêm cấm viết tắt, teencode, từ vô nghĩa, các từ ngữ nhạy cảm, thiếu văn hóa, vi phạm thuần phong mĩ tục, các kí tự đặc biệt, không cần thiết trong tin đăng.

2. Nghiêm cấm đăng nội dung sai sự thật, nội dung ảo, sai khác với thông tin thật của Bất Động Sản.

3. Nghiêm cấm đăng tin có nội dung đồi trụy, tôn giáo, chính trị, phân biệt cùng miền,các thông tin vi phạm pháp luật, thuần phong, mỹ tục nói chung,....

4. Chỉ đăng tin mua/bán/cho thuê Bất Động Sản. Ngoài ra các thông tin mua bán hay quảng cáo các sản phẩm, dịch vụ khác đều không được chấp nhận!( Không thể hiện bất kì giao dịch Bất Động Sản nào).

5. Tin đăng cần chứa đầy đủ các thông tin cần thiết: địa chỉ, giá, diện tích, thông tin liên hệ của người bán., các trường thông tin khi đăng tin cần được điền đầy đủ và chi tiết nhất có thể. Nghiêm cấm các hành vi đăng tin mập mờ, không rõ ràng khiến khách hàng hiểu lầm.

6. Nếu thông tin thuộc dự án, có chủ đầu tư thì cần ghi rõ tên dự án và chủ đầu tư.

7. Khi Bất Động Sản đã được bán/cho thuê thành công, Tin đăng về Bất Động Sản đó cần được xóa tránh mất thời gian cho khách hàng.

8. Không gộp nhiều bất động sản trong một tin đăng.

9. Tin đăng phải chính xác, đặc biệt là về phân loại bất động sản, kiểu bất động sản, loại giao dịch, vị trí và giá BĐS.Hình ảnh phải liên quan đến BĐS đang đăng.

10. Khách hàng và thành viên sử dụng LandberAgent phải hoàn toàn chịu trách nhiệm pháp lý về tất cả các nội dung thông tin và hình ảnh, video clip được đăng trên LandberAgent. LandberAgent hoàn toàn không chịu trách nhiệm về những vi phạm pháp luật của nội dung tin đăng, hay các vi phạm về quyền tác giả, quyền sở hữu trí tuệ liên quan đến nội dung, hình ảnh được đăng tải trên LandberAgent.`

        let contentChild3 = `1. Tin đăng có hình ảnh phản cảm, hình ảnh sai khác hoặc không không đúng với nội dung (Không phải hình ảnh về BĐS đang được bán/cho thuê).

2. Nội dung không dấu, không rõ ràng, chứa đường dẫn đến những trang web khác.

3. Tin đăng sai vị trí

4. Tin đăng để giá ảo, tin đăng bị sai giá.

5. Tin đăng bị sai tên dự án

6. Tên liên hệ, số điện thoại là ảo, không có thật

7. Tin đăng để sai địa chỉ.

8. Tin đăng bị trùng, cùng nội dung

9. Tin đăng post sai mục bán - mua - cho thuê (Tin bán đăng trong mục cho thuê, tin bán đăng trong mục tin cần mua/thuê,...)`


        return(
            <ScrollView style={styles.viewBodyDieuKhoan}
                        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 8 }}
            >
                <Text style={[styles.textNameFriend, {marginTop: 24}]}>{title1}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{content1}</Text>

                <Text style={[styles.textNameFriend, {marginTop: 24}]}>{title2}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{content2}</Text>

                <Text style={[styles.textNameFriend, {marginTop: 24}]}>{title3}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{content3}</Text>

                <Text style={[styles.textNameFriend, {marginTop: 24}]}>{title4}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{content4}</Text>

                <Text style={[styles.textNameFriend, {marginTop: 24}]}>{title5}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{content5}</Text>

                <Text style={[styles.textNameFriend, {marginTop: 24}]}>{title6}</Text>

                <Text style={[styles.textNameFriend, {marginTop: 22, fontSize: 15}]}>{titleChild1}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{contentChild1}</Text>
                <Text style={[styles.textNameFriend, {marginTop: 22, fontSize: 15}]}>{titleChild2}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{contentChild2}</Text>
                <Text style={[styles.textNameFriend, {marginTop: 22, fontSize: 15}]}>{titleChild3}</Text>
                <Text style={[styles.textContent, {marginTop: 20}]}>{contentChild3}</Text>
            </ScrollView>
        )
    }

    _onPressClose() {
        Actions.pop()
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewGroupChatHeader: {
        height: 64,
        width: width,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewCloseLeft: {
        width: 40,
        height: 64,
        justifyContent: 'center',
        paddingLeft: 16,
        paddingTop: gui.marginTopAgent
    },
    viewCloseIcon: {
        width: 40,
        height: 64,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16,
        paddingTop: gui.marginTopAgent
    },
    headerText: {
        width: width - 80,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    textNameFriend: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.textPostAds,
        fontSize: 17
    },
    viewBodyDieuKhoan: {
        flex: 1
    },
    textContent: {
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.textPostAds,
        fontSize: 15
    }
});

export default DieuKhoanAgent;
