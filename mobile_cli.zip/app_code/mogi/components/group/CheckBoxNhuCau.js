import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

export default class CheckBoxNhuCau extends Component {
    render() {
        let selected = this.props.selected;
        let iconName =  selected ? 'check-box' : 'check-box-outline-blank';
        let iconColor = selected ? gui.mainColor : 'rgba(204,204,204,1)';

        return (
            <TouchableOpacity onPress={() => this.props.onPress()} style={[styles.viewCheckFriends, this.props.mainProps]}>
                <MaterialIcons name={iconName} size={this.props.size} color={iconColor} />
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    viewCheckFriends: {
        height: 48,
        width: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
});