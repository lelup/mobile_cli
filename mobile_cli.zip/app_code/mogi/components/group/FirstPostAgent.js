import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    StyleSheet,
    TouchableOpacity,
    TouchableHighlight,
    ListView,
    ScrollView,
    RefreshControl,
    Alert
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import { Actions } from 'react-native-router-flux';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import OfflineBar from '../line/OfflineBar';
import gui from '../../lib/gui';
import RelandIcon from '../../components/RelandIcon';
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();
import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

const actions = [
    globalActions,
    registerActions,
    searchActions,
    adsMgmtActions,
    postAdsActions,
    needToBuyActions,
    adsMgmtActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class FirstPostAgent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false
        }
    }

    render() {
        let firstPost = 'Đăng bài đầu tiên';
        let textIntroduce = 'Chỉ mất chưa đến 5 phút,' +
            ' bạn có thể đăng được một bài đăng bán/cho thuê lên Landber,' +
            ' và hơn hết là hoàn toàn miễn phí.';
        return (
            <View style={styles.viewWelcomePost}>
                <OfflineBar />
                {this._renderBackButton()}
                <Text style={styles.textFirtPost}>{firstPost}</Text>
                <Text style={styles.textIntroGuide}>{textIntroduce}</Text>
                <TouchableOpacity onPress={this._onPressAgentPost.bind(this)}
                                  style={{marginTop: 70}}
                >
                    <MaterialCommunityIcons
                        name="plus-circle-outline"
                        color={gui.mainTextColor}
                        size={40}
                    />
                </TouchableOpacity>
            </View>
        );
    }

    _renderBackButton() {
        return (
            <TouchableOpacity style={styles.viewBackIcon}
                              onPress={this._onBackButton.bind(this)}>
                <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor} />
            </TouchableOpacity>
        );
    }

    _onBackButton() {
        Actions.pop();
    }

    _onPressAgentPost() {
       this.props.onAgentPost();
    }

}
const styles = StyleSheet.create({
    viewWelcomePost: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 40,
        paddingRight: 40
    },
    textFirtPost: {
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        fontSize: 20
    },
    textIntroGuide: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.colorMainBlur,
        marginTop: 12,
        textAlign: 'center'
    },
    viewBackIcon: {
        position: 'absolute',
        top: 20,
        left: 16,
        right: 100,
        bottom: 100,
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(FirstPostAgent);