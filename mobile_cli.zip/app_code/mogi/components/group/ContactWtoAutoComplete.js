'use strict';

import  React, {Component} from 'react';

import {
    StyleSheet, StatusBar
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import gui from "../../lib/gui";
import log from "../../lib/logUtil";

import GooglePlacesAutocomplete5 from './GooglePlacesAutocomplete5';

class ContactWtoAutoComplete extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        StatusBar.setBarStyle('dark-content');
    }

    _onPress(data) {
        log.enter("===========> newLoginAutoComplete._onPress", data);
        this.props.onSuggestionBuyPressed(data);        
        Actions.pop();

    }

    _updateBarColor() {
        // if (this.props.owner != 'home') {
        //     StatusBar.setBarStyle('light-content');
        // }
        StatusBar.setBarStyle('default');
    }

    _onCancelPress() {
        Actions.pop();
        this._updateBarColor();
    }

    render() {
        StatusBar.setBarStyle('light-content');
        let predefinedPlaces = [
        ];

        // let placeHolder = 'Nhập tên thành phố';

        return (

            <GooglePlacesAutocomplete5
                placeholder={this.props.placeHolder}
                minLength={2} // minimum length of text to search
                autoFocus={true}
                fetchDetails={false}
                onPress={this._onPress.bind(this)}
                onCancelPress={this._onCancelPress.bind(this)}
                getDefaultValue={() => {
                    return ''; // text input default value
                }}
                textInputProps={{
                    autoCorrect: false
                }}
                styles={{
                    description: {
                        //fontWeight: 'bold',
                        fontFamily : gui.fontFamily,
                        fontSize: 15,
                        marginLeft:10,
                        marginRight: 10,
                        color: '#3a3a3c'
                    },
                    predefinedPlacesDescription: {
                        color: '#1faadb'
                    },
                    container: {
                        paddingTop: 0,
                        backgroundColor: 'white'
                    },
                    row : {
                        height: 44
                    },
                    separator:{
                        backgroundColor: "#E9E9E9",
                        marginLeft: 0,
                        marginRight: 0
                    }
                }}

                currentLocation={false} // Will add a 'Vị trí Hiện tại' button at the top of the predefined places list
                predefinedPlacesAlwaysVisible={false}
                predefinedPlaces = {predefinedPlaces}
                enablePoweredByContainer={false}
                category={this.props.category}
            />
        );
    }
}

export default ContactWtoAutoComplete;