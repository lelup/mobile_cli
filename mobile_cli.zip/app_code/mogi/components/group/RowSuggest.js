import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity
} from 'react-native'

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';

import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();

class RowSuggest extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        let data = this.props.data;        
        let joinStatus = data.joinStatus;
        let imgUrl = data.thumbnail || data.image;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageGroup) {
            imageGroup = defaultCover;
        }
        let nameSan = data.name || '';
        let nameChuSan = 'Chủ sàn: ' + `${data.fullNameChuSan ? data.fullNameChuSan : ''}`;
        let countMember = `${data.countMember ? data.countMember : ''}` + ' thành viên';
        let chiTietSan = data.chiTiet || '';
        let textThamGia = 'THAM GIA';
        return (
            <TouchableOpacity 
                onPress={() => this.props.onPressRow && this.props.onPressRow(data)}
                style={styles.rowSuggest}>
                <View style={styles.viewImage}>
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsCoverRelated}
                    />
                </View>
                <View style={styles.viewDetailRow}>
                    <View style={{width: width - 132, height: 'auto'}}>
                        <Text numberOfLines={1} style={[styles.textNameSan, {color: 'rgba(70,70,70,1)', fontWeight: '500'}]}>{nameSan}</Text>
                    </View>
                    <Text style={[styles.textNameSan, {color: gui.textShare, fontSize: 15, fontWeight: '500'}]}>{nameChuSan}</Text>
                    <Text style={[styles.textNameSan, {color: gui.textShare, fontSize: 13, fontWeight: '500'}]}>{countMember}</Text>

                    { chiTietSan && chiTietSan.length > 0 ?
                    (<Text style={[styles.textNameSan, {color: gui.textShare, fontSize: 13}]}>{chiTietSan}</Text>) : null}
                </View>
                { joinStatus!=1 && joinStatus!=2 ?
                    (<TouchableOpacity  
                        onPress={() => this.props.onRequestJoin && this.props.onRequestJoin(data)}
                        style={styles.touchAddThamGia}>
                    <Text style={styles.textThamGia}>{textThamGia}</Text>
                </TouchableOpacity>) : null
                }
            </TouchableOpacity>
        )
    }
    
}



const styles = StyleSheet.create({
    rowSuggest: {
        paddingVertical: 10,
        width: width,
        height: 'auto',
        flexDirection: 'row'
    },
    viewImage: {
        height: 32,
        width: 32,
        marginLeft: 8,
        marginRight: 8
    },
    adsCoverRelated: {
        height: 32,
        width: 32,
        borderRadius: 16
    },
    viewDetailRow: {
        width: width - 56,
        height: 'auto'
    },
    textNameSan: {
        color: gui.mainTextColor,
        fontSize: 15,
        fontFamily: gui.fontFamily
    },
    textThamGia: {
        fontSize: 13,
        fontWeight: '500',
        color: gui.mainAgentColor,
        fontFamily: gui.fontFamily
    },
    touchAddThamGia: {
        height: 22,
        width: 73,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: gui.mainAgentColor,
        borderRadius: 3,
        position: 'absolute',
        right: 10,
        top: 15,
        borderWidth: 1
    }
});

export default RowSuggest;