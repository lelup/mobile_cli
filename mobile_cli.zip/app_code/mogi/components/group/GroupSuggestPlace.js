import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    FlatList,
    RefreshControl,
    TouchableHighlight
} from 'react-native';

import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import { Actions } from 'react-native-router-flux';
import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import DanhMuc from '../../assets/DanhMuc';
import GiftedSpinner from "../GiftedSpinner";
import SearchInput from './SearchInputAgent';
import TruliaIcon from '../TruliaIcon';
var Contacts = require('react-native-contacts');

import AnimatedSprite from '../animatedSprite/AnimatedSprite';
import newContactButton from './NewContactButton';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';

import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';
let ds_listAlert = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

const minLength = 0;

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupSuggestPlace extends Component {
    constructor(props) {
        super(props);
        this.state = {
            laoding: false,
            listKhuVuc: props.listKhuVuc,
            focused: false,
            text: '',

            toggleState: false,
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.groupContact.selectedContactTab !== nextProps.groupContact.selectedContactTab) {
            this.setState({ phanLoai: nextProps.groupContact.selectedContactTab });
        }
        if (this.props.groupContact.contactList !== nextProps.groupContact.contactList) {
            this.setState({ contactList: nextProps.groupContact.contactList });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                <FullLine style={{ marginTop: 4 }} />
                <View style={{ flex: 1 }}>
                    {this._renderBodyGroupMgmt()}
                </View>


                {this._renderLoadingView()}
            </View>
        );
    }



    _renderHeader() {

        let searchInputWidth = width - 32;
        let headerText = this.props.dataType == 'T' ? 'Danh sách khu vực' : 'Danh sách dự án'
        let placeHolderText = this.props.dataType == 'T' ? 'Tìm kiếm khu vực' : 'Tìm kiếm dự án'
        return (
            <View style={styles.headerView}>

                <View style={styles.subHeader2}>

                    <TouchableOpacity onPress={this._onBackButton.bind(this)}
                        style={[styles.viewSortAlphabet, {}]   }
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={'rgba(56,151,241,1)'} />
                    </TouchableOpacity>

                    <View style={[styles.viewSortAlphabet, { width: width - 84 }]}>
                        <Text style={styles.headerText}>{headerText}</Text>
                    </View>
                </View>

                <View style={[styles.viewTextInput, { marginTop: 4, marginLeft: 16, width: searchInputWidth, height: 36 }]}>
                    
                    <SearchInput ref="searchInput"
                        owner='Contacts'
                        placeholder={placeHolderText}
                        placeholderTextColor={gui.arrowColor}
                        textValue={this.state.text}
                        onChangeText={this._onChangeText.bind(this)}
                        onFocus={this._onFocus.bind(this)}
                        showCloseButton={this.state.focused && this.state.text != ''}
                        editable={true}
                        searchContainer={styles.searchContainer}
                    />

                </View>
            </View>
        );

    }

    onPressChat() {
        Actions.GroupInbox();
    }



    _renderSeparator() {
        return (
            <View style={styles.separatorLine}></View>
        )
    }

    _onFocus() {
        !this.state.focused && this.setState({ focused: true });
    }

    _onChangeText(text) {

        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            text: text
        });
    }

    _request(text) {
        if (text && text.length > minLength) {
            let filteredList = [];
            this.props.listKhuVuc.forEach((e) => {
                if (this.props.dataType == 'T') {
                    if (utils.locDauV2(e.tinh).indexOf(utils.locDauV2(text)) > -1)
                        filteredList.push(e)
                } else {
                    if (utils.locDauV2(e.duAn).indexOf(utils.locDauV2(text)) > -1)
                        filteredList.push(e)
                }
            })
            this.setState({ 'listKhuVuc': filteredList })
        } else {
            this.setState({ 'listKhuVuc': this.props.listKhuVuc })
        }
    }


    _onBackButton() {
        // Actions.pop();
        // let userInfo = { deviceID: this.props.global.currentUser.deviceID, userID: this.props.global.currentUser.userID };
        Actions.pop();
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _renderBodyGroupMgmt() {
        return (
            <View style={styles.viewBody}>
                {this._renderListView()}
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState });
    }



    _renderListView() {
        let viewSanThamGia = [styles.viewSanThamGia, { height: height - 106 - 4 }];
        return (
            <View style={viewSanThamGia}>
                {this._renderListAll()}
            </View>
        );
    }

    _renderListAll() {
        let listKhuVuc = this.state.listKhuVuc;
        let userID = this.props.global.currentUser.userID;
        return this._renderContactList(listKhuVuc);
    }


    _renderContactList(listKhuVuc) {
        //sort by alphabet
        listKhuVuc = this.props.dataType == 'T' ? listKhuVuc.sort(utils.dynamicSortASC('tinh')) : listKhuVuc.sort(utils.dynamicSortASC('duAn'))

        return (
            <View style={{height: height - 110, width: width}}>
                <FlatList
                    data={listKhuVuc}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(dataToRender) => this._renderRowKhuVuc(dataToRender.item)}
                    removeClippedSubviews={false}
                    initialListSize={25}
                    enableEmptySections={true}
                    showsHorizontalScrollIndicator={false}
                    showsVerticalScrollIndicator={false}
                    style={styles.viewBodyAlert}
                />
            </View>

        )
    }



    _onRefresh() { }


    _renderRowKhuVuc(value, isFirstRow, isLastRow) {
        let data = value;
        if (isFirstRow) {
            return data;
        }

        return (
            <View style={styles.viewRowContact}>
                <TouchableOpacity onPress={this._onRowPress.bind(this, data)}
                    underlayColor="rgba(30,30,30,0.8)"
                    style={styles.viewRowChild}
                >
                    <View style={styles.viewToDoRow}>
                        <View style={styles.viewChildContact}>
                            <Text style={styles.toDoContentText}>
                                {data.type == 'T' ? data.tinh : data.duAn}
                            </Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>

        );
    }

    _onRowPress(data) {
        this.props.onPressSuggestGroup && this.props.onPressSuggestGroup(data)
    }

    _renderLoadingView() {
        if (this.props.group.loadingContact) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderContent: {
        height: 72,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 19,
        paddingRight: 21
    },
    viewIconSearch: {
        height: 72,
        width: 18,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewInputSearch: {
        height: 72,
        width: width - 78,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextInput: {
        width: width - 70,
        height: 64
    },
    
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width - 32,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 20
    },
    viewBody: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewTabSelect: {
        height: 39,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row',
        marginTop: 23
    },
    viewSanThamGia: {
        backgroundColor: '#fff',
        height: height - 204,
        width: width,
        marginLeft: 8,
        // marginTop: 3,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewContent: {
        marginTop: 15,
        width: width - 30,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        height: 80,
        width: width - 208,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 100,
        height: 82,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 16
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 198,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    viewListContainer: {
        paddingBottom: 30
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        // width: width - 28,
        // marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center',
        // marginBottom: 50
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewPlusSearch: {
        height: 72,
        width: 20,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    toDoView: {
        width: width,
        height: height - 204,//'auto',
        justifyContent: 'center',
        alignItems: 'center'
    },
    toDoTitle: {
        width: width,
        height: 48,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    toDoContent: {
        width: width,
        height: height - 184,//'auto',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    toDoTitleText: {
        width: (width - 32) / 2,
        textAlign: 'left',
        marginLeft: 16,
        marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 20,
        fontWeight: '600',
        backgroundColor: 'transparent',
        color: '#526173'
    },
    themCongViecText: {
        // width: width/2,
        textAlign: 'right',
        marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '400',
        // backgroundColor: 'transparent',
        color: gui.mainColor
    },
    toDoContentText: {
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#526173'
    },
    toDoDateText: {
        width: 90,
        textAlign: 'right',
        marginRight: 16,
        // marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight: '400',
        backgroundColor: 'transparent',
        color: '#526173'
    },
    viewToDoRow: {
        backgroundColor: '#FFFFFF',
        width: width,
        height: 44,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotView: {
        // marginRight: 8,
        // marginTop: 6,
        width: 32,
        borderRadius: 16,
        height: 32,
        marginLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    headerView: {
        backgroundColor: '#fff',
        height: 106,
        width: width,
        //borderBottomWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)'
    },
    subHeader: {
        backgroundColor: 'transparent',
        marginTop: 40,
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 24,
        flexDirection: 'row'
    },
    subHeader2: {
        backgroundColor: 'transparent',
        width: width,
        height: 36,
        flexDirection: 'row'
    },
    searchContainer: {
        marginTop: gui.marginTopAgent + 6,
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0
    },
    tabHeader: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        // marginTop: 17,
        // marginLeft: 16,
        width: width,
        height: 32,
        paddingTop: 3,
        paddingBottom: 5,
        marginTop: 6
    },
    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: 'rgba(35,35,35,1)',
        // marginLeft: 8
    },
    tabbar: {
        flexDirection: 'row',
        paddingLeft: 20,
        paddingRight: 20,
        borderColor: '#dfdfdf',
        borderBottomWidth: 0,
        paddingTop: 17,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewBackIcon: {
        height: 25,
        width: 25,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    adsCover: {
        width: 32,
        height: 32,
        marginLeft: 0,
        borderRadius: 16
    },
    pageHeaderWrapper: {
        position: 'absolute',
        // left: 50,
        right: 6,
        top: 0,
        // height: 64
    },
    separatorLine: {
        borderLeftWidth: 0.5,
        width: 1,
        height: 40,
        marginTop: 7,
        borderColor: "#99526173",
        opacity: 0.6
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    textSapxep: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewSortAlphabet: {           
        height: 64,
        width: 42,
        paddingTop: gui.marginTopAgent + 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    touchableSort: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    textSort: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        // borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewEachButtonTab: {
        paddingHorizontal: 12,
        paddingVertical: 9,
        borderColor: 'rgba(37,37,37,0.3)',
        borderWidth: 1,
        borderRadius: 4,
        marginLeft: 8,
        marginTop: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    selectedButtonTab: {
        backgroundColor: gui.mainColor,
        borderWidth: 0,
    },
    selectedButtonText: {
        color: '#fff',
        fontWeight: '600'
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: 'rgba(37,37,37,0.7)',
        textAlign: 'center'
    },
    viewProgress: {
        width: width,
        height: 2,
        backgroundColor: 'skyblue',
        marginTop: 3
    },
    searchButtonText2: {
        width: width,
        justifyContent: 'flex-end',
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    listView: {
        paddingTop: 0,
        backgroundColor: 'white',
        borderColor: '#e6e6e6',
        borderBottomWidth: 0,
    },
    viewBodyAlert: {
        flex: 1,
        flexDirection: 'column',
    },
    rowBack: {
        alignItems: 'flex-end',
        backgroundColor: '#fff',
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingLeft: 0,
    },
    viewDeleteInbox: {
        right: 0,
        width: 65,
        backgroundColor: '#f43838',
        height: 66,
        alignItems: 'center',
        justifyContent: 'center'
    },
    saveText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: "white",
        textAlign: 'center',
        fontWeight: '500'
    },
    viewRowContact: {
        backgroundColor: '#fff',
        flexDirection: 'column',
        overflow: 'hidden'
    },
    viewRowChild: {
        width: width,
        height: 45,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderColor: '#dcdcdc'
    },
    viewChildContact: {
        height: 44,
        justifyContent: 'center',
        width: width - 64,
        paddingLeft: 8
    },
    textPhoneTop: {
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    textLevel: {
        fontFamily: gui.fontFamily,
        color: 'rgba(57,181,74,1)',
        fontSize: 12,
        marginLeft: 8
    },
    pagingTitle: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'lightgray'
    },
    orderLabel: {
        fontSize: 13,
        backgroundColor: 'transparent',
        color: 'darkgray',
        marginRight: 5
    },
    viewIconProfile: {
        height: 30,
        width: 46,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginLeft: 12,
        marginTop: 27
    },
    numberOfMessage2: {
        height: 16,
        width: 16,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 0,
        // left: 0,
        right: 15,//12
        backgroundColor: '#ff0000'
    },
    numberInbox: {
        fontSize: 8,
        color: '#fff',
        backgroundColor: 'transparent'
    },
    viewNewContact: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        width: 56,
        height: 56,
        borderRadius: 28,
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.15,
        shadowRadius: 2
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupSuggestPlace);