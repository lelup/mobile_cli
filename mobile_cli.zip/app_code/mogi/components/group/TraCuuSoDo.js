import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    Switch,
    StatusBar,
    KeyboardAvoidingView,
    Alert,    
    Linking,
    TouchableWithoutFeedback,
    Keyboard
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesomeSolid from '../font/FontAwesomeSolid'
import { Actions } from 'react-native-router-flux';
import Modal from 'react-native-modalbox';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import GiftedSpinner from "../../components/GiftedSpinner";
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import Camera from 'react-native-camera';
import OfflineBar from '../line/OfflineBar';
import ImagePreview from '../ImagePreview';
import CheckBox from './CheckBox';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import FloatInput from '../loginGroup/FloatInput';
let { width, height } = utils.getDimensions();
import Toast, { DURATION } from '../toast/Toast';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';

const Permissions = require('react-native-permissions');
import FontAwesomeLight from '../font/FontAwesomeLight';
import dismissKeyboard from 'react-native-dismiss-keyboard';

import * as globalActions from '../../reducers/global/globalActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as authActions from '../../reducers/auth/authActions';

var errorMessage = '';

const actions = [
    globalActions,
    registerActions,
    postAdsActions,
    authActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class TraCuuSoDo extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        this.state = {
            verifyLoading: false,
            validateIntoUser: false,
            soSeri: '',
            soCMT: '',
            name: '',
            email: '',
            phoneNumber: '',
            isOpenModalTraCuu: false,
            isAllowRule: false,
            modalImage: false
        }
    }

    render() {
        let introTraCuu = 'Sau khi nhận được các thông tin này, LandberAgent sẽ gửi đến các phòng công chứng liên kết để kiểm tra.\n'
            + 'Trong vòng 1 ngày làm việc, bạn sẽ nhận được kết quả gửi qua email.';
        let textDieuKhoan = ` điều khoản `;
        return(
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                      style={{flex: 1}}
            >
                <View style={styles.container}>
                    <OfflineBar />
                    {this._renderHeader()}
                    <FullLine />
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        ref='scroll'
                    >
                        <View style={styles.scrollView}>
                            <TouchableOpacity style={styles.viewDiaChinhTraCuu}
                                onPress={this._onDiaChinhPress.bind(this)}
                            >
                                <View style={styles.viewTextLeft}>
                                    <Text style={[styles.textNameFriend, { fontWeight: 'normal' }]}>Địa chính của BĐS</Text>
                                </View>
                                <View style={styles.viewRightDiaChinh}
                                >
                                    <Text style={[styles.textNameFriend, { fontWeight: 'normal' }]}>Hà Nội</Text>
                                    <View style={styles.viewIcon}>
                                        <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                            mainProps={{ marginTop: 2, marginLeft: 0 }}
                                            noAction={true}
                                        >
                                        </TruliaIcon>
                                    </View>
                                </View>
                            </TouchableOpacity>
                            <View style={[styles.viewEmail, { marginTop: 8 }]}>
                                <FloatInput
                                    placeholder={"Số seri sổ đỏ"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => this.setState({ soSeri: text })}
                                    value={this.state.soSeri}
                                    autoCapitalize='none'
                                    onSubmitEditing={() => { this.refs.txtCMT.focus() }}
                                    // keyboardType={'numeric'}
                                    returnKeyType='done'
                                />
                            </View>
                            <View style={[styles.viewEmail, { marginTop: 8 }]}>
                                <FloatInput
                                    ref="txtCMT"
                                    placeholder={"Số CMND"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => this.setState({ soCMT: text })}
                                    value={this.state.soCMT}
                                    autoCapitalize='none'
                                    onSubmitEditing={() => { this.refs.txtHoTen.focus() }}
                                    returnKeyType='done'
                                    keyboardType={'numeric'}
                                />
                            </View>
                            <View style={[styles.viewEmail, { marginTop: 8 }]}>
                                <FloatInput
                                    ref="txtHoTen"
                                    placeholder={"Họ tên"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => this.setState({ name: text })}
                                    value={this.state.name}
                                    autoCapitalize='none'
                                    onSubmitEditing={() => { this.refs.txtEmail.focus() }}
                                    returnKeyType='done'
                                />
                            </View>
                            <View style={[styles.viewEmail, { marginTop: 8 }]}>
                                <FloatInput
                                    ref="txtEmail"
                                    placeholder={"Email"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => this.setState({ email: text })}
                                    value={this.state.email}
                                    autoCapitalize='none'
                                    onSubmitEditing={() => { this.refs.txtPhone.focus() }}
                                    returnKeyType='done'
                                />
                            </View>
                            <View style={[styles.viewEmail, { marginTop: 8 }]}>
                                <FloatInput
                                    ref="txtPhone"
                                    placeholder={"Số điện thoại"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => this.setState({ phoneNumber: (text) })}
                                    value={this.state.phoneNumber}
                                    autoCapitalize='none'
                                    onSubmitEditing={() => dismissKeyboard()}
                                    returnKeyType='done'
                                    keyboardType={'numeric'}
                                />
                            </View>

                            <View style={[styles.viewAllowRule, { marginTop: 20 }]}>
                                <CheckBox
                                    checkBoxStyle={{ height: 20 }}
                                    selected={this.state.isAllowRule}
                                    onPress={this.onPressAllow.bind(this)} />
                                <Text style={[styles.textBroker, { color: gui.textPostAds, marginLeft: 8 }]}>
                                    Xác nhận đồng ý với các
                                    <Text style={[styles.textBroker, { color: gui.mainColor }]}
                                        onPress={this._onPressDieuKhoan.bind(this)}
                                    > {textDieuKhoan}</Text>
                                    của Landber
                                </Text>
                            </View>
                            <View style={[styles.viewIntroBonus, { marginTop: 32 }]}>
                                <Text style={styles.textIntroBonus}>{introTraCuu}</Text>
                            </View>


                            <TouchableOpacity style={[styles.viewIntroBonus, {marginTop: 11}]}
                                              onPress={this.onPressKetQuaMau.bind(this)}
                            >
                                <Text style={[styles.textIntroBonus, {color: gui.mainColor}]}>Xem kết quả mẫu</Text>
                            </TouchableOpacity>

                            <View style={styles.viewTwoButton}>
                                {this.state.verifyLoading ?
                                    <View style={styles.viewCreateButton}>
                                        <GiftedSpinner color="white" />
                                    </View>
                                    :
                                    <TouchableOpacity style={styles.viewCreateButton}
                                                        onPress={this._onPressAcceptCode.bind(this)}>
                                        <Text style={styles.textFbStart}>GỬI THÔNG TIN TRA CỨU</Text>
                                    </TouchableOpacity>
                                }
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                    <KeyboardSpacer topSpacing={-40} />
                    <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={height / 3}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{ color: '#fff' }}
                    />
                    {this._renderModalTraCuuInfo()}
                    {this.state.modalImage ? <ImagePreview owner={'TraCuuSD'} closeModal={() => this.setState({ modalImage: false })} /> : null}
                </View>
            </TouchableWithoutFeedback>
        );
    }

    onPressKetQuaMau() {
        // let link = "https://landber.com/ket-qua-tra-cuu-so-do.pdf";
        // log.info('============> link', link);
        // Linking.canOpenURL(link).then(supported => {
        //     if (!supported) {
        //         log.info('Can\'t handle url: ' + link);
        //     } else {
        //         Linking.openURL(link);
        //     }
        // }).catch(err => log.error('An error occurred', link, err));
        this.setState({
            modalImage: true
        })
    }

    isValidInputData() {
        let errors = '';
        let { soSeri, soCMT, name, email, phoneNumber } = this.state;


        if (!soSeri || !soSeri.trim()) {
            errors += ' (số seri sổ đỏ)';
        }

        if (!soCMT || !soCMT.trim()) {
            errors += ' (số CMT)';
        }

        if (!name) {
            errors += ' (họ tên)';
        }

        if (!email) {
            errors += ' (email)';
        }

        if (!phoneNumber) {
            errors += ' (số điện thoại)';
        }

        if (errors != '') {
            errorMessage = 'Bạn chưa nhập' + errors + '!';
            return false;
        }

        if (email) {
            email = email.trim();
            if (email.indexOf("@") < 0 || !utils.validateEmail(email)) {
                errorMessage = "Địa chỉ email không đúng định dạng!";
                return false;
            }
        }
        if (phoneNumber) {
            phoneNumber = phoneNumber.trim();
            if (!utils.validatePhone(phoneNumber)) {
                errorMessage = "Số điện thoại không đúng định dạng!";
                return false;
            }
        }

        return true;
    }

    _onPressDieuKhoan() {
        Actions.DieuKhoanAgent();
    }

    onPressAllow() {
        this.setState({
            isAllowRule: !this.state.isAllowRule
        })
    }

    _onDiaChinhPress() {
        log.info('===========. _onDiaChinhPress');
    }

    _renderHeader() {
        return (
            <View style={styles.viewGroupChatHeader}>
                <TouchableOpacity style={styles.viewCloseLeft}
                    onPress={this._onPressClose.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.headerText}>
                    <Text numberOfLines={1} style={styles.textNameFriend}>Tra cứu sổ đỏ</Text>
                </View>
                <TouchableOpacity style={styles.viewCloseIcon}
                    onPress={this._onMoreInfoPress.bind(this)}
                >
                    <FontAwesomeLight name={'question-circle'}
                        size={19}
                        color={gui.mainColor}
                        noAction={true}
                        iconOnly={true} />
                </TouchableOpacity>
            </View>
        );

    }

    _renderModalTraCuuInfo() {
        return (
            <Modal isOpen={this.state.isOpenModalTraCuu}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
                animationDuration={200}
            >
                {this._renderTraCuuContent()}
            </Modal>
        )
    }

    _renderTraCuuContent() {
        let contextText = `Giúp bạn tra cứu:

Lịch sử mua bán, thế chấp của bất động sản bạn đang quan tâm

Người bán đã mua lâu chưa hay vừa mua rồi bán lại ngay?

Nhà đất có đang bị cấm giao dịch hay không?`;
        return (
            <View style={styles.viewTraCuuContent}>
                <Text style={[styles.textNameFriend, { marginTop: 5 }]}>Tra cứu sổ đỏ</Text>
                <Text style={styles.textNameContent}>{contextText}</Text>
                <TouchableOpacity
                    style={styles.touchCloseModal}
                    onPress={this._onContentModal.bind(this)}>
                    <Text style={[styles.textSignUp, { color: 'rgba(223,64,90,1)', marginTop: 36 }]}>Đóng</Text>
                </TouchableOpacity>
            </View>
        )
    }

    _onContentModal() {
        this.setState({
            isOpenModalTraCuu: false
        })
    }

    _onMoreInfoPress() {
        this.setState({
            isOpenModalTraCuu: true
        })
    }

    _onPressClose() {
        Actions.pop()
    }


    _onPressAcceptCode() {
        log.info('================> _onPressAcceptCode')
        if (this.state.isAllowRule == false) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn vui lòng xác nhận đồng ý với các điều khoản của Landber', DURATION.LENGTH_LONG);
            return;
        }
        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG);
            return;
        }
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        let { soSeri, soCMT, name, email, phoneNumber } = this.state;

        let dto = {
            codeTinh: 'HN',
            seri: soSeri,
            cmndNumber: soCMT,
            userID: this.props.global.currentUser.userID,
            fullName: name,
            email: email,
            phone: phoneNumber
        };

        this.props.actions.yeuCauTraCuuSoDo(dto, token)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                        }
                    }]);
                } else {
                    Keyboard.dismiss();
                    this.props.actions.validateXacMinhSoDo({ userID: userID }, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{
                                    text: 'Đóng', onPress: () => {
                                    }
                                }]);
                            } else {
                                Alert.alert('Thông báo', res.msg,
                                    [{ text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
                                    {
                                        text: 'Đồng ý', onPress: () => {
                                            let xacMinhSoDoDto = {
                                                userID: userID,
                                                codeTinh: 'HN',
                                                seri: soSeri,
                                                cmndNumber: soCMT,
                                                fullName: name,
                                                email: email,
                                                phone: phoneNumber
                                            }
                                            this.props.actions.xacMinhSoDo(xacMinhSoDoDto, token)
                                                .then(res => {
                                                    if (res.status != 0) {
                                                        Alert.alert("Thông báo", res.msg, [{
                                                            text: 'Đóng', onPress: () => {
                                                            }
                                                        }]);
                                                    } else {
                                                        Alert.alert("Thông báo", res.msg, [{
                                                            text: 'Đóng', onPress: () => {
                                                                Actions.pop();
                                                            }
                                                        }]);
                                                    }
                                                })
                                        }
                                    }
                                    ]);

                            }
                        });

                }
            });

    }

    sendVerifyCode() {
        this.setState({ verifyLoading: true });
        if (this.state.brokerValue) {
            this.props.actions.onRegisterFieldChange('broker', 'Y');
        } else {
            this.props.actions.onRegisterFieldChange('broker', 'N');
        }
        let username = this.props.register.username.toLowerCase().trim();
        let destinationType = username.indexOf("@") > -1 ? "email" : "số điện thoại";
        this.props.actions.requestVerifyCode({ username: username, verifyType: DanhMuc.VERIFY_TYPE.register })
            .then((res) => {
                if (res.success) {
                    this.setState({ verifyLoading: false });
                    let codeGuide = `Mã xác nhận gồm 5 chữ số vừa được gửi đến ${destinationType} của bạn.`;
                    Actions.VerifyCode({ codeGuide: codeGuide, doFinalAction: () => Actions.Home({ type: 'reset' }) });
                } else {
                    this.setState({ verifyLoading: false });
                    let codeSendError = 'Hệ thống gửi mã xác nhận không thành công. Xin vui lòng thực hiện lại sau 15 phút.';
                    this.refs.toastTop && this.refs.toastTop.show(codeSendError, DURATION.LENGTH_LONG);
                }
            });
    }




}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewGroupChatHeader: {
        height: 64,
        width: width,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewCloseLeft: {
        width: 40,
        height: 64,
        justifyContent: 'center',
        paddingLeft: 16,
        paddingTop: gui.marginTopAgent
    },
    viewCloseIcon: {
        width: 40,
        height: 64,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 16,
        paddingTop: gui.marginTopAgent
    },
    headerText: {
        width: width - 80,
        height: 64,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    textNameFriend: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.textPostAds,
        fontSize: 17
    },
    textNameContent: {
        fontFamily: gui.fontFamily,
        color: gui.textPostAds,
        fontWeight: 'normal',
        fontSize: 15,
        marginTop: 22,
        textAlign: 'center',
        alignSelf: 'center'
    },
    scrollView: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 22
    },
    textDangNhap: {
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 24
    },
    viewDiaChinhTraCuu: {
        height: 73,
        width: width,
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTextLeft: {
        width: width / 2,
        justifyContent: 'center',
        height: 73,
        paddingLeft: 16
    },
    viewRightDiaChinh: {
        width: width / 2,
        justifyContent: 'flex-end',
        alignItems: 'center',
        height: 73,
        paddingRight: 16,
        flexDirection: 'row'
    },
    viewEmail: {
        width: width,
        height: 48,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        marginTop: 41
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width,
        opacity: 0.8
    },
    floatInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        backgroundColor: 'rgba(82,97,115,1)',
        width: width - 32,
        height: 48
    },
    viewMoiGioiOption: {
        height: 121,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 32
    },
    viewSwitchBroker: {
        width: width - 32,
        height: 32,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderColor: 'rgba(82,97,115,0.1)',
    },
    viewTextDetail: {
        marginTop: 8,
        height: 60,
        width: width - 32,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textBroker: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 15,
    },
    textIntroBonus: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: 'rgba(178,178,178,1)',
        fontSize: 13,
        textAlign: 'left',
        alignSelf: 'flex-start'
    },
    viewTextBroker: {
        height: 32,
        width: width - 144,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    addTextBroker: {
        color: 'rgba(82,97,115,0.6)',
        textAlign: 'center',
        fontSize: 12
    },
    viewChooseBroker: {
        width: 112,
        height: 32,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-end'
    },
    viewYesBroker: {
        height: 32,
        width: 64,
        justifyContent: 'flex-start',
        alignItems: 'flex-end'
    },
    textYestBroker: {
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        color: '#78BC61',
        fontSize: 15
    },
    viewSwitchChange: {
        height: 32,
        width: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        marginBottom: 6
    },
    viewTwoButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 48,
        marginTop: 31
    },
    viewCreateButton: {
        width: width - 32,
        height: 48,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 24
    },
    textFbStart: {
        fontFamily: gui.fontFamily,
        color: '#fff',
        fontSize: 15,
        fontWeight: 'bold'
    },
    viewTopNewLogin: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        flexDirection: 'row'
    },
    textSignUp: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainAgentColor,
        fontSize: 15
    },
    viewBackButton: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    viewSignUpText: {
        width: width / 2,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    changeImage: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 8,
        flexDirection: 'row',
        width: width,
        height: 38
    },
    textImage: {
        fontSize: 13,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        marginLeft: 8
    },
    detailImage: {
        width: 40,
        height: 40,
        borderRadius: 20
    },
    viewIconIntro: {
        backgroundColor: 'rgba(82,97,115,0.07)',
        width: 36,
        height: 48,
        justifyContent: 'center'
    },
    viewIntroBonus: {
        width: width - 32,
        height: 'auto'
    },
    viewIcon: {
        height: 44,
        width: 22,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 'auto',
        width: width - 105,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewTraCuuContent: {
        backgroundColor: '#fff',
        borderRadius: 5,
        alignItems: 'center',
        paddingVertical: 12,
        paddingHorizontal: 15,
        width: width - 105
    },
    touchCloseModal: {
        paddingVertical: 3,
        paddingHorizontal: 5
    },
    viewAllowRule: {
        width: width - 32,
        height: 'auto',
        flexDirection: 'row',
        alignItems: 'center',
        marginRight: 16
    }

});

export default connect(mapStateToProps, mapDispatchToProps)(TraCuuSoDo);
