'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as historyActions from '../../reducers/history/historyActions';
import * as groupActions from '../../reducers/group/groupActions';

import CommonUtils from '../../lib/CommonUtils';

import {Map} from 'immutable';

import React, {Component} from 'react';

import { Text, View, Image, ScrollView,TouchableOpacity,
    StyleSheet, StatusBar, TouchableHighlight, Linking, Alert, ListView, Animated, ImageBackground} from 'react-native'

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
var ShareManager = require('react-native').NativeModules.ShareManager;

import {Actions} from 'react-native-router-flux';

import DanhMuc from '../../assets/DanhMuc';

import SearchResultDetailFooter from '../detail/SearchResultDetailFooter';

import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';
import utils from '../../lib/utils';

import CollapsiblePanel from '../CollapsiblePanel';
import SummaryText from '../SummaryText';
import OfflineBar from '../line/OfflineBar';
import TruliaIcon from '../TruliaIcon';

import GiftedSpinner from 'react-native-gifted-spinner';

import MHeartIcon from '../MHeartIcon';

import MEyeIcon from '../MEyeIcon';

import RelandIcon from '../RelandIcon';

import Icon from 'react-native-vector-icons/FontAwesome';

import Communications from '../detail/MCommunications';

import ImagePreview from '../ImagePreview';

import dbService from "../../lib/localDB";

import MChartView from '../MChartView';

import log from '../../lib/logUtil';

import HomeCollection from '../home/HomeCollection';

import LinearGradient from 'react-native-linear-gradient';

import FullLine from '../line/FullLine';

import MMessage from '../message/MMessage';

import MapView from 'react-native-maps';

import LocationMarker from '../marker/LocationMarker';

import ScalableText from 'react-native-text';

import cfg from "../../cfg";

var Analytics = require('react-native-firebase-analytics');

const noCoverUrl = cfg.noCoverUrl;

const actions = [
  globalActions,
  searchActions,
  chatActions,
  registerActions,
  historyActions,
  groupActions
];

function mapStateToProps(state) {
  return {
      ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
          .merge(...actions)
          .filter(value => typeof value === 'function')
          .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

var {width, height} = utils.getDimensions();
var mapWidth = width-44;
var mapHeight = (width-width%2)/2+3;

var imgHeight = height/2;

var url = '';

var text = '';

var linkAds = '';

const ds_postedGroup = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});

class GroupAdsDetail extends Component {
  constructor(props) {
    super(props);

    StatusBar.setBarStyle('light-content');

    this.state = {
      textMessage: '',
      msgType: '',
      msgBgColor: null,
      msgTextColor: null,
      'data' : null,
      loaded: false,
      modal: false,
      headerColor: 'transparent',
      headerButtonColor: 'white',
      sendButtonColor:'white',
      backButtonColor: 'white',
      heartBgColor: '#4A443F',
      isChatLoading: false,
      postedGroup: []
    }
  }
  fetchData() {
    if (this.props.source != 'local') {
      let deviceID = this.props.global.deviceInfo.deviceID || undefined;
      let userID = this.props.global.currentUser.userID || undefined;
      this.props.actions.getDetail(
          {'adsID' : this.props.adsID, 'userID': userID, 'deviceID': deviceID}
          , (data) => {
            this.refreshRowData(data.ads)
          }
          , (error) => {
              this.setState({loaded: true});
              this._updateMessageProcessing(error, 'rgba(250,73,22,0.7)', 'white');
          });
    }
    else {
      dbService.getAds(this.props.adsID, this.refreshRowData.bind(this));
    }
  }

  refreshRowData(ads) {
      // console.log('================> ads', ads);
      let streetViewUrl = '';
      if (ads.place.geo && !isNaN(ads.place.geo.lat) && !isNaN(ads.place.geo.lon)) {
          streetViewUrl = 'https://www.instantstreetview.com/s/'+ads.place.geo.lat+','+ads.place.geo.lon;
      }
    this.setState({
      'data' : ads,
      'streetViewUrl' : streetViewUrl,
      loaded: true
    });
      let groupID = ads && ads.groupID || [];
    this._getPostedGroup(groupID);
  }

  _getPostedGroup(groupIDs) {
      let userID = this.props.global.currentUser.userID;
      let postedGroup = this._getListGroup(this.props.group.searchResult.listRelatedGroup, userID, groupIDs);
      this.setState({postedGroup: postedGroup});
  }

    _getListGroup(data, userID, groupIDs) {
        let postedGroup = [];
        if (!groupIDs || groupIDs.length == 0
            || !data || data.length == 0) {
            return postedGroup;
        }
        let hashGroupID = {};
        groupIDs.forEach((one) => {
            hashGroupID[one] = true;
        });
        postedGroup = data.filter((one) => {
                return hashGroupID[one.groupID] && (one.createdBy == userID || one.joinStatus == 2)
            }) || [];
        return postedGroup;
    }

  _updateMessageProcessing(textMessage, bgColor, textColor) {
    this.setState({textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor});
    this._onMsgAnimationStart();
  }

  _onMsgAnimationStart() {
    this.setState({msgType: 'fadeInDown'});
    clearTimeout(this.msgTimer);
    this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 5000);
  }

  _renderMessageItem() {
    let textValue = this.state.textMessage;
    if (textValue == '' || this.state.msgType == '') {
      return null;
    }
    return (
        <MMessage mainStyle={{top: 0}}
                  hideStatus={this.state.msgType == 'fadeInDown'}
                  // barStyle="light-content"
                  animation={this.state.msgType}
                  duration={500}
                  onAnimationEnd={this._onAnimationEnd.bind(this)}
                  textValue={textValue}
                  bgColor={this.state.msgBgColor}
                  textColor={this.state.msgTextColor}/>
    );
  }

  _onAnimationEnd() {
    if (this.state.msgType === 'slideOutUp') {
      clearTimeout(this.msgTimer);
      this.msgTimer = setTimeout(() => {this.setState({textMessage: '', msgType: ''})}, 2000);
    }
  }

  componentWillMount() {
    //this.props.actions.loadHomeData();
    StatusBar.setBarStyle('light-content');
    setTimeout(() => this.fetchData(), 300);
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    let userID = this.props.global.currentUser.userID || undefined;
    Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
  }
  renderLoadingView() {
      //let imageUri = require('../assets/image/photo_detail_blank.jpg');
      let imageUriHome = {uri: this.props.imageDetail};
      // if (!imageUriHome) {
      //     imageUriHome = require('../assets/image/photo_detail_blank.jpg');
      // }
    return (
            <View style={detailStyles.viewLoaderContent}>
                <View style={detailStyles.viewLineLoader}></View>
                <View style={[detailStyles.viewLineLoader1, {marginTop: 15}]}></View>
                <View style={[detailStyles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[detailStyles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[detailStyles.viewLineLoader1, {width: width*3/4 -50}]}></View>

                <View style={[detailStyles.viewLineLoader, {marginTop : 30 }]}></View>
                <View style={[detailStyles.viewLineLoader1, {marginTop: 15}]}></View>
                <View style={[detailStyles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[detailStyles.viewLineLoader1, {width: width/5 }]}></View>
                <View style={[detailStyles.viewLineLoader1, {width: width*3/4 -50}]}></View>
            </View>
    )
  }

  componentDidMount() {
  }

  _renderHeaderBar() {
    let ads = this.state.data;
    // let isHiddenAds = utils.isHiddenAds(ads, this.props.global.currentUser);
    let showHiddenAdsButton =
        // !isHiddenAds &&
        ads && (this.props.owner == 'SearchMenu'
            || this.props.owner == 'SearchResultListExt' || this.props.owner == 'Home');
      let adsID = ads && ads.adsID;
      let isLiked = this.isLiked(adsID);
      let color = isLiked ? 'white' : 'white';
      let bgColor = isLiked ? '#E50064' : '#4A443F';
      let bgStyle = isLiked ? {} : {opacity: 0.55};

      let uploadingLikedAds = this.props.history.uploadingLikedAds.uploading;

      return (
        <View style={this.state.headerColor != 'transparent' ? detailStyles.headerContainer : {}}>
          <LinearGradient colors={['rgba(0, 0, 0, 0.9)', 'transparent']}
                          style={detailStyles.linearGradient}>
            <Text style={{height: 64}}></Text>
            <View style={[detailStyles.customPageHeader, {backgroundColor: this.state.headerColor}]}>
              {/*<TruliaIcon onPress={this._onBack.bind(this)}*/}
                          {/*name="arrow-left" color={this.state.backButtonColor}*/}
                          {/*mainProps={[detailStyles.backButton, {marginTop: 28, paddingLeft: 20}]} size={26} >*/}
              {/*</TruliaIcon>*/}
                <TouchableOpacity style={detailStyles.viewPlusPost}
                                  onPress={this._onBack.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={this.state.backButtonColor} />
                </TouchableOpacity>
              <View style={[detailStyles.shareMainView, {marginRight: 0, marginLeft: 0}]}>
                {/*showHiddenAdsButton ?
                  <View style={[detailStyles.shareButton, {marginTop: 26}]}>
                    <MEyeIcon onPress={this._onHideAds.bind(this)} color={this.state.headerButtonColor}
                              bgColor={this.state.heartBgColor} bgStyle={{opacity: 0.55}} size={35}
                              mainProps={{flexDirection: 'row'}} />
                  </View> : null
                */}
                {/*<RelandIcon onPress={this._onShare.bind(this)}
                            name="share-o" color={this.state.headerButtonColor}
                            iconProps={{style: [detailStyles.shareButton, {marginTop: 28}]}} size={28} >
                </RelandIcon>*/}
                <View style={[detailStyles.shareButton, {alignItems: 'flex-start', marginTop: 30, paddingLeft: 0, paddingRight: 10}]}>
                      {uploadingLikedAds ?
                          <View style={{marginLeft: 22}}>
                              <GiftedSpinner size="small" color="white"/>
                          </View>
                          :
                          <MHeartIcon onPress={this.onLike.bind(this, adsID)} color={color}
                                      bgColor={bgColor} bgStyle={bgStyle} size={22} />
                      }
                  </View>
                <RelandIcon onPress={this._onAdsAlertUs.bind(this)}
                            name="alert-f" color={this.state.sendButtonColor}
                            iconProps={{style: [detailStyles.shareButton, {paddingRight: 26, marginTop: 30}]}} size={25} >
                </RelandIcon>
              </View>
            </View>
          </LinearGradient>
        </View>
    );
  }
  _onHideAds() {
      if (this.props.global.loggedIn) {
          this._doHideAds();
      } else {
          Actions.NewLogin({doFinalAction: () => this._doHideAds()});
      }
  }
  _doHideAds() {
      let ads = this.state.data;
      let userID = this.props.global.currentUser.userID || undefined;
      Analytics.logEvent('HIDE_ADS', {userID: userID});
      Actions.HideAds({ads: ads, currentUserID: userID, doFinalAction: (dto, userDto) => this._doAfterHideAds(dto, userDto)});
  }
  _doAfterHideAds(dto, userDto) {
      if (this.props.owner == 'SearchMenu') {
          this.props.actions.updateHideAds(dto);
      }
      if (this.props.owner == 'SearchResultListExt' || this.props.owner == 'Home') {
          this.props.actions.updateHideAdsExt(dto);
      }
      // this.props.actions.updateHiddenAdsList(userDto);
      this._onBack();
  }
  _renderFooter(mobile, rowData) {
    if (!rowData) {
        return (
            <View />
        );
    }
    let isLiked = false;
    let userID = null;
    let deviceID = this.props.global.deviceInfo.deviceID;
    if (this.props.global.loggedIn) {
      let currentUser = this.props.global.currentUser;
      let adsLikes = currentUser && currentUser.adsLikes;
      userID = currentUser && currentUser.userID;
      isLiked = rowData && adsLikes && adsLikes.indexOf(rowData.adsID) > -1;
    }
    return (
        // <SearchResultDetailFooter mobile={mobile} onChat={() => this._onChat(rowData)} userID={userID} deviceID={deviceID}
        //                           isLiked={isLiked} ads={rowData} loggedIn={this.props.global.loggedIn}
        //                           likeAds={this.props.actions.likeAds}
        //                           unlikeAds={this.props.actions.unlikeAds}
        //                           updateMessageProcessing={this._updateMessageProcessing.bind(this)}
        //                           isChatLoading={this.state.isChatLoading}
        //                           isLikeAdsLoading={this.props.history.uploadingLikedAds.uploading} />
        <View style={detailStyles.viewContentButton}>
            <TouchableOpacity
                style={[detailStyles.buttonContact, {backgroundColor: 'rgba(49,207,100,1)', marginRight: 10}]}
                onPress={this._onPhoneCall.bind(this, mobile)}
            >
                <FontAwesomeLight name="phone" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                <Text style={[detailStyles.textCommon, {fontSize: 15, marginLeft: 5, color: '#fff'}]}>Gọi</Text>
            </TouchableOpacity>
            <TouchableOpacity style={detailStyles.buttonContact}
                              onPress={this._onChat.bind(this,rowData)}
            >
                <FontAwesomeLight name="comment-dots" size={20} color={'#fff'} noAction={true} iconOnly={true} />
                <Text style={[detailStyles.textCommon, {fontSize: 15, marginLeft: 5, color: '#fff'}]}>Chat</Text>
            </TouchableOpacity>
        </View>
    );
  }
  
  _renderImagePreviewModal(imageDataItems, mobile, rowData) {
    let isLiked = false;
    let userID = null;
    if (this.props.global.loggedIn) {
      let currentUser = this.props.global.currentUser;
      let adsLikes = currentUser && currentUser.adsLikes;
      userID = currentUser && currentUser.userID;
      isLiked = adsLikes && adsLikes.indexOf(rowData.adsID) > -1;
    }
    return (
        <ImagePreview images={imageDataItems} mobile={mobile} onChat={() => this._onChat(rowData)}
                      closeModal={() => this.setState({modal: false}) } isLiked={isLiked} ads={rowData} userID={userID}
                      loggedIn={this.props.global.loggedIn} likeAds={this.props.actions.likeAds}
                      unlikeAds={this.props.actions.unlikeAds}
                      isChatLoading={this.state.isChatLoading}
                      isLikeAdsLoading={this.props.search.uploadingLikedAds.uploading}
        />
    );
  }
  render() {
    let rowData = this.state.data;
      let imageUriHome = {uri: this.props.imageDetail};
      if (!imageUriHome) {
          imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
      }

      let _scrollView: ScrollView;
      let imagePreviewAction = this._onImagePreviewPressed.bind(this);
      let imageDataItems = [];
      let lienHe = {
          name : '',
          showName: true,
          email : '',
          showEmail: true,
          phone : '',
          showPhone: true
      };
    if(rowData) {
        if (rowData.lienHe){
            lienHe.name = rowData.lienHe.tenLienLac;
            lienHe.showName = rowData.lienHe.showTenLienLac;
            lienHe.email = rowData.lienHe.email;
            lienHe.showEmail = rowData.lienHe.showEmail;
            lienHe.phone = rowData.lienHe.phone;
            lienHe.showPhone = rowData.lienHe.showPhone;
        } else {
            if (rowData.dangBoi) {
                lienHe.name = rowData.dangBoi.name;
                lienHe.email = rowData.dangBoi.email;
                lienHe.phone = rowData.dangBoi.phone;
            }
        }
        if (rowData.image) {
            let imageUrl = rowData.image.cover;            
            let hashLoadedImage = {};
            //bachtv: do not push cover to image list
            // imageDataItems.push(imageUrl);
            // hashLoadedImage[imageUrl] = true;
            for (let i=0; i<rowData.image.images.length; i++) {
                imageUrl = rowData.image.images[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
            url = rowData.image.cover;
        }

        this._createTextMessage(rowData);
    }

    let marginBottom = rowData && rowData.dangBoi.userID == this.props.global.currentUser.userID ? 0 : 44
    return (
        <View style={detailStyles.fullWidthContainer}>
            <OfflineBar />
        <View style={detailStyles.mainView}>
          <ScrollView
              ref={(scrollView) => { _scrollView = scrollView; }}
              automaticallyAdjustContentInsets={false}
              vertical={true}
              style={[detailStyles.scrollView, {height: height-marginBottom}]}
              onScroll={this.handleScroll.bind(this)}
              scrollEventThrottle={200}
          >
            <View style={detailStyles.searchContent}>

              {/*<Swiper style={[detailStyles.wrapper,{backgroundColor: 'white'}]} height={imgHeight} width={width}*/}
                      {/*showsButtons={false} autoplay={false} loop={false} bounces={true}*/}
                      {/*dot={<View style={[detailStyles.dot, {backgroundColor: 'transparent'}]} />}*/}
                      {/*activeDot={<View style={[detailStyles.dot, {backgroundColor: 'transparent'}]}/>}*/}
                      {/*renderPagination={this._renderPagination}*/}
                      {/*paginationStyle={{*/}
                        {/*bottom: 20, left: 20, right: null,*/}
                      {/*}}*/}
              {/*>*/}
                {/*{imageItems}*/}
              {/*</Swiper>*/}

                <View style={[detailStyles.wrapper,{backgroundColor: 'white', height: imgHeight, width: width}]}>
                    <TouchableHighlight onPress={imagePreviewAction} underlayColor="transparent" >
                        <View>
                        <ImageBackground style={detailStyles.imgItem}
                               source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}>
                            {this._renderTotalPhoto()}
                        </ImageBackground>
                        </View>
                    </TouchableHighlight>
                </View>

                {this._renderBodyContent()}
            </View>
          </ScrollView>

          {this._renderHeaderBar()}

          {this._renderMessageItem()}
        </View>
        {rowData && rowData.dangBoi.userID == this.props.global.currentUser.userID ? null : this._renderFooter(lienHe.phone, rowData)}
        {this.state.modal ? this._renderImagePreviewModal(imageDataItems, lienHe.phone, rowData) : null }
        </View>
		)
	}

	_renderTotalPhoto() {
        let rowData = this.state.data;
        if(!rowData) {
            return null;
        }

        let imageDataItems = [];
        if (rowData.image) {
            let imageUrl = rowData.image.cover;
            let hashLoadedImage = {};
            //bachtv: do not push cover to image list
            // imageDataItems.push(imageUrl);
            // hashLoadedImage[imageUrl] = true;
            for (let i=0; i<rowData.image.images.length; i++) {
                imageUrl = rowData.image.images[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }
        let total = imageDataItems.length;
      return(
          <View style={{
              position: 'absolute',
              bottom: 20,
              left: 20
          }}>
              <RelandIcon name="camera-o" color="#fff"
                          iconProps={{style: detailStyles.pagingIcon}} size={16}
                          textProps={detailStyles.pagingText}
                          mainProps={detailStyles.pagingView}
                          text={(total) + ' ảnh' }
              >
              </RelandIcon>
          </View>
      );
    }

	_renderBodyContent() {

        let rowData = this.state.data;
        if(!rowData) {
            return this.renderLoadingView();
        }
        let loaiTinVal = rowData.loaiTin;
        let loaiTin = DanhMuc.getLoaiTinValue(loaiTinVal);
        let loaiNhaDat = loaiTinVal ? DanhMuc.LoaiNhaDatThue[rowData.loaiNhaDat] :  DanhMuc.LoaiNhaDatBan[rowData.loaiNhaDat];
        let diaChi = rowData.place.diaChi;
        let huyen = rowData.place.diaChinh.huyen ? rowData.place.diaChinh.huyen : '';
        let tinh = rowData.place.diaChinh.tinh ? ', ' + rowData.place.diaChinh.tinh : '';
        let diaChiTinh = huyen + tinh;
        let dacDiemValues = [];
        dacDiemValues.push(loaiNhaDat);

        let dienTich = rowData.dienTichFmt;
        if (dienTich == 'Không rõ') {
            dienTich = '';
        }
        if (dienTich) {
            dacDiemValues.push(dienTich);
        }

        let giaVal = rowData.gia;
        let gia = rowData.giaFmt;
        let giaM2 = rowData.giaM2Fmt;

        let giaCu = rowData.giaCuFmt || utils.getPriceDisplay(rowData.giaCu, rowData.loaiTin);
        let isGiamGia = rowData.giaCu && rowData.gia && rowData.gia < rowData.giaCu;
        let giaDaGiam = rowData.giaFmt || utils.getPriceDisplay(rowData.gia, rowData.loaiTin);

        let soTang = rowData.soTang;
        if (soTang) {
            soTang = soTang + ' tầng';
            dacDiemValues.push(soTang);
        }
        let duAn = rowData.duAn;
        let luotXem = this._getLuotXem(rowData);
        let soPhongTamVal = rowData.soPhongTam;
        let soPhongTam = soPhongTamVal;
        if (soPhongTam) {
            soPhongTam = soPhongTam + ' phòng tắm';
            dacDiemValues.push(soPhongTam);
        }

        let soPhongNguVal = rowData.soPhongNgu;
        let soPhongNgu = soPhongNguVal;
        if (soPhongNgu) {
            soPhongNgu = soPhongNgu + ' phòng ngủ';
        }
        if (soPhongNgu) {
            dacDiemValues.push(soPhongNgu);
        }

        let huongNha = DanhMuc.HuongNha[rowData.huongNha];
        let huongNhaText = '';
        if (rowData.huongNha && rowData.huongNha != '-1') {
            huongNhaText = "Hướng " + huongNha;
        }
        if (huongNhaText) {
            dacDiemValues.push(huongNhaText);
        }

        let ngayDangTin = rowData.ngayDangTinFmt;
        let soNgayDaDangTin = rowData.soNgayDaDangTinFmt;
        if (soNgayDaDangTin) {
            dacDiemValues.push(soNgayDaDangTin);
        }

        let dacDiemItems = [];
        for (let i = 0; i<dacDiemValues.length; i = i+2) {
            let one = dacDiemValues[i];
            let other = '';
            if (i < dacDiemValues.length-1) {
                other = dacDiemValues[i+1];
            }
            let item = this.renderTwoNormalProps(one, other, {marginTop: 11}, {marginTop: 4, marginBottom: 4}, 'prop_' + i);
            dacDiemItems.push(item);
        }

        let chiTiet = rowData.chiTiet;
        let lienHe = {
            name : '',
            showName: true,
            email : '',
            showEmail: true,
            phone : '',
            showPhone: true
        };

        if (rowData.lienHe){
            lienHe.name = rowData.lienHe.tenLienLac;
            lienHe.showName = rowData.lienHe.showTenLienLac;
            lienHe.email = rowData.lienHe.email;
            lienHe.showEmail = rowData.lienHe.showEmail;
            lienHe.phone = rowData.lienHe.phone;
            lienHe.showPhone = rowData.lienHe.showPhone;
        } else {
            if (rowData.dangBoi) {
                lienHe.name = rowData.dangBoi.name;
                lienHe.email = rowData.dangBoi.email;
                lienHe.phone = rowData.dangBoi.phone;
            }
        }

        let _scrollView: ScrollView;
        let mapUrl = '';
        if (rowData.place.geo && !isNaN(rowData.place.geo.lat) && !isNaN(rowData.place.geo.lon)) {
            mapUrl = 'http://maps.google.com/maps/api/staticmap?zoom=16&size='+mapWidth+'x'+mapHeight+'&markers=color:red|'+rowData.place.geo.lat+','+rowData.place.geo.lon+'&sensor=false';
            mapUrl = mapUrl + '&key=AIzaSyDCGmWrUyarAz5iIUeOX3X8eI3S7Qvfo3g';
        }
        let imageItems = [];
        let imageDataItems = [];
        let imageIndex = 0;
        let imagePreviewAction = this._onImagePreviewPressed.bind(this);
        if (rowData.image) {
            let imageUrl = rowData.image.cover;
            let hashLoadedImage = {};
            imageDataItems.push(imageUrl);
            hashLoadedImage[imageUrl] = true;
            let imageUri = {uri: imageUrl};
            if (noCoverUrl == imageUrl) {
                imageUri = require('../../assets/image/reland_house_large.jpg');
            }
            // imageItems.push(
            //     <View style={detailStyles.slide} key={"img"+(imageIndex++)}>
            //       <TouchableHighlight onPress={imagePreviewAction} underlayColor="transparent" >
            //         <Image style={detailStyles.imgItem}
            //                source={imageUri} defaultSource={CommonUtils.getNoCoverImage()}>
            //         </Image>
            //       </TouchableHighlight>
            //     </View>
            // );
            for (let i=0; i<rowData.image.images.length; i++) {
                imageUrl = rowData.image.images[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
                let imageUri = {uri: imageUrl};
                if (noCoverUrl == imageUrl) {
                    imageUri = require('../../assets/image/reland_house_large.jpg');
                }
                // imageItems.push(
                //   <View style={detailStyles.slide} key={"img"+(imageIndex++)}>
                //     <TouchableHighlight onPress={imagePreviewAction} underlayColor="transparent" >
                //     <Image style={detailStyles.imgItem}
                //        source={imageUri} defaultSource={CommonUtils.getNoCoverImage()}>
                //     </Image>
                //     </TouchableHighlight>
                //   </View>
                // );
            }
            url = rowData.image.cover;
        }
        // let {typeDetail} = this.state;
        let title = rowData.title || utils.getTitleAdsDetail(rowData);
        let diaChiItems = rowData.title ?
            <View>
                <FullLine style={{marginBottom: 4, width: width - 44, marginLeft: 20}} />
                <View style={detailStyles.lineBorder}>
                    <Text style={[detailStyles.textFullWidth, {marginBottom: 8}]}>
                        {diaChi}
                    </Text>
                </View>
            </View> : null;
      return(
          <View style={detailStyles.slideItem}>
              <View style={{flexDirection: 'row'}}>
                  {isGiamGia ?
                      <View style={{flexDirection: 'row'}}>
                          <Text style={detailStyles.price} numberOfLines={1}>{giaDaGiam}</Text>
                          <Text style={[detailStyles.price, {marginLeft: 10, textDecorationLine: 'line-through',
                                                color: '#C7C8CA'}]} numberOfLines={1}>{giaCu}</Text>
                      </View> :
                      <Text style={detailStyles.price} numberOfLines={1}>{giaDaGiam}</Text>
                  }
              </View>
              <FullLine style={{marginBottom: 4, width: width - 44, marginLeft: 20}} />
              <View style={detailStyles.lineBorder}>
                  <Text style={[detailStyles.textFullWidth, {marginBottom: 8, fontSize: 17, fontWeight: '600'}]}>
                      {title}
                  </Text>
              </View>
              {diaChiItems}
              {/*<View style={[detailStyles.lineBorder, {marginBottom: 4}]} />*/}
              <FullLine style={{marginBottom: 4, width: width - 44, marginLeft: 20}} />
              {dacDiemItems}
              {/*<View style={[detailStyles.lineBorder2, {marginTop: 4, marginBottom: 8}]} />*/}

              {/*<View style={detailStyles.viewTabInterest}>*/}
                  {/*<MLikeTapButton name={'resultDetail'}*/}
                                  {/*onPress={this._onTypeDetail.bind(this)}*/}
                                  {/*selected={typeDetail == 'resultDetail'}*/}
                                  {/*mainProps={detailStyles.tabResultDetail}>Chi tiết</MLikeTapButton>*/}
                  {/*<MLikeTapButton name={'result'}*/}
                                  {/*onPress={this._onTypeDetail.bind(this)}*/}
                                  {/*selected={typeDetail == 'resultReceive'}*/}
                                  {/*mainProps={detailStyles.tabNeedToBuy}>Cần mua</MLikeTapButton>*/}
                  {/*<MLikeTapButton name={'interestTotalMonth'}*/}
                                  {/*onPress={this._onTypeDetail.bind(this)}*/}
                                  {/*selected={typeDetail == 'resultSendTo'}*/}
                                  {/*mainProps={detailStyles.tabNeedToReceive}>Cần thuê</MLikeTapButton>*/}
              {/*</View>*/}


              <FullLine style={{marginTop: 4, marginBottom: 8}} />
              <View style={detailStyles.chiTietText}>
                  <Text style={[detailStyles.textTitle, {marginLeft: 0, marginBottom: 2}]}>Chi Tiết</Text>
                  <SummaryText longText={chiTiet}
                               expanded={false}
                               maxLength={130}
                               width={width-43}>
                  </SummaryText>
              </View>
              {this._renderDanDuong()}
              {this._renderStreetView()}
              {/*<View style={detailStyles.lineBorder2} />*/}
              <FullLine />
              {this._renderDacDiem(loaiNhaDat, gia, giaM2, soPhongNguVal, soPhongTamVal, dienTich,
                  huongNha, duAn, ngayDangTin, luotXem, diaChi, rowData.maSo)}
              {/*<View style={detailStyles.lineBorder2} />*/}
              <FullLine />
              {this._renderViTri(mapUrl, rowData.isFakeGeo)}
              {/*<View style={detailStyles.lineBorder2} />*/}
              <FullLine />
              {/*this._renderShareButtons(lienHe.phone, lienHe.email, loaiNhaDat, diaChi)*/}
              {/*<View style={detailStyles.lineBorder2} />*/}
              <FullLine />
              {this._renderLienHe(lienHe, loaiNhaDat, diaChi)}
              {/*<View style={detailStyles.lineBorder2} />*/}
              <FullLine />
              {/*<CollapsiblePanel title="Môi giới" expanded={true}>
               <Text style={[detailStyles.textFullWidth,{marginTop: 0}]}>
               Các môi giới đang bán nhà tương tự
               </Text>
               {moiGioiTuongTu}
               </CollapsiblePanel>*/}
              {this._renderPhuongAnTaiChinh(giaVal, loaiTinVal)}
              {/*this._renderPostedGroup()*/}

              {/*<View style={{marginTop: 10.5, alignItems: 'center', justifyContent:'center'}}>
               <Text style={detailStyles.adsMore}>
               Khám Phá Thêm
               </Text>
               <View style={{width: width, marginTop: 10.5}}>
               {this.renderContent(this.props.search.collections)}
               </View>
               </View>*/}
          </View>
      );
    }

    _getLuotXem(rowData) {
        if (!this.props.global.loggedIn) {
            return null;
        }
        let currentUserID = this.props.global.currentUser.userID;
        let dangBoiUserID = rowData.dangBoi && rowData.dangBoi.userID;
        if (currentUserID != dangBoiUserID) {
            return null;
        }
        let goiViTri = rowData.goiViTri;
        if (!goiViTri || goiViTri.level == 4) {
            return null;
        }
        let remainDays = utils.getRemainDay(goiViTri);
        if (remainDays <= 0) {
            return null;
        }
        return rowData.luotXem;
    }

    // _onTypeDetail(value) {
    //     this.setState({
    //         typeDetail: value
    //     });
    // }

  _beginChatLoading() {
    this.setState({isChatLoading: true});
  }

  _endChatLoading() {
    this.setState({isChatLoading: false});
  }

  _createTextMessage(ads) {
    let title = ads.title || utils.getTitleAdsDetail(ads);
    let loaiTin = DanhMuc.getLoaiTinValue(ads.loaiTin).toLowerCase();
    text = `Mình thấy bạn đang rao '${title}'`;
    // linkAds = cfg.serverUrl + '/web/detail/' + ads.adsID;
    // text += linkAds;
    text += `. Nhà đã ${loaiTin} chưa bạn? Bạn là chủ hay môi giới thế ?`;
  }

  _renderDacDiem(loaiNhaDat, gia, giaM2, soPhongNguVal, soPhongTamVal, dienTich, huongNha, duAn, ngayDangTin, luotXem, diaChi, maSo) {
    return (
        <CollapsiblePanel title="Đặc Điểm" mainProps={{marginTop: 8, marginBottom: 8}}
                          collapseProps={{marginTop: 15, marginBottom: 15}}
                          expanded={true} bodyProps={{marginTop: 0}}>
          <Text style={[detailStyles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
            Thông tin tổng quan về bất động sản này
          </Text>
          {this.renderTitleProps("Loại tin rao", loaiNhaDat, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Giá", gia, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Giá/m²", giaM2, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Số phòng ngủ", soPhongNguVal, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Số phòng tắm", soPhongTamVal, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Diện tích", dienTich, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Hướng nhà", huongNha, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Thuộc dự án", duAn, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Ngày đăng tin", ngayDangTin, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Lượt xem", luotXem, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Địa chỉ", diaChi, {marginTop: 3, marginBottom: 2.2})}
          {this.renderTitleProps("Mã tin", maSo, {marginTop: 3, marginBottom: 2.2})}
          <Text style={{fontSize: 5}} />
        </CollapsiblePanel>
    );
  }

  _renderViTri(mapUrl, isFakeGeo) {
    if (!mapUrl) {
        return null;
    }
    let ads = this.state.data;
    let geo = ads && ads.place.geo;
    if (!geo) {
        return null;
    }
    let region = {latitude: geo.lat, longitude: geo.lon, latitudeDelta: 0.021, longitudeDelta: 0.0144};
    // let viTriHint = isFakeGeo ? "Vị trí chưa xác thực" : "Vị trí đã xác thực";
    let viTriHint = "Vị trí của bất động sản này trên bản đồ";
    return (
        <CollapsiblePanel title="Vị Trí" mainProps={{marginTop: 8}}
                          collapseProps={{marginTop: 15, marginBottom: 15}}
                          expanded={true} bodyProps={{marginTop: 0}}>
          <Text style={[detailStyles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
              {viTriHint}
          </Text>
          <TouchableHighlight onPress={() => this._onMapPressed()}
              style={detailStyles.mapViewButton}>
              <View>
                  <MapView
                      style={detailStyles.imgMapView}
                      scrollEnabled={false}
                      zoomEnabled={false}
                      pitchEnabled={false}
                      rotateEnabled={false}
                      initialRegion={region}>
                      <MapView.Marker coordinate={region} pointerEvents="none">
                          <LocationMarker/>
                      </MapView.Marker>
                  </MapView>
              </View>
          </TouchableHighlight>
          <Text style={{fontSize: 5}} />
        </CollapsiblePanel>
    );
  }

  _onAddContact(dangBoi, mobile, email) {

  }

  _renderShareButtons(mobile, email, loaiNhaDat, diaChi) {
    return (
      <CollapsiblePanel title="Chia Sẻ" mainProps={{marginTop: 8, marginBottom: 8}}
                        collapseProps={{marginTop: 15, marginBottom: 15}}
                        expanded={true} bodyProps={{marginTop: 0}}>
        <Text style={[detailStyles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
          Chia sẻ bất động sản này với người thân
        </Text>
        <View style={detailStyles.shareMainView}>
          <View style={detailStyles.shareLeft}>
            <View style={[detailStyles.circleContainer2, {backgroundColor: '#fff'}]} >
              <RelandIcon onPress={() => this._onSmsFriend()}
                          name="share-sms" color={'#ffcf00'}
                          size={40} iconProps={{style: detailStyles.shareIcon}}>
              </RelandIcon>
            </View>
            <View style={[detailStyles.circleContainer2, {backgroundColor: '#fff'}]} >
              <RelandIcon onPress={() => this._onEmailFriend()}
                          name="share-mail" color={'#dd5044'}
                          size={40} iconProps={{style: detailStyles.shareIcon}}>
              </RelandIcon>
            </View>
            <View style={[detailStyles.circleContainer, {backgroundColor: '#A6A6A6'}]} >
              <RelandIcon onPress={this._onCopy.bind(this)}
                          name="copy-link" color={'white'}
                          size={26} iconProps={{style: detailStyles.shareIcon}}>
              </RelandIcon>
            </View>
          </View>
          <View style={detailStyles.shareRight}>
            <View style={[detailStyles.circleContainer, {marginRight: 0, backgroundColor:'#575757'}]} >
              <RelandIcon onPress={this._onShare.bind(this)}
                          name="share-o" color={'white'}
                          size={26} iconProps={{style: detailStyles.shareIcon}}>
              </RelandIcon>
            </View>
          </View>
        </View>
        <Text style={{fontSize: 5}} />
      </CollapsiblePanel>
    );
  }

  _onAdsAlertUs() {
      if (this.props.global.loggedIn) {
          this._doAdsAlertUs();
      } else {
          Actions.NewLogin({doFinalAction: this._doAdsAlertUs.bind(this)});
      }
  }

  _doAdsAlertUs() {
      this.props.actions.onAlertUsChange('');
      Actions.AdsAlertUs({adsID: this.props.adsID});
  }

  _renderLienHe(lienHe, loaiNhaDat, diaChi) {
    return (
      <CollapsiblePanel title="Liên Hệ" mainProps={{marginTop: 8}}
                        collapseProps={{marginTop: 15, marginBottom: 15}}
                        expanded={true} bodyProps={{marginTop: 0}}>
        <Text style={[detailStyles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
          Thông tin liên hệ của người đăng tin
        </Text>

          <View style={detailStyles.shareMainView}>
              <View style={detailStyles.shareLeft}>
                  { lienHe.phone && lienHe.phone.length>0 ?
                      (  <View style={[detailStyles.circleContainer, {backgroundColor: '#57ba4d'}]} >
                          <RelandIcon onPress={() => this._onSms(lienHe.phone)}
                                      name="sms" color={'white'}
                                      size={26} iconProps={{style: detailStyles.shareIcon}}>
                          </RelandIcon>
                          </View>
                      ) : null}

                  { lienHe.showEmail && lienHe.email && lienHe.email.length > 0 ?
                      ( <View style={[detailStyles.circleContainer, {backgroundColor: '#dd5044'}]} >
                          <RelandIcon onPress={() => this._onEmail(lienHe.email, loaiNhaDat, diaChi)}
                                      name="email" color={'white'}
                                      size={26} iconProps={{style: detailStyles.shareIcon}}>
                          </RelandIcon>
                         </View>
                      ) : null }
              </View>
          </View>


        { lienHe.showName && lienHe.name && lienHe.name.length>0 ?
            this.renderTitleProps("Tên liên lạc", lienHe.name, {marginTop: 3, marginBottom: 2.2}) : null
        }
        { lienHe.showPhone && lienHe.phone && lienHe.phone.length>0 ?
            this.renderTitleProps("Điện thoại", lienHe.phone, {marginTop: 3, marginBottom: 2.2}, () => this._onCall(lienHe.phone)) : null
        }
        { lienHe.showEmail && lienHe.email && lienHe.email.length>0 ?
          this.renderTitleProps("Email", lienHe.email, {marginTop: 3, marginBottom: 2.2}, () => this._onEmail(lienHe.email, loaiNhaDat, diaChi)) : null
        }
        <Text style={{fontSize: 5}} />
      </CollapsiblePanel>
    );
  }
  _renderDanDuong() {
      let ads = this.state.data;
      if (!ads.place.geo || isNaN(ads.place.geo.lat) || isNaN(ads.place.geo.lon)) {
          return null;
      }
    return (
        <View>
          <FullLine/>
          <TouchableHighlight onPress={() => this._onDanDuongPressed()} underlayColor="transparent" >
            <View style={detailStyles.lineBorder2}>
              <View style={[detailStyles.danDuongView, {marginLeft: 20, marginRight: 29}]}>
                <View style={detailStyles.danDuongLeftView}>
                  <TruliaIcon name={"car"} size={20} color={gui.mainColor} text={"Dẫn đường"}
                              textProps={detailStyles.danDuongText} onPress={() => this._onDanDuongPressed()}/>
                </View>
                <View style={detailStyles.danDuongRightView}>
                  <TruliaIcon name={"arrow-right"} size={20} color={"gray"} onPress={() => this._onDanDuongPressed()}/>
                </View>
              </View>
            </View>
          </TouchableHighlight>
          <FullLine/>
        </View>
    );
  }

  _renderStreetView() {
    if (!this.state.streetViewUrl) {
        return null;
    }
    return (
        <TouchableHighlight onPress={() => this._onStreetViewPressed()} underlayColor="transparent" >
          <View style={detailStyles.lineBorder2}>
            <View style={[detailStyles.danDuongView, {marginLeft: 20, marginRight: 29}]}>
              <View style={detailStyles.danDuongLeftView}>
                <RelandIcon name={"street-view"} size={20} color={gui.mainColor} text={"Street view"}
                            mainProps={{flexDirection: 'row'}}
                            iconProps={{style: {marginRight: 0}}}
                            textProps={[detailStyles.danDuongText, {paddingLeft: 0}]}
                            onPress={() => this._onStreetViewPressed()}/>
              </View>
              <View style={detailStyles.danDuongRightView}>
                <TruliaIcon name={"arrow-right"} size={20} color={"gray"}
                            onPress={() => this._onStreetViewPressed()}/>
              </View>
            </View>
          </View>
        </TouchableHighlight>
    );
  }

  renderContent(collections) {
    if (this.props.search.homeDataErrorMsg) {
      return (
          <View style={{flexGrow:1, alignItems:'center', justifyContent:'center', marginTop: 30}}>
            <Text style={detailStyles.welcome}>{this.props.search.homeDataErrorMsg}</Text>
          </View>
      )
    }

    return this.renderCollections(collections);
  }

  renderCollections(collections) {
    return collections.map(e => {
      return <HomeCollection key={e.title1} collectionData = {e} searchFromHome={this.props.actions.searchFromHome}/>
    });
  }

  getPaymentPerMonth(totalPrincipal, numOfMonth, interestRatePerYear){
    let pricipalPerMonth = totalPrincipal/numOfMonth;
    let totalInterest = interestRatePerYear * totalPrincipal;
    let interestPerMonth = totalInterest/12;

    return {
      payment: pricipalPerMonth,
      interest: interestPerMonth,
      sumOfPayment: pricipalPerMonth + interestPerMonth
    }
  }

  _renderPhuongAnTaiChinh(giaVal, loaiTinVal) {
    if (loaiTinVal || !giaVal) {
      return null;
    }

    let percentOfPrice = 0.7; /* duoc vay 70% */
    let numOfMonth = 12*20; /* vay 20 nam */
    let interestRatePerYear = 0.085; /* lai suat nam */

    let {payment, interest} = this.getPaymentPerMonth(giaVal*percentOfPrice, numOfMonth, interestRatePerYear);

    //let payment = mainAccount / months;
    //let interest = 0.12*principal/12;
    let paymentFmt = utils.getPriceDisplay(payment, loaiTinVal);
    let interestFmt = utils.getPriceDisplay(interest, loaiTinVal);
    //
    // paymentFmt = paymentFmt ? paymentFmt + "/Tháng" : paymentFmt;
    // interestFmt = interestFmt ? interestFmt + "/Tháng" : interestFmt;

    let data = [{
      "name": "",
      "fillColor" : gui.mainColor,
      "value": payment
    }, {
      "name": "",
      "fillColor" : "#DE6207",
      "value": interest
    }];
    let pallete = [
      utils.hexToRgb(gui.mainColor), utils.hexToRgb("#DE6207")
    ];
    let options = {
      margin: {
        top: 1,
        left: 2,
        bottom: 1,
        right: 2
      },
      width: 126,
      height: 126,
      r: 46,
      R: 61,
      legendPosition: 'topLeft',
      animate: {
        type: 'oneByOne',
        duration: 200,
        fillTransition: 3
      },
      label: {
        fontFamily: gui.fontFamily,
        fontSize: gui.buttonFontSize,
        fontWeight: 'normal'
      }
    };
    let chartTitleBold = utils.getPriceDisplay(payment+interest, loaiTinVal);
    let chartTitle = chartTitleBold.substring(chartTitleBold.indexOf(' ') + 1) + '/Tháng';
    chartTitleBold = chartTitleBold.substring(0, chartTitleBold.indexOf(' '));

    return (
      <View>
        <CollapsiblePanel title="Phương Án Tài Chính"
                          expanded={true} bodyProps={{marginTop: 0}}
                          mainProps={{marginTop: 8}}
                          collapseProps={{marginTop: 15, marginBottom: 15}}>
          <Text style={[detailStyles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
            Tính trên cơ sở vay 70% giá trị nhà trong vòng 20 năm với lãi suất cố định 8.5%/năm theo số tiền vay
          </Text>
            <View style={{flexDirection: "row", alignItems: 'center', justifyContent: 'flex-start', backgroundColor:'white', paddingTop:0}}>
              <View style={{paddingLeft: 2, paddingTop:2, width: width/2-15, alignItems: 'center', justifyContent: 'center'}}>
                <MChartView
                    data={data}
                    options={options}
                    pallete={pallete}
                    chartTitle={chartTitle}
                    chartTitleBold={chartTitleBold}
                />
              </View>
              <View style={{paddingLeft: 0, paddingTop:2}}>
                {this._renderMoneyLine("Tiền gốc trả hàng tháng", paymentFmt, gui.mainColor)}
                {this._renderMoneyLine("Tiền lãi trả hàng tháng", interestFmt, '#DE6207')}
              </View>
            </View>
          <Text style={{fontSize: 5}} />
          <TouchableOpacity onPress={()=> {this._renderTaiChinh(giaVal*1000000*percentOfPrice, numOfMonth, interestRatePerYear*100)}}>
           <Text style={detailStyles.textTaiChinh}>Nhấn vào đây để xem chi tiết Phương án tài chính</Text>
          </TouchableOpacity>
        </CollapsiblePanel>
        {/*<View style={detailStyles.lineBorder2} />*/}
      </View>
    );
  }

    _renderPostedGroup() {
        let postedGroup = this.state.postedGroup;
        
        if(postedGroup.length <= 0) {
            return;
        }
        return (
            <View style={detailStyles.viewCungLoai}>
                <FullLine />
                <View style={detailStyles.viewBdsCungLoai}>
                    <View style={[detailStyles.viewTextTile, {height: 28, justifyContent: 'flex-end'}]}>
                        <Text style={detailStyles.textTitleSuggest}>Danh sách sàn đã đăng tin</Text>
                    </View>
                    <View style={detailStyles.viewListView}>
                        <ListView style={detailStyles.viewListNhaGan}
                                  enableEmptySections={true}
                                  showsVerticalScrollIndicator={false}
                                  dataSource={ds_postedGroup.cloneWithRows(postedGroup)}
                                  renderRow={this._renderRowPostedGroup.bind(this)} />
                    </View>
                </View>
            </View>
        );
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateMessageProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateMessageProcessing.bind(this));
            }
        }
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }

    _renderRowPostedGroup(data) {
        let imgUrl = data.image;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/no_cover.jpg');
        }
        let adminAvatarUrl = data.avatar;
        let adminSource = { uri: adminAvatarUrl };
        let groupName = data.name;
        let nameAdmin = data.fullNameChuSan;
        let totalMember = data.countMember || 0;
        return (
            <View style={detailStyles.viewContent}>
                <Image
                    resizeMode={"cover"}
                    source={imageGroup}
                    defaultSource={defaultCover}
                    style={detailStyles.adsCover} />
                <View style={detailStyles.viewBodyContent}>
                    <View style={[detailStyles.viewNameGroup, {width: width - 108}]}>
                        <ScalableText style={detailStyles.textNameGroup} numberOfLines={2}>{groupName}</ScalableText>
                    </View>
                    <View style={[detailStyles.viewNameGroup, {marginTop: 5}]}>
                        <Image
                            resizeMode={"cover"}
                            source={adminSource}
                            defaultSource={defaultCover}
                            style={detailStyles.avatarAdmin} />
                        <Text style={[detailStyles.textNameAvatar, { marginLeft: 8 }]} numberOfLines={1}>{nameAdmin}</Text>
                        <Icon name="users" size={13} color={gui.mainTextColor} style={{ marginLeft: 10 }} />
                        <Text style={[detailStyles.textNameAvatar, { marginLeft: 8 }]}>{totalMember}</Text>
                    </View>
                </View>
            </View>
        )
    }


    _renderTaiChinh(totalLoan, loanPeriod, interestRate) {
      let result = utils.getPayment(totalLoan,loanPeriod, interestRate/100);
      let firstMonthLoan = result.allMonth[1].originalPerMonth;
      let firstMonthInterest =result.allMonth[1].interestPerMonth;
      let totalInterest = result.totalInterest;
      
      Actions.VayUocTinh3({totalLoan: totalLoan, loanPeriod:loanPeriod, interestRate: interestRate,
                          firstMonthLoan: firstMonthLoan, firstMonthInterest: firstMonthInterest,
                          totalInterest: totalInterest});
    }

  _renderMoneyLine(label, value, dotColor) {
    return (
        <View style={{flexDirection:'row'}}>
          <View style={[detailStyles.dot3, {borderColor: dotColor}]}>
          </View>
          <View style={{flexDirection:'column', marginTop: 8, marginBottom: 8}}>
            <Text style={{fontSize: 13, fontFamily: gui.fontFamily, fontWeight: '500'}}>
              {value}
            </Text>
            <Text style={{fontSize: 12, fontFamily: gui.fontFamily, color: '#9C9C9C', width: width/2-40}}>
              {label}
            </Text>
          </View>
        </View>
    )
  }

  _onImagePreviewPressed() {
      let rowData =  this.state.data;
      if(!rowData) {
          return;
      }
    if (this.state.modal) {
      return;
    }
    this.setState({
      modal: true
    });
  }

  // _renderPagination(index, total, context) {
  //   return (
  //       <View style={{
  //     position: 'absolute',
  //     bottom: 20,
  //     left: 20,
  //   }}>
  //         <RelandIcon name="camera-o" color="black"
  //                iconProps={{style: detailStyles.pagingIcon}} size={16}
  //                textProps={detailStyles.pagingText}
  //                mainProps={detailStyles.pagingView}
  //                text={(index + 1) + '/' + (total)}
  //         >
  //         </RelandIcon>
  //       </View>
  //   )
  // }
  //
  //   _renderPaginationImg(total) {
  //       return (
  //           <View style={{
  //               position: 'absolute',
  //               bottom: 20,
  //               left: 20,
  //           }}>
  //               <RelandIcon name="camera-o" color="black"
  //                           iconProps={{style: detailStyles.pagingIcon}} size={16}
  //                           textProps={detailStyles.pagingText}
  //                           mainProps={detailStyles.pagingView}
  //                           text={(total) + ' ảnh' }
  //               >
  //               </RelandIcon>
  //           </View>
  //       )
  //
  //   }

  _onCall(phone) {
    Communications.phonecall(phone, true);
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    let userID = this.props.global.currentUser.userID || undefined;
    Analytics.logEvent('DETAIL_DIALING', {deviceID: deviceID, userID: userID, adsID: this.props.adsID, phone: phone});
  }

  _onEmail(email, loaiNhaDat, diaChi) {
    if (!email) {
      return;
    }
    let bodyText = `${text}`;

    let action = loaiNhaDat.indexOf("Bán")>=0 ? "mua" : "thuê";

    let subject = `Tôi đang cần ${action} nhà tại ${diaChi}`;
      //  loaiNhaDat.replace('Bán', 'Mua');
    Communications.email([email], null, null, subject, bodyText);
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    let userID = this.props.global.currentUser.userID || undefined;
    Analytics.logEvent('DETAIL_SENDMAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID, email: email});
  }

    _onEmailFriend() {
        let linkShare = linkAds || '';
        Communications.email('', null, null, null, linkShare);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('DETAIL_SENDMAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

  _onSms(phone) {
    let bodyText = `${text}`;
    if (!phone) {
       return;
    }
    Communications.text(phone, bodyText);
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    let userID = this.props.global.currentUser.userID || undefined;
    Analytics.logEvent('DETAIL_SENDSMS', {deviceID: deviceID, userID: userID, adsID: this.props.adsID, phone: phone});
  }

    _onSmsFriend() {
        let linkShare = linkAds || '';
        Communications.text('', linkShare);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('DETAIL_SENDSMS', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

  _onCopy() {
    Communications.copy(linkAds);
    Alert.alert('Thông báo',
        'Đường link của tin đã được copy. Hãy paste vào nơi bạn muốn chia sẻ!',
        [{
          text: 'Đóng',
          onPress: () => {}
        }]);
  }

    _onPhoneCall(phoneNumber) {
        if (!phoneNumber) {
            return;
        }

        let phone = phoneNumber;

        let userID = null;
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        Communications.phonecall(phone, true);
        Analytics.logEvent('USER_DIALING', { deviceID: deviceID, userID: userID, phone: phone });
    }


    _onChat(ads) {
    if (!ads) {
        return;
    }
    if (!this.props.global.loggedIn) {
      Actions.NewLogin();
    } else {
      if (ads.dangBoi.userID == this.props.global.currentUser.userID) {
        Alert.alert('Thông báo', gui.ERR_NotAllowChatYourSelf);
        return;
      }

      this._beginChatLoading();

      /*if (!ads.dangBoi.userID) {
        if ( ads.dangBoi.phone && ads.dangBoi.phone.length >0){
          this._onSms(ads.dangBoi.phone);
          return;
        }

        if ( ads.dangBoi.email && ads.dangBoi.email.length >0){
          this._onSms(ads.dangBoi.phone);
          return;
        }

        alert(gui.ERR_NotRelandUser);
        return;
      }*/

      let partner = {
        phone: ads.dangBoi.phone || undefined,
        email: ads.dangBoi.email || undefined,
        fullName : ads.dangBoi.name  || undefined
      };

      if (ads.dangBoi.userID){
        partner.userID = ads.dangBoi.userID;

        this.props.actions.startFriendChat(this.props.global.currentUser, partner)
            .then( (e) => {
              this._doChatPress(partner, e);
            });
      }
    }
  }

  _doChatPress(partner, e) {
    let deviceID = this.props.global.deviceInfo.deviceID || undefined;
    let userID = this.props.global.currentUser.userID || undefined;
    let isSpam = false;
    if(e.partners)
        e.partners.forEach((pn) => {
            if (pn.userID==userID && pn.spamStatus==2)
                isSpam=true;
        })
    Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: partner.fullName || '' });
    this._endChatLoading();
    Analytics.logEvent('DETAIL_CHAT', {deviceID: deviceID, userID: userID, partner: partner});
  }

  _onMapPressed() {
    let {geo} = this.state.data.place;
    let region = {
      latitude: geo.lat,
      longitude: geo.lon,
      latitudeDelta: 0.021,
      longitudeDelta: 0.0144
    };
    Actions.SearchMapDetail({region: region, ads: this.state.data});
  }

  _drawDiemDanhGia(diemDanhGia) {
    let diemDanhGiaItems = [];
    let i = 0;
    for(i = 0; i < diemDanhGia; i++) {
      diemDanhGiaItems.push(
          <TruliaIcon key={'diem-'+i} name="star" mainProps={detailStyles.moiGioiStar} color={'#FEBC0A'} size={16}/>);
    }
    for(i = 0; i < 5-diemDanhGia; i++) {
      diemDanhGiaItems.push(
          <TruliaIcon key={'diem-star-'+i} name="star-o" mainProps={detailStyles.moiGioiStarO} color={'#FEBC0A'} size={16}/>);
    }
    return (
        <View style={detailStyles.moiGioiStarView}>
          {diemDanhGiaItems}
        </View>
    );
  }

  _onDanDuongPressed() {
    let onOpenURL = this._onOpenURL.bind(this);
    let ads = this.state.data;
    navigator.geolocation.getCurrentPosition(
        (position) => {
          let geoUrl = 'http://maps.apple.com/?saddr='+position.coords.latitude+','+position.coords.longitude+'&daddr='+ads.place.geo.lat+','+ads.place.geo.lon+'&dirflg=d&t=s';
          onOpenURL(geoUrl);
        },
        (error) => {
          let geoUrl = 'http://maps.apple.com/?daddr='+ads.place.geo.lat+','+ads.place.geo.lon+'&dirflg=d&t=s';
          this._updateMessageProcessing(gui.ERR_LocationNotOn2, '#fa4916', 'white');
          onOpenURL(geoUrl);
        },
        {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
    );
  }

  _onOpenURL(geoUrl) {
    Linking.canOpenURL(geoUrl).then(supported => {
      if (supported) {
        Linking.openURL(geoUrl);
      } else {
        log.info('Don\'t know how to open URI: ' + geoUrl);
      }
    });
  }

  _onStreetViewPressed() {
    Actions.MStreetView({source: this.state.streetViewUrl});
    
    // Linking.canOpenURL(this.state.streetViewUrl).then(supported => {
    //   if (supported) {
    //     Linking.openURL(this.state.streetViewUrl);
    //   } else {
    //     Alert.alert('Thông báo',
    //       'Bạn cần cài đặt ứng dụng Google Maps!',
    //       [{
    //         text: 'Đóng',
    //         onPress: () => {}
    //       }]);
    //   }
    // });
  }

  renderTwoNormalProps(prop1, prop2, dotStyle, textStyle, key) {
    if (prop1 || prop2) {
      let dotIcon1Style = prop1 ? {} : {backgroundColor: 'transparent'};
      let dotIcon2Style = prop2 ? {} : {backgroundColor: 'transparent'};
      return (
          <View key={key} style={[detailStyles.searchDetailRowAlign, {width: width - 22.5, marginLeft: 20}]}>
            <View style={{flexDirection: 'row'}}>
              <View style={[detailStyles.dot2, dotIcon1Style, dotStyle]} />
              <Text style={[detailStyles.textHalfWidth, textStyle]}>
                {prop1}
              </Text>
            </View>
            <View style={{flexDirection: 'row', marginLeft: 10}}>
              <View style={[detailStyles.dot2, dotIcon2Style, dotStyle]} />
              <Text style={[detailStyles.textHalfWidth, textStyle]}>
                {prop2}
              </Text>
            </View>
          </View>
      )
    }
  }

  renderTitleProps(title, prop, textStyle, onPress) {
    if (prop) {
      if (onPress) {
        return (
            <View style={detailStyles.searchDetailRowAlign}>
              <Text style={[detailStyles.textHalfWidth2, textStyle]}>
                {title}
              </Text>
              <TouchableHighlight onPress={onPress} underlayColor="transparent">
                <Text style={[detailStyles.textHalfWidthBold2, {color: gui.mainColor}, textStyle]}>
                  {prop}
                </Text>
              </TouchableHighlight>
            </View>
        );
      } else {
        return (
            <View style={detailStyles.searchDetailRowAlign}>
              <Text style={[detailStyles.textHalfWidth2, textStyle]}>
                {title}
              </Text>
              <Text style={[detailStyles.textHalfWidthBold2, textStyle]}>
                {prop}
              </Text>
            </View>
        );
      }
    }
  }

 handleScroll(event) {
   if (event.nativeEvent.contentOffset.y <= imgHeight-64 && this.state.headerColor != 'transparent') {
     StatusBar.setBarStyle('light-content');
     this.setState({
       headerColor: 'transparent',
       headerButtonColor: 'white',
       sendButtonColor:'white',
       backButtonColor: 'white',
       heartBgColor: '#323230'
     });
   } else if (event.nativeEvent.contentOffset.y > imgHeight-64 && this.state.headerColor != '#FEFEFE') {
     StatusBar.setBarStyle('default');
     this.setState({
       headerColor: '#FEFEFE',
       headerButtonColor: 'rgba(55,55,55,0.8)',
       sendButtonColor:'#ecc003',
       backButtonColor: gui.mainColor,
       heartBgColor: '#FEFEFE'
     });
   }
 //   if (event.nativeEvent.contentOffset.y <= imgHeight-30 && this.state.headerButtonColor != 'white') {
 //     StatusBarIOS.setStyle('light-content');
 //     this.setState({
 //       headerButtonColor: 'white'
 //     });
 //   } else if (event.nativeEvent.contentOffset.y > imgHeight-30 && this.state.headerButtonColor != gui.mainColor) {
 //     StatusBarIOS.setStyle('default');
 //     this.setState({
 //       headerButtonColor: gui.mainColor
 //     });
 //   }
 }

  _onBack() {
    // if (this.props.owner != 'GroupWall') {
    //     StatusBar.setBarStyle('default');
    // }
    StatusBar.setBarStyle('default');
    Actions.pop();
  }

  _onShare() {
      let linkShare = linkAds || '';
    // ShareManager.share({text: text, url: url});
    ShareManager.share({text: linkShare});
  }

  _onLike() {
    log.info("On like pressed!");
  }
}

var detailStyles = StyleSheet.create({
  pagingText: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: '#fff',
    marginRight: 10,
    marginBottom: 2,
    marginTop: 2
  },
  pagingIcon: {
    borderRadius: 0,
    marginLeft: 10,
    marginBottom: 2,
    marginTop: 2
  },
  pagingView: {
    flexDirection: 'row',
    backgroundColor: '#5b5c61',
    borderRadius: 5,
    opacity: 0.75
  },
  moiGioiStar: {
    marginRight: 5
  },
  moiGioiStarO: {
    marginRight: 5
  },
  moiGioiStarView: {
    flexDirection: 'row',
    marginTop: 5,
    marginBottom: 5
  },
  moiGioiRowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  moiGioiRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  moiGioiInfo: {
    flexDirection: 'column',
    marginLeft: 8,
    width: width - 192
  },
  moiGioiImage: {
    width: 60,
    height: 60
  },
  moiGioiName: {
    fontSize: 13,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: 'black'
  },
  moiGioiNumberOfAds: {
    fontSize: 13,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: 'black'
  },
  moiGioiButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  moiGioiChatButton: {
    backgroundColor: 'transparent',
    color: '#EA9409',
    borderColor: '#EA9409',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15,
    textAlign: 'center',
    borderWidth: 2,
    borderRadius: 5,
    padding: 5,
    paddingTop: 3,
    paddingBottom: 0
  },
  moiGioiCallButton: {
    backgroundColor: 'transparent',
    color: '#FB0007',
    borderColor: '#FB0007',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15,
    textAlign: 'center',
    borderWidth: 2,
    borderRadius: 5,
    marginLeft: 5,
    padding: 5,
    paddingTop: 3,
    paddingBottom: 0
  },
  shareButton: {
    paddingLeft: 10,
    marginTop: 24,
    paddingRight: 5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  backButton: {
    paddingLeft: 15,
    paddingRight: 15,
    marginTop: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  circleContainer: {
    marginTop: 0,
    marginBottom: 0,
    marginRight: 10,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#A8A8A8'
  },
    circleContainer2: {
        marginTop: -7,
        marginBottom: 0,
        marginRight: 10,
        backgroundColor: '#A8A8A8'
    },
  shareIcon: {
    marginTop: 5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  shareLeft: {
    width: width-80,
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: 8,
    marginBottom: 8
  },
  shareRight: {
    alignItems: 'flex-end',
    marginTop: 8,
    marginBottom: 8
  },
  welcome: {
      marginTop: -50,
      marginBottom: 50,
      fontSize: 17,
      textAlign: 'center',
      margin: 10,
  },
  linearGradient: {
    flexGrow: 1,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor : "transparent"
  },
  mainView: {
    flexGrow: 1,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor : "transparent"
  },
  scrollView: {
    flexGrow: 1,
    position: 'absolute',
    height: height-44
    // height: height
  },
  fullWidthContainer: {
    flexGrow: 1,
      alignItems: 'stretch',
      backgroundColor: 'white',
  },
  searchContent: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  searchDetailRowAlign: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-around',
  },
  chiTietText: {
      marginBottom: 8,
      marginLeft: 20
  },
  shareMainView: {
      flexDirection: 'row'
  },
  headerContainer: {
    borderBottomColor: '#D7D7D7',
    borderBottomWidth: 0.5
  },
  customPageHeader: {
      position: 'absolute',
      top: 0,
      left: 0,
      width: width,
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      height: 64
  },
	search: {
      marginLeft: 20,
			marginTop: 20,
	    flexDirection: 'row',
	    alignItems: 'center',
			justifyContent: 'center',
			backgroundColor: 'transparent',
	},
  search2: {
      marginLeft: 10,
      marginTop: 28,
      marginRight: 5,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent',
  },
  wrapper: {
    marginTop: 0,
    marginBottom: 0
  },
  slide: {
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  dot : {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
    bottom: 32
  },
  dot2 : {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    marginTop: 11,
    marginLeft: 20,
    marginRight: 0,
    backgroundColor: '#C1C1C1'
  },
  dot3 : {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: 14,
    marginTop: 18,
    backgroundColor: 'white',
    borderWidth: 3.5
  },
  imgItem: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: width,
    height: imgHeight,
      alignSelf: 'auto'
  },
  searchMapView: {
    marginTop: 7,
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'center'
  },
  imgMapView: {
    width: mapWidth,
    height: mapHeight,
  },
  mapViewButton: {
    backgroundColor: 'transparent',
    width: mapWidth,
    // marginLeft: 20,
    // marginRight: 20
  },
  slideItem: {
    flexGrow: 1,
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    backgroundColor: 'transparent',
    marginTop: 8,
    paddingBottom: 15

  },
  price: {
    fontSize: 22,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    textAlign: 'left',
    backgroundColor: 'transparent',
    color: '#f33333',
    marginBottom: 8,
    marginLeft: 18.5,
    marginRight: 20,
  },
  textTitle: {
    fontSize: 17,
    fontFamily: gui.fontFamily,
    fontWeight: '600',
    textAlign: 'left',
    backgroundColor: 'transparent',
    color: 'black',
    marginBottom: 16,
    marginLeft: 20,
    marginRight: 22.5,
  },
  textHalfWidth: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 3,
    marginBottom: 4,
    marginLeft: 5,
    marginRight: 10,
    width: width/2-20
  },
  textHalfWidthBold: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: 'black',
    marginTop: 8,
    marginBottom: 8,
    marginLeft: 10,
    marginRight: 10,
    width: width/2-20
  },
  textHalfWidth2: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 3,
    marginBottom: 2,
    marginLeft: 10,
    marginRight: 9.5,
    width: width/2 - 55
  },
  textHalfWidthBold2: {
    textAlign: 'left',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color: 'black',
    marginTop: 3,
    marginBottom: 2,
    marginLeft: 10,
    marginRight: 9.5,
    width: width/2 + 17
  },
  textFullWidth: {
    textAlign: 'justify',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: 'black',
    marginTop: 8,
    marginBottom: 7,
    marginLeft: 0,
    marginRight: 0,
  },
  lineBorder: {
    // borderTopWidth: 1,
    // borderTopColor: 'rgba(220,220,220,0.6)',
    width: width - 44,
    marginLeft: 20
  },
  lineBorder2: {
    borderTopWidth: 0,
    borderTopColor: 'rgba(220,220,220,0.6)',
    width: width,
    marginLeft: 0,
    marginRight: 0
  },
  danDuongView: {
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'space-between',
    paddingTop: 8,
    marginBottom: 8
  },
  danDuongLeftView: {
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  danDuongRightView: {
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  danDuongText: {
    marginLeft: 10,
    fontSize: 15,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: 'black',
    textAlign: 'justify'
  },
    textTaiChinh: {
      textAlign: 'center',
      fontSize: 15,
      fontFamily: gui.fontFamily,
      color: gui.mainColor,
      fontWeight: '600',
      marginBottom: 8
    },
    viewListView: {
        flexGrow:1,
        backgroundColor:'white',
        marginTop:6,
        width: width - 37,
        // height: 142,
        marginRight: 37
    },
    viewListNhaGan: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    viewBdsCungLoai: {
        height: 'auto', //220,
        width: width,
        paddingLeft: 37,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewCungLoai: {
        // height: 221,
        width: width,
        marginBottom: 30,
        paddingLeft: 0,
        justifyContent: 'center',
        flexDirection: 'column'
    },
    viewTextTile: {
        marginTop: 11,
        height: 40,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: width - 92,
        height: 142,
        marginRight: 9
    },
    linearGradient2: {
        marginTop: 71,
        height: 71,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent",
        flexGrow: 1
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 8,
        right: 8,
        width: 35,
        height: 35,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 10
    },
    viewTextContent: {
        paddingTop: 8,
        marginTop: -71,
        marginLeft: 12,
        height: 71,
        width: 180
    },
    priceText: {
        fontSize: 13,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        paddingTop:1
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    },
    textTitleSuggest: {
        color   :'#000',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0,
    },
    viewImgDefault: {
      width: width,
      height: height/2 - 1,
      backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewImageBlank: {
        height: height/2,
        width: width
    },
    viewLoaderContent: {
        flex: 1,
        paddingLeft: 20,
        backgroundColor: 'transparent',
        justifyContent: 'flex-start',
        height: imgHeight,
        width: width
    },
    viewLineLoader: {
        height: 25,
        width: width/3,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
        marginTop: 16
    },
    viewLineLoader1: {
        height: 18,
        width: width*3/4,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
        marginTop: 10
    },
    tinCanMuaRowContent: {
        flex: 1,
        justifyContent:'center',
        width: width - 83,
        height: 142,
        flexDirection: 'row'
    },
    avatarContent: {
        height: 142,
        width: 90,
        justifyContent: 'center',
        alignItems: 'center'
    },
    avatarImage: {
        height: 60,
        width: 60,
        borderRadius: 5
    },
    tinCanMuaRowInfo: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: 10,
        paddingLeft: 0,
        paddingTop: 0
    },
    tinCanMuaLine1Text: {
        fontSize: 12,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: '#2C2C2E',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoTitleText: {
        fontSize: 15,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    tinCanMuaInfoText: {
        fontSize: 15,
        fontWeight: 'normal',
        textAlign: 'left',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily
    },
    separatedView: {
        height: 142,
        width: 9,
        backgroundColor: '#F0F0F2'
    },
    viewTabInterest: {
        flexGrow:1,
        flexDirection: 'row',
        paddingLeft: 5,
        paddingRight: 5
    },
    tabResultDetail: {
        borderTopRightRadius: 0,
        borderBottomRightRadius: 0,
        marginLeft: 10,
        marginRight: 0,
        borderRadius: 5,
        margin: 0,
        width: (width - 30)/3
    },
    tabNeedToBuy: {
        borderRadius: 0,
        margin: 0,
        width: (width - 30)/3,
        borderLeftWidth: 0,
        borderRightWidth: 0
    },
    tabNeedToReceive : {
        borderTopLeftRadius: 0,
        borderBottomLeftRadius: 0,
        marginLeft: 0,
        marginRight: 10,
        borderRadius: 5,
        margin: 0,
        width: (width - 30)/3
    },
    viewContent: {
        marginTop: 15,
        width: width - 37,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 18
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        // height: 80,
        width: width - 108,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 168,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewPlusPost: {
        height: 35,
        width: 35,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        // paddingRight: 21,
        marginTop: 22,
        marginLeft: 16
    },
    viewContentButton: {
        width: width,
        height: 56,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    buttonContact: {
        height: 40,
        width: (width - 60)/2,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 20
    },
    textCommon: {
        fontSize: 13,
        fontFamily:gui.fontFamily,
        color: "rgba(112,112,112,1)",
        fontWeight: '500'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupAdsDetail);
