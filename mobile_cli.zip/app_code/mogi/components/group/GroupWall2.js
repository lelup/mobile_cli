import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    StatusBar,
    ImageBackground,
    TextInput,
    ListView,
    TouchableHighlight,
    Alert,
    RefreshControl,
    FlatList,
    TouchableWithoutFeedback
} from 'react-native';

import Toast, { DURATION } from '../toast/Toast';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import FontAwesomeLight from '../font/FontAwesomeLight';
import OfflineBar from '../line/OfflineBar';
import { Actions } from 'react-native-router-flux';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';
// import AlphabetListView from 'react-native-alphabetlistview'
import SelectableSectionsListView from '../myalphabetlistview/SelectableSectionsListView'

import SearchBox from './SearchBox';
import ImagePreview from './ImagePreview';
import GiftedSpinner from "../GiftedSpinner";
import { Map } from 'immutable';
import DanhMuc from '../../assets/DanhMuc';
import FunctionModal from '../FunctionModal'

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import LinearGradient from 'react-native-linear-gradient';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
import RangeUtils from "../../lib/RangeUtils";
import UserModal from '../UserModal';

import apiUtils from '../../lib/ApiUtils';

import MHeartIcon from '../MHeartIcon';

import SearchInput from './SearchInputAgent';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as wallActions from '../../reducers/wall/wallActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions';
import * as searchActions from '../../reducers/search/searchActions';

import dismissKeyboard from 'react-native-dismiss-keyboard';

let { width, height } = utils.getDimensions();

let imageGroup = 188;

const ASPECT_RATIO = width / (height - 188);

const LATITUDE = 15.91246021276861;
const LONGITUDE = 105.7527299557314;
const LATITUDE_DELTA = 15.43258937437489;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

const actions = [
    globalActions,
    meActions,
    wallActions,
    inboxActions,
    chatActions,
    groupSearchActions,
    searchActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let ds_myGroup = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

class GroupWall2 extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        this.onFocus = this.onFocus.bind(this);
        this.onChangeText = this.onChangeText.bind(this);
        this._onSearchInputSubmitEditting = this._onSearchInputSubmitEditting.bind(this);
        let initDataToRender = this._prepareDataToRender(props.group.wallList)

        this.state = {
            loading: false,
            headerColor: 'transparent',
            backgroundInput: '#fff',
            microButtonColor: gui.colorMainBlur,
            backButtonColor: '#fff',
            inputBorderColor: 'transparent',
            textInputColor: gui.colorMainBlur,
            valuePost: '',
            loaded: false,
            countedRequest: false,
            textSearch: props.group.textSearch,
            pickedRow: {},
            pendingRequest: 0,
            wallList: props.group.wallList,
            isOpenMoreModal: false,
            isOpenFunctionModal: false,
            groupData: props.groupData,
            selectedPost: null,
            focused: false,
            dataToRender: initDataToRender,
            isOpenUserModal: false,
            userModalData: null
        }
    }

    componentWillMount() {
        // setTimeout(() => this.getAllMembers(), 200);
        this.getAllMembers()
        // this.getPendingRequest();
    }

    getAllMembers() {
        this.props.actions.getAllMember(
            { 'groupID': this.props.groupID }
            , (res) => {
                // log.info('server respond data getAllMember: =====>>>>>', res);
                let pendingRequest = res.data.filter((e) => { return e.status == 1 });
                this.setState({ pendingRequest: pendingRequest.length })
            }
            , (error) => {
                //log.info('server respond error: =====>>>>>', error)
            });
        setTimeout(() => this.props.actions.onWallFieldChange('fetchingPendingRequest', false), 200)
    }

    componentDidMount() {
        StatusBar.setBarStyle('default');
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.wall.requestList !== this.props.wall.requestList) {
            this.setState({ pendingRequest: nextProps.wall.requestList.length });
        }

        if (nextProps.wall.wallList !== this.props.wall.wallList) {

            let dataToRender = this._prepareDataToRender(nextProps.wall.wallList)
            this.setState({
                wallList: nextProps.wall.wallList,
                dataToRender: dataToRender
            })
        }

        // if (nextProps.wall.textSearch !== this.props.wall.textSearch) {
        //     this.setState({ textSearch: nextProps.wall.textSearch });
        // }

        if (nextProps.groupData !== this.props.groupData) {
            this.setState({ groupData: nextProps.groupData });
        }
    }

    fetchData() {
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.setState({ 'pendingRequest': 0 });
        // this.props.actions.onGroupFieldChange('requestList', [])
        this.props.actions.onWallFieldChange("pageNo", 1);
        let textSearch = this.state.textSearch ? this.state.textSearch.trim() : '';
        this.props.actions.getNextWall(
            {
                'groupID': [this.props.groupID],
                'limit': this.props.wall.limit,
                'pageNo': 1,
                'textSearch': textSearch,
            }
            , (res) => {
                // log.info('getNextWall: =====>>>>>', res)
                this.props.actions.getPendingRequest(
                    { 'groupID': this.props.groupID }
                    , (res) => {
                        // log.info('pendingRequest: =====>>>>>', res)
                        this.setState({ pendingRequest: res.data.length })
                    }
                    , (error) => {
                        // this.setState({ countedRequest: true });
                        this._updateMessageProcessing(error, '#fa4916', 'white');
                    });
                setTimeout(() => this.props.actions.onWallFieldChange('fetchingPendingRequest', false), 200);
            }
            , (error) => {
                // this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
    }

    getPendingRequest() {
        this.setState({ 'pendingRequest': 0 });
        this.props.actions.getPendingRequest(
            { 'groupID': this.props.groupID }
            , (res) => {
                this.setState({ pendingRequest: res.data.length })
            }
            , (error) => {
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
        setTimeout(() => this.props.actions.onWallFieldChange('fetchingPendingRequest', false), 200)
    }

    _prepareDataToRender(data) {

        let dataToRender = {};

        //prepare header section
        dataToRender['headerSection'] = [{ header: 'header' }];

        //prepare content section
        let sectionData = [];
        sectionData.push({
            meta: 'groupinfo', groupData: this.props.groupData, groupID: this.props.groupID,
            loadLastSearchFilter: this._loadLastSearchFilter.bind(this)
        })
        sectionData.push({ meta: 'input' })

        data.forEach((e) => {
            sectionData.push(e)
        })
        dataToRender['contentSection'] = sectionData;

        return dataToRender;
    }

    _loadLastSearchFilter(groupID) {

        let region = {
            latitude: LATITUDE,
            longitude: LONGITUDE,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA
        };
        let viewport = apiUtils.getViewport(region);
        this.props.actions.onGroupSearchFieldChange("viewport", viewport);
        this.props.actions.onGroupSearchFieldChange("diaChinhViewport", viewport);
        this.props.actions.onGroupSearchFieldChange("center", {});

        let diaChinh = {
            fullName: gui.TAT_CA_KHU_VUC
        };

        this.props.actions.onGroupSearchFieldChange("diaChinh", diaChinh);

        this.props.actions.onGroupSearchFieldChange("circle", {});
        this.props.actions.onGroupCircleChange({});
        this.props.actions.onGroupSearchFieldChange("polygon", []);
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("loaiTin", 'ban');
        let defaultBan = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onGroupSearchFieldChange("ban", defaultBan);
        this.props.actions.onGroupSearchFieldChange("thue", defaultThue);
        this.props.actions.onGroupSearchFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onGroupSearchFieldChange("radiusInKmSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("huongNha", 0);
        this.props.actions.onGroupSearchFieldChange("ngayDaDang", '');
        this.props.actions.onGroupSearchFieldChange("hasImage", true);
        this.props.actions.onGroupSearchFieldChange("excludeMoiGioi", false);
        this.props.actions.onGroupSearchFieldChange("isFakeGeo", undefined);
        // }
    }

    _renderLoadingView() {
        if (this.props.wall.fetchingPendingRequest || this.props.wall.memberListLoading) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' />
            </View>)
        }
    }

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'wallList': [...this.props.wall.wallList, ...data],
            loaded: true
        });

        let dataToRender = this._prepareDataToRender([...this.props.wall.wallList, ...data])
        this.setState({
            dataToRender: dataToRender
        })
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderBar()}
                {this._renderBodyMyGroup()}

                {this.props.wall.showImagePreview ? this._renderImagePreviewModal(this.state.pickedRow) : null}
                {this._renderLoadingView()}
                {this._openMoreModal()}
                {this._openFunctionModal()}
                {this._openGroupWallUserModal()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        );
    }

    _onMoreButtonPress(data) {
        this.setState({ isOpenMoreModal: true });
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        let currentUser = this.props.global.currentUser;
        let modalHeight = currentUser.userID == this.state.groupData.userID ? 173 : 120;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {

        let currentUser = this.props.global.currentUser;

        let items = []

        if (currentUser.userID == this.state.groupData.userID) {
            items.push({ _text: 'Sửa sàn', _function: () => this._onEditGroupPress() })
            items.push({ _text: 'Xóa sàn', _function: () => this._onDeleteGroupPress() })
        } else {
            items.push({ _text: 'Rời khỏi sàn', _function: () => this._onLeaveGroupPress() })
        }

        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outMoreModal.bind(this)} />
        )
    }

    _onFunctionButtonPress(data) {
        this.setState({ isOpenFunctionModal: true, selectedPost: data });
    }

    _outFunctionModal() {
        this.setState({
            isOpenFunctionModal: false
        });
    }

    _openFunctionModal() {
        let currentUser = this.props.global.currentUser;
        let selectedPost = this.state.selectedPost;
        let modalHeight = selectedPost && selectedPost.userID == currentUser.userID ? 233 : 173;
        return (
            <Modal isOpen={this.state.isOpenFunctionModal}
                onClosed={this._outFunctionModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderFunctionContent()}
            </Modal>
        );
    }

    _renderFunctionContent() {
        let selectedPost = this.state.selectedPost;
        let items = [];
        let currentUser = this.props.global.currentUser;
        let textModal1 = 'Xóa bài viết và giữ chia sẻ BĐS trên kho hàng';
        let textModal2 = 'Xóa bài viết và BĐS khỏi kho hàng';

        if (selectedPost && selectedPost.userID == currentUser.userID) {
            if (selectedPost.ads.length > 0) {
                // mainItems = <View style={[styles.viewSwipeButton, { height: 154 }]}>
                //     <TouchableOpacity onPress={this._onEditPostPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                //         <Text style={[styles.textMoreButton, { fontSize: 15 }]}>Sửa bài viết</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     <TouchableOpacity onPress={this._onDeletePostPress.bind(this, true)} style={[styles.viewButtonModal, styles.modalButton1]}>
                //         <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal1}</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, styles.modalButton2]}>
                //         <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal2}</Text>
                //     </TouchableOpacity>
                // </View>
                items.push({ _text: 'Sửa bài viết', _function: () => this._onEditPostPress() })
                items.push({ _text: textModal1, _function: () => this._onDeletePostPress(true) })
                items.push({ _text: textModal2, _function: () => this._onDeletePostPress(false) })
            }
            else {
                // mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>
                //     <TouchableOpacity onPress={this._onEditPostPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                //         <Text style={styles.textMoreButton}>Sửa bài</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                //         <Text style={styles.textMoreButton}>Xóa bài</Text>
                //     </TouchableOpacity>
                // </View>
                items.push({ _text: 'Sửa bài', _function: () => this._onEditPostPress() })
                items.push({ _text: 'Xóa bài', _function: () => this._onDeletePostPress(false) })
            }
        } else {
            if (selectedPost && currentUser.userID == this.state.groupData.createdBy) { //la admin
                // mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>
                //     <TouchableOpacity onPress={this.onChat.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                //         <Text style={styles.textMoreButton}>Chat với người đăng</Text>
                //     </TouchableOpacity>
                //     <FullLine />
                //     {selectedPost.ads.length > 0
                //         ?
                //         (
                //             <View>
                //                 <TouchableOpacity onPress={this._onDeletePostPress.bind(this, true)} style={[styles.viewButtonModal, styles.modalButton1]}>
                //                     <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal1}</Text>
                //                 </TouchableOpacity>
                //                 <FullLine />
                //                 <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, styles.modalButton2]}>
                //                     <Text style={[styles.textMoreButton, { fontSize: 15 }]}>{textModal2}</Text>
                //                 </TouchableOpacity>
                //             </View>)
                //         :
                //         <TouchableOpacity onPress={this._onDeletePostPress.bind(this, false)} style={[styles.viewButtonModal, styles.modalButton2]}>
                //             <Text style={styles.textMoreButton}>Xóa bài</Text>
                //         </TouchableOpacity>
                //     }
                // </View>
                items.push({ _text: 'Chat với người đăng', _function: () => this.onChat() })
                if (selectedPost.ads.length > 0) {
                    items.push({ _text: textModal1, _function: () => this._onDeletePostPress(true) })
                    items.push({ _text: textModal2, _function: () => this._onDeletePostPress(false) })
                } else {
                    items.push({ _text: 'Xóa bài', _function: () => this._onDeletePostPress(false) })
                }
            } else {
                // mainItems = <View style={[styles.viewSwipeButton, { height: 155 }]}>
                //     <TouchableOpacity onPress={this.onChat.bind(this)} style={[styles.viewButtonModal]}>
                //         <Text style={styles.textMoreButton}>Chat với người đăng</Text>
                //     </TouchableOpacity>
                // </View>
                items.push({ _text: 'Chat với người đăng', _function: () => this.onChat(true) })
            }
        }


        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this._outFunctionModal.bind(this)} />
        )


    }

    _onEditGroupPress() {
        let selectedGroup = this.state.groupData;
        if (!selectedGroup) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        if (userID != selectedGroup.createdBy) {
            Alert.alert('Thông báo', 'Bạn không phải là quản trị của sàn \'' + selectedGroup.name + '\' ?');
            return;
        }
        this.props.actions.onGroupFieldChange('groupID', selectedGroup.groupID);
        this.props.actions.onGroupFieldChange('name', selectedGroup.name);
        this.props.actions.onGroupFieldChange('groupType', selectedGroup.groupType);
        this.props.actions.onGroupFieldChange('chiTiet', selectedGroup.chiTiet);
        this.props.actions.onGroupFieldChange('photos', selectedGroup.image ? [{ uri: selectedGroup.image }] : []);
        this.props.actions.onGroupFieldChange('allDiaChinh', selectedGroup.diaBan);
        Actions.Group({ doAfterSaveGroup: this._outMoreModal.bind(this), doRefreshGroupInfo: this._doRefreshGroupInfo.bind(this) });
        this._outMoreModal();
    }

    _onEditPostPress() {
        let selectedPost = this.state.selectedPost;
        // log.info('_onEditPostPress ******', selectedPost)
        if (!selectedPost) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let images = []
        if (selectedPost.image && selectedPost.image.length > 0)
            selectedPost.image.forEach((e) => {
                images.push({ uri: e })
            })

        let wallContent = {
            postID: selectedPost.id,
            postContent: selectedPost.content,
            postWallPhotos: images,
            postWallAds: selectedPost.adsList ? selectedPost.adsList[0] : (selectedPost.wtoList ? selectedPost.wtoList[0] : {})
        }
        Actions.GroupPostAds({ owner: 'GroupWall', groupData: this.state.groupData, groupID: this.props.groupID, wallContent: wallContent, scrollToTop: this._scrollToTop.bind(this) });
        this._outFunctionModal();
    }

    _doRefreshGroupInfo(groupData) {
        if (groupData) {
            this.setState({ groupData: groupData })
        }
    }

    _onDeleteGroupPress() {
        let selectedGroup = this.state.groupData;
        if (!selectedGroup) {
            return;
        }
        Alert.alert('Thông báo', 'Bạn muốn xóa sàn \'' + selectedGroup.name + '\' ?',
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedGroup.groupID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.deleteGroup(groupID, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            } else {
                                let userID = this.props.global.currentUser.userID || undefined;
                                // this.props.actions.onRefreshGroupInbox(userID);
                            }
                        });
                    this._outMoreModal();
                    Actions.pop();
                }
            }
            ]);
        // Actions.GroupMain();
    }


    _onDeletePostPress(keepShareAds) {
        let selectedPost = this.state.selectedPost;
        if (!selectedPost) {
            return;
        }
        let alertMsg = selectedPost.ads.length > 0
            ? (keepShareAds ? 'Bạn muốn xoá bài viết và giữ chia sẻ BĐS trên kho hàng?' : 'Bạn muốn xoá bài viết và BĐS khỏi kho hàng?')
            : 'Bạn muốn xoá bài viết'
        Alert.alert('Thông báo', alertMsg,
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let postID = selectedPost.id;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.deletePost({ postID: postID, keepShareAds: keepShareAds }, token)
                        .then(res => {
                            if (res.status != 0) {
                                Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                            }
                            else {
                                setTimeout(() => Alert.alert("Thông báo", "Xoá bài viết thành công.", [{
                                    text: 'Đóng', onPress: () => {
                                        let textSearch = this.state.textSearch ? this.state.textSearch.trim() : '';
                                        this.props.actions.onWallFieldChange("pageNo", 1);
                                        this.props.actions.getNextWall(
                                            {
                                                'groupID': [this.props.groupID],
                                                'limit': this.props.wall.limit,
                                                'pageNo': 1,
                                                'textSearch': textSearch
                                            }
                                            , (res) => {
                                                // log.info('server respond data: =====>>>>>', res)
                                                // this.refreshRowData(res.data)
                                            }
                                            , (error) => {
                                                this.setState({ loaded: true });
                                                this._updateMessageProcessing(error, '#fa4916', 'white');
                                            });
                                    }
                                }]), 1000);
                            }
                        });
                    this._outFunctionModal();
                }
            }
            ]);
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn rời khỏi sàn ?');
    }

    _doLeaveOrCall(title) {

        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = this.props.groupID;
                    let userID = this.props.global.currentUser.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.leaveGroup({ groupID: groupID, userID: userID }, token);
                    this._outMoreModal();
                    Actions.pop();
                }
            }
            ]);
        // Actions.GroupMain();
    }

    _renderContentMembers() {
        let group = this.state.groupData;
        let groupName = group && group.name || '';
        // let countMember = group && group.countMember || 0;
        let countMember = this.props.wall.memberList.length;
        let textMember = group.groupType == 'private' ? `Nhóm riêng tư - ${countMember} thành viên`
            : `Nhóm công khai - ${countMember} thành viên`;
        return (
            <View style={styles.viewStyleMembers}>
                <TouchableOpacity style={styles.viewContentMembers}
                    onPress={this._onMoreButtonPress.bind(this)}
                    opacity={1}
                >
                    <View>
                        <View style={styles.viewNameMain}>
                            <View style={styles.viewGroupTop}>
                                <Text style={[styles.textCommon, { fontWeight: '500', fontSize: 18, color: gui.textAgentSolid }]} numberOfLines={2}>{groupName}</Text>
                            </View>
                            <View style={styles.viewIconMember}>
                                <MaterialCommunityIcons name="chevron-down" size={26} color={gui.mainTextColor} />
                            </View>
                        </View>
                        <Text style={[styles.textCommon, { fontSize: 12, color: gui.textShare }]} numberOfLines={1}>{textMember}</Text>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _renderListAvatarMemmber() {
        let index = -1;
        let allGroupAvt = this.props.wall.memberList.filter((one) => {
            let valid = true;
            if (valid) {
                index++;
            }
            return valid && index < 6;
        }) || [];
        if (allGroupAvt.length == 0) return null;
        return (
            <View style={styles.viewListMembers}>
                <FlatList
                    data={allGroupAvt}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRowAvatarMembers(data.item)}
                    initialListSize={25}
                    ListFooterComponent={this.listFooterComponent()}
                    removeClippedSubviews={false}
                    contentContainerStyle={styles.viewListAvatar}
                    horizontal={true}
                    enableEmptySections={true}
                    showsHorizontalScrollIndicator={false}
                    showsVerticalScrollIndicator={false}
                />
            </View>
        )
    }

    _renderRowAvatarMembers(data) {
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let imageEachInbox = data.thumbnail ? { uri: data.thumbnail } : (data.avatar ? { uri: data.avatar } : defaultAvatar);
        return (
            <TouchableOpacity onPress={this._onMemberPress.bind(this)}>
                <Image style={styles.myAvatarInbox}
                    source={imageEachInbox}
                    defaultSource={defaultAvatar}
                />
            </TouchableOpacity>
        )
    }

    listFooterComponent() {
        let memberList = this.props.wall.memberList;
        return (
            <TouchableOpacity
                style={styles.viewTouchMoreAvt}
                onPress={this._onMemberPress.bind(this)}
            >
                {memberList && memberList.length > 6 ?
                    (<View style={styles.moreAvtDot}>
                        <MaterialIcons name="more-horiz" size={15} color={"#fff"} />
                    </View>) : null
                }
                <View style={styles.viewAddMember}>
                    <MaterialCommunityIcons name="plus" size={15} color={"#fff"} />
                    <Text style={[styles.textCommon, { color: '#fff', marginLeft: 3, fontSize: 12 }]}>THÊM</Text>
                </View>
            </TouchableOpacity>
        )
    }

    _renderHeaderBar() {

        return (
            <View style={styles.viewHeaderWall}>
                <View style={[styles.customPageHeader]}>
                    <TouchableOpacity style={styles.viewBackMyGroup}
                        onPress={this._onPressBack.bind(this)}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} style={{ marginLeft: 8 }} />
                    </TouchableOpacity>
                    <View style={styles.inputMainView}>
                        <SearchInput
                            placeholder="Tìm trong sàn"
                            placeholderTextColor={gui.arrowColor}
                            textValue={this.state.textSearch}
                            searchContainer={{ marginRight: 0, marginTop: 3 }}
                            onChangeText={this.onChangeText.bind(this)}
                            onFocus={this.onFocus.bind(this)}
                            showCloseButton={this.state.focused && this.state.textSearch != ''}
                            onSubmitEditing={() => this._onSearchInputSubmitEditting}

                        />
                    </View>
                </View>
            </View>
        );
    }


    onFocus() {
        !this.state.focused && this.setState({ focused: true });
    }

    _onSearchInputSubmitEditting() {
        dismissKeyboard();
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.setState({ 'pendingRequest': 0 });
        // this.props.actions.onGroupFieldChange('requestList', [])
        this.props.actions.onWallFieldChange("pageNo", 1);
        let textSearch = this.props.wall.textSearch ? this.props.wall.textSearch.trim() : '';
        this.props.actions.getNextWall(
            {
                'groupID': [this.props.groupID],
                'limit': this.props.wall.limit,
                'pageNo': 1,
                'textSearch': textSearch,
            }
            , (res) => {
            }
            , (error) => {
                // this.setState({ loaded: true });
                this._updateMessageProcessing(error, '#fa4916', 'white');
            });
    }
    //
    // _renderNewButtonGroups() {
    //     return (
    //         <View style={styles.viewNewButtonGroup}>
    //             <TouchableOpacity onPress={this._onGroupFilterPress.bind(this)}>
    //                 <View style={[styles.viewNewEachButton, { width: (width - 16) / 2 - 1 }]}>
    //                     <Text style={styles.textNewButtonGroup}>NGUỒN HÀNG</Text>
    //                 </View>
    //             </TouchableOpacity>
    //             <View style={styles.lineVertical} />
    //             <TouchableOpacity onPress={this._onGroupDetail.bind(this)}>
    //                 <View style={styles.viewNewEachButton}>
    //                     <Text style={styles.textNewButtonGroup}>THÔNG TIN</Text>
    //                 </View>
    //             </TouchableOpacity>
    //         </View>
    //     );
    // }

    _renderNewRequest() {

        if (this.state.pendingRequest == 0)
            return (<View style={{ marginTop: 0 }} />);
        return (
            <TouchableOpacity style={styles.viewNewRequest}
                onPress={this._onPressNewRequest.bind(this)}
            >
                <Text style={[styles.textBottonGroup, { color: '#fff' }]}>{this.state.pendingRequest} yêu cầu tham gia mới</Text>
            </TouchableOpacity>
        );
    }

    _renderBodyMyGroup_old() {
        return (
            <View style={styles.scrollView}>
                {this._renderListGroupWall()}
            </View>
        )
    }

    _scrollToTop() {
        // this._listView.scrollToSection('headerSection');
        this._listView.scrollToTop();
    }

    _renderBodyMyGroup() {
        let data = this.state.dataToRender;

        if (data && Object.keys(data).length > 0)
            return (
                <View style={styles.alphabetListView}>
                    <SelectableSectionsListView
                        ref={(listView) => { this._listView = listView; }}
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        refreshControl={
                            <RefreshControl
                                refreshing={false}
                                onRefresh={this._onRefresh.bind(this)}
                            />
                        }

                        data={data}
                        cell={Cell}
                        cellProps={{
                            renderRowGroupWall: (value) => this._renderRowGroupWall(value),
                            renderHeaderContent: () => this._renderHeaderContent(),
                            renderNewButtonGroups: () => this._renderNewButtonGroups(),
                            renderPostSource: () => this._renderPostSource(),
                        }}
                        cellHeight={33}
                        sectionListItem={SectionItem}
                        sectionHeader={SectionHeader}
                        sectionHeaderHeight={33}
                        style={styles.listContent}
                        contentContainerStyle={{ paddingBottom: 0 }}
                        onEndReached={this.loadNextPage.bind(this)}
                    />
                </View>
            );
        else return null;
    }

    _renderPostSource() {
        let imgUrl = this.props.global.currentUser.thumbnail;
        let imageMyPost = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!imgUrl) {
            imageMyPost = defaultAvatar;
        }
        return (
            <View style={styles.postSourceStyle}>
                <View style={styles.viewPostSource}>
                    <Image
                        resizeMode={"cover"}
                        source={imageMyPost}
                        defaultSource={defaultCover}
                        style={styles.myAvatarPost} />
                    <TouchableOpacity style={styles.viewTextInputPost} onPress={this._onPostWall.bind(this)}>
                        <Text style={[styles.textInputPost, { color: gui.textAgentSolid }]}>Chia sẻ thông tin…</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _refreshGroupPostAds() {

        let emptyDto = {
            postID: null,
            postContent: '',
            postWallPhotos: [],
            postWallAds: {}
        }
        this.props.actions.onWallAllFieldChange(emptyDto);
    }

    _onPostWall() {
        // this._refreshGroupPostAds();
        let wallContent = {
            postID: null,
            postContent: '',
            postWallPhotos: [],
            postWallAds: []
        }
        Actions.GroupPostAds({
            owner: 'GroupWall', groupData: this.state.groupData, groupID: this.props.groupID,
            wallContent: wallContent, scrollToTop: this._scrollToTop.bind(this)
        });
    }

    _onChangeText(text) {
        this.setState({
            valuePost: text
        })
    }

    _onMemberPress() {
        this.props.actions.getAllMember(
            { 'groupID': this.props.groupID }
            , (res) => {
                // console.log('server respond data: =====>>>>>', res)                                
                Actions.GroupMember({ groupData: this.state.groupData, groupID: this.props.groupID });
            }
            , (error) => {
            });

    }

    _onGroupDetail() {
        Actions.GroupDetail2({ groupData: this.state.groupData, groupID: this.props.groupID, owner: 'GroupWall' });
    }

    _onGroupFilterPress() {
        Actions.GroupFilterResult({ groupData: this.state.groupData, groupID: this.props.groupID });
    }

    _onPressAdsRow(ads) {
        Actions.GroupAdsDetail({ adsID: ads.id || ads.adsID, imageDetail: ads.image.cover, owner: 'GroupWall' });
    }

    _onPressWto(data) {
        if (!data.phone) {
            this.props.actions.getUserInfo(data.userID)
                .then(res => {
                    if (res.status != 0) {
                        Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                    } else {

                        if (res.userInfo) {
                            data.phone = res.userInfo.phone
                            data.email = res.userInfo.email
                            data.fullName = res.userInfo.fullName
                            data.avatar = res.userInfo.avatar
                        }

                        Actions.AgentWtoDetail({ data: data });
                    }
                });
        } else Actions.AgentWtoDetail({ data: data });
    }

    _renderListGroupWall() {
        return (
            <View style={{ flex: 1 }}>
                <FlatList
                    refreshControl={
                        <RefreshControl
                            refreshing={false}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                    ref={(ref) => this.scrollView = ref}
                    data={this.props.wall.wallList}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(data) => this._renderRowGroupWall(data.item)}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                    onEndReachedThreshold={200}
                    ListHeaderComponent={this._renderHeaderContent()}
                    removeClippedSubviews={false}
                    enableEmptySections
                    style={styles.listContent}
                    contentContainerStyle={{ paddingBottom: 70 }}
                    onEndReached={this.loadNextPage.bind(this)}
                />
            </View>
        );
    }

    _renderHeaderContent() {
        let group = this.state.groupData;
        let mySourceImg = group && group.image || '';
        let imageUriGroup = { uri: mySourceImg };
        let defaultCover = require('../../assets/image/photo_detail_blank.jpg');
        if (!mySourceImg) {
            imageUriGroup = defaultCover;
        }
        let userID = this.props.global.currentUser.userID;
        let showNewRequest = (userID == group.userID);
        return (
            <View style={{ marginBottom: 0 }} >
                <ImageBackground style={styles.imgItemHeader}
                    source={imageUriGroup}
                    defaultSource={defaultCover}
                    resizeMode={"cover"}
                >
                </ImageBackground>
                <FullLine />
                {this._renderContentMembers()}
                {this._renderListAvatarMemmber()}
                <View style={{ width: width, height: 6, backgroundColor: gui.newLineFacebook }} />
                {showNewRequest ? this._renderNewRequest() : null}
                {/* {this._renderNewButtonGroups()} */}
                {/* {this._renterPostSource()} */}
            </View>
        );
    }

    _onRefresh() {
        this.fetchData();
    }

    // onChangeText(value) {
    //     this.props.actions.onGroupFieldChange("textSearch", value);
    //     this.setState({ textSearch: value });
    // }

    onChangeText = async (text) => {
        this.currentText = text;

        let pre = text;

        await this.setState({
            textSearch: text
        });

        await setTimeout(() => {
            if (pre == this.currentText) {
                // this.props.actions.onWallFieldChange("textSearch", text);

                let deviceID = this.props.global.deviceInfo.deviceID || undefined;
                let userID = this.props.global.currentUser.userID || undefined;
                                                
                let textSearch = this.state.textSearch ? this.state.textSearch.trim() : '';
                this.props.actions.getNextWall(
                    {
                        'groupID': [this.props.groupID],
                        'limit': this.props.wall.limit,
                        'pageNo': 1,
                        'textSearch': textSearch,
                    }
                    , (res) => {
                        this.props.actions.onWallFieldChange("pageNo", 1);
                    }
                    , (error) => {
                        this.props.actions.onWallFieldChange("pageNo", 1);
                        this._updateMessageProcessing(error, '#fa4916', 'white');
                    });
            }
        }, 100);

    }

    onChat() {
        this._outFunctionModal();
        let data = this.state.selectedPost
        let partner = data.userID ? { userID: data.userID } : undefined;
        let chatTitle = data.fullName ? data.fullName : (data.fullNameChuSan ? data.fullNameChuSan : '');

        if (!partner) {
            Alert.alert("Thông báo", 'Có lỗi xảy ra. Không thể bắt đầu trò chuyện.', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);            
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
                this.setState({
                    isloadingPressRow: false
                })
            });
    }

    _renderRowGroupWall(value, isFirstRow, isLastRow) {
        // log.info('_renderRowGroupWall data to render =====>>>>>', value)
        let data = value;
        if (isFirstRow) {
            return data;
        }
        if (data.adsList && data.adsList.length > 0 && (data.adsList[0].id || data.adsList[0].adsID))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderAdsImagePost(data)}
                    {this._renderDetailPost(data)}
                </View>
            );
        if (data.wtoList && data.wtoList.length > 0 && (data.wtoList[0].id))
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderWtoPost(data)}
                    {this._renderCommentCount(data)}
                </View>
            );
        if (data.image && data.image.length > 0)
            return (
                <View style={styles.viewListMyGroup}>
                    {this._renderRowTopContent(data)}
                    {this._renderSimpleImagePost(data)}
                    {this._renderCommentCount(data)}

                </View>
            );
        return (
            <View style={styles.viewListMyGroup}>
                {this._renderRowTopContent(data)}
                {this._renderCommentCount(data)}

            </View>
        );
    }

    _renderWtoPost(data) {
        // log.info('===========> groupwal2 _renderRowWto',status);        
        if (data.wtoList && data.wtoList.length > 0) {
            data = data.wtoList[0];
        }

        return (
            <View style={styles.viewAdsWto}>
                <TouchableOpacity style={styles.viewRowPostWto} onPress={() => this._onPressWto(data)}>
                    {this._renderDetailWtoPost(data)}
                </TouchableOpacity>
            </View>
        )
    }

    _renderDetailWtoPost(data) {
        let priority = data.priority ? data.priority.toUpperCase() : '';
        let backGroudTypePost = !data.priority ? 'rgba(169,183,200,1)' : (data.priority == 'hot' ? 'rgba(255,81,81,1)' : (data.priority == 'warm' ? 'rgba(255,207,86,1)' : 'rgba(169,183,200,1)'))

        let diaChiFullname = utils.getTitleWtoDetail2(data.content);
        let giaNha = this._getGiaText(data);
        let areaValue = this.getDienTichText(data);
        let bedroomValue = data.content.soPhongNgu;
        let bathroomValue = data.content.soPhongTam;

        let huongNhaValue = data.content.huongNha && data.content.huongNha.length > 0 ? utils.getHuongNhaText(data.content.huongNha, 20) : DanhMuc.BAT_KY;
        let loaiTinText = data.content.loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = data.content.loaiNhaDat && data.content.loaiNhaDat.length > 0 ? utils.getLoaiNhaDatText(loaiTinText, data.content.loaiNhaDat) : DanhMuc.BAT_KY;
        let loaiNhaDatText = `Loại nhà đất: ${loaiNhaDat}`;

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue && huongNhaValue != DanhMuc.BAT_KY) {
            detailItems.push(this._renderHuongNha(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }

        let diaChiFullName = data.content.place.fullName || ' ';
        return (
            <View style={[styles.viewDetailPost2, { height: 'auto' }]}>
                <View style={styles.viewTieuDe}>
                    <View style={[styles.viewTypePost, { backgroundColor: backGroudTypePost }]}>
                        <Text style={styles.textTypePost}>{priority}</Text>
                    </View>
                    <View style={styles.viewTextTieuDe}>
                        <Text style={styles.textTieuDe} numberOfLines={1}>{diaChiFullname}</Text>
                    </View>
                </View>
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { fontWeight: '500' }]} numberOfLines={1}>{giaNha}</Text>
                </View>
                <View style={[styles.viewLabel, { marginTop: 6 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 48 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { color: gui.textPostCommon }]}>{diaChiFullName}</Text>
                    </View>
                </View>
                {
                    detailItems && detailItems.length > 0 ?
                        <View style={[styles.viewPercentDraft, { flexDirection: 'row' }]}>
                            {detailItems}
                        </View> : null
                }
                <View style={styles.viewPercentDraft}>
                    <Text style={[styles.textGiaNha, { color: '#898989' }]} numberOfLines={1}>{loaiNhaDatText}</Text>
                </View>
            </View>
        );
    }

    getDienTichText(wto) {
        let { content } = wto;
        let { dienTichTu, dienTichDen } = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        let dienTichTuFmt = utils.getDienTichDisplay(dienTichTu);
        let dienTichDenFmt = utils.getDienTichDisplay(dienTichDen);
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }


    _getGiaText(wto) {
        let { content } = wto;
        let { giaTu, giaDen, loaiTin } = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        let giaTuFmt = utils.getPriceDisplay(giaTu, loaiTin);
        let giaDenFmt = utils.getPriceDisplay(giaDen, loaiTin);
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _renderRowTopContent(data) {
        let userAvatar = { uri: data.avatar };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        if (!data.avatar) {
            userAvatar = defaultAvatar;
        }
        let textPromote = data.content || '';
        let nameMainUser = data.fullName || '';
        let timePost = utils.getDiffTime(data.timeModified) || '';


        return (
            <View style={styles.viewRowTopContent}>
                <View style={styles.viewMainUser}>
                    <Image
                        resizeMode={"cover"}
                        source={userAvatar}
                        defaultSource={defaultCover}
                        style={[styles.mainUserAvatar, { marginTop: 2 }]} />

                    <View style={{ width: width - 100, height: 34, marginLeft: 8, marginBottom: 0 }}>
                        <TouchableOpacity onPress={this._onGroupWallUserPress.bind(this, data)}>
                            <Text numberOfLines={1} style={[styles.textMainUser, { fontSize: 15, color: gui.textAgentSolid }]}>{nameMainUser}</Text>
                            <Text style={[styles.textMainMinute, { fontSize: 12 }]}>{timePost}</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity onPress={this._onFunctionButtonPress.bind(this, data)} style={styles.viewIconBubble}>
                        <FontAwesomeLight name="ellipsis-h" size={32} color={gui.moreColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>
                </View>
                <TouchableOpacity onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textSearch, { marginTop: 16, color: gui.textAgentSolid }]}>{textPromote}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _onGroupWallUserPress(data) {
        // log.info("========== _onGroupWallUserPress print user data ", data);
        this.setState({
            isOpenUserModal: true,
            userModalData: data
        })
    }

    _openGroupWallUserModal() {
        log.info("======== print _openGroupWallUserModal ", this.state.userModalData);
        return (
            <Modal isOpen={this.state.isOpenUserModal}
                onClosed={this.closeUserModal.bind(this)}
                style={styles.viewUserModal}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                <UserModal groupName={this.state.groupData && this.state.groupData.name ? this.state.groupData.name : ''}
                    data={this.state.userModalData}
                    onClosePress={this.closeUserModal.bind(this)}
                />
            </Modal>
        );
    }

    closeUserModal() {
        this.setState({
            isOpenUserModal: false,
            userModalData: null
        })
    }

    _renderAdsImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let adsCoverPhoto = { uri: ads.image ? ads.image.cover : '' };
        if (!ads.image || !ads.image.cover) {
            adsCoverPhoto = defaultCover;
        }
        let adsID = undefined;
        if (data.adsList && data.adsList.length > 0) {
            let ads = data.adsList[0];
            adsID = ads.id || ads.adsID;
        }

        return (
            <View style={styles.imageContentRow}>
                <ImageBackground style={[styles.imgItem, { height: gui.ADS_IMAGE_RATIO * width }]}
                    resizeMode={"cover"}
                    source={adsCoverPhoto} defaultSource={defaultCover}>
                    <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}>
                        <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                            style={styles.linearGradientMain}>
                            {this._renderUserLogo(data)}
                            {/*{this._renderNamePrice(data)}*/}
                            {this._renderLikeIcon(adsID)}
                        </LinearGradient>
                    </TouchableOpacity>
                </ImageBackground>
                <View style={[styles.lineDangNhap, { marginTop: 8, marginLeft: 8 }]} />
            </View>
        )
    }

    _renderLikeIcon(adsID) {
        let isLiked = this.isLiked(adsID);
        let color = isLiked ? '#E7E9EB' : 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : { opacity: 0.55 };

        if (this.props.search.uploadingLikedAds.uploading && this.props.search.uploadingLikedAds.adsID == adsID) {
            return (
                <View style={{ position: "absolute", left: width - 55, backgroundColor: 'transparent', top: 10 }}>
                    <View style={styles.heartButton}>
                        <GiftedSpinner size="small" color="white" />
                    </View>
                </View>
            )
        } else {
            return (
                <View style={{ position: "absolute", left: width - 75, backgroundColor: 'transparent', top: 10 }}>
                    <MHeartIcon onPress={() => this.onLike(adsID)} color={color} bgColor={bgColor} bgStyle={bgStyle} size={22}
                        mainProps={styles.heartButton} />
                </View>
            )
        }
    }

    isLiked(adsID) {
        const { adsLikes } = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            //this.props.actions.onAuthFieldChange('activeRegisterLoginTab',0);
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            }
        }
    }

    _updateLikeAdsProcessing(likeAdsMessage) {
        this._updateMessageProcessing(likeAdsMessage, '#166CA5', 'white');
    }

    _renderSimpleImagePost(data) {
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let imageCover = {};
        if (data.image && data.image.length > 0) {
            imageCover = data.image[0];
        }
        let adsCoverPhoto = { uri: imageCover };
        if (!imageCover) {
            adsCoverPhoto = defaultCover;
        }

        return (
            <View style={styles.imageContentRow}>
                <TouchableOpacity onPress={this._onImagePreviewPressed.bind(this, data)} underlayColor="transparent" >
                    <View>
                        <ImageBackground style={[styles.imgItem, { height: gui.ADS_IMAGE_RATIO * width }]}
                            resizeMode={"cover"}
                            source={adsCoverPhoto} defaultSource={defaultCover}>
                            <LinearGradient colors={['rgba(50, 50, 50, 0.15)', 'rgba(50, 50, 50, 0.3)']}
                                style={styles.linearGradientMain}>
                            </LinearGradient>
                            {this._renderTotalPhoto(data)}
                        </ImageBackground>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _renderImagePreviewModal(data) {
        if (!data)
            return null;

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image) {
            for (let i = 0; i < data.image.length; i++) {
                imageUrl = data.image[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }

        let userID = null;
        if (this.props.global.loggedIn) {
            let currentUser = this.props.global.currentUser;
            userID = currentUser && currentUser.userID;
        }
        return (
            <ImagePreview images={imageDataItems}
                closeModal={() => this.props.actions.onWallFieldChange('showImagePreview', false)} ads={data} userID={userID}
                loggedIn={this.props.global.loggedIn}
            />
        );
    }

    _renderTotalPhoto(data) {
        if (!data) {
            return null;
        }

        let imageDataItems = [];
        let hashLoadedImage = {};
        if (data.image) {
            for (let i = 0; i < data.image.length; i++) {
                imageUrl = data.image[i];
                if (hashLoadedImage[imageUrl]) {
                    continue;
                }
                imageDataItems.push(imageUrl);
                hashLoadedImage[imageUrl] = true;
            }
        }
        let total = imageDataItems.length;
        return (
            <View style={{
                position: 'absolute',
                bottom: 20,
                left: 16
            }}>
                <RelandIcon name="camera-o" color="#fff"
                    iconProps={{ style: styles.pagingIcon }} size={16}
                    textProps={styles.pagingText}
                    mainProps={styles.pagingView}
                    text={(total) + ' ảnh'}
                >
                </RelandIcon>
            </View>
        );
    }

    _onImagePreviewPressed(data) {
        if (!data.image) {
            return;
        }
        if (this.props.wall.showImagePreview) {
            return;
        }
        this.props.actions.onWallFieldChange('showImagePreview', true);
        this.setState({
            pickedRow: data
        });
    }



    loadNextPage() {
        let myProps = this.props.group;
        // log.info('props =======>>', myProps);

        if (myProps.loadingWall) {
            return;
        }

        let pageNo = myProps.pageNo;
        let totalPages = myProps.totalWallCount / myProps.limit;

        if (totalPages && pageNo < totalPages) {
            pageNo = pageNo + 1;
            this.props.actions.onWallFieldChange("pageNo", pageNo);
            let textSearch = this.props.wall.textSearch ? this.props.wall.textSearch.trim() : '';
            this.props.actions.getNextWall(
                {
                    'groupID': [this.props.groupID],
                    'limit': this.props.wall.limit,
                    'pageNo': pageNo,
                    'textSearch': textSearch
                }
                , (res) => {
                    // log.info('server respond data: =====>>>>>', res)
                    this.refreshRowData(res.data)
                }
                , (error) => {
                    this.setState({ loaded: true });
                    this._updateMessageProcessing(error, '#fa4916', 'white');
                });
        }
    }

    _renderPagination(index, total, context) {
        return (
            <View style={{
                position: 'absolute',
                bottom: 20,
                left: 20,
            }}>
                <RelandIcon name="camera-o" color="black"
                    iconProps={{ style: styles.pagingIcon }} size={16}
                    textProps={styles.pagingText}
                    mainProps={styles.pagingView}
                    text={(index + 1) + '/' + (total)}
                >
                </RelandIcon>
            </View>
        )
    }

    // _renderUserLogo(data) {
    //     var logoList = [];
    //     if (data.adsList && data.adsList.length > 0) {
    //         logoList = data.adsList[0].goiLogo;
    //     }
    //     var logos = logoList ? logoList.map((tag, index) => {
    //         let marginLeft = index == 0 ? 0 : 8;
    //         return (
    //             <View key={index} style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
    //                 <Text style={[styles.textSearch, { color: gui.mainTextColor }]}>{tag.text}</Text>
    //             </View>
    //         )
    //     }) : (<View></View>)

    //     return (
    //         <View style={styles.viewUserLogo}>{logos}</View>
    //     );
    // }

    _renderUserLogo(data) {
        let ads;
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let logoItems = [];
        let index = 0;

        if (ads && ads.banGap) {
            let marginLeft = index == 0 ? 0 : 8;
            let banGapText = ads.loaiTin ? DanhMuc.THUE_GAP : DanhMuc.BAN_GAP;
            logoItems.push(
                <View key={'logoBanGap'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{banGapText}</Text>
                </View>
            );
            index++;
        }


        if (ads && ads.chinhChuDangTin) {
            let marginLeft = index == 0 ? 0 : 8;
            logoItems.push(
                <View key={'logoChinhChuDangTin'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{DanhMuc.CHINH_CHU}</Text>
                </View>
            );
            index++;
        }

        return (
            <View style={styles.viewUserLogo}>
                {logoItems}
            </View>
        );
    }

    _renderNamePrice(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let imageChildUser = { uri: ads.avatar };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);
        let nameUserChild = ads.fullName;
        return (
            <View style={styles.viewNamePrice}>
                <View style={styles.viewPrice}>
                    <Text style={[styles.textNameGroup, { fontSize: 20 }]} numberOfLines={1}>{priceValue}</Text>
                </View>
                {/* <View style={styles.viewUserPostChild}>
                 <View style={styles.viewNameUserChild}>
                 <Text style={[styles.textNameChild, { color: '#fff' }]} numberOfLines={1}>{nameUserChild}</Text>
                 </View>
                 <Image
                 resizeMode={"cover"}
                 source={imageChildUser}
                 defaultSource={defaultCover}
                 style={styles.mainUserChild} />
                 </View> */}
            </View>
        );
    }

    _renderDetailPost(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let areaValue = utils.getDienTichDisplay(ads.dienTich);
        let bedroomValue = ads.soPhongNgu;
        let bathroomValue = ads.soPhongTam;
        let huongNha = ads.huongNha ? DanhMuc.HuongNha[ads.huongNha] : '';
        let addressValue = '';
        let textMotionValue = '';
        if (ads.place) {
            addressValue = ads.place.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail(ads);
        } else {

            addressValue = ads.diaChi;
            textMotionValue = ads.title || utils.getTitleAdsDetail2(ads);
        }
        let timePostValue = ads.ngayDangTin ? utils.formatDate(ads.ngayDangTin) : '';
        let commentCount = data.commentCount || 0;
        let commentValue = commentCount + ' Bình luận';

        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }

        if (!!huongNha) {
            detailItems.push(this._renderHuongNha(huongNha, (detailItems.length == 0) ? 0 : 12));
        }

        return (
            <View style={styles.viewDetailPost}>
                <TouchableOpacity onPress={this._onPressAdsRow.bind(this, ads)}
                    style={styles.viewTopDetail}
                >
                    <View style={styles.viewMainTextPost}>
                        <Text style={[styles.textMainPost, { color: gui.textAgentSolid }]} numberOfLines={2}>{textMotionValue}</Text>
                        <Text style={[styles.textTimePost, { color: gui.textComment, marginTop: 2 }]} numberOfLines={1}>{timePostValue}</Text>
                    </View>
                    <View style={styles.lineDangNhap} />
                    {this._renderGiaFmt(data)}
                    <View style={styles.viewTextAddress}>
                        <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
                        <Text style={[styles.textMainMinute, { marginLeft: 8, color: gui.textPostAds, fontSize: 15 }]} numberOfLines={1}>{addressValue}</Text>
                    </View>
                    {
                        detailItems && detailItems.length > 0 ?
                            <View style={styles.viewContentSource}>
                                {detailItems}
                            </View> : null
                    }
                </TouchableOpacity>
                <View style={styles.lineDangNhap} />
                <TouchableOpacity style={styles.viewLikeComment} onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textMainUser, { fontWeight: 'normal', color: gui.textComment }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{commentValue}</Text>
                    <View style={{ flexDirection: 'row' }}>
                        <FontAwesomeLight name="comment-alt" size={16} color={'rgba(70,70,70,1)'} noAction={true} iconOnly={true} mainProps={{ marginTop: 2 }} />
                        <Text style={[styles.textMainUser, { color: 'rgba(70,70,70,1)', marginLeft: 8 }]}>Bình luận</Text>
                    </View>
                </TouchableOpacity>
                {this._renderLastComment(data)}
            </View>
        )
    }

    _renderGiaFmt(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }
        let priceValue = utils.getPriceDisplay(ads.gia, ads.loaiTin);

        let giaFmt = `Giá: ${priceValue}`;
        return (
            <View style={styles.viewGiaFmt}>
                <Text style={styles.textPriceFmt}>{giaFmt}</Text>
            </View>
        );
    }


    _renderHuongNha(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="compass" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="bath" color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostAds}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostAds} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    _renderCommentCount(data) {
        let ads = {};
        if (data.adsList && data.adsList.length > 0) {
            ads = data.adsList[0];
        }

        let commentCount = data.commentCount || 0;
        let commentValue = commentCount + ' Bình luận';
        let viewsValue = data.viewsValue;

        return (
            <View style={styles.viewDetailPost}>
                <View style={styles.lineDangNhap} />
                <TouchableOpacity style={[styles.viewLikeComment]}
                    onPress={() => this._onPressComment(data)}>
                    <Text style={[styles.textMainUser, { fontWeight: 'normal', color: gui.textComment }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >
                        {commentValue}
                    </Text>
                    <View style={{ flexDirection: 'row' }}>
                        <FontAwesomeLight name="comment-alt" size={16} color={'rgba(70,70,70,1)'} noAction={true} iconOnly={true} mainProps={{ marginTop: 2 }} />
                        <Text style={[styles.textMainUser, { color: 'rgba(70,70,70,1)', marginLeft: 8 }]}>Bình luận</Text>
                    </View>
                </TouchableOpacity>
                {commentCount > 0 ? this._renderLastComment(data) : null}
            </View>
        )
    }

    _renderLastComment(data) {
        let lastComment = data.lastComment;
        if (lastComment) {
            let imageUserComment
            if (lastComment.createdByAvatar)
                imageUserComment = { uri: lastComment.createdByAvatar };
            else {
                imageUserComment = require('../../assets/image/register_avatar_icon.png');
            }
            let defaultCover = require('../../assets/image/register_avatar_icon.png');

            let nameUser = lastComment.createdByName ? lastComment.createdByName : '';
            let commentContent = lastComment.content ? lastComment.content : '';

            return (
                <View style={styles.viewLastComment}>
                    <View style={styles.lineDangNhap} />
                    <TouchableOpacity style={styles.viewRowComment}
                        onPress={() => this._onPressComment(data)}
                    >
                        <Image
                            resizeMode={"cover"}
                            source={imageUserComment}
                            defaultSource={defaultCover}
                            style={styles.mainUserAvatar} />
                        <View style={styles.viewContentComment}>
                            <Text style={[styles.nameUserComment, { color: gui.textAgentSolid }]} numberOfLines={1}>{nameUser}</Text>
                            <Text style={styles.textContentChat} numberOfLines={1}>{commentContent}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }
        else return (<View></View>)
    }


    _onPressComment(data) {
        this.props.actions.onWallFieldChange('watchingWallID', data.id)
        Actions.GroupComment({ parentContent: data, groupID: data.groupID, groupWallID: data.id, owner: 'GroupWall' });
    }

    _onPressBack = async () => {
        if (this.props.owner == 'MyAlert') {
            // Actions.MyAlert();
            Actions.pop();
            StatusBar.setBarStyle('default');
        } else {
            // await this.setState({ 'pendingRequest': 0 });
            // await this.props.actions.onGroupFieldChange('requestList', []);
            Actions.pop();
            StatusBar.setBarStyle('default');
        }
    }

    _onPressNewRequest() {
        Actions.GroupRequest({ groupData: this.state.groupData, groupID: this.props.groupID });
    }
}

class SectionHeader extends React.Component {

    constructor(props) {
        super(props);
    }

    _renderNewButtonGroups() {
        return (
            <View style={styles.viewNewButtonGroup}>
                <TouchableOpacity onPress={this._onGroupFilterPress.bind(this)}>
                    <View style={[styles.viewNewEachButton, { width: (width - 16) / 2 - 1 }]}>
                        <Text style={[styles.textNewButtonGroup, { color: gui.textAgentSolid }]}>NGUỒN HÀNG</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.lineVertical} />
                <TouchableOpacity onPress={this._onGroupDetail.bind(this)}>
                    <View style={styles.viewNewEachButton}>
                        <Text style={[styles.textNewButtonGroup, { color: gui.textAgentSolid }]}>THÔNG TIN</Text>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onGroupFilterPress() {

        let groupData = this.props.sectionData.filter((e) => { return e.meta == 'groupinfo' })[0].groupData;
        let groupID = this.props.sectionData.filter((e) => { return e.meta == 'groupinfo' })[0].groupID;
        let loadLastSearchFilter = this.props.sectionData.filter((e) => { return e.meta == 'groupinfo' })[0].loadLastSearchFilter;
        loadLastSearchFilter(groupID);
        setTimeout(() => Actions.GroupFilterResult({ groupData: groupData, groupID: groupID }), 500);
    }

    _onGroupDetail() {
        let groupData = this.props.sectionData.filter((e) => { return e.meta == 'groupinfo' })[0].groupData;
        let groupID = this.props.sectionData.filter((e) => { return e.meta == 'groupinfo' })[0].groupID;

        Actions.GroupDetail2({ groupData: groupData, groupID: groupID, owner: 'GroupWall' });
    }

    render() {
        let title = this.props.title;
        if (title == 'contentSection')
            return (
                this._renderNewButtonGroups()
            )
        else return null
    }
}

class SectionItem extends React.Component {
    render() {
        return null
    }
}

class Cell extends React.Component {
    render() {
        let data = this.props.item;
        // log.info('rendering cell **** ', data)
        if (data.header == 'header') {
            return this.props.renderHeaderContent();
        }
        else if (data.meta == 'groupinfo') return null;
        else if (data.meta == 'input') return this.props.renderPostSource();
        else return this.props.renderRowGroupWall(data);

    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        flexGrow: 1,
        position: 'absolute',
        height: height - 44,
        top: 44 + gui.marginTopAgent
    },
    viewListContainer: {
        paddingBottom: 50
    },
    linearGradient: {
        flexGrow: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    customPageHeader: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: width,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        height: 44,
        backgroundColor: '#fff',
    },
    inputMainView: {
        width: width - 48,
        height: 44,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewBackMyGroup: {
        height: 44,
        width: 40,
        justifyContent: 'center',
        paddingBottom: 5,
    },
    viewInputMyGroup: {
        height: 40,
        width: width - 112,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row',
        borderRadius: 2,
        borderWidth: 1
    },
    viewIconMicro: {
        width: 27,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextInput: {
        width: width - 118,
        height: 40,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    imgItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 16,
        height: imageGroup,
        alignSelf: 'auto',
        marginLeft: 8,
        marginRight: 8
    },
    imageContentRow: {
        width: width,
        height: gui.ADS_IMAGE_RATIO * width,
        backgroundColor: '#fff'
    },
    imgItemHeader: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: imageGroup,
        alignSelf: 'auto',
    },
    imgItem2: {
        width: width,
        height: imageGroup,
        alignSelf: 'auto'
    },
    viewNameGroup: {
        marginTop: 74,
        marginLeft: 16,
        // height: 36,
        width: width - 32,
        backgroundColor: 'transparent'
    },
    viewTotalMembers: {
        marginTop: 4,
        marginLeft: 16,
        height: 20,
        width: width - 180,
        backgroundColor: 'transparent'
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: '#fff',
        fontWeight: '500'
    },
    textTotalMembers: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: 'rgba(255,255,255,0.75)',
        fontWeight: 'normal'
    },
    linearGradient2: {
        marginTop: 0,
        height: imageGroup,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    linearGradientMain: {
        marginTop: 0,
        height: gui.ADS_IMAGE_RATIO * width,
        width: width - 16,
        marginLeft: 0,
        marginRight: 0,
        backgroundColor: "transparent"
    },
    viewButtonGroup: {
        width: width,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff'
    },
    viewNewButtonGroup: {
        width: width,
        height: 38,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderColor: gui.newLineFacebook
    },
    viewNewEachButton: {
        height: 36,
        width: (width - 16) / 2,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    textBottonGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: 'normal'
    },
    textNewButtonGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    sortDescIcon: {
        position: 'absolute',
        top: 14,
        right: 18
    },
    viewNewRequest: {
        height: 32,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    viewBodyMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    postSourceStyle: {
        height: 64,
        width: width,
        backgroundColor: gui.newLineFacebook,
        paddingTop: 6
    },
    viewPostSource: {
        height: 58,
        // marginLeft: 8,
        // marginRight: 8,
        width: width,
        flexDirection: 'row',
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center',
        // borderTopWidth: 1,
        // borderBottomWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)',
        // borderRadius: 2
    },
    myAvatarPost: {
        // width: 32,
        // height: 32,
        // borderRadius: 16,
        marginLeft: 8,
        height: 36,
        width: 36,
        borderRadius: 18

    },
    viewTextInputPost: {
        height: 38,
        backgroundColor: '#fff',
        width: width - 80,
        paddingLeft: 12,
        justifyContent: 'center'
    },
    textInputPost: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        color: gui.colorMainBlur
    },
    viewListMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 6, //8,
        backgroundColor: gui.groupBackground
    },
    viewRowTopContent: {
        // marginLeft: 8,
        // marginRight: 8,
        paddingTop: 16,
        paddingBottom: 12,
        paddingLeft: 8,
        paddingRight: 8,
        // borderWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)',
        // borderRadius: 2,
        // borderBottomWidth: 0,
        // borderBottomLeftRadius: 0,
        // borderBottomRightRadius: 0,
        backgroundColor: '#fff',
        width: width,
        height: 'auto'
    },
    viewMainUser: {
        height: 34, // 24
        width: width - 16, // 48
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    mainUserAvatar: {
        // height: 24,
        // width: 24,
        // borderRadius: 12
        height: 36,
        width: 36,
        borderRadius: 18
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostAds,
        marginLeft: 0, //8
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        marginLeft: 0
    },
    viewIconBubble: {
        position: 'absolute',
        right: 0,
        top: 0,
        width: 40,
        height: 30,
        alignItems: 'flex-end'
    },
    viewUserLogo: {
        position: 'absolute',
        left: 17,
        bottom: 17,
        height: 24,
        // width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 16, //23
        bottom: 13,
        height: 32,
        width: width - 46,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent'
    },
    viewUserPostChild: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    mainUserChild: {
        height: 26,
        width: 26,
        borderRadius: 13
    },
    viewNameUserChild: {
        height: 32,
        width: width - 48 - 24 - 8 - 16,
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundColor: 'transparent',
    },
    textNameChild: {
        fontSize: 12,
        color: '#fff',
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewDetailPost: {
        // height: 145,
        width: width,
        // paddingLeft: 8,
        // paddingRight: 8,
        justifyContent: 'flex-start',
        alignItems: 'center',
        // borderWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)',
        // borderRadius: 2,
        // borderTopWidth: 0,
        // borderTopLeftRadius: 0,
        // borderTopRightRadius: 0,
        backgroundColor: '#fff',
        height: 'auto'
    },
    viewTopDetail: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewMainTextPost: {
        // height: 39,
        width: width,
        paddingLeft: 8, //16
        paddingRight: 8,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
    },
    textMainPost: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 16,
        opacity: 0.8,
        // marginLeft: 8,
        // marginRight: 8
    },
    viewContentSource: {
        //height: 20,
        width: width, // 12?
        paddingLeft: 8,
        paddingRight: 8,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 8
    },
    viewTextAddress: {
        //height: 20,
        width: width,
        paddingLeft: 8,
        paddingRight: 8,
        // marginBottom: 6,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 2,
        marginBottom: 4
    },
    textTimePost: {
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    viewLikeComment: {
        height: 39,
        width: width,
        paddingLeft: 8,
        paddingRight: 8,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row'
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 3,
        bottom: 32
    },
    pagingText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#fff',
        marginRight: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingIcon: {
        borderRadius: 0,
        marginLeft: 10,
        marginBottom: 2,
        marginTop: 2
    },
    pagingView: {
        flexDirection: 'row',
        backgroundColor: '#5b5c61',
        borderRadius: 5,
        opacity: 0.75
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent',
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: height / 2 - 20,
        left: width / 2 - 20,
        width: 40,
        height: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    modalButton1: {
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
        alignItems: 'center',
        // paddingLeft: 12
    },
    modalButton2: {
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        alignItems: 'center',
        // paddingLeft: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewRowComment: {
        height: 60,
        width: width,
        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 8,
        flexDirection: 'row',
        marginBottom: 4
    },
    viewLastComment: {
        height: 61,
        width: width,
        alignItems: 'center'
    },
    myAvatarCommnent: {
        width: 32,
        height: 32,
        borderRadius: 16
    },
    viewContentComment: {
        justifyContent: 'center',
        marginLeft: 8,
        backgroundColor: '#f0f1f3',
        width: width - 16 - 24 - 8 - 12,
        height: 48,
        borderRadius: 12,
        paddingHorizontal: 8,
        paddingVertical: 8
    },
    viewNameComment: {
        justifyContent: 'center',
        width: width - 48 - 24 - 8 - 12,
        height: 18
    },
    viewDetailLastContent: {
        width: width - 48 - 24 - 8 - 12,
        height: 42
    },
    viewNameUser: {
        height: 20,
        width: width - 64,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        paddingLeft: 8
    },
    nameUserComment: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
    },
    timeMinuteComment: {
        fontSize: 12,
        color: gui.colorMainBlur,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        position: 'absolute',
        right: 0,
        top: 0
    },
    textContentChat: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
    },
    // listContent: {
    //     height: height - 50 - 44,
    //     width: width,
    //     backgroundColor: gui.lineFacebook
    // },
    listContent: {
        flex: 1
    },
    viewHeaderWall: {
        height: 44,
        width: width,
        marginTop: gui.marginTopAgent
    },
    viewStyleMembers: {
        height: 'auto',
        width: width,
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewContentMembers: {
        height: 'auto',
        width: width,
        backgroundColor: '#fff',
        paddingHorizontal: 32,
        paddingVertical: 8,
        alignItems: 'center'
    },
    textCommon: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        textAlign: 'center'
    },
    viewNameMain: {
        height: 'auto',
        width: width - 64,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center'
    },
    viewIconMember: {
        marginLeft: 2
    },
    viewGroupTop: {
        height: 'auto',
        width: width - 98,
    },
    viewListMembers: {
        height: 36,
        paddingHorizontal: 32,
        alignItems: 'center',
        width: width,
        backgroundColor: '#fff'
    },
    viewListAvatar: {
        height: 26,
        width: width - 64,
        backgroundColor: '#fff',
        justifyContent: 'center'
    },
    myAvatarInbox: {
        height: 26,
        width: 26,
        borderRadius: 13
    },
    viewEachInboxChild: {
        height: 26,
        width: 26,
        borderRadius: 13,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 5
    },
    viewTouchMoreAvt: {
        height: 26,
        width: 'auto',
        flexDirection: 'row'
    },
    moreAvtDot: {
        height: 26,
        width: 26,
        borderRadius: 13,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 5,
        backgroundColor: gui.mainAgentColor
    },
    viewAddMember: {
        width: 65,
        height: 26,
        borderRadius: 13,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 5,
        backgroundColor: gui.mainAgentColor,
        flexDirection: 'row'
    },
    lineVertical: {
        height: 26,
        width: 1,
        backgroundColor: 'rgba(211,211,211,0.5)',
    },
    alphabetListView: {
        flex: 1,
        backgroundColor: gui.newLineFacebook,
    },
    heartButton: {
        marginTop: 6
    },
    viewRowPostNormalWto: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff'
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    viewDetailPost2: {
        height: 65,
        width: width - 34,
        justifyContent: 'center',
        backgroundColor: '#fff',
        paddingLeft: 6
    },
    viewTieuDe: {
        flexDirection: 'row',
        width: width - 34 - 16,
        alignItems: 'center',
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewTypePost: {
        backgroundColor: gui.mainTextColor,
        paddingVertical: 3,
        paddingHorizontal: 6,
        borderRadius: 2
    },
    textTieuDe: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '500',
        color: gui.textPostAds,
        marginLeft: 9
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 14,
        fontWeight: 'normal',
        color: gui.textPostAds,
    },
    viewTextTieuDe: {
        height: 24,
        width: width - 62 - 32 - 16,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    viewAdsWto: {
        width: width,
        height: 'auto',
        backgroundColor: '#fff',
    },
    viewRowPostWto: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingRight: 8,
        paddingTop: 6,
        paddingBottom: 3,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        width: width - 16,
        height: 'auto',
        //marginTop: 8,
        marginBottom: 8,
        marginLeft: 8,
        marginRight: 8
    },
    viewUserModal: {
        justifyContent: 'flex-start',
        height: 'auto',
        backgroundColor: 'transparent',
        alignItems: 'center',
    },
    viewGiaFmt: {
        width: width,
        height: 28,
        paddingLeft: 8,
        justifyContent: 'flex-end',
    },
    textPriceFmt: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.textPostAds
    },

    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        width: width - 34,
        height: 20,
        backgroundColor: '#fff'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupWall2);
