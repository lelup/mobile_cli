import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    StatusBar,
    ImageBackground,
    TextInput,
    ListView,
    PanResponder,
    Easing,
    SegmentedControlIOS,
    Alert
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Actions } from 'react-native-router-flux';
import LinearGradient from 'react-native-linear-gradient';

import MapView from 'react-native-maps';

import PriceMarker from '../marker/PriceMarker';
import PriceMarker2 from '../marker/PriceMarker2';

import Modal from 'react-native-modalbox';

import GroupPlacesAutoComplete from './GroupPlacesAutoComplete';

import GroupSearchFilter from './GroupSearchFilter';

import CollapsiblePanelModal from '../CollapsiblePanelModal';

import * as Animatable from 'react-native-animatable';

import ScalableText from 'react-native-text';

import Slider from 'react-native-slider';

import LocationMarker from '../marker/LocationMarker';

import MHeartIcon from '../MHeartIcon';

import GiftedSpinner from "../GiftedSpinner";

var FlipView = require('../flip/FlipView');

import MMessage from '../message/MMessage';
import OfflineBar from '../line/OfflineBar';
var Analytics = require('react-native-firebase-analytics');

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';
import FontAwesomeLight from '../font/FontAwesomeLight';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();

import DanhMuc from '../../assets/DanhMuc';

import RangeUtils from "../../lib/RangeUtils";

import apiUtils from '../../lib/ApiUtils';

import CommonUtils from '../../lib/CommonUtils';

import findApi from '../../lib/FindApi';

var imageHeight = 143;

import Tag from './Tag';

import moment from 'moment';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import { Map } from 'immutable';

const actions = [
    globalActions,
    authActions,
    searchActions,
    groupSearchActions,
    postAdsActions
];

function createMarkerObject(item, duplicate) {
    let marker = {
        coordinate: { latitude: item.place.geo.lat, longitude: item.place.geo.lon },
        price: item.giaFmt,
        id: item.adsID,
        loaiTin: item.loaiTin,
        loaiNhaDat: item.loaiNhaDat,
        cover: item.image.cover,
        diaChi: item.place.diaChi,
        dienTich: item.dienTich,
        dienTichFmt: item.dienTichFmt,
        soPhongNguFmt: item.soPhongNguFmt,
        soTangFmt: item.soTangFmt,
        duplicate: duplicate,
        isFakeGeo: item.isFakeGeo
    };
    return marker;
}

function getAllUniquePosAds(listAds) {
    let dupCount = {};
    let markerList = [];
    let markerData = [];
    let dupMarker = {};
    if (listAds) {
        for (var i = 0; i < listAds.length; i++) {
            var item = listAds[i];
            if (item.place.geo && !isNaN(item.place.geo.lat) && !isNaN(item.place.geo.lon)) {
                let indexOfItem = markerData.findIndex((oldItem) =>
                    Math.abs(oldItem.place.geo.lat - item.place.geo.lat) <= PADDING
                    && Math.abs(oldItem.place.geo.lon - item.place.geo.lon) <= PADDING);
                if (markerData.length === 0 || indexOfItem === -1) {
                    dupCount[item.adsID] = 1;
                    markerData.push(item);
                    let marker = createMarkerObject(item, dupCount[item.adsID]);
                    markerList.push(marker);
                    dupMarker[item.adsID] = [marker];
                } else {
                    let validAdsId;
                    let oldMarker = markerList[indexOfItem];
                    if ((item.gia && item.gia != -1) && ((!markerData[indexOfItem].gia || markerData[indexOfItem].gia == -1)
                        || item.gia < markerData[indexOfItem].gia)) {
                        validAdsId = item.adsID;
                        let oldAdsId = oldMarker.id;
                        dupCount[validAdsId] = dupCount[oldAdsId] + 1;
                        markerData[indexOfItem] = item;
                        let marker = createMarkerObject(item, dupCount[validAdsId]);
                        dupMarker[validAdsId] = [];
                        dupMarker[validAdsId] = dupMarker[validAdsId].concat(dupMarker[oldAdsId]);
                        dupMarker[validAdsId].push(marker);
                        dupCount[oldAdsId] = 0;
                        dupMarker[oldAdsId] = [];
                        markerList[indexOfItem] = marker;
                        oldMarker.duplicate = dupCount[validAdsId];
                    } else {
                        validAdsId = oldMarker.id;
                        dupCount[validAdsId] = dupCount[validAdsId] + 1;
                        let marker = createMarkerObject(item, dupCount[validAdsId]);
                        dupMarker[validAdsId].push(marker);
                        oldMarker.duplicate = dupCount[validAdsId];
                    }
                }
            }
        }
    }
    return { markerData: markerData, markerList: markerList, dupCount: dupCount, dupMarker: dupMarker };
}

function mapStateToProps(state) {
    let currentUser = state.global.currentUser;
    let maxAdsInMapView = state.global.setting.maxAdsInMapView;
    let allUniquePosAds = getAllUniquePosAds(state.groupSearch.result.listAds);
    let diaChinh = state.groupSearch.form.fields.diaChinh;
    // let recentSearchList = state.groupSearch.recentSearchList;
    return {
        ...state,
        listAds: state.groupSearch.result.listAds,
        boundary: state.groupSearch.result.boundary,
        loading: state.groupSearch.loadingFromServer,
        errorMsg: state.groupSearch.result.errorMsg,
        adsLikes: currentUser && currentUser.adsLikes,
        loggedIn: state.global.loggedIn,
        userID: currentUser && currentUser.userID,
        deviceID: state.global.deviceInfo.deviceID,
        token: currentUser && currentUser.token,
        fields: state.groupSearch.form.fields,
        totalCount: state.groupSearch.result.totalCount,
        polygons: state.groupSearch.map.polygons,
        listScrollPos: state.groupSearch.listScrollPos,
        limit: maxAdsInMapView,
        uploadingLikedAds: state.search.uploadingLikedAds,
        //******* DIFF MAP *******//
        diaChinhFullName: diaChinh && diaChinh.fullName,
        allUniquePosAds: allUniquePosAds,
        maxAdsInMapView: maxAdsInMapView,
        //******* DIFF MAP END *******//
        // recentSearchList: recentSearchList,
        searchView: state.groupSearch.searchView,
        currentUser: currentUser
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

let imageGroup = 168;

let ds_filterGroup = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

const ASPECT_RATIO = width / (height - 168);

const PADDING = 0.00000005;
const LATITUDE = 15.91246021276861;
const LONGITUDE = 105.7527299557314;
const LATITUDE_DELTA = 15.43258937437489;
const MIN_LATITUDE = 5.196165;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

var currentAdsIndex = 0;

const delayDuration = 500;

class GroupFilterResult extends Component {
    _panResponder = {}
    _previousLeft = 0
    _previousTop = 0

    constructor(props) {
        super(props);
        //********* MAP **********//
        let circle = props.groupSearch.map.circle;
        //********* MAP END **********//
        let isFront = props.searchView == 'list';

        this.editing = null;

        let { loaiTin, ngayDaDang, huongNha, dienTich, ban, thue,
            soPhongNguSelectedIdx, radiusInKmSelectedIdx, hasImage, excludeMoiGioi } = this.props.groupSearch.form.fields;

        let { initDienTich, fromDienTich, toDienTich } = this._initDienTich(dienTich);

        let showMore = ngayDaDang != '' || huongNha != 0;

        let { initGia, fromGia, toGia } = this._initGia(loaiTin, this.props.groupSearch.form.fields[loaiTin].gia);

        this.state = {
            firstTime: true,
            textMessage: '',
            showMessage: false,
            isFlipped: !isFront,
            isSuggestionFlipped: false,
            isFront: isFront,
            msgType: '',
            sorting: false,
            onHelpFilter: false,
            isOpenToastMap: false,
            onFilterComplete: !props.global.help.mapFilterHelped,

            //******* MAP **********//
            modal: false,
            mapType: "Standard",
            mmarker: {},
            markers: [],
            openLocalInfo: false,
            openDraw: false,
            drawPressed: false,
            openDetailAdsModal: false,
            markedList: [],
            isOpenModalSapxep: false,
            isOpenModalLoaiTin: false,
            isOpenModalLoaiNhaDat: false,
            isOpenModalMucGia: false,
            isOpenModalDienTich: false,
            isOpenModalHasImage: false,
            isOpenModalHelp: false,
            // editing: null,
            enableRegionChange: false,
            coordinate: null,
            circle: circle,
            // pageNo: 1,
            mounting: true,
            positionSearchPress: props.groupSearch.positionSearchMode,
            drawSearchPress: false,
            searchTime: moment().toDate().getTime(),
            alertDrawMessage: '',
            openRadiusModal: false,
            geoLocationMsg: '',
            circleSearchMsg: '',
            searchFilter2Actived: false,

            showMore: showMore,
            showNgayDaDang: false,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            initNgayDaDang: ngayDaDang,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            inputNgayDaDang: ngayDaDang,
            toggleState: false,
            loaiTin: loaiTin,
            ban: ban,
            thue: thue,
            dienTich: dienTich,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            radiusInKmSelectedIdx: radiusInKmSelectedIdx,
            huongNha: huongNha,
            ngayDaDang: ngayDaDang,
            hasImage: hasImage,
            excludeMoiGioi: excludeMoiGioi,
            conditions: ''
        };
    }

    _initDienTich(dienTich) {
        let initDienTich = [];
        Object.assign(initDienTich, dienTich);
        let dienTichVal = RangeUtils.dienTichRange.toValRange(initDienTich);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        return { initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich };
    }

    _initGia(loaiTin, gia) {
        let initGia = [];
        Object.assign(initGia, gia);
        let giaStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(initGia);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if (DanhMuc.loaiTinFilter.ban === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if (DanhMuc.loaiTinFilter.ban === loaiTin) {
            toGia = toGia / 1000;
        }
        return { initGia: initGia, fromGia: fromGia, toGia: toGia };
    }

    componentWillReceiveProps(nextProps) {
        if (!this.state.openRadiusModal) {
            let circle = nextProps.groupSearch.map.circle;
            if (!circle || JSON.stringify(circle) == JSON.stringify({})) {
                circle = {
                    center: {
                        latitude: LATITUDE,
                        longitude: LONGITUDE,
                    },
                    radius: 0,
                }
            }
            let positionSearchPress = circle && circle.radius > 0;
            var region = this.getNextRegion(nextProps);
            if (Object.keys(region).length <= 0 || isNaN(region.latitude) || !this.hasRegionChange(region)) {
                this.setState({ circle: circle, positionSearchPress: positionSearchPress });
            } else {
                this.setState({ circle: circle, positionSearchPress: positionSearchPress, region: region, oldRegion: region });
            }
        }
        if (nextProps.listAds !== this.props.listAds) {
            this.refreshNextMarkers(nextProps);
            this._onShowMessage();
        }
        if (nextProps.global.help.mapFilterHelped !== this.props.global.help.mapFilterHelped) {
            this.setState({ onFilterComplete: !nextProps.global.help.mapFilterHelped })
        }
        if (nextProps.searchView !== this.props.searchView && nextProps.searchView != 'list') {
            this.setState({ isFront: false });
        }
    }

    getNextRegion(nextProps) {
        let { viewport } = nextProps.groupSearch.form.fields;
        let region = {};
        if (viewport && Object.keys(viewport).length == 2) {
            region = apiUtils.getRegionByViewport(viewport);
        }
        return region;
    }

    hasRegionChange(region) {
        let oldRegion = this.state.oldRegion;
        return !(oldRegion && Math.abs(oldRegion.latitude - region.latitude) <= PADDING
            && Math.abs(oldRegion.longitude - region.longitude) <= PADDING
            // && Math.abs(oldRegion.latitudeDelta - region.latitudeDelta) <= PADDING
            && Math.abs(oldRegion.longitudeDelta - region.longitudeDelta) <= PADDING);
    }

    resetAllMarkers() {
        this.setState({ markers: [] });
    }

    refreshNextMarkers(nextProps) {
        let viewableList = nextProps.allUniquePosAds.markerList;
        let allMarkers = this.getAllMarkersBy(viewableList, this.state.mmarker);
        this.setState({ markers: allMarkers });
    }

    refreshAllMarkers() {
        let allMarkers = this.getAllMarkers(this.state.mmarker);
        this.setState({ markers: allMarkers });
    }

    getAllMarkers(mmarker) {
        let viewableList = this._getViewableAds();
        return this.getAllMarkersBy(viewableList, mmarker);
    }

    _getViewableAds() {
        return this.props.allUniquePosAds.markerList;
    }

    getAllMarkersBy(viewableList, mmarker) {
        let allMarkers = [];
        let uuid = new Date().getTime();
        for (let i = 0; i < viewableList.length; i++) {
            let marker = viewableList[i];
            let isSelectedMarker = mmarker && mmarker.id == marker.id;
            allMarkers.push(
                <MapView.Marker key={uuid + i} coordinate={marker.coordinate}
                    style={{ zIndex: isSelectedMarker ? viewableList.length : i }}
                    // onSelect={()=>this._onMarkerPress(marker)}
                    // onDeselect={this._onMarkerDeselect.bind(this)}
                    onPress={() => this._onMarkerPress(marker, i)}>
                    {marker.duplicate == 1 ?
                        <PriceMarker color={isSelectedMarker ? '#E73E21' :
                            (this.state.markedList.indexOf(marker.id) >= 0 ? "grey" : gui.mainColor)}
                            amount={marker.price} /> :
                        <PriceMarker2 duplicate={marker.duplicate} color={isSelectedMarker ? '#E73E21' :
                            (this.state.markedList.indexOf(marker.id) >= 0 ? "grey" : gui.mainColor)}
                            amount={marker.price} />
                    }
                </MapView.Marker>);
        }
        return allMarkers;
    }

    _onMarkerPress(marker, index) {
        log.info("Call GroupFilterResult._onMarkerPress");
        var markedList = this.state.markedList;
        let { loading } = this.props;
        let { openDraw, openLocalInfo } = this.state;

        if (openLocalInfo || loading || openDraw) {
            return;
        }

        markedList.push(marker.id);
        currentAdsIndex = index;
        this.state.markers = this.getAllMarkers(marker);
        this.setState({
            openDetailAdsModal: true,
            openLocalInfo: false,
            mmarker: marker,
            markedList: markedList,
            firstTime: true
        });
    }

    componentWillMount() {
        this._panResponder = PanResponder.create({
            onStartShouldSetPanResponder: this._handleStartShouldSetPanResponder.bind(this),
            onMoveShouldSetPanResponder: this._handleMoveShouldSetPanResponder.bind(this),
            onPanResponderGrant: this._handlePanResponderGrant.bind(this),
            onPanResponderMove: this._handlePanResponderMove.bind(this),
            onPanResponderRelease: this._handlePanResponderEnd.bind(this),
            onPanResponderTerminate: this._handlePanResponderEnd.bind(this),
        });
        this._previousLeft = 20;
        this._previousTop = 84;

        var region = this.getInitialRegion();
        this.setState({ region: region, oldRegion: region });
        this.helpImage0 = (<Image style={styles.imgMapView}
            source={require('../../assets/image/gif/loc_map.gif')}
        />);
        this.helpImage1 = (<Image style={styles.imgMapView}
            source={require('../../assets/image/gif/ve_tay.gif')}
        />);
        this.helpImage2 = (<Image style={styles.imgMapView}
            source={require('../../assets/image/gif/one_vi_tri.gif')}
        />);
        this.helpImage3 = (<Image style={styles.imgMapView}
            source={require('../../assets/image/gif/dia_diem_map.gif')}
        />);
        this.helpImage4 = (<Image style={styles.imgMapView}
            source={require('../../assets/image/gif/next_map.gif')}
        />);
        if (!this.props.boundary || this.props.boundary.length == 0) {
            this._loadRegionBoundary();
        }
        this._onSearchDiaChinhViewport();
        setTimeout(this._initAdsList.bind(this), 300);
    }

    _onSearchDiaChinhViewport() {
        let myProps = this.props;
        let { diaChinh, diaChinhViewport } = myProps.groupSearch.form.fields;
        if (diaChinhViewport || !diaChinh || (!diaChinh.tinhKhongDau && !diaChinh.huyenKhongDau && !diaChinh.xaKhongDau)) {
            return;
        }
        let codeTinh = diaChinh.tinhKhongDau;
        let codeHuyen = diaChinh.huyenKhongDau;
        let codeXa = diaChinh.xaKhongDau;

        var placeType = 'T';
        if (codeHuyen)
            placeType = 'H';
        if (codeXa)
            placeType = 'X';

        let diaChinhDto = {
            codeTinh: codeTinh || undefined,
            codeHuyen: codeHuyen || undefined,
            codeXa: codeXa || undefined,
            placeType: placeType
        };
        let onGroupSearchFieldChange = myProps.actions.onGroupSearchFieldChange;
        findApi.getDiaChinhByCondition(diaChinhDto)
            .then(function (e) {
                if (e && e.status === 0 && e.predictions && e.predictions.length > 0) {
                    let diaChinhViewport = e.predictions[0].geometry.viewport;
                    onGroupSearchFieldChange("diaChinhViewport", diaChinhViewport);
                }
            });
    }

    _initAdsList() {
        let myProps = this.props;
        // if (myProps.listAds.length > 0) {
        //     return;
        // }
        let { diaChinh } = myProps.fields;
        let fields = utils.cloneRecord(myProps.fields);
        fields.limit = myProps.global.setting.maxAdsInMapView;
        fields.isIncludeCountInResponse = true;

        //TODO: need to verify logic of updating last search
        if (myProps.global.currentUser && myProps.global.currentUser.userID) {
            fields.userID = myProps.global.currentUser.userID;
        }
        fields.updateLastSearch = diaChinh && diaChinh.tinhKhongDau && diaChinh.tinhKhongDau != '';

        // for counting active device
        if (myProps.global.deviceInfo && myProps.global.deviceInfo.deviceID) {
            fields.deviceID = myProps.global.deviceInfo.deviceID;
        }

        fields.groupID = myProps.groupID;

        myProps.actions.groupSearch(
            fields
            , () => { }
            , (error) => { });
    }

    getInitialRegion() {
        let { viewport } = this.props.groupSearch.form.fields;
        let region = viewport && Object.keys(viewport).length == 2 ? apiUtils.getRegionByViewport(viewport) : {};
        if (Object.keys(region).length <= 0 || isNaN(region.latitude)) {
            region = {
                latitude: LATITUDE,
                longitude: LONGITUDE,
                latitudeDelta: LATITUDE_DELTA,
                longitudeDelta: LONGITUDE_DELTA
            };
        }
        return region;
    }

    _handleStartShouldSetPanResponder(e, gestureState) {
        // Should we become active when the user presses down on the circle?
        return true;
    }

    _handleMoveShouldSetPanResponder(e, gestureState) {
        // Should we become active when the user moves a touch over the circle?
        return true;
    }

    _handlePanResponderGrant(e, gestureState) {
        this._previousLeft = gestureState.x0;
        this._previousTop = gestureState.y0;
    }

    _handlePanResponderMove(e, gestureState) {
        this._refreshPolygons(gestureState);
    }

    _handlePanResponderEnd(e, gestureState) {
        this._previousLeft += gestureState.dx;
        this._previousTop += gestureState.dy;

        let editing = this.editing;
        let hasPolygon = editing && editing.length > 2;
        if (hasPolygon) {
            var geoBox = apiUtils.getPolygonBox2(editing);
            var region = apiUtils.getRegion(geoBox);
            var viewport = apiUtils.getViewport(region);
            var polygon = apiUtils.convertPolygon2(editing);
            // this.props.actions.onGroupSearchFieldChange("viewport", viewport);
            this.props.actions.onGroupSearchFieldChange("polygon", polygon);
            this.props.actions.onGroupPolygonsChange(editing);
            // this.props.actions.onGroupSearchFieldChange("diaChinh", {});
            this.props.actions.onGroupSearchFieldChange("pageNo", 1);
            this.state.markers = [];
            this.props.allUniquePosAds.markerList = [];
            this._refreshListData(viewport, polygon, () => {
                this._closeDrawIfNoResult(viewport, region);
                this._onShowMessage();
            }, {}, false, {});
            Analytics.logEvent('GROUP_MAP_DRAW', { deviceID: this.props.deviceID, userID: this.props.userID });
        }
        this._updateMapView(hasPolygon);
    }

    _refreshPolygons(gestureState) {
        log.info("Call GroupFilterResult._refreshPolygons");
        var region = this.state.region;
        if (isNaN(region.latitude) || isNaN(region.longitude)) {
            return;
        }
        let mapHeight = height - 168;
        let verticalMargin = 168;
        var x0 = this._previousLeft + gestureState.dx;
        var y0 = this._previousTop + gestureState.dy;
        var lat = region.latitude + (region.longitudeDelta / ASPECT_RATIO) * (0.5 - (y0 - verticalMargin) / mapHeight);
        var lon = region.longitude + region.longitudeDelta * (x0 / width - 0.5);
        var coordinate = { latitude: lat, longitude: lon };
        let editing = this.editing;
        if (!editing) {
            this.editing = [coordinate];
        } else {
            // this.editing = [
            //     ...editing,
            //     coordinate
            // ];
            this.editing = editing.concat([coordinate]);
        }
        this.forceUpdate();
    }

    _closeDrawIfNoResult(viewport, region) {
        clearTimeout(this.drawSearchTimer);
        let numberOfAds = this._getNumberOfAds();
        if (numberOfAds == 0) {
            setTimeout(() => this._onCloseDraw(), 50);
        } else {
            this.state.region = region;
            this.state.oldRegion = region;
            this.props.actions.onGroupSearchFieldChange("viewport", viewport);
            let diaChinh = { fullName: gui.KHUNG_NHIN_HIEN_TAI };
            this.props.actions.onGroupSearchFieldChange("diaChinh", diaChinh);
            this.props.actions.onGroupSearchFieldChange("diaChinhViewport", undefined);
            this.refreshAllMarkers();
            this._onDrawMapDone();
        }
    }

    _getNumberOfAds() {
        let { listAds } = this.props;
        return listAds && listAds.length;
    }

    _onCloseDraw() {
        this.setState({
            openDetailAdsModal: false,
            openLocalInfo: false,
            // editing: null,
            openDraw: false,
            alertDrawMessage: ''
        });
        this.editing = null;
        this.forceUpdate();
        this.props.actions.onGroupDrawModeChange(false);
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("polygon", []);
    }

    _updateMapView(waitForSearchDone) {
        log.info("Call GroupFilterResult._updateMapView");
        if (waitForSearchDone) {
            this.drawSearchTimer = setTimeout(() => { this._onDrawMapDone() }, 2000);
        } else {
            this._onDrawMapDone();
        }
    }

    _onDrawMapDone() {
        this.setState({
            openDetailAdsModal: false,
            openLocalInfo: false,
            // editing: null,
            openDraw: false,
            alertDrawMessage: ''
        });
        this.editing = null;
        this.forceUpdate();
        this.props.actions.onGroupDrawModeChange(false);
    }

    _doRefreshListData() {
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        let viewport = {};
        if (this.props.global.setting.autoLoadAds) {
            viewport = this.props.groupSearch.form.fields.viewport;
        } else {
            viewport = apiUtils.getViewport(this.state.region);
        }
        this.props.actions.onGroupSearchFieldChange("viewport", viewport);
        this.setState({ markedList: [] });
        this._refreshListData(viewport, null, () => {
            this._onShowMessage()
        });
    }

    _refreshListData(newViewport, newPolygon, refreshCallback, newCenter, excludeCount, newDiaChinh, newPageNo, isAppend, newCircle) {
        log.info("Call GroupFilterResult._refreshListData");
        var {
            loaiTin, viewport, diaChinh, center, polygon, pageNo, circle
        } = this.props.groupSearch.form.fields;
        let limit = this.props.maxAdsInMapView;
        var isHavingCount = excludeCount ? false : true;

        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.viewport = newViewport || viewport;
        fields.diaChinh = newDiaChinh || diaChinh;
        fields.center = newCenter || center;
        fields.polygon = newPolygon || polygon;
        fields.circle = newCircle || circle;
        fields.pageNo = !isAppend ? 1 : newPageNo || pageNo;
        fields.limit = limit;
        fields.isIncludeCountInResponse = isHavingCount;

        // add userID, deviceID for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            fields.userID = this.props.global.currentUser.userID;
        }

        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            fields.deviceID = this.props.global.deviceInfo.deviceID;
        }

        var ms = moment().toDate().getTime();
        var previousSearchTime = this.state.searchTime;
        this.setState({ searchTime: ms });
        if (ms - previousSearchTime > delayDuration) {
            fields.updateLastSearch = false;
            fields.groupID = this.props.groupID;

            this.setState({textMessage: ''});

            this.props.actions.groupSearch(
                fields
                , refreshCallback
                , (error) => {
                    this.props.actions.changeLoadingGroupSearchResult(false);
                    this._onShowMessage();
                });


            if (!isAppend) {
                this.setState({ mounting: false, drawPressed: false });
            }
        }
    }

    _loadRegionBoundary() {
        let { diaChinh } = this.props.groupSearch.form.fields;
        if (diaChinh && !diaChinh.duAnKhongDau
            && (diaChinh.tinhKhongDau || diaChinh.huyenKhongDau || diaChinh.xaKhongDau)) {
            let diaChinhDto = {
                codeTinh: diaChinh.tinhKhongDau || undefined, codeHuyen: diaChinh.huyenKhongDau || undefined,
                codeXa: diaChinh.xaKhongDau || undefined, codeDuong: diaChinh.duongKhongDau || undefined
            };
            this.props.actions.getGroupBoundary(diaChinhDto,
                (boundary) => this._updateMapViewport(boundary, diaChinh.duongKhongDau));
        }
    }

    _updateMapViewport(boundary, isDuongPlace) {
        if (isDuongPlace) {
            let geoBox = apiUtils.getGeoBoxBoundary(boundary);
            if (geoBox.length == 0) {
                return;
            }
            let region = apiUtils.getRegion(geoBox);
            let oldRatio = region.longitudeDelta / region.latitudeDelta;
            let delta = Math.max(region.latitudeDelta, region.longitudeDelta);
            region.latitudeDelta = oldRatio > ASPECT_RATIO ? delta / ASPECT_RATIO : delta;
            region.longitudeDelta = oldRatio > ASPECT_RATIO ? delta : delta * ASPECT_RATIO;
            let viewport = apiUtils.getViewport(region);
            this.props.actions.onGroupSearchFieldChange("viewport", viewport);
            this.props.actions.onGroupSearchFieldChange("diaChinhViewport", viewport);
            this.setState({ region: region, oldRegion: region });

            this._refreshListData(viewport, null, () => {
                this._onShowMessage()
            }, null, false, null);
        }
    }

    componentDidMount() {
        StatusBar.setBarStyle('default');
        //***** MAP *******//
        // this.setState({enableRegionChange: true});
        let numberOfAds = this._getNumberOfAds();
        if (numberOfAds > 0) {
            this.refreshAllMarkers();
            this._onShowMessage();
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    _loadSearchFilter(fields) {
        let { loaiTin, ngayDaDang, huongNha, dienTich, ban, thue,
            soPhongNguSelectedIdx, radiusInKmSelectedIdx } = fields;
        let { initDienTich, fromDienTich, toDienTich } = this._initDienTich(dienTich);
        let { initGia, fromGia, toGia } = this._initGia(loaiTin, fields[loaiTin].gia);
        let showMore = ngayDaDang != '' || huongNha != 0;
        this.setState({
            showMore: showMore,
            showNgayDaDang: false,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            initNgayDaDang: ngayDaDang,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            inputNgayDaDang: ngayDaDang,
            toggleState: false,
            loaiTin: loaiTin,
            ban: ban,
            thue: thue,
            dienTich: dienTich,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            radiusInKmSelectedIdx: radiusInKmSelectedIdx,
            huongNha: huongNha,
            ngayDaDang: ngayDaDang
        });
    }

    render() {
        log.info("Call GroupFilterResult render");
        if (this.state.isSuggestionFlipped) {
            return this._renderPlaceAutoComplete();
        } else {
            return this._renderMainView();
        }
    }

    _renderPlaceAutoComplete() {
        let predefinedPlaces = [
            // ...this.props.search.saveSearchList,
            // ...this.props.search.recentSearchList
        ];
        return (
            <View style={styles.fullWidthContainer}>
                <GroupPlacesAutoComplete
                    ref={'placeSuggestion'}
                    onSelectPress={this._onPlacePress.bind(this)}
                    onCancelPress={this._onCancelPress.bind(this)}
                    predefinedPlaces={predefinedPlaces}
                    allPlace={true}
                />
            </View>
        )
    }

    _onCancelPress() {
        this._flipSuggestion();
    }

    _onPlacePress(data) {
        log.enter("GroupFilterResult._onPlacePress", data);

        this.props.actions.onGroupSearchFieldChange("viewport", {});
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("polygon", []);
        this.props.actions.onGroupSearchFieldChange("circle", {});
        this.props.actions.onGroupSearchFieldChange("orderBy", '');
        this.props.actions.onResetGroupAdsList();
        this.props.actions.changeLoadingGroupSearchResult(true);
        this.resetAllMarkers();
        this.props.actions.onGroupCircleChange({});
        this.onChangePositionSearch({});
        this.props.actions.onResetGroupBoundary();

        if (data.isRecent || data.isSaveSearch) {
            this.props.actions.loadSavedSearch(data);
        } else {
            data.fullName = data.shortName || data.fullName;

            if (data.fullName != gui.TAT_CA_KHU_VUC) {
                this.props.actions.onGroupSearchFieldChange("viewport", data.viewport);
                this.props.actions.onGroupSearchFieldChange("diaChinhViewport", data.viewport);
                this.props.actions.onGroupSearchFieldChange("center", data.center);
            } else {
                let region = {
                    latitude: LATITUDE,
                    longitude: LONGITUDE,
                    latitudeDelta: LATITUDE_DELTA,
                    longitudeDelta: LONGITUDE_DELTA
                };
                let viewport = apiUtils.getViewport(region);
                this.props.actions.onGroupSearchFieldChange("viewport", viewport);
                this.props.actions.onGroupSearchFieldChange("diaChinhViewport", viewport);
                this.props.actions.onGroupSearchFieldChange("center", {});
            }
            let diaChinh = {
                tinhKhongDau: data.tinh, huyenKhongDau: data.huyen,
                xaKhongDau: data.xa, duAnKhongDau: data.duAn, duongKhongDau: data.duong, fullName: data.fullName
            };

            this.props.actions.onGroupSearchFieldChange("diaChinh", diaChinh);
        }

        this.props.actions.changeLoadingGroupSearchResult(true);
        this.props.actions.onChangeGroupListScrollPos(0);
        this._flipSuggestion();
        setTimeout(() => {
            this._handleSearchAction();
            this._loadRegionBoundary();
            this.refreshRegion();
        }, 1000);
    }

    _flipSuggestion() {
        this.setState({ isSuggestionFlipped: !this.state.isSuggestionFlipped });
    };

    refreshRegion() {
        let region = this.getInitialRegion();
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        let allMarkers = this.getAllMarkers(this.state.mmarker);
        this.setState({ region: region, markers: allMarkers });
    }

    onChangePositionSearch(circle) {
        let positionSearchPress = circle && circle.radius > 0;
        this.setState({ circle: circle, positionSearchPress: positionSearchPress });
    }

    _handleSearchAction() {
        var { loaiTin } = this.props.groupSearch.form.fields;

        this.props.actions.onResetGroupAdsList();
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this.doSearchAds();
    }

    doSearchAds() {
        let { diaChinh, circle } = this.props.groupSearch.form.fields;

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;

        //TODO: need to verify logic of updating last search
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            fields.userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            fields.deviceID = this.props.global.deviceInfo.deviceID;
        }
        fields.updateLastSearch = diaChinh && diaChinh.tinhKhongDau && diaChinh.tinhKhongDau != '';

        this._loadSearchFilter(fields);

        fields.groupID = this.props.groupID;

        if (!this.state.searchFilter2Actived) {

            this.setState({textMessage: ''});

            this.props.actions.groupSearch(
                fields
                , () => {
                    let mCircle = {};
                    if (circle != undefined && JSON.stringify(circle) != JSON.stringify({})) {
                        let radius = circle.radius * 1000;
                        let center = { latitude: circle.center.lat, longitude: circle.center.lon };
                        mCircle = { center: center, radius: radius };
                    }
                    this.props.actions.onGroupCircleChange(mCircle);
                    this.onChangePositionSearch(mCircle);
                    this._onShowMessage();
                }
                , (error) => {
                    this.props.actions.changeLoadingGroupSearchResult(false)
                });
        } else {
            this.props.actions.changeLoadingGroupSearchResult(false);
        }
    }

    _renderMainView() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderFilterResult()}
                <View style={{ width: width, height: height - 60 }}>
                    {this.state.searchFilter2Actived ? this._renderSearchFilter2() : this._renderSearchMainView()}
                    {this._openModalSapxep()}
                    {this._openModalLoaiTin()}
                    {this._openModalLoaiNhaDat()}
                    {this._openModalMucGia()}
                    {this._openModalDienTich()}
                    {this._openModalHasImage()}
                </View>
            </View>
        );
    }

    _renderSearchFilter2() {
        let placeName = this._getHeaderTitle();
        let btnDisabled = this.props.groupSearch.drawMode || this.state.openRadiusModal;
        return (
            <GroupSearchFilter
                placeName={placeName} onShowMessage={() => this._onShowMessage()}
                isHeaderLoading={() => this._isHeaderLoading()}
                loadHomeData={this.props.actions.loadHomeData}
                owner={'list'}
                refreshRegion={() => {
                    this.props.actions.onChangeGroupListScrollPos(0);
                    this.refreshRegion()
                }}
                resetAllMarkers={() => this.resetAllMarkers()}
                onChangePositionSearch={this.onChangePositionSearch.bind(this)}
                onSuggestPress={() => { this.refs.placeSuggestion && this.refs.placeSuggestion.focusInputSearch(); this._flipSuggestion() }}
                activeView={'SearchResult'}
                userID={this.props.userID}
                deviceID={this.props.deviceID}
                disabled={btnDisabled}
                onBackToSearchMain={this._onBackToSearchMain.bind(this)}
                fields={this.props.groupSearch.form.fields}
                getHeaderTitle={this._getHeaderTitle.bind(this)}
                onLoaiTinChange={this._onLoaiTinChange.bind(this)}
                filterState={this.state}
                updateSearchFilterState={this._updateSearchFilterState.bind(this)}
                onGiaChanged={this._onGiaChanged.bind(this)}
                doChangeGia={this._doChangeGia.bind(this)}
                onDienTichChanged={this._onDienTichChanged.bind(this)}
                onNgayDaDangChanged={this._onNgayDaDangChanged.bind(this)}
                getGiaValue={this._getGiaValue.bind(this)}
                getDienTichValue={this._getDienTichValue.bind(this)}
                getLoaiNhatDatValue={this._getLoaiNhatDatValue.bind(this)}
                getHuongNhaValue={this._getHuongNhaValue.bind(this)}
                getNgayDaDangValue={this._getNgayDaDangValue.bind(this)}
                onKeyboardToggle={this.onKeyboardToggle.bind(this)}
                onSearchFilterApply={this.onSearchFilterApply.bind(this)}
                onMoreOption={this.onMoreOption.bind(this)}
                onResetFilters={this.onResetFilters.bind(this)}
                onPropertyTypesPressed={this._onPropertyTypesPressed.bind(this)}
                onHuongNhaPressed={this._onHuongNhaPressed.bind(this)}
                onSoPhongNguChanged={this._onSoPhongNguChanged.bind(this)}
                onSoTangChanged={this._onSoTangChanged.bind(this)}
                onSoNhaTamChanged={this._onSoNhaTamChanged.bind(this)}
                onBanKinhTimKiemChanged={this._onBanKinhTimKiemChanged.bind(this)}
                onNgayDaDangInputChange={this._onNgayDaDangInputChange.bind(this)}
                onSearchFieldChange={this.props.actions.onGroupSearchFieldChange} />
        );
    }

    _onPropertyTypesPressed() {
        let { loaiTin } = this.state;
        Actions.PropertyTypes({
            func: 'search', loaiTin: loaiTin, loaiNhaDat: this.state[loaiTin].loaiNhaDat,
            onLoaiNhaDatChange: (loaiNhaDat) => this._onLoaiNhaDatChange(loaiNhaDat)
        });
    }

    _onLoaiNhaDatChange(loaiNhaDat) {
        let { loaiTin } = this.state;
        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = loaiNhaDat;
        if (loaiTin == DanhMuc.loaiTinFilter.ban) {
            this.setState({ ban: loaiNhaDatParent });
        } else {
            this.setState({ thue: loaiNhaDatParent });
        }
    }

    _onHuongNhaPressed() {
        Actions.HuongNha({ huongNha: this.state.huongNha, onHuongNhaChange: (huongNha) => this._onHuongNhaChange(huongNha) });
    }

    _onHuongNhaChange(huongNha) {
        this.setState({ huongNha: huongNha });
    }

    _onSoPhongNguChanged(index) {
        this.setState({ soPhongNguSelectedIdx: index });
    }

    _onSoTangChanged(index) {
        this.props.actions.onGroupSearchFieldChange("soTangSelectedIdx", index);
    }

    _onSoNhaTamChanged(index) {
        this.props.actions.onGroupSearchFieldChange("soNhaTamSelectedIdx", index);
    }

    _onBanKinhTimKiemChanged(index) {
        this.setState({ radiusInKmSelectedIdx: index });
    }

    _onNgayDaDangInputChange(value) {
        this.setState({ inputNgayDaDang: value, ngayDaDang: value });
    }

    onMoreOption() {
        this.setState({ showMore: true });
    }

    onResetFilters() {
        let defaultBan = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onGroupSearchFieldChange("ban", defaultBan);
        this.props.actions.onGroupSearchFieldChange("thue", defaultThue);
        this.props.actions.onGroupSearchFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onGroupSearchFieldChange("radiusInKmSelectedIdx", 0);
        this.props.actions.onGroupSearchFieldChange("huongNha", 0);
        this.props.actions.onGroupSearchFieldChange("ngayDaDang", '');
        this.props.actions.onGroupSearchFieldChange("hasImage", true);
        this.props.actions.onGroupSearchFieldChange("excludeMoiGioi", false);
        this.props.actions.onGroupSearchFieldChange("isFakeGeo", undefined);

        this.setState({
            initGia: RangeUtils.BAT_KY_RANGE, initDienTich: RangeUtils.BAT_KY_RANGE, initNgayDaDang: 0,
            fromDienTich: '', toDienTich: '', fromGia: '', toGia: '', inputNgayDaDang: '',
            showMore: false, showGia: false, showDienTich: false, showNgayDaDang: false,
            ban: defaultBan, thue: defaultThue, dienTich: RangeUtils.BAT_KY_RANGE,
            soPhongNguSelectedIdx: 0, radiusInKmSelectedIdx: 0, huongNha: 0, ngayDaDang: ''
        });
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    onSearchFilterApply() {
        log.info("Call Search.onSearchFilter2Apply");
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this.props.actions.onResetGroupAdsList();
        this.props.actions.changeLoadingGroupSearchResult(true);

        let { loaiTin } = this.state;
        this.props.actions.setGroupSearchLoaiTin(loaiTin);

        this.doSearchFilterAds(false);
    }

    doSearchFilterAds(reloadDiaChinhViewport) {
        let { loaiTin, dienTich, soPhongNguSelectedIdx, radiusInKmSelectedIdx, huongNha, ngayDaDang } = this.state;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        let ban = null;
        let thue = null;
        if (loaiTin == DanhMuc.loaiTinFilter.ban) {
            ban = this.state[DanhMuc.loaiTinFilter.ban];
        } else {
            thue = this.state[DanhMuc.loaiTinFilter.thue];
        }

        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;
        this.props.actions.onGroupSearchFieldChange(loaiTin, loaiNhaDatParent);

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);
        this.props.actions.onGroupSearchFieldChange("dienTich", newDienTich);
        this.props.actions.onGroupSearchFieldChange("soPhongNguSelectedIdx", soPhongNguSelectedIdx);
        this.props.actions.onGroupSearchFieldChange("radiusInKmSelectedIdx", radiusInKmSelectedIdx);
        this.props.actions.onGroupSearchFieldChange("huongNha", huongNha);
        this.props.actions.onGroupSearchFieldChange("ngayDaDang", ngayDaDang);
        this.props.actions.onGroupSearchFieldChange("orderBy", '');

        let maxItem = this.props.global.setting.maxAdsInMapView;
        this._handleSearchFilterAction(loaiTin, ban, thue, '', 1, maxItem, newGia, newDienTich, soPhongNguSelectedIdx,
            radiusInKmSelectedIdx, huongNha, ngayDaDang, reloadDiaChinhViewport);
        // if (this.props.needBack) {
        //     Actions.pop();
        // } else {
        //     log.info("Call open SearchResultList in reset mode");
        //
        //     Actions.SearchResultList({type: "reset"});
        // }
        this._onBackToSearchMain();
        this.props.actions.onChangeGroupListScrollPos(0);
        this.refreshRegion();
        this._onShowMessage();
    }

    _handleSearchFilterAction(newLoaiTin, newBan, newThue, newOrderBy, newPageNo, newLimit, newGia, newDienTich, newSoPhongNguSelectedIdx,
        newRadiusInKmSelectedIdx, newHuongNha, newNgayDaDang, reloadDiaChinhViewport) {
        var { loaiTin, ban, thue, orderBy, diaChinh, viewport, pageNo, diaChinhViewport } = this.props.groupSearch.form.fields;
        if (newGia) {
            if (loaiTin == DanhMuc.loaiTinFilter.ban) {
                ban.gia = newGia;
            } else {
                thue.gia = newGia;
            }
        }

        let newViewport = viewport;
        if (reloadDiaChinhViewport) {
            newViewport = diaChinhViewport || viewport;
            this.props.actions.onGroupSearchFieldChange("viewport", newViewport);
        }

        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.loaiTin = newLoaiTin || loaiTin;
        fields.ban = newBan || ban;
        fields.thue = newThue || thue;
        fields.soPhongNguSelectedIdx = newSoPhongNguSelectedIdx;
        fields.dienTich = newDienTich;
        fields.orderBy = newOrderBy == null ? orderBy : newOrderBy;
        fields.radiusInKmSelectedIdx = newRadiusInKmSelectedIdx;
        fields.huongNha = newHuongNha;
        fields.ngayDaDang = newNgayDaDang;
        fields.pageNo = newPageNo || pageNo;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;

        //TODO: need to verify logic of updating last search
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            fields.userID = this.props.global.currentUser.userID;
        }
        fields.updateLastSearch = diaChinh && diaChinh.tinhKhongDau && diaChinh.tinhKhongDau != '';

        // for counting active device
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            fields.deviceID = this.props.global.deviceInfo.deviceID;
        }

        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => {/*setTimeout(() => this.props.actions.loadHomeData(), 100)*/ }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) });
        Analytics.logEvent('GROUP_SEARCH_FILTER', { deviceID: this.props.deviceID, userID: this.props.userID });
    }

    _getGiaValue() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        return RangeUtils.getFromToDisplay(newGia, giaStepValues.getUnitText());
    }

    _getDienTichValue() {
        let { dienTich } = this.state;
        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        return RangeUtils.getFromToDisplay(newDienTich, RangeUtils.dienTichRange.getUnitText());
    }

    _getHuongNhaValue() {
        let { huongNha } = this.state;
        if (!huongNha || huongNha.length == 0 || huongNha[0] == 0) {
            return RangeUtils.BAT_KY;
        }
        return utils.getHuongNhaText(huongNha, 20);
    }

    _getNgayDaDangValue() {
        var { ngayDaDang } = this.state;
        if (!ngayDaDang || ngayDaDang == 0) {
            return RangeUtils.BAT_KY;
        }
        return ngayDaDang + " ngày";
    }

    _onGiaChanged(pickedValue) {
        let { loaiTin } = this.state;
        let giaStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = pickedValue.split('_');
        let value = giaStepValues.rangeVal2Display(giaVal);
        this._doChangeGia(loaiTin, value);
        var initGia = [];
        Object.assign(initGia, value);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if (DanhMuc.loaiTinFilter.ban === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if (DanhMuc.loaiTinFilter.ban === loaiTin) {
            toGia = toGia / 1000;
        }
        this.setState({ initGia: initGia, fromGia: fromGia, toGia: toGia });
    }

    _doChangeGia(loaiTin, giaVal) {
        var parent = {};
        Object.assign(parent, this.state[loaiTin]);
        parent.gia = giaVal;
        if (loaiTin == DanhMuc.loaiTinFilter.ban) {
            this.setState({ ban: parent });
        } else {
            this.setState({ thue: parent });
        }
    }

    _onDienTichChanged(pickedValue) {
        let dienTichVal = pickedValue.split('_');
        let value = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        let initDienTich = [];
        Object.assign(initDienTich, value);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({ initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value });
    }

    _onNgayDaDangChanged(pickedValue) {
        let value = pickedValue;
        this.setState({ initNgayDaDang: value, inputNgayDaDang: value, ngayDaDang: value });
    }

    _updateSearchFilterState(newState) {
        this.setState(newState);
    }

    _onLoaiTinChange(value) {
        if (value == DanhMuc.loaiTinFilter.duAn) {
            this.setState({ loaiTin: value });
            return;
        }

        let { initGia, fromGia, toGia } = this._initGia(value);
        this.setState({
            loaiTin: value,
            initGia: initGia,
            fromGia: fromGia,
            toGia: toGia,
            showGia: false,
            showDienTich: false
        });
    }

    _onBackToSearchMain() {
        this.setState({ searchFilter2Actived: false });
    }

    _onShowMessage() {
        let { loading, errorMsg } = this.props;
        let { mounting, openDraw, alertDrawMessage, geoLocationMsg, circleSearchMsg } = this.state;
        let numberOfAds = this._getNumberOfAds();

        if ((!errorMsg && numberOfAds == 0) || alertDrawMessage != '' || geoLocationMsg != '' || circleSearchMsg != '' || loading || mounting || (openDraw && alertDrawMessage == '')) {
            return null;
        }

        let textMessage = errorMsg || this.getPagingTitle();

        this.setState({
            openDetailAdsModal: false, textMessage: textMessage,
            openLocalInfo: false, showMessage: true, mounting: false, drawPressed: false
        });
        this._onMsgAnimationStart();
    }

    _isHeaderLoading() {
        return this.props.loading;
    }

    _renderSearchMainView() {
        return (
            <View style={{ flex: 1 }}>
                <View style={styles.mainContainer}>
                    <FlipView style={{ flex: 1 }}
                        front={this._renderFront()}
                        back={this._renderBack()}
                        isFlipped={this.state.isFlipped}
                        onFlipped={(val) => {
                            this.setState({ isFront: !val });
                            this.props.actions.onGroupSearchViewChange("searchView", val ? 'map' : 'list');
                        }}
                        flipAxis="y"
                        flipEasing={Easing.out(Easing.ease)}
                        flipDuration={1000}
                        perspective={1000} />
                </View>
                {this._renderMessageItem()}
                <View style={styles.tabFilterContainer}>
                    {this._renderTapFilter()}
                    <View style={styles.lineDangNhap} />
                </View>
            </View>
        );
    }

    _renderMessageItem() {
        let textValue = this.state.textMessage;
        if (this.props.loading || textValue == '' || this.state.msgType == '') {
            return null;
        }
        return (
            <MMessage mainStyle={{ top: 92 }}
                // barStyle="light-content"
                animation={this.state.msgType}
                duration={500}
                onAnimationEnd={this._onAnimationEnd.bind(this)}
                textValue={textValue} />
        );
    }

    _updateMessageProcessing(textMessage) {
        this.setState({ textMessage: textMessage });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => { this.setState({ textMessage: '', msgType: '' }) }, 2000);
        }
    }

    _flip() {
        this.setState({ isFlipped: !this.state.isFlipped });
    };

    _renderFront() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }

        return (
            <View style={[styles.fullWidthContainer, { backgroundColor: 'white' }]}>
                {this._renderTapList(true)}
                {this._renderBodyContent()}
            </View>
        );

    };

    _renderBack() {
        let { polygons } = this.props.groupSearch.map;
        let showPoline = (!polygons || polygons.length === 0) && this.editing;

        return (
            <View style={[styles.fullWidthContainer, { backgroundColor: 'white' }]}>
                {this._renderTapList(false)}
                <View
                    style={{ width: width, height: height - 152 }}
                >
                    <MapView
                        ref="map"
                        region={this.state.region}
                        onRegionChange={this._onRegionChange.bind(this)}
                        onRegionChangeComplete={this._onRegionChangeComplete.bind(this)}
                        style={styles.mapView}
                        mapType={this.state.mapType.toLowerCase()}
                        rotateEnabled={false}
                        showsUserLocation={true}
                        // followUserLocation={true}
                        moveOnMarkerPress={false}
                        pitchEnabled={false}
                        scrollEnabled={!this.state.isFront}
                    >
                        {!this.props.groupSearch.drawMode || (!this.props.loading && !this.editing && polygons &&
                            polygons.length > 0) ? this.state.markers : null}
                        {polygons && polygons.length > 0 ? <MapView.Polygon
                            coordinates={polygons}
                            strokeColor={gui.mainColor}
                            fillColor="rgba(0,168,230,0.3)"
                            strokeWidth={2}
                        /> : null}
                        {showPoline && (
                            <MapView.Polyline
                                coordinates={this.editing}
                                strokeColor={gui.mainColor}
                                fillColor="rgba(0,168,230,0.3)"
                                strokeWidth={2}
                            />
                        )}
                        {this._renderSearchBoundary()}
                        {this._renderMapCircle()}
                        {this._renderMapCenter()}
                        <View pointerEvents={this.state.openDraw ? "auto" : "none"}
                            style={{ width: width, height: height - 154, backgroundColor: 'transparent' }}
                            {...this._panResponder.panHandlers}>
                        </View>
                    </MapView>

                    <View style={styles.mapButtonContainer}>
                        {this._renderPositionSearchButton()}
                        {this._renderDrawButton()}
                        {this._renderCurrentPosButton()}
                    </View>

                    {/*this._renderRefreshButton()*/}
                    {/*this._renderPreviousButton()*/}
                    {/*this._renderNextButton()*/}
                    {/* {this._renderHelpButton()} */}
                    {this._renderBottomControls()}

                    {this._renderHelpMap()}

                    {this._renderAdsModal()}

                    {this._renderRadiusModal()}

                    {this._renderLoadingOrNotFoundView()}

                </View>

                {this._renderLocalInfoModal()}
                {/* {this._rendalModalHelp()} */}
                {this._renderLoadingView()}
            </View>
        );
    }

    _renderLoadingOrNotFoundView() {
        let { loading, errorMsg } = this.props;
        let { mounting, openDraw, drawPressed, alertDrawMessage, geoLocationMsg, circleSearchMsg } = this.state;
        let numberOfAds = this._getNumberOfAds();
        let textColor = 'white';
        let bgColor = '#166CA5';
        let textMsg = '';
        if (openDraw && alertDrawMessage != '') {
            textMsg = alertDrawMessage;
        } else if (circleSearchMsg != '') {
            textMsg = circleSearchMsg;
        } else if (geoLocationMsg != '') {
            textMsg = geoLocationMsg;
            bgColor = '#fa4916';
        }

        if (textMsg != '') {
            return (<View style={styles.resultContainer}>
                <Animatable.View animation={"fadeIn"}
                    duration={500} >
                    <View style={[styles.resultText, { paddingBottom: 2, backgroundColor: bgColor }]}>
                        <ScalableText style={[styles.resultIcon, { fontWeight: '600', color: textColor }]}>  {textMsg} </ScalableText>
                    </View>
                </Animatable.View>
            </View>)
        }

        if (loading || mounting || openDraw) {
            // return (<View style={styles.resultContainer}>
            //     <View style={styles.loadingContent}>
            //         {loading ? <GiftedSpinner color="white"/> : null}
            //     </View>
            // </View>)
            return null;
        }

        if (errorMsg || drawPressed || numberOfAds > 0) {
            return null;
        }

        return (<View style={styles.resultContainer}>
            <Animatable.View animation={"fadeIn"}
                duration={500}>
                {this._renderAdsNotFoundMessage()}
            </Animatable.View>
        </View>)
    }

    getDieuKienLoc() {
        let fields = this.props.fields;
        return fields ? findApi.convertQuery2String(findApi.convertFieldsToQueryParams(fields)) : "";
    }

    getShortedText(text) {
        if (!text) {
            return null;
        }
        var maxDiaChiLength = width * 7 / 40;
        var index = text.indexOf(',', maxDiaChiLength - 5);
        var length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = text.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        let shortedText = text.substring(0, length);
        if (shortedText.length < text.length) {
            shortedText = shortedText + '...';
        }
        return shortedText;
    }

    isDisplayTwoLinesMsg() {
        let diaChinh = this.props.fields.diaChinh;

        let placeName;
        if (diaChinh && diaChinh.tinhKhongDau) {
            placeName = diaChinh.fullName;
        } else if (diaChinh && diaChinh.fullName) {
            placeName = diaChinh.fullName;
        } else { //others: banKinh or currentLocation
            placeName = gui.KHUNG_NHIN_HIEN_TAI;
        }

        return (this.props.polygons && this.props.polygons.length)
            || (this.props.groupSearch.drawMode)
            || (placeName != gui.KHUNG_NHIN_HIEN_TAI && placeName != gui.VI_TRI_HIEN_TAI);
    }

    _renderNotFoundLine2() {
        let buttonText = gui.INF_KhongCoKetQuaL2;
        let fontWeight = '600';
        let textColor = gui.mainColor;
        return (
            <ScalableText style={[styles.resultIcon,
            { fontWeight: fontWeight, color: textColor }]}>{buttonText}
            </ScalableText>
        );
    }

    _onAllRegion() {
        let diaChinh = { fullName: gui.KHUNG_NHIN_HIEN_TAI };
        this.props.actions.onGroupSearchFieldChange("diaChinh", diaChinh);
        this.props.actions.onGroupSearchFieldChange("diaChinhViewport", undefined);
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("polygon", []);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this.props.actions.onGroupSearchFieldChange("center", null);
        this._refreshListData(null, [], () => { this._onShowMessage() }, {}, false, diaChinh, 1);
    }

    _renderAdsNotFoundMessage() {
        let text1 = gui.INF_KhongCoKetQuaL1;

        let dieuKienLoc = this.getDieuKienLoc();
        let searchText = dieuKienLoc && dieuKienLoc.length > 0 ? 'ĐK lọc hiện tại: ' + dieuKienLoc : 'ĐK lọc hiện tại: ' + DanhMuc.BAT_KY;
        searchText = '(' + this.getShortedText(searchText) + ')';

        let text2 = null;
        let fontWeight = '600';
        let backgroundColor = 'white';
        let textColor = 'gray';

        if (this.isDisplayTwoLinesMsg()) {
            text2 = this._renderNotFoundLine2();
        }
        if (text2) {
            return (
                <TouchableOpacity style={{ backgroundColor: 'transparent' }} onPress={this._onAllRegion.bind(this)} >
                    <View style={[styles.resultText, { top: 0, backgroundColor: backgroundColor, paddingBottom: 2, paddingTop: 2 }]}>
                        <ScalableText style={[styles.resultIcon, { fontWeight: fontWeight, color: textColor }]}>  {text1} </ScalableText>
                        <ScalableText style={[styles.resultIcon, { fontWeight: 'normal', color: textColor, fontSize: 11 }]}>  {searchText} </ScalableText>
                        {text2}
                    </View>
                </TouchableOpacity>
            );
        } else {
            return (
                <View style={[styles.resultText, { top: 0, backgroundColor: backgroundColor, paddingBottom: 2, paddingTop: 2 }]}>
                    <ScalableText style={[styles.resultIcon, { fontWeight: fontWeight, color: textColor }]}>  {text1} </ScalableText>
                    <ScalableText style={[styles.resultIcon, { fontWeight: 'normal', color: textColor, fontSize: 11 }]}>  {searchText} </ScalableText>
                </View>
            );
        }
    }

    _renderLoadingView() {
        if (this.props.loading) {
            return (
                <View style={styles.loadingContent}>
                    <GiftedSpinner size="large" color={gui.mainTextColor} />
                </View>
            );
        }
    }

    _renderLocalInfoModal() {
        return (
            <Modal style={[styles.modal]} isOpen={this.state.openLocalInfo} position={"center"} ref={"localInfoModal"}
                isDisabled={false}
                backdrop={false} onClosed={this._onCloseLocalInfo.bind(this)}>
                <View style={styles.modalHeader}>
                    <View style={{
                        flexDirection: "row",
                        alignItems: "flex-start",
                        position: 'absolute',
                        left: 15,
                        top: 13
                    }}>
                        <RelandIcon mainProps={{ paddingRight: 30, paddingBottom: 20 }}
                            name="close" color={gui.mainColor} size={15}
                            onPress={this._onCloseLocalInfo.bind(this)} />
                    </View>
                    <Text style={styles.modalHeaderText}>Tiện ích</Text>
                </View>
                <View style={styles.modalTitle}>
                    <Text style={styles.modalTitleText}>Loại bản đồ</Text>
                </View>
                <View style={{ marginTop: 10 }}>
                    <SegmentedControlIOS
                        values={DanhMuc.getDanhMucValues(DanhMuc.MapText)}
                        selectedIndex={DanhMuc.MapType.indexOf(this.state.mapType)}
                        onChange={this._onMapTypeChange.bind(this)}
                        tintColor={gui.mainColor} height={30} width={width - 70}
                    >
                    </SegmentedControlIOS>
                </View>
            </Modal>
        )
    }

    _onMapTypeChange(event) {
        this.setState({
            mapType: DanhMuc.MapType[event.nativeEvent.selectedSegmentIndex]
        });
        setTimeout(() => this.setState({
            openDetailAdsModal: false,
            openLocalInfo: false
        }), 100);
    }

    _rendalModalHelp() {
        return (
            <Modal isOpen={this.state.isOpenModalHelp}
                onClosed={this._onModalHelpClose.bind(this)}
                style={styles.viewModalHelp}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderModalHelpContent()}
            </Modal>
        );

    }

    _onModalHelpClose() {
        this.setState({
            isOpenModalHelp: false
        });

    }

    _renderModalHelpContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]}>
                    {this._renderTextTroGiup()}
                    {this._renderTextCancelHelp()}
                </View>
                <ScrollView style={styles.viewContentHelp}>
                    {this._renderFilterMap()}
                    <FullLine />
                    {this._renderKhuVuc()}
                    <FullLine />
                    {this._renderOneViTri()}
                    <FullLine />
                    {this._renderViTriHienTai()}
                    <FullLine />
                    {this._renderNextResult()}
                </ScrollView>
            </View>
        );

    }

    _renderFilterMap() {
        return (
            <CollapsiblePanelModal
                ref="help0"
                title="Thay đổi diện tích, mức giá,..." mainProps={{ marginTop: 0 }}
                collapseProps={{ marginTop: 15, marginBottom: 15 }}
                expanded={true} bodyProps={{ marginTop: 0 }}
                helpName={"loc-map"}
                onPress={() => this.collapseAllExcept(0)}
            >
                <Text style={[styles.textFullWidth, { marginBottom: 0 }]}>
                    Nhấn vào nút "Lọc" để thay đổi các tiêu chí:
                </Text>
                <Text style={[styles.textFullWidth, { marginTop: 0, marginBottom: 0 }]}>
                    loại nhà đất, diện tích, mức giá
                </Text>
                <Text style={[styles.textFullWidth, { marginTop: 0, marginBottom: 0 }]}>
                    phù hợp với bạn
                </Text>
                {this.helpImage0}
            </CollapsiblePanelModal>
        );
    }

    _renderKhuVuc() {
        return (
            <CollapsiblePanelModal
                ref="help1"
                title="Vẽ tay để chọn khu vực cần tìm kiếm" mainProps={{ marginTop: 8 }}
                collapseProps={{ marginTop: 15, marginBottom: 15 }}
                expanded={false} bodyProps={{ marginTop: 0 }}
                helpName={"hand-o-up"}
                onPress={() => this.collapseAllExcept(1)}
            >
                {this.helpImage1}
            </CollapsiblePanelModal>
        );
    }

    _renderOneViTri() {
        return (
            <CollapsiblePanelModal
                ref="help2"
                title="Tìm kiếm xung quanh một vị trí bất kỳ" mainProps={{ marginTop: 8 }}
                collapseProps={{ marginTop: 15, marginBottom: 15 }}
                expanded={false} bodyProps={{ marginTop: 0 }}
                helpName={"map-view"}
                onPress={() => this.collapseAllExcept(2)}
            >
                {this.helpImage2}
            </CollapsiblePanelModal>
        );
    }

    _renderViTriHienTai() {
        return (
            <CollapsiblePanelModal
                ref="help3"
                title="Tìm kiếm xung quanh vị trí hiện" mainProps={{ marginTop: 8 }}
                collapseProps={{ marginTop: 15, marginBottom: 15 }}
                expanded={false} bodyProps={{ marginTop: 0 }}
                helpName={"direction"}
                onPress={() => this.collapseAllExcept(3)} >
                {this.helpImage3}
            </CollapsiblePanelModal>
        );
    }

    _renderNextResult() {
        return (
            <CollapsiblePanelModal
                ref="help4"
                title="Xem các kết quả tiếp theo" mainProps={{ marginTop: 8 }}
                collapseProps={{ marginTop: 15, marginBottom: 15 }}
                expanded={false} bodyProps={{ marginTop: 0 }}
                helpName={"next"}
                onPress={() => this.collapseAllExcept(4)} >
                {this.helpImage4}
                <Text style={{ fontSize: 5 }} />
            </CollapsiblePanelModal>
        );
    }

    collapseAllExcept(selectedIndex) {
        if (selectedIndex !== 0) {
            this.refs.help0.collapse();
        }
        if (selectedIndex !== 1) {
            this.refs.help1.collapse();
        }
        if (selectedIndex !== 2) {
            this.refs.help2.collapse();
        }
        if (selectedIndex !== 3) {
            this.refs.help3.collapse();
        }
        if (selectedIndex !== 4) {
            this.refs.help4.collapse();
        }
    }

    _renderTextTroGiup() {
        return (
            <View style={styles.viewSortModal}>
                <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Trợ giúp</Text>
            </View>
        );
    }

    _renderTextCancelHelp() {
        return (
            <TouchableOpacity style={[styles.touchSortCancel, { alignItems: 'center' }]}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );

    }

    _renderAdsModal() {
        let { dupMarker } = this.props.allUniquePosAds;
        let selectedDupMarkers = dupMarker[this.state.mmarker.id];
        if (!selectedDupMarkers) {
            selectedDupMarkers = [];
        }
        let allItems = [];
        let i = 0;
        selectedDupMarkers.map((mmarker) => {
            let markerId = mmarker.id;
            allItems.push(
                <View style={styles.detailAdsModal} key={i++}>
                    <TouchableOpacity onPress={() => {
                        this._onDetailAdsPress(markerId, mmarker)
                    }}>
                        <ImageBackground style={styles.detailAdsModalThumb} source={{ uri: `${mmarker.cover}` }}
                            defaultSource={CommonUtils.getNoCoverImage()}>
                            <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.5)']}
                                style={styles.detailAdsModalLinearGradient}>
                                <View style={styles.detailAdsModalDetail}>
                                    <View>
                                        <Text style={styles.detailAdsModalPrice}>{mmarker.price}</Text>
                                        <Text
                                            style={styles.detailAdsModalText}>{this._getDiaChi(mmarker.diaChi)}{this._getMoreInfo(mmarker)}</Text>
                                    </View>
                                    {this.renderLikeIcon(markerId)}
                                    {/*this.renderAdsNoPos(mmarker)*/}
                                </View>
                            </LinearGradient>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>
            );
        });
        let modalContent = null;
        let modalHeight = allItems.length <= 1 ? imageHeight : (allItems.length > 2 ? imageHeight * 2.25 : imageHeight * 2);
        let distanceFromTop = height - modalHeight;
        if (allItems.length <= 1) {
            modalContent = allItems;
        } else {
            let ds = myDs.cloneWithRows(allItems);
            modalContent =
                <ListView
                    ref={(listView) => {
                        this._listView = listView;
                    }}
                    dataSource={ds}
                    renderRow={this.renderRow.bind(this)}
                    stickyHeaderIndices={[]}
                    initialListSize={1}
                    style={styles.searchListView}
                />;
        }

        return (
            <Modal animationDuration={100} style={[styles.adsModal, { height: modalHeight }]}
                isOpen={this.state.openDetailAdsModal} position={"bottom"}
                ref={"detailAdsModal"} isDisabled={false} onPress={() => {
                    this._onDetailAdsPress(this.state.mmarker.id, this.state.mmarker)
                }}
                onClosed={this._onCloseLocalInfo.bind(this)}>
                {modalContent}
            </Modal>
        );

    }

    _onDetailAdsPress(markerId, mmarker) {
        Actions.GroupAdsDetail({ adsID: markerId, imageDetail: mmarker.cover });
    }

    _onCloseLocalInfo() {
        this.setState({
            openDetailAdsModal: false,
            openLocalInfo: false
        });
    }

    renderLikeIcon(adsID) {
        let isLiked = this.isLiked(adsID);
        // let color = isLiked ? '#A2A7AD' : 'white';
        let color = 'white';
        let bgColor = isLiked ? '#E50064' : '#4A443F';
        let bgStyle = isLiked ? {} : { opacity: 0.55 };
        if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID) {
            return (
                <View style={{ position: "absolute", left: width - 37 }}>
                    <View style={[styles.detailAdsModalTextHeartButton, { paddingRight: 18, paddingTop: 9 }]}>
                        <GiftedSpinner size="small" color="white" />
                    </View>
                </View>
            );
        } else {
            return (
                <View style={{ position: "absolute", left: width - 57 }}>
                    <View style={[styles.detailAdsModalTextHeartButton, { paddingRight: 18, paddingTop: 9 }]}>
                        <MHeartIcon onPress={() => this.onLike(adsID)} color={color} bgColor={bgColor} bgStyle={bgStyle}
                            size={19} />
                    </View>
                </View>);
        }
    }

    renderAdsNoPos(mmarker) {
        if (mmarker.isFakeGeo) {
            return (
                <View style={styles.adsNoPosContainer}>
                    <RelandIcon name="no-location" color='#fff' mainProps={{ flexDirection: 'row' }}
                        size={26} textProps={{ paddingLeft: 0 }}
                        noAction={true} />
                </View>
            )
        }
        return null;
    }

    _getDiaChi(param) {
        var diaChi = param || '';
        var originDiaChi = param || '';
        if (diaChi) {
            var maxDiaChiLength = 25;
            var index = diaChi.indexOf(',', maxDiaChiLength - 5);
            var length = 0;
            if (index !== -1 && index <= maxDiaChiLength) {
                length = index;
            } else {
                index = diaChi.indexOf(' ', maxDiaChiLength - 5);
                length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
            }
            diaChi = diaChi.substring(0, length);
            if (diaChi.length < originDiaChi.length) {
                diaChi = diaChi + '...';
            }
        }
        return diaChi;
    }

    _getMoreInfo(mmarker) {
        var loaiTin = mmarker.loaiTin;
        var loaiNhaDat = mmarker.loaiNhaDat;
        var dienTich = '';
        if (mmarker.dienTichFmt && mmarker.dienTichFmt != 'Không rõ') {
            dienTich = ' · ' + mmarker.dienTichFmt;
        }
        var soPhongNgu = '';
        if (mmarker.soPhongNguFmt) {
            soPhongNgu = "   " + mmarker.soPhongNguFmt;
        }

        var soTang = '';
        if (mmarker.soTangFmt) {
            soTang = "   " + mmarker.soTangFmt;
        }
        var moreInfo = '';
        var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = dienTich + soPhongNgu;
        }
        else if (!loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
                || (loaiNhaDat == loaiNhaDatKeys[3])
                || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = dienTich + soTang;
        }
        else {
            moreInfo = dienTich;
        }
        return moreInfo;
    }

    renderRow(rowData) {
        return (
            rowData
        );
    }

    isLiked(adsID) {
        const { adsLikes } = this.props;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.loggedIn) {
            //this.props.actions.onAuthFieldChange('activeRegisterLoginTab',0);
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            }
        }
    }

    _updateLikeAdsProcessing(likeAdsMessage) {
        this.setState({ firstTime: false, textMessage: likeAdsMessage });
        this._onMsgAnimationStart();
    }

    _renderHelpButton() {
        let color = this.props.groupSearch.drawMode ? '#C5C2BA' : 'black';
        return (
            <View style={styles.helpButton}>
                <TouchableOpacity disabled={this.props.groupSearch.drawMode}
                    onPress={this._openModalHelp.bind(this)}>
                    <View style={{
                        width: 43, height: 38, backgroundColor: 'transparent',
                        justifyContent: 'center', alignItems: 'center'
                    }}>
                        <RelandIcon name="help" size={26} color={color}
                            iconProps={{ marginRight: 0 }}
                            mainProps={[{ flexDirection: 'row' }]}
                            textProps={{ paddingLeft: 0 }}
                            noAction={true}

                        />
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _openModalHelp() {
        this.setState({
            isOpenModalHelp: true
        });
        Analytics.logEvent('GROUP_MAP_HELP', { deviceID: this.props.deviceID, userID: this.props.userID });
    }

    _getTotalCount() {
        return this.props.totalCount;
    }

    _renderNextButton() {
        let { pageNo } = this.props.groupSearch.form.fields;
        let limit = this.props.maxAdsInMapView;
        let totalCount = this._getTotalCount();
        let totalPages = totalCount / limit;
        let hasNextPage = pageNo < totalPages && !this.props.groupSearch.drawMode;
        return (
            <View style={styles.nextButton}>
                {!hasNextPage ?
                    <View style={styles.pagingView}>
                        <RelandIcon name="next" color={'#C5C2BA'}
                            mainProps={{ flexDirection: 'row', justifyContent: 'center' }}
                            size={20} textProps={{ paddingLeft: 0 }}
                            noAction={true} />
                        <Text style={[styles.drawIconText, { fontSize: 9, color: '#C5C2BA' }]}>Sau</Text>
                    </View> :
                    <TouchableOpacity onPress={this._doNextPage.bind(this)}>
                        <View style={styles.pagingView}>
                            <RelandIcon name="next" color={'black'}
                                mainProps={{ flexDirection: 'row', justifyContent: 'center' }}
                                size={20} textProps={{ paddingLeft: 0 }}
                                noAction={true} />
                            <Text style={[styles.drawIconText, { fontSize: 9, color: 'black' }]}>Sau</Text>
                        </View>
                    </TouchableOpacity>}
            </View>
        );
    }

    _renderHelpMap() {
        return (
            <Modal isOpen={this.state.isOpenToastMap}
                onClosed={this._onCloseToastMap.bind(this)}
                style={styles.viewToastMap}
                position={"bottom"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={0}
                backdropColor={'#a9a8a8'}
                backdropOpacity={0.4}

            >
                {this._renderHelpToastMap()}
            </Modal>
        );
    }

    _onCloseToastMap() {
        this.setState({
            isOpenToastMap: false
        })
    }

    _renderHelpToastMap() {
        return (
            <TouchableOpacity style={styles.viewModalTop}
                activeOpacity={0}
                onPress={this._onCloseToastMap.bind(this)}
            >
                <Animatable.View
                    animation="fadeIn"
                // direction="alternate"
                >
                    <View style={styles.viewAnimatable}>
                        <TouchableOpacity style={[styles.viewIconClose, { left: -120 }]}
                            activeOpacity={1}
                            onPress={this._onCloseToastMap.bind(this)}
                        >
                            <RelandIcon name="close" color='#fff' mainProps={{ top: 6, marginRight: 5 }}
                                size={8} textProps={{}}
                                noAction={true}
                            />
                        </TouchableOpacity>
                        <ScalableText style={styles.textContent}>
                            Nhấn vào đây để xem hướng dẫn sử dụng tìm kiếm trên bản đồ!
                        </ScalableText>
                    </View>
                    <View style={[styles.triangle, { marginLeft: 203 }]} />
                </Animatable.View>
            </TouchableOpacity>
        );
    }

    _renderPreviousButton() {
        let { pageNo } = this.props.groupSearch.form.fields;
        let hasPreviousPage = pageNo > 1 && !this.props.groupSearch.drawMode;
        return (
            <View style={styles.previousButton}>
                {!hasPreviousPage ?
                    <View style={styles.pagingView}>
                        <RelandIcon name="previous" color={'#C5C2BA'}
                            mainProps={{ flexDirection: 'row', justifyContent: 'center' }}
                            size={20} textProps={{ paddingLeft: 0 }}
                            noAction={true} />
                        <Text style={[styles.drawIconText, { fontSize: 9, color: '#C5C2BA' }]}>Trước</Text>
                    </View> :
                    <TouchableOpacity onPress={this._doPreviousPage.bind(this)}>
                        <View style={styles.pagingView}>
                            <RelandIcon name="previous" color={'black'}
                                mainProps={{ flexDirection: 'row', justifyContent: 'center' }}
                                size={20} textProps={{ paddingLeft: 0 }}
                                noAction={true} />
                            <Text style={[styles.drawIconText, { fontSize: 9, color: 'black' }]}>Trước</Text>
                        </View>
                    </TouchableOpacity>}
            </View>
        );
    }

    _renderRefreshButton() {
        let btnDisabled = this.props.groupSearch.drawMode;
        let btnColor = btnDisabled ? '#C5C2BA' : 'black';
        return (
            this.props.global.setting.autoLoadAds ? null :
                <View style={styles.refreshButton}>
                    <TouchableOpacity onPress={this._doRefreshListData.bind(this)} disabled={btnDisabled}>
                        <View style={styles.pagingView}>
                            <RelandIcon name="refresh" color={btnColor}
                                mainProps={{ flexDirection: 'row', justifyContent: 'center' }}
                                size={20} textProps={{ paddingLeft: 0 }}
                                noAction={true} />
                            <Text style={[styles.drawIconText, { fontSize: 9, color: btnColor }]}>Refresh</Text>
                        </View>
                    </TouchableOpacity>
                </View>
        );
    }

    _renderCurrentPosButton() {
        let { region } = this.state;
        let { center } = this.props.groupSearch.form.fields;
        let isCurrentPos = center && Math.abs(center.lat - region.latitude) <= PADDING
            && Math.abs(center.lon - region.longitude) <= PADDING;

        let color = this.props.groupSearch.drawMode || (this.props.groupSearch.map.polygons &&
            this.props.groupSearch.map.polygons.length > 0) || this.state.positionSearchPress ? '#C5C2BA' :
            isCurrentPos ? gui.mainColor : 'black';

        return (
            <TouchableOpacity disabled={this.state.positionSearchPress
                || this.props.groupSearch.drawMode
                || (this.props.groupSearch.map.polygons && this.props.groupSearch.map.polygons.length > 0)}
                onPress={this._onCurrentLocationPress.bind(this)}>
                <View style={[styles.bubble, styles.button, { marginTop: 10 }]}>
                    <RelandIcon name="direction" color={color}
                        mainProps={{ flexDirection: 'row' }}
                        size={20} textProps={{ paddingLeft: 0 }}
                        noAction={true} />
                </View>
            </TouchableOpacity>
        );
    }

    _onCurrentLocationPress() {

        this.props.actions.changeLoadingGroupSearchResult(true);

        navigator.geolocation.getCurrentPosition(
            (position) => {
                //this._requestNearby(position.coords.latitude, position.coords.longitude);
                let data = {
                    currentLocation: {
                        "lat": position.coords.latitude,
                        "lon": position.coords.longitude
                    }
                };

                var region = {
                    latitude: data.currentLocation.lat,
                    longitude: data.currentLocation.lon,
                    latitudeDelta: gui.LATITUDE_DELTA,
                    longitudeDelta: gui.LONGITUDE_DELTA
                };

                this.setState({
                    region: region,
                    circle: {},
                    positionSearchPress: false,
                    openDraw: false,
                    drawPressed: false,
                    geoLocationMsg: ''
                });

                let viewport = apiUtils.getViewport(region);

                this.props.actions.onGroupSearchFieldChange("viewport", viewport);
                this.props.actions.onGroupDrawModeChange(false);
                this.props.actions.onGroupPolygonsChange([]);
                this.props.actions.onGroupSearchFieldChange("polygon", []);
                this.props.actions.onGroupSearchFieldChange("circle", {});
                this.props.actions.onGroupSearchFieldChange("diaChinh", { fullName: gui.VI_TRI_HIEN_TAI });
                this.props.actions.onGroupSearchFieldChange("pageNo", 1);
                this.props.actions.onResetGroupBoundary();
                this.props.actions.onResetGroupAdsList();

                let center = { lat: region.latitude, lon: region.longitude };

                this.props.actions.onGroupSearchFieldChange("center", center);
                this._refreshListData(viewport, [], () => { this._onShowMessage() }, center);
            },
            (error) => {
                log.warn("SearchResultMap.onCurrentLocationPress - ", error.message);
                this.setState({ geoLocationMsg: gui.ERR_LocationNotOn });
                this.props.actions.changeLoadingGroupSearchResult(false);
                setTimeout(() => this.setState({ geoLocationMsg: '' }), 5000);
            },
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    }

    _renderPositionSearchButton() {
        let mainColor = this.props.groupSearch.drawMode || (this.props.groupSearch.map.polygons &&
            this.props.groupSearch.map.polygons.length > 0) ? '#C5C2BA' :
            this.state.positionSearchPress ? gui.mainColor : 'black';
        return (
            <TouchableOpacity disabled={this.props.groupSearch.drawMode || (this.props.groupSearch.map.polygons &&
                this.props.groupSearch.map.polygons.length > 0)}
                onPress={this._onMMapSearch.bind(this)}>
                <View style={[styles.bubble2, styles.button, { marginTop: 1 }]}>
                    {!this.state.positionSearchPress ?
                        <View style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                            <RelandIcon name="map-view" color={mainColor}
                                mainProps={{ flexDirection: 'row' }}
                                size={24} textProps={{ paddingLeft: 0 }}
                                noAction={true} />
                            < View style={styles.viewIconDiaDiem}>
                                <Text style={[styles.textIconDiaDiem, { color: mainColor }]}>Địa điểm</Text>
                            </View>
                        </View> :
                        <RelandIcon name="close" color='black' mainProps={{ flexDirection: 'row' }}
                            size={15} textProps={{ paddingLeft: 0 }}
                            noAction={true} />
                    }
                </View>
            </TouchableOpacity>
        );
    }

    _renderDrawButton() {
        let drawIconColor = this.state.positionSearchPress ? '#C5C2BA' :
            this.props.groupSearch.map.polygons && this.props.groupSearch.map.polygons.length == 0 && this.props.groupSearch.drawMode ? gui.mainColor : 'black';
        return (
            <TouchableOpacity disabled={this.state.positionSearchPress}
                onPress={this._onDrawPressed.bind(this)}>
                <View style={[styles.bubble, styles.button, { flexDirection: 'column' }]}>
                    {this.props.groupSearch.map.polygons && this.props.groupSearch.map.polygons.length > 0 ? (
                        <RelandIcon name="close" color='black' mainProps={{ flexDirection: 'row' }}
                            size={15} textProps={{ paddingLeft: 0 }}
                            noAction={true} />) :
                        (
                            <View style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                                <RelandIcon name="hand-o-up" color={drawIconColor}
                                    mainProps={{ flexDirection: 'row' }}
                                    size={20} textProps={{ paddingLeft: 0 }}
                                    noAction={true} />
                                <Text style={[styles.drawIconText, { color: drawIconColor }]}>Vẽ tay</Text>
                            </View>
                        )}
                </View>
            </TouchableOpacity>
        );
    }

    _onDrawPressed() {

        var { polygons } = this.props.groupSearch.map;
        var openDraw = !polygons || polygons.length === 0;
        var drawPressed = !polygons || polygons.length <= 2;
        if (!this.props.groupSearch.drawMode && openDraw) {
            this.props.actions.abortGroupSearch();
            clearTimeout(this.timer);
            this.setState({
                openDetailAdsModal: false,
                openLocalInfo: false,
                // editing: null,
                showMessage: false,
                openDraw: openDraw,
                positionSearchPress: false,
                circle: {},
                textMessage: '',
                alertDrawMessage: 'Hãy vẽ khu vực muốn tìm.'
            });
            // this.props.actions.onResetAdsList();
            this.props.actions.onGroupDrawModeChange(openDraw);
            this.props.actions.onGroupSearchFieldChange("circle", {});
            // setTimeout(() => this.setState({alertDrawMessage: ''}), 3000);
        } else {
            this.setState({
                openDetailAdsModal: false,
                openLocalInfo: false,
                // editing: null,
                openDraw: false,
                drawPressed: drawPressed,
                alertDrawMessage: ''
            });
            this.props.actions.onGroupDrawModeChange(false);
        }
        this.editing = null;
        this.forceUpdate();
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("polygon", []);
        this.props.actions.onResetGroupBoundary();
    }

    _doPreviousPage() {
        log.info("Call SearchResultMap._doPreviousPage");
        let { pageNo } = this.props.groupSearch.form.fields;
        let { polygons } = this.props.groupSearch.map;
        let isDrawMode = polygons && polygons.length > 0;
        let circle = this.state.circle;
        let isPositionSearch = circle && circle.radius > 0;

        if (pageNo > 1) {
            pageNo = pageNo - 1;
            this._onUpdateChangePageStatus(pageNo);
            this._refreshListData(null, null, () => {
                this._onShowMessage()
            }, null, null, isPositionSearch || isDrawMode ? {} : null, pageNo, true);
            Analytics.logEvent('GROUP_MAP_PAGINATION', {
                deviceID: this.props.deviceID, userID: this.props.userID,
                pageNo: pageNo
            });
        }
    }

    _doNextPage() {
        log.info("Call SearchResultMap._doNextPage");
        let { pageNo } = this.props.groupSearch.form.fields;
        let limit = this.props.maxAdsInMapView;
        let totalCount = this._getTotalCount();
        let totalPages = totalCount / limit;
        let { polygons } = this.props.groupSearch.map;
        let isDrawMode = polygons && polygons.length > 0;
        let circle = this.state.circle;
        let isPositionSearch = circle && circle.radius > 0;

        if (pageNo < totalPages) {
            pageNo = pageNo + 1;
            this._onUpdateChangePageStatus(pageNo);
            this._refreshListData(null, null, () => {
                this._onShowMessage()
            }, null, null, isPositionSearch || isDrawMode ? {} : null, pageNo, true);
            Analytics.logEvent('GROUP_MAP_PAGINATION', {
                deviceID: this.props.deviceID, userID: this.props.userID,
                pageNo: pageNo
            });
        }
    }

    _onUpdateChangePageStatus(pageNo) {
        this.props.actions.onGroupSearchFieldChange("pageNo", pageNo);
        this.setState({ mounting: false });
    }

    _renderMapCircle() {
        let circle = this.state.circle;
        var region = JSON.parse(JSON.stringify(this.state.region));
        if (this.state.openRadiusModal && region && Object.keys(region).length > 0) {
            circle.center = { latitude: region.latitude, longitude: region.longitude };
        }

        if (this.state.positionSearchPress && circle && (circle.radius > 0 || this.state.openRadiusModal)) {
            return (
                <MapView.Circle
                    key={circle.center.latitude + circle.center.longitude + circle.radius}
                    center={circle.center}
                    radius={circle.radius}
                    fillColor="rgba(165,207,255,0.5)"
                    strokeColor={gui.mainColor}
                    position="absolute"
                    zIndex={1}
                    strokeWidth={1}
                />
            )
        }
    }

    _renderMapCenter() {
        let circle = this.state.circle;
        var region = JSON.parse(JSON.stringify(this.state.region));
        if (this.state.openRadiusModal && region && Object.keys(region).length > 0) {
            let center = { latitude: region.latitude, longitude: region.longitude };
            circle.center = center;
        }

        if (this.state.positionSearchPress && circle && (circle.radius > 0 || this.state.openRadiusModal)) {
            return (
                <MapView.Marker coordinate={circle.center} pointerEvents="none">
                    <LocationMarker />
                </MapView.Marker>
            );
        }
    }

    _renderRadiusModal() {
        let modalHeight = 100;
        return (
            <Modal animationDuration={100} style={[styles.adsModal, { height: modalHeight, opacity: 0.9 }]} isOpen={this.state.openRadiusModal} position={"bottom"}
                ref={"radiusModal"} isDisabled={false} onPress={() => { this._onCloseRadiusModel() }}
                onClosed={this._onCloseRadiusModel.bind(this)} backdrop={false}>
                {this._renderRadiusContent()}
            </Modal>
        );
    }

    _renderRadiusContent() {
        let radius = this.state.circle.radius ? this.state.circle.radius : 0;
        return (
            <View style={styles.searchListButton2}>
                <View style={styles.viewTopNav}>
                    <TruliaIcon onPress={this._onMMapSearch.bind(this)}
                        name="arrow-down" color={gui.mainColor} size={26}
                        mainProps={styles.backButton} text={this.props.backTitle}
                        textProps={styles.backButtonText} >
                    </TruliaIcon>
                    <ScalableText style={styles.textSpaceTop}>{radius / 1000} km xung quanh vị trí đã chọn.</ScalableText>
                    <TouchableOpacity onPress={this._onVitri.bind(this)} style={styles.customPageRightTitle}>
                        <ScalableText style={styles.customPageRightTitleText}>
                            Xong
                        </ScalableText>
                    </TouchableOpacity>
                </View>
                <View style={styles.viewCenterNav}>
                    <Slider
                        value={radius / 1000}
                        onValueChange={this._setRadiusCenter.bind(this)}
                        trackStyle={styles.track}
                        thumbStyle={styles.thumb}
                        minimumValue={0}
                        maximumValue={5}
                        step={0.5}
                        minimumTrackTintColor={gui.mainColor}
                        maximumTrackTintColor='#b7b7b7'
                    />
                </View>
                {this._renderSliderView()}
                <View style={styles.viewBottomNav}>
                    <View style={styles.viewTextBottom}>
                        <Text style={styles.textBottomLeft}>{radius / 1000}</Text>
                        <Text style={styles.textBottomCenter}>KM</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.textBottomRight}>5 KM</Text>
                    </View>
                </View>
            </View>
        );
    }

    _setRadiusCenter(radius) {
        let circle = JSON.parse(JSON.stringify(this.state.circle));
        circle.radius = radius * 1000;
        let region = JSON.parse(JSON.stringify(this.state.region));
        let center = { latitude: region.latitude, longitude: region.longitude };
        circle.center = center;
        let delta = apiUtils.convertRadius2Delta(radius);
        if (0.5 * region.latitudeDelta < delta) {
            region.latitudeDelta = delta;
            region.longitudeDelta = delta;
        }
        this.setState({
            region: region,
            circle: circle
        });
    }

    _renderSliderView() {
        return (
            <View style={styles.viewMeasure}>
                <View style={styles.sliderDotOne}></View>
                <View style={styles.sliderDotTwo}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotThree}></View>
                <View style={styles.sliderDotFour}></View>
            </View>
        );
    }

    _onMMapSearch() {
        if (!this.state.positionSearchPress) {
            this.props.actions.abortGroupSearch();
            this.setState({
                positionSearchPress: true, openRadiusModal: true, markers: [], drawPressed: false,
                circleSearchMsg: gui.INF_RadiusSelection, textMessage: ''
            });
            // let location = {lat: this.state.region.latitude, lon: this.state.region.longitude};
            // Actions.MMapSearch({ onPress: this._onVitri.bind(this), onBack: this._onMMapSearch.bind(this),
            //     location: this.state.region });
        } else {
            this.setState({
                positionSearchPress: false, openRadiusModal: false, circle: {},
                openDetailAdsModal: false, openLocalInfo: false, circleSearchMsg: ''
            });
            this.props.actions.onGroupSearchFieldChange("circle", {});
            this.props.actions.onGroupPositionSearchModeChange(false);
            this.props.actions.onGroupCircleChange({});
        }
    }

    _onVitri() {
        if (!this.state.circle.radius) {
            Alert.alert('Thông báo', 'Bạn phải chọn bán kính để thực hiện tìm kiếm.');
            return;
        }
        let circle = JSON.parse(JSON.stringify(this.state.circle));
        let region = JSON.parse(JSON.stringify(this.state.region));
        region.latitude = circle.center.latitude;
        region.longitude = circle.center.longitude;
        let radius = circle.radius / 1000;
        let delta = apiUtils.convertRadius2Delta(radius);
        region.latitudeDelta = delta;
        region.longitudeDelta = delta;

        let sCircle = {
            center: {
                lat: circle.center.latitude,
                lon: circle.center.longitude
            },
            radius: radius
        }

        this.props.actions.onGroupDrawModeChange(false);
        this.props.actions.onGroupPolygonsChange([]);
        this.props.actions.onGroupSearchFieldChange("polygon", []);
        this.props.actions.onResetGroupBoundary();
        this.props.actions.onResetGroupAdsList();
        let diaChinh = { fullName: gui.KHUNG_NHIN_HIEN_TAI };
        this.props.actions.onGroupSearchFieldChange("diaChinh", diaChinh);
        this.props.actions.onGroupSearchFieldChange("diaChinhViewport", undefined);

        this.props.actions.onGroupPositionSearchModeChange(true);
        this.props.actions.onGroupCircleChange(circle);
        this.props.actions.onGroupSearchFieldChange("circle", sCircle);
        this.props.actions.onGroupSearchFieldChange("center", {});

        this.setState({ openRadiusModal: false, circleSearchMsg: '' });

        let viewport = apiUtils.getViewport(region);
        this.props.actions.onGroupSearchFieldChange("viewport", viewport);

        let pageNo = 1;
        this.props.actions.onGroupSearchFieldChange("pageNo", pageNo);
        this._refreshListData(viewport, null, () => {
            this._onShowMessage()
        }, {}, null, {}, pageNo, false, sCircle);
        Analytics.logEvent('GROUP_MAP_POSITION', {
            deviceID: this.props.deviceID, userID: this.props.userID,
            circle: sCircle, viewport: viewport
        });
    }

    _onCloseRadiusModel() {
        this.setState({ openRadiusModal: false });
    }

    _renderSearchBoundary() {
        if (this.state.isFront || !this.state.enableRegionChange || !this.props.boundary) {
            return null;
        }
        let { diaChinh } = this.props.groupSearch.form.fields;
        let boundaryItems = [];
        let boundaryId = 0;
        this.props.boundary.map((oneBoundary) => {
            let boundary = oneBoundary.filter((location) => {
                return location.latitude !== null && location.longitude !== null;
            });
            if (boundary.length > 0) {
                if (diaChinh.duongKhongDau) {
                    boundaryItems.push(
                        <MapView.Polyline
                            key={boundaryId++}
                            coordinates={boundary}
                            strokeColor={gui.mainColor}
                            fillColor="rgba(0,168,230,0.1)"
                            strokeWidth={3}
                        />
                    )
                } else {
                    boundaryItems.push(
                        <MapView.Polygon
                            key={boundaryId++}
                            coordinates={boundary}
                            strokeColor={gui.mainColor}
                            fillColor="rgba(0,168,230,0.1)"
                            strokeWidth={2}
                        />
                    )
                }
            }
        });
        return boundaryItems;
    }

    _onRegionChangeComplete(region) {
        log.info("Call SearhResultMap._onRegionChangeComplete");
        if (this.state.isFront || !this.state.enableRegionChange || this.state.openDraw || region.latitude < MIN_LATITUDE) {
            this.setState({ enableRegionChange: true });
            return;
        }
        // this.state.region = region;
        this.setState({
            region: region,
            oldRegion: region,
            openDetailAdsModal: false,
            openLocalInfo: false, showMessage: false
        });

        let numberOfAds = this._getNumberOfAds();
        if (this.state.openRadiusModal || (numberOfAds > 0 && !this.hasRegionChange(region))) {
            return;
        }

        let { polygons } = this.props.groupSearch.map;
        let isDrawMode = polygons && polygons.length > 0;

        if (this.props.global.setting.autoLoadAds) {
            let viewport = apiUtils.getViewport(region);
            this.props.actions.onGroupSearchFieldChange("viewport", viewport);
            this.props.actions.onGroupSearchFieldChange("pageNo", 1);
            this._refreshListData(viewport, null, () => {
                this._onShowMessage()
            }, null, false, isDrawMode ? {} : null);
        }
    }

    _onRegionChange(region) {
        log.info("Call SearhResultMap._onRegionChange");
        if (!this.state.isFront && this.state.enableRegionChange && region.latitude >= MIN_LATITUDE) {
            this.setState({
                region: region,
                openDetailAdsModal: false,
                openLocalInfo: false, showMessage: false
            });
        }
    }

    _renderBodyContent() {
        let myProps = this.props;
        if (myProps.loading) {
            let imageUriHome = require('../../assets/image/default_cover/no_cover_03.jpg');
            return (
                <View style={styles.container}>
                    <View style={styles.viewLoaderAds}>
                        {/*<Text> Loading ... </Text>*/}
                        {/*<GiftedSpinner size="large"/>*/}
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                        <ImageBackground style={styles.viewChildRow}
                            source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()}
                        >
                            <View style={[styles.viewLineLoaderRow, { width: 38, height: 15 }]}></View>
                            <View style={[styles.viewLineLoaderRow, { marginBottom: 21 }]}></View>
                        </ImageBackground>
                    </View>
                </View>
            );
        }

        return (
            <View style={styles.container}>
                <View
                    style={{ width: width, height: height - 152 }}
                >
                    <ScrollView
                        automaticallyAdjustContentInsets={false}
                        vertical={true}
                    >
                        {this._renderNumberResult()}
                        {this._renderListGroupSearch()}
                    </ScrollView>
                    {this._renderBottomControls()}
                </View>
            </View>
        );
    }

    _onModalSapXep() {
        this.setState({ isOpenModalSapxep: true });
    }

    _onContentModal() {
        this.setState({
            isOpenModalSapxep: false,
            isOpenModalHelp: false,
            isOpenModalLoaiTin: false,
            isOpenModalLoaiNhaDat: false,
            isOpenModalMucGia: false,
            isOpenModalDienTich: false,
            isOpenModalHasImage: false
        });
    }

    _openModalSapxep() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }
        return (
            <Modal isOpen={this.state.isOpenModalSapxep}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewModalStyle}
                position={"center"}
                swipeToClose={false}
                animationDuration={200}
                backdropPressToClose={false}
            >
                {this._renderSapXepContent()}
            </Modal>
        );

    }

    _renderSapXepContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    {this._renderTextSapxep()}
                    {this._renderTextCancel()}
                </View>
                {
                    DanhMuc.getSearchOrderValues().map((e, index) => {
                        let orderByKey = this.props.groupSearch.form.fields.orderBy || '';
                        let orderByValue = DanhMuc.searchOrder[orderByKey];
                        let checked = e == orderByValue;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep,{ borderTopWidth: borderTopWidth }]}
                                key={e}
                                onPress={() => this._onChooseSearchOrder(e)}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        )
    }

    _renderTextSapxep() {
        return (
            <View style={styles.viewSortModal}>
                <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Sắp xếp</Text>
            </View>
        );
    }

    _onChooseSearchOrder(searchOrderValue) {
        this.setState({
            isOpenModalSapxep: false
        });

        let newOrderBy = DanhMuc.findSearchOrderKey(searchOrderValue);
        this.props.actions.onGroupSearchFieldChange("orderBy", newOrderBy);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this.setState({ sorting: true });

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.orderBy = newOrderBy;
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => {
                this.setState({ sorting: false })
            }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_LIST_SORT', { deviceID: deviceID, userID: userID, orderBy: newOrderBy });
    }

    _openModalLoaiTin() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }
        return (
            <Modal isOpen={this.state.isOpenModalLoaiTin}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiTinStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderLoaiTinContent()}
            </Modal>
        );
    }

    _renderLoaiTinContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Loại tin</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {
                    DanhMuc.findLoaiTinValues().map((e, index) => {
                        let { loaiTin } = this.state;
                        let orderLoaiTin = DanhMuc.LoaiTinType[loaiTin];
                        let checked = e == orderLoaiTin;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                key={e}
                                onPress={() => { this._onTabLoaiTinChange(e) }}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }

            </View>
        )
    }

    _onTabLoaiTinChange(value) {

        let loaiTinPress = value == 'Bán' ? 'ban' : 'thue';

        let { loaiTin } = this.state;

        if (loaiTin == loaiTinPress) {
            this.setState({
                isOpenModalLoaiTin: false
            });
            return;
        }
        let newLoaiTin = (value == 'Bán') ? 'ban' : 'thue';
        let defaultBan = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onGroupSearchFieldChange("loaiTin", newLoaiTin);
        this.props.actions.onGroupSearchFieldChange("ban", defaultBan);
        this.props.actions.onGroupSearchFieldChange("thue", defaultThue);
        this.props.actions.onGroupSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onGroupSearchFieldChange("hasImage", true);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);

        this.setState({
            initGia: RangeUtils.BAT_KY_RANGE,
            initDienTich: RangeUtils.BAT_KY_RANGE,
            initNgayDaDang: 0,
            fromDienTich: '',
            toDienTich: '',
            fromGia: '',
            toGia: '',
            inputNgayDaDang: '',
            showMore: false,
            showGia: false,
            showDienTich: false,
            showNgayDaDang: false,
            ban: defaultBan,
            thue: defaultThue,
            dienTich: RangeUtils.BAT_KY_RANGE,
            soPhongNguSelectedIdx: 0,
            radiusInKmSelectedIdx: 0,
            huongNha: [0],
            ngayDaDang: '',
            isOpenModalLoaiTin: false,
            loaiTin: newLoaiTin
        });

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.loaiTin = newLoaiTin;
        fields.ban = defaultBan;
        fields.thue = defaultThue;
        fields.soPhongNguSelectedIdx = 0;
        fields.soNhaTamSelectedIdx = 0;
        fields.radiusInKmSelectedIdx = 0;
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.hasImage = true;
        fields.excludeMoiGioi = false;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _openModalLoaiNhaDat() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }
        return (
            <Modal isOpen={this.state.isOpenModalLoaiNhaDat}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderLoaiNhaDatContent()}
            </Modal>
        );
    }

    _renderLoaiNhaDatContent() {
        let { loaiTin } = this.state;
        let loaiNhaDatType = loaiTin == 'ban' ? DanhMuc.findLoaiNhaDatBanValues() : DanhMuc.findLoaiNhaDatThueValues();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Loại nhà đất</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {
                    loaiNhaDatType.map((e, index) => {
                        let orderLoaiNhaDat = this._getLoaiNhatDatFullValue();
                        let checked = e == orderLoaiNhaDat;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                key={e}
                                onPress={() => { this._onTabLoaiNhaDatChange(e) }}>
                                <Text style={[styles.textSapxep, { width: width - 110 }]} numberOfLines={1}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        )
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );

    }

    _onTabLoaiNhaDatChange(value) {
        let { loaiTin } = this.state;
        let hashLoaiNhaDat = loaiTin == 'ban' ? DanhMuc.LoaiNhaDatBan : DanhMuc.LoaiNhaDatThue;
        let loaiNhaDatKey = utils.getKeyByValue(hashLoaiNhaDat, value);

        let loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = Number(loaiNhaDatKey) || undefined;
        if (loaiTin == DanhMuc.loaiTinFilter.ban) {
            this.setState({ ban: loaiNhaDatParent, isOpenModalLoaiNhaDat: false });
        } else {
            this.setState({ thue: loaiNhaDatParent, isOpenModalLoaiNhaDat: false });
        }
        this.props.actions.onGroupSearchFieldChange(loaiTin, loaiNhaDatParent);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields[loaiTin] = loaiNhaDatParent;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _openModalMucGia() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }
        return (
            <Modal isOpen={this.state.isOpenModalMucGia}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderMucGiaContent()}
            </Modal>
        );
    }

    _renderMucGiaContent() {
        let { loaiTin } = this.state;
        let rangeStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let pickerRange = rangeStepValues.getAllRangeVal();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Mức giá</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>
                <ScrollView>
                    {
                        pickerRange.map((value, index) => {
                            let label = RangeUtils.getFromToDisplay(
                                rangeStepValues.rangeVal2Display(value), rangeStepValues.getUnitText()
                            );
                            let orderMucGia = this._getGiaValue();
                            let checked = label == orderMucGia;
                            let borderTopWidth = index == 0 ? 0 : 1;
                            return (
                                <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                    key={label}
                                    onPress={() => { this._onTabMucGiaChange(value) }}>
                                    <Text style={styles.textSapxep}>{label}</Text>
                                    <View style={styles.viewTickSapxep}>
                                        {
                                            checked ?
                                                <TruliaIcon
                                                    name="check" color={gui.mainColor} size={20}
                                                    mainProps={styles.viewCheckIcon}
                                                /> : null
                                        }

                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                </ScrollView>
            </View>
        )
    }

    _onTabMucGiaChange(value) {

        let { loaiTin } = this.state;

        let loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);

        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = value;
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;
        if (loaiTin == DanhMuc.loaiTinFilter.ban) {
            this.setState({ ban: loaiNhaDatParent, isOpenModalMucGia: false });
        } else {
            this.setState({ thue: loaiNhaDatParent, isOpenModalMucGia: false });
        }
        this.props.actions.onGroupSearchFieldChange(loaiTin, loaiNhaDatParent);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields[loaiTin] = loaiNhaDatParent;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });

    }

    _openModalDienTich() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }
        return (
            <Modal isOpen={this.state.isOpenModalDienTich}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderDienTichContent()}
            </Modal>
        );
    }

    _renderDienTichContent() {

        let rangeStepValues = RangeUtils.dienTichRange;
        let pickerRange = rangeStepValues.getAllRangeVal();
        let orderDienTich = this._getDienTichValue();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Diện tích</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>
                <ScrollView>
                    {
                        pickerRange.map((value, index) => {
                            let label = RangeUtils.getFromToDisplay(
                                rangeStepValues.rangeVal2Display(value), rangeStepValues.getUnitText()
                            );
                            let checked = label == orderDienTich;
                            let borderTopWidth = index == 0 ? 0 : 1;
                            return (
                                <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                    key={label}
                                    onPress={() => { this._onTabDienTichChange(value) }}>
                                    <Text style={styles.textSapxep}>{label}</Text>
                                    <View style={styles.viewTickSapxep}>
                                        {
                                            checked ?
                                                <TruliaIcon
                                                    name="check" color={gui.mainColor} size={20}
                                                    mainProps={styles.viewCheckIcon}
                                                /> : null
                                        }

                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                </ScrollView>
            </View>
        )
    }

    _onTabDienTichChange(value) {
        let dienTichVal = value;
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        this.props.actions.onGroupSearchFieldChange("dienTich", newDienTich);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this.setState({
            isOpenModalDienTich: false,
            dienTich: newDienTich
        });

        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.dienTich = newDienTich;
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _openModalHasImage() {
        if (this.props.groupSearch.drawMode) {
            return null;
        }
        return (
            <Modal isOpen={this.state.isOpenModalHasImage}
                onClosed={this._onContentModal.bind(this)}
                style={[styles.viewLoaiNhaDatStyle, { height: 120 }]}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderHasImageContent()}
            </Modal>
        );
    }

    _renderHasImageContent() {
        let hasImageValue = DanhMuc.finHasImageValues();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>Loại tin rao</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {
                    hasImageValue.map((e, index) => {
                        let orderImage = this._getHasImageValue();
                        let checked = e == orderImage;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, {borderTopWidth: borderTopWidth}]}
                                key={e}
                                onPress={() => { this._onTabHasImageChange(e) }}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        )
    }

    _onTabHasImageChange(value) {
        let newHasImage = (value == 'Tin có ảnh') ? true : undefined;
        this.props.actions.onGroupSearchFieldChange("hasImage", newHasImage);
        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this.setState({
            isOpenModalHasImage: false,
            hasImage: newHasImage
        });
        let newLimit = this.props.global.setting.maxAdsInMapView;

        let deviceID = undefined;
        let userID = undefined;
        // for counting active device
        if (this.props.global.currentUser && this.props.global.currentUser.userID) {
            userID = this.props.global.currentUser.userID;
        }
        if (this.props.global.deviceInfo && this.props.global.deviceInfo.deviceID) {
            deviceID = this.props.global.deviceInfo.deviceID;
        }
        let fields = utils.cloneRecord(this.props.groupSearch.form.fields);
        fields.pageNo = 1;
        fields.limit = newLimit;
        fields.isIncludeCountInResponse = true;
        fields.userID = userID;
        fields.deviceID = deviceID;
        fields.hasImage = newHasImage;
        fields.groupID = this.props.groupID;

        this.setState({textMessage: ''});

        this.props.actions.groupSearch(
            fields
            , () => { }
            , (error) => { this.props.actions.changeLoadingGroupSearchResult(false) }
        );
        Analytics.logEvent('GROUP_TAB_FILTER', { deviceID: deviceID, userID: userID });
    }

    _renderHeaderFilterResult() {
        let btnDisabled = this.props.loading;
        let backButtonItem = null;
        let filterButtonItem = null;
        if (!this.state.searchFilter2Actived) {
            backButtonItem = (
                <TouchableOpacity style={styles.viewBackButton}
                    onPress={this._onBackPress.bind(this)}>
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
            );
            // filterButtonItem = (
            //     <TouchableOpacity style={styles.viewBackButton}
            //         onPress={this._onFilterPress.bind(this)}
            //         disabled={btnDisabled}
            //     >
            //         <MaterialCommunityIcons name="filter-outline" size={24} color={gui.mainTextColor} />
            //     </TouchableOpacity>
            // );
        } else {
            filterButtonItem = (
                <TouchableOpacity style={styles.viewBackButton}
                    onPress={this._onFilterPress.bind(this)}
                    disabled={btnDisabled}
                >
                    <Text style={styles.titleText}>Hủy</Text>
                </TouchableOpacity>
            );
        }
        return (
            <View style={styles.viewFilterHeader}>
                {backButtonItem}
                {this._renderInputFilter(btnDisabled)}
                {filterButtonItem}
            </View>
        );
    }

    _onArraySort(a, b) {
        if (a === '') {
            return 1;
        }
        if (b === '') {
            return -1;
        }
        return a - b;
    }

    _getLoaiTinValue() {
        let { loaiTin } = this.state;
        let loaiTinValue = DanhMuc.getLoaiTinTypeValue(loaiTin);
        return loaiTinValue;
    }

    _getGiaValue() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = DanhMuc.loaiTinFilter.ban === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        return RangeUtils.getFromToDisplay(newGia, giaStepValues.getUnitText());
    }

    _getDienTichValue() {
        let { dienTich } = this.state;
        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        return RangeUtils.getFromToDisplay(newDienTich, RangeUtils.dienTichRange.getUnitText());
    }

    _getHasImageValue() {
        let { hasImage } = this.state;
        let adsImage;
        if (hasImage) {
            adsImage = 'Tin có ảnh';
        } else {
            adsImage = 'Tất cả tin rao';
        }
        return adsImage;
    }

    _getLoaiNhatDatValue() {
        let { loaiTin } = this.state;

        if (loaiTin == DanhMuc.loaiTinFilter.duAn)
            return DanhMuc.BAT_KY;

        return DanhMuc.getLoaiNhaDatForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat).substring(0, 25);
    }

    _getLoaiNhatDatFullValue() {
        let { loaiTin } = this.state;

        if (loaiTin == DanhMuc.loaiTinFilter.duAn)
            return DanhMuc.BAT_KY;

        return DanhMuc.getLoaiNhaDatForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat);
    }

    _renderTapFilter() {
        let filterValue = 'Lọc';
        let filterBgColor = gui.mainColor;
        let filterTextColor = '#fff';
        let loaiTinValue = this._getLoaiTinValue();
        let loaiTinBgColor = gui.mainColor;
        let loaiTinTextColor = '#fff';
        let filterCount = 1;
        let loaiNhaDatIndex = this._getLoaiNhatDatValue();
        let loaiNhaDatValue = (loaiNhaDatIndex == 'Bất kỳ') ? 'Loại nhà đất - Bất kỳ' : loaiNhaDatIndex;
        let loaiNhaDatBgColor = (loaiNhaDatIndex == 'Bất kỳ') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let loaiNhaDatTextColor = (loaiNhaDatIndex == 'Bất kỳ') ? '#526173' : '#fff';
        filterCount = (loaiNhaDatIndex == 'Bất kỳ') ? filterCount : filterCount+1;
        let loaiGiaIndex = this._getGiaValue();
        let loaiGiaValue = (loaiGiaIndex == 'Bất kỳ') ? 'Mức giá - Bất kỳ' : loaiGiaIndex;
        let loaiGiaBgColor = (loaiGiaIndex == 'Bất kỳ') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let loaiGiaTextColor = (loaiGiaIndex == 'Bất kỳ') ? '#526173' : '#fff';
        filterCount = (loaiGiaIndex == 'Bất kỳ') ? filterCount : filterCount+1;
        let loaiDienTichIndex = this._getDienTichValue();
        let loaiDienTichValue = (loaiDienTichIndex == 'Bất kỳ') ? 'Diện tích - Bất kỳ' : loaiDienTichIndex;
        let loaiDienTichBgColor = (loaiDienTichIndex == 'Bất kỳ') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let loaiDienTichTextColor = (loaiDienTichIndex == 'Bất kỳ') ? '#526173' : '#fff';
        filterCount = (loaiDienTichIndex == 'Bất kỳ') ? filterCount : filterCount+1;
        let hasImage = this._getHasImageValue();
        let hasImageBgColor = (hasImage == 'Tất cả tin rao') ? 'rgba(82,97,115,0.25)' : gui.mainColor;
        let hasImageTextColor = (hasImage == 'Tất cả tin rao') ? '#526173' : '#fff';
        filterCount = (hasImage == 'Tất cả tin rao') ? filterCount : filterCount+1;
        let btnDisabled = this.props.loading;

        return (
            <View style={styles.viewTabFilter}>
                <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    scrollEnabled={!btnDisabled}
                >

                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: filterBgColor, marginLeft: 0, paddingLeft: 8 }]}
                                      onPress={this._onFilterPress.bind(this)}
                                      disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={styles.totalView}>
                                <Text style={styles.totalText}>{filterCount}</Text>
                            </View>
                            <Text style={[styles.textButtonTab, { color: filterTextColor }]}>{filterValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={filterTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiTinBgColor }]}
                        onPress={this._onModalMua.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiTinTextColor }]}>{loaiTinValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiTinTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiNhaDatBgColor }]}
                        onPress={this._onModalKieuNha.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiNhaDatTextColor }]}>{loaiNhaDatValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiNhaDatTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiGiaBgColor }]}
                        onPress={this._onModalMucGia.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiGiaTextColor }]}>{loaiGiaValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiGiaTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: loaiDienTichBgColor }]}
                        onPress={this._onModalDienTich.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: loaiDienTichTextColor }]}>{loaiDienTichValue}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={loaiDienTichTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.viewEachButtonTab, { backgroundColor: hasImageBgColor }]}
                        onPress={this._onModalHasImage.bind(this)}
                        disabled={btnDisabled}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={[styles.textButtonTab, { color: hasImageTextColor }]}>{hasImage}</Text>
                        </View>
                        <RelandIcon
                            name="caret-down" color={hasImageTextColor} size={22}
                            mainProps={styles.viewDownIcon}
                            noAction={true}
                        />
                    </TouchableOpacity>

                </ScrollView>
            </View>
        );
    }

    _renderTapList(isFront) {
        let buttonMapText = isFront ? 'Bản đồ' : 'Danh sách';
        let buttonIcon = isFront ? 'map' : 'list-alt';
        let buttonSize = isFront ? 16 : 18;
        let orderByKey = this.props.groupSearch.form.fields.orderBy || '';
        let textSort = DanhMuc.searchOrderSort[orderByKey];
        let iconName = this._getIconValue(orderByKey);
        let sortValue = iconName == 'sort';
        let textPostAds = 'Đăng tin';
        let btnDisabled = isFront && !this.state.isFront || !isFront && this.state.isFront ||
            this.props.loading || this.props.groupSearch.drawMode || this.state.openRadiusModal;
        return (
            <View style={styles.viewTabList}>
                <TouchableOpacity style={[styles.viewTabListContent, { width: width / 2 - 1 }]}
                    onPress={this._onListPressed.bind(this)}
                    disabled={btnDisabled}
                >
                    <Icon name={buttonIcon} size={buttonSize} color={gui.mainTextColor} style={{ marginRight: 12 }} />
                    <Text style={styles.textButtonMap}>{buttonMapText}</Text>
                </TouchableOpacity>
                <View style={styles.lineTab} />
                <TouchableOpacity style={[styles.viewTabListContent, { width: width / 2 - 1 }]}
                    onPress={this._onModalSapXep.bind(this)}
                    disabled={btnDisabled}
                >
                    {/*<Text style={styles.textButtonMap}>Giá:</Text>
                    <Text style={[styles.textButtonMap,{marginLeft: 5}]}>{textSort}</Text>*/}
                    <Text style={styles.textButtonMap}>{textSort}</Text>
                    {!sortValue ? (<Icon name={iconName} size={15} color={gui.mainTextColor} style={{ marginLeft: 4, marginRight: 5 }} />) : null}
                    <Icon name="sort" size={15} color={gui.mainTextColor} style={{ marginLeft: 10 }} />
                </TouchableOpacity>
            </View>
        );
    }

    _onPressAgentPost() {
        this.props.actions.onPostAdsFieldChange('photos', []);
        this.props.actions.onPostAdsFieldChange('imageIndex', 0);
        this.props.actions.onPostAdsFieldChange('pickMode', 'new');
        this.props.actions.onPostAdsFieldChange('loaiNhaDat', '');
        this.props.actions.onPostAdsFieldChange('dienTich', null);
        this.props.actions.onPostAdsFieldChange('matTien', null);
        this.props.actions.onPostAdsFieldChange('namXayDung', null);
        this.props.actions.onPostAdsFieldChange('soPhongNguSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soPhongNguText', '');
        this.props.actions.onPostAdsFieldChange('soNhaTamSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soNhaTamText', '');
        this.props.actions.onPostAdsFieldChange('soTangSelectedIdx', -1);
        this.props.actions.onPostAdsFieldChange('soTangText', '');
        this.props.actions.onPostAdsFieldChange("place", {
            duAn: '',
            duAnFullName: '',
            placeId: "ChIJKQqAE44ANTERDbkQYkF-mAI",
            diaChiChiTiet: '',
            diaChi: '',
            diaChinh: {
                tinh: '',
                huyen: '',
                xa: '',
                duAn: '',
                duong: '',
                tinhKhongDau: '',
                huyenKhongDau: '',
                xaKhongDau: '',
                codeTinh: '',
                codeHuyen: '',
                codeXa: '',
                codeDuAn: '',
                codeDuong: ''
            },
            geo: { lat: '', lon: '' }
        });
        let {currentUser} = this.props.global;
        let lienHe = {
            tenLienLac: currentUser.fullName,
            showTenLienLac: true,
            phone: currentUser.phone,
            showPhone: true,
            email: currentUser.email,
            showEmail: true
        };
        this.props.actions.onPostAdsFieldChange("lienHe", lienHe);
        this.props.actions.onPostAdsFieldChange('dangBoi', {
            userID: undefined,
            email: null,
            phone: null,
            name: null
        });
        this.props.actions.onPostAdsFieldChange('huongNha', null);
        this.props.actions.onPostAdsFieldChange('duongTruocNha', null);
        this.props.actions.onPostAdsFieldChange('nhaMoiXay', null);
        this.props.actions.onPostAdsFieldChange('nhaLoGoc', null);
        this.props.actions.onPostAdsFieldChange('otoDoCua', null);
        this.props.actions.onPostAdsFieldChange('nhaKinhDoanhDuoc', null);
        this.props.actions.onPostAdsFieldChange('noiThatDayDu', null);
        this.props.actions.onPostAdsFieldChange('chinhChuDangTin', null);
        this.props.actions.onPostAdsFieldChange('gia', null);
        this.props.actions.onPostAdsFieldChange('donViTien', 0);
        this.props.actions.onPostAdsFieldChange('chiTiet', '');
        this.props.actions.onPostAdsFieldChange('maSo', null);
        this.props.actions.onPostAdsFieldChange('error', '');
        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', null);
        this.props.actions.onPostAdsFieldChange('selectedDuAn', null);
        this.props.actions.onPostAdsFieldChange('duAnList', null);
        this.props.actions.onPostAdsFieldChange('serviceOrder', undefined);
        this.props.actions.onPostAdsFieldChange('id', null);
        this.props.actions.onPostAdsFieldChange('banGap', false);
        this.props.actions.onPostAdsFieldChange('title', undefined);
        this.props.actions.onPostAdsFieldChange('groupID', undefined);
        Actions.NewPostAdsDetail({groupID: this.props.groupID, owner: 'GroupFilterResult'});
    }

    _getIconValue(value) {
        let iconName = 'sort';
        let upValues = ['giaASC', 'giaM2ASC', 'dienTichASC'];
        let downValues = ['giaDESC', 'giaM2DESC', 'dienTichDESC'];
        if (upValues.includes(value)) {
            iconName = 'long-arrow-up';
        } else if (downValues.includes(value)) {
            iconName = 'long-arrow-down';
        }
        return iconName;

    }

    _onListPressed() {
        this._flip();
    }

    _renderNumberResult() {
        let result = this.getPagingTitle();
        return (
            <View style={styles.viewNumberResult}>
                <Text style={styles.textResult}>
                    {result}
                </Text>
            </View>
        );
    }

    getPagingTitle() {
        let myProps = this.props;
        let numberOfAds = myProps.listAds.length;
        let { diaChinh } = myProps.fields;
        let totalCount = myProps.totalCount;
        let pageNo = myProps.fields.pageNo;
        let limit = myProps.limit;
        let totalPages = totalCount / limit;
        let endAdsIndex = (pageNo - 1) * limit + numberOfAds;
        if (totalCount < endAdsIndex) {
            totalCount = endAdsIndex;
        }
        if (pageNo == totalPages) {
            totalCount = endAdsIndex;
        }
        let title = totalCount + ' kết quả';
        if (diaChinh.tinhKhongDau) {
            title += ' cho "' + diaChinh.fullName + '"';
        }
        return title;
    }

    _renderBottomControls() {
        let myProps = this.props;
        let totalCount = myProps.totalCount;
        let pageNo = myProps.fields.pageNo;
        let limit = myProps.limit;
        let totalPages = Math.ceil(totalCount / limit);
        if (totalPages == 0) {
            totalPages = 1;
        }
        let hasPreviousPage = pageNo > 1 && !myProps.groupSearch.drawMode;
        let previousColor = hasPreviousPage ? gui.mainColor : gui.colorMainBlur;

        let hasNextPage = pageNo < totalPages && !myProps.groupSearch.drawMode;
        let nextColor = hasNextPage ? gui.mainColor : gui.colorMainBlur;

        let numberItems =
            <View style={styles.viewNumberNext}>
                <Text style={styles.textButtonMap}>{pageNo}</Text>
                <Text style={[styles.textButtonMap, { color: gui.colorMainBlur }]}>{` / ` + totalPages}</Text>
                <Icon name="sort" size={9} color={gui.mainTextColor} style={{ marginLeft: 6 }} />
            </View>;

        return (
            <View style={styles.viewNextButtonResult}>
                <View style={styles.nextButtonContent}>
                    <TouchableOpacity style={styles.viewNextLeft}
                        onPress={this._doPreviousPage.bind(this)}
                        disabled={!hasPreviousPage}
                    >
                        <Icon name="chevron-left" size={16} color={previousColor} style={{ marginRight: 0 }} />
                    </TouchableOpacity>
                    <View style={styles.lineTab} />
                    {numberItems}
                    <View style={styles.lineTab} />
                    <TouchableOpacity style={styles.viewNextLeft}
                        onPress={this._doNextPage.bind(this)}
                        disabled={!hasNextPage}
                    >
                        <Icon name="chevron-right" size={16} color={nextColor} style={{ marginRight: 0 }} />
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _renderListGroupSearch() {
        let dsFilterGroup = ds_filterGroup.cloneWithRows(this.props.listAds);
        return (
            <View style={styles.viewListGroupSearch}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsFilterGroup}
                    renderRow={this._renderRowFilterGroup.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowFilterGroup(data) {
        return (
            <TouchableOpacity style={styles.viewListMyGroup}
                onPress={this._onPressFilterGroup.bind(this, data)}
            >
                {this._renderMainImagePost(data)}
                {this._renderDetailPost(data)}
            </TouchableOpacity>
        );
    }

    _onPressFilterGroup(ads) {
        Actions.GroupAdsDetail({ adsID: ads.adsID, imageDetail: ads.image.cover });
    }

    _renderMainImagePost(data) {
        // console.log('_renderMainImagePost **************** data', data)
        let image = data.image;
        let memberSourceUrl = image && image.cover;
        if (!memberSourceUrl && image && image.images && image.images.length > 0) {
            memberSourceUrl = image.images[0];
        }
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let imageMainPost = memberSourceUrl ? { uri: memberSourceUrl } : defaultCover;
        return (
            <ImageBackground style={[styles.imgItem, { height: gui.ADS_IMAGE_RATIO*width }]}
                source={imageMainPost} defaultSource={defaultCover}>
                {/*<LinearGradient colors={['rgba(50, 50, 50, 0.6)', 'rgba(50, 50, 50, 0.6)']}
                    style={styles.linearGradientMain}>*/}
                    {this._renderUserLogo(data)}
                    {/*{this._renderNamePrice(data)}*/}
                    {this.renderFrontLikeIcon(data.adsID)}
                {/*</LinearGradient>*/}
            </ImageBackground>
        )
    }

    renderFrontLikeIcon(adsID) {
        let isLiked = this.isLiked(adsID);
        // let color = isLiked ? '#A2A7AD' : 'white';
        let color = 'white';
        let bgColor = isLiked ? '#E50064' : '#4A443F';
        let bgStyle = isLiked ? {} : { opacity: 0.55 };
        if (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID) {
            return (
                <View style={{position: "absolute", left: width-55, backgroundColor:'transparent', top: 10}}>
                    <View style={styles.heartButton}>
                        <GiftedSpinner size="small" color="white"/>
                    </View>
                </View>
            )
        } else {
            return (
                <View style={{position: "absolute", left: width-75, backgroundColor:'transparent', top: 10}}>
                    <MHeartIcon onPress={() => this.onLike(adsID)} color={color} bgColor={bgColor} bgStyle={bgStyle} size={22}
                                mainProps={styles.heartButton} />
                </View>
            )
        }
    }

    _renderUserLogo(data) {
        let logoItems = [];

        let index = 0;

        if (data.banGap) {
            let marginLeft = index == 0 ? 0 : 8;
            let banGapText = data.loaiTin ? DanhMuc.THUE_GAP : DanhMuc.BAN_GAP;
            logoItems.push(
                <View key={'logoBanGap'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{banGapText}</Text>
                </View>
            );
            index++;
        }


        if (data.chinhChuDangTin) {
            let marginLeft = index == 0 ? 0 : 8;
            logoItems.push(
                <View key={'logoChinhChuDangTin'}
                    style={[styles.viewEachLogo, { marginLeft: marginLeft }]}>
                    <Text style={[styles.textSearch, { color: gui.mainTextColor }]}
                        onStartShouldSetResponder={(evt) => false}
                        onMoveShouldSetResponder={(evt) => false}
                    >{DanhMuc.CHINH_CHU}</Text>
                </View>
            );
            index++;
        }

        return (
            <View style={styles.viewUserLogo}>
                {logoItems}
            </View>
        );
    }

    _renderNamePrice(data) {
        let dangBoi = data.dangBoi;
        let userChildUrl = dangBoi && dangBoi.avatar;
        let defaultCover = require('../../assets/image/no_cover.jpg');
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let imageChildUser = userChildUrl ? { uri: userChildUrl } : defaultAvatar;
        let priceValue = data.giaFmt || utils.getPriceDisplay(data.gia, data.loaiTin);
        let nameUserChild = dangBoi && dangBoi.name;
        return (
            <View style={styles.viewNamePrice}>
                <View style={styles.viewPrice}>
                    <Text style={[styles.textNameGroup, { fontSize: 20 }]} numberOfLines={1}>{priceValue}</Text>
                </View>
                <View style={styles.viewUserPostChild}>
                    <View style={styles.viewNameUserChild}>
                        <Text style={[styles.textNameChild, { color: '#fff' }]} numberOfLines={1}>{nameUserChild}</Text>
                    </View>
                    {userChildUrl ?
                        <Image
                            resizeMode={"cover"}
                            source={imageChildUser}
                            defaultSource={defaultCover}
                            style={styles.mainUserChild} /> : null
                    }
                </View>
            </View>
        );
    }

    _renderDetailPost(data) {
        let loaiTin = data.loaiTin;
        let addressValue = data.diaChi || '';
        let loaiNhaDat = loaiTin ? DanhMuc.LoaiNhaDatThue[data.loaiNhaDat] : DanhMuc.LoaiNhaDatBan[data.loaiNhaDat];
        let featureItems = [];
        let index = 0;
        if (data.dienTichFmt && data.dienTichFmt != 'Không rõ') {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostAds} mainProps={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainPost, { marginLeft: 6 }]}>{data.dienTichFmt}</Text>
                </View>
            );
        }
        if (data.soPhongNgu) {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostAds} mainProps={{ marginLeft: marginLeft }} noAction={true} iconOnly={true} />

                    <Text style={[styles.textMainPost, { marginLeft: 6 }]}>{data.soPhongNgu}</Text>
                </View>
            );
        }

        if (data.soPhongTam) {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight noAction={true}
                                      name="bath" color={gui.textPostAds}
                                      mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainPost, { marginLeft: 6 }]}>{data.soPhongTam}</Text>
                </View>
            );
        }

        if (data.soTang) {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight noAction={true}
                                      name="building" color={gui.textPostAds}
                                      mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainPost, { marginLeft: 6 }]}>{data.soTang}</Text>
                </View>
            );
        }

        // if (data.ngayDangTin) {
        //     let now = moment();
        //     let ngayDangTin = moment(data.ngayDangTin, 'YYYYMMDD');
        //     let soNgayDaDangTin = now.diff(ngayDangTin, 'days');
        //     let soNgayDaDangTinFmt = soNgayDaDangTin > 0 ? soNgayDaDangTin + ' ngày trước' :
        //         'hôm nay';
        //     featureItems.push(
        //         <Text key={'feature_' + index++} style={styles.textTimePost} numberOfLines={1}>
        //             {soNgayDaDangTinFmt}
        //         </Text>
        //     );
        // }

        let date = moment(data.ngayDangTin).format("DD/MM/YYYY");
        let dateFmt = `Ngày đăng: ${date}`;
        let textMotionValue = data.title || utils.getTitleAdsDetail2(data);

        let priceValue = data.giaFmt || utils.getPriceDisplay(data.gia, data.loaiTin);

        let giaFmt = `Giá: ${priceValue}`;

        return (
            <View style={styles.viewDetailPost}>
                <View style={styles.viewMainTextPost}>
                    <Text style={[styles.textMainPost, {fontWeight: '500'}]} numberOfLines={2}>{textMotionValue}</Text>
                    <Text style={[styles.textDatePost, { marginLeft: 0, fontSize: 13 }]}>{dateFmt}</Text>
                </View>
                <View style={[styles.lineDangNhap, { width: width - 48, marginLeft: 24, marginRight: 24 }]} />
                <View style={styles.viewPrice}>
                    <Text style={[styles.textNameGroup, { fontSize: 17 }]} numberOfLines={1}>{giaFmt}</Text>
                </View>
                <View style={styles.viewTextAddress}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostAds} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainPost, {marginLeft: 8}]} numberOfLines={1}>{addressValue}</Text>
                </View>
                { featureItems && featureItems.length > 0 ? (
                    <View style={styles.viewContentSource}>
                        {featureItems}
                    </View>) : null
                }
                {/*<View style={[styles.lineDangNhap, { marginLeft: 0, marginRight: 0, width: width - 32 }]} />*/}
            </View>
        )
    }


    _onModalMua() {
        this.setState({
            isOpenModalLoaiTin: true
        });
    }

    _onModalKieuNha() {
        this.setState({
            isOpenModalLoaiNhaDat: true
        })
    }
    _onModalMucGia() {
        this.setState({
            isOpenModalMucGia: true
        })
    }

    _onModalDienTich() {
        this.setState({
            isOpenModalDienTich: true
        })
    }

    _onModalHasImage() {
        this.setState({
            isOpenModalHasImage: true
        })
    }

    _onBackPress() {
        Actions.pop();
    }

    _onFilterPress() {
        if (this.state.searchFilter2Actived) {
            this._loadSearchFilter(this.props.fields);
        }
        this.setState({ searchFilter2Actived: !this.state.searchFilter2Actived });
    }

    _isSameViewport() {
        let { viewport, diaChinhViewport } = this.props.fields;
        // log.info('======viewport', viewport, diaChinhViewport);
        if (!diaChinhViewport) {
            return true;
        }
        let region = apiUtils.getRegionByViewport(viewport);
        let diaChinhRegion = apiUtils.getRegionByViewport(diaChinhViewport);

        return Math.abs(region.latitude - diaChinhRegion.latitude) <= PADDING
            && Math.abs(region.longitude - diaChinhRegion.longitude) <= PADDING
            // && Math.abs(region.latitudeDelta - diaChinhRegion.latitudeDelta) <= PADDING
            && Math.abs(region.longitudeDelta - diaChinhRegion.longitudeDelta) <= PADDING;
    }

    _getHeaderTitle() {
        let diaChinh = this.props.fields.diaChinh;

        //1. Search by diaChinh, then name = diaChinh's name
        if (this.props.polygons && this.props.polygons.length) {
            //placeName = `[${r.latitude}, ${r.longitude}]`
            return 'Trong khu vực vẽ tay';
        }

        // if (this.props.groupSearch.drawMode) {
        //     return 'Vẽ khu vực muốn tìm';
        // }

        if (this.props.fields.center && Object.keys(this.props.fields.center).length > 0) {
            let { region } = this.state;
            let { center } = this.props.groupSearch.form.fields;
            let isCurrentPos = center && Math.abs(center.lat - region.latitude) <= PADDING
                && Math.abs(center.lon - region.longitude) <= PADDING;
            if (isCurrentPos) {
                return 'Xung quanh vị trí hiện tại';
            }
        }

        if (this.props.groupSearch.form.fields.circle && Object.keys(this.props.groupSearch.form.fields.circle).length > 0) {
            return 'Xung quanh địa điểm';
        }

        let placeName;
        //2. Search by Polygon: name is just center
        if (diaChinh && diaChinh.tinhKhongDau) {
            placeName = diaChinh.fullName;
        } else if (diaChinh && diaChinh.fullName && diaChinh.fullName != gui.VI_TRI_HIEN_TAI) {
            placeName = diaChinh.fullName;
        } else { //others: banKinh or currentLocation
            //let geoBox = apiUtils.getBbox(r);
            //placeName = geoBox.toString()
            placeName = gui.KHUNG_NHIN_HIEN_TAI;
        }

        return placeName;
    }

    _renderInputFilter(btnDisabled) {
        let placeName = this._getHeaderTitle();
        let isSameViewport = this._isSameViewport();
        let tagName = isSameViewport ? '' : 'Khung bản đồ';
        let inputWidth = this.state.searchFilter2Actived ? width - 77 : width - 65;
        let textWidth = this.state.searchFilter2Actived ? width - 107 : width - 95;
        let marginLeft = this.state.searchFilter2Actived ? 17 : 0;
        return (
            <TouchableOpacity style={{ height: 36, width: inputWidth, marginLeft: marginLeft, backgroundColor: '#fff' }}
                              onPress={() => {
                    this.refs.placeSuggestion && this.refs.placeSuggestion.focusInputSearch();
                    this._flipSuggestion();
                }
                }
                              disabled={btnDisabled}
            >
                <View style={styles.viewInputFilter}>
                    <View style={styles.viewConditions}>
                        {tagName ? <Tag
                            type="DiaChinh"
                            index={1}
                            label={tagName}
                            isLastTag={true}
                            onLayoutLastTag={this.onLayoutLastTag}
                            removeIndex={(index) => this._reloadDiaChinhViewport()}
                            tagColor={gui.mainTextColor}
                            tagTextColor='#fff'
                            tagContainerStyle={{ marginBottom: 3, borderRadius: 5 }}
                        /> : null}
                        {placeName ?
                            <View style={styles.diaChiView}>
                                <View style={{ width: isSameViewport ? textWidth : textWidth - 122 }}>
                                    <Text style={styles.diaChiText} numberOfLines={1}>{placeName}</Text>
                                </View>
                            </View>
                            : null}
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _reloadDiaChinhViewport() {
        let { diaChinhViewport } = this.props.fields;
        this.props.actions.onGroupSearchFieldChange('viewport', diaChinhViewport);
        let region = apiUtils.getRegionByViewport(diaChinhViewport);
        this.setState({ region: region, oldRegion: region });

        this.props.actions.onGroupSearchFieldChange("pageNo", 1);
        this._refreshListData(diaChinhViewport, null, () => {
            this._onShowMessage()
        }, null, false, null);
    }

    onLayoutLastTag = (endPosOfTag: number) => {
        const margin = 3;
        this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
        const inputWidth = GroupFilterResult.inputWidth(
            this.state.text,
            this.spaceLeft,
            this.wrapperWidth,
        );
        if (inputWidth !== this.state.inputWidth) {
            this.setState({ inputWidth });
        }
    };

    static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
        if (text === "") {
            return 90;
        } else if (spaceLeft >= 100) {
            return spaceLeft - 10;
        } else {
            return wrapperWidth;
        }
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    mainContainer: {
        position: 'absolute',
        top: 52,
        left: 0,
        right: 0,
        height: height - 96
    },
    scrollView: {
        flexGrow: 1,
        position: 'absolute',
        height: height - 44
    },
    viewFilterHeader: {
        marginTop: 10,
        height: 50,
        justifyContent: 'flex-start',
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 14,
        backgroundColor: '#fff'
    },
    viewBackButton: {
        width: 56,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewInputFilter: {
        flex: 1,
        borderRadius: 5,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: gui.groupBackground,
        paddingLeft: 7
    },
    speachIcon: {
        position: 'absolute',
        top: 10,
        right: 17
    },
    viewConditions: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start'
    },
    tabFilterContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 64,
        flexDirection: 'column'
    },
    viewTabFilter: {
        height: 52,
        paddingVertical: 8,
        paddingHorizontal: 8,
        width: width,
    },
    viewDownIcon: {
        marginBottom: 0,
        justifyContent: 'flex-end',
        height: 21,
        marginTop: 30
    },
    viewEachButtonTab: {
        paddingHorizontal: 12,
        paddingVertical: 9,
        // height: 32,
        borderRadius: 4,
        marginLeft: 8,
        marginTop: 0,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: 'rgba(82,97,115,0.25)'
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainTextColor,
        textAlign: 'left',
        marginRight: 8,
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 16,
        opacity: 0.8,
        marginLeft: 8,
        marginRight: 8
    },
    viewTabList: {
        height: 40,
        width: width,
        borderBottomWidth: 1,
        borderColor: '#dcdcdc',
        flexDirection: 'row'
    },
    viewTabListContent: {
        width: width / 3,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    lineTab: {
        width: 1,
        backgroundColor: '#dcdcdc',
        height: 24,
        opacity: 0.8,
        marginTop: 8,
        marginBottom: 8
    },
    textButtonMap: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainTextColor,
    },
    viewNumberResult: {
        width: width,
        // height: 64,
        marginTop: 8,
        marginBottom: 8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textResult: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.colorMainBlur,
    },
    viewListGroupSearch: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewListContainer: {
        paddingBottom: 15
    },
    viewListMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginBottom: 8
    },
    imgItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width - 16,
        height: imageGroup,
        alignSelf: 'auto'
    },
    viewNameGroup: {
        position: 'absolute',
        left: 16,
        bottom: 50,
        height: 36,
        width: width - 180,
        backgroundColor: 'transparent'
    },
    viewTotalMembers: {
        position: 'absolute',
        left: 16,
        bottom: 26,
        height: 20,
        width: width - 180,
        backgroundColor: 'transparent'
    },
    textNameGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: gui.textPostAds,
        fontWeight: '500',
    },
    textTotalMembers: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: 'rgba(255,255,255,0.75)',
        fontWeight: 'normal'
    },
    linearGradient2: {
        marginTop: 0,
        height: imageGroup,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    linearGradientMain: {
        marginTop: 0,
        height: 216,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewButtonGroup: {
        width: width,
        height: 56,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewEachButton: {
        height: 56,
        width: (width - 16) / 4,
        backgroundColor: '#fff',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: 5
    },
    textBottonGroup: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: 'normal'
    },
    sortDescIcon: {
        position: 'absolute',
        top: 14,
        right: 18
    },
    viewNewRequest: {
        height: 32,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    viewBodyMyGroup: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 8
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    viewUserLogo: {
        position: 'absolute',
        left: 15,
        bottom: 17,
        height: 24,
        // width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 15,
        bottom: 13,
        height: 32,
        width: width - 30,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 28,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        width: width - 18,
        paddingLeft: 17,
        paddingRight: 17
    },
    viewUserPostChild: {
        height: 32,
        width: (width - 30) / 2,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    mainUserChild: {
        height: 26,
        width: 26,
        borderRadius: 13
    },
    viewNameUserChild: {
        height: 32,
        width: (width - 30) / 2 - 33,
        marginRight: 7,
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundColor: 'transparent',
    },
    textNameChild: {
        fontSize: 12,
        color: '#fff',
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewDetailPost: {
        // height: 105,
        width: width - 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderTopWidth: 0,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 15,
        color: gui.textPostAds,
        fontFamily: gui.fontFamily
    },
    viewContentSource: {
        height: 24,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 4
    },
    viewTextAddress: {
        // height: 28,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: 4
    },
    textTimePost: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        position: 'absolute',
        right: 17
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewNextButtonResult: {
        height: 40,
        width: 156,
        justifyContent: 'flex-start',
        alignItems: 'center',
        position: 'absolute',
        bottom: 11,
        left: width / 2 - 78,
        backgroundColor: 'transparent'
    },
    nextButtonContent: {
        height: 38,
        width: 154,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 4,
        borderColor: gui.colorMainBlur,
        borderWidth: 1,
        backgroundColor: '#fff',
        opacity: 0.9
    },
    viewNextLeft: {
        height: 38,
        width: 41,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewNumberNext: {
        height: 38,
        width: 70,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewLoaderAds: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    viewChildRow: {
        width: width,
        height: gui.ADS_IMAGE_RATIO*width,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingLeft: 17,
        borderBottomWidth: 1,
        borderColor: '#eaebed'
    },
    viewLineLoaderRow: {
        height: 14,
        width: width / 3,
        backgroundColor: 'rgba(234, 234, 234, 0.5)',
        marginBottom: 8
    },
    diaChiText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    diaChiView: {
        backgroundColor: gui.groupBackground,
        paddingVertical: 5,
        paddingHorizontal: 8
    },
    viewModalStyle: {
        justifyContent: 'center',
        height: 359,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewLoaiTinStyle: {
        justifyContent: 'center',
        height: 120,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewLoaiNhaDatStyle: {
        justifyContent: 'center',
        height: 409,
        width: width - 60,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    textSapxep: {
        fontSize: 17,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    fullWidthContainer: {
        flexGrow: 1,
        flexDirection: 'column',
        alignItems: 'stretch',
        backgroundColor: 'transparent'
    },
    map: {
        flex: 1,
        position: 'absolute',
        top: 40,
        left: 0,
        right: 0,
        bottom: 0
    },
    mapView: {
        flex: 1,
        marginTop: 0,
        marginBottom: 0
    },
    bubble: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 2,
        paddingVertical: 2,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 5
    },
    bubble2: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 2,
        paddingVertical: 2,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 13
    },
    button: {
        width: 43,
        height: 38,
        paddingVertical: 2,
        alignItems: 'center',
        marginVertical: 2,
        backgroundColor: 'white',
        opacity: 0.75,
        marginLeft: 15
    },
    viewIconDiaDiem: {
        flex: 1,
        backgroundColor: 'transparent',
        justifyContent: 'flex-end'
    },
    textIconDiaDiem: {
        backgroundColor: 'white',
        fontSize: 8
    },
    drawIconText: {
        fontSize: 8,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'center'
    },
    refreshButton: {
        position: 'absolute',
        bottom: 13,
        left: width / 2 - 21,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    previousButton: {
        position: 'absolute',
        bottom: 13,
        left: width / 2 - 79,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    nextButton: {
        position: 'absolute',
        bottom: 13,
        left: width / 2 + 37,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    helpButton: {
        position: 'absolute',
        bottom: 13,
        left: width - 56,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#C5C2BA',
        width: 43,
        height: 38,
        backgroundColor: 'white',
        opacity: 0.9,
    },
    imageHelp: {
        backgroundColor: 'transparent'
    },
    pagingView: {
        paddingTop: 0,
        width: 35,
        height: 32,
        backgroundColor: 'transparent'
    },
    viewToastMap: {
        width: width,
        height: 118,
        backgroundColor: 'transparent',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom: 50,
        borderRadius: 5,
        borderWidth: 0
    },
    viewModalTop: {
        width: 240,
        height: 69,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'rgba(169, 168, 168, 0.01)',
        paddingTop: 10,
        paddingRight: 6
    },
    viewBoxTop: {
        width: 240,
        height: 69,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'rgba(169, 168, 168, 0.01)',
        paddingTop: 10
    },
    viewAnimatable: {
        width: 240,
        height: 60,
        backgroundColor: '#fff',
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 6
    },
    viewIconClose: {
        height: 20,
        width: 20,
        borderRadius: 10,
        backgroundColor: '#b6b6b6',
        left: 106,
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        marginTop: -20
    },
    textContent: {
        color: '#5f5f5f',
        fontSize: 13,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    triangle: {
        width: 0,
        height: 0,
        backgroundColor: 'transparent',
        borderStyle: 'solid',
        borderLeftWidth: 6,
        borderRightWidth: 6,
        borderBottomWidth: 9,
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderBottomColor: '#fff',
        transform: [
            { rotate: '180deg' }
        ],
        marginLeft: 10
    },
    detailAdsModal: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
        height: imageHeight,
        width: width
    },
    detailAdsModalThumb: {
        justifyContent: 'flex-end',
        alignItems: 'stretch',
        height: imageHeight,
        width: width,
        alignSelf: 'auto'
    },
    detailAdsModalLinearGradient: {
        flex: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    detailAdsModalPrice: {
        fontSize: 17,
        fontWeight: '500',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 10,
        color: 'white'
    },
    detailAdsModalText: {
        fontSize: 15,
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 10,
        marginBottom: 15,
        margin: 5,
        color: 'white'
    },
    detailAdsModalTextHeartButton: {
        marginBottom: 10
    },
    detailAdsModalDetail: {
        backgroundColor: 'transparent',
        flexDirection: 'row',
        justifyContent: 'space-between',
        top: 83,
        width: width
    },
    adsModal: {
        justifyContent: 'center',
        alignItems: 'center',
        height: imageHeight,
        width: width,
        marginVertical: 0,
    },
    searchListView: {
        marginTop: 0,
        margin: 0,
        backgroundColor: 'white'
    },
    adsNoPosContainer: {
        position: 'absolute',
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        bottom: 10,
        right: 14,
        width: 55,
        backgroundColor: 'transparent'
    },
    searchListButton2: {
        flexDirection: 'column',
        justifyContent: 'space-between',
        width: width,
        backgroundColor: 'transparent',
        height: 100,
        borderTopWidth: 1,
        borderColor: 'lightgray'
    },
    backButton: {
        width: 60,
        paddingTop: 5,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingRight: 18,
        paddingLeft: 5
    },
    backButtonText: {
        color: gui.mainColor,
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 5
    },
    viewTopNav: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        backgroundColor: 'white',
        height: 30,
        width: width
    },
    textSpaceTop: {
        fontSize: 15,
        color: '#333333',
        textAlign: 'center',
        alignItems: 'center',
    },
    viewCenterNav: {
        backgroundColor: 'white',
        height: 40,
        width: width - 30,
        right: 15,
        left: 15,
        alignItems: 'stretch',
        justifyContent: 'center',
        flexDirection: 'column'
    },
    track: {
        height: 2,
        borderRadius: 1,
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: gui.mainColor,
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    viewBottomNav: {
        backgroundColor: 'white',
        height: 30,
        width: width,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewTextBottom: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        flexDirection: 'row',
        backgroundColor: 'transparent'
    },
    textBottomLeft: {
        fontSize: 13,
        flex: 1,
        color: '#676769',
        textAlign: 'right',
        marginBottom: 5,
        paddingRight: 3,
    },
    textBottomCenter: {
        fontSize: 13,
        flex: 5,
        color: '#676769',
        textAlign: 'left',
        marginBottom: 5,
    },
    textBottomRight: {
        fontSize: 13,
        flex: 1,
        color: '#676769',
        textAlign: 'right',
        paddingRight: 15,
        marginBottom: 5
    },
    customPageRightTitle: {
        alignItems: 'flex-end',
        justifyContent: 'center',
        height: 25,
        width: 60,
        paddingTop: 5,
        paddingRight: 5,
        backgroundColor: 'transparent'
    },
    customPageRightTitleText: {
        color: gui.mainColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        textAlign: 'right',
        fontWeight: '500'
    },
    viewMeasure: {
        backgroundColor: 'transparent',
        height: 5,
        width: width - 30,
        right: 15,
        left: 15,
        bottom: 8,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row'
    },
    sliderDotOne: {
        backgroundColor:gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        left: 6
    },
    sliderDotTwo: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        marginLeft: (width - 30) / 10
    },
    sliderDotThree: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        marginLeft: (width - 30) / 10 - 7
    },
    sliderDotFour: {
        backgroundColor: gui.mainColor,
        height: 5,
        width: 5,
        borderRadius: 5,
        marginLeft: (width - 30) / 10 - 6
    },
    modal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        height: 150,
        width: width - 40,
        marginVertical: 0,
        borderRadius: 5
    },
    modalHeader: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'center',
        alignItems: 'center',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 10,
        paddingBottom: 10,
        borderTopWidth: 1,
        marginVertical: 0,
        width: width - 40,
        borderTopColor: '#f8f8f8',
        borderRadius: 5
    },
    modalHeaderText: {
        fontSize: 17,
        fontWeight: '600',
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 0,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    modalTitle: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 8,
        paddingBottom: 8,
        borderTopWidth: 1,
        marginVertical: 0,
        width: width - 40,
        borderTopColor: '#f8f8f8',
        backgroundColor: '#f8f8f8'
    },
    modalTitleText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: '#606060',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 0,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    viewModalHelp: {
        justifyContent: 'center',
        height: height - 180,
        width: width - 30,
        marginVertical: 0,
        borderRadius: 8
    },
    viewContentHelp: {
        flex: 1,
        marginBottom: 10
    },
    textFullWidth: {
        textAlign: 'justify',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#9c9c9c',
        marginTop: 6,
        marginBottom: 6,
        marginLeft: 32
    },
    mapButtonContainer: {
        position: 'absolute',
        bottom: 10,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginVertical: 5,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    loadingContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        width: width,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent',
    },
    resultText: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        width: width,
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor: 'transparent',
        opacity: 0.85
    },
    resultIcon: {
        color: '#03a0da',
        fontSize: gui.capitalizeFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'center'
    },
    titleText: {
        backgroundColor: 'transparent',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600'
    },
    totalView: {
        width: 24,
        height: 24,
        marginRight: 8,
        borderRadius: 4,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    },
    totalText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        color: gui.mainColor,
        textAlign: 'left'
    },
    heartButton: {
        marginTop: 6
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupFilterResult);