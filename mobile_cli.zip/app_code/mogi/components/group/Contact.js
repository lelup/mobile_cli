import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    FlatList,
    RefreshControl,
    TouchableHighlight
} from 'react-native';

import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import { Actions } from 'react-native-router-flux';
import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import DanhMuc from '../../assets/DanhMuc';
import GiftedSpinner from "../GiftedSpinner";
import SearchInput from './SearchInputAgent';
import TruliaIcon from '../TruliaIcon';
var Contacts = require('react-native-contacts');

import userApi from '../../lib/userApi';
// import { DocumentPicker, DocumentPickerUtil } from 'react-native-document-picker';
import FunctionModal from '../FunctionModal';

import AnimatedSprite from '../animatedSprite/AnimatedSprite';
import newContactButton from './NewContactButton';
import OfflineBar from '../line/OfflineBar';

var Analytics = require('react-native-firebase-analytics');

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';

import GroupLikeTabButton from './GroupLikeTabButton';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';
let ds_listAlert = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });

const minLength = 0;

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class Contact extends Component {
    constructor(props) {
        super(props);
        this.state = {
            laoding: false,
            searchText: '',
            phanLoai: props.groupContact.selectedContactTab,
            contactList: props.groupContact.contactList,
            isOpenMoreModal: false,
            selectedEvent: null,
            focused: false,
            text: props.groupContact.searchContact,
            isOpenModalSapxep: false,
            isOpenNewModal: false,
            orderByKey: '',
            toggleState: false,
            scroll: true
        }

        this._onAddContact = this._onAddContact.bind(this);
        this._onImportFromDevice = this._onImportFromDevice.bind(this);

    }

    componentWillReceiveProps(nextProps) {
        if (this.props.groupContact.selectedContactTab !== nextProps.groupContact.selectedContactTab) {
            this.setState({ phanLoai: nextProps.groupContact.selectedContactTab });
        }
        if (this.props.groupContact.contactList !== nextProps.groupContact.contactList) {
            this.setState({ contactList: nextProps.groupContact.contactList });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeader()}

                <View style={{ flex: 1 }}>
                    {this._renderBodyGroupMgmt()}
                </View>
                {this._renderNewContact()}

                {this._renderLoadingView()}
                {this._openMoreModal()}
                {this._openModalSapxep()}
                {this._openNewModal()}
            </View>
        );
    }

    _renderNewContact() {
        if (this.props.owner == 'MyTodoNotes' || this.props.owner == 'ContactRespond' || this.props.owner == 'AgentWto') {
            return null;
        }
        return (
            <AnimatedSprite
                ref={'newContactRef'}
                sprite={newContactButton}
                animationFrameIndex={[]}
                loopAnimation={true}
                coordinates={{
                    top: height - 144,
                    left: width - 88,
                }}
                size={{
                    width: newContactButton.size.width,
                    height: newContactButton.size.height,
                }}
                draggable={true}
                tweenStart={'fromMethod'}
                onPress={() => { this._onNewButtonPress(); }}
            >
                <View style={styles.viewNewContact}>
                    {/*<FontAwesomeLight name="plus" size={22} color={gui.mainColor} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />*/}

                    <MaterialCommunityIcons name="plus" color={gui.mainColor} size={32} style={{ marginTop: 2 }} />
                </View>
            </AnimatedSprite>
        );
    }

    _renderHeader() {
        let orderByKey = this.state.orderByKey || '';
        let textTangDan = DanhMuc.contactOrder[orderByKey];

        let phanLoaiContact = [
            { code: 'all', text: 'Tất cả' },
            { code: 'favorite', text: 'Ưa thích' },
            { code: 'important', text: 'Khách nét' },
            { code: 'new', text: 'Khách mới' },
            { code: 'investor', text: 'Nhà đầu tư' },
            { code: 'canceled', text: 'Không mua nữa' },
            { code: 'bought', text: 'Đã mua' },
        ].map((e) => {
            e.tabColor = this.state.phanLoai == e.code ? styles.selectedButtonTab : {};
            e.textColor = this.state.phanLoai == e.code ? styles.selectedButtonText : {};
            return e;
        });

        let showBackButton = this.props.owner == 'MyTodoNotes' || this.props.owner == 'ContactRespond' || this.props.owner == 'AgentWto';
        let searchInputWidth = showBackButton ? width - 58 : width - 70;

        let numberInbox = 0;
        if (this.props.inbox.listHomeInbox) {
            let allGroupInboxDS = this.props.inbox.listHomeInbox.filter((one) => {
                let valid = one.content != undefined && (!one.spamStatus || (one.spamStatus != 1 && one.spamStatus != 2));
                return valid && !!one.numOfUnreadMessage;
            }) || [];
            numberInbox = allGroupInboxDS.length;
        }

        return (
            <View style={styles.headerView}>


                <View style={styles.subHeader2}>
                    {
                        showBackButton ?
                            (<TouchableOpacity onPress={this._onBackButton.bind(this)}
                                style={styles.viewSortAlphabet}
                            >
                                <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                            </TouchableOpacity>) :
                            <TouchableOpacity style={styles.viewIconProfile}
                                              onPress={this.onPressChat.bind(this)}
                            >
                                <FontAwesomeLight name="comment-dots" size={24} color={gui.mainColor} noAction={true} iconOnly={true} />
                                {numberInbox ?
                                    <View style={styles.numberOfMessage2}>
                                        <Text style={styles.numberInbox}>{numberInbox}</Text>
                                    </View>
                                    : null
                                }
                            </TouchableOpacity>
                    }

                    <View style={styles.viewTextInput}>
                        <SearchInput ref="searchInput"
                            owner='Contacts'
                            placeholder="Tìm trong khách hàng"
                            placeholderTextColor={gui.arrowColor}
                            textValue={this.state.text}
                            onChangeText={this._onChangeText.bind(this)}
                            onFocus={this._onFocus.bind(this)}
                            showCloseButton={this.state.focused && this.state.text != ''}
                            editable={true}
                            searchContainer={styles.searchContainer}
                        />

                    </View>

                    {/*<TouchableOpacity onPress={this._onModalSapXep.bind(this)}
                                      style={styles.viewSortAlphabet}
                    >
                        <FontAwesomeLight name="sort" size={18} color={gui.mainColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>*/}

                    {showBackButton ? null :
                        <TouchableOpacity style={styles.viewIconProfile}
                            onPress={this.onPressMyAlert.bind(this)}
                        >
                            <FontAwesomeLight name="bell" size={23} color={gui.mainColor} noAction={true} iconOnly={true} />
                            {this.props.me.pushMessage == 1 ?
                                <View style={styles.notification} />
                                : null
                            }
                        </TouchableOpacity>
                    }

                </View>

                <View style={styles.tabHeader}>
                    <ScrollView
                        horizontal={true}
                        showsHorizontalScrollIndicator={false}
                        scrollEnabled={true}
                        contentContainerStyle={{marginRight: 10, marginLeft: 10}}
                    >
                        {
                            phanLoaiContact.map(e => {
                                return (
                                    <GroupLikeTabButton name={e.code}
                                                        key={e.code}
                                        onPress={this._onTabChange.bind(this)}
                                        selected={this.state.phanLoai === e.code}>{e.text}</GroupLikeTabButton>
                                )
                            })
                        }

                    </ScrollView>
                </View>
                <FullLine style={{ marginTop: 0 }} />

            </View>
        );

    }

    onPressMyAlert() {
        Actions.MyAlert();

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_CONTACT_NOTIFICATION', { deviceID: deviceID, userID: userID });
    }

    onPressChat() {
        Actions.GroupInbox();

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_CONTACT_INBOX', { deviceID: deviceID, userID: userID });
    }

    _onContentModal() {
        this.setState({
            isOpenModalSapxep: false,
        });
    }

    _onModalSapXep() {
        this.setState({ isOpenModalSapxep: true });
    }

    _openModalSapxep() {
        return (
            <Modal isOpen={this.state.isOpenModalSapxep}
                onClosed={this._onContentModal.bind(this)}
                style={[styles.viewModalStyle, {width: width - 16}]}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
                animationDuration={200}
            >
                {this._renderSapXepContent()}
            </Modal>
        );

    }

    _renderSapXepContent() {
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    {this._renderTextSapxep()}
                    {this._renderTextCancel()}
                </View>
                {
                    DanhMuc.getContactOrderValues().map((e, index) => {
                        let orderByKey = this.state.orderByKey || '';
                        let orderByValue = DanhMuc.contactOrder[orderByKey];
                        let checked = e == orderByValue;
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, { borderTopWidth: borderTopWidth }]}
                                key={e}
                                onPress={() => this._onChooseContactOrder(e)}>
                                <Text style={[styles.textSapxep, {color: gui.textAgentSolid}]}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }
                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        )
    }

    _onNewButtonPress(data) {
        this.setState({ isOpenNewModal: true });

        //bach demo upload file
        // DocumentPicker.show({
        //     filetype: [DocumentPickerUtil.allFiles()],
        // }, (error, res) => {
        //     // Android
        //     console.log(
        //         res.uri,
        //         res.type, // mime type
        //         res.fileName,
        //         res.fileSize
        //     );
        // });

    }

    _outNewModal() {
        this.setState({
            isOpenNewModal: false
        });
    }

    _openNewModal() {
        let modalHeight = 173 + 50;
        return (
            <Modal isOpen={this.state.isOpenNewModal}
                onClosed={this._outNewModal.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto', bottom:50 }]}
                position={"bottom"}
                backdropPressToClose={true}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderNewModalContent()}
            </Modal>
        );

    }

    _renderNewModalContent() {
        
        let items = [
            {_text: `Thêm khách hàng`, _function: () => this._onAddContact()},
            {_text: `Nhập từ danh bạ máy`, _function: () => this._onImportFromDevice()},
        ]
        return (
            <FunctionModal 
                //data={data}                
                items={items}
                onCloseModal={this._outNewModal.bind(this)} />
        )
    }

    _onImportFromDevice() {
        this.onLogEvent("Danh bạ thêm từ máy");
        this._outNewModal();
        Contacts.requestPermission((err, permission) => {
            Contacts.getAll((err, contacts) => {
                if (err === 'denied') {
                    // error
                } else {                    
                    contacts = contacts.filter((e) => {return e.phoneNumbers && e.phoneNumbers.length>0})

                    contacts.forEach(e => {
                        e.checked = false;
                        e.canInvite = true;

                        let contactInReducer = this.props.groupContact.allDeviceContactList.filter((f) => { return f.recordID == e.recordID })

                        if (contactInReducer && contactInReducer.length > 0) {
                            e.canInvite = contactInReducer[0].canInvite
                        }

                        let contactPhone = e.phoneNumbers && e.phoneNumbers.length > 0 ? e.phoneNumbers[0].number.trim() : '';
                        contactPhone = contactPhone.replace(/\D/g, '')
                        if (contactPhone.startsWith('84'))
                            contactPhone = '0' + contactPhone.slice(2, contactPhone.length);

                        let contactList = this.state.contactList;
                        let existedInDanhBa = contactList.filter((e) => { return e.contactPhone == contactPhone })
                        if (existedInDanhBa && existedInDanhBa.length > 0)
                            e.canInvite = false;
                    })

                    this.setState({ 'deviceContactList': contacts })
                    this.props.actions.onGroupContactFieldChange('allDeviceContactList', contacts)
                    this.props.actions.onGroupContactFieldChange('filteredDeviceContactList', contacts)
                    Actions.ContactImport({ text: this.state.text, request: (value) => this._request(value) });
                }
            })

        });

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_CONTACT_IMPORT', { deviceID: deviceID, userID: userID });
    }

    onLogEvent(title) {
        let eventDto = {
            scene: "Contact",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onChooseContactOrder(contactOrderValue) {
        let newOrderBy = DanhMuc.findContactOrderKey(contactOrderValue);
        this.setState({
            isOpenModalSapxep: false,
            orderByKey: newOrderBy
        });

        this.props.actions.onGroupContactFieldChange("orderBy", newOrderBy);
        let currentUser = this.props.global.currentUser;

        if (this.state.text && this.state.text.length > minLength) {
            // this.props.actions.onGroupContactFieldChange('contactList', [])
            let searchTextStandardlized = utils.locDauV2(utils.standardlizeName(this.state.text));
            this.props.actions.searchContact(
                {
                    'userID': this.props.global.currentUser.userID,
                    'searchText': searchTextStandardlized,
                    'orderBy': newOrderBy
                }
                , (res) => {
                    //start sort                    
                }
                , (error) => {
                    log.info('server respond error: =====>>>>>', error)
                });
        }
        else {
            // this.props.actions.onGroupContactFieldChange('contactList', [])
            this.props.actions.getAllContact(
                { 'userID': currentUser.userID, 'orderBy': newOrderBy }
                , (res) => {
                }
                , (error) => {
                    log.info('server respond data: =====>>>>>', error)
                });
        }
    }

    _renderTextSapxep() {
        return (
            <View style={styles.viewSortModal}>
                <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17, color: gui.textAgentSolid }]}>Sắp xếp</Text>
            </View>
        );
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );
    }

    _renderSeparator() {
        return (
            <View style={styles.separatorLine}></View>
        )
    }

    _onFocus() {
        !this.state.focused && this.setState({ focused: true });
    }

    _onChangeText(text) {

        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            text: text
        });
    }

    _request(text) {
        if (text && text.length > minLength) {
            this._requestContact(text);
        } else {
            let searchContact = text || undefined;
            // this.props.actions.onGroupContactFieldChange('contactList', [])
            this.props.actions.getAllContact(
                {
                    'userID': this.props.global.currentUser.userID,
                    'orderBy': this.props.groupContact.orderBy
                }
                , (res) => {
                }
                , (error) => {
                    log.info('server respond error: =====>>>>>', error)
                });
        }

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_CONTACT_SEARCH', { deviceID: deviceID, userID: userID });
    }

    _requestContact(text) {

        let searchContact = text || undefined;
        // this.props.actions.onGroupContactFieldChange('contactList', [])
        let searchTextStandardlized = utils.locDauV2(utils.standardlizeName(searchContact));
        this.props.actions.searchContact(
            {
                'userID': this.props.global.currentUser.userID,
                'searchText': searchTextStandardlized,
                'orderBy': this.props.groupContact.orderBy
            }
            , (res) => {
            }
            , (error) => {
                log.info('server respond error: =====>>>>>', error)
            });
    }

    _onBackButton() {
        // Actions.pop();
        // let userInfo = { deviceID: this.props.global.currentUser.deviceID, userID: this.props.global.currentUser.userID };
        Actions.pop();
    }

    _onAddContact() {
        this.onLogEvent("Danh bạ nhập mới");
        this._outNewModal();
        this._onRefreshNewContact();

        this._onSaveInitialContact();

        Actions.ModifyContact({ text: this.state.text, request: (value) => this._request(value) });

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('AGENT_CONTACT_ADD', { deviceID: deviceID, userID: userID });
    }

    _onSaveInitialContact() {
        // local storage initialContact
        this.props.actions.onHelpedModalChange('initialContact', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialContact = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _onRefreshNewContact() {
        this.props.actions.onGroupContactFieldChange('contactID', null);
        this.props.actions.onGroupContactFieldChange('contactSource', '');
        this.props.actions.onGroupContactFieldChange('contactName', '');
        this.props.actions.onGroupContactFieldChange('contactPhone', '');
        this.props.actions.onGroupContactFieldChange('contactEmail', '');
        this.props.actions.onGroupContactFieldChange('contactType', 1);
        this.props.actions.onGroupContactFieldChange('contactSaleState', 2);
        this.props.actions.onGroupContactFieldChange('contactPhotos', []);
        this.props.actions.onGroupContactFieldChange('recordID', null);
        this.props.actions.onGroupContactFieldChange('listContactNhucau', []);
        this.props.actions.onGroupContactFieldChange('isFavorited', 0);
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        let modalHeight = 169;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: modalHeight }]}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
                backdropPressToClose={true}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {
        let mainItems = null;

        mainItems = <View style={styles.viewSwipeButton}>
            <TouchableOpacity style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                <Text style={styles.textMoreButton}>Sửa công việc</Text>
            </TouchableOpacity>
            <View style={styles.lineSpaceButton} />
            <TouchableOpacity style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                <Text style={styles.textMoreButton}>Đánh dấu đã xong</Text>
            </TouchableOpacity>
        </View>;

        return (
            <View style={styles.viewShowModal}>
                {mainItems}
            </View>
        )
    }

    _onCancelJoinPress() {
        this._doLeaveOrCall('Bạn muốn    ?');
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn rời khỏi sàn ?');
    }

    _doLeaveOrCall(title) {
        let selectedEvent = this.state.selectedEvent;
        if (!selectedEvent) {
            return;
        }
        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedEvent.groupID;
                    let userID = this.props.global.currentUser.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.leaveGroup({ groupID: groupID, userID: userID }, token);
                    this._outMoreModal();
                }
            }
            ]);
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }

    _renderBodyGroupMgmt() {
        return (
            <View style={styles.viewBody}>
                {this._renderRowView()}
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState });
    }

    _onTabChange(value) {
        this.setState({ 'text': '', phanLoai: value })
        this.props.actions.onGroupContactFieldChange('selectedContactTab', value);

        this.props.actions.onGroupContactFieldChange('searchContact', '')
        let currentUser = this.props.global.currentUser;
        this.props.actions.getAllContact(
            { 'userID': currentUser.userID, 'orderBy': this.props.groupContact.orderBy }
            , (res) => {
                // this.props.actions.onGroupContactFieldChange('selectedContactTab', value);
                // this.setState({
                //     phanLoai: value
                // });
            }
            , (error) => {
                log.info('server respond data: =====>>>>>', error)
                // this.props.actions.onGroupContactFieldChange('selectedContactTab', value);
                // this.setState({
                //     phanLoai: value
                // });
            });
    }

    _renderRowView() {
        let content;
        let hideBackButton = this.props.hideBackButton;
        let viewSanThamGia = [styles.viewSanThamGia, { height: hideBackButton ? height - 104 : height - 104 }];
        switch (this.state.phanLoai) {
            case "all": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListAll()}
                    </View>
                );
                break;
            }
            case "favorite": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListFavorite()}
                    </View>
                );
                break;
            }
            case "investor": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListInvestor()}
                    </View>
                );
                break;
            }
            case "important": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListImportant()}
                    </View>
                );
                break;
            }
            case "new": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListNew()}
                    </View>
                );
                break;
            }
            case "canceled": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListCanceled()}
                    </View>
                );
                break;
            }
            case "bought": {
                content = (
                    <View style={viewSanThamGia}>
                        {this._renderListBought()}
                    </View>
                );
                break;
            }
            default: {
                content = (
                    <View style={viewSanThamGia} />
                );
            }
        }
        return content;
    }

    _renderListAll() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;

        let listContact = this.state.contactList;
        let userID = this.props.global.currentUser.userID;
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    _renderListFavorite() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;
        let listContact = this.state.contactList;
        let userID = this.props.global.currentUser.userID;
        listContact = listContact.filter((one) => {
            return one.favorite == 1 //Favorite
        }) || [];
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    _renderListInvestor() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;
        let listContact = this.state.contactList;
        
        listContact = listContact.filter((one) => {
            return one.contactType == 3 //contactType=3 : investor
        }) || [];
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    _renderListImportant() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;
        let listContact = this.state.contactList;
        let userID = this.props.global.currentUser.userID;
        listContact = listContact.filter((one) => {
            return one.contactSaleState == 1 //Important
        }) || [];
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    _renderListNew() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;
        let listContact = this.state.contactList;
        let userID = this.props.global.currentUser.userID;
        listContact = listContact.filter((one) => {
            return one.contactSaleState == 2 //new contact
        }) || [];
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    _renderListCanceled() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;
        let listContact = this.state.contactList;
        let userID = this.props.global.currentUser.userID;
        listContact = listContact.filter((one) => {
            return one.contactSaleState == 3 //khach khong mua nua
        }) || [];
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    _renderListBought() {
        let imageNoContact = require('../../assets/image/none_danh_ba.png');
        let textNoneContact = DanhMuc.guideContact.newGuide;
        let listContact = this.state.contactList;
        let userID = this.props.global.currentUser.userID;
        listContact = listContact.filter((one) => {
            return one.contactSaleState == 4 //khach da mua
        }) || [];
        if(listContact.length == 0) {
            return (
                <View style={styles.noneAdsList}>
                    <Image
                        source={imageNoContact}
                        resizeMode={"cover"}
                        style={styles.imageNoGroup}
                    />
                    <Text style={[styles.textNoneAds, styles.newTextGuide]}>
                        Quản lý khách hàng
                    </Text>
                    <Text style={styles.textNoneAds}>
                        {textNoneContact}
                    </Text>
                    {this.renderAddContactButtons()}
                </View>
            )
        }
        return this._renderContactList(listContact);
    }

    renderAddContactButtons() {

        return(
          <View>
              <TouchableOpacity style={styles.viewAddCustomer}
                                onPress={this._onAddContact}
              >
                    <Text style={styles.textAddCustomer}>Thêm khách hàng</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.viewAddCustomer}
                                onPress={this._onImportFromDevice}
              >
                  <Text style={styles.textAddCustomer}>Nhập từ danh bạ máy</Text>
              </TouchableOpacity>
          </View>
        );
    }

    _renderContactList(listContact) {

        let hideBackButton = this.props.hideBackButton;

        let firstControl = null;
        let orderByKey = this.state.orderByKey || '';
        let orderLabel = DanhMuc.contactOrder[orderByKey];
        if (this.props.groupContact.loadingContact) {
            firstControl =
                <View style={{ flex: 0, height: 40, backgroundColor: '#F6F6F6', alignItems: 'flex-end', justifyContent: 'center' }}>
                    {/*<GiftedSpinner size="small"/>*/}
                </View>;
        } else {
            firstControl =
                <View>
                    <View style={{
                        flex: 0, height: 40, width: width, backgroundColor: '#F6F6F6', paddingLeft: 10, paddingRight: 15,
                        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'
                    }}>
                        <Text style={styles.pagingTitle}>{this._getPagingTitle(listContact.length)}</Text>
                        <TouchableOpacity onPress={this._onModalSapXep.bind(this)}
                            style={[styles.viewSortAlphabet, { flexDirection: 'row', width: 'auto', height: 40, paddingTop: 0 }]}
                        >
                            <Text style={[styles.orderLabel, {color: 'rgba(85,85,85,1)'}]}>{orderLabel}</Text>
                            <FontAwesomeSolid name="sort" size={18} color={'rgba(85,85,85,1)'} noAction={true} iconOnly={true} />
                        </TouchableOpacity>
                    </View>
                </View>;
        }

        let dsList = [firstControl];
        dsList = dsList.concat(listContact);

        let data = ds_listAlert.cloneWithRows(dsList);

        return (
            <View style={styles.viewBodyAlert}
                        showsVerticalScrollIndicator={false}
            >
                <SwipeListView
                    refreshControl={
                        <RefreshControl
                            refreshing={false}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                    ref={ref => this._swipeListView = ref}
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode="on-drag"
                    enableEmptySections={true}
                    showsVerticalScrollIndicator={false}
                    dataSource={data}
                    
                    renderRow={(rowData, sectionID, rowID, rowMap) => (
                        <SwipeRow                            
                            disableRightSwipe={true}
                            disableLeftSwipe={parseInt(rowID) === 0}
                            rightOpenValue={-197}
                            
                        >
                            <View style={[styles.rowBack, {
                                alignItems: (rowID == 0) ? 'flex-end' : (rowID == (listContact.length - 1)) ? 'flex-start' : 'center'
                            }]}>

                                <TouchableOpacity onPress={() => {
                                    rowMap[`${sectionID}${rowID}`].closeRow();
                                    this._onFavorite(rowData)
                                }}
                                    style={[styles.viewDeleteInbox, { backgroundColor: '#FFCF56' }]}
                                >
                                    {this.props.me.loadingDeleteMyNotify ?
                                        <View><GiftedSpinner color="#fff" /></View> : <Text style={styles.saveText}>{rowData.favorite == 1 ? 'Bỏ thích' : 'Thích'}</Text>
                                    }
                                </TouchableOpacity>

                                <TouchableOpacity onPress={() => {
                                    rowMap[`${sectionID}${rowID}`].closeRow();
                                    this._onEdit(rowData)
                                }}
                                    style={[styles.viewDeleteInbox, { backgroundColor: '#928D93' }]}
                                >
                                    {this.props.me.loadingDeleteMyNotify ?
                                        <View><GiftedSpinner color="#fff" /></View> : <Text style={styles.saveText}>Sửa</Text>
                                    }
                                </TouchableOpacity>

                                <TouchableOpacity onPress={() => {
                                    rowMap[`${sectionID}${rowID}`].closeRow();
                                    this._onDelete(rowData)
                                }}
                                    style={[styles.viewDeleteInbox]}
                                >
                                    {this.props.me.loadingDeleteMyNotify ?
                                        <View><GiftedSpinner color="#fff" /></View> : <Text style={styles.saveText}>Xóa</Text>
                                    }
                                </TouchableOpacity>
                            </View>
                            {this._renderRowContact(rowData, (rowID == 0), (rowID == (listContact.length - 1)))}
                        </SwipeRow>
                    )}
                    style={styles.listView}
                    contentContainerStyle={{ marginBottom: 50 }}
                />
            </View>


            // <View style={toDoView}>

            //     <FlatList
            //         refreshControl={
            //             <RefreshControl
            //                 refreshing={false}
            //                 onRefresh={this._onRefresh.bind(this)}
            //             />
            //         }
            //         data={data}
            //         keyExtractor={(item, index) => "list" + index}
            //         renderItem={(item) => this._renderRowContact(item)}
            //         //ListFooterComponent={() => this._renderFooter()}
            //         removeClippedSubviews={false}
            //         enableEmptySections
            //         style={{ flex: 1 }}
            //         contentContainerStyle={{ paddingBottom: 0 }}
            //     />

            //     {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
            //         style={[styles.searchButtonText2, {
            //             textAlign: 'right', color: gui.mainColor,
            //             backgroundColor: gui.doneKeyButton
            //         }]}>Xong</Button> : null}
            //     <KeyboardSpacer topSpacing={-50} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />
            // </View>
        )
    }

    _onDelete(data) {
        Alert.alert('Thông báo', 'Bạn có muốn xóa liên hệ này không?',
            [{ text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
            { text: 'Đồng ý', onPress: () => this._doDeleteContact(data) }
            ]);
    }

    _onFavorite(data) {
        if (!data) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let token = this.props.global.currentUser.token || undefined;
        let selectedContact = data;
        let newFavorite = data.favorite == 1 ? 0 : 1;
        let dto = {
            contactID: selectedContact.id,
            userID: userID,
            favorite: newFavorite
        }
        this.props.actions.favoriteContact(dto, token)
            .then(res => {

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    let listContact = this.state.contactList;
                    listContact.forEach((one) => {
                        if (one.id == selectedContact.id) {
                            one.favorite = newFavorite;
                        }
                    });
                    this.props.actions.onGroupContactFieldChange('contactList', listContact)
                    this.setState({ contactList: listContact })
                }
            });
    }

    _onEdit(data) {
        if (!data) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let selectedContact = data;

        // console.log('_onEditButton will update this contact ******', selectedContact);
        this.props.actions.onGroupContactFieldChange('contactID', selectedContact.id);
        this.props.actions.onGroupContactFieldChange('contactName', selectedContact.contactName);
        this.props.actions.onGroupContactFieldChange('contactSource', selectedContact.contactSource);
        this.props.actions.onGroupContactFieldChange('contactPhone', selectedContact.contactPhone);
        this.props.actions.onGroupContactFieldChange('contactEmail', selectedContact.contactEmail);
        this.props.actions.onGroupContactFieldChange('contactType', selectedContact.contactType);
        this.props.actions.onGroupContactFieldChange('contactSaleState', selectedContact.contactSaleState);
        this.props.actions.onGroupContactFieldChange('recordID', selectedContact.recordID);
        this.props.actions.onGroupContactFieldChange('listContactNhucau', selectedContact.nhuCau);
        this.props.actions.onGroupContactFieldChange('contactPhotos', selectedContact.avatar ? [{ uri: selectedContact.avatar }]
                                        : ( selectedContact.zaloAvatar ? [{ uri: selectedContact.zaloAvatar }] : []) );
        this.props.actions.onGroupContactFieldChange('isFavorited', selectedContact.favorite);

        this._onSaveInitialContact();

        Actions.ModifyContact({ text: this.state.text, request: (value) => this._request(value) });
    }

    _doDeleteContact(row) {
        let id = row.id || row.contactID;
        let dto = {
            userID: this.props.global.currentUser.userID,
            id: id
        };
        let token=this.props.global.currentUser.token
        this.props.actions.deleteContact(dto, token).then((e) => {
            if (e.status != 0) {
                Alert.alert("Thông báo", 'Xóa liên hệ không thành công!');
            } else {
                this._swipeListView.safeCloseOpenRow();
            }

        });
    }

    _onRefresh() { }

    getLevelTextColor(value) {
        let colorLevel = DanhMuc.contactTextLevel[value];
        return colorLevel;
    }
    _renderRowContact(value, isFirstRow, isLastRow) {
        let data = value;
        if (isFirstRow) {
            return data;
        }

        let imgUrl = data.avatar || data.zaloAvatar;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }
        let nameDefault = utils.geDefaultName(data.contactName);
        let nameColor = utils.getNameColor(nameDefault);
        let level = DanhMuc.contactSaleState[data.contactSaleState] || '';
        let phone = data.contactPhone;
        let levelColor = this.getLevelTextColor(level);
        return (
            <View>
                <View style={styles.viewRowContact}>
                    <TouchableHighlight onPress={this._onContactPress.bind(this, data)}
                        underlayColor="rgba(30,30,30,0.8)"
                        style={styles.viewRowChild}
                    >
                        <View style={styles.viewToDoRow}>
                            {imgUrl && imgUrl.length > 0 ?
                                (<View style={[styles.dotView]}>
                                    <Image
                                        resizeMode={"cover"}
                                        source={imageGroup}
                                        defaultSource={defaultCover}
                                        style={styles.adsCover} />
                                </View>) : (
                                    <View style={[styles.dotView, { backgroundColor: '#eeedf0' }]}>
                                        <Text style={[styles.textSort, { color: nameColor, fontSize: 17, fontWeight: '600' }]}>{nameDefault}</Text>
                                    </View>
                                )
                            }
                            <View style={styles.viewChildContact}>
                                <Text style={styles.toDoContentText}>
                                    {data.contactName}
                                </Text>
                                <Text style={styles.textPhoneTop}>
                                    {phone}
                                    <Text style={[styles.textLevel, { color: levelColor }]}>{`  ${level}`}</Text>
                                </Text>
                            </View>
                        </View>
                    </TouchableHighlight>
                </View>
                <FullLine style={{marginLeft: 74}}/>
            </View>

        );
    }

    _getPagingTitle(length) {
        return 'Có tất cả ' + length + ' khách hàng';
    }

    _onContactPress(data) {
        if (this.props.owner == 'MyTodoNotes') {
            let personContactDto = {
                contactID: data.id,
                contactName: data.contactName,
                contactPhone: data.contactPhone,
                contactEmail: data.contactEmail,
                contactType: data.contactType == 1,
                contactAvatar: data.avatar || data.zaloAvatar,
                contactSaleState: data.isImporcontactSaleStatetant
            }
            this.props.actions.onGroupContactFieldChange('personContact', personContactDto);
            Actions.pop();
        }

        if (this.props.owner == 'ContactRespond') {
            let personContactDto = {
                contactID: data.id,
                contactName: data.contactName,
                contactPhone: data.contactPhone,
                contactEmail: data.contactEmail,
                contactType: data.contactType == 1,
                contactAvatar: data.avatar || data.zaloAvatar,
                contactSaleState: data.contactSaleState
            }
            this.props.actions.onGroupContactFieldChange('contactOfRespond', personContactDto);
            Actions.pop();
        }

        if (this.props.owner == 'AgentWto') {
            let personContactDto = {
                contactID: data.id,
                contactName: data.contactName,
                contactPhone: data.contactPhone,
                contactEmail: data.contactEmail,
                contactType: data.contactType == 1,
                contactAvatar: data.avatar || data.zaloAvatar,
                contactSaleState: data.isImporcontactSaleStatetant
            }
            this.props.actions.onGroupContactFieldChange('contactOfWto', personContactDto);
            Actions.pop();
        }

        if (this.props.owner == 'NewHomeAgent') {
            this.props.actions.onGroupContactFieldChange('selectedContact', data);
            // this.props.actions.onGroupContactFieldChange('contactHistoryList', [])
            this.props.actions.getContactHistory(
                {
                    'userID': this.props.global.currentUser.userID,
                    'contactID': data.contactID
                }
                , (res) => {

                }
                , (error) => {
                    log.info('getContactHistory server respond error: =====>>>>>', error)
                });

            Actions.NewDetailContact({request: (value) => this._request(value) });
        }
    }

    _onMoreButtonPress(data) {
        this.setState({ selectedEvent: data, isOpenMoreModal: true });
    }


    _renderLoadingView() {
        if (this.props.groupContact.loadingContact) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='small' color="gray" />
            </View>)
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderContent: {
        height: 72,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 19,
        paddingRight: 21
    },
    viewIconSearch: {
        height: 72,
        width: 18,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPlusSearch: {
        height: 72,
        width: 20,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewInputSearch: {
        height: 72,
        width: width - 78,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextInput: {
        flex: 1
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width - 32,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 20
    },
    viewBody: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewTabSelect: {
        height: 39,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row',
        marginTop: 23
    },
    viewSanThamGia: {
        backgroundColor: '#fff',
        height: height - 204,
        width: width,
        // marginTop: 3,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewContent: {
        marginTop: 15,
        width: width - 30,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        height: 80,
        width: width - 208,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 100,
        height: 82,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 16
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 198,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    viewListContainer: {
        paddingBottom: 30
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,        
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    toDoView: {
        width: width,
        height: height - 204,//'auto',
        justifyContent: 'center',
        alignItems: 'center'
    },
    toDoTitle: {
        width: width,
        height: 48,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    toDoContent: {
        width: width,
        height: height - 184,//'auto',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    toDoTitleText: {
        width: (width - 32) / 2,
        textAlign: 'left',
        marginLeft: 16,
        marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 20,
        fontWeight: '600',
        backgroundColor: 'transparent',
        color: '#526173'
    },
    themCongViecText: {
        // width: width/2,
        textAlign: 'right',
        marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '400',
        // backgroundColor: 'transparent',
        color: gui.mainColor
    },
    toDoContentText: {
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textAgentSolid
    },
    toDoDateText: {
        width: 90,
        textAlign: 'right',
        marginRight: 16,
        // marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight: '400',
        backgroundColor: 'transparent',
        color: '#526173'
    },
    viewToDoRow: {
        backgroundColor: '#FFFFFF',
        width: width,
        height: 74,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotView: {
        // marginRight: 8,
        // marginTop: 6,
        width: 50,
        borderRadius: 25,
        height: 50,
        marginLeft: 12,
        justifyContent: 'center',
        alignItems: 'center'
    },
    headerView: {
        backgroundColor: '#fff',
        height: 106, //150 102
        width: width,
        //borderBottomWidth: 1,
        // borderColor: 'rgba(82,97,115,0.3)'
    },
    subHeader: {
        backgroundColor: 'transparent',
        marginTop: 40,
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 24,
        flexDirection: 'row'
    },
    subHeader2: {
        backgroundColor: 'transparent',
        width: width,
        height: 64,
        flexDirection: 'row'
    },
    searchContainer: {
        marginTop: gui.marginTopAgent + 6,
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0
    },
    tabHeader: {
        // justifyContent: 'flex-start',
        // alignItems: 'center',
        // marginTop: 17,
        // marginLeft: 16,
        // width: width,
        // height: 33,
        marginTop: 6,
        flexDirection: 'row',
        // paddingLeft: 8,
        // paddingRight: 8,
        borderColor: '#dfdfdf',
        borderBottomWidth: 0,
        paddingTop: 0
    },
    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173',
        // marginLeft: 8
    },
    tabbar: {
        flexDirection: 'row',
        paddingLeft: 20,
        paddingRight: 20,
        borderColor: '#dfdfdf',
        borderBottomWidth: 0,
        paddingTop: 17,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewBackIcon: {
        height: 25,
        width: 25,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    adsCover: {
        width: 50,
        height: 50,
        marginLeft: 0,
        borderRadius: 25
    },
    pageHeaderWrapper: {
        position: 'absolute',
        // left: 50,
        right: 6,
        top: 0,
        // height: 64
    },
    separatorLine: {
        borderLeftWidth: 0.5,
        width: 1,
        height: 40,
        marginTop: 7,
        borderColor: "#99526173",
        opacity: 0.6
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    textSapxep: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewSortAlphabet: {
        height: 64,
        width: 42,
        paddingTop: gui.marginTopAgent + 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    touchableSort: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    textSort: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        // borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        paddingLeft: 18,
        width: width - 16
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewEachButtonTab: {
        paddingHorizontal: 12,
        paddingVertical: 9,
        borderColor: 'rgba(37,37,37,0.3)',
        borderWidth: 1,
        borderRadius: 4,
        marginLeft: 8,
        marginTop: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    selectedButtonTab: {
        backgroundColor: gui.mainColor,
        borderWidth: 0,
    },
    selectedButtonText: {
        color: '#fff',
        fontWeight: '600'
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: 'rgba(37,37,37,0.7)',
        textAlign: 'center'
    },
    viewProgress: {
        width: width,
        height: 2,
        backgroundColor: 'skyblue',
        marginTop: 3
    },
    searchButtonText2: {
        width: width,
        justifyContent: 'flex-end',
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    listView: {
        flex: 1,
        paddingTop: 0,
        backgroundColor: 'white',
        borderColor: '#e6e6e6',
        borderBottomWidth: 0,
        marginBottom: 50
    },
    viewBodyAlert: {
        flex: 1,
        flexDirection: 'column',
    },
    rowBack: {
        alignItems: 'flex-end',
        backgroundColor: '#fff',
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingLeft: 0,
    },
    viewDeleteInbox: {
        right: 0,
        width: 65,
        backgroundColor: '#f43838',
        height: 74,
        alignItems: 'center',
        justifyContent: 'center'
    },
    saveText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: "white",
        textAlign: 'center',
        fontWeight: '500'
    },
    viewRowContact: {
        backgroundColor: '#fff',
        flexDirection: 'column',
        overflow: 'hidden'
    },
    viewRowChild: {
        width: width,
        height: 75,
        backgroundColor: '#fff',
    },
    viewChildContact: {
        height: 74,
        justifyContent: 'center',
        width: width - 74,
        paddingLeft: 10
    },
    textPhoneTop: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        marginTop: 3
    },
    textLevel: {
        fontFamily: gui.fontFamily,
        color: 'rgba(57,181,74,1)',
        fontSize: 15,
        marginLeft: 8
    },
    pagingTitle: {
        fontSize: 13,
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'lightgray'
    },
    orderLabel: {
        fontSize: 13,
        backgroundColor: 'transparent',
        color: 'darkgray',
        marginRight: 5
    },
    viewIconProfile: {
        height: 30,
        width: 46,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 27,
        // marginLeft: 12,
        // paddingLeft: 4
    },
    numberOfMessage2: {
        height: 16,
        width: 16,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 0,
        // left: 0,
        right: 12,
        backgroundColor: '#ff0000'
    },
    numberInbox: {
        fontSize: 8,
        color: '#fff',
        backgroundColor: 'transparent'
    },
    viewNewContact: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        width: 56,
        height: 56,
        borderRadius: 28,
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        elevation: 1,
        shadowOpacity: 0.15,
        shadowRadius: 2
    },
    noneAdsList: {
        flex: 1,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingBottom: 50
    },
    imageNoGroup: {
        width: 110 * 0.7,
        height: 126 * 0.7
    },
    textNoneAds: {
        color: gui.textPostAds,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        alignSelf: 'center',
        textAlign: 'center'
    },
    newTextGuide: {
        fontWeight: '500',
        marginTop: 22,
        marginBottom: 12,
        fontSize: 18 ,
        color: gui.mainColor
    },
    textAddCustomer: {
        fontFamily: gui.fontFamily,
        fontWeight: '500',
        fontSize: 18 ,
        color: '#fff'
    },
    viewAddGroup: {
        width: 158,
        height: 40,
        backgroundColor: gui.mainColor,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 24
    },
    notification: {
        position: 'absolute',
        backgroundColor: '#ff0000',
        top: 2,
        right: 6,
        alignSelf: 'auto',
        width: 6,
        height: 6,
        borderRadius: 3,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewAddCustomer: {
        width: 273,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        borderRadius: 5,
        marginTop: 12
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Contact);