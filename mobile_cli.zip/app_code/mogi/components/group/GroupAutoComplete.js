'use strict';

import  React, {Component} from 'react';

import {
    Text, View, ListView, Image
    , TextInput, StyleSheet, RecyclerViewBackedScrollView
    , TouchableHighlight, StatusBar,
    TouchableOpacity
} from 'react-native'

import RelandIcon from '../RelandIcon';

import {Actions} from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import SearchInput from './SearchInputAgent';

var gui = require("../../lib/gui");
var log = require("../../lib/logUtil");
import cfg from '../../cfg';

import GroupApi from '../../lib/GroupApi';

import utils from '../../lib/utils';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import Button from 'react-native-button';

var {width, height} = utils.getDimensions();

class GroupAutoComplete extends React.Component {
    constructor(props) {
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: function rowHasChanged(r1, r2) {
                return r1 !== r2;
            }
        });

        let listGroup = this._getListGroup(props.listGroup);

        this.state = {
            focused: false,
            dataSource: ds.cloneWithRows(this.buildRowsFromResults(listGroup)),
            listAdmin: [],
            listGroup: listGroup,
            text: props.searchFields.name,
            toggleKeyboard: false
        };
    }

    _getListGroup(data) {
        let listGroup = [];
        if (!data || data.length == 0) {
            return listGroup;
        }
        let index = 0;
        listGroup.push({
            key: index,
            name: 'Theo tên Sàn',
            type: 'Group'
        });
        data.forEach((one) => {
            one.type = 'Group';
            listGroup.push(one);
        });
        // console.log('_getListGroup ******', listGroup)
        return listGroup;
    }

    _getListGroupFromFTS(data) {
        let listGroup = [];
        if (!data || data.length == 0) {
            return listGroup;
        }
        let index = 0;
        listGroup.push({
            key: index,
            name: 'Theo tên Sàn',
            type: 'Group'
        });
        // console.log('_getListGroupFromFTS data ******', data)
        data.forEach((one) => {
            one.type = 'Group';
            listGroup.push(one);
        });
        // console.log('_getListGroupFromFTS ******', listGroup)
        return listGroup;
    }

    buildRowsFromResults(results) {
        return [...results];
    }

    componentWillMount() {
        setTimeout(() => this.focusInputSearch(), 300);
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderMainContent()}
                {this.state.toggleKeyboard ? <Button onPress={() => this._onSubmitChange()}
                                                     style={{ paddingRight: 17, fontFamily: gui.fontFamily, fontWeight : 'normal', textAlign: 'right',
                                                    color: gui.mainColor, backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)}/>

                <View style={styles.pageHeader}>
                    <TouchableOpacity style={styles.backButton}
                                      onPress={this._onBackPress.bind(this)}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor} />
                    </TouchableOpacity>
                    <View style={styles.pageHeaderWrapper}>
                        <SearchInput ref="searchInput"
                                     placeholder={this.props.placeholder} textValue={this.state.text}
                                     loadSearchFilter={(fields) => this._loadSearchFilter(fields)}
                                     onSuggestPress={this._onSuggestPress.bind(this)}
                                     onChangeText={this._onChangeText.bind(this)}
                                     onFocus={this._onFocus.bind(this)}
                                     showCloseButton={this.state.focused && this.state.text != ''}
                                     editable={true} />
                    </View>
                </View>
            </View>
        );
    }

    _onSubmitChange() {
        dismissKeyboard();
        this.props.onPress(this.state.text);
    }

    focusInputSearch() {
        this.refs.searchInput && this.refs.searchInput.focusInputSearch();
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    _request(text) {
        if (text.length >= this.props.minLength) {
            this._requestGroup(text);
        } else {            
        }
    }

    _requestGroup(text) {
        let fields = utils.cloneRecord(this.props.searchFields);
        fields.name = text ? utils.locDauV2(utils.standardlizeName(text)) : undefined;
        if (fields.name)
            GroupApi.searchGroupByFTS(fields).then((res) => {
                if (res.status == 0) {                    
                    let listGroup = this._getListGroupFromFTS(res.data);
                    this.setState({
                        dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(listGroup)),
                        listGroup: listGroup
                    });
                }
            });
        else 
            GroupApi.searchGroup(fields).then((res) => {
                if (res.status == 0) {
                    let listGroup = this._getListGroup(res.data);
                    this.setState({
                        dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(listGroup)),
                        listGroup: listGroup
                    });
                }
            });
    }

    _onChangeText(text) {
        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            text: text
        });
    }

    _onFocus() {
        !this.state.focused && this.setState({focused: true});
    }

    _renderMainContent() {
        return (
            <ListView style={[styles.groupListView, {marginTop: 64}]}
                      ref={(listView) => { this._listView = listView; }}
                      dataSource={this.state.dataSource}
                      renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0))}
                      stickyHeaderIndices={[]}
                      keyboardShouldPersistTaps="always"
                      keyboardDismissMode="none"
                      enableEmptySections={true}
                      automaticallyAdjustContentInsets={false} />
        );
    }

    _renderRow(rowData = {}, sectionID, rowID, isFirstRow) {
        let isGroup = rowData.type == 'Group';
        let name = isGroup ? rowData.name : rowData.fullNameChuSan;
        if (!rowData.groupID) {
            return (
                <View style={styles.groupTitleView}>
                    <Text style={styles.groupTitleText}>{name}</Text>
                </View>
            );
        }
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        return (
            <View style={{marginLeft: 15, marginRight: 15, marginBottom: 11,
                            borderBottomWidth: 1, borderBottomColor: 'rgba(82,97,115,0.05)'}}>
                <TouchableHighlight
                    onPress={() =>this._onPress(rowData)}
                    underlayColor="#c8c7cc"
                >
                    <View style={{marginTop: 12, marginBottom: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start'}}>
                        {isGroup ? null : <Image style={styles.adminAvatar} source={{uri: rowData.avatar}} defaultSource={defaultAvatar}/>}
                        <Text style={styles.labelText}>{name}</Text>
                    </View>
                </TouchableHighlight>
            </View>
        );
    }

    _onPress(rowData) {
        if (!rowData.groupID)
            return;

        if (rowData.isLoading === true) {
            // already requesting
            return;
        }

        this.setState({
            text: rowData.name
        });

        delete rowData.isLoading;

        dismissKeyboard();
        let text = rowData? rowData.name : undefined;
        this.props.onPress(text);
    }

    _onBackPress() {
        Actions.pop();
    }

    _loadSearchFilter(fields) {

    }

    _onSuggestPress() {
    }
}

const styles = StyleSheet.create({
    container: {
        paddingTop: 0,
        backgroundColor: "white",
        flex: 1
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width,
        height: 64
    },
    pageHeaderWrapper: {
        position: 'absolute',
        left: 50,
        right: 6,
        top: 0,
        height: 64
    },
    backButton: {
        height: 64,
        width: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: gui.marginTopAgent
    },
    groupTitleView: {
        marginTop: 10,
        marginBottom: 10,
        marginLeft: 16,
        marginRight: 16
    },
    groupTitleText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        fontWeight : '500',
        color: 'rgba(82,97,115,0.5)',
        textAlign: 'left'
    },
    groupListView: {
        flex: 1,
        height: height-64
    },
    groupMainView: {
        flexDirection: 'row',
        paddingTop: 17,
        paddingLeft: 17,
        paddingRight: 17,
        paddingBottom: 10
    },
    lineView: {
        borderTopWidth: 1,
        height:1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    labelText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    adminAvatar: {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 8
    }
});

export default GroupAutoComplete;