import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    Switch,
    TextInput,
    Alert,
    FlatList,
    RefreshControl,
    ImageBackground
} from 'react-native';
import moment from 'moment'
import DatePicker from 'react-native-datepicker';
import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/FontAwesome';
import Modal from 'react-native-modalbox';
import GiftedSpinner from "../GiftedSpinner";
import DanhMuc from '../../assets/DanhMuc';
import OfflineBar from '../line/OfflineBar';
import LinearGradient from 'react-native-linear-gradient';
import RelandIcon from '../RelandIcon';
import TruliaIcon from '../TruliaIcon';
let { width, height } = utils.getDimensions();
import utils from '../../lib/utils';
import gui from "../../lib/gui";
import FullLine from '../line/FullLine';
import TextInputAuto from '../postAds/TextInputAuto';
import RNCalendarEvents from 'react-native-calendar-events';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Toast, { DURATION } from '../toast/Toast';
import userApi from '../../lib/userApi';

import * as globalActions from '../../reducers/global/globalActions';
// import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as eventActions from '../../reducers/event/eventActions';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';

const actions = [
    globalActions,
    // groupActions,
    adsMgmtActions,
    groupContactActions,
    eventActions
];


function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class MyTodoNotes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            //nameToto: props.event.eventName,
            namePostLine: false,
            notiAllDay: false,
            repeatNote: false,
            notifyNote: true,
            isOpenLevel: false,
            isOpenEventType: false,
            levelNoteKey: props.event.eventLevel,
            eventType: props.event.eventType,
            personContact: null,
            dateStart: moment(props.event.eventStartDate),
            dateEnd: moment(props.event.eventEndDate),
            eventAds: props.event.eventAds,
            savingEvent: false
        }
    }

    componentWillMount() {
        this.props.actions.onHideChatIconChange(true);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.event.eventStartDate !== this.props.event.eventStartDate) {
            this.setState({
                dateStart: moment(nextProps.event.eventStartDate)
            });
        }
        if (nextProps.event.eventEndDate !== this.props.event.eventEndDate) {
            this.setState({
                dateEnd: moment(nextProps.event.eventEndDate)
            });
        }
        if (nextProps.event.eventLevel !== this.props.event.eventLevel) {
            this.setState({
                levelNoteKey: nextProps.event.eventLevel
            });
        }
        if (nextProps.event.eventAds !== this.props.event.eventAds) {
            this.setState({
                eventAds: nextProps.event.eventAds
            });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderButton()}
                <FullLine style={{ marginTop: 0 }} />
                {this._renderBodyTodo()}
                {this._renderModalLevelNoti()}
                {this._renderModalEventType()}
                {this._renderLoadingView()}
                {this._renderLoadingAdsView()}

                <Toast
                    ref="toastTop"
                    position='center'
                    positionValue={45}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    }

    _renderLoadingView() {
        if (this.state.savingEvent) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='small' color="gray" />
            </View>)
        }
    }

    _renderLoadingAdsView() {
        if (this.props.event.loadingAdsForEvent) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='small' color="gray" />
            </View>)
        }
    }

    _renderHeaderButton() {
        let titleText = 'Lưu';
        if (this.state.savingEvent) {
            return (
                <View style={styles.viewHeaderButton}>
                    <TouchableOpacity style={styles.viewBackIcon}
                        onPress={this._onBackButton.bind(this)}>
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} style={{ marginLeft: 0 }} />
                    </TouchableOpacity>
                    <View style={[styles.viewTextSave, {width: width - 132}]}>
                        <Text style={[styles.textSavePost, {fontWeight: '500', fontSize: 17, color: gui.textAgentSolid}]}>Tạo công việc</Text>
                    </View>
                    <View style={styles.viewTextSave}>
                        <Text style={[styles.textSavePost, { color: gui.mainColor }]}>{titleText}</Text>
                    </View>
                </View>
            )
        } else
            return (
                <View style={styles.viewHeaderButton}>
                    <TouchableOpacity style={styles.viewBackIcon}
                        onPress={this._onBackButton.bind(this)}>
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} style={{ marginLeft: 0 }} />
                    </TouchableOpacity>
                    <View style={[styles.viewTextSave, {width: width - 132}]}>
                        <Text style={[styles.textSavePost, {fontWeight: '500', fontSize: 17, color: gui.textAgentSolid}]}>Tạo công việc</Text>
                    </View>
                    <TouchableOpacity onPress={this._onSaveEvent.bind(this)} style={styles.viewTextSave}>
                        <Text style={[styles.textSavePost, { color: gui.mainColor }]}>{titleText}</Text>
                    </TouchableOpacity>
                </View>
            )
    }

    onLogEvent() {
        let eventDto = {
            scene: "MyToDoNotes",
            parentScene: this.props.owner,  //truyen owner neu co            
            componentType: "button",
            component: "Lưu",
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    _onSaveEvent() {
        this.onLogEvent();
        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;

        if (!this.props.event.eventName.trim()) {
            Alert.alert("Thông báo", 'Bạn chưa nhập Tên công việc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        if (!this.state.dateStart || !this.state.dateEnd) {
            Alert.alert("Thông báo", 'Bạn chưa chọn ngày Bắt đầu và Kết thúc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        if (this.state.dateStart.diff(this.state.dateEnd) > 0) {
            Alert.alert("Thông báo", 'Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }

        this.setState({ savingEvent: true })

        let eventDto = {
            title: this.props.event.eventName,
            // location: 'hadico me tri nam tu liem han noi',
            eventID: this.props.event.eventID || undefined,
            personContact: this.props.groupContact.personContact ? this.props.groupContact.personContact.contactID : '',
            startDate: this.props.event.eventAllDay ? (moment(moment(this.props.event.eventStartDate).toDate().setHours(1, 0, 0, 0)).toISOString())
                : this.props.event.eventStartDate,
            endDate: this.props.event.eventAllDay ? (moment(moment(this.props.event.eventEndDate).toDate().setHours(23, 59, 59, 999)).toISOString())
                : this.props.event.eventEndDate,
            userID: currentUser.userID,
            allDay: this.props.event.eventAllDay,
            level: this.props.event.eventLevel,
            alarms: this.props.event.eventAlarm ? [{
                date: -30 // or absolute date - iOS Only
            }] : [],
            recurrenceRule: this.props.event.eventRepeat ? {
                frequency: 'daily',
                interval: 1,
                endDate: moment(this.state.dateEnd).add(3, 'days').toISOString()
            } : {},
            status: this.props.event.eventStatus,
            eventType: this.props.event.eventType,
            adsID: (this.props.event.eventType == DanhMuc.eventType[1] && this.props.event.eventAds) ? this.props.event.eventAds.adsID : '',
            eventIDInDevice: this.props.event.eventIDInDevice,
        };

        RNCalendarEvents.authorizeEventStore()
            .then(status => {
                // handle status
                let eventInDevice = {
                    //location: 'hadico me tri nam tu liem ha noi',                    
                    notes: eventDto.personContact ? eventDto.personContact.contactName : '',
                    startDate: eventDto.startDate,
                    endDate: eventDto.endDate,
                    alarms: eventDto.alarms,
                    recurrenceRule: eventDto.recurrenceRule
                }
                if (eventDto.eventIDInDevice) {
                    eventInDevice.id = eventDto.eventIDInDevice

                    //query if current eventID existed - for case user uses 2 devices                
                    RNCalendarEvents.findEventById(eventInDevice.id)
                        .then(event => {
                            // handle events
                            if (event && event.id) {
                                RNCalendarEvents.saveEvent(eventDto.title, eventInDevice)
                                    .then(id => {
                                        // handle success
                                    })
                                    .catch(error => {
                                        // handle error
                                    });
                            }
                            this.props.actions.saveCalendarEvent(eventDto, token)
                                .then(res => {
                                    // console.log("server respond: ", res);
                                    this.setState({
                                        loading: false,

                                    });

                                    if (res.status != 0) {
                                        Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                                        this.setState({ savingEvent: false })
                                    } else {
                                        this.refs.toastTop && this.refs.toastTop.show(
                                            "Cập nhật thành công!", DURATION.LENGTH_LONG);
                                        let fromDate = this.props.owner=='CalendarEvent' ? this.props.event.startDateTimeFrom : new Date(moment(new Date()).subtract(7, 'days')).setHours(0, 0, 0, 0)
                                        let toDate = this.props.owner=='CalendarEvent' ? this.props.event.startDateTimeTo : new Date(moment(new Date())).setHours(23, 59, 59, 999)
                                        setTimeout(() => {
                                            // this.props.actions.onEventFieldChange('eventList', [])
                                            this.props.actions.getAllCalendarEvent(
                                                {
                                                    'userID': currentUser.userID,
                                                    'startDateTimeFrom': fromDate,
                                                    'startDateTimeTo': toDate
                                                }
                                                , (res) => {
                                                    this.setState({ savingEvent: false })
                                                    // console.log('server respond data: =====>>>>>', res)
                                                }
                                                , (error) => {
                                                    this.setState({ savingEvent: false })
                                                    console.log('server respond data: =====>>>>>', error)
                                                });
                                            this.props.actions.onHideChatIconChange(false);
                                            Actions.pop();
                                        }, 500);
                                    }
                                });

                        })
                        .catch(error => {
                            this.setState({ savingEvent: false })
                            // handle error
                            console.log('Error while RNCalendarEvents.findEventById: ', error)
                        });
                } else {
                    RNCalendarEvents.saveEvent(eventDto.title, eventInDevice)
                        .then(id => {
                            eventDto.eventIDInDevice = id;
                            this.props.actions.saveCalendarEvent(eventDto, token)
                                .then(res => {
                                    // console.log("server respond: ", res);
                                    this.setState({
                                        loading: false
                                    });

                                    if (res.status != 0) {
                                        Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                                        this.setState({ savingEvent: false })
                                    } else {
                                        this.refs.toastTop && this.refs.toastTop.show(
                                            "Cập nhật thành công!", DURATION.LENGTH_LONG);

                                        setTimeout(() => {
                                            // this.props.actions.onEventFieldChange('eventList', [])
                                            let fromDate = this.props.owner=='CalendarEvent' ? this.props.event.startDateTimeFrom : new Date(moment(new Date()).subtract(7, 'days')).setHours(0, 0, 0, 0)
                                            let toDate = this.props.owner=='CalendarEvent' ? this.props.event.startDateTimeTo : new Date(moment(new Date())).setHours(23, 59, 59, 999)
                                            this.props.actions.getAllCalendarEvent(
                                                {
                                                    'userID': currentUser.userID,
                                                    'startDateTimeFrom': fromDate,
                                                    'startDateTimeTo': toDate
                                                }
                                                , (res) => {
                                                    this.setState({ savingEvent: false })
                                                    // console.log('server respond data: =====>>>>>', res)
                                                }
                                                , (error) => {
                                                    this.setState({ savingEvent: false })
                                                    console.log('server respond data: =====>>>>>', error)
                                                });
                                            this.props.actions.onHideChatIconChange(false);
                                            Actions.pop();

                                        }, 500);
                                    }
                                });
                        })
                        .catch(error => {
                            // handle error
                            this.setState({ savingEvent: false })
                            console.log(error);
                        });
                }
            })
            .catch(error => {
                this.setState({ savingEvent: false })
                // handle error
            });

    }

    _renderBodyTodo() {
        return (
            <ScrollView
                automaticallyAdjustContentInsets={false}
                showsVerticalScrollIndicator={false}
                vertical={true}
                keyboardShouldPersistTaps="always"
                keyboardDismissMode="on-drag"
                ref={(scrollView) => { this._scrollView = scrollView; }}
                style={styles.viewBody}>

                {this._renderNameTodo()}
                {this._renderPersonConnect()}
                {this._renderEventType()}
                {this._renderRelatedAdsPicker()}
                {this._renderRelatedAdsList()}
                {this._renderBasicInfo('Thời gian')}
                {this._renderDayNoti()}
                {this._renderDayStartNoti()}
                {this._renderDayEndNoti()}
                {/*{this._renderRepeatNote()}*/}
                {this._renderBasicInfo('Thông báo')}
                {this._renderNotifyNote()}
                {this._renderLevelNotify()}
            </ScrollView>
        );
    }

    _renderBasicInfo(value) {
        return (
            <View style={styles.viewTextBasic}>
                <Text style={[styles.textLoaiTin, { fontSize: 20 }]}>{value}</Text>
            </View>
        );
    }

    _renderNameTodo() {
        let borderColor = this.state.namePostLine ? gui.mainTextColor : 'lightgray';
        let border = this.state.namePostLine ? 1 : 0.5;
        console.log('===========> this.props.event.eventName.length', this.props.event.eventName.length);
        return (
            <View style={styles.viewNamePost}>
                <View style={styles.viewInputPost}>
                    <TextInputAuto
                        onBlur={() => this.onBlurNamePost()}
                        onFocus={() => this.onFocusNamePost()}
                        placeholder="Nhập tên công việc"
                        keyboardType="twitter"
                        placeholderTextColor={gui.colorMainBlur}
                        style={styles.viewTextInput}
                        autoFocus={false}
                        autoCorrect={false}
                        underlineColorAndroid='rgba(0,0,0,0)'
                        onChangeText={(text) => { this._onNamePostChange(text) }}
                        value={this.props.event.eventName}
                        maxLength={99}
                    />
                    <View style={styles.dotStyle} />
                </View>
                {this.state.namePostLine && this.props.event.eventName.length == 0 ? this.guideTagName() : null}
                <FullLine style={[styles.lineStyle, { marginTop: 11, borderColor: borderColor, borderTopWidth: border }]} />
            </View>
        );
    }

    guideTagName() {
        let guide1 = 'Dẫn khách đi xem nhà';
        let guide2 = 'Gửi thông tin cho khách';
        return(
            <View style={styles.viewGuideTagName}>
                <TouchableOpacity style={styles.viewGuideContent}
                                  onPress={() => this._onNamePostChange(guide1)}
                >
                    <Text style={[styles.textSapxep, {color: 'rgba(112,112,112,1)', fontSize: 13}]}>{guide1}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.viewGuideContent, {marginLeft: 8}]}
                                  onPress={() => this._onNamePostChange(guide2)}
                >
                    <Text style={[styles.textSapxep, {color: 'rgba(112,112,112,1)', fontSize: 13}]}>{guide2}</Text>
                </TouchableOpacity>
            </View>
        )
    }

    _renderPersonConnect() {
        let contactName = this.props.groupContact.personContact ? this.props.groupContact.personContact.contactName : '';
        return (
            <View style={[styles.viewEachInfo, { height: 'auto' }]}>
                <TouchableOpacity onPress={this._onPersonContactPress.bind(this)} style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>Người liên quan</Text>
                    <View style={styles.touchKieuNha}>

                        <Text numberOfLines={1} style={styles.dienTichInput}>{contactName}</Text>
                    </View>
                    <View style={styles.dotStyle} />
                </TouchableOpacity>
                <FullLine style={styles.lineStyle} />
            </View>

        );
    }

    _renderEventType() {
        let eventType = this.props.event.eventType || '';
        return (
            <View style={[styles.viewEachInfo, { height: 'auto' }]}>
                <TouchableOpacity onPress={this._onPressEventType.bind(this)} style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>Loại công việc</Text>
                    <View style={styles.touchKieuNha}>
                        <Text numberOfLines={1} style={styles.dienTichInput}>{eventType}</Text>
                    </View>
                    <View style={styles.dotStyle} />
                </TouchableOpacity>
                <FullLine style={styles.lineStyle} />
            </View>

        );
    }

    _renderRelatedAdsPicker() {
        if (this.props.event.eventType == DanhMuc.eventType[1])
            return (
                <View style={[styles.viewEachInfo, { height: 'auto' }]}>
                    <TouchableOpacity onPress={this._onChooseAdsPost.bind(this)} style={styles.viewKieuNha}>
                        <Text style={styles.textSavePost}>BĐS của bạn</Text>
                        <View style={styles.touchKieuNha}>
                            <Text numberOfLines={1} style={styles.dienTichInput}>Nhấn để chọn</Text>
                        </View>
                        <View style={styles.dotStyle} />
                    </TouchableOpacity>
                    <FullLine style={styles.lineStyle} />
                </View>

            );
        else return (<View></View>)
    }

    _renderRelatedAdsList() {
        if (this.props.event.eventType == DanhMuc.eventType[1] && this.state.eventAds && this.state.eventAds.adsID) {
            let data = this.state.eventAds;

            let defaultCover = require('../../assets/image/no_cover.jpg');

            let addressValue = data.diaChi ? data.diaChi : '';

            let priceValue = utils.getPriceDisplay(data.gia, data.loaiTin);
            return (
                <View style={[styles.imgAdsItem, { height: 36 }]}>
                    <TouchableOpacity onPress={this._onPressAdsRow.bind(this, data)}>
                        <View style={styles.viewToDoRow}>
                            <View style={[styles.dotView]}></View>
                            <View style={{ width: width - 136, height: 24, justifyContent: 'center' }}>
                                <Text style={[styles.textMainMinute, { marginLeft: 6 }]} numberOfLines={1}>{addressValue}</Text>
                            </View>
                            <View style={{ position: 'absolute', right: 0 }}>
                                <Text style={[styles.textMainMinute]} numberOfLines={1}>{priceValue}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>
            )
        }
        else return (<View></View>)
    }

    _onPressAdsRow(ads) {
        Actions.GroupAdsDetail({ adsID: ads.adsID, imageDetail: ads.image });
    }

    _onRefresh() { }

    _renderRowAds(value, sectionID, rowID) {
        let data = value.item;
        let defaultCover = require('../../assets/image/no_cover.jpg');

        let addressValue = data.diaChi ? data.diaChi : '';

        let priceValue = utils.getPriceDisplay(data.gia, data.loaiTin);
        return (
            <View style={[styles.imgAdsItem, { height: 36 }]}>
                <TouchableOpacity onPress={this._onPressAdsRow.bind(this, data)}>
                    <View style={styles.viewToDoRow}>
                        <View style={[styles.dotView]}></View>
                        <View style={{ width: width - 136, height: 24, justifyContent: 'center' }}>
                            <Text style={[styles.textMainMinute, { marginLeft: 6 }]} numberOfLines={1}>{addressValue}</Text>
                        </View>
                        <View style={{ position: 'absolute', right: 0 }}>
                            <Text style={[styles.textMainMinute]} numberOfLines={1}>{priceValue}</Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _onChooseAdsPost() {
        this.props.actions.onEventFieldChange('loadingAdsForEvent', true);
        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        Actions.NewAgentPostViewOnly({ owner: 'MyTodoNotes' });
    }

    _onPersonContactPress() {
        this.props.actions.getAllContact(
            { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.groupContact.orderBy }
            , (res) => {
            }
            , (error) => {
                console.log('server respond error: =====>>>>>', error)
            });
        Actions.Contact({ owner: 'MyTodoNotes' });
    }

    _renderDayNoti() {
        let timeAllNoti = 'Cả ngày';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{timeAllNoti}</Text>
                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._notiAllDayChanged()}
                            value={this.props.event.eventAllDay}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _renderDayStartNoti() {
        let textStart = 'Bắt đầu';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{textStart}</Text>
                    <View style={styles.touchKieuNha}>
                        <DatePicker
                            style={{
                                width: width / 2 - 30,
                            }}
                            customStyles={{
                                dateInput: {
                                    borderWidth: 0,
                                    alignItems: 'flex-end'
                                },
                                placeholderText: {
                                    color: gui.mainTextColor,
                                    fontWeight: '500'
                                },
                                dateText: {
                                    color: gui.mainTextColor,
                                    fontWeight: '500'
                                }
                            }}
                            showIcon={false}
                            date={this.state.dateStart}
                            mode="datetime"
                            placeholder="Chọn thời gian"
                            format="HH:mm DD-MM-YYYY"
                            minDate="00:00 01-12-2017"
                            maxDate="00:00 01-12-2020"
                            confirmBtnText="Chọn"
                            cancelBtnText="Hủy"
                            onDateChange={this._onDateStartChange.bind(this)}
                        />
                    </View>
                    <View style={styles.dotStyle} />
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _renderDayEndNoti() {
        let textEnd = 'Kết thúc';
        let dayEnd = 'Thứ 7, 30 Tháng 1, 2018';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{textEnd}</Text>
                    <View style={styles.touchKieuNha}>
                        <DatePicker
                            style={{
                                width: width / 2 - 30,
                            }}
                            customStyles={{
                                dateInput: {
                                    borderWidth: 0,
                                    alignItems: 'flex-end'
                                },
                                placeholderText: {
                                    color: gui.mainTextColor,
                                    fontWeight: '500'
                                },
                                dateText: {
                                    color: gui.mainTextColor,
                                    fontWeight: '500'
                                }
                            }}
                            showIcon={false}
                            date={this.state.dateEnd}
                            mode="datetime"
                            placeholder="Chọn thời gian"
                            format="HH:mm DD-MM-YYYY"
                            minDate="00:00 01-12-2017"
                            maxDate="00:00 01-12-2020"
                            confirmBtnText="Chọn"
                            cancelBtnText="Hủy"
                            onDateChange={this._onDateEndChange.bind(this)}
                        />
                    </View>
                    <View style={styles.dotStyle} />
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _onDateStartChange(date) {
        let eventStartDate = date ? moment(date, 'HH:mm DD-MM-YYYY', true) : '';
        this.setState({ dateStart: eventStartDate });
        this.props.actions.onEventFieldChange('eventStartDate', eventStartDate.toISOString());

        let eventEndDate = eventStartDate ? eventStartDate.add(1, 'hours') : ''
        this.setState({ dateEnd: eventEndDate });
        this.props.actions.onEventFieldChange('eventEndDate', eventEndDate.toISOString());
    }

    _onDateEndChange(date) {
        let eventEndDate = date ? moment(date, 'HH:mm DD-MM-YYYY', true) : '';
        this.setState({ dateEnd: eventEndDate });
        this.props.actions.onEventFieldChange('eventEndDate', eventEndDate.toISOString());
    }

    _renderRepeatNote() {
        let repeatNoti = 'Lặp lại';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{repeatNoti}</Text>
                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._repeatNoteChanged()}
                            value={this.props.event.eventRepeat}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _renderNotifyNote() {
        let notify = 'Thông báo';
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{notify}</Text>
                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._notifyNoteChanged()}
                            value={this.props.event.eventAlarm}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _renderLevelNotify() {
        let levelText = 'Mức độ ưu tiên';
        let { levelNoteKey } = this.state;
        let levelNotify = DanhMuc.levelNotifyNote[levelNoteKey];
        let levelColor = this._getLevelColor();
        return (
            <View style={styles.viewEachInfo}>
                <TouchableOpacity style={styles.viewKieuNha}
                    onPress={this._onPressLevelNotify.bind(this)}
                >
                    <Text style={styles.textSavePost}>{levelText}</Text>
                    <View style={styles.touchKieuNha}>
                        <Text style={[styles.textSavePost, { fontWeight: '500' }]} numberOfLines={1}>{levelNotify}</Text>
                    </View>
                    <View style={[styles.dotStyle, { backgroundColor: levelColor }]} />
                </TouchableOpacity>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _getLevelColor() {
        let { levelNoteKey } = this.state;
        if (levelNoteKey == 0) {
            return 'rgba(255,94,91,1)';
        } else if (levelNoteKey == 1) {
            return 'rgba(120,188,97,1)';
        } else if (levelNoteKey == 2) {
            return 'rgba(82,97,115,0.2)';
        } else return 'rgba(82,97,115,0.2)';
    }

    _onPressLevelNotify() {
        this.setState({
            isOpenLevel: true
        })
    }

    _onPressEventType() {
        this.setState({
            isOpenEventType: true
        })
    }

    _renderModalLevelNoti() {
        return (
            <Modal isOpen={this.state.isOpenLevel}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLevelStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
                animationDuration={200}
            >
                {this._renderLevelContent()}
            </Modal>
        );
    }

    _renderModalEventType() {
        return (
            <Modal isOpen={this.state.isOpenEventType}
                onClosed={this._onTypeModal.bind(this)}
                style={styles.viewLevelStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
                animationDuration={200}
            >
                {this._renderTypeContent()}
            </Modal>
        );
    }

    _renderTypeContent() {
        let levelValues = DanhMuc.findEventTypeValues();
        return (
            <View style={styles.viewDetailModal}>
                {
                    levelValues.map((e) => {
                        let { eventType } = this.state;
                        // let levelValue = DanhMuc.eventType[levelNoteKey];
                        let checked = e == eventType;
                        return (
                            <TouchableOpacity style={styles.choosePoint}
                                key={e}
                                onPress={() => { this._onEventTypeChange(e) }}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainAgentColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
                <TouchableOpacity onPress={this._onTypeModal.bind(this)} style={styles.viewSortModal}>
                    <View>
                        <Text style={styles.textCancel}>Hủy</Text>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _renderLevelContent() {
        let levelValues = DanhMuc.findLevelNotifyNoteValues();
        return (
            <View style={styles.viewDetailModal}>
                {
                    levelValues.map((e) => {
                        let { levelNoteKey } = this.state;
                        let levelValue = DanhMuc.levelNotifyNote[levelNoteKey];
                        let checked = e == levelValue;
                        return (
                            <TouchableOpacity style={styles.choosePoint}
                                key={e}
                                onPress={() => { this._onLevelChange(e) }}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainAgentColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }
                <View style={styles.viewSortModal}>
                    <TouchableOpacity onPress={this._onContentModal.bind(this)}>
                        <Text style={styles.textCancel}>Hủy</Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _onLevelChange(value) {
        let newLevelKey = DanhMuc.findLevelNotifyNoteKey(value);
        this.setState({
            levelNoteKey: newLevelKey,
            isOpenLevel: false
        })
        this.props.actions.onEventFieldChange('eventLevel', newLevelKey);
    }

    _onEventTypeChange(value) {
        // let newLevelKey = DanhMuc.findLevelNotifyNoteKey(value);
        this.setState({
            eventType: value,
            isOpenEventType: false
        })
        this.props.actions.onEventFieldChange('eventType', value);
    }

    _onContentModal() {
        this.setState({
            isOpenLevel: false
        })
    }

    _onTypeModal() {
        this.setState({
            isOpenEventType: false
        })
    }

    _notifyNoteChanged() {
        // let { notifyNote } = this.state;
        // this.setState({
        //     notifyNote: !notifyNote
        // })
        this.props.actions.onEventFieldChange('eventAlarm', !this.props.event.eventAlarm);
    }

    _repeatNoteChanged() {
        // let { repeatNote } = this.state;
        // this.setState({
        //     repeatNote: !repeatNote
        // })
        this.props.actions.onEventFieldChange('eventRepeat', !this.props.event.eventRepeat);
    }

    _notiAllDayChanged() {
        // let { notiAllDay } = this.state;
        // this.setState({
        //     notiAllDay: !notiAllDay
        // })
        this.props.actions.onEventFieldChange('eventAllDay', !this.props.event.eventAllDay);
    }

    _onNamePostChange(value) {
        // this.setState({
        //     nameToto: value
        // })
        this.props.actions.onEventFieldChange('eventName', value);
    }

    onFocusNamePost() {
        this.setState({
            namePostLine: true
        })
    }

    onBlurNamePost() {
        this.setState({
            namePostLine: false
        })
    }

    _onBackButton() {
        this.props.actions.onHideChatIconChange(false);
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderButton: {
        height: 38,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        marginTop: gui.marginTopAgent
    },
    viewBackIcon: {
        height: 38,
        width: 50,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        marginBottom: 5
    },
    viewTextSave: {
        height: 38,
        width: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 3
    },
    textSavePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    viewCreateTodo: {
        height: 36,
        width: width - 32,
        marginTop: 22,
        marginLeft: 16,
        marginRight: 16,
        justifyContent: 'center',
    },
    textCreate: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
        // backgroundColor: gui.groupBackground,
        //marginBottom: 72 // why me can't scroll to end
    },
    viewNameTodo: {
        height: 24,
        width: width - 32,
        marginTop: 23,
        marginLeft: 16,
        marginRight: 16,
        justifyContent: 'center'
    },
    textNameTodo: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewNamePost: {
        width: width - 32,
        height: 'auto',
        marginLeft: 16,
        marginRight: 16
    },
    textBaiDang: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    viewInputPost: {
        width: width - 32,
        height: 'auto',
        marginTop: 20,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotStyle: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: gui.dotColor,
        position: 'absolute',
        right: 8
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: 18,
        // backgroundColor: gui.groupBackground,
        backgroundColor: '#fff',
        width: width - 70,
        color: gui.mainTextColor
    },
    viewKieuNha: {
        height: 41,
        width: width - 32,
        flexDirection: 'row',
        marginTop: 13,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewEachInfo: {
        height: 55,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    touchKieuNha: {
        position: 'absolute',
        right: 16,
        marginRight: 8
    },
    viewTextBasic: {
        height: 32,
        width: width - 32,
        marginTop: 33,
        marginLeft: 16,
        marginRight: 16,
    },
    textLoaiTin: {
        fontFamily: gui.fontFamily,
        fontSize: 22,
        fontWeight: '500',
        color: gui.mainTextColor,
        justifyContent: 'flex-end'
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        marginBottom: 6
    },
    viewLevelStyle: {
        justifyContent: 'center',
        height: 156,
        width: width - 120,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        flexGrow: 1,
        borderRadius: 8
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    textSapxep: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    textCancel: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainAgentColor
    },
    choosePoint: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderBottomWidth: 1,
        borderColor: 'rgba(220,220,220,0.4)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    dienTichInput: {
        marginTop: 8,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 30,
        borderColor: gui.mainTextColor,
        width: width / 2,
        textAlign: 'right',
        alignSelf: 'center',
        fontWeight: '500',
        color: gui.mainTextColor
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewToDoRow: {
        // backgroundColor: '#FFFFFF',
        marginTop: 17,
        marginBottom: 15,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        height: 24,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    toDoContentText: {
        width: width - 40 - 90,
        textAlign: 'left',
        marginLeft: 8,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '600',
        color: '#526173'
    },
    imgAdsItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 188,
        alignSelf: 'auto'
    },
    linearGradientMain: {
        marginTop: 0,
        height: 216,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewEachLogo: {
        paddingHorizontal: 9,
        paddingVertical: 2,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 2,
        opacity: 0.85
    },
    viewNamePrice: {
        position: 'absolute',
        left: 23,
        bottom: 13,
        height: 32,
        width: width - 46,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    viewPrice: {
        height: 32,
        width: (width - 46) / 2,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent'
    },
    textSearch: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewUserLogo: {
        position: 'absolute',
        left: 21,
        bottom: 52,
        height: 24,
        width: width - 42,
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    textNameGroup2: {
        fontFamily: gui.fontFamily,
        fontSize: 24,
        color: '#fff',
        fontWeight: '500'
    },
    deleteContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.5,
        top: 2,
        right: 2,
        alignSelf: 'auto'
    },
    deleteButton: {
        alignItems: 'center'
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    viewDetailPost: {
        height: 78,
        marginLeft: 16,
        width: width - 32,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderTopWidth: 0,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    },
    viewMainTextPost: {
        height: 39,
        width: width - 32,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 17,
        fontWeight: '500',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 64,
        opacity: 0.8,
        marginLeft: 17,
        marginRight: 17
    },
    viewContentSource: {
        height: 36,
        width: width - 32,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTextAddress: {
        height: 28,
        width: width - 32,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    textTimePost: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        position: 'absolute',
        right: 17
    },
    viewLikeComment: {
        height: 39,
        width: width - 32,
        paddingLeft: 16,
        paddingRight: 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'

    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 8
    },
    dotView: {
        width: 8,
        borderRadius: 4,
        height: 8,
        marginLeft: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(82,97,115,0.2)'
    },
    viewGuideTagName: {
        width: width - 32,
        height: 'auto',
        marginTop: 20,
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    viewGuideContent: {
        paddingVertical: 8,
        paddingHorizontal: 8,
        borderRadius: 5,
        borderColor: 'lightgray',
        borderWidth: 1
    }

});

export default connect(mapStateToProps, mapDispatchToProps)(MyTodoNotes);