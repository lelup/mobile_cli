'use strict';

import  React, {Component} from 'react';

import { View, StyleSheet, Alert, TouchableOpacity, Image} from 'react-native';

import {Actions} from 'react-native-router-flux';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import {Map} from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Camera from 'react-native-camera';

import GiftedSpinner from 'react-native-gifted-spinner';

import * as globalActions from '../../reducers/global/globalActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as chatActions from '../../reducers/chat/chatActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as meActions from '../../reducers/me/meActions';
import NewLogin from '../loginGroup/NewLogin';

import RelandIcon from '../RelandIcon';

import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const actions = [
    globalActions,
    groupActions,
    chatActions,
    registerActions,
    meActions
];

function mapStateToProps(state) {
    return {
        global: state.global,
        chat: state.chat,
        // photos: state.group.postWallPhotos,
        // imageIndex: state.group.wallImageIndex
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupPostAds2 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isCapturing: false,
            camera:{
                type: Camera.constants.Type.back,
                flashMode: Camera.constants.FlashMode.auto,
                flashIcon: 'flash-auto'
            }

        }
    }

    render() {

        if (this.props.global.loggedIn) {
            let buttonItems =
                (
                    <View style={styles.viewContainer}>
                        <View style={styles.buttonContainer}>
                            <View style={styles.capture2}>
                                <RelandIcon name="close-circle" color='white' mainProps={styles.captureIcon2}
                                            size={22} textProps={{paddingLeft: 0}}
                                            onPress={this.onHome.bind(this)} />
                            </View>
                            <View style={styles.capture}>
                                <RelandIcon name="camera" color="black"
                                            mainProps={styles.captureIcon}
                                            size={22} textProps={{paddingLeft: 0}}
                                            onPress={this.takePictureWithLocation.bind(this)} disabled={this.state.isCapturing} />
                            </View>
                            <View style={styles.capture2}>
                            </View>
                        </View>

                        <View style={styles.buttonTopCamera}>
                            <View style={styles.viewTypeCamera} >
                                {/*<Image*/}
                                {/*source={this.flashIcon}*/}
                                {/*/>*/}
                                <RelandIcon name="camera-switch" color="rgba(255,255,255,0.85)"
                                            mainProps={styles.captureIcon3}
                                            size={22} onPress={this.switchType.bind(this)}
                                />
                            </View>
                            <View style={styles.flashButton} >
                                {/*<Image*/}
                                {/*source={this.flashIcon}*/}
                                {/*/>*/}
                                <RelandIcon name={this.state.camera.flashIcon} color="rgba(255,255,255,0.85)"
                                            mainProps={styles.captureIcon3}
                                            size={24} onPress={this.switchFlash.bind(this)}
                                />
                            </View>
                        </View>


                    </View>);
            return (
                <View style={[styles.container]} >
                    <Camera
                        ref={(cam) => {
                            this.camera = cam;
                        }}
                        // captureTarget={Camera.constants.CaptureTarget.disk}
                        style={styles.preview}
                        aspect={Camera.constants.Aspect.fill}
                        captureAudio={false}
                        type={this.state.camera.type}
                    >
                        {buttonItems}
                    </Camera>
                    {this._renderLoadingView()}
                </View>
            )
        } else {
            return (
                <View style={styles.container} >
                    <NewLogin />
                </View>
            )
        }
    }

    onHome() {
        Actions.pop();
    }

    switchType (){
        let newType;
        const { back, front } = Camera.constants.Type;

        if (this.state.camera.type === back) {
            newType = front;
        } else if (this.state.camera.type === front) {
            newType = back;
        }

        this.setState({
            camera: {
                ...this.state.camera,
                type: newType
            },
        });
    }
    switchFlash () {
        let newFlashMode;
        let newFlashIcon;
        const { auto, on, off } = Camera.constants.FlashMode;

        if (this.state.camera.flashMode === auto) {
            newFlashMode = on;
            newFlashIcon = 'flash-on';
        } else if (this.state.camera.flashMode === on) {
            newFlashMode = off;
            newFlashIcon = 'flash-off';
        } else if (this.state.camera.flashMode === off) {
            newFlashMode = auto;
            newFlashIcon = 'flash-auto';
        }

        this.setState({
            camera: {
                ...this.state.camera,
                flashMode: newFlashMode,
                flashIcon: newFlashIcon
            }
        });
    }

    // get typeIcon() {
    //     let icon;
    //     const { back, front } = Camera.constants.Type;
    //
    //     if (this.state.camera.type === back) {
    //         icon = require('../assets/image/ic_camera_rear_white.png');
    //     } else if (this.state.camera.type === front) {
    //         icon = require('../assets/image/ic_camera_front_white.png');
    //     }
    //
    //     return icon;
    // }
    // get flashIcon() {
    //     let icon;
    //     const { auto, on, off } = Camera.constants.FlashMode;
    //
    //     if (this.state.camera.flashMode === auto) {
    //         icon = require('../assets/image/ic_flash_auto_white.png');
    //     } else if (this.state.camera.flashMode === on) {
    //         icon = require('../assets/image/ic_flash_on_white.png');
    //     } else if (this.state.camera.flashMode === off) {
    //         icon = require('../assets/image/ic_flash_off_white.png');
    //     }
    //
    //     return icon;
    // }

    takePictureWithLocation() {
        this.setState({isCapturing: true});

        navigator.geolocation.getCurrentPosition(
            (position) => {
                let metadata = {metadata: {location: position}};
                this.takePicture(metadata);
            },
            (error) => {
                this.takePicture({});
            },
            {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
        );
    }

    takePicture(metadata) {
        if (!this.camera) {
            return;
        }
        this.camera.capture(metadata)
            .then((data) => {
                this.imageCropper(data);
                this.setState({isCapturing: false});
            })
            .catch(err => {
                if (err.message && err.message.indexOf("User denied access")>=0){
                    Alert.alert("Thông báo", gui.INF_CameraAccess);
                } else {
                    log.info(err);
                }
                this.setState({isCapturing: false});
            });
    }

    imageCropper(data) {
        let {photos, wallImageIndex} = this.props;
        let newPhotos = [];
        if (!photos) {
            wallImageIndex = 0;
        } else {
            newPhotos = [...photos];
        }

        newPhotos[wallImageIndex] = {uri: data.path};

        // this.props.actions.onGroupFieldChange('postWallPhotos', newPhotos);
        this.props.onPhotosChange && this.props.onPhotosChange(newPhotos);
        this.props.onTakePhoto && this.props.onTakePhoto();
        Actions.pop();
    }

    _renderLoadingView() {
        if (this.state.isCapturing) {
            return (
                <View style={styles.loadingContent}>
                    <GiftedSpinner color="white" size="large"/>
                </View>
            )
        }
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "transparent"
    },
    preview: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
        height: height,
        width: width
    },
    capture: {
        backgroundColor: '#fff',
        borderRadius: 50,
        height:50,
        width:50,
        justifyContent:'center',
        alignItems:'center',
        marginRight: 5
    },
    capture2: {
        backgroundColor: 'transparent',
        borderRadius: 5
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        width: 50,
        padding: 5
    },
    captureIcon2: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    captureIcon3: {
        backgroundColor:'transparent',
        justifyContent: 'center',
        padding: 5
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        bottom:0,
        backgroundColor: 'rgba(0,0,0,0.85)',
        width: width,
        height: 58,
        alignItems: 'center'
    },
    loadingContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: height/2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    viewContainer:{
        flex:1,
        justifyContent:'flex-end',
        alignItems:'center'
    },
    viewTypeCamera:{
        left: 41
    },
    flashButton:{
        right: 40
    },
    buttonTopCamera:{
        position: 'absolute',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        top: 0,
        width:width,
        height:60,
        flex:1,
        backgroundColor:'rgba(0,0,0,0.85)',
        paddingTop:20

    }
});


export default connect(mapStateToProps, mapDispatchToProps)(GroupPostAds2);