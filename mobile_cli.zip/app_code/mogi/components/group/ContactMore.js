'use strict';
import React, {Component} from 'react';

import {View, StyleSheet, AlertIOS, Alert, WebView} from 'react-native'

import {Actions} from 'react-native-router-flux';

import CommonHeader from '../../components/CommonHeader';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import WebViewAutoheight from './WebViewAutoheight';
var {width, height} = utils.getDimensions();

class ContactMore extends Component {
    constructor(props) {
        super(props);
        this.state = {
            source: {uri: props.url}
        };
    }

    render() {
        return (
            <View style={myStyles.fullWidthContainer}>
                {/* <CommonHeader headerTitle={"Street View"} /> */}
                <View style={myStyles.headerSeparator} />

                <WebViewAutoheight
                    source={this.state.source}
                    style={{width: width, height: height-64}}
                    automaticallyAdjustContentInsets={false}
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                    decelerationRate="normal"
                    startInLoadingState={true}
                    scalesPageToFit={true}
                />
            </View>
        );
    }
}

export default (ContactMore);



// Later on in your styles..
var myStyles = StyleSheet.create({
    fullWidthContainer: {
        flexGrow: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    headerSeparator: {
        marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    }
});

