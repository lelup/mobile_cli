'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import { Map } from 'immutable';

import gui from '../../lib/gui';

import React, { Component } from 'react';

import {
    Text, View, Navigator, TouchableOpacity, InteractionManager, TouchableHighlight, Alert, TouchableWithoutFeedback
    , ListView, SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS, Image, TextInput, Animated, Platform, Keyboard, FlatList,
    Switch
} from 'react-native'

import Modal from 'react-native-modalbox';
import CheckDot from '../detail/CheckDot';
import { Actions } from 'react-native-router-flux';
import TruliaIcon from '../TruliaIcon'
import OfflineBar from '../line/OfflineBar';
import TitleTabButton from './TitleTabButton';
import RangeUtils from "../../lib/RangeUtils"
import FontAwesomeLight from '../font/FontAwesomeLight'
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import DanhMuc from "../../assets/DanhMuc"

import Icon from 'react-native-vector-icons/FontAwesome';
import MLikeTapButton3 from '../MLikeTapButton3';
import SegmentedControl from '../SegmentedControl';

import log from '../../lib/logUtil';
import moment from 'moment';
import PickerExt from '../picker/PickerExt';

import FullLine from '../line/FullLine';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import DatePicker from 'react-native-datepicker';
import ScalableText from 'react-native-text';

import placeUtil from '../../lib/PlaceUtil';

import Toast, { DURATION } from '../toast/Toast';

import GiftedSpinner from 'react-native-gifted-spinner';

import utils from '../../lib/utils';

import userApi from '../../lib/userApi';
var { width, height } = utils.getDimensions();
const ds_listAdsSuggest = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    adsMgmtActions,
    postAdsActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class AgentWto extends Component {
    constructor(props) {
        super(props);

        this._firstDisplay = true;
        this._scrollViewHeight = 0;
        this._scrollContentHeight = 0;
        this._scrollToBottomOnNextRender = false;
        this._scrollToPreviousPosition = false;
        this.listViewMaxHeight = height - 114 + 48;

        let { id, loaiTin, mua, thue, huongNha, dienTich, soTangSelectedIdx,
            soPhongNguSelectedIdx, soNhaTamSelectedIdx, ghiChu, priority, dateStart, dateEnd, ketNoiCungCau } = this.props.group.agentWtoFields;
        let { initDienTich, fromDienTich, toDienTich } = this._initDienTich();
        let { initGia, fromGia, toGia } = this._initGia(loaiTin);

        let dataAdsSuggest = [
            {
                giaFmt: "2 tỷ",
                diaChi: "Sun Square, Nam Từ Liêm, Hà Nội",
                cover: "https://img.landber.com/2dea1808-ddfa-42a4-be4a-fcc641ade62b.jpg",
                dienTichFmt: "150m²",
                soPhongNgu: 5,
                soPhongTam: 5,
                huongNha: 4
            },
            {
                giaFmt: "2 tỷ",
                diaChi: "Sun Square, Nam Từ Liêm, Hà Nội",
                cover: "https://img.landber.com/2dea1808-ddfa-42a4-be4a-fcc641ade62b.jpg",
                dienTichFmt: "150m²",
                soPhongNgu: 5,
                soPhongTam: 5,
                huongNha: 4
            },
            {
                giaFmt: "2 tỷ",
                diaChi: "Sun Square, Nam Từ Liêm, Hà Nội",
                cover: "https://img.landber.com/2dea1808-ddfa-42a4-be4a-fcc641ade62b.jpg",
                dienTichFmt: "150m²",
                soPhongNgu: 5,
                soPhongTam: 5,
                huongNha: 4
            }
        ]
        this.state = {
            id: id,
            showGia: false,
            showDienTich: false,
            initGia: initGia,
            initDienTich: initDienTich,
            fromDienTich: fromDienTich,
            toDienTich: toDienTich,
            fromGia: fromGia,
            toGia: toGia,
            toggleState: false,
            loaiTin: loaiTin,
            mua: mua,
            thue: thue,
            dienTich: dienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            ghiChu: ghiChu,
            onCancelling: false,
            blankFromGiaColor: gui.placeholderColor,
            blankToGiaColor: gui.placeholderColor,
            blankDiaChiColor: gui.placeholderColor,
            dateStart: dateStart,
            dateEnd: dateEnd,
            ketNoiCungCau: ketNoiCungCau,
            likeStatus: priority,
            height: new Animated.Value(this.listViewMaxHeight),
            ghiChuFocus: false,
            postWtoModal: false,
            changeWto: 'mua',
            showMoreContent: false,
            dataAdsSuggest: dataAdsSuggest,
            giaAnimation: new Animated.Value(),
            dienTichAnimation: new Animated.Value()
        };
    }

    _initDienTich() {
        let { dienTich } = this.props.group.agentWtoFields;
        let initDienTich = [];
        Object.assign(initDienTich, dienTich);
        let dienTichVal = RangeUtils.dienTichRange.toValRange(initDienTich);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        return { initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich };
    }

    _initGia(loaiTin) {
        let gia = this.props.group.agentWtoFields[loaiTin].gia;
        let initGia = [];
        Object.assign(initGia, gia);
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(initGia);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        return { initGia: initGia, fromGia: fromGia, toGia: toGia };
    }

    _onLoaiTinChange(value) {
        let { initGia, fromGia, toGia } = this._initGia(value);
        this.setState({ loaiTin: value, initGia: initGia, fromGia: fromGia, toGia: toGia, showGia: false, showDienTich: false, postWtoModal: false });
    }

    _onPressGiaHandle() {
        // this.pickerGia.toggle();
        var { showGia } = this.state;
        this.setState({ showGia: !showGia });
        if (!showGia) {
            this._onScrollGia();
        }
    }

    _onScrollGia() {
        if (this._scrollView) {
            // var {showDienTich} = this.state;
            // var scrollTo = 38;
            // if (showDienTich) {
            //     scrollTo = scrollTo + 225;
            // }
            // this._scrollView.scrollTo({y: scrollTo});
            this._scrollView.scrollTo({ y: 40 });
        }
    }

    _onPressDienTichHandle() {
        // this.pickerDienTich.toggle();
        var { showDienTich } = this.state;
        this.setState({ showDienTich: !showDienTich });
        if (!showDienTich) {
            this._onScrollDienTich();
        }
    }

    _onScrollDienTich() {
        if (this._scrollView) {
            this._scrollView.scrollTo({ y: 90 });
        }
    }

    _onGhiChuFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + 175;
            if (this.showSoTang()) {
                scrollTo = scrollTo + 95;
            }
            if (this.showSoPhongNgu()) {
                scrollTo = scrollTo + 95;
            }
            if (this.showSoNhaTam()) {
                scrollTo = scrollTo + 95;
            }
            this._scrollView.scrollTo({ y: scrollTo });
        }
    }

    _doChangeGia(loaiTin, giaVal) {
        var parent = {};
        Object.assign(parent, this.state[loaiTin]);
        parent.gia = giaVal;
        if (loaiTin == 'mua') {
            this.setState({ mua: parent });
        } else {
            this.setState({ thue: parent });
        }
    }

    _onDienTichChanged(pickedValue) {
        let dienTichVal = pickedValue.split('_');
        let value = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        var initDienTich = [];
        Object.assign(initDienTich, value);
        let fromDienTich = dienTichVal[0];
        let toDienTich = dienTichVal[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({ initDienTich: initDienTich, fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value });
        setTimeout(() => {
            this._getSuggestAds(null, null, null)
        }, 500)
    }

    // _getLoaiNhatDatValue() {
    //     let { loaiTin } = this.state;
    //     return DanhMuc.getLoaiNhaDatWToForDisplay(loaiTin, this.state[loaiTin].loaiNhaDat, true).substring(0, 25);
    // }

    // _getHuongNhaValue() {
    //     var { huongNha } = this.state;
    //     if (!huongNha) {
    //         return RangeUtils.BAT_KY;
    //     }
    //     return DanhMuc.HuongNha[huongNha];
    // }


    _getLoaiNhatDatValue() {
        let { loaiTin } = this.state;
        if (!this.state[loaiTin].loaiNhaDat || this.state[loaiTin].loaiNhaDat.length == 0 || this.state[loaiTin].loaiNhaDat[0] == 0) {
            return RangeUtils.BAT_KY;
        }
        return utils.getLoaiNhaDatText(loaiTin, this.state[loaiTin].loaiNhaDat, 20);
    }

    _getHuongNhaValue() {
        let { huongNha } = this.state;
        if (!huongNha || huongNha.length == 0 || huongNha[0] == 0) {
            return RangeUtils.BAT_KY;
        }
        return utils.getHuongNhaText(huongNha, 20);
    }

    _getHeaderTitle() {
        let { place } = this.props.group.agentWtoFields;
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    componentDidMount() {
        this.scrollResponder = this._scrollView.getScrollResponder();
    }

    render() {

        let blankDiaChiColor = 'rgba(166,178,188,1)';

        let diaChi = this._getHeaderTitle();
        let diaChiColor = (diaChi == gui.CHON_KHU_VUC) ? blankDiaChiColor : gui.textPostAds;
        let styleHot = this.state.likeStatus == 'hot' ? [styles.tabStyle, { marginLeft: 0 }, styles.mainViewSelected1] : [styles.tabStyle, { marginLeft: 0 }];
        let styleWarm = this.state.likeStatus == 'warm' ? [styles.tabStyle, styles.mainViewSelected2] : [styles.tabStyle];
        let styleInactive = this.state.likeStatus == 'inactive' ? [styles.tabStyle, styles.mainViewSelected3] : [styles.tabStyle];
        return (
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                style={{ flex: 1 }}
            >
                <View style={styles.fullWidthContainer}
                >
                    <OfflineBar />
                    <View style={[styles.searchFilter, { top: 64 }]}>
                        <FullLine />
                        <View style={styles.scrollView}>
                            <Animated.View
                                style={{
                                    height: this.state.height,
                                    justifyContent: 'flex-end',
                                }}

                            >
                                <ScrollView
                                    keyboardShouldPersistTaps="always"
                                    keyboardDismissMode="none"
                                    ref={(scrollView) => { this._scrollView = scrollView; }}
                                    onLayout={event => {
                                        this._scrollViewHeight = event.nativeEvent.layout.height
                                    }}
                                    onContentSizeChange={(contentWidth, contentHeight) => {
                                        this._scrollContentHeight = contentHeight;
                                    }}
                                    // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
                                    onKeyboardWillShow={this.onKeyboardWillShow.bind(this)}
                                    onKeyboardDidShow={this.onKeyboardDidShow.bind(this)}
                                    // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
                                    onKeyboardWillHide={this.onKeyboardWillHide.bind(this)}
                                    onKeyboardDidHide={this.onKeyboardDidHide.bind(this)}
                                    //automaticallyAdjustContentInsets={false}
                                    showsVerticalScrollIndicator={false}
                                    vertical={true}
                                    style={styles.scrollView2}>
                                    {this.renderTabCanMuaThue()}
                                    <View style={styles.searchFilterDetail}>
                                        <FullLine />
                                        {this.renderHeaderLabel('ĐẶC ĐIỂM')}
                                        <FullLine />
                                        <TouchableOpacity
                                            disabled={this.isUploading()}
                                            onPress={this._onAddressPress.bind(this)}>
                                            <View style={[styles.searchFilterAttributeExt3, { width: width }]}>
                                                <View style={{ width: 55 }}>
                                                    <Text style={styles.textSavePost}>
                                                        Khu vực
                                                        </Text>
                                                </View>
                                                <View style={{ flexDirection: "row", justifyContent: "flex-end", width: width - 38 - 55 }}>
                                                    <View style={{ width: width - 38 - 75, alignItems: "flex-end" }}>
                                                        <ScalableText style={styles.searchAttributeValue} numberOfLines={1}> {this._getTextAddress()} </ScalableText>
                                                    </View>
                                                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                                                </View>
                                            </View>
                                        </TouchableOpacity>
                                        <FullLine style={{ marginLeft: 17 }} />
                                        <TouchableOpacity
                                            disabled={this.isUploading()}
                                            onPress={this._onPropertyTypesPressed.bind(this)}>
                                            <View style={styles.searchFilterAttributeExt3}>
                                                <Text style={styles.textSavePost}>
                                                    Loại nhà đất
                                                </Text>
                                                <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                                                    <ScalableText style={styles.searchAttributeValue}> {this._getLoaiNhatDatValue()} </ScalableText>
                                                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                                                </View>
                                            </View>
                                        </TouchableOpacity>
                                        <FullLine style={{ marginLeft: 17 }} />
                                        {this._renderGia()}
                                        <FullLine style={{ marginLeft: 17 }} />
                                        {this._renderDienTich()}
                                        <FullLine style={{ marginLeft: 17 }} />
                                        {this._renderHuongNha()}
                                        {this.showSoTang() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                                        {this._renderSoTang()}
                                        {this.showSoPhongNgu() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                                        {this._renderSoPhongNgu()}
                                        {this.showSoNhaTam() ? <FullLine style={{ marginLeft: 17 }} /> : null}
                                        {this._renderSoNhaTam()}
                                        {/*<View style={styles.lineSuggest} />*/}
                                        <FullLine />
                                        {this.renderHeaderLabel('GẮN VỚI KHÁCH CỦA BẠN')}
                                        <FullLine />
                                        {this._renderPersonConnect()}
                                        <FullLine />
                                        {this.renderHeaderLabel('KẾT NỐI CUNG & CẦU')}
                                        <FullLine />
                                        {this._renderKetNoiCungCau()}
                                        <FullLine />
                                        {this.renderHeaderLabel('THỜI GIAN')}
                                        <FullLine />
                                        {this._renderDayStartNoti()}
                                        {this._renderDayEndNoti()}
                                        {/*<View style={styles.lineSuggest} />*/}
                                        <FullLine />
                                        {this.renderHeaderLabel('ĐỘ ƯU TIÊN')}
                                        <FullLine />
                                        <View style={[styles.viewTabInterest]}>
                                            <MLikeTapButton3 name={'hot'}
                                                onPress={this._onStatusPress.bind(this)}
                                                selected={this.state.likeStatus == 'hot'}
                                                mainProps={styleHot}
                                                line1="Hot"></MLikeTapButton3>

                                            <MLikeTapButton3 name={'warm'}
                                                onPress={this._onStatusPress.bind(this)}
                                                selected={this.state.likeStatus == 'warm'}
                                                mainProps={styleWarm}
                                                line1="Warm"></MLikeTapButton3>

                                            <MLikeTapButton3 name={'inactive'}
                                                onPress={this._onStatusPress.bind(this)}
                                                selected={this.state.likeStatus == 'inactive'}
                                                mainProps={styleInactive}
                                                line1="Inactive"></MLikeTapButton3>
                                        </View>
                                        {/*<View style={styles.lineSuggest} />*/}
                                        <FullLine />
                                        {this.renderHeaderLabel('GHI CHÚ')}
                                        <FullLine />
                                        {this._renderGhiChu()}
                                        <FullLine style={[styles.lineStyle, { marginLeft: 16, width: width - 16 }]} />
                                        <View style={styles.viewLine} />
                                    </View>
                                </ScrollView>
                                {this._renderAdsSuggest()}
                                {this._renderPostWToButton()}
                            </Animated.View>
                            {this.renderModalPostWto()}
                            {/*{this.state.toggleState ? <Button onPress={() => dismissKeyboard()}*/}
                            {/*style={[styles.searchButtonText2, {*/}
                            {/*textAlign: 'right', color: gui.mainColor,*/}
                            {/*backgroundColor: gui.doneKeyButton*/}
                            {/*}]}>Xong</Button> : null}*/}
                            <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />

                        </View>
                    </View>
                    <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={height / 2}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{ color: '#fff' }}
                    />
                    {this._renderLoadingView()}
                    {this._renderHeaderAds()}
                </View>
            </TouchableWithoutFeedback>
        );
    }

    renderHeaderLabel(title) {
        return (
            <View style={styles.searchSectionTitle}
                onStartShouldSetResponder={() => true}
            >
                <Text style={styles.cacDieuKienText}>
                    {title}
                </Text>
            </View>
        )
    }

    renderTabCanMuaThue() {
        let { loaiTin } = this.state;
        return (
            <View style={[styles.searchFilterButton]}>
                {/*<View style={styles.viewTextTitle}>*/}
                {/*<Text style={[styles.textSavePost, {fontWeight: '500'}]}>Loại nhu cầu</Text>*/}
                {/*</View>*/}
                {this.renderHeaderLabel('LOẠI NHU CẦU')}
                <FullLine />
                <View style={styles.viewButtons}>
                    <TitleTabButton name={'mua'}
                        disabled={this.isUploading()}
                        onPress={this._onLoaiTinChange.bind(this)}
                        selected={loaiTin === 'mua'}
                        textButtonStyle={{ fontSize: 17 }}
                        mainProps={{
                            borderTopLeftRadius: 5, borderBottomLeftRadius: 5,
                            borderTopWidth: 1, borderLeftWidth: 1, borderBottomWidth: 1,
                            marginLeft: 10, marginRight: 0, width: width / 2 - 16, margin: 5, paddingTop: 2
                        }}>Cần mua</TitleTabButton>
                    <TitleTabButton name={'thue'}
                        disabled={this.isUploading()}
                        onPress={this._onLoaiTinChange.bind(this)}
                        selected={loaiTin === 'thue'}
                        textButtonStyle={{ fontSize: 17 }}
                        mainProps={{
                            borderTopRightRadius: 5, borderBottomRightRadius: 5,
                            borderTopWidth: 1, borderBottomWidth: 1, borderRightWidth: 1,
                            marginLeft: 0, marginRight: 10, width: width / 2 - 16, margin: 5, paddingTop: 2
                        }}>Cần thuê</TitleTabButton>
                </View>
            </View>
        )
    }

    renderModalPostWto() {
        return (
            <Modal isOpen={this.state.postWtoModal}
                onClosed={this.outModalPostWto.bind(this)}
                style={styles.viewModalShareAds}
                position={"top"}
                entry={"top"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this.renderModalPostWtoContent()}
            </Modal>
        )
    }

    outModalPostWto() {
        this.setState({
            postWtoModal: false
        })
    }

    renderModalPostWtoContent() {
        return (
            <View style={styles.viewShareAds}>
                <View style={styles.viewTriangle}></View>
                <TouchableOpacity style={styles.viewShareTopContent}
                    onPress={this.onWtoMuaPress.bind(this)}
                >
                    <View style={styles.checkAds}>
                        <CheckDot name={'mua'}
                            onPress={this.onWtoMuaPress.bind(this)}
                            selected={this.state.loaiTin == 'mua'}
                            mainProps={styles.viewSaleState}></CheckDot>
                    </View>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15, marginLeft: 4 }]}>Đăng tin cần mua</Text>
                </TouchableOpacity>
                <View style={styles.lineStyles} />
                <TouchableOpacity style={styles.viewShareBottomContent}
                    onPress={this.onWtoThuePress.bind(this)}
                >
                    <View style={styles.checkAds}>
                        <CheckDot name={'thue'}
                            onPress={this.onWtoThuePress.bind(this)}
                            selected={this.state.loaiTin == 'thue'}
                            mainProps={styles.viewSaleState}></CheckDot>
                    </View>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15, marginLeft: 4 }]}>Đăng tin cần thuê</Text>
                </TouchableOpacity>
            </View>
        )
    }

    onWtoMuaPress() {
        this.props.actions.onAgentWtoFieldChange('loaiTin', 'mua');
        this._onLoaiTinChange('mua');
    }

    onWtoThuePress() {
        this.props.actions.onAgentWtoFieldChange('loaiTin', 'thue');
        this._onLoaiTinChange('thue');
    }


    onKeyboardWillHide() {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight,
            duration: 150,
        }).start();
    }

    onKeyboardDidHide(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillHide(e);
        }

        this.scrollToBottom();
    }

    onKeyboardWillShow(e) {
        Animated.timing(this.state.height, {
            toValue: this.listViewMaxHeight - e.endCoordinates.height,
            duration: 200,
        }).start();
    }

    onKeyboardDidShow(e) {
        if (Platform.OS === 'android') {
            this.onKeyboardWillShow(e);
        }

        setTimeout(() => {
            this.scrollToBottom();
        }, (Platform.OS === 'android' ? 200 : 100));
    }

    scrollToBottom(animated = null) {
        if (this.state.ghiChuFocus && this._scrollViewHeight && this._scrollContentHeight && this._scrollContentHeight > this._scrollViewHeight) {
            let scrollDistance = this._scrollViewHeight - this._scrollContentHeight;

            if (this.scrollResponder) {
                this.scrollResponder.scrollTo({
                    y: -scrollDistance,
                    x: 0,
                    animated: typeof animated === 'boolean' ? animated : true
                });
                // this.scrollView.scrollToEnd({animated: typeof animated === 'boolean' ? animated : true});
            }
        }
    }

    getBackgroundButton() {
        let backgroundColor = '#fff';
        if (this.state.likeStatus == 'hot')
            backgroundColor = 'rgba(255,81,81,1)';
        if (this.state.likeStatus == 'warm')
            backgroundColor = 'rgba(255,207,86,1)';
        if (this.state.likeStatus == 'inactive')
            backgroundColor = 'rgba(169,183,200,1)';
        return backgroundColor;
    }

    _onStatusPress(value) {
        this.setState({
            likeStatus: value
        });
    }

    _renderLoadingView() {
        if (this.props.group.loadingAgentWto || this.props.group.loadingMatchingAds || this.props.group.loadingContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderAdsSuggest() {
        let heightAds = 48;
        let listAdsMatching = this.props.group.listAdsMatchingWto;
        let adsToRender = listAdsMatching[0] && listAdsMatching[0].data.filter((e) => { return e.userID == this.props.global.currentUser.userID })
        let numberOfAds = 0;
        if (adsToRender && adsToRender.length > 0)
            numberOfAds = adsToRender[0].data.length;

        let numberAdsSuggestText = ` ${numberOfAds} nhà phù hợp`;
        let moreInfoLabel = this.state.showMoreContent ? 'Thu gọn' : 'Mở rộng';
        let moreInfoIcon = this.state.showMoreContent ? 'chevron-down' : 'chevron-up';
        return (
            <View>
                <FullLine />
                <TouchableOpacity style={[styles.viewAdsSuggest, { height: heightAds }]}
                    onPress={() => this._onMoreButtonPressed()}
                >
                    <View style={styles.viewNumberAdsSuggest}>
                        {numberOfAds > 0 ?
                            <Text style={styles.textSavePost}>Bạn có
                            <Text style={[styles.textSavePost, { fontWeight: '500' }]}>{numberAdsSuggestText}</Text>
                            </Text>
                            : <Text style={styles.textSavePost}>Chưa có nhà phù hợp</Text>
                        }

                    </View>
                    <View style={styles.viewNumberAdsSuggestRight}>
                        <Text style={[styles.textSavePost, { color: gui.mainColor }]}>{moreInfoLabel}</Text>
                        <Icon name={moreInfoIcon} color={gui.mainAgentColor} size={15} style={{ marginLeft: 5 }} />
                    </View>
                </TouchableOpacity>
                {this.state.showMoreContent ? this._renderAdsExpand() : null}
            </View>
        )
    }

    _renderAdsExpand() {
        let listAdsMatching = this.props.group.listAdsMatchingWto;
        let adsToRender = listAdsMatching[0] && listAdsMatching[0].data.filter((e) => { return e.userID == this.props.global.currentUser.userID })
        if (adsToRender && adsToRender.length > 0)
            return (
                <View style={styles.viewAdsSuggestContent}>
                    {/*<FlatList*/}
                    {/*data={adsToRender[0].data}*/}
                    {/*keyExtractor={(item, index) => "list" + index}*/}
                    {/*renderItem={(data) => this._renderRowAdsSuggest(data.item)}*/}
                    {/*removeClippedSubviews={false}*/}
                    {/*horizontal*/}
                    {/*contentContainerStyle={{flex: 1}}*/}
                    {/*style={{flex: 1}}*/}
                    {/*/>*/}
                    <ListView contentContainerStyle={{ alignItems: 'center', paddingRight: 20 }}
                        style={styles.listSource}
                        horizontal={true}
                        enableEmptySections={true}
                        legacyImplementation={true}
                        showsHorizontalScrollIndicator={false}
                        dataSource={ds_listAdsSuggest.cloneWithRows(adsToRender[0].data)}
                        renderRow={this._renderRowAdsSuggest.bind(this)} />
                </View>
            )
    }

    _renderRowAdsSuggest(data) {
        let imgUrl = data.image.cover;
        let imagePost = imgUrl ? { uri: imgUrl } : null;
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imgUrl) {
            imagePost = require('../../assets/image/no_cover.jpg');
        }
        let giaFmt = data ? utils.getPriceDisplay(data.gia, data.loaiTin) : '';
        let giaContent = `Giá: ${giaFmt}`;
        let areaValue = utils.getDienTichDisplay(data.dienTich);
        let bedroomValue = data.soPhongNgu;
        let bathroomValue = data.soPhongTam;
        let huongNhaValue = DanhMuc.getHuongNhaForDisplay(data.huongNha);

        // let areaValue = data.dienTichFmt || DanhMuc.KHONG_RO;
        // let bedroomValue = data.soPhongNgu ? String(data.soPhongNgu) : '';
        // let bathroomValue = data.soPhongTam ? String(data.soPhongTam) : '';
        // let huongNhaValue = data.huongNha ? DanhMuc.HuongNha[data.huongNha] : DanhMuc.BAT_KY;

        let diaChiFullName = data.diaChi ? data.diaChi : (data.place ? data.place.diaChi : ' ');
        let detailItems = [];
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO) {
            detailItems.push(this.getDienTich(areaValue));
        }
        if (!!bedroomValue) {
            detailItems.push(this._renderPhongNgu(bedroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!bathroomValue) {
            detailItems.push(this._renderPhongTam(bathroomValue, (detailItems.length == 0) ? 0 : 12));
        }
        if (!!huongNhaValue) {
            detailItems.push(this._renderHuongNhaAdsGuide(huongNhaValue, (detailItems.length == 0) ? 0 : 9));
        }
        return (
            <TouchableOpacity style={styles.viewNewDetailPost}
                onPress={this._onPressAdsRow.bind(this, data)}
            >
                <Image
                    resizeMode={"cover"}
                    source={imagePost}
                    defaultSource={defaultCover}
                    style={styles.imagePost} />
                <View style={[styles.viewPercentDraft, { marginTop: 0, width: width - 52 - 48 - 32 }]}>
                    <Text style={[styles.textGiaNha, { fontSize: 17, fontWeight: '500' }]}>{giaContent}</Text>
                </View>
                {detailItems && detailItems.length > 0 ? (
                    <View style={[styles.viewPercentDraft, { flexDirection: 'row', marginTop: 3 }]}>
                        {detailItems}
                    </View>
                ) : null}
                <View style={[styles.viewLabel, { alignItems: 'flex-start', marginTop: 5 }]}>
                    <FontAwesomeLight name="map-marker-alt" size={15} color={gui.textPostCommon} noAction={true} iconOnly={true} />
                    <View style={{ width: width - 54 - 24 - 17 }}>
                        <Text numberOfLines={1} style={[styles.textDatePost, { fontSize: 14, color: gui.textPostCommon }]}>{diaChiFullName}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    _onPressAdsRow(ads) {
        Actions.GroupAdsDetail({ adsID: ads.id, imageDetail: ads.image.cover });
    }

    _renderHuongNhaAdsGuide(huongNhaValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!huongNhaValue)
            return (
                <View key={"huongNha_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="compass" color={gui.textPostCommon}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{huongNhaValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongTam(bathroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bathroomValue)
            return (
                <View key={"phongTam_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight noAction={true} iconOnly={true}
                        name="bath" color={gui.textPostCommon}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} size={15} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bathroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    _renderPhongNgu(bedroomValue, marginLeft) {
        let uuid = new Date().getTime();
        if (!!bedroomValue)
            return (
                <View key={"phongNgu_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="bed" size={15} color={gui.textPostCommon}
                        mainProps={{ marginTop: 0, marginLeft: marginLeft }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{bedroomValue}</Text>
                </View>
            )
        else return (<View></View>)
    }

    getDienTich(areaValue) {
        let uuid = new Date().getTime();
        if (!!areaValue && areaValue != DanhMuc.KHONG_RO)
            return (
                <View key={"dienTich_" + uuid} style={{ height: 20, justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row' }}>
                    <FontAwesomeLight name="expand" size={15} color={gui.textPostCommon} style={{ marginLeft: 0 }} noAction={true} iconOnly={true} />
                    <Text style={[styles.textMainUser, { marginLeft: 6 }]}>{areaValue}</Text>
                </View>
            )
        else return (<View></View>)

    }

    _onMoreButtonPressed() {
        this.setState({ showMoreContent: !this.state.showMoreContent });
    }

    _renderPostWToButton() {
        if (this.isUploading()) {
            return (
                <View style={styles.viewButtonBottom}>
                    <View style={styles.viewTextPreview}>
                        <Text style={styles.textPreview}>Xem trước</Text>
                    </View>
                    <View style={styles.viewPostWtoButton}>
                        <View style={styles.searchButton}>
                            <GiftedSpinner color="white" />
                        </View>
                    </View>
                    <View style={styles.bottomLine}>
                        <FullLine style={{ width: width }} />
                    </View>
                </View>
            )
        } else {
            return (
                <View style={styles.viewButtonBottom}>
                    <View style={styles.viewTextPreview}>
                        <TouchableOpacity onPress={this._onPressPreview.bind(this)}>
                            <Text style={styles.textPreview}>Xem trước</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewPostWtoButton}>

                        <TouchableHighlight onPress={this.props.group.creatingAgentWto ? null : this.onApply.bind(this)}
                            underlayColor="transparent"
                        >
                            <View style={styles.searchButton}>
                                <Text style={[styles.searchButtonText, { fontWeight: '500' }]}>{this.state.id ? 'Cập nhật' : 'Lưu'}</Text>
                            </View>
                        </TouchableHighlight>

                    </View>
                    <View style={styles.bottomLine}>
                        <FullLine style={{ width: width }} />
                    </View>
                </View>)
        }
    }

    _onPressPreview() {
        let msg = this._validInputData();
        if (msg) {
            this.refs.toastTop && this.refs.toastTop.show(msg, 3000);
            return;
        }

        let { loaiTin, dienTich, soTangSelectedIdx, soPhongNguSelectedIdx, soNhaTamSelectedIdx, huongNha,
            ghiChu, dateStart, dateEnd, ketNoiCungCau } = this.state;

        let { id, place } = this.props.group.agentWtoFields;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        let mua = null;
        let thue = null;
        if (loaiTin == 'mua') {
            mua = this.state['mua'];
        } else {
            thue = this.state['thue'];
        }

        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;

        this.props.actions.onAgentWtoFieldChange('loaiTin', loaiTin);
        this.props.actions.onAgentWtoFieldChange(loaiTin, loaiNhaDatParent);

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);
        this.props.actions.onAgentWtoFieldChange("dienTich", newDienTich);
        this.props.actions.onAgentWtoFieldChange("soTangSelectedIdx", soTangSelectedIdx);
        this.props.actions.onAgentWtoFieldChange("soPhongNguSelectedIdx", soPhongNguSelectedIdx);
        this.props.actions.onAgentWtoFieldChange("soNhaTamSelectedIdx", soNhaTamSelectedIdx);
        this.props.actions.onAgentWtoFieldChange("huongNha", huongNha);
        this.props.actions.onAgentWtoFieldChange("ghiChu", ghiChu);

        let currentUser = this.props.global.currentUser;
        let userID = currentUser.userID;

        let dto = {
            id: id,
            loaiTin: loaiTin,
            mua: loaiTin == 'mua' ? loaiNhaDatParent : undefined,
            thue: loaiTin != 'mua' ? loaiNhaDatParent : undefined,
            dienTich: newDienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            place: place,
            ghiChu: ghiChu,
            userID: userID,
            dateStart: dateStart,
            dateEnd: dateEnd,
            ketNoiCungCau: ketNoiCungCau,
            priority: this.state.likeStatus
        };

        let wtoDto = this.convertWToFieldsToParams(dto);

        Actions.AgentWtoDetail({ data: wtoDto });
    }


    _onPersonContactPress() {
        this.props.actions.getAllContact(
            { 'userID': this.props.global.currentUser.userID, 'orderBy': this.props.groupContact.orderBy }
            , (res) => {
            }
            , (error) => {
                console.log('server respond error: =====>>>>>', error)
            });
        Actions.Contact({ owner: 'AgentWto' });
    }

    _renderPersonConnect() {
        // console.log('renderpercontactnnect ***************', this.props.groupContact.contactOfWto)
        let contactName = this.props.groupContact.contactOfWto && this.props.groupContact.contactOfWto.contactName ? this.props.groupContact.contactOfWto.contactName : 'Nhấn để chọn';
        return (
            <View style={[styles.viewEachInfo]}>
                <TouchableOpacity onPress={this._onPersonContactPress.bind(this)} style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>Khách hàng</Text>
                    <View style={styles.touchKieuNha}>

                        <Text numberOfLines={1} style={styles.khachHangText}>{contactName}</Text>
                    </View>

                </TouchableOpacity>
                {/* <FullLine style={styles.lineStyle} /> */}
            </View>

        );
    }

    _renderKetNoiCungCau() {
        return (
            <View style={styles.viewEachInfo}>
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textKieuNha}>Cho phép kết nối cung cầu </Text>
                    <TouchableOpacity style={styles.viewInfoMatching}>
                        <FontAwesomeSolid
                            name="info-circle"
                            size={15}
                            color={gui.textShare}
                            noAction={true}
                            iconOnly={true}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.touchKieuNha, { marginRight: 0, right: 4 }]}>
                        <Switch
                            onValueChange={() => this._onKetNoiCungCauChange()}
                            value={this.state.ketNoiCungCau ? true : false}
                            onTintColor={'#78BC61'}
                            tintColor={'rgba(82,97,115,0.1)'}
                            style={styles.viewAswitch}
                        />
                    </TouchableOpacity>
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _onKetNoiCungCauChange() {
        let currentCungCau = this.state.ketNoiCungCau;
        this.setState({ ketNoiCungCau: !currentCungCau });
        // let { ketNoiCungCau } = this.props.group.agentWtoFields;
        this.props.actions.onAgentWtoFieldChange('ketNoiCungCau', !currentCungCau);
    }

    _renderDayStartNoti() {
        let textStart = 'Bắt đầu';
        return (
            <View style={styles.viewEachInfo}
                onStartShouldSetResponder={() => true}
            >
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{textStart}</Text>
                    <View style={styles.touchKieuNha}>
                        <DatePicker
                            style={{
                                width: width / 2 - 30,
                            }}
                            customStyles={{
                                dateInput: {
                                    borderWidth: 0,
                                    alignItems: 'flex-end'
                                },
                                placeholderText: {
                                    color: 'rgba(56,151,241,1)',
                                    fontWeight: '500'
                                },
                                dateText: {
                                    color: 'rgba(56,151,241,1)',
                                    fontWeight: '500'
                                }
                            }}
                            showIcon={false}
                            date={this.state.dateStart}
                            mode="date"
                            placeholder="Chọn thời gian"
                            format="DD/MM/YYYY"
                            minDate="01/12/2017"
                            maxDate="01/12/2020"
                            confirmBtnText="Chọn"
                            cancelBtnText="Hủy"
                            onDateChange={this._onDateStartChange.bind(this)}
                        />
                    </View>
                    <View style={styles.dotStyle} />
                </View>
                <FullLine style={[styles.lineStyle, { width: width - 16 }]} />
            </View>
        );
    }

    _renderDayEndNoti() {
        let textEnd = 'Kết thúc';
        return (
            <View style={styles.viewEachInfo}
                onStartShouldSetResponder={() => true}
            >
                <View style={styles.viewKieuNha}>
                    <Text style={styles.textSavePost}>{textEnd}</Text>
                    <View style={styles.touchKieuNha}>
                        <DatePicker
                            style={{
                                width: width / 2 - 30,
                            }}
                            customStyles={{
                                dateInput: {
                                    borderWidth: 0,
                                    alignItems: 'flex-end'
                                },
                                placeholderText: {
                                    color: 'rgba(56,151,241,1)',
                                    fontWeight: '500'
                                },
                                dateText: {
                                    color: 'rgba(56,151,241,1)',
                                    fontWeight: '500'
                                }
                            }}
                            showIcon={false}
                            date={this.state.dateEnd}
                            mode="date"
                            placeholder="Chọn thời gian"
                            format="DD/MM/YYYY"
                            minDate="01/12/2017"
                            maxDate="01/12/2020"
                            confirmBtnText="Chọn"
                            cancelBtnText="Hủy"
                            onDateChange={this._onDateEndChange.bind(this)}
                        />
                    </View>
                </View>
                <FullLine style={styles.lineStyle} />
            </View>
        );
    }

    _onDateStartChange(date) {
        let eventStartDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState({ dateStart: eventStartDate });
    }

    _onDateEndChange(date) {
        let eventEndDate = date ? moment(date, 'DD/MM/YYYY', true) : '';
        this.setState({ dateEnd: eventEndDate });
    }

    _onAddressPress() {
        let { place } = this.props.group.agentWtoFields;
        let placeType = place.codeDuAn ? DanhMuc.placeType.DU_AN : DanhMuc.placeType.DIA_DIEM;
        let selectedDuAn = undefined;
        if (placeType == DanhMuc.placeType.DU_AN) {
            selectedDuAn = {
                duAn: place.codeDuAn,
                placeName: place.tenDuAn,
                tinhName: place.tenTinh,
                tinh: place.codeTinh,
                huyenName: place.tenHuyen,
                huyen: place.codeHuyen,
                xaName: place.tenXa,
                xa: place.codeXa,
                duongName: place.tenDuong,
                duong: place.codeDuong
            };
        }
        let selectedDiaChinh = {
            codeTinh: place.codeTinh || undefined,
            codeHuyen: place.codeHuyen || undefined,
            codeXa: place.codeXa || undefined,
            codeDuong: place.codeDuong || undefined,
            tinh: place.tenTinh || undefined,
            huyen: place.tenHuyen || undefined,
            xa: place.tenXa || undefined,
            duong: place.tenDuong || undefined
        }

        this.setState({ geoFinding: false });

        // Actions.WToPlaceMapView({
        //     onPress: this._loadPositionInMap.bind(this),
        //     diaChi: place.fullName,
        //     viewport: place.viewport,
        //     placeType: placeType,
        //     duAn: selectedDuAn,
        //     diaChinhInfo: selectedDiaChinh,
        //     circle: place.circle,
        //     polygon: place.polygon
        // });

        Actions.ContactWtoAutoComplete(
            {
                onSuggestionBuyPressed: (location) => this._collectSuggestionInfo(location),
                category: ["DIA_CHINH", "DU_AN"],
                placeHolder: 'Nhập tên địa chính/dự án'
            }
        )

    }

    /*
    {
        id: Joi.string(),
        status: Joi.number(),
        dataType: Joi.string(),
        content: Joi.object({
          dienTichDen: Joi.number(),
          dienTichTu: Joi.number(),
          giaDen: Joi.number(),
          giaTu: Joi.number(),
          huongNha: Joi.array(),
          loaiNhaDat: Joi.array(),
          loaiTin: Joi.number(),
          place: Joi.object(),
          ghiChu: Joi.string(),
          soPhongNgu: Joi.number(),
          soPhongTam: Joi.number(),
          soTang: Joi.number()
        })
    }
    */
    /*
         let wtoList = [];
         wtoList.push({
             id: 'unknown',
             // status: e.status,
             content: {
                 loaiTin: this.state.loaiTin === 'mua' ? 0 : 1,
                 place: place
             },
         })
         this.props.actions.getAdsMatchingAgentWto(
             {
                 'userID': this.props.global.currentUser.userID,
                 'wtoList': wtoList,
                 'onlyOwnAds': true,
             }
             , (res) => {
                 // Actions.pop()
                 console.log(' ******************************', res.data)
             }
             , (error) => {
             });
         */
    _getSuggestAds(newPlace, newLoaiNhaDatParent, newHuongNha, newPhongNgu, newTang, newPhongTam) {

        let { loaiTin } = this.state;

        let { dienTich,
            ghiChu, dateStart, dateEnd } = this.state;

        let { id } = this.props.group.agentWtoFields;
        let place = newPlace || this.props.group.agentWtoFields.place
        let huongNha = newHuongNha || this.state.huongNha
        let soTangSelectedIdx = newTang || this.state.soTangSelectedIdx
        let soPhongNguSelectedIdx = newPhongNgu || this.state.soPhongNguSelectedIdx
        let soNhaTamSelectedIdx = newPhongTam || this.state.soNhaTamSelectedIdx

        //do not query until have place info
        if (!place || !place.codeTinh)
            return;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, newLoaiNhaDatParent || this.state[loaiTin]);

        let gia = this.state[loaiTin].gia;
        // console.log('gia: ', gia)
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;

        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let userID = currentUser.userID;

        let dto = {
            id: id,
            loaiTin: loaiTin,
            mua: loaiTin == 'mua' ? loaiNhaDatParent : undefined,
            thue: loaiTin != 'mua' ? loaiNhaDatParent : undefined,
            dienTich: newDienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            place: place,
            ghiChu: ghiChu,
            userID: userID,
            dateStart: dateStart,
            dateEnd: dateEnd,
            priority: this.state.likeStatus,
            contactID: this.props.groupContact.contactOfWto ? this.props.groupContact.contactOfWto.contactID || this.props.groupContact.contactOfWto.id : ''
        };

        let wtoDto = this.convertWToFieldsToParams(dto)

        wtoDto.content.giaTuFmt = undefined
        wtoDto.content.giaDenFmt = undefined
        wtoDto.content.dienTichTuFmt = undefined
        wtoDto.content.dienTichDenFmt = undefined
        wtoDto.content.soPhongNguFmt = undefined
        wtoDto.content.soTangFmt = undefined
        wtoDto.content.soPhongTamFmt = undefined
        wtoDto.content.huongNhaFmt = undefined
        wtoDto.content.textKhongDau = undefined
        let wtoList = [];

        wtoList.push({
            id: wtoDto.id || 'unknown',
            content: wtoDto.content
        })
        this.props.actions.getAdsMatchingAgentWto(
            {
                'userID': this.props.global.currentUser.userID,
                'wtoList': wtoList,
                'onlyOwnAds': true,
            }
            , (res) => {
                // Actions.pop()
                console.log('_get Suggest Ads ******************************', res.data)
            }
            , (error) => {
            });

    }

    _collectSuggestionInfo(position) {

        let place = {
            codeDuong: position.duong || undefined,
            tenDuong: (position.placeType == 'D' ? position.placeName : position.duongName) || undefined,
            codeXa: position.xa || undefined,
            tenXa: (position.placeType == 'X' ? position.placeName : position.xaName) || undefined,
            codeHuyen: position.huyen || undefined,
            tenHuyen: (position.placeType == 'H' ? position.placeName : position.huyenName) || undefined,
            codeTinh: position.tinh || undefined,
            tenTinh: (position.placeType == 'T' ? position.placeName : position.tinhName) || undefined,
            codeDuAn: position.duAn || undefined,
            tenDuAn: (position.placeType == 'A' ? position.placeName : position.duAnName) || undefined,
            viewport: position.viewport || undefined,
            location: position.location || undefined,
            fullName: position.fullName || undefined
        };
        this.props.actions.onAgentWtoFieldChange('place', place);
        this._getSuggestAds(place, null, null);
    }

    _getTextAddress() {
        let diaChi = this._getHeaderTitle();

        if (diaChi && diaChi.length > 40) {
            diaChi = diaChi.substring(0, 40) + '...';
        }

        return diaChi ? diaChi : 'Nhập địa chính hoặc dự án...';
    }

    _renderGhiChu() {
        let placeholder = 'Nhập ghi chú...';
        return (
            <View style={styles.searchFilterAttribute}>
                <TextInput ref="textInput"
                    autoCorrect={false}
                    multiline={true}
                    onChangeText={this._onGhiChuChangeText.bind(this)}
                    style={styles.textInput}
                    value={this.state.ghiChu}
                    placeholder={placeholder}
                    placeholderTextColor={gui.arrowColor}
                    onFocus={() => this.setState({ ghiChuFocus: true })}
                    onBlur={() => setTimeout(() => this.setState({ ghiChuFocus: false }), 1000)}
                    clearButtonMode="never"
                    selectTextOnFocus={true}
                    disabled={this.isUploading()}
                    allowFontScaling={false}
                />
            </View>
        )
    }

    _onGhiChuChangeText(text) {
        this.setState({ ghiChu: text });
    }

    _renderHeaderAds() {
        let { loaiTin } = this.state;
        let iconHeader = !this.state.postWtoModal ? 'chevron-down' : 'chevron-up';
        let loaiTinText = loaiTin === 'mua' ? 'Đăng tin cần mua' : 'Đăng tin cần thuê';
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this.onCancel()}
                    style={styles.backButton}
                    activeOpacity={0}
                >
                    {/*<MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />*/}
                    <Text style={styles.textHeader}>Hủy</Text>
                </TouchableOpacity>
                <View style={[styles.backButton, { flex: 1 }]}>
                    <Text style={[styles.textHeader, { color: gui.mainTextColor2 }]}>{loaiTinText}</Text>
                </View>
                <View
                    style={styles.viewRightHeader}>
                </View>
            </View>
        );
    }

    _onPressLoaiTinChange() {
        this.setState({
            postWtoModal: true
        })
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    onCancel() {
        let isUpdate = this.state.id && this.state.id.length > 0;
        this.setState({ onCancelling: true });
        // this.requeryWto();
        Actions.pop();
    }

    requeryWto() {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.loadMyWto(userID, token)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    this.props.onSetCungCauWtoState && this.props.onSetCungCauWtoState(res.data)
                    setTimeout(() => {
                        let wtoList = [];
                        res.data.forEach((e) => {
                            if (e.ketNoiCungCau) {
                                //clear fields due to endpoint not allow
                                e.content.giaTuFmt = undefined
                                e.content.giaDenFmt = undefined
                                e.content.dienTichTuFmt = undefined
                                e.content.dienTichDenFmt = undefined
                                e.content.soPhongNguFmt = undefined
                                e.content.soTangFmt = undefined
                                e.content.soPhongTamFmt = undefined
                                e.content.huongNhaFmt = undefined

                                wtoList.push({
                                    id: e.wtoID,
                                    status: e.status,
                                    content: e.content,
                                    dataType: e.dataType || undefined,
                                })
                            }
                        })

                        this.props.actions.getAdsMatchingAgentWto(
                            {
                                'userID': this.props.global.currentUser.userID,
                                'wtoList': wtoList,
                                'excludeOwnAds': true,
                            }
                            , (res) => {
                                // Actions.pop()
                            }
                            , (error) => {
                                // Actions.pop()
                            });
                    }, 300);
                }
            });
    }

    isValidLoaiTin() {
        let { loaiTin } = this.state;
        let loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if (loaiNhaDat == '' || loaiNhaDat === 0) {
            return false;
        }
        let dmLoaiNhatDatKeys = loaiTin == 'mua' ? DanhMuc.LoaiNhaDatBanKey : DanhMuc.LoaiNhaDatThueKey;
        let found = dmLoaiNhatDatKeys.filter((item) => item == loaiNhaDat);
        return found && found.length > 0;
    }

    isValidPlace() {
        let { place } = this.props.group.agentWtoFields;
        let validDiaChinh = place.codeDuAn || place.codeXa || place.codeHuyen || place.codeTinh || place.codeDuong;
        let ignoreDiaChinh = (place.circle && place.circle.radius > 0) || (place.polygon && place.polygon.length > 0);
        let valid = ignoreDiaChinh || validDiaChinh;
        this.setState({ blankDiaChiColor: valid ? '#000' : 'red' });
        return valid;
    }

    isValidGia() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let blankFromGiaColor = '#000';
        if (giaVal[0] <= 0) {
            blankFromGiaColor = 'red';
        }
        let blankToGiaColor = '#000';
        if (giaVal[1] <= 0 || giaVal[1] == DanhMuc.BIG) {
            blankToGiaColor = 'red';
        }
        this.setState({ blankFromGiaColor: blankFromGiaColor, blankToGiaColor: blankToGiaColor });
        return giaVal[0] > 0 && (giaVal[1] > 0 && giaVal[1] != DanhMuc.BIG);
    }

    _validInputData() {
        let errors = '';

        if (!this.isValidPlace()) {
            errors += ' (khu vực)';
        }
        //
        // if (!this.isValidLoaiTin()) {
        //     errors += ' (loại nhà)';
        // }

        if (!this.isValidGia()) {
            errors += ' (giá)';
        }

        if (errors != '') {
            return 'Bạn chưa nhập thông tin' + errors + '!';
        }

        if (this.state.dateStart && this.state.dateEnd && this.state.dateStart.diff(this.state.dateEnd) > 0) {
            // Alert.alert("Thông báo", 'Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc', [{ text: 'Đóng', onPress: () => { } }]);
            // this.refs.toastTop && this.refs.toastTop.show('Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc', 3000);
            return 'Yêu cầu chọn ngày Bắt đầu trước ngày Kết thúc';
        }

        return null;
    }

    isUploading() {
        return this.props.group.creatingAgentWto;
    }

    onApply() {
        let { loaiTin } = this.state;
        let titleEvent = loaiTin === 'mua' ? 'Lưu tin cần mua' : 'Lưu tin cần thuê';
        this.onLogEvent(titleEvent);
        let msg = this._validInputData();
        if (msg) {
            this.refs.toastTop && this.refs.toastTop.show(msg, 3000);
            return;
        }

        let { dienTich, soTangSelectedIdx, soPhongNguSelectedIdx, soNhaTamSelectedIdx, huongNha,
            ghiChu, dateStart, dateEnd, ketNoiCungCau } = this.state;

        let { id, place } = this.props.group.agentWtoFields;

        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);

        // if (loaiTin == 'mua') {
        //     mua = this.state['mua'];
        // } else {
        //     thue = this.state['thue'];
        // }

        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        loaiNhaDatParent.gia = newGia;

        this.props.actions.onAgentWtoFieldChange('loaiTin', loaiTin);
        this.props.actions.onAgentWtoFieldChange(loaiTin, loaiNhaDatParent);

        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);

        this._doChangeGia(loaiTin, newGia);
        this.props.actions.onAgentWtoFieldChange("dienTich", newDienTich);
        this.props.actions.onAgentWtoFieldChange("soTangSelectedIdx", soTangSelectedIdx);
        this.props.actions.onAgentWtoFieldChange("soPhongNguSelectedIdx", soPhongNguSelectedIdx);
        this.props.actions.onAgentWtoFieldChange("soNhaTamSelectedIdx", soNhaTamSelectedIdx);
        this.props.actions.onAgentWtoFieldChange("huongNha", huongNha);
        this.props.actions.onAgentWtoFieldChange("ghiChu", ghiChu);

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let userID = currentUser.userID;

        let dto = {
            id: id,
            loaiTin: loaiTin,
            mua: loaiTin == 'mua' ? loaiNhaDatParent : undefined,
            thue: loaiTin != 'mua' ? loaiNhaDatParent : undefined,
            dienTich: newDienTich,
            soTangSelectedIdx: soTangSelectedIdx,
            soPhongNguSelectedIdx: soPhongNguSelectedIdx,
            soNhaTamSelectedIdx: soNhaTamSelectedIdx,
            huongNha: huongNha,
            place: place,
            ghiChu: ghiChu,
            userID: userID,
            dateStart: dateStart,
            dateEnd: dateEnd,
            ketNoiCungCau: ketNoiCungCau,
            priority: this.state.likeStatus,
            contactID: this.props.groupContact.contactOfWto ? this.props.groupContact.contactOfWto.contactID || this.props.groupContact.contactOfWto.id : ''
        };

        let wtoDto = this.convertWToFieldsToParams(dto)

        // console.log('payload to call saveAgentWto ************', wtoDto)
        this.props.actions.saveAgentWto(wtoDto, this.props.global.currentUser, token)
            .then(res => {

                let userID = this.props.global.currentUser.userID || undefined;
                let token = this.props.global.currentUser.token || undefined;

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);
                    this.props.actions.onPostAdsFieldChange('inboxType', 'wto');
                    setTimeout(() => {
                        this.props.actions.onGroupFieldChange('textSearchAds', '')
                    }
                        , 300);
                    // this.requeryWto();
                    // Actions.pop()
                    Actions.popTo('root');
                    Actions.NewAgentPost();
                    //refresh danh sach nhu cau;
                }
            });

    }

    onLogEvent(title) {
        let eventDto = {
            scene: "AgentWto",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID,
            customData: this.props.group.agentWtoFields.id ? {wtoID: this.props.group.agentWtoFields.id} : undefined
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    convertWToFieldsToParams(fields) {
        var { id, loaiTin, dienTich, soTangSelectedIdx, soPhongNguSelectedIdx, soNhaTamSelectedIdx,
            huongNha, place, ghiChu, userID, dateStart, dateEnd, ketNoiCungCau, priority, contactID
        } = fields;

        let loaiNhaDat = fields[loaiTin].loaiNhaDat;
        let gia = fields[loaiTin].gia;

        let giaRange = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;

        let giaTu = undefined;
        let giaDen = undefined;
        if (gia) {
            let giaVal = giaRange.toValRange(gia);
            giaTu = giaVal[0];
            giaDen = giaVal[1];
        }

        let dienTichTu = undefined;
        let dienTichDen = undefined;
        if (dienTich) {
            let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
            dienTichTu = dienTichVal[0];
            dienTichDen = dienTichVal[1];
        }

        let loaiTinVal = 'mua' === loaiTin ? 0 : 1;

        let textKhongDau = '';
        if (loaiNhaDat && loaiNhaDat.length > 0)
            textKhongDau += utils.getLoaiNhaDatText(loaiTin, loaiNhaDat) + ' '

        textKhongDau += place.fullName + ' '; //
        if (huongNha && huongNha.length > 0)
            textKhongDau += utils.getHuongNhaText2(huongNha) + ' '

        let donViTien = 0 === loaiTin ? "tỷ" : "triệu";
        if (giaTu)
            textKhongDau += String(this.state.fromGia) + ' ' + donViTien + ' '
        if (giaDen)
            textKhongDau += String(this.state.toGia) + ' ' + donViTien + ' '

        textKhongDau = utils.locDauV2(utils.standardlizeName(textKhongDau));

        let params = {
            'id': id || undefined,
            'userID': userID || undefined,
            'loaiTin': loaiTinVal,
            'dateStart': dateStart ? dateStart.format('YYYYMMDD') : undefined,
            'dateEnd': dateEnd ? dateEnd.format('YYYYMMDD') : undefined,
            'ketNoiCungCau': ketNoiCungCau,
            'priority': priority,
            'contactID': contactID,
            content: {
                'textKhongDau': textKhongDau,
                'loaiTin': loaiTinVal,
                'loaiNhaDat': loaiNhaDat || [0], //0 = bat ky
                'giaTu': giaTu || -1,
                'giaDen': giaDen || DanhMuc.BIG,
                'dienTichTu': dienTichTu || -1,
                'dienTichDen': dienTichDen || DanhMuc.BIG,
                'soTang': Number(DanhMuc.getSoTangByIndex(soTangSelectedIdx)) || undefined,
                'soPhongNgu': Number(DanhMuc.getSoPhongByIndex(soPhongNguSelectedIdx)) || undefined,
                'soPhongTam': Number(DanhMuc.getSoPhongTamByIndex(soNhaTamSelectedIdx)) || undefined,
                'place': place && Object.keys(place).length > 0 ? place : undefined,
                'huongNha': huongNha || [0], //0 = bat ky
                'ghiChu': ghiChu || undefined
            }
        };

        return params
    }

    _onArraySort(a, b) {
        if (a === '') {
            return 1;
        }
        if (b === '') {
            return -1;
        }
        return a - b;
    }

    onResetFilters(keepID) {
        let defaultMua = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
        this.props.actions.onAgentWtoFieldChange("mua", defaultMua);
        this.props.actions.onAgentWtoFieldChange("thue", defaultThue);
        this.props.actions.onAgentWtoFieldChange("soTangSelectedIdx", 0);
        this.props.actions.onAgentWtoFieldChange("soPhongNguSelectedIdx", 0);
        this.props.actions.onAgentWtoFieldChange("soNhaTamSelectedIdx", 0);
        this.props.actions.onAgentWtoFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
        this.props.actions.onAgentWtoFieldChange("huongNha", 0);
        this.props.actions.onAgentWtoFieldChange("place", {});
        this.props.actions.onAgentWtoFieldChange("ghiChu", '');
        this.props.actions.onAgentWtoFieldChange("contactID", '');

        let id = keepID ? this.props.group.agentWtoFields.id : null;
        this.props.actions.onAgentWtoFieldChange('id', id);

        this.setState({
            id: id, initGia: RangeUtils.BAT_KY_RANGE, initDienTich: RangeUtils.BAT_KY_RANGE,
            fromDienTich: '', toDienTich: '', fromGia: '', toGia: '', showGia: false, showDienTich: false,
            mua: defaultMua, thue: defaultThue, dienTich: RangeUtils.BAT_KY_RANGE,
            soTangSelectedIdx: 0, soPhongNguSelectedIdx: 0, soNhaTamSelectedIdx: 0, huongNha: 0, ghiChu: '',
            onCancelling: false
        });
    }

    _onPropertyTypesPressed() {
        let { loaiTin } = this.state;
        Actions.PropertyTypesWTo({
            owner: 'ContactNhuCau', func: 'search', loaiTin: loaiTin, loaiNhaDat: this.state[loaiTin].loaiNhaDat,
            onLoaiNhaDatChange: (loaiNhaDat) => this._onLoaiNhaDatChange(loaiNhaDat)
        });
    }

    _onLoaiNhaDatChange(loaiNhaDat) {
        let { loaiTin } = this.state;
        var loaiNhaDatParent = {};
        Object.assign(loaiNhaDatParent, this.state[loaiTin]);
        loaiNhaDatParent.loaiNhaDat = loaiNhaDat;
        if (loaiTin == 'mua') {
            this.setState({ mua: loaiNhaDatParent });
        } else {
            this.setState({ thue: loaiNhaDatParent });
        }

        setTimeout(() => { this._getSuggestAds(null, loaiNhaDatParent) }, 300)
    }

    _onHuongNhaPressed() {
        Actions.WToHuongNha({ huongNha: this.state.huongNha, onHuongNhaChange: (huongNha) => this._onHuongNhaChange(huongNha) });
    }

    _onHuongNhaChange(huongNha) {
        this.setState({ huongNha: huongNha });
        setTimeout(() => { this._getSuggestAds(null, null, huongNha) }, 300)
    }

    _onSoPhongNguChanged(index) {
        this.setState({ soPhongNguSelectedIdx: index });
        setTimeout(() => { this._getSuggestAds(null, null, null, index) }, 300)
    }

    _onSoTangChanged(index) {
        this.setState({ soTangSelectedIdx: index });
        setTimeout(() => { this._getSuggestAds(null, null, null, null, index) }, 300)
    }

    _onSoNhaTamChanged(index) {
        this.setState({ soNhaTamSelectedIdx: index });
        setTimeout(() => { this._getSuggestAds(null, null, null, null, null, index) }, 300)
    }

    _renderDienTich() {
        var { showDienTich } = this.state;
        var iconName = showDienTich ? "arrow-up" : "arrow-down";
        return (
            <Animated.View style={{ height: this.state.dienTichAnimation }} >
                <TouchableOpacity
                    onPress={this._toggleDienTichPicker.bind(this)}>
                    <View onLayout={this._setDienTichMinHeight.bind(this)}
                        style={styles.searchFilterAttribute}>
                        <Text style={styles.textSavePost}>
                            Diện tích
                        </Text>

                        <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                            <ScalableText style={styles.searchAttributeValue}>{this._getDienTichValue()} </ScalableText>
                            <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
                {this._renderDienTichPicker()}
            </Animated.View>
        );
        
    }

    _getDienTichValue() {
        let { dienTich } = this.state;
        let dienTichVal = RangeUtils.dienTichRange.toValRange(dienTich);
        dienTichVal.sort((a, b) => this._onArraySort(a, b));
        let newDienTich = RangeUtils.dienTichRange.rangeVal2Display(dienTichVal);
        return RangeUtils.getFromToDisplay(newDienTich, RangeUtils.dienTichRange.getUnitText());
    }


    _renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder, onTextChange, onTextFocus,
        pickerSelectedValue, onPickerValueChange, onPress, inputLabel, fromValue, toValue, unitText) {
        return (
            <PickerExt pickerRange={pickerRange} rangeStepValues={rangeStepValues} fromPlaceholder={fromPlaceholder}
                toPlaceholder={toPlaceholder} onTextChange={onTextChange} onTextFocus={onTextFocus}
                pickerSelectedValue={pickerSelectedValue} onPickerValueChange={onPickerValueChange}
                onPress={onPress} inputLabel={inputLabel} fromValue={fromValue} toValue={toValue}
                unitText={unitText} />
        );
    }

    _setDienTichMaxHeight(event) {
        this.setState({
            dienTichMaxHeight: event.nativeEvent.layout.height
        });
    }

    _setDienTichMinHeight(event) {
        this.setState({
            dienTichMinHeight: event.nativeEvent.layout.height
        });
    }

    _toggleDienTichPicker() {
        //Step 1
        let initialValue = this.state.showDienTich ? this.state.dienTichMaxHeight + this.state.dienTichMinHeight : this.state.dienTichMinHeight,
            finalValue = this.state.showDienTich ? this.state.dienTichMinHeight : this.state.dienTichMaxHeight + this.state.dienTichMinHeight;

        this.setState({
            showDienTich: !this.state.showDienTich  //Step 2
        });

        this.state.dienTichAnimation.setValue(initialValue);  //Step 3
        Animated.decay(     //Step 4
            this.state.dienTichAnimation,
            {
                toValue: finalValue
            }
        ).start();  //Step 5
    }

    _renderDienTichPicker() {
        var { showDienTich, initDienTich, fromDienTich, toDienTich } = this.state;
        if (showDienTich) {
            let rangeStepValues = RangeUtils.dienTichRange;
            let pickerRange = rangeStepValues.getAllRangeVal();
            let fromPlaceholder = 'Từ';
            let toPlaceholder = 'Đến';
            let onTextChange = this._onDienTichInputChange.bind(this);
            let onTextFocus = this._onScrollDienTich.bind(this);
            let dienTichRange = rangeStepValues.toValRange(initDienTich);
            let pickerSelectedValue = dienTichRange[0] + '_' + dienTichRange[1];
            let onPickerValueChange = this._onDienTichChanged.bind(this);
            return (
                <View onLayout={this._setDienTichMaxHeight.bind(this)}>
                    {this._renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder,
                        onTextChange, onTextFocus, pickerSelectedValue, onPickerValueChange,
                        this._toggleDienTichPicker.bind(this), "m²", String(fromDienTich), String(toDienTich),
                        rangeStepValues.getUnitText())}
                </View>
            );
        }
    }

    _onDienTichInputChange(index, val) {
        let { dienTich } = this.state;
        let newDienTich = [];
        Object.assign(newDienTich, dienTich);
        if (val === '') {
            val = -1;
        } else {
            val = utils.interestNumeric(val);
            if (utils.countDot(val, '\\.') >= 2) {
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!', DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (val === '.') {
            val = '0.';
        }
        newDienTich[index] = val;
        let other = newDienTich[1 - index];
        if (DanhMuc.CHUA_XAC_DINH == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            other = Number(other.substring(0, other.indexOf(" ")));
        } else {
            other = -1;
        }
        newDienTich[1 - index] = other;
        // newDienTich.sort((a, b) => a - b);

        let value = RangeUtils.dienTichRange.rangeVal2Display(newDienTich);

        let fromDienTich = newDienTich[0];
        let toDienTich = newDienTich[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.setState({ fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value });

        setTimeout(() => {
            this._getSuggestAds(null, null, null)
        }, 500)
    }

    _renderGia() {
        var { showGia } = this.state;
        var iconName = showGia ? "arrow-up" : "arrow-down";
        return (
            <Animated.View style={{ height: this.state.giaAnimation }} >
                <TouchableOpacity
                    onPress={this._toggleGiaPicker.bind(this)}>
                    <View onLayout={this._setGiaMinHeight.bind(this)}
                        style={styles.searchFilterAttribute}>
                        <Text style={styles.textSavePost}>
                            Mức giá
                        </Text>

                        <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                            <ScalableText style={styles.searchAttributeValue}> {this._getGiaValue()} </ScalableText>
                            <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
                {this._renderGiaPicker()}
            </Animated.View>
        );        
    }

    _getGiaValue() {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = giaStepValues.toValRange(gia);
        giaVal.sort((a, b) => this._onArraySort(a, b));
        let newGia = giaStepValues.rangeVal2Display(giaVal);
        return RangeUtils.getFromToDisplay(newGia, giaStepValues.getUnitText());
    }

    _setGiaMaxHeight(event) {
        this.setState({
            giaMaxHeight: event.nativeEvent.layout.height
        });
    }

    _setGiaMinHeight(event) {
        this.setState({
            giaMinHeight: event.nativeEvent.layout.height
        });
    }

    _toggleGiaPicker() {
        //Step 1
        let initialValue = this.state.showGia ? this.state.giaMaxHeight + this.state.giaMinHeight : this.state.giaMinHeight,
            finalValue = this.state.showGia ? this.state.giaMinHeight : this.state.giaMaxHeight + this.state.giaMinHeight;

        this.setState({
            showGia: !this.state.showGia  //Step 2
        });

        this.state.giaAnimation.setValue(initialValue);  //Step 3
        Animated.decay(     //Step 4
            this.state.giaAnimation,
            {
                toValue: finalValue
            }
        ).start();  //Step 5
    }

    _renderGiaPicker() {
        var { loaiTin, showGia, initGia, fromGia, toGia, blankFromGiaColor, blankToGiaColor } = this.state;
        if (showGia) {
            var rangeStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
            let pickerRange = rangeStepValues.getAllRangeVal();
            let fromPlaceholder = 'Từ';
            let toPlaceholder = 'Đến';
            let onTextChange = this._onGiaInputChange.bind(this);
            let onTextFocus = this._onScrollGia.bind(this);
            let giaRange = rangeStepValues.toValRange(initGia);
            let pickerSelectedValue = giaRange[0] + '_' + giaRange[1];
            let onPickerValueChange = this._onGiaChanged.bind(this);
            let inputLabel = 'mua' === loaiTin ? "tỷ" : "triệu";
            return (
                <View onLayout={this._setGiaMaxHeight.bind(this)}>
                    {this._renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder,
                        onTextChange, onTextFocus, pickerSelectedValue, onPickerValueChange,
                        this._toggleGiaPicker.bind(this), inputLabel, String(fromGia), String(toGia),
                        rangeStepValues.getUnitText())}
                </View>
            );
        }
    }

    _onGiaChanged(pickedValue) {
        let { loaiTin } = this.state;
        let giaStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let giaVal = pickedValue.split('_');
        let value = giaStepValues.rangeVal2Display(giaVal);
        this._doChangeGia(loaiTin, value);
        var initGia = [];
        Object.assign(initGia, value);
        let fromGia = giaVal[0];
        let toGia = giaVal[1];
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        this.setState({ initGia: initGia, fromGia: fromGia, toGia: toGia });

        setTimeout(() => {
            this._getSuggestAds(null, null, null)
        }, 500)
    }

    _onGiaInputChange(index, val) {
        let { loaiTin } = this.state;
        let gia = this.state[loaiTin].gia;
        let rangeStepValues = 'mua' === loaiTin ? RangeUtils.sellPriceRange : RangeUtils.rentPriceRange;
        let newGia = [];
        let newVal = val;
        Object.assign(newGia, gia);
        if (newVal === '') {
            newVal = -1;
        } else {
            newVal = utils.interestNumeric(newVal);
            val = newVal;
            if (utils.countDot(newVal, '\\.') >= 2) {
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!', DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (newVal === '.') {
            newVal = '0.';
        }
        // let hasLastDot = newVal[newVal.length-1] === '.';
        if ('mua' === loaiTin && newVal != -1) {
            newVal = 1000 * newVal;
        }
        // newGia[index] = hasLastDot && 'mua' === loaiTin ? newVal + '.' : newVal;
        newGia[index] = newVal;
        let other = String(newGia[1 - index]);
        if (DanhMuc.THOA_THUAN == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            if (other.indexOf("tỷ") != -1) {
                other = 1000 * Number(other.substring(0, other.indexOf(" ")));
            } else {
                other = Number(other.substring(0, other.indexOf(" ")));
            }
        } else {
            other = -1;
        }
        newGia[1 - index] = other;

        let value = rangeStepValues.rangeVal2Display(newGia);
        this._doChangeGia(loaiTin, value);
        let fromGia = newGia[0];
        let toGia = newGia[1];
        // hasLastDot = fromGia[fromGia.length-1] === '.';
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('mua' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        // fromGia = hasLastDot && 'mua' === loaiTin ? fromGia + '.' : fromGia;
        // hasLastDot = toGia[toGia.length-1] === '.';
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('mua' === loaiTin) {
            toGia = toGia / 1000;
        }
        // toGia = hasLastDot && 'mua' === loaiTin ? toGia + '.' : toGia;
        if (index == 0) {
            this.setState({ fromGia: val, toGia: toGia });
        } else {
            this.setState({ fromGia: fromGia, toGia: val });
        }

        setTimeout(() => {
            this._getSuggestAds(null, null, null)
        }, 500)
    }

    _renderSoPhongNgu() {
        if (this.showSoPhongNgu()) {
            return this._renderSegment("Số phòng ngủ", DanhMuc.getSoPhongNguValues(),
                this.state["soPhongNguSelectedIdx"], this._onSoPhongNguChanged.bind(this));
        } else if (0 != this.state.soPhongNguSelectedIdx) {
            this.setState({ soPhongNguSelectedIdx: 0 });
        }
        return null;
    }

    _renderSoTang() {
        if (this.showSoTang()) {
            return this._renderSegment("Số tầng", DanhMuc.getSoTangValues(),
                this.state["soTangSelectedIdx"], this._onSoTangChanged.bind(this));
        } else if (0 != this.state.soTangSelectedIdx) {
            this.setState({ soTangSelectedIdx: 0 });
        }
        return null;
    }

    _renderSoNhaTam() {
        if (this.showSoNhaTam()) {
            return this._renderSegment("Số nhà tắm", DanhMuc.getSoPhongTamValues(),
                this.state["soNhaTamSelectedIdx"], this._onSoNhaTamChanged.bind(this));
        } else if (0 != this.state.soNhaTamSelectedIdx) {
            this.setState({ soNhaTamSelectedIdx: 0 });
        }
        return null;
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                onChange={onChange} disabled={this.isUploading()} />
        );
    }

    _renderHuongNha() {
        return (
            <TouchableOpacity
                disabled={this.isUploading()}
                onPress={() => this._onHuongNhaPressed()}>
                <View style={styles.searchFilterAttributeExt3}>
                    <Text style={styles.textSavePost}>
                        Hướng nhà
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                        <ScalableText style={styles.searchAttributeValue}> {this._getHuongNhaValue()} </ScalableText>
                        <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    showSoPhongNgu() {
        var { loaiTin } = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        // arr1.some(r=> arr2.indexOf(r) >= 0)
        if (loaiNhaDat && [1, 2, 3, 4].some(r => loaiNhaDat.indexOf(r) >= 0)) {
            return true;
        } else {
            return false;
        }
    }

    showSoTang() {
        var { loaiTin } = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if ((loaiNhaDat && [2, 3, 4].some(r => loaiNhaDat.indexOf(r) >= 0) && loaiTin == 'mua')
            || (loaiNhaDat && [2, 3, 4, 5, 6].some(r => loaiNhaDat.indexOf(r) >= 0) && loaiTin == 'thue')
        ) {
            return true;
        } else {
            return false;
        }
    }

    showSoNhaTam() {
        var { loaiTin } = this.state;
        var loaiNhaDat = this.state[loaiTin].loaiNhaDat;
        if (loaiNhaDat && [1, 2, 3, 4].some(r => loaiNhaDat.indexOf(r) >= 0)) {
            return true;
        } else {
            return false;
        }
    }

    showBanKinhTimKiem() {
        // let {center} = this.props.search.form.fields;
        // return center && !isNaN(center.lat);
        return false;
    }
}

/**
 * ## Styles
 */
const styles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        width: width,
        height: 64
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchButtonText2: {
        margin: 0,
        padding: 11,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreFilterButton: {
        flexGrow: 0.5,
        alignItems: 'stretch',
        justifyContent: 'center'
    },
    searchMoreSeparator: {
        backgroundColor: '#F6F6F6'
    },
    searchResetText: {
        color: 'red',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    searchMoreText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainColor
    },
    searchAttributeLabel: {
        fontSize: gui.normalFontGroup,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    searchAttributeValue: {
        fontSize: gui.normalFontGroup,
        fontFamily: gui.fontFamily,
        color: gui.arrowColor,
        marginRight: 3
    },
    searchFilterButton: {
        height: 88,
        width: width

    },
    searchFilter: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0
    },
    searchFilterDetail: {
        flexGrow: 0,
        flexDirection: "column"
        //borderWidth:1,
        //borderColor: "green"
    },
    scrollView: {
        flex: 1,
        height: height - 65
    },
    scrollView2: {
        flex: 1
    },
    cacDieuKienText: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#555555',
        justifyContent: 'space-between',
        padding: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttribute: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'space-between',
        paddingTop: 10,
        paddingLeft: 0,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    // searchFilterAttribute2: {
    //   flexDirection : "row",
    //   borderWidth:1,
    //   borderColor: "red",
    //   justifyContent :'space-between',
    //   paddingRight: 8,
    //   paddingTop: 5,
    //   paddingLeft: 17,
    //   paddingBottom: 7,
    //   borderTopWidth: 0,
    //   borderTopColor: gui.separatorLine
    // },
    searchFilterAttribute3: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'space-between',
        paddingTop: 10,
        paddingLeft: 17,
        paddingRight: 13,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchFilterAttributeExt: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'space-between',
        paddingTop: 12,
        paddingLeft: 0,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        marginLeft: 17,
        borderTopColor: gui.separatorLine
    },
    // searchFilterAttributeExt2: {
    //   flexDirection : "row",
    //   borderWidth:1,
    //   borderColor: "red",
    //   justifyContent :'space-between',
    //   paddingRight: 10,
    //   paddingTop: 5,
    //   paddingLeft: 0,
    //   paddingBottom: 8,
    //   borderTopWidth: 0,
    //   marginLeft: 17,
    //   borderTopColor: gui.separatorLine
    // },
    searchFilterAttributeExt3: {
        flexDirection: "row",
        //borderWidth:1,
        //borderColor: "red",
        justifyContent: 'space-between',
        paddingTop: 12,
        paddingLeft: 17,
        paddingRight: 19,
        paddingBottom: 10,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    searchMoreFilterAttribute: {
        padding: 10,
        paddingBottom: 11,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    // ngayDaDangItem: {
    //   fontSize: gui.normalFontSize,
    //   fontFamily: gui.fontFamily
    // },
    addViewBottom: {
        height: 30,
        width: width,
        backgroundColor: '#fff'
    },
    backButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewRightHeader: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 64,
        width: 64
    },
    viewTitleHeader: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textHeader: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        color: gui.mainAgentColor,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    searchDiaChinhView: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    diaChinhSubView: {
        justifyContent: 'center',
        alignItems: 'center',
        height: 60,
        width: width,
        backgroundColor: '#fff'
    },
    diaChinhTouchable: {
        height: 44,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderRadius: 5,
        width: width - 32,
        borderWidth: 1,
        borderColor: gui.groupBackground,
        shadowColor: '#000',
        shadowOffset: { width: 1, height: 1 },
        elevation: 1,
        shadowOpacity: 0.15,
        shadowRadius: 2,
    },
    viewTextKhuVuc: {
        width: width - 32 - 40,
    },
    diaChinhText: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    locationIcon: {
        backgroundColor: 'white',
        height: 25,
        width: 30,
        marginRight: 4,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        textAlign: 'left',
        width: width - 30,
        height: 60
    },
    textInputView: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width
    },
    textInputView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width / 3 - 5,
        marginTop: 10,
        marginBottom: 10
    },
    input: {
        fontSize: gui.normalFontGroup,
        fontFamily: gui.fontFamily,
        height: 28,
        width: width / 3 - 5,
        textAlign: 'center',
        alignSelf: 'center',
        backgroundColor: 'white'
    },
    label: {
        fontSize: gui.normalFontGroup,
        fontFamily: gui.fontFamily,
        marginLeft: 10
    },
    loadingContent: {
        position: 'absolute',
        top: -23,
        left: width / 2 - 19,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    lineSuggest: {
        width: width,
        height: 8,
        backgroundColor: gui.newLineFacebook
    },
    searchSectionTitle: {
        justifyContent: 'center',
        paddingLeft: 16,
        backgroundColor: '#F8F8F8',
        height: 32
    },
    viewTabInterest: {
        flexGrow: 1,
        flexDirection: 'row',
        width: width - 32,
        height: 30,
        marginVertical: 7,
        marginLeft: 16,
    },
    abStyle: {
        height: 30,
        width: (width - 52) / 3,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderRadius: 15,
        marginLeft: 10,
        backgroundColor: '#fff',
        borderColor: 'rgba(54,54,54,1)',
    },
    mainViewSelected1: {
        flexGrow: 1,
        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: 'rgba(255,81,81,1)',
        borderColor: 'rgba(255,81,81,1)',
    },
    mainViewSelected2: {
        flexGrow: 1,
        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: 'rgba(255,207,86,1)',
        borderColor: 'rgba(255,207,86,1)',
    },
    mainViewSelected3: {
        flexGrow: 1,
        flexDirection: 'column',
        borderWidth: 1,
        backgroundColor: 'rgba(169,183,200,1)',
        borderColor: 'rgba(169,183,200,1)',
    },
    viewEachInfo: {
        height: 44,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    viewKieuNha: {
        height: 44,
        width: width - 32,
        flexDirection: 'row',
        // marginTop: 13,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textSavePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textAgentSolid
    },
    touchKieuNha: {
        position: 'absolute',
        right: 8,
    },
    lineStyle: {
        marginLeft: 0,
        marginRight: 0,
        width: width - 32
    },
    tabStyle: {
        height: 30,
        width: (width - 52) / 3,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderRadius: 15,
        marginLeft: 10,
        backgroundColor: '#fff',
        borderColor: 'rgba(54,54,54,1)',
    },
    viewLine: {
        height: 18,
        width: width
    },
    viewButtonBottom: {
        // position: 'absolute',
        // bottom: 4,
        // top: height - 52,
        height: 49,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff'
    },
    searchButton: {
        height: 40,
        borderRadius: 20,
        width: 158,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainAgentColor,
    },
    viewSubLabel: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    bottomLine: {
        position: 'absolute',
        top: 0
    },
    viewShareAds: {
        width: width - 16,
        marginLeft: 8,
        marginRight: 8,
        height: 102,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewModalShareAds: {
        height: 102,
        width: width,
        backgroundColor: 'transparent'
    },
    viewShareTopContent: {
        width: width - 16,
        height: 44,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 12,
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        backgroundColor: '#fff'
    },
    viewShareBottomContent: {
        width: width - 16,
        height: 44,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 12,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
        backgroundColor: '#fff'
    },
    lineStyles: {
        width: width - 16,
        height: 1,
        backgroundColor: 'rgba(211,211,211,0.5)'
    },
    viewTriangle: {
        width: 0,
        height: 0,
        borderLeftWidth: 6,
        borderRightWidth: 6,
        borderBottomWidth: 12,
        borderStyle: 'solid',
        backgroundColor: 'transparent',
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderBottomColor: '#fff'
    },
    checkAds: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        marginLeft: 0
    },
    viewSaleState: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        paddingTop: 12
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewTextPreview: {
        height: 49,
        width: width / 2,
        paddingLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPostWtoButton: {
        height: 49,
        width: width / 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textPreview: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainAgentColor
    },
    khachHangText: {
        color: 'rgba(56,151,241,1)',
        fontWeight: '500'
    },
    viewButtons: {
        flex: 1,
        flexDirection: 'row',
        paddingLeft: 5,
        paddingRight: 5,
        height: 50,
        width: width,
        marginVertical: 5
    },
    viewTextTitle: {
        height: 32,
        width: width,
        justifyContent: 'flex-end',
        paddingLeft: 16,
        marginBottom: 5
    },
    viewAdsSuggest: {
        width: width,
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewNumberAdsSuggest: {
        height: 48,
        width: width / 2,
        paddingLeft: 16,
        justifyContent: 'center'
    },
    viewNumberAdsSuggestRight: {
        height: 48,
        width: width / 2,
        paddingRight: 16,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    viewAdsSuggestContent: {
        width: width,
        height: 96,
        backgroundColor: '#fff'
    },
    viewNewDetailPost: {
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width - 52,
        marginLeft: 16,
        borderWidth: 1,
        borderColor: 'rgba(211,211,211,0.5)',
        paddingLeft: 16,
        paddingRight: 8,
        paddingVertical: 10,
        position: 'relative'
    },
    viewPercentDraft: {
        height: 20,
        width: 'auto',
        marginTop: 5,
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        fontWeight: '500',
        color: gui.textPostAds,
    },
    viewLabel: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        width: width - 54 - 24,
        height: 20,
        backgroundColor: '#fff'
    },
    textDatePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.textShare,
        marginLeft: 4
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.textPostCommon,
        marginLeft: 0
    },
    imagePost: {
        height: 48,
        width: 48,
        position: 'absolute',
        top: 8,
        right: 8
    },
    listSource: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        marginBottom: 6
    },
    viewInfoMatching: {
        height: 'auto',
        width: 20,
        marginRight: 5,
        justifyContent: 'center',
        alignItems: 'center'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(AgentWto);
