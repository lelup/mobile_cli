import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    FlatList,
    RefreshControl
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Iconicons from 'react-native-vector-icons/Ionicons';
import { Actions } from 'react-native-router-flux';
import OfflineBar from '../line/OfflineBar';
import Communications from '../detail/MCommunications';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import DanhMuc from '../../assets/DanhMuc';
import GiftedSpinner from "../GiftedSpinner";
import moment from 'moment'
import TruliaIcon from '../TruliaIcon';
import Toast, { DURATION } from '../toast/Toast';
import userApi from '../../lib/userApi';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as eventActions from '../../reducers/event/eventActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';

import CallDetectorManager from 'react-native-call-detection'

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions,
    eventActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var callDetector = undefined

class CalendarEvent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            laoding: false,
            searchText: '',
            phanLoai: props.event.selectedEventTab,
            isOpenMoreCalendarModal: props.isOpenMoreCalendarModal,
            selectedEvent: props.selectedEvent,
            isOpenModalDoUuTien: false,
            doUuTien: props.group.doUuTienKey,
            eventList: props.event.eventList,
            isListening: false,
            callControl: 'none',
            callTimeControl: null,
        }
    }

    componentWillMount() {
        let currentUser = this.props.global.currentUser;
            // this.props.actions.getAllCalendarEvent(
            //     {
            //         'userID': currentUser.userID,
            //         'startDateTimeFrom': this.props.event.startDateTimeFrom,
            //         'startDateTimeTo': this.props.event.startDateTimeTo
            //     }
            //     , (res) => {
            //         //this.props.actions.onGroupFieldChange('selectedEventTab', 'all');
            //         log.info('=============> res', res)
            //     }
            //     , (error) => {
            //         console.log('server respond data: =====>>>>>', error)
            //     });
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.event.selectedEventTab !== nextProps.event.selectedEventTab) {
            this.setState({ phanLoai: nextProps.event.selectedEventTab });
        }
        if (this.props.event.eventList !== nextProps.event.eventList) {
            this.setState({ eventList: nextProps.event.eventList });
        }
        // if (this.props.event.selectedEvent !== nextProps.event.selectedEvent) {
        //     this.setState({ selectedEvent: nextProps.event.selectedEvent });
        // }
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeader()}

                {this._renderRowView()}
                {this._renderLoadingView()}
                {/* {this._renderDoUuTienModal()} */}
                {this._openMoreModal()}

                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        );
    }

    _renderHeader() {
        let doUuTienValue = this._getDoUuTienValue();
        return (
            <View style={styles.headerView}>
                <View style={styles.subHeader}>

                    <TouchableOpacity style={styles.viewBackIcon}
                        onPress={this._onBackButton.bind(this)}>
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                    </TouchableOpacity>

                    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={[styles.headerText]}>Công việc</Text>
                    </View>

                    <TouchableOpacity style={{ width: 64, height: 25, justifyContent: 'center', alignItems: 'flex-end' }}
                        onPress={this._onAddGroup.bind(this)}>

                        <View style={{ justifyContent: 'center', alignItems: 'flex-end' }}>
                            <MaterialCommunityIcons name="plus" size={26} color={gui.mainColor} />
                        </View>

                    </TouchableOpacity>
                </View>

                {/*<View style={styles.tabHeader}>*/}
                {/*<View style={styles.tabbar}>*/}
                {/*<GroupLikeTabButton name={'todo'}*/}
                {/*onPress={this._onTabChange.bind(this)}*/}
                {/*selected={this.state.phanLoai == 'todo'}>CHƯA XONG</GroupLikeTabButton>*/}
                {/*<GroupLikeTabButton name={'done'}*/}
                {/*onPress={this._onTabChange.bind(this)}*/}
                {/*selected={this.state.phanLoai === 'done'}>ĐÃ XONG</GroupLikeTabButton>*/}
                {/*<GroupLikeTabButton name={'all'}*/}
                {/*onPress={this._onTabChange.bind(this)}*/}
                {/*selected={this.state.phanLoai == 'all'}>TẤT CẢ</GroupLikeTabButton>*/}
                {/*</View>*/}

                {/*<TouchableOpacity*/}
                {/*style={styles.touchSortContent}*/}
                {/*onPress={this._onModalDoUuTien.bind(this)}*/}
                {/*>*/}
                {/*<Text style={[styles.tabHeaderText]}>{doUuTienValue}</Text>*/}
                {/*<View style={styles.viewSortIcon}>*/}
                {/*<Icon name="sort-desc" size={14} color={gui.mainTextColor} />*/}
                {/*</View>*/}
                {/*</TouchableOpacity>*/}
                {/*</View>*/}
                {/*<TouchableOpacity style={styles.touchFilterEvent}>*/}
                {/*/!*onPress={this._onAddFilterEvent.bind(this)}>*!/*/}
                {/*<Text style={styles.viewTextSort}>Lọc</Text>*/}
                {/*</TouchableOpacity>*/}
            </View>
        );

    }

    _onAddFilterEvent() {
        Actions.EventFilter();
    }

    _getDoUuTienValue() {
        let { doUuTien } = this.state;
        let doUuTienValue = DanhMuc.getDoUuTienTypeValue(doUuTien);
        return doUuTienValue ? doUuTienValue.toUpperCase() : 'TẤT CẢ';
    }

    _onModalDoUuTien() {
        this.setState({
            isOpenModalDoUuTien: true
        })
    }

    _onBackButton() {
        // Actions.pop();
        let userInfo = { deviceID: this.props.global.currentUser.deviceID, userID: this.props.global.currentUser.userID };

        // this.props.actions.getAllCalendarEvent(
        //     { 'userID': this.props.global.currentUser.userID }
        //     , (res) => {
        //         console.log('server respond data: =====>>>>>', res)
        //     }
        //     , (error) => {
        //         console.log('server respond data: =====>>>>>', error)
        //     });

        // if (!this.props.loadingAgentHomeData) {
        //     this.props.actions.loadAgentHomeData(
        //         () => { },
        //         (error) => log.info(error),
        //         userInfo
        //     );
        // }        
        Actions.pop();
    }

    _onAddGroup() {
        this.onLogEvent();
        this._onRefreshNewEvent();

        this._onSaveInitialEvent();

        Actions.MyTodoNotes({owner: 'CalendarEvent'});
    }

    onLogEvent() {
        let eventDto = {                                    
                scene: "CalendarEvent",  
                parentScene: this.props.owner,  //truyen owner neu co            
                componentType: "button",
                component: "Thêm công việc",
                sessionID: this.props.global.currentUser.token,
                userID: this.props.global.currentUser.userID              
        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
                .then(function (json) {                    
                    return json;
                });
    }

    _onRefreshNewEvent() {
        this.props.actions.onEventFieldChange('eventID', null);
        this.props.actions.onEventFieldChange('eventName', '');
        this.props.actions.onGroupContactFieldChange('personContact', null);
        this.props.actions.onEventFieldChange('eventStartDate', moment(new Date()).toISOString());
        this.props.actions.onEventFieldChange('eventEndDate', moment(new Date()).toISOString());
        this.props.actions.onEventFieldChange('eventAllDay', false);
        this.props.actions.onEventFieldChange('eventRepeat', false);
        this.props.actions.onEventFieldChange('eventAlarm', true);
        this.props.actions.onEventFieldChange('eventStatus', 1);
        this.props.actions.onEventFieldChange('eventLevel', 1);//normal
        this.props.actions.onEventFieldChange('eventType', '');//normal
        this.props.actions.onEventFieldChange('eventAds', null)
        this.props.actions.onEventFieldChange('eventIDInDevice', null);
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreCalendarModal: false
        });
        // this.props.actions.onGroupFieldChange('isOpenMoreCalendarModal', false)
    }

    _openMoreModal() {
        let { selectedEvent } = this.state;
        return (
            <Modal isOpen={this.state.isOpenMoreCalendarModal}
                onClosed={this._outMoreModal.bind(this)}
                style={styles.viewModalStyle}
                position={"bottom"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderPopupTodo(selectedEvent)}
            </Modal>
        );

    }

    _renderDoUuTienModal() {
        return (
            <Modal isOpen={this.state.isOpenModalDoUuTien}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewDoUuTienStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
                animationDuration={200}
            >
                {this._renderDoUuTienContent()}
            </Modal>
        );
    }

    _renderDoUuTienContent() {
        let allDoUuTien = [];
        allDoUuTien.push('Tất cả');
        DanhMuc.findDoUuTienValues().forEach((one) => {
            allDoUuTien.push(one);
        });
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalSapxep, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>ĐỘ ƯU TIÊN</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {
                    allDoUuTien.map((e, index) => {
                        let { doUuTien } = this.state;
                        let orderDoUuTien = DanhMuc.DoUuTienType[doUuTien];
                        let checked = (e == orderDoUuTien) || (e == 'Tất cả' && orderDoUuTien == undefined);
                        let borderTopWidth = index == 0 ? 0 : 1;
                        return (
                            <TouchableOpacity style={[styles.touchModalSapxep, { borderTopWidth: borderTopWidth }]}
                                key={e}
                                onPress={() => { this._onTabDoUuTienChange(e) }}>
                                <Text style={styles.textSapxep}>{e}</Text>
                                <View style={styles.viewTickSapxep}>
                                    {
                                        checked ?
                                            <TruliaIcon
                                                name="check" color={gui.mainColor} size={20}
                                                mainProps={styles.viewCheckIcon}
                                            /> : null
                                    }

                                </View>
                            </TouchableOpacity>
                        )
                    })
                }

            </View>
        )
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );

    }

    _onTabDoUuTienChange(value) {

        let doUuTienPress = (value == DanhMuc.doUuTien[0]) ? 'high' : (value == DanhMuc.doUuTien[1]) ? 'medium' : (value == DanhMuc.doUuTien[2]) ? 'low' : undefined;

        let { doUuTien } = this.state;

        if (doUuTien == doUuTienPress) {
            this.setState({
                isOpenModalDoUuTien: false
            });
            return;
        }
        let newDoUuTien = (value == DanhMuc.doUuTien[0]) ? 'high' : (value == DanhMuc.doUuTien[1]) ? 'medium' : (value == DanhMuc.doUuTien[2]) ? 'low' : undefined;
        this.props.actions.onGroupFieldChange('doUuTienKey', newDoUuTien);
        this.setState({
            isOpenModalDoUuTien: false,
            doUuTien: newDoUuTien
        });
        // this.props.actions.onEventFieldChange('eventList', [])
        this.props.actions.getAllCalendarEvent(
            {
                'userID': this.props.global.currentUser.userID,
                'startDateTimeFrom': this.props.event.startDateTimeFrom,
                'startDateTimeTo': this.props.event.startDateTimeTo
            }
            , (res) => {
            }
            , (error) => {
                console.log('server respond data: =====>>>>>', error)
            });
    }

    _onContentModal() {
        this.setState({
            isOpenModalDoUuTien: false,
            isOpenMoreCalendarModal: false
        });
        // this.props.actions.onGroupFieldChange('isOpenMoreCalendarModal', false)
    }


    _renderPopupTodo(data) {
        if (!data) {
            return (
                <View style={styles.viewContentPopup}>
                </View>
            )
        }
        if (data.contactName)
            return (
                <View style={styles.viewContentPopup}>
                    {this._renderTodoTitle(data)}
                    <FullLine style={{ marginLeft: 16, marginRight: 16 }} />
                    {this._renderNameContact(data)}
                    <FullLine style={{ marginLeft: 16, marginRight: 16 }} />
                    {this._renderAds(data)}
                    <FullLine />
                    {this._renderAddNote(data)}
                </View>
            )
        else
            return (
                <View style={styles.viewContentPopup}>
                    {this._renderTodoTitle(data)}
                    <FullLine style={{ marginLeft: 16, marginRight: 16 }} />
                    <Text style={[styles.textRelated, { alignSelf: 'center' }]}>Không có người liên quan</Text>
                </View>
            )
    }

    _renderAddNote(data) {
        let textAddNote = 'Cập nhật phản hồi từ khách';
        if (data.adsID)
            return (
                <TouchableOpacity onPress={this._onViewPhanHoi.bind(this, data)} style={styles.viewAddNote}>
                    <MaterialCommunityIcons name={"plus"} color={gui.mainAgentColor} size={14} />
                    <Text style={[styles.viewTextSort, { fontSize: 12, marginLeft: 5 }]}>{textAddNote}</Text>
                </TouchableOpacity>

            )
        else return null;
    }

    _onViewPhanHoi(selectedEvent) {
        this.props.actions.onGroupContactFieldChange('contactRespondList', [])
        this.props.actions.getContactRespondByEvent(
            {
                'userID': this.props.global.currentUser.userID,
                'eventID': selectedEvent.id
            }
            , (res) => {
                // console.log('getContactRespondByEvent : server respond res: =====>>>>>', res)
                // Actions.ContactAdsViewed({owner: 'CalendarEvent', selectedEvent: selectedEvent})
                let respondData = null;
                if (res.status == 0) {
                    respondData = res.data.find((one) => {
                        return one.contactID == selectedEvent.contactID
                            && one.adsID == selectedEvent.adsID;
                    });
                }
                this._onThemPhanHoi(selectedEvent, respondData);
            }
            , (error) => {
                // console.log('getContactRespondByEvent : server respond error: =====>>>>>', error)
                // Actions.ContactAdsViewed({owner: 'CalendarEvent', selectedEvent: selectedEvent})
                this._onThemPhanHoi(selectedEvent);
            });
    }

    _onThemPhanHoi(selectedEvent, respondData) {
        let personContactDto = {
            contactID: selectedEvent.contactID,
            contactName: selectedEvent.contactName,
            contactPhone: selectedEvent.contactPhone,
            contactAvatar: selectedEvent.contactAvatar,
            contactSaleState: selectedEvent.contactSaleState
        }

        let soPhongNgu = undefined;
        let soPhongTam = undefined;
        let likeStatus = '';
        let contactRespondComment = '';
        let contactRespondID = null;

        if (respondData) {
            soPhongNgu = respondData.soPhongNgu;
            soPhongTam = respondData.soPhongTam;
            likeStatus = respondData.likeStatus;
            contactRespondComment = respondData.comment;
            contactRespondID = respondData.id;
        }

        let adsDto = {
            adsID: selectedEvent.adsID,
            image: selectedEvent.image,
            diaChi: selectedEvent.diaChi,
            gia: selectedEvent.gia,
            dienTich: selectedEvent.dienTich,
            loaiTin: selectedEvent.loaiTin,
            title: selectedEvent.adsTitle || selectedEvent.diaChi,
            soPhongNgu: soPhongNgu,
            soPhongTam: soPhongTam
        }

        this.props.actions.onGroupContactFieldChange('contactRespondAds', adsDto)
        this.props.actions.onGroupContactFieldChange('contactOfRespond', personContactDto)
        this.props.actions.onGroupContactFieldChange('likeStatus', likeStatus)
        this.props.actions.onGroupContactFieldChange('contactRespondComment', contactRespondComment)
        this.props.actions.onGroupContactFieldChange('contactRespondID', contactRespondID)
        this.props.actions.onGroupContactFieldChange('contactRespondEventID', selectedEvent.id)

        Actions.ContactRespond({ owner: 'CalendarEvent', selectedEvent: selectedEvent, disableAdsPicker: !!selectedEvent.adsID });
    }

    _renderTodoTitle(data) {
        let textModify = 'Sửa';
        let textContent = data.title || '';
        let dateTodo = utils.showChatTime(data.startDate);
        let dotColor = this._getLevelColor(data.level);
        return (
            <View style={styles.viewTodoTitle}>
                <View style={styles.viewDotTodo}>
                    <View style={[styles.dotStyle, { backgroundColor: dotColor }]} />
                </View>
                <View style={styles.viewTodoContent}>
                    <Text numberOfLines={2} style={[styles.textModify, { fontWeight: '500' }]}>{textContent}</Text>
                    <Text style={styles.textDate}>{dateTodo}</Text>
                </View>
                <View style={styles.viewModifyTodo}>
                    {data.status != 2 ?
                        (<TouchableOpacity onPress={this._onMarkEventIsDonePress.bind(this)}>
                            <Iconicons name={"md-checkmark"} color={'green'} size={22} />
                        </TouchableOpacity>) : <View></View>
                    }
                    <TouchableOpacity onPress={this._onEditEventPress.bind(this)}>
                        <Text style={styles.textModify}>{textModify}</Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _renderNameContact(data) {
        let myAvatar = data.contactAvatar;
        // if(!myAvatar) {
        //     return(
        //     <View style={styles.viewNameContact}>
        //     </View>
        //     )
        // }
        let uriAvatar = { uri: myAvatar };
        let defaultSource = require('../../assets/image/register_avatar_icon.png');
        let nameUserContact = data.contactName;
        let phoneNumber = data.contactPhone || '';
        let textMessage = 'Nhắn tin';
        return (
            <View style={styles.viewNameContact}>
                <View style={styles.avatarContact}>
                    <Image
                        source={uriAvatar}
                        style={styles.avatarImage}
                        defaultSource={defaultSource}
                    />
                    <View style={{ alignItems: 'flex-start' }}>
                        <Text numberOfLines={1} style={styles.textUserContact}>{nameUserContact}</Text>
                        <Text style={[styles.textMessage, { fontSize: 12, marginLeft: 22, marginTop: 3 }]}>{phoneNumber}</Text>
                    </View>
                </View>
                <View style={{
                    height: 96, width: width / 2, flexDirection: 'row', paddingLeft: 16, alignItems: 'center', justifyContent: 'flex-end'
                }}>
                    <TouchableOpacity style={styles.messageContact}
                        onPress={this._onSmsNumber.bind(this, data)}
                    >
                        <Icon name={"comments-o"} color={gui.mainTextColor} size={22} />
                        {/* <Text style={[styles.textMessage, {marginLeft: 10}]}>{textMessage}</Text> */}
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.viewPhoneContact}
                        onPress={this._onPhoneCall.bind(this, data)}
                    >
                        <Iconicons name={"md-call"} color={gui.mainTextColor} size={22} />
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _onSmsNumber(data) {
        let phoneNumber = data.contactPhone || '';
        if (!phoneNumber) {
            return;
        }
        Communications.text(phoneNumber, '');
        let historyDto = {
            content: 'Gửi tin nhắn sms',
            contactID: this.state.selectedEvent.contactID,
            toPhone: phoneNumber,
            // toEmail: ,
            userID: this.props.global.currentUser.userID,
            eventType: 'sms'
        }
        this.props.actions.createHistory(historyDto, this.props.global.currentUser.token).then(res => { });
    }

    _renderPhoneContact(data) {
        let phoneNumber = data.contactPhone || '';
        if (!phoneNumber) {
            return (
                <TouchableOpacity style={styles.viewPhoneContact}>
                </TouchableOpacity>
            )
        }
        return (
            <TouchableOpacity style={styles.viewPhoneContact}
                onPress={this._onPhoneCall.bind(this, data)}
            >
                <Iconicons name={"md-call"} color={gui.mainTextColor} size={22} />
                <Text style={[styles.textMessage, { marginLeft: 22, marginTop: 3 }]}>{phoneNumber}</Text>
            </TouchableOpacity>
        );
    }

    _renderAds(data) {
        if (data.adsID) {

            let defaultCover = require('../../assets/image/no_cover.jpg');

            let addressValue = data.diaChi ? data.diaChi : '';

            let priceValue = utils.getPriceDisplay(data.gia, data.loaiTin);

            return (
                <View style={[styles.imgAdsItem, { height: 36 }]}>
                    <View style={styles.viewAdsRow}>
                        <View style={[styles.dotView2]}></View>
                        <View style={{ width: width - 136, height: 24, justifyContent: 'center' }}>
                            <Text style={[styles.textMainMinute, { marginLeft: 6 }]} numberOfLines={1}>{addressValue}</Text>
                        </View>
                        <View style={{ position: 'absolute', right: 0 }}>
                            <Text style={[styles.textMainMinute]} numberOfLines={1}>{priceValue}</Text>
                        </View>
                    </View>

                </View>
            )
        } else return (<View></View>)
    }

    _renderRowAds(value, sectionID, rowID) {
        let data = value.item;
        // console.log('renderRowAds ***', data);

        let addressValue = data.diaChi ? data.diaChi : '';

        let priceValue = utils.getPriceDisplay(data.gia, data.loaiTin);
        return (
            <View style={[styles.imgAdsItem, { height: 36 }]}>
                <View style={styles.viewAdsRow}>
                    <View style={[styles.dotView2]}></View>
                    <View style={{ width: width - 136, height: 24, justifyContent: 'center' }}>
                        <Text style={[styles.textMainMinute, { marginLeft: 6 }]} numberOfLines={1}>{addressValue}</Text>
                    </View>
                    <View style={{ position: 'absolute', right: 0 }}>
                        <Text style={[styles.textMainMinute]} numberOfLines={1}>{priceValue}</Text>
                    </View>
                </View>

            </View>
        )
    }

    startListenerTapped() {
        let currentUser = this.props.global.currentUser;
        let selectedEvent = this.state.selectedEvent;
        if (this.state.isListening == false) {
            callDetector = new CallDetectorManager((event, phoneNumber) => {
                // For iOS event will be either "Connected",
                // "Disconnected","Dialing" and "Incoming"

                // For Android event will be either "Offhook",
                // "Disconnected", "Incoming" or "Missed"

                // if (number == selectedContact.contactPhone) {
                if (event === 'Disconnected') {
                    // Alert.alert("Thông báo", 'Disconnected!');
                    if (this.state.callControl == 'connected') {
                        let currentTime = new Date().getTime();
                        let duration = this.state.callTimeControl ? currentTime - this.state.callTimeControl : 0;
                    }
                    if (this.state.callControl == 'dialing') {
                        let historyDto = {
                            content: 'Cuộc gọi nhỡ',
                            contactID: selectedEvent.contactID,
                            // toPhone: phoneNumber, //cannot detect phoneNumber in ios
                            // toEmail: ,
                            userID: currentUser.userID,
                            eventType: 'phoneDisconnected'
                        }
                        this.props.actions.createHistory(historyDto, currentUser.token).then(res => { });
                    }
                    this.setState({ 
                        callControl: 'none',
                        callTimeControl: null
                    })
                }
                else if (event === 'Connected') {
                    // This clause will only be executed for iOS
                    if (this.state.callControl == 'dialing') {
                        this.setState({ callControl: 'connected' })
                        this.setState({ callTimeControl: new Date().getTime() });
                        let historyDto = {
                            content: 'Cuộc gọi đi',
                            contactID: selectedEvent.contactID,
                            // toPhone: phoneNumber,
                            // toEmail: ,
                            userID: currentUser.userID,
                            eventType: 'phoneConnected'
                        }
                        this.props.actions.createHistory(historyDto, currentUser.token).then(res => { });
                    }
                }
                else if (event === 'Incoming') {
                    // Alert.alert("Thông báo", 'Incoming!');                        
                }
                else if (event === 'Dialing') {
                    this.setState({ callControl: 'dialing' })
                }
                /*
                else if (event === 'Offhook') {
                    //Device call state: Off-hook. 
                    // At least one call exists that is dialing,
                    // active, or on hold, 
                    // and no calls are ringing or waiting.
                    // This clause will only be executed for Android
                }
                else if (event === 'Missed') {
                    // Do something call got missed
                    // This clause will only be executed for Android
                }
                */
                // }
            },
                false, // if you want to read the phone number of the incoming call [ANDROID], otherwise false
                () => { }, // callback if your permission got denied [ANDROID] [only if you want to read incoming number] default: console.error
                {
                    title: 'Phone State Permission',
                    message: 'This app needs access to your phone state in order to react and/or to adapt to incoming calls.'
                } // a custom permission request message to explain to your user, why you need the permission [recommended] - this is the default one
            )
            this.setState({
                isListening: true,
            });
        }
    }

    stopListenerTapped() {
        this.setState({
            isListening: false,
            callControl: 'none',
            callTimeControl: null
        });
        callDetector && callDetector.dispose();
    }

    _onPhoneCall(data) {
        this.startListenerTapped();
        let phoneNumber = data.contactPhone || '';
        if (!phoneNumber) {
            return;
        }
        Communications.phonecall(phoneNumber, true);
        setTimeout(() => {
            this.stopListenerTapped();
        }, 10 * 60 * 1000)
    }

    _onCancelJoinPress() {
        this._doLeaveOrCall('Bạn muốn hủy yêu cầu tham gia ?');
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn rời khỏi sàn ?');
    }

    _doLeaveOrCall(title) {
        let selectedEvent = this.state.selectedEvent;
        if (!selectedEvent) {
            return;
        }
        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedEvent.groupID;
                    let userID = this.props.global.currentUser.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.leaveGroup({ groupID: groupID, userID: userID }, token);
                    this._outMoreModal();
                }
            }
            ]);
    }

    _onEditEventPress() {
        let selectedEvent = this.state.selectedEvent;
        if (!selectedEvent) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let personContactDto = {
            contactID: selectedEvent.contactID,
            contactName: selectedEvent.contactName,
            contactPhone: selectedEvent.contactPhone,
            contactAvatar: selectedEvent.contactAvatar,
            contactSaleState: selectedEvent.contactSaleState
        }

        let adsDto = {
            adsID: selectedEvent.adsID,
            image: selectedEvent.image,
            diaChi: selectedEvent.diaChi,
            gia: selectedEvent.gia,
            dienTich: selectedEvent.dienTich,
            loaiTin: selectedEvent.loaiTin,
            title: selectedEvent.adsTitle || selectedEvent.diaChi
        }

        this.props.actions.onEventFieldChange('eventID', selectedEvent.id);
        this.props.actions.onEventFieldChange('eventName', selectedEvent.title);
        this.props.actions.onGroupContactFieldChange('personContact', personContactDto);
        this.props.actions.onEventFieldChange('eventStartDate', selectedEvent.startDate);
        this.props.actions.onEventFieldChange('eventEndDate', selectedEvent.endDate);
        this.props.actions.onEventFieldChange('eventAllDay', selectedEvent.allDay);
        this.props.actions.onEventFieldChange('eventRepeat', selectedEvent.recurrenceRule && selectedEvent.recurrenceRule.frequency ? true : false);
        this.props.actions.onEventFieldChange('eventAlarm', selectedEvent.alarms && selectedEvent.alarms.length > 0 ? true : false);
        this.props.actions.onEventFieldChange('eventLevel', selectedEvent.level);//normal
        this.props.actions.onEventFieldChange('eventType', selectedEvent.eventType);
        this.props.actions.onEventFieldChange('eventAds', adsDto)
        this.props.actions.onEventFieldChange('eventIDInDevice', selectedEvent.eventIDInDevice);

        this._onSaveInitialEvent();

        Actions.MyTodoNotes({owner: 'CalendarEvent'});
        this._outMoreModal();
    }

    _onSaveInitialEvent() {
        // local storage initialEvent
        this.props.actions.onHelpedModalChange('initialEvent', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialEvent = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _onMarkEventIsDonePress() {
        let selectedEvent = this.state.selectedEvent;
        if (!selectedEvent) {
            return;
        }
        let eventDto = {};
        eventDto.status = 2;// done
        eventDto.eventID = selectedEvent.id;
        eventDto.title = selectedEvent.title
        eventDto.userID = selectedEvent.userID
        eventDto.personContact = selectedEvent.personContact
        eventDto.adsID = selectedEvent.adsID
        eventDto.startDate = selectedEvent.startDate
        eventDto.endDate = selectedEvent.endDate
        eventDto.alarms = selectedEvent.alarms
        eventDto.recurrenceRule = selectedEvent.recurrenceRule
        eventDto.level = selectedEvent.level
        eventDto.allDay = selectedEvent.allDay
        eventDto.eventIDInDevice = selectedEvent.eventIDInDevice
        eventDto.eventType = selectedEvent.eventType

        let token = this.props.global.currentUser.token;
        this.props.actions.saveCalendarEvent(eventDto, token)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                } else {
                    this.refs.toastTop && this.refs.toastTop.show(
                        "Cập nhật thành công!", DURATION.LENGTH_LONG);

                    setTimeout(() => {
                        // this.props.actions.onEventFieldChange('eventList', [])
                        this.props.actions.getAllCalendarEvent(
                            {
                                'userID': this.props.global.currentUser.userID,
                                'startDateTimeFrom': this.props.event.startDateTimeFrom,
                                'startDateTimeTo': this.props.event.startDateTimeTo
                            }
                            , (res) => {
                            }
                            , (error) => {
                                console.log('server respond data: =====>>>>>', error)
                            });

                    }, 1000);
                }
            });
        this._outMoreModal();
    }


    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }

    _renderBodyGroupMgmt() {
        return (
            <View style={styles.viewBody}>
                {/* {this._renderTabSelected()} */}
                {this._renderRowView()}
            </View>
        );
    }



    _onTabChange(value) {
        let currentUser = this.props.global.currentUser;
        // this.props.actions.onEventFieldChange('eventList', [])
        this.props.actions.getAllCalendarEvent(
            {
                'userID': currentUser.userID,
                'startDateTimeFrom': this.props.event.startDateTimeFrom,
                'startDateTimeTo': this.props.event.startDateTimeTo
            }
            , (res) => {
                this.props.actions.onEventFieldChange('selectedEventTab', value);
                this.setState({
                    phanLoai: value
                });
            }
            , (error) => {
                console.log('server respond data: =====>>>>>', error)
            });

    }

    _renderRowView() {
        let content;
        switch (this.state.phanLoai) {
            case "all": {
                content = (
                    <View style={styles.viewSanThamGia}>
                        {this._renderListAll()}
                    </View>
                );
                break;
            }
            case "todo": {
                content = (
                    <View style={styles.viewSanThamGia}>
                        {this._renderListToDo()}
                    </View>
                );
                break;
            }
            case "done": {
                content = (
                    <View style={styles.viewSanThamGia}>
                        {this._renderListDone()}
                    </View>
                );
                break;
            }
            default: {
                content = (
                    <View style={styles.viewSanThamGia} />
                );
            }
        }
        return content;
    }

    _renderListAll() {
        let filterList = utils.filterEventListByDoUuTien(this.state.eventList, this.state.doUuTien)
        let userID = this.props.global.currentUser.userID;
        return this._renderToDoList(filterList);
    }

    _renderListToDo() {
        console.log('will render listtodo *+++++++', this.state.eventList)
        let filterList = utils.filterEventListByDoUuTien(this.state.eventList, this.state.doUuTien)
        let userID = this.props.global.currentUser.userID;
        filterList = filterList.filter((one) => {
            return one.status == 1 && !one.dataType //not done && is not dummy event
        }) || [];
        return this._renderToDoList(filterList);
    }

    _renderListDone() {
        let filterList = utils.filterEventListByDoUuTien(this.state.eventList, this.state.doUuTien)
        let userID = this.props.global.currentUser.userID;
        filterList = filterList.filter((one) => {
            return one.status == 2 && !one.dataType //Done
        }) || [];
        return this._renderToDoList(filterList);
    }

    _renderToDoList(listEvent) {
        let data = listEvent.filter((one) => {
            return !one.dataType //not dummy
        }) || []

        let nameFilter = this.props.event.eventFilterState == 'distance'
            ? 'Từ ' + moment(this.props.event.startDateTimeFrom).format('DD/MM/YY') + ' đến ' + moment(this.props.event.startDateTimeTo).format('DD/MM/YY')
            : DanhMuc.eventFilter[this.props.event.eventFilterState];
        return (
            <View style={styles.toDoView}>
                <View style={styles.viewTitleFilter}>
                    <Text style={[styles.textFilter, { fontWeight: '500' }]}>{nameFilter}</Text>

                    <TouchableOpacity style={{ width: 64, height: 25, justifyContent: 'center', alignItems: 'flex-end' }}
                        onPress={this._onAddFilterEvent.bind(this)}>
                        <View style={{ justifyContent: 'center', alignItems: 'flex-end' }}>
                            <Text style={[styles.textFilter, { color: gui.mainAgentColor }]}>Lọc</Text>
                        </View>
                    </TouchableOpacity>

                </View>
                {data.length == 0 ?
                    (
                        <View style={styles.viewNoTodo}>
                            <Text style={styles.explainText}>Không có công việc cần hoàn thành</Text>
                        </View>
                    ) : (<View style={styles.toDoContent}>
                        <FlatList
                            refreshControl={
                                <RefreshControl
                                    refreshing={false}
                                    onRefresh={this._onRefresh.bind(this)}
                                />
                            }
                            data={data}
                            keyExtractor={(item, index) => "list" + index}
                            renderItem={(item) => this._renderRowToDo(item)}
                            //ListFooterComponent={() => this._renderFooter()}
                            removeClippedSubviews={false}
                            enableEmptySections
                            style={{ flex: 1 }}
                        />
                    </View>)
                }

            </View>
        )
    }

    _onRefresh() { }

    _getLevelColor(level) {
        if (level == 0) {
            return 'rgba(255,94,91,1)';
        } else if (level == 1) {
            return 'rgba(120,188,97,1)';
        } else if (level == 2) {
            return 'rgba(82,97,115,0.2)';
        } else return 'rgba(82,97,115,0.2)';
    }

    _renderRowToDo(value, sectionID, rowID) {
        let data = value.item;
        let dotColor = this._getLevelColor(data.level);
        let titleToShow = data.title;
        let timeColor = utils.isPast(data.startDate) ? 'red' : '#526173';
        return (
            <View style={{ flex: 1 }}>
                <TouchableOpacity onPress={this._onMoreButtonPress.bind(this, data)} >
                    <View style={styles.viewToDoRow}>
                        <View style={[styles.dotView, { backgroundColor: dotColor }]}></View>
                        <View style={{ width: width - 44, height: 56, justifyContent: 'center', paddingLeft: 9 }}>
                            <Text style={[styles.toDoDateText, { color: timeColor }]}>{utils.showChatTime(data.startDate)}</Text>
                            <Text style={styles.toDoContentText} numberOfLines={1}>{titleToShow}</Text>
                        </View>
                        {this._renderCheckLevel(data.status)}
                    </View>
                </TouchableOpacity>
            </View>

        );
    }

    _renderCheckLevel(value) {
        if (value == 2) {
            return (
                <View style={styles.viewCheckStatus}>
                    <Iconicons name={"md-checkmark"} color={'green'} size={22} />
                </View>
            )
        } else return null;
    }


    _onMoreButtonPress(data) {
        this.setState({ selectedEvent: data, isOpenMoreCalendarModal: true });
        // this.props.actions.onGroupFieldChange('selectedEvent', data);        
        // this.props.actions.onGroupFieldChange('isOpenMoreCalendarModal', true)
    }


    _renderLoadingView() {
        if (this.props.event.loadingEvent) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }


}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderContent: {
        height: 72,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 19,
        paddingRight: 21
    },
    viewIconSearch: {
        height: 72,
        width: 18,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPlusSearch: {
        height: 72,
        width: 20,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewInputSearch: {
        height: 72,
        width: width - 78,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        backgroundColor: '#fff',
        width: width - 78,
        height: 70,
        paddingLeft: 10,
        color: gui.mainTextColor
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width - 32,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 20
    },
    viewBody: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewTabSelect: {
        height: 39,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row',
        marginTop: 23
    },
    viewSanThamGia: {
        // height: height - 105,
        // width: width,
        flex: 1,
        marginTop: 0,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: gui.groupBackground
    },
    viewContent: {
        marginTop: 15,
        width: width - 30,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 18
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        height: 80,
        width: width - 208,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 100,
        height: 82,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 16
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 198,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    viewListContainer: {
        paddingBottom: 30
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 'auto',
        width: width,
        // marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center',
        // marginBottom: 50
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    toDoView: {
        flex: 1,
        backgroundColor: gui.groupBackground
    },
    toDoTitle: {
        width: width,
        height: 48,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    toDoContent: {
        // width: width,
        // height: 'auto',
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: gui.groupBackground
    },
    toDoTitleText: {
        width: (width - 32) / 2,
        textAlign: 'left',
        marginLeft: 16,
        marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 20,
        fontWeight: '600',
        backgroundColor: 'transparent',
        color: '#526173'
    },
    themCongViecText: {
        // width: width/2,
        textAlign: 'right',
        marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '400',
        // backgroundColor: 'transparent',
        color: gui.mainColor
    },
    toDoContentText: {
        textAlign: 'left',
        // marginTop: 9,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '600',
        // backgroundColor: 'transparent',
        color: '#526173'
    },
    toDoDateText: {
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight: '400',
        backgroundColor: 'transparent',
        color: '#526173'
    },
    viewToDoRow: {
        backgroundColor: '#fff',
        marginBottom: 6,
        width: width - 12,
        height: 56,
        marginLeft: 6,
        marginRight: 6,
        flexDirection: 'row',
        alignItems: 'center'
    },
    dotView: {
        width: 3,
        height: 56
    },
    dotView2: {
        width: 8,
        borderRadius: 4,
        height: 8,
        marginLeft: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(82,97,115,0.2)'
    },
    headerView: {
        backgroundColor: '#fff',
        height: 64, //136,
        width: width,
        borderBottomWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)'
    },
    subHeader: {
        backgroundColor: 'transparent',
        marginTop: 30,
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 24,
        flexDirection: 'row'
    },
    tabHeader: {
        // backgroundColor: 'blue',
        flexDirection: 'row',
        marginTop: 17,
        width: width - 32,
        height: 55
    },
    headerText: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173',
        marginLeft: 16
    },
    tabbar: {
        flexDirection: 'row',
        paddingLeft: 20,
        paddingRight: 20,
        borderColor: '#dfdfdf',
        borderBottomWidth: 0,
        paddingTop: 17,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewBackIcon: {
        height: 25,
        width: 64,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        marginTop: 1
    },
    viewContentPopup: {
        height: 'auto',
        width: width,
        borderRadius: 2,
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
        backgroundColor: '#fff'
    },
    viewTodoTitle: {
        height: 60,
        width: width - 32,
        flexDirection: 'row',
        marginTop: 16,
        marginLeft: 16,
        marginRight: 16
    },
    viewDotTodo: {
        height: 60,
        width: 18,
        paddingTop: 4
    },
    dotStyle: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: 'rgba(255,94,91,1)'
    },
    viewModifyTodo: {
        height: 60,
        width: 70,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    textModify: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 15
    },
    viewTodoContent: {
        height: 60,
        width: width - 120
    },
    textDate: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        marginTop: 3
    },
    viewNameContact: {
        height: 96,
        width: width,
        flexDirection: 'row'
    },
    avatarContact: {
        height: 96,
        width: width / 2,
        flexDirection: 'row',
        paddingLeft: 16,
        alignItems: 'center'
    },
    messageContact: {
        height: 96,
        // width: width/4,
        flexDirection: 'row',
        // paddingRight: 16,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    viewPhoneContact: {
        height: 96,
        // width: width/4,
        paddingLeft: 16,
        paddingRight: 16,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    avatarImage: {
        height: 48,
        width: 48,
        borderRadius: 24
    },
    textUserContact: {
        fontSize: 17,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 10
    },
    textMessage: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor
    },
    textRelated: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur
    },
    touchSortContent: {
        width: width / 2,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingRight: 16
    },
    tabHeaderText: {
        fontSize: 15,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    viewSortIcon: {
        marginLeft: 10,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 5
    },
    viewDoUuTienStyle: {
        justifyContent: 'center',
        height: 120,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalSapxep: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    textSapxep: {
        color: gui.mainTextColor,
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewAdsRow: {
        // backgroundColor: '#FFFFFF',
        marginTop: 17,
        marginBottom: 15,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        height: 24,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    imgAdsItem: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 188,
        alignSelf: 'auto'
    },
    viewTextSort: {
        fontSize: 15,
        color: gui.mainAgentColor,
        fontFamily: gui.fontFamily
    },
    touchFilterEvent: {
        position: 'absolute',
        right: 18,
        top: 100
    },
    viewAddNote: {
        height: 37,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textFilter: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    viewTitleFilter: {
        height: 40,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: gui.groupBackground,
        flexDirection: 'row'
    },
    viewTouchPlus: {
        position: 'absolute',
        right: 16
    },
    viewCheckStatus: {
        position: 'absolute',
        right: 8
    },
    viewNoTodo: {
        height: 39,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.groupBackground
    },
    explainText: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(CalendarEvent);