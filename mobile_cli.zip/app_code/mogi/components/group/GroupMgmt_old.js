import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ListView,
    TextInput,
    Alert,
    StatusBar
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';

import gui from '../../lib/gui';
import RelandIcon from '../RelandIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();
import TabGroupMgmt from './TabGroupMgmt';
import GroupSearchHeader from './GroupSearchHeader';
import danhMuc from '../../assets/DanhMuc';
import ScalableText from 'react-native-text';
import GiftedSpinner from "../GiftedSpinner";
import findApi from '../../lib/FindApi';
import RangeUtils from "../../lib/RangeUtils";

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Modal from 'react-native-modalbox';

let ds_groupOrder = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 != r2 });


const actions = [
    globalActions,
    meActions,
    groupSearchActions,
    groupActions,
    inboxActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupMgmt extends Component {
    constructor(props) {
        super(props);
        this.state = {
            laoding: false,
            searchText: '',
            loaiSan: props.group.selectedGroupTab,
            isOpenMoreModal: false,
            selectedGroup: null
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.group.selectedGroupTab !== nextProps.group.selectedGroupTab) {
            this.setState({ loaiSan: nextProps.group.selectedGroupTab });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}
                <View style={styles.lineFullWidth} />
                <View style={styles.viewDangNhap}>
                    <Text style={styles.textDangNhap}>Sàn môi giới</Text>
                </View>
                {this._renderBodyGroupMgmt()}
                {this._renderLoadingView()}
                {this._openMoreModal()}
            </View>
        );
    }

    _outMoreModal() {
        this.setState({
            isOpenMoreModal: false
        });
    }

    _openMoreModal() {
        let modalHeight = this.state.loaiSan == "sanQuanLy" ? 169 : 116;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this._outMoreModal.bind(this)}
                style={[styles.viewModalStyle, { height: modalHeight }]}
                position={"bottom"}
                swipeToClose={false}
               animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );

    }

    _renderMoreContent() {
        let mainItems = null;
        if (this.state.loaiSan == "sanYeuCau") {
            mainItems = <View style={[styles.viewSwipeButton, { height: 52 }]}>
                <TouchableOpacity onPress={this._onCancelJoinPress.bind(this)} style={styles.viewButtonModal}>
                    <Text style={styles.textMoreButton}>Hủy yêu cầu tham gia</Text>
                </TouchableOpacity>
            </View>;
        }
        if (this.state.loaiSan == "sanQuanLy") {
            mainItems = <View style={styles.viewSwipeButton}>
                <TouchableOpacity onPress={this._onEditGroupPress.bind(this)} style={[styles.viewButtonModal, { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }]}>
                    <Text style={styles.textMoreButton}>Sửa sàn</Text>
                </TouchableOpacity>
                <View style={styles.lineSpaceButton} />
                <TouchableOpacity onPress={this._onDeleteGroupPress.bind(this)} style={[styles.viewButtonModal, { borderTopLeftRadius: 0, borderTopRightRadius: 0 }]}>
                    <Text style={styles.textMoreButton}>Xóa sàn</Text>
                </TouchableOpacity>
            </View>;
        }
        if (this.state.loaiSan == "sanThamGia") {
            mainItems = <View style={[styles.viewSwipeButton, { height: 52 }]}>
                <TouchableOpacity onPress={this._onLeaveGroupPress.bind(this)} style={styles.viewButtonModal}>
                    <Text style={styles.textMoreButton}>Rời khỏi sàn</Text>
                </TouchableOpacity>
            </View>;
        }
        return (
            <View style={styles.viewShowModal}>
                {mainItems}
                {/*<TouchableOpacity onPress={() => this._outMoreModal()} style={styles.viewSwipeButton2}>
                    <Text style={[styles.textMoreButton, {fontWeight: '500', fontSize: 18}]}>Hủy</Text>
                </TouchableOpacity>*/}
            </View>
        )
    }

    _onCancelJoinPress() {
        this._doLeaveOrCall('Bạn muốn hủy yêu cầu tham gia ?');
    }

    _onLeaveGroupPress() {
        this._doLeaveOrCall('Bạn muốn rời khỏi sàn ?');
    }

    _doLeaveOrCall(title) {
        let selectedGroup = this.state.selectedGroup;
        if (!selectedGroup) {
            return;
        }
        Alert.alert('Thông báo', title,
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedGroup.groupID;
                    let userID = this.props.global.currentUser.userID;
                    let token = this.props.global.currentUser.token;
                    this.props.actions.leaveGroup({ groupID: groupID, userID: userID }, token);
                    this._outMoreModal();
                }
            }
            ]);
    }

    _onEditGroupPress() {
        let selectedGroup = this.state.selectedGroup;
        if (!selectedGroup) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        if (userID != selectedGroup.createdBy) {
            Alert.alert('Thông báo', 'Bạn không phải là quản trị của sàn \'' + selectedGroup.name + '\' ?');
            this._outMoreModal();
            return;
        }
        this.props.actions.onGroupFieldChange('groupID', selectedGroup.groupID);
        this.props.actions.onGroupFieldChange('name', selectedGroup.name);
        this.props.actions.onGroupFieldChange('groupType', selectedGroup.groupType);
        this.props.actions.onGroupFieldChange('chiTiet', selectedGroup.chiTiet);
        this.props.actions.onGroupFieldChange('photos', selectedGroup.image ? [{ uri: selectedGroup.image }] : []);
        this.props.actions.onGroupFieldChange('allDiaChinh', selectedGroup.diaBan);
        Actions.Group({ doAfterSaveGroup: this._doAfterSaveGroup.bind(this) });
        this._outMoreModal();
    }

    _doAfterSaveGroup() {
        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.getRelatedGroup({userID: userID}, token, () => {
            this.props.actions.searchGroup(false, this.props.group.searchFields, () => { });
        });
    }

    _onDeleteGroupPress() {
        let selectedGroup = this.state.selectedGroup;
        if (!selectedGroup) {
            return;
        }
        Alert.alert('Thông báo', 'Bạn muốn xóa sàn \'' + selectedGroup.name + '\' ?',
            [{
                text: 'Hủy', onPress: () => { this._outMoreModal() }
            },
            {
                text: 'Đồng ý', onPress: () => {
                    let groupID = selectedGroup.groupID;
                    let token = this.props.global.currentUser.token;                    
                    this.props.actions.deleteGroup(groupID, token)
                    .then(res => {
                        if (res.status != 0) {
                            Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                        } else {
                            let userID = this.props.global.currentUser.userID || undefined;
                            // this.props.actions.onRefreshGroupInbox(userID);
                        }
                    });
                    this._outMoreModal();
                }
            }
            ]);
    }

    _renderHeader() {
        return (
            <GroupSearchHeader
                onChangeText={(text) => { this._onUserSearchChange(text) }}
                value={this.state.searchText}
                onGroupSearchPress={this._onGroupSearchPress.bind(this)}
                onAddGroup={this._onAddGroup.bind(this)}
            />
        );
    }

    _onAddGroup() {
        this._onRefreshGroup();
        Actions.Group();
    }

    _onRefreshGroup() {
        this.props.actions.onGroupFieldChange('groupID', null);
        this.props.actions.onGroupFieldChange('name', '');
        this.props.actions.onGroupFieldChange('groupType', 'public');
        this.props.actions.onGroupFieldChange('chiTiet', '');
        this.props.actions.onGroupFieldChange('photos', []);
        this.props.actions.onGroupFieldChange('allDiaChinh', []);
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }

    _renderBodyGroupMgmt() {
        return (
            <View style={styles.viewBody}>
                {this._renderTabSelected()}
                {this._renderRowView()}
            </View>
        );
    }

    _renderTabSelected() {
        return (
            <View style={styles.viewTab}>
                <View style={styles.viewTabSelect}>
                    <TabGroupMgmt name={'sanThamGia'}
                        onPress={this._onLoaiSanChange.bind(this)}
                        selected={this.state.loaiSan == 'sanThamGia'}>SÀN</TabGroupMgmt>
                    <TabGroupMgmt name={'sanQuanLy'}
                        onPress={this._onLoaiSanChange.bind(this)}
                        selected={this.state.loaiSan == 'sanQuanLy'}>KHÁM PHÁ</TabGroupMgmt>
                    
                </View>
                <FullLine style={{marginTop: 3}}/>
            </View>
        );
    }

    _onLoaiSanChange(value) {
        this.props.actions.onGroupFieldChange('selectedGroupTab', value);
        this.setState({
            loaiSan: value
        });
    }

    _renderRowView() {
        let content;
        switch (this.state.loaiSan) {
            case "sanThamGia": {
                content = (
                    <View style={styles.viewSanThamGia}>
                        {this._renderListRelatedGroupView(2)}
                    </View>
                );
                break;
            }

            case "sanQuanLy": {
                content = (
                    <View style={styles.viewSanThamGia}>
                        {this._renderListSanQuanLyView()}
                    </View>
                );
                break;
            }
            case "sanYeuCau": {
                content = (
                    <View style={styles.viewSanThamGia}>
                        {this._renderListRelatedGroupView(1)}
                    </View>
                );
                break;
            }
            default: {
                content = (
                    <View style={styles.viewSanThamGia} />
                );
            }
        }
        return content;
    }

    _renderListSanQuanLyView() {
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let userID = this.props.global.currentUser.userID;
        listRelatedGroup = listRelatedGroup.filter((one) => {
            return one.createdBy == userID
        }) || [];
        return this._renderListView(listRelatedGroup);
    }

    _renderListRelatedGroupView(joinStatus) {
        let listRelatedGroup = this.props.group.searchResult.listRelatedGroup;
        let userID = this.props.global.currentUser.userID;
        listRelatedGroup = listRelatedGroup.filter((one) => {
            return one.createdBy != userID && one.joinStatus == joinStatus
        }) || [];
        return this._renderListView(listRelatedGroup);
    }

    _renderListView(listRelatedGroup) {
        let dsDaThamGia = ds_groupOrder.cloneWithRows(listRelatedGroup);
        return (
            <View style={{ flex: 1, marginBottom: 50, backgroundColor: gui.groupBackground }}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsDaThamGia}
                    renderRow={this._renderRow.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRow(data) {
        let imgUrl = data.image;
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/no_cover.jpg');
        if (!imageGroup) {
            imageGroup = defaultCover;
        }
        let adminAvatarUrl = data.avatar;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let adminSource = adminAvatarUrl ? { uri: adminAvatarUrl } : defaultAvatar;
        let groupName = data.name;
        let nameAdmin = data.fullNameChuSan;
        let totalMember = data.countMember || 0;
        let groupStatus = danhMuc.groupStatus[data.status];
        let showStatus = this.state.loaiSan == "sanQuanLy" && (data.status == 1 || data.status == 3);
        let viewMoreStyle = showStatus ? {} : { width: 31, flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'center' };
        return (
            <TouchableOpacity onPress={this._onOpenGroupWallPress.bind(this, data)}>
                <View style={styles.viewContent}>
                    <Image
                        resizeMode={"cover"}
                        source={imageGroup}
                        defaultSource={defaultCover}
                        style={styles.adsCover} />
                    <View style={[styles.viewBodyContent, { width: showStatus ? width - 181 : width - 128 }]}>
                        <View style={[styles.viewNameGroup, { width: showStatus ? width - 215 : width - 138 }]}>
                            <ScalableText style={styles.textNameGroup} numberOfLines={2}>{groupName}</ScalableText>
                        </View>
                        <View style={[styles.viewNameGroup, {marginTop: 5, height: 24, width: showStatus ? width - 215 : width - 138}]}>
                            <Image
                                resizeMode={"cover"}
                                source={adminSource}
                                defaultSource={defaultCover}
                                style={styles.avatarAdmin} />
                            <View style={[styles.viewTextAdmin,{width: showStatus ? (width - 215 - 95) : (width - 138 - 95)}]}>
                                <Text style={[styles.textNameAvatar, { marginLeft: 8 }]} numberOfLines={1}>{nameAdmin}</Text>
                            </View>
                            <View style={styles.textTotalIcon} >
                                <Icon name="users" size={13} color={gui.mainTextColor}/>
                            </View>
                            <View style={styles.textTotalMember}>
                                <Text style={styles.textNameAvatar}>{totalMember}</Text>
                            </View>
                        </View>
                    </View>
                    <View style={[styles.viewMoreButton, viewMoreStyle]}>
                        {showStatus ? <Text style={[styles.textNameAvatar, { marginRight: 8 }]}>{groupStatus}</Text> : null}
                        <TouchableOpacity onPress={this._onMoreButtonPress.bind(this, data)} style={{ width: 31, alignItems: 'flex-start', justifyContent: 'center' }}>
                            <RelandIcon noAction={true}
                                name="more-ext2" color={gui.mainTextColor}
                                size={22} mainProps={{ marginLeft: 0, flexDirection: 'row' }}>
                            </RelandIcon>
                            {/*<Icon name="ellipsis-v" size={20} color={gui.mainTextColor} style={{marginLeft: 0}} />*/}
                        </TouchableOpacity>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    _onMoreButtonPress(data) {
        this.setState({ selectedGroup: data, isOpenMoreModal: true });
    }

    _onOpenGroupWallPress(data) {
        if (this.state.loaiSan == "sanYeuCau" || data.status == 1 || data.status == 3) {
            Actions.GroupDetail2({ groupData: data, groupID: data.groupID, owner: 'GroupMgmt' });
        } else {
            this.props.actions.onGroupFieldChange("pageNo", 1);
            this.props.actions.getNextWall(
                {
                    'groupID': [data.groupID],
                    'limit': this.props.group.limit,
                    'pageNo': 1,
                    'textSearch': this.props.group.textSearch ? this.props.group.textSearch.trim() : ''
                }
                , (res) => {                    
                    StatusBar.setBarStyle('light-content');
                    this._loadLastSearchFilter(data.groupID);
                    Actions.GroupWall2({ groupData: data, groupID: data.groupID });
                }
                , (error) => {
                    // this.setState({ loaded: true });
                    // this._updateMessageProcessing(error, '#fa4916', 'white');
                    Alert.alert("Thông báo", error, [{ text: 'Đóng', onPress: () => { } }]);
                })            
        }
    }

    _loadLastSearchFilter(groupID) {
        let lastSearchAgent = this.props.groupSearch.lastSearchAgent;
        let fields = null;
        if (lastSearchAgent && lastSearchAgent.length > 0) {
            let lastSearch = lastSearchAgent.find((one => {
                return one.groupID == groupID
            }));
            if (lastSearch) {
                fields = findApi.convertQueryToFieldsParams(lastSearch.query);
            }
        }
        if (fields) {
            this.props.actions.onGroupSearchFieldChange("diaChinh", fields.diaChinh);
            this.props.actions.onGroupSearchFieldChange("viewport", fields.viewport);
            this.props.actions.onGroupSearchFieldChange("diaChinhViewport", undefined);
            this.props.actions.onGroupSearchFieldChange("center", null);
            this.props.actions.onGroupSearchFieldChange("circle", {});
            this.props.actions.onGroupCircleChange({});
            this.props.actions.onGroupSearchFieldChange("polygon", []);
            this.props.actions.onGroupPolygonsChange([]);
            this.props.actions.onGroupSearchFieldChange("loaiTin", fields.loaiTin);
            this.props.actions.onGroupSearchFieldChange("ban", fields.ban);
            this.props.actions.onGroupSearchFieldChange("thue", fields.thue);
            this.props.actions.onGroupSearchFieldChange("soPhongNguSelectedIdx", fields.soPhongNguSelectedIdx);
            this.props.actions.onGroupSearchFieldChange("soNhaTamSelectedIdx", fields.soNhaTamSelectedIdx);
            this.props.actions.onGroupSearchFieldChange("dienTich", fields.dienTich);
            this.props.actions.onGroupSearchFieldChange("radiusInKmSelectedIdx", fields.radiusInKmSelectedIdx);
            this.props.actions.onGroupSearchFieldChange("huongNha", fields.huongNha);
            this.props.actions.onGroupSearchFieldChange("ngayDaDang", fields.ngayDaDang);
            this.props.actions.onGroupSearchFieldChange("hasImage", fields.hasImage);
            this.props.actions.onGroupSearchFieldChange("excludeMoiGioi", fields.excludeMoiGioi);
            this.props.actions.onGroupSearchFieldChange("isFakeGeo", fields.isFakeGeo);
        } else {
            let defaultDiaChinh = {
                tinhKhongDau : 'HN',
                fullName : 'Hà Nội'
            };
            let defaultViewport = {
                northeast: {
                    lat:21.385027,
                    lon:106.0198859
                },
                southwest: {
                    lat:20.562323,
                    lon:105.2854659
                }
            };
            this.props.actions.onGroupSearchFieldChange("diaChinh", defaultDiaChinh);
            this.props.actions.onGroupSearchFieldChange("viewport", defaultViewport);
            this.props.actions.onGroupSearchFieldChange("diaChinhViewport", undefined);
            this.props.actions.onGroupSearchFieldChange("center", null);
            this.props.actions.onGroupSearchFieldChange("circle", {});
            this.props.actions.onGroupCircleChange({});
            this.props.actions.onGroupSearchFieldChange("polygon", []);
            this.props.actions.onGroupPolygonsChange([]);
            this.props.actions.onGroupSearchFieldChange("loaiTin", 'ban');
            let defaultBan = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
            let defaultThue = { loaiNhaDat: '', gia: RangeUtils.BAT_KY_RANGE };
            this.props.actions.onGroupSearchFieldChange("ban", defaultBan);
            this.props.actions.onGroupSearchFieldChange("thue", defaultThue);
            this.props.actions.onGroupSearchFieldChange("soPhongNguSelectedIdx", 0);
            this.props.actions.onGroupSearchFieldChange("soNhaTamSelectedIdx", 0);
            this.props.actions.onGroupSearchFieldChange("dienTich", RangeUtils.BAT_KY_RANGE);
            this.props.actions.onGroupSearchFieldChange("radiusInKmSelectedIdx", 0);
            this.props.actions.onGroupSearchFieldChange("huongNha", 0);
            this.props.actions.onGroupSearchFieldChange("ngayDaDang", '');
            this.props.actions.onGroupSearchFieldChange("hasImage", true);
            this.props.actions.onGroupSearchFieldChange("excludeMoiGioi", false);
            this.props.actions.onGroupSearchFieldChange("isFakeGeo", undefined);
        }

    }

    _renderLoadingView() {
        if (this.props.group.loadingWall) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderButtonChat() {
        let totalMessages = '23';
        return (
            <TouchableOpacity style={styles.viewButtonChat}
                onPress={() => this.onPressChat()}
            >
                <View style={styles.viewCircleChat}>
                    <Icon name="comments-o" size={22} color={'#fff'} style={{ marginLeft: 0 }} />
                </View>
                {/* <View style={styles.viewNumberMessage}>
                    <Text style={[styles.textNameAvatar, {fontSize: 8, color: '#fff'}]}>{totalMessages}</Text>
                </View> */}
            </TouchableOpacity>
        );
    }

    onPressChat() {
        // Actions.Inbox({owner: 'GroupMain'});
        Actions.GroupInbox();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderContent: {
        height: 72,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingLeft: 19,
        paddingRight: 21
    },
    viewIconSearch: {
        height: 72,
        width: 18,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewPlusSearch: {
        height: 72,
        width: 20,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewInputSearch: {
        height: 72,
        width: width - 78,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontGroup,
        backgroundColor: '#fff',
        width: width - 78,
        height: 70,
        paddingLeft: 10,
        color: gui.mainTextColor
    },
    lineFullWidth: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width,
        opacity: 0.8
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewBody: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewTabSelect: {
        height: 39,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row'
    },
    viewTab: {
        height: 40,
        width: width,
        marginTop: 23
    },
    viewSanThamGia: {
        backgroundColor: gui.groupBackground,
        height: height - 184,
        width: width,
        marginTop: 3,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    viewContent: {
        marginTop: 15,
        width: width - 30,
        height: 82,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        flexDirection: 'row'
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 18
    },
    viewBodyContent: {
        backgroundColor: '#fff',
        // height: 80,
        width: width - 208,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 100,
        // height: 82,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 16,
        paddingBottom: 22
    },
    viewNameGroup: {
        backgroundColor: '#fff',
        // height: 24,
        width: width - 198,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    viewTextAdmin: {
        width: width - 198 - 90,
        height: 24,
        justifyContent: 'center'
    },
    textNameAvatar: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 18,
        height: 18,
        borderRadius: 9,
        top: 0,
        right: 0
    },
    viewListContainer: {
        paddingBottom: 30
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    textTotalMember: {
        height: 24,
        width: 30,
        justifyContent: 'center'
    },
    textTotalIcon: {
        height: 24,
        width: 20,
        marginBottom: 1,
        justifyContent: 'center'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupMgmt);