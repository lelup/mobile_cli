'use strict';

import gui from '../../lib/gui';

import React, {Component} from 'react';

import { Text, View, Navigator, TouchableOpacity, InteractionManager
  , SegmentedControlIOS, ScrollView, StyleSheet, StatusBar, PickerIOS } from 'react-native'

import Button from 'react-native-button';
import {Actions} from 'react-native-router-flux';
import TruliaIcon from '../../components/TruliaIcon'

import LikeTabButton from '../../components/LikeTabButton';
import RangeUtils from "../../lib/RangeUtils"

import DanhMuc from "../../assets/DanhMuc"

import SegmentedControl from '../../components/SegmentedControl';

import log from '../../lib/logUtil';

import PickerExt from '../../components/picker/PickerExt';

import PickerExt2 from '../../components/picker/PickerExt2';

import FullLine from '../../components/line/FullLine';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import ScalableText from 'react-native-text';

import Toast, {DURATION} from '../toast/Toast';

import utils from '../../lib/utils';

const {width, height} = utils.getDimensions();

class SearchFilter2 extends Component {
    componentDidMount() {
        StatusBar.setBarStyle('default');
    }

  _onPressGiaHandle(){
    // this.pickerGia.toggle();
      var {showGia} = this.props.filterState;
      this.props.updateSearchFilterState({showGia: !showGia});
      if (!showGia) {
          this._onScrollGia();
      }
  }

  _onScrollGia() {
      if (this._scrollView) {
          var {showDienTich} = this.props.filterState;
          // var scrollTo = height/2-330;
          var scrollTo = 38;
          if (showDienTich) {
              scrollTo = scrollTo + 225;
          }
          this._scrollView.scrollTo({y: scrollTo});
      }
  }

  _onPressDienTichHandle(){
    // this.pickerDienTich.toggle();
      var {showDienTich} = this.props.filterState;
      this.props.updateSearchFilterState({showDienTich: !showDienTich});
      if (!showDienTich) {
          this._onScrollDienTich();
      }
  }

  _onScrollDienTich() {
      if (this._scrollView) {
          this._scrollView.scrollTo({y: 0});
      }
  }

  _onPressNgayDaDangHandle() {
    var {showNgayDaDang} = this.props.filterState;
    this.props.updateSearchFilterState({showNgayDaDang: !showNgayDaDang});
    if (!showNgayDaDang) {
        this._onScrollNgayDaDang();
    }
  }

  _onScrollNgayDaDang() {
      if (this._scrollView) {
          var {showGia, showDienTich} = this.props.filterState;
          // var scrollTo = height/2-238;
          var scrollTo = 225;
          if (showGia) {
              scrollTo = scrollTo + 225;
          }
          if (showDienTich) {
              scrollTo = scrollTo + 225;
          }
          this._scrollView.scrollTo({y: scrollTo});
      }
  }

  render() {
    //log.info(RangeUtils.sellPriceRange.getPickerData());
    log.info("CALL Search.render");
    //log.info(this.props);

    let {loaiTin} = this.props.filterState;

    return (
      <View style={myStyles.fullWidthContainer}>
        <View style={[myStyles.searchFilter, {top: 0}]}>

          <View style={[myStyles.searchFilterButton]}>
            <View style = {{flexGrow:1, flexDirection: 'row', paddingLeft: 5, paddingRight: 5}}>
                <LikeTabButton name={'ban'}
                             onPress={this.props.onLoaiTinChange}
                             selected={loaiTin === 'ban'}>TIN BÁN</LikeTabButton>
                <LikeTabButton name={'thue'}
                             onPress={this.props.onLoaiTinChange}
                             selected={loaiTin === 'thue'}>TIN CHO THUÊ</LikeTabButton>
            </View>
              <FullLine />
          </View>

          <View style={myStyles.scrollView}>
          <ScrollView
            keyboardShouldPersistTaps="always"
            keyboardDismissMode="none"
            ref={(scrollView) => { this._scrollView = scrollView; }}
            automaticallyAdjustContentInsets={false}
            vertical={true}
            style={myStyles.scrollView2}>

              {this.renderMainView()}
              <Toast
                  ref="toastTop"
                  position='top'
                  positionValue={height/2 - 120}
                  fadeInDuration={850}
                  fadeOutDuration={1400}
                  opacity={0.8}
                  textStyle={{color:'#fff'}}
              />
            </ScrollView>

              {this.props.filterState.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                style={[myStyles.searchButtonText2, {textAlign: 'right', color: gui.mainColor,
                                            backgroundColor: gui.doneKeyButton}]}>Xong</Button> : null}
              <KeyboardSpacer topSpacing={-93} onToggle={(toggleState) => this.props.onKeyboardToggle(toggleState)}/>

          </View>
        </View>

        <View style={myStyles.searchButton}>
            <View style={myStyles.searchButtonWrapper}>
                <Button onPress={this.props.onSearchFilterApply}
                        style={myStyles.searchButtonText}>Thực hiện</Button>
            </View>
        </View>
          
      </View>
    );
  }

  renderMainView(){
      if (this.props.filterState.loaiTin == DanhMuc.loaiTinFilter.duAn)
          return (
              <View>
                  <View style={myStyles.searchSectionTitle}>
                      <Text style={myStyles.cacDieuKienText}>
                          CÁC ĐIỀU KIỆN
                      </Text>
                  </View>
                  <FullLine />
                  <TouchableOpacity
                      onPress={this._onPressFilterDuAn.bind(this)}>
                      <View style={myStyles.searchFilterAttributeExt3}>
                          <Text style={myStyles.searchAttributeLabel}>
                              Chủ đầu tư
                          </Text>
                          <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                              <ScalableText style={myStyles.searchAttributeValue}> {this._getChuDauTuValue()} </ScalableText>
                              <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                          </View>
                      </View>
                  </TouchableOpacity>
                  <FullLine />
              </View>
          );
      else
          return (
              <View>
                  <View style={myStyles.searchFilterDetail}>
                      <View style={myStyles.searchSectionTitle}>
                          <Text style={myStyles.cacDieuKienText}>
                              CÁC ĐIỀU KIỆN
                          </Text>
                      </View>
                      <FullLine />
                      <TouchableOpacity
                          onPress={this.props.onPropertyTypesPressed}>
                          <View style={myStyles.searchFilterAttributeExt3}>
                              <Text style={myStyles.searchAttributeLabel}>
                                  Loại nhà đất
                              </Text>
                              <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                                  <ScalableText style={myStyles.searchAttributeValue}> {this.props.getLoaiNhatDatValue()} </ScalableText>
                                  <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
                              </View>
                          </View>
                      </TouchableOpacity>
                      <FullLine style={{ marginLeft: 17 }} />
                      {this._renderDienTich()}
                      <FullLine style={{ marginLeft: 17 }} />
                      {this._renderGia()}
                      <FullLine style={{ marginLeft: 17 }} />
                      {this._renderSoPhongNgu()}
                      <FullLine style={{ marginLeft: 17 }} />
                      {this._renderImageFilter()}
                      {/*<FullLine style={{marginLeft:17}} />*/}
                      {/*this._renderMoiGioiFilter()*/}
                      {/*<FullLine style={{ marginLeft: 17 }} />*/}
                      {/*this._renderFakeGeoFilter()*/}
                      <FullLine />

                      {this._renderBanKinhTimKiem()}

                  </View>

                  <View style={myStyles.searchMoreFilterButton}>
                      <View style={[myStyles.searchMoreFilterAttribute, myStyles.searchMoreSeparator]}>
                          <Text />
                      </View>
                      <FullLine />
                      {this._renderMoreComponent()}
                      <View style={[myStyles.searchMoreFilterAttribute, myStyles.searchMoreSeparator]}>
                          <Text />
                      </View>
                      <FullLine />
                      <View style={myStyles.searchMoreFilterAttribute}>
                          <Button onPress={this.props.onResetFilters} style={myStyles.searchResetText}>Thiết lập lại</Button>
                      </View>
                      <FullLine />
                  </View>
                  <View style={myStyles.addViewBottom}></View>
              </View>
          )
  }

  onCancel() {
    Actions.pop();
    // StatusBar.setBarStyle('light-content');
  }

    _onPressFilterDuAn () {
        // return this.refs.toastTop && this.refs.toastTop.show('Tính năng đang phát triển', 2000)
    }

    _getChuDauTuValue() {
        return DanhMuc.BAT_KY;
    }

    _renderDienTich() {
        var {showDienTich} = this.props.filterState;
        var iconName = showDienTich ? "arrow-up" : "arrow-down";
        return (
            <View>
                <TouchableOpacity
                                  onPress={this._onPressDienTichHandle.bind(this)}>
                    <View style={myStyles.searchFilterAttribute}>
                        <Text style={myStyles.searchAttributeLabel}>
                            Diện tích
                        </Text>

                        <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                            <ScalableText style={myStyles.searchAttributeValue}>{this.props.getDienTichValue()} </ScalableText>
                            <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
                {this._renderDienTichPicker()}
                <Toast
                    ref="toastErea"
                    position='top'
                    positionValue={0}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
            </View>
        );
    }

    _renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder, onTextChange, onTextFocus,
                     pickerSelectedValue, onPickerValueChange, onPress, inputLabel, fromValue, toValue, unitText) {
        return (
            <PickerExt pickerRange={pickerRange} rangeStepValues={rangeStepValues} fromPlaceholder={fromPlaceholder}
                       toPlaceholder={toPlaceholder} onTextChange={onTextChange} onTextFocus={onTextFocus}
                       pickerSelectedValue={pickerSelectedValue} onPickerValueChange={onPickerValueChange}
                       onPress={onPress} inputLabel={inputLabel} fromValue={fromValue} toValue={toValue}
                       unitText={unitText}/>
        );
    }

    _renderDienTichPicker() {
        var {showDienTich, initDienTich, fromDienTich, toDienTich} = this.props.filterState;
        if (showDienTich) {
            let rangeStepValues = RangeUtils.dienTichRange;
            let pickerRange = rangeStepValues.getAllRangeVal();
            let fromPlaceholder = 'Từ';
            let toPlaceholder = 'Đến';
            let onTextChange = this._onDienTichInputChange.bind(this);
            let onTextFocus = this._onScrollDienTich.bind(this);
            let dienTichRange = rangeStepValues.toValRange(initDienTich);
            let pickerSelectedValue = dienTichRange[0] + '_' + dienTichRange[1];
            let onPickerValueChange = this.props.onDienTichChanged;
            return this._renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder,
                onTextChange, onTextFocus, pickerSelectedValue, onPickerValueChange,
                this._onPressDienTichHandle.bind(this), "m²", String(fromDienTich), String(toDienTich),
                rangeStepValues.getUnitText());
        }
    }

    _onDienTichInputChange(index, val) {
        let {dienTich} = this.props.filterState;
        let newDienTich = [];
        Object.assign(newDienTich, dienTich);
        if (val === '') {
            val = -1;
        } else {
            val = utils.interestNumeric(val);
            if(utils.countDot(val, '\\.') >= 2){
                this.refs.toastErea && this.refs.toastErea.show('Bạn cần điền đúng định dạng số!',DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (val === '.') {
            val = '0.';
        }
        newDienTich[index] = val;
        let other = newDienTich[1-index];
        if (DanhMuc.CHUA_XAC_DINH == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            other = Number(other.substring(0, other.indexOf(" ")));
        } else {
            other = -1;
        }
        newDienTich[1-index] = other;
        // newDienTich.sort((a, b) => a - b);

        let value = RangeUtils.dienTichRange.rangeVal2Display(newDienTich);

        let fromDienTich = newDienTich[0];
        let toDienTich = newDienTich[1];
        if (fromDienTich == -1 || fromDienTich == DanhMuc.BIG) {
            fromDienTich = '';
        }
        if (toDienTich == -1 || toDienTich == DanhMuc.BIG) {
            toDienTich = '';
        }
        this.props.updateSearchFilterState({fromDienTich: fromDienTich, toDienTich: toDienTich, dienTich: value});
    }

    _renderGia() {
        var {showGia} = this.props.filterState;
        var iconName = showGia ? "arrow-up" : "arrow-down";
        return (
            <View>
                <TouchableOpacity
                    onPress={this._onPressGiaHandle.bind(this)}>
                    <View style={myStyles.searchFilterAttribute}>
                        <Text style={myStyles.searchAttributeLabel}>
                            Mức giá
                        </Text>

                        <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                            <ScalableText style={myStyles.searchAttributeValue}> {this.props.getGiaValue()} </ScalableText>
                            <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
                        </View>
                    </View>
                </TouchableOpacity>
                {this._renderGiaPicker()}
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={0}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
            </View>
        );
    }

    _renderGiaPicker() {
        let {loaiTin, showGia, initGia, fromGia, toGia} = this.props.filterState;
        if (showGia) {
            let rangeStepValues = 'ban' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
            let pickerRange = rangeStepValues.getAllRangeVal();
            let fromPlaceholder = 'Từ';
            let toPlaceholder = 'Đến';
            let onTextChange = this._onGiaInputChange.bind(this);
            let onTextFocus = this._onScrollGia.bind(this);
            let giaRange = rangeStepValues.toValRange(initGia);
            let pickerSelectedValue = giaRange[0] + '_' + giaRange[1];
            let onPickerValueChange = this.props.onGiaChanged;
            let inputLabel = 'ban' === loaiTin ? "tỷ" : "triệu";
            return this._renderPickerExt(pickerRange, rangeStepValues, fromPlaceholder, toPlaceholder,
                onTextChange, onTextFocus, pickerSelectedValue, onPickerValueChange,
                this._onPressGiaHandle.bind(this), inputLabel, String(fromGia), String(toGia),
                rangeStepValues.getUnitText());
        }
    }

    _onGiaInputChange(index, val) {
        let {loaiTin} = this.props.filterState;
        let gia = this.props.filterState[loaiTin].gia;
        let rangeStepValues = 'ban' === loaiTin ? RangeUtils.sellPriceRange :RangeUtils.rentPriceRange;
        let newGia = [];
        let newVal = val;
        Object.assign(newGia, gia);
        if (newVal === '') {
            newVal = -1;
        } else {
            newVal = utils.interestNumeric(newVal);
            val = newVal;
            if(utils.countDot(newVal, '\\.') >= 2){
                this.refs.toastTop && this.refs.toastTop.show('Bạn cần điền đúng định dạng số!',DURATION.LENGTH_SHORT);
                return;
            }
        }
        if (newVal === '.') {
            newVal = '0.';
        }
        // let hasLastDot = val[val.length-1] === '.';
        if ('ban' === loaiTin && newVal != -1) {
            newVal = 1000 * newVal;
        }
        // newGia[index] = hasLastDot && 'ban' === loaiTin ? val + '.' : val;
        newGia[index] = newVal;
        let other = String(newGia[1-index]);
        if (DanhMuc.THOA_THUAN == other) {
            other = 0;
        } else if (DanhMuc.BAT_KY == other) {
            other = -1;
        } else if (other && other.indexOf(" ") != -1) {
            if (other.indexOf("tỷ") != -1) {
                other = 1000 * Number(other.substring(0, other.indexOf(" ")));
            } else {
                other = Number(other.substring(0, other.indexOf(" ")));
            }
        } else {
            other = -1;
        }
        newGia[1-index] = other;

        let value = rangeStepValues.rangeVal2Display(newGia);
        this.props.doChangeGia(loaiTin, value);
        let fromGia = newGia[0];
        let toGia = newGia[1];
        // hasLastDot = fromGia[fromGia.length-1] === '.';
        if (fromGia == -1 || fromGia == DanhMuc.BIG) {
            fromGia = '';
        } else if ('ban' === loaiTin) {
            fromGia = fromGia / 1000;
        }
        // fromGia = hasLastDot && 'ban' === loaiTin ? fromGia + '.' : fromGia;
        // hasLastDot = toGia[toGia.length-1] === '.';
        if (toGia == -1 || toGia == DanhMuc.BIG) {
            toGia = '';
        } else if ('ban' === loaiTin) {
            toGia = toGia / 1000;
        }
        // toGia = hasLastDot && 'ban' === loaiTin ? toGia + '.' : toGia;
        if(index == 0) {
            this.props.updateSearchFilterState({fromGia: val, toGia: toGia});
        } else {
            this.props.updateSearchFilterState({fromGia: fromGia, toGia: val});
        }

    }

  _renderSoPhongNgu(){
    if (this.showSoPhongNgu()){
        return this._renderSegment("Số phòng ngủ", DanhMuc.getSoPhongNguValues(),
            this.props.filterState["soPhongNguSelectedIdx"], this.props.onSoPhongNguChanged);
    } else if (0 != this.props.filterState.soPhongNguSelectedIdx) {
        this.props.updateSearchFilterState({soPhongNguSelectedIdx: 0});
    }
      return null;
  }

  _renderSoTang() {
    if (this.showSoTang()){
        return this._renderSegment("Số tầng", DanhMuc.getSoTangValues(),
            this.props.fields["soTangSelectedIdx"], this.props.onSoTangChanged);
    }else if (0 != this.props.fields.soTangSelectedIdx) {
      this.props.onSearchFieldChange("soTangSelectedIdx", 0);
    }
  }

  _renderSoNhaTam() {
    if (this.showSoNhaTam()){
        return this._renderSegment("Số nhà tắm", DanhMuc.getSoPhongTamValues(),
            this.props.fields["soNhaTamSelectedIdx"], this.props.onSoNhaTamChanged);
    }else if (0 != this.props.fields.soNhaTamSelectedIdx) {
      this.props.onSearchFieldChange("soNhaTamSelectedIdx", 0);
    }
      return null;
  }

  _renderBanKinhTimKiem() {
        if (this.showBanKinhTimKiem()){
            return this._renderSegment("Bán kính tìm kiếm (Km)", DanhMuc.getRadiusInKmValues(),
                this.props.filterState["radiusInKmSelectedIdx"], this.props.onBanKinhTimKiemChanged);
        }
        /*
        else if (0 != this.props.filterState.radiusInKmSelectedIdx) {
           this.props.updateSearchFilterState({radiusInKmSelectedIdx: 0});
        }
        */
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                              onChange={onChange} />
        );
    }

  _renderMoreComponent() {
    var {showMore} = this.props.filterState;
    if (!showMore) {
      return (
          <View>
            {this._renderMoreButton()}
              <FullLine />
          </View>
      );
    } else {
      return (
          <View>
            {this._renderHuongNha()}
            <FullLine style={{marginLeft:17}}/>
            {this._renderNgayDaDang()}
            <FullLine />
          </View>
      );
    }
  }

  _renderMoreButton() {
    return (
        <View style={myStyles.searchMoreFilterAttribute}>
          <Button onPress={() => this.props.onMoreOption()} style={myStyles.searchMoreText}>Mở rộng</Button>
        </View>
    );
  }

  _renderHuongNha() {
    return (
        <TouchableOpacity
            onPress={() => this.props.onHuongNhaPressed()}>
          <View style={myStyles.searchFilterAttributeExt3}>
            <Text style={myStyles.searchAttributeLabel}>
              Hướng nhà
            </Text>
            <View style={{flexDirection: "row", alignItems: "flex-end"}}>
              <ScalableText style={myStyles.searchAttributeValue}> {this.props.getHuongNhaValue()} </ScalableText>
              <TruliaIcon name="arrow-right" color={gui.arrowColor} size={18} />
            </View>
          </View>
        </TouchableOpacity>
    );
  }

    _renderImageFilter() {
        return (
            <View
                style={[myStyles.headerSeparator, { paddingTop: 12, marginBottom: 10, marginLeft: 17, paddingLeft: 0 }]}>
                <TouchableOpacity
                    onPress={() => this._onImageFilterPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]}>
                        <Text style={myStyles.searchAttributeLabel}>
                            Tin có ảnh
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <TruliaIcon name={"check"}
                                        onPress={() => this._onImageFilterPressed()}
                                        color={this.props.fields.hasImage ? gui.mainColor : gui.arrowColor}
                                        size={18}/>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onImageFilterPressed() {
        let hasImage = !this.props.fields.hasImage || undefined;
        this.props.onSearchFieldChange("hasImage", hasImage);
    }

    _renderMoiGioiFilter() {
        return (
            <View
                style={[myStyles.headerSeparator, { paddingTop: 12, marginBottom: 10, marginLeft: 17, paddingLeft: 0 }]}>
                <TouchableOpacity
                    onPress={() => this._onMoiGioiFilterPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]}>
                        <View style={{marginRight:10, width:width-60}}>
                            <Text numberOfLines={2} style={myStyles.searchAttributeLabel}>
                                Bỏ tin đăng của môi giới đề xuất bởi Landber                            
                            </Text>
                        </View>
                        <View style={myStyles.arrowIcon}>
                            <TruliaIcon name={"check"}
                                        onPress={() => this._onMoiGioiFilterPressed()}
                                        color={this.props.fields.excludeMoiGioi ? gui.mainColor : gui.arrowColor}
                                        size={18}/>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onMoiGioiFilterPressed() {
        let excludeMoiGioi = !this.props.fields.excludeMoiGioi || undefined;
        this.props.onSearchFieldChange("excludeMoiGioi", excludeMoiGioi);
    }

    _renderFakeGeoFilter() {
        return (
            <View
                style={[myStyles.headerSeparator, { paddingTop: 12, marginBottom: 10, marginLeft: 17, paddingLeft: 0 }]}>
                <TouchableOpacity
                    onPress={() => this._onFakeGeoFilterPressed()}>
                    <View style={[myStyles.imgList, { paddingLeft: 0 }]}>
                        <Text style={myStyles.searchAttributeLabel}>
                            Tin có vị trí đã xác thực
                        </Text>
                        <View style={myStyles.arrowIcon}>
                            <TruliaIcon name={"check"}
                                        onPress={() => this._onFakeGeoFilterPressed()}
                                        color={this.props.fields.isFakeGeo == undefined ? gui.arrowColor : gui.mainColor}
                                        size={18}/>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onFakeGeoFilterPressed() {
        let isFakeGeo = this.props.fields.isFakeGeo == undefined ? false : undefined;
        this.props.onSearchFieldChange("isFakeGeo", isFakeGeo);
    }

  _renderNgayDaDang() {
    var {showNgayDaDang} = this.props.filterState;
    var iconName = showNgayDaDang ? "arrow-up" : "arrow-down";
    return (
        <View>
          <TouchableOpacity
                            onPress={() => this._onPressNgayDaDangHandle()}>
            <View style={myStyles.searchFilterAttribute3}>
              <Text style={myStyles.searchAttributeLabel}>
                Ngày đã đăng
              </Text>

              <View style={{flexDirection: "row", alignItems: "flex-end"}}>
                <ScalableText style={myStyles.searchAttributeValue}> {this.props.getNgayDaDangValue()} </ScalableText>
                <TruliaIcon name={iconName} color={gui.arrowColor} size={18} />
              </View>
             </View>
          </TouchableOpacity>
          {this._renderNgayDaDangPicker()}
        </View>
    );
  }

  _renderNgayDaDangPicker() {
    var {showNgayDaDang, initNgayDaDang, inputNgayDaDang} = this.props.filterState;
    if (showNgayDaDang) {
        let pickerRange = DanhMuc.getNgayDaDangValues();
        let inputPlaceholder = '';
        let onTextChange = this.props.onNgayDaDangInputChange;
        let onTextFocus = this._onScrollNgayDaDang.bind(this);
        let pickerSelectedValue = initNgayDaDang;
        let inputTextValue = inputNgayDaDang ? String(inputNgayDaDang) : '';
        let onPickerValueChange = this.props.onNgayDaDangChanged;
        let val2Display = this._ngayDaDangVal2Display.bind(this);
        let onPress = this._onPressNgayDaDangHandle.bind(this);
        let inputLabel = 'ngày';
        return <PickerExt2 pickerRange={pickerRange} val2Display={val2Display} inputPlaceholder={inputPlaceholder}
                   inputValue={inputTextValue} onTextChange={onTextChange} onTextFocus={onTextFocus}
                   pickerSelectedValue={pickerSelectedValue} onPickerValueChange={onPickerValueChange}
                   onPress={onPress} inputLabel={inputLabel} />
    }
  }

  _ngayDaDangVal2Display(ngayDaDangKey) {
      return DanhMuc.NgayDaDang[ngayDaDangKey];
  }

  showSoPhongNgu(){
    var {loaiTin} = this.props.filterState;
    var loaiNhaDat = this.props.filterState[loaiTin].loaiNhaDat;
    var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
      if (loaiNhaDat == loaiNhaDatKeys[0]
      || loaiNhaDat == loaiNhaDatKeys[1]
      || loaiNhaDat == loaiNhaDatKeys[2]
      || loaiNhaDat == loaiNhaDatKeys[3]
      || loaiNhaDat == loaiNhaDatKeys[4]) {
          return true;
      } else {
          return false;
      }
  }

  showSoTang(){
    return false;
  }

  showSoNhaTam(){
      var {loaiTin} = this.props.filterState;
      var loaiNhaDat = this.props.filterState[loaiTin].loaiNhaDat;
      var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
      if (loaiNhaDat == loaiNhaDatKeys[0]
          || loaiNhaDat == loaiNhaDatKeys[1]
          || loaiNhaDat == loaiNhaDatKeys[2]
          || loaiNhaDat == loaiNhaDatKeys[3]
          || loaiNhaDat == loaiNhaDatKeys[4]) {
          return true;
      } else {
          return false;
      }
  }

  showBanKinhTimKiem(){
      // let {center} = this.props.fields;
      // return center && !isNaN(center.lat);
      return false;
  }
}

/**
 * ## Styles
 */
var myStyles = StyleSheet.create({
  fullWidthContainer: {
    flexGrow: 1,
    alignItems: 'stretch',
    backgroundColor: 'white'
  },
  pageHeader: {
      top: 0,
      position: 'absolute',
      alignItems: 'stretch',
      justifyContent: 'center',
      backgroundColor: 'white',
      width: width,
      height: 60
  },
  // searchAttributeLabelBold : {
  //   fontSize: gui.normalFontSize,
  //   fontFamily: gui.fontFamily,
  //   color: 'black',
  //   fontWeight: 'bold'
  // },

  searchButton: {
      alignItems: 'center',
      justifyContent: 'flex-end',
      position: 'absolute',
      bottom: 0,
      height: 45,
      width: width
  },
  searchButtonWrapper: {
      backgroundColor: "#EB4221",
      height: 40,
      width: width-20,
      borderRadius: 5,
      marginBottom: 5
  },
  searchButtonText: {
      marginLeft: 17,
      marginRight: 17,
      marginTop: 10,
      marginBottom: 10,
      color: 'white',
      fontSize: gui.buttonFontSize,
      fontFamily: gui.fontFamily,
      fontWeight : '500'
  },
  searchButtonText2: {
      margin: 0,
      padding: 10,
      paddingRight: 17,
      color: 'white',
      fontSize: gui.buttonFontSize,
      fontFamily: gui.fontFamily,
      fontWeight : 'normal'
  },
  searchMoreFilterButton: {
    flexGrow: 0.5,
    alignItems: 'stretch',
    justifyContent: 'center'
  },
  searchMoreSeparator: {
    backgroundColor: '#F6F6F6'
  },
  searchResetText: {
    color: 'red',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  searchMoreText: {
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: gui.mainColor
  },
  searchAttributeLabel : {
    fontSize: gui.normalFontSize,
    fontFamily: gui.fontFamily,
    color: 'black'
  },
  searchAttributeValue : {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: gui.arrowColor,
    marginRight: 3
  },
  searchFilterButton: {
    flexDirection: 'column'
  },
  searchFilter: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0
  },
  searchSectionTitle: {
    flexDirection : "row",
    //borderWidth:1,
    //borderColor: "red",
    justifyContent :'space-between',
    paddingRight: 8,
    paddingLeft: 17,
    paddingTop: 8,
    paddingBottom: 8,
    // borderTopWidth: 1,
    // borderTopColor: '#f8f8f8',
    backgroundColor: '#f8f8f8'
  },
  searchFilterDetail: {
    flexGrow: 0,
    flexDirection:"column"
    //borderWidth:1,
    //borderColor: "green"
  },
  scrollView: {
    flex: 1,
    height: height-210
  },
  scrollView2: {
    flex: 1
  },
  cacDieuKienText: {
    fontSize: 12,
    fontFamily: gui.fontFamily,
    color: '#606060',
    justifyContent :'space-between',
    padding: 0,
    borderTopWidth: 0,
    borderTopColor: gui.separatorLine
  },
  searchFilterAttribute: {
    flexDirection : "row",
    //borderWidth:1,
    //borderColor: "red",
    justifyContent :'space-between',
    paddingTop: 10,
    paddingLeft: 0,
    paddingRight: 13,
    paddingBottom: 10,
    borderTopWidth: 0,
    marginLeft: 17,
    borderTopColor: gui.separatorLine
  },
  // searchFilterAttribute2: {
  //   flexDirection : "row",
  //   borderWidth:1,
  //   borderColor: "red",
  //   justifyContent :'space-between',
  //   paddingRight: 8,
  //   paddingTop: 5,
  //   paddingLeft: 17,
  //   paddingBottom: 7,
  //   borderTopWidth: 0,
  //   borderTopColor: gui.separatorLine
  // },
  searchFilterAttribute3: {
    flexDirection : "row",
    //borderWidth:1,
    //borderColor: "red",
    justifyContent :'space-between',
    paddingTop: 10,
    paddingLeft: 17,
    paddingRight: 13,
    paddingBottom: 10,
    borderTopWidth: 0,
    borderTopColor: gui.separatorLine
  },
  searchFilterAttributeExt: {
    flexDirection : "row",
    //borderWidth:1,
    //borderColor: "red",
    justifyContent :'space-between',
    paddingTop: 12,
    paddingLeft: 0,
    paddingRight: 19,
    paddingBottom: 10,
    borderTopWidth: 0,
    marginLeft: 17,
    borderTopColor: gui.separatorLine
  },
  // searchFilterAttributeExt2: {
  //   flexDirection : "row",
  //   borderWidth:1,
  //   borderColor: "red",
  //   justifyContent :'space-between',
  //   paddingRight: 10,
  //   paddingTop: 5,
  //   paddingLeft: 0,
  //   paddingBottom: 8,
  //   borderTopWidth: 0,
  //   marginLeft: 17,
  //   borderTopColor: gui.separatorLine
  // },
  searchFilterAttributeExt3: {
    flexDirection : "row",
    //borderWidth:1,
    //borderColor: "red",
    justifyContent :'space-between',
    paddingTop: 12,
    paddingLeft: 17,
    paddingRight: 19,
    paddingBottom: 10,
    borderTopWidth: 0,
    borderTopColor: gui.separatorLine
  },
  searchMoreFilterAttribute: {
    padding: 10,
    paddingBottom: 11,
    borderTopWidth: 0,
    borderTopColor: gui.separatorLine
  },
  // ngayDaDangItem: {
  //   fontSize: gui.normalFontSize,
  //   fontFamily: gui.fontFamily
  // },
  addViewBottom: {
    height:30,
    width:width,
    backgroundColor:'#fff'
  },
    arrowIcon: {
        flexDirection: "row",
        alignItems: "flex-end",
        paddingRight: 4
    },
    headerSeparator: {
        marginTop: 0,
        borderTopWidth: 0,
        borderTopColor: gui.separatorLine
    },
    imgList: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: 17,
        paddingRight: 10,
        backgroundColor: 'white'
    }
});

export default SearchFilter2;
