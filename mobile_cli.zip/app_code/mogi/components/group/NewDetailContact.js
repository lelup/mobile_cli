import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    ImageBackground,
    Alert,
    RefreshControl
} from 'react-native';

import Modal from 'react-native-modalbox';
import GiftedSpinner from "../GiftedSpinner";
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Actions } from 'react-native-router-flux';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import OfflineBar from '../line/OfflineBar';
let Analytics = require('react-native-firebase-analytics');

import CheckDot from '../detail/CheckDot';
import FontAwesomeLight from '../font/FontAwesomeLight'
import FontAwesomeSolid from '../font/FontAwesomeSolid'
import TapContact from './TapContact';
import ContactHistory from './ContactHistory';
import ContactWishList from './ContactWishList';
import ContactAdsViewed from './ContactAdsViewed';
import ContactNote from './ContactNote';
import ContactMore from './ContactMore';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import Communications from '../detail/MCommunications';
import FullLine from '../line/FullLine';
import DanhMuc from '../../assets/DanhMuc';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import SelectableSectionsListView from '../myalphabetlistview/SelectableSectionsListView';
import FunctionModal from '../FunctionModal';
import CallDetectorManager from 'react-native-call-detection'


let { width, height } = utils.getDimensions();
let text = '';

const TAP_MENU = {
    history: 'history',
    demand: 'demand',
    viewed: 'viewed',
    noted: 'noted',
    more: 'more'
};

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var callDetector = undefined

class NewDetailContact extends Component {
    constructor(props) {
        super(props);
        let initDataToRender = this._prepareDataToRender();
        let contactSaleState = props.groupContact.selectedContact.contactSaleState;
        this.state = {
            contactOrder: 'history',
            isFavorited: props.groupContact.selectedContact.favorite == 1,
            isOpenMoreModal: false,
            isOpenLevelModal: false,
            contactSaleState: contactSaleState,
            dataToRender: initDataToRender,
            isListening: false,
            callControl: 'none',
            callTimeControl: null,
        }

    }

    componentWillReceiveProps(nextProps) {
        if (this.props.groupContact.selectedContact !== nextProps.groupContact.selectedContact) {
            this.setState({ isFavorited: nextProps.groupContact.selectedContact.favorite });
        }

        // if (nextProps.forceUpdate !== this.props.forceUpdate) {
        //     console.log('bachtv forceupdtea *************', nextProps.forceUpdate)
        //     this.forceUpdate();
        // }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return 1 == 1;
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeader()}
                {/*<FullLine />*/}
                {/*{this._renderContentTop()}*/}
                {/*{this._renderTapContent()}*/}
                {this._renderBody()}
                {/* {this._openMoreCommentModal()} */}
                {this._openMoreModal()}
                {this._openLevelModal()}
                {this._renderLoadingView()}

            </View>
        )
    }

    outModalMore() {
        this.setState({
            isOpenMoreModal: false,
            isOpenLevelModal: false
        });
    }

    _openMoreModal() {
        let modalHeight = 169;
        return (
            <Modal isOpen={this.state.isOpenMoreModal}
                onClosed={this.outModalMore.bind(this)}
                style={[styles.viewModalStyle, { height: 'auto' }]}
                position={"bottom"}
                swipeToClose={false}
                backdropPressToClose={true}
                animationDuration={200}
            >
                {this._renderMoreContent()}
            </Modal>
        );
    }

    _openLevelModal() {
        return (
            <Modal isOpen={this.state.isOpenLevelModal}
                onClosed={this.outModalMore.bind(this)}
                style={styles.viewModalShareAds}
                position={"center"}
                swipeToClose={false}
                animationDuration={200}
            >
                {this._renderLevelContent()}
            </Modal>
        );
    }

    _renderLevelContent() {

        let saleStateItems = [];
        let sateStateKeys = Object.keys(DanhMuc.contactSaleState);
        sateStateKeys.forEach((saleState) => {
            let hiddenType = DanhMuc.contactSaleState[saleState];

            saleStateItems.push(
                <View key={saleState}>
                    <TouchableOpacity style={styles.viewShareContent}
                        onPress={this.changLevelContact.bind(this, saleState)}
                    >
                        <View style={styles.checkAds}>
                            <CheckDot name={saleState}
                                selected={this.state.contactSaleState == saleState}
                                mainProps={styles.viewSaleState}></CheckDot>
                        </View>
                        <Text style={[styles.textTypePost, {
                            color: 'rgba(54,54,54,1)',
                            fontSize: 15,
                            marginLeft: 8
                        }]}>{hiddenType}</Text>

                    </TouchableOpacity>
                    <FullLine style={{ marginLeft: 16 }} />
                </View>
            );
        });
        return (
            <View style={styles.viewShareAds}>
                <View style={styles.viewShareTitle}>
                    <Text style={[styles.textTypePost, { color: 'rgba(54,54,54,1)', fontSize: 15 }]}>Đánh giá tiềm
                        năng</Text>
                </View>
                <FullLine />
                {saleStateItems}
            </View>
        )
    }

    changLevelContact(newSaleState) {
        // log.info('=========> changLevelContact', data);
        this.setState({ contactSaleState: newSaleState });

        let selectedContact = this.props.groupContact.selectedContact;
        if (!selectedContact) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let token = this.props.global.currentUser.token || undefined;
        let dto = {
            contactID: selectedContact.id,
            userID: userID,
            contactSaleState: newSaleState
        };
        this.props.actions.changeLevelContact(dto, token)
            .then(res => {
                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                        }
                    }]);
                } else {
                    selectedContact.contactSaleState = newSaleState;
                    this.props.actions.onGroupContactFieldChange('selectedContact', selectedContact)

                    let contactList = this.props.groupContact.contactList;
                    contactList.forEach((e) => {
                        if (e.id == selectedContact.id)
                            e.contactSaleState = newSaleState
                    });
                    this.props.actions.onGroupContactFieldChange('contactList', contactList.slice(0))
                }
                this.outModalMore()
            });
    }

    _renderMoreContent() {
        let items = [
            { _text: 'Sửa liên hệ', _function: () => this._onEditButton() },
            { _text: 'Xóa liên hệ', _function: () => this._onDeleteButton() },
        ]
        return (
            <FunctionModal
                // data={data}
                items={items}
                onCloseModal={this.outModalMore.bind(this)} />
        )
    }

    _prepareDataToRender(data) {
        let dataToRender = {};

        //prepare header section
        dataToRender['headerSection'] = [{ header: 'header' }];

        //prepare content section
        let sectionData = [];
        sectionData.push({
            meta: 'contactinfo',
            contactData: this.props.groupContact.selectedContact,
            contactID: this.props.groupContact.selectedContact.id,
        });

        [].forEach((e) => {
            sectionData.push(e)
        });
        dataToRender['contentSection'] = sectionData;

        return dataToRender;
    }

    // _openMoreCommentModal() {
    //     let { commentViewed } = this.props.groupContact;
    //     return (
    //         <Modal isOpen={this.props.groupContact.openCommentViewed}
    //             onClosed={this._outMoreModal.bind(this)}
    //             style={styles.viewModalStyle}
    //             position={"bottom"}
    //             swipeToClose={false}
    //             animationDuration={200}
    //         >
    //             <View style={styles.viewModalContent}>
    //                 <Text style={styles.textComment} numberOfLines={8}>{commentViewed}</Text>
    //             </View>
    //         </Modal>
    //     );
    // }

    _outMoreModal() {
        this.props.actions.onGroupContactFieldChange('openCommentViewed', false);
        this.props.actions.onGroupContactFieldChange('commentViewed', '');
    }

    _renderHeader() {
        let dataToRender = this.props.groupContact.selectedContact;
        let phone = dataToRender.contactPhone;
        let email = dataToRender.contactEmail;
        let favoriteIcon = this.state.isFavorited ? 'star' : 'star-outline';
        return (
            <View style={styles.viewHeader}>
                <TouchableOpacity style={styles.viewIconLeft}
                    onPress={this._onBackPress.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor}
                        style={{ marginBottom: 3 }} />
                </TouchableOpacity>
                <View style={styles.viewIconsHeader}>
                    <TouchableOpacity onPress={this._onFavorite.bind(this, phone)}
                        style={styles.startButton}
                    >
                        {this.state.isFavorited ?
                            <FontAwesomeSolid name={'star'}
                                size={21}
                                color={'rgba(255,207,86,1)'}
                                noAction={true}
                                iconOnly={true}
                                mainProps={{ marginBottom: 18 }}
                            /> :
                            < FontAwesomeLight name={'star'}
                                size={21}
                                color={'rgba(255,207,86,1)'}
                                noAction={true}
                                iconOnly={true}
                                mainProps={{ marginBottom: 18 }}
                            />
                        }
                    </TouchableOpacity>
                    <TouchableOpacity onPress={this._onMoreFunction.bind(this)}
                        style={styles.startButton}
                    >
                        <FontAwesomeSolid name={'ellipsis-v'}
                            size={22}
                            color={gui.mainAgentColor}
                            noAction={true}
                            iconOnly={true}
                            mainProps={{ marginBottom: 17 }} />
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _onFavorite() {
        this.setState({ isFavorited: !this.state.isFavorited });
        let selectedContact = this.props.groupContact.selectedContact;
        if (!selectedContact) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let token = this.props.global.currentUser.token || undefined;
        let newFavorite = selectedContact.favorite == 1 ? 0 : 1;
        let dto = {
            contactID: selectedContact.id || selectedContact.contactID,
            userID: userID,
            favorite: newFavorite
        };
        this.props.actions.favoriteContact(dto, token)
            .then(res => {

                if (res.status != 0) {
                    Alert.alert("Thông báo", res.msg, [{
                        text: 'Đóng', onPress: () => {
                        }
                    }]);
                } else {
                    selectedContact.favorite = newFavorite;
                    this.props.actions.onGroupContactFieldChange('selectedContact', selectedContact);

                    let contactList = this.props.groupContact.contactList;
                    contactList.forEach((e) => {
                        if (e.id == selectedContact.id)
                            e.favorite = newFavorite
                    });

                    this.props.actions.onGroupContactFieldChange('contactList', contactList.slice(0))
                }
            });
    }

    _onMoreFunction() {
        log.info('================> _onMoreFunction');
        this.setState({ isOpenMoreModal: true });
    }

    _renderHeaderOld() {
        let contactName = this.props.groupContact.selectedContact.contactName;
        return (
            <View style={styles.viewHeader}>
                <TouchableOpacity style={styles.viewIconLeft}
                    onPress={this._onBackPress.bind(this)}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor}
                        style={{ marginLeft: 0 }} />
                </TouchableOpacity>
                <View style={styles.viewTextProfile}>
                    <Text style={styles.textProfile}>{contactName}</Text>
                </View>
                <TouchableOpacity onPress={this._onEditButton.bind(this)} style={styles.viewTextLeft}>
                    <Text style={styles.textCommon}>Sửa</Text>
                </TouchableOpacity>
            </View>
        )
    }

    _renderContentTop() {
        let dataToRender = this.props.groupContact.selectedContact;

        let myAvatar = dataToRender.avatar || dataToRender.zaloAvatar;
        let uriAvatar = { uri: myAvatar };
        let defaultSource = require('../../assets/image/register_avatar_icon.png');

        let name = dataToRender.contactName;
        let level = DanhMuc.contactSaleState[dataToRender.contactSaleState];
        let phone = dataToRender.contactPhone;
        let email = dataToRender.contactEmail;
        let nameDefault = utils.geDefaultName(dataToRender.contactName);
        let nameColor = utils.getNameColor(nameDefault);
        let levelColor = this.getLevelTextColor(level);

        return (
            <View style={styles.viewTopBody}>
                <View style={styles.imageTopCover}>
                    <View style={styles.viewTopAvt} />
                    <TouchableOpacity style={styles.touchImageAvt} onPress={this._onEditButton.bind(this)}>
                        {myAvatar && myAvatar.length > 0 ?
                            <Image
                                source={uriAvatar}
                                style={styles.myTopAvatar}
                                defaultSource={defaultSource}>
                            </Image> :
                            <View style={styles.dotAvatar}>
                                <Text style={[styles.textSort, { color: nameColor, fontSize: 17, fontWeight: '600' }]}>{nameDefault}</Text>
                            </View>
                        }
                    </TouchableOpacity>
                    <View style={[styles.viewTopAvt, { backgroundColor: 'rgba(246,246,246,1)', borderBottomWidth: 0 }]} />
                </View>
                <View style={styles.viewTopLeftBody}>
                    <View style={[styles.viewNameTop, { width: width - 170, height: 18, marginTop: 15 }]}>
                        <Text numberOfLines={1} style={styles.textNameTop}>{name}</Text>
                    </View>
                    <View style={[styles.viewNameTop, { width: width, height: 16 }]}>
                        {this._renderPhoneEmail(phone, email)}
                    </View>
                    <TouchableOpacity
                        onPress={this.changeLevelContact.bind(this)}
                        style={[styles.viewNameTop, { width: width - 170, height: 16, flexDirection: 'row' }]}>
                        <Text style={[styles.textLevelTop, { color: levelColor, marginTop: 3, marginRight: 4 }]}>{level}</Text>
                        <FontAwesomeSolid name="caret-down" size={15} color={levelColor} noAction={true} iconOnly={true} />
                    </TouchableOpacity>
                </View>

                <View style={styles.viewIconsHeader2}>

                    <TouchableOpacity style={[styles.viewItemsButton, { marginLeft: 0 }]}
                        onPress={this._onPhoneCall.bind(this, phone)}>
                        <View style={styles.viewButtonActions}>
                            <FontAwesomeSolid name="phone" size={21} color={'#fff'} noAction={true} iconOnly={true} />
                        </View>
                        <Text style={styles.textButton}>Gọi</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewItemsButton, { marginLeft: 0 }]}
                        onPress={this._onSms.bind(this, phone)}>
                        <View style={styles.viewButtonActions}>
                            <FontAwesomeSolid name="comment" size={21} color={'#fff'} noAction={true}
                                iconOnly={true} />
                        </View>
                        <Text style={styles.textButton}>Nhắn tin</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.viewItemsButton, { marginLeft: 0 }]}
                        onPress={this._onEmail.bind(this, email)}>
                        <View style={styles.viewButtonActions}>
                            <FontAwesomeSolid name="envelope" size={21} color={'#fff'} noAction={true} iconOnly={true} />
                        </View>
                        <Text style={styles.textButton}>Gửi email</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    changeLevelContact() {
        this.setState({
            isOpenLevelModal: true
        })
    }

    getLevelTextColor(value) {
        let colorLevel = DanhMuc.contactTextLevel[value];
        return colorLevel;
    }

    _renderPhoneEmail(phone, email) {
        if (phone && email)
            return (
                <View style={styles.viewNameTop}>
                    <View style={styles.viewTextPhone}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{phone}</Text>
                    </View>
                </View>
            );
        if (phone && !email)
            return (
                <View style={styles.viewNameTop}>
                    <View style={styles.viewTextPhone}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{phone}</Text>
                    </View>
                </View>
            );

        if (!phone && email)
            return (
                <View style={styles.viewNameTop}>
                    <View style={styles.viewTextPhone}>
                        <Text style={styles.textPhoneTop} numberOfLines={1}>{email}</Text>
                    </View>
                </View>
            )
    }

    _renderContentTopOld() {
        let dataToRender = this.props.groupContact.selectedContact;

        let myAvatar = dataToRender.avatar;
        let uriAvatar = { uri: myAvatar };
        let defaultSource = require('../../assets/image/register_avatar_icon.png');

        let name = dataToRender.contactName;
        let level = DanhMuc.contactSaleState[dataToRender.contactSaleState];
        let phone = dataToRender.contactPhone;
        let email = dataToRender.contactEmail;
        return (
            <View style={styles.viewContentTop}>
                <View style={styles.viewDetailTop}>
                    <View style={styles.imageCover}>
                        <Image
                            source={uriAvatar}
                            style={styles.myAvatar}
                            defaultSource={defaultSource}
                        />
                    </View>
                    <View style={styles.viewDetailText}>
                        <Text style={[styles.textCommon, styles.textLevel]}>{level}</Text>
                        {phone ? <Text style={styles.textPhone}>{phone}</Text> : null}
                        {email ? <Text style={[styles.textPhone, { marginTop: 0 }]}>{email}</Text> : null}
                    </View>
                    <View style={styles.viewIconContact}>
                        <TouchableOpacity onPress={this._onSms.bind(this, phone)} style={styles.touchIconChild}>
                            <View style={styles.viewIconMessage}>
                                <FontAwesome name="comment" size={16} color={'#fff'} />
                            </View>
                            {/*<Text style={styles.textIcon}>sms</Text>*/}
                        </TouchableOpacity>
                        <TouchableOpacity onPress={this._onPhoneCall.bind(this, phone)}
                            style={[styles.touchIconChild, { marginLeft: 32 }]}>
                            <View style={styles.viewIconMessage}>
                                <FontAwesome name="phone" size={19} color={'#fff'} />
                            </View>
                            {/*<Text style={styles.textIcon}>call</Text>*/}
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.touchIconChild, { marginLeft: 32 }]}>
                            <View style={styles.viewIconMessage}>
                                <FontAwesome name="video-camera" size={16} color={'#fff'} />
                            </View>
                            {/*<Text style={styles.textIcon}>video call</Text>*/}
                        </TouchableOpacity>
                    </View>
                </View>
                <FullLine />
            </View>
        )
    }

    startListenerTapped() {
        let currentUser = this.props.global.currentUser;
        let selectedContact = this.props.groupContact.selectedContact;
        if (this.state.isListening == false) {
            callDetector = new CallDetectorManager((event, phoneNumber) => {
                // For iOS event will be either "Connected",
                // "Disconnected","Dialing" and "Incoming"

                // For Android event will be either "Offhook",
                // "Disconnected", "Incoming" or "Missed"

                // if (number == selectedContact.contactPhone) {
                if (event === 'Disconnected') {
                    // Alert.alert("Thông báo", 'Disconnected!');
                    if (this.state.callControl == 'connected') {
                        let currentTime = new Date().getTime();
                        let duration = this.state.callTimeControl ? currentTime - this.state.callTimeControl : 0;
                    }
                    if (this.state.callControl == 'dialing') {
                        let historyDto = {
                            content: 'Cuộc gọi nhỡ',
                            contactID: selectedContact.id,
                            toPhone: phoneNumber,
                            // toEmail: ,
                            userID: currentUser.userID,
                            eventType: 'phoneDisconnected'
                        }
                        this.props.actions.createHistory(historyDto, currentUser.token).then(res => { });
                    }
                    this.setState({
                        callControl: 'none',
                        callTimeControl: null
                    })
                }
                else if (event === 'Connected') {
                    // This clause will only be executed for iOS
                    if (this.state.callControl == 'dialing') {
                        this.setState({ callControl: 'connected' })
                        this.setState({ callTimeControl: new Date().getTime() });
                        let historyDto = {
                            content: 'Cuộc gọi đi',
                            contactID: selectedContact.id,
                            toPhone: phoneNumber,
                            // toEmail: ,
                            userID: currentUser.userID,
                            eventType: 'phoneConnected'
                        }
                        this.props.actions.createHistory(historyDto, currentUser.token).then(res => { });
                    }
                }
                else if (event === 'Incoming') {
                    // Alert.alert("Thông báo", 'Incoming!');                        
                }
                else if (event === 'Dialing') {
                    this.setState({ callControl: 'dialing' })                    
                }
                /*
                else if (event === 'Offhook') {
                    //Device call state: Off-hook. 
                    // At least one call exists that is dialing,
                    // active, or on hold, 
                    // and no calls are ringing or waiting.
                    // This clause will only be executed for Android
                }
                else if (event === 'Missed') {
                    // Do something call got missed
                    // This clause will only be executed for Android
                }
                */
                // }
            },
                false, // if you want to read the phone number of the incoming call [ANDROID], otherwise false
                () => { }, // callback if your permission got denied [ANDROID] [only if you want to read incoming number] default: console.error
                {
                    title: 'Phone State Permission',
                    message: 'This app needs access to your phone state in order to react and/or to adapt to incoming calls.'
                } // a custom permission request message to explain to your user, why you need the permission [recommended] - this is the default one
            )
            this.setState({
                isListening: true,
            });
        }
    }

    stopListenerTapped() {
        this.setState({
            isListening: false,
            callControl: 'none',
            callTimeControl: null
        });
        callDetector && callDetector.dispose();
    }

    _onPhoneCall(phoneNumber) {
        this.startListenerTapped();
        if (!phoneNumber) {
            return;
        }
        Communications.phonecall(phoneNumber, true);
        setTimeout(() => {
            this.stopListenerTapped();
        }, 10 * 60 * 1000)
    }

    _onSms(phone) {
        let bodyText = `${text}`;
        if (!phone) {
            return;
        }
        Communications.text(phone, bodyText);
        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        Analytics.logEvent('DETAIL_SENDSMS', {
            deviceID: deviceID,
            userID: userID,
            adsID: this.props.adsID,
            phone: phone
        });
        let historyDto = {
            content: 'Gửi tin nhắn sms',
            contactID: this.props.groupContact.selectedContact.id,
            toPhone: phone,
            // toEmail: ,
            userID: userID,
            eventType: 'sms'
        }
        this.props.actions.createHistory(historyDto, this.props.global.currentUser.token).then(res => { });
    }

    _onEmail(email) {
        if (!email)
            return;

        let bodyText = `Xin chào!`;
        let subject = `Chào bạn`;
        Communications.email([email], null, null, subject, bodyText);
        let historyDto = {
            content: 'Gửi email',
            contactID: this.props.groupContact.selectedContact.id,
            // toPhone: phone,
            toEmail: email,
            userID: this.props.global.currentUser.userID,
            eventType: 'email'
        }
        this.props.actions.createHistory(historyDto, this.props.global.currentUser.token).then(res => { });
    }

    _renderTapContent() {
        return (
            <View style={styles.tapContent}>
                <FullLine />
                <View style={styles.viewEachTap}>
                    <ScrollView horizontal={true}
                        showsHorizontalScrollIndicator={false}>
                        <TapContact name={TAP_MENU.history}
                            onPress={this._onTypeOrder.bind(this)}
                            selected={this.state.contactOrder == TAP_MENU.history}
                            stylesButton={{ marginLeft: 0 }}>Lịch sử</TapContact>
                        <TapContact name={TAP_MENU.demand}
                            onPress={this._onTypeOrder.bind(this)}
                            selected={this.state.contactOrder == TAP_MENU.demand}
                            stylesButton={{ marginLeft: 5 }}>Nhu cầu</TapContact>
                        <TapContact name={TAP_MENU.viewed}
                            onPress={this._onTypeOrder.bind(this)}
                            selected={this.state.contactOrder == TAP_MENU.viewed}
                            stylesButton={{ marginLeft: 5 }}>Nhà đã xem</TapContact>
                        <TapContact name={TAP_MENU.noted}
                            onPress={this._onTypeOrder.bind(this)}
                            selected={this.state.contactOrder == TAP_MENU.noted}
                            stylesButton={{ marginLeft: 5 }}>Ghi chú</TapContact>
                        <TapContact name={TAP_MENU.more}
                            onPress={this._onTypeOrder.bind(this)}
                            selected={this.state.contactOrder == TAP_MENU.more}
                            stylesButton={{ marginLeft: 5 }}>Mở rộng</TapContact>
                    </ScrollView>
                </View>
                <FullLine />
                {/*<View style={{flex: 1, backgroundColor: '#fff'}}>
                    {this._renderDetailContent()}
                </View>*/}
            </View>
        )
    }

    _renderLoadingView() {
        if (this.props.groupContact.loadingContactWto || this.props.groupContact.loadingMatchingAds || this.props.groupContact.loadingContactRespond) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _onDeleteButton() {
        this._outMoreModal();
        this.outModalMore();
        let data = this.props.groupContact.selectedContact;
        Alert.alert('Thông báo', 'Bạn có muốn xóa liên hệ này không?',
            [{ text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
            { text: 'Đồng ý', onPress: () => this._doDeleteContact(data) }
            ]);
    }

    _doDeleteContact(row) {
        let id = row.id || row.contactID;
        let dto = {
            userID: this.props.global.currentUser.userID,
            id: id
        };
        let token = this.props.global.currentUser.token
        this.props.actions.deleteContact(dto, token).then((e) => {
            if (e.status != 0) {
                Alert.alert("Thông báo", 'Xóa liên hệ không thành công!');
            } else {
                Actions.pop();
            }
        });
    }

    _onEditButton() {
        this._outMoreModal();
        this.outModalMore();
        if (!this.props.groupContact.selectedContact) {
            return;
        }
        let userID = this.props.global.currentUser.userID;
        let selectedContact = this.props.groupContact.selectedContact;

        this.props.actions.onGroupContactFieldChange('contactID', selectedContact.id || selectedContact.contactID);
        this.props.actions.onGroupContactFieldChange('contactName', selectedContact.contactName);
        this.props.actions.onGroupContactFieldChange('contactSource', selectedContact.contactSource);
        this.props.actions.onGroupContactFieldChange('contactPhone', selectedContact.contactPhone);
        this.props.actions.onGroupContactFieldChange('contactEmail', selectedContact.contactEmail);
        this.props.actions.onGroupContactFieldChange('contactType', selectedContact.contactType);
        this.props.actions.onGroupContactFieldChange('contactSaleState', selectedContact.contactSaleState);
        this.props.actions.onGroupContactFieldChange('recordID', selectedContact.recordID);
        this.props.actions.onGroupContactFieldChange('isFavorited', selectedContact.favorite);
        this.props.actions.onGroupContactFieldChange('listContactNhucau', selectedContact.nhuCau || []);
        this.props.actions.onGroupContactFieldChange('contactPhotos', selectedContact.avatar ? [{ uri: selectedContact.avatar }]
            : (selectedContact.zaloAvatar ? [{ uri: selectedContact.zaloAvatar }] : []));

        this._onSaveInitialContact();

        Actions.ModifyContact({request: this.props.request});
    }

    _onSaveInitialContact() {
        // local storage initialContact
        this.props.actions.onHelpedModalChange('initialContact', true);
        let { help } = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.initialContact = true;
        this.props.actions.updateLocalHelped(helped);
    }

    _renderDetailContent() {
        let { contactOrder } = this.state;
        if (contactOrder == TAP_MENU.history) {
            return <ContactHistory {...this.props} />
        }

        if (contactOrder == TAP_MENU.demand) {
            return <ContactWishList {...this.props}/>
        }

        if (contactOrder == TAP_MENU.viewed) {
            return <ContactAdsViewed {...this.props} />
        }

        if (contactOrder == TAP_MENU.noted) {
            return <ContactNote {...this.props} />
        }

        if (contactOrder == 'more') {
            let selectedContact = this.props.groupContact.selectedContact;
            let url = 'https://www.google.com.vn/search?q=';
            if (selectedContact.contactPhone)
                url += selectedContact.contactPhone.replace(' ', '+');
            else if (selectedContact.contactEmail)
                url += selectedContact.contactEmail.replace(' ', '+');
            else if (selectedContact.contactName)
                url += selectedContact.contactName.replace(' ', '+');

            return <ContactMore {...this.props} url={url} />
        }
    }

    _onTypeOrder(value) {
        let selectedContact = this.props.groupContact.selectedContact;
        switch (value) {
            case TAP_MENU.history:
                this.props.actions.getContactHistory(
                    {
                        'userID': this.props.global.currentUser.userID,
                        'contactID': selectedContact.contactID
                    }
                    , (res) => {
                        this.setState({
                            contactOrder: value
                        });
                    }
                    , (error) => {
                        log.info('getContactHistory server respond error: =====>>>>>', error)
                    });
                break;
            case TAP_MENU.demand:
                this.props.actions.onGroupFieldChange('contactWtoList', []);
                this.props.actions.getContactWto(
                    {
                        'userID': this.props.global.currentUser.userID,
                        'contactID': selectedContact.contactID,
                        'dataType': selectedContact.dataType || undefined,
                    }
                    , (res) => {
                        if (res.data && res.data.length > 0) {
                            //replace with cache query
                            setTimeout(() => {
                                let wtoList = [];
                                res.data.forEach((e) => {
                                    //clear fields due to endpoint not allow
                                    e.content.textKhongDau = undefined;
                                    wtoList.push({
                                        id: e.id,
                                        status: e.status,
                                        content: e.content,
                                        dataType: e.dataType || undefined,
                                    })
                                });
                                this.props.actions.getAdsMatchingAgentWto(
                                    {
                                        'userID': this.props.global.currentUser.userID,
                                        'wtoList': wtoList,
                                        'excludeOwnAds': false,
                                    }
                                    , (res) => {
                                        log.info('getAdsMatchingAgentWto server respond ***: ', res);
                                        this.setState({
                                            contactOrder: value
                                        });
                                    }
                                    , (error) => {
                                        this.setState({
                                            contactOrder: value
                                        });
                                    });
                            }, 300);

                        } else {
                            this.setState({
                                contactOrder: value
                            });
                        }
                    }
                    , (error) => {
                        this.setState({
                            contactOrder: value
                        });
                        log.warn('getContactWto : server respond error: =====>>>>>', error)
                    });
                break;
            case TAP_MENU.viewed:
                this.props.actions.onGroupContactFieldChange('contactRespondList', []);
                this.props.actions.getContactRespond(
                    {
                        'userID': this.props.global.currentUser.userID,
                        'contactID': selectedContact.contactID
                    }
                    , (res) => {
                        this.setState({
                            contactOrder: value
                        });
                    }
                    , (error) => {
                        log.warn('getContactRespond : server respond error: =====>>>>>', error);
                        this.setState({
                            contactOrder: value
                        });
                    });
                break;
            case TAP_MENU.noted:
                this.props.actions.onGroupFieldChange('contactNoteList', []);
                this.props.actions.getContactNote(
                    {
                        'userID': this.props.global.currentUser.userID,
                        'contactID': selectedContact.contactID
                    }
                    , (res) => {
                        this.setState({
                            contactOrder: value
                        });
                    }
                    , (error) => {
                        log.warn('getContactNote : server respond error: =====>>>>>', error);
                        this.setState({
                            contactOrder: value
                        });
                    });
                break;
            default:
                this.setState({
                    contactOrder: value
                });
        }
    }

    _onBackPress() {
        Actions.pop();
    }

    _renderBody() {
        let data = this.state.dataToRender;

        if (data && Object.keys(data).length > 0)
            return (
                <View style={styles.alphabetListView}>
                    <SelectableSectionsListView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="on-drag"
                        refreshControl={
                            <RefreshControl
                                refreshing={false}
                                onRefresh={this._onRefresh.bind(this)}
                            />
                        }

                        data={data}
                        cell={Cell}
                        cellProps={{
                            renderRowContactDetail: (value) => this._renderDetailContent(value),
                            renderHeaderContent: () => this._renderHeaderContent()
                        }}

                        sectionHeaderProps={{
                            renderMainMenu: () => this._renderMainMenu()
                        }}

                        cellHeight={33}
                        sectionListItem={SectionItem}
                        sectionHeader={SectionHeader}
                        sectionHeaderHeight={33}
                        style={styles.alphabetListView}
                        contentContainerStyle={{ paddingBottom: 0 }}
                    />
                </View>
            );
        else return null;
    }

    _onRefresh() {
        log.warn("need to be implemented");
    }

    _renderMainMenu() {
        return this._renderTapContent();
    }

    _renderHeaderContent() {
        return this._renderContentTop();
    }

}


class SectionHeader extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            contactOrder: TAP_MENU.history
        }
    }

    render() {
        if (this.props.title == 'contentSection')
            return (
                this.props.renderMainMenu()
            );
        else return <View style={{ width: width, height: 1, backgroundColor: '#fff' }}></View>
    }
}

class SectionItem extends React.Component {
    render() {
        return null
    }
}

class Cell extends React.Component {
    render() {
        let data = this.props.item;
        if (data.header == 'header') {
            return this.props.renderHeaderContent();
        }
        else return this.props.renderRowContactDetail(data);
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderCover: {
        height: 46,
        width: width
    },
    viewHeader: {
        height: 64,
        width: width,
        paddingLeft: 8,
        paddingRight: 8,
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    viewIconLeft: {
        height: 64,
        width: 38,
        justifyContent: 'center',
        paddingTop: gui.marginTopAgent,
    },
    viewIconsHeader: {
        height: 64,
        width: width - 54,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingTop: gui.marginTopAgent
    },
    startButton: {
        height: 64,
        width: 30,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: gui.marginTopAgent - 8
    },
    viewIconsHeader2: {
        height: 54 + 30,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        // marginTop: 16,
        // marginBottom: 14,
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewTextLeft: {
        height: 26,
        width: 38,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom: 2
    },
    viewTextProfile: {
        width: width - 108,
        height: 64,
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingTop: gui.marginTopAgent
    },
    textCommon: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainAgentColor
    },
    textNameTop: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.textAgentSolid,
        fontWeight: '500'
    },
    textLevelTop: {
        fontSize: 12,
        color: 'rgba(49,207,100,1)',
        fontFamily: gui.fontFamily,
        marginLeft: 5,
        // color: '#fff'
    },
    textProfile: {
        fontSize: 17,
        fontWeight: 'bold',
        color: gui.mainTextColor
    },
    viewContentTop: {
        height: 'auto', //236,
        width: width
    },
    viewDetailTop: {
        height: 'auto',//235,
        width: width
    },
    myAvatar: {
        width: 60,
        height: 60,
        borderRadius: 30,
        zIndex: 1
    },
    imageCover: {
        width: 66,
        height: 66,
        borderRadius: 33,
        alignSelf: 'center',
        backgroundColor: 'rgba(241,247,255,1)',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewDetailText: {
        height: 'auto',
        width: width,
        alignItems: 'center',
        paddingTop: 5
    },
    textLevel: {
        color: 'rgba(57,181,74,1)',
        fontSize: 15,
        marginTop: 2
    },
    textPhone: {
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        marginTop: 7
    },
    textName: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        color: gui.mainTextColor
    },
    viewIconContact: {
        height: 56,
        width: width,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        marginTop: 8,
        marginBottom: 8
    },
    touchIconChild: {
        height: 56 - 11,
        width: 42,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    viewIconMessage: {
        height: 32,
        width: 32,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    textIcon: {
        fontSize: 8,
        fontWeight: '600',
        color: gui.mainTextColor,
        marginTop: 3
    },
    tapContent: {
        height: 50,
        width: width,
        backgroundColor: '#fff'
    },
    viewEachTap: {
        height: 50,
        width: width,
        flexDirection: 'row',
        paddingLeft: 8,
        alignItems: 'center',
        paddingRight: 0,
        borderBottomWidth: 0,
        paddingTop: 0,
        backgroundColor: '#fff'
    },
    viewTopBody: {
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        height: 'auto',
        alignItems: 'center',
        backgroundColor: 'transparent'
    },
    viewTopLeftBody: {
        width: width,
        height: 'auto',
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 16,
        paddingRight: 16,
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewNameTop: {
        height: 14,
        width: width,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextPhone: {
        height: 14,
        width: width,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textPhoneTop: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        marginTop: 3
    },
    imageTopCover: {
        width: width,
        height: 76,
        borderRadius: 28,
        alignSelf: 'center',
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 3
    },
    myTopAvatar: {
        width: 76,
        height: 76,
        borderRadius: 38
    },
    dotAvatar: {
        width: 76,
        height: 76,
        borderRadius: 38,
        backgroundColor: '#eeedf0',
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchImageAvt: {
        alignSelf: 'center',
        position: 'absolute',
        top: 1,
        zIndex: 1
    },
    viewTopAvt: {
        height: 38,
        width: width,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderColor: 'rgba(211,211,211,0.6)'

    },
    dotView: {
        width: 76,
        height: 76,
        borderRadius: 38,
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'center',
        position: 'absolute',
        top: 1,
        zIndex: 1
    },
    textButton: {
        fontSize: 13,
        fontWeight: 'normal',
        color: gui.mainColor,
        fontFamily: gui.fontFamily,
        marginTop: 3
    },
    textSort: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewThinLine: {
        height: 14,
        width: 1,
        backgroundColor: gui.mainTextColor,
        marginLeft: 5,
        marginRight: 5,
        // backgroundColor: '#fff'
    },

    viewModify: {
        height: 25,
        width: 50,
        backgroundColor: 'rgba(0,0,0,0.4)',
        borderBottomLeftRadius: 25,
        borderBottomRightRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        zIndex: 1,
        top: 28
    },
    textModify: {
        color: '#fff',
        fontSize: 10,
        fontFamily: gui.fontFamily
    },
    textComment: {
        fontSize: 15,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 229,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewModalContent: {
        height: 160,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        paddingTop: 10
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textMoreButton: {
        color: gui.mainColor,
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    viewShowModal: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewButtonActions: {
        height: 36,
        width: 36,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 18
    },
    viewItemsButton: {
        height: 52,
        width: 60,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 18,
        marginLeft: 25
    },
    viewModalShareAds: {
        height: 200,
        width: width,
        backgroundColor: 'transparent'
    },
    viewShareAds: {
        width: width - 16,
        marginLeft: 8,
        marginRight: 8,
        height: 200,
        backgroundColor: '#fff',
        borderRadius: 5
    },
    viewShareTitle: {
        height: 31,
        width: width - 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textTypePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: '#fff'
    },
    viewShareContent: {
        width: width,
        height: 40,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 12,
    },
    viewSaleState: {
        height: 44,
        width: 32,
        justifyContent: 'center',
        paddingTop: 12,
        margin: 0
    },
    checkAds: {
        height: 44,
        width: 32,
        justifyContent: 'center'
    },
    alphabetListView: {
        flex: 1,
        backgroundColor: '#fff',
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NewDetailContact);