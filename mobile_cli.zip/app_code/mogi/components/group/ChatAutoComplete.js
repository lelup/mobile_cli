'use strict';

import React, { Component } from 'react';
import FullLine from '../line/FullLine';
import {
    Text, View, ListView, Image
    , TextInput, StyleSheet, RecyclerViewBackedScrollView
    , TouchableHighlight, StatusBar,
    TouchableOpacity,
    ScrollView,
    Alert,
    FlatList
} from 'react-native'

import { Actions } from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SearchInput from './SearchInputAgent';

import TabGroupMain from './TabGroupMain';
import gui from "../../lib/gui";
import log from "../../lib/logUtil";
import cfg from '../../cfg';
import GiftedSpinner from "../../components/GiftedSpinner";

import GroupApi from '../../lib/GroupApi';

import HTML from 'react-native-render-html';

import utils from '../../lib/utils';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import DanhMuc from '../../assets/DanhMuc';

import Button from 'react-native-button';

import AlphabetListView from 'react-native-alphabetlistview'

import Toast, {DURATION} from '../toast/Toast';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as chatActions from '../../reducers/chat/chatActions';

import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

const { width, height } = utils.getDimensions();
const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    adsMgmtActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class ChatAutoComplete extends React.Component {
    constructor(props) {
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: function rowHasChanged(r1, r2) {
                return r1 !== r2;
            }
        });

        this.state = {
            focused: false,
            text: props.group.chatSearchFields.text,
            toggleKeyboard: false,
            dataToRender: {},
            phanLoai: props.group.selectedMainSearchTab,
            loading: false
        };
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.group.selectedMainSearchTab !== nextProps.group.selectedMainSearchTab) {
            this.setState({ phanLoai: nextProps.group.selectedMainSearchTab });
        }

        if (nextProps.group.chatSearchFields.text !== this.props.group.chatSearchFields.text) {
            this.setState({
                text: nextProps.group.searchFields.text
            });
        }
    }

    _prepareDataToRender(data, pageNo, limit, isAppend) {

        let showLimit = limit * pageNo
        let dataToRender = isAppend ? this.state.dataToRender : {};

        let memberArray = [];
        if (isAppend && dataToRender[DanhMuc.mainTextSearchHeader.group]) {
            memberArray = dataToRender[DanhMuc.mainTextSearchHeader.group]
            if (memberArray[memberArray.length - 1] && memberArray[memberArray.length - 1].footer == 'footer')
                memberArray = memberArray.slice(0, memberArray.length - 1)
        }

        let contactArray = [];
        if (isAppend && dataToRender[DanhMuc.mainTextSearchHeader.contact]) {
            contactArray = dataToRender[DanhMuc.mainTextSearchHeader.contact]
            if (contactArray[contactArray.length - 1] && contactArray[contactArray.length - 1].footer == 'footer')
                contactArray = contactArray.slice(0, contactArray.length - 1)
        }

        if (!data || data.length == 0) {
            return dataToRender;
        }
        data.forEach((one) => {
            if (one.type == 'GroupMember' && memberArray.length < showLimit)
                memberArray.push(one);
        });
        //add footer item for each section
        // if (memberArray.length > 0)
        //     memberArray.push({ type: 'GroupMember', footer: 'footer' })


        if (memberArray.length > 0)
            dataToRender[DanhMuc.mainTextSearchHeader.group] = memberArray;

        return dataToRender;
    }

    renderLoadingView() {
        if (this.state.loading) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    buildRowsFromResults(results) {
        return [...results];
    }

    componentWillMount() {
        setTimeout(() => this.focusInputSearch(), 300);
    }

    render() {
        let data = this.state.dataToRender;
        return (
            <View style={styles.container}>
                {this._renderHeaderAds()}
                <FullLine/>
                <View style={styles.pageHeaderInput}>
                    <View style={styles.viewChatWith}>
                        <Text style={[styles.textEdit, {color: 'rgba(149,149,149,1)'}]}>Tới: </Text>
                    </View>
                    <View style={styles.pageHeaderWrapper}>
                        <SearchInput ref="searchInput"
                            placeholder="Tìm kiếm" textValue={this.state.text}
                            loadSearchFilter={(fields) => this._loadSearchFilter(fields)}
                            onSuggestPress={this._onSuggestPress.bind(this)}
                            onChangeText={this._onChangeText.bind(this)}
                            onFocus={this._onFocus.bind(this)}
                            showCloseButton={this.state.focused && this.state.text != ''}
                            searchContainer={{ marginRight: 16, marginTop: 5, marginBottom: 0}}
                            editable={true} />
                    </View>
                </View>
                <FullLine style={{ marginTop: 4 }} />

                {this._renderMainContent()}
                {this.state.toggleKeyboard && data && Object.keys(data).length > 0 ? <Button onPress={() => dismissKeyboard()}
                    style={{
                        paddingRight: 17, fontFamily: gui.fontFamily, fontWeight: 'normal', textAlign: 'right',
                        color: gui.mainColor, backgroundColor: '#f0f1f3', height: 40, paddingTop: 8
                    }}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)} />
                {this.renderLoadingView()}
                <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={45}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{ color: '#fff' }}
                    />
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity style={styles.viewCancelButton}
                                  onPress={this.onPressHuy.bind(this)}
                >
                    <Text style={[styles.textEdit, {color: gui.mainAgentColor}]}>Hủy</Text>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, { fontWeight: '500', fontSize: 17}]}>Tin nhắn mới</Text>
                </View>
                <View style={styles.viewCancelButton}></View>
            </View>

        );
    }

    onPressHuy() {
        Actions.pop()
    }

    focusInputSearch() {
        this.refs.searchInput && this.refs.searchInput.focusInputSearch();
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    _request(text, pageNo, limit, isAppend) {
        if (text && text.length >= 0) {
            this._requestAll(text, pageNo, limit, isAppend);
        }
    }

    _requestAll(text, pageNo, limit, isAppend) {
        let fields = utils.cloneRecord(this.props.group.chatSearchFields);
        fields.text = text || undefined;
        fields.pageNo = pageNo
        fields.limit = limit
        fields.groupIDs = [];

        let relatedGroup = this.props.group.searchResult.listRelatedGroup;
        // console.log('_requestAll (****************', relatedGroup)
        relatedGroup.forEach((e) => {
            if ( (e.status == 1 || e.status == 2) && e.joinStatus == 2
                // && fields.groupIDs.length < 20
            )
                fields.groupIDs.push(e.groupID)
        });

        if (fields.text)
            GroupApi.searchFTSChat(fields).then((res) => {
                if (res.status == 0) {
                    //let dataToRender = this._prepareDataToRender(res.data, pageNo, limit, isAppend)
                    this.setState({
                        dataToRender: res.data
                    })
                }
            });
    }

    _resetToFirstPage() {
        this.props.actions.onChatSearchFieldChange('pageNo', 1)
    }

    _onChangeText = async(text) => {
        if (text == '')
            this._resetToFirstPage();
        this.currentText = text;

        let pre = text;
        this.props.actions.onChatSearchFieldChange('pageNo', 1);

       await setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre, 1, this.props.group.chatSearchFields.limit, false);
            }
        }, 100);

        await this.setState({
            text: text
        });
    }

    _onFocus() {
        !this.state.focused && this.setState({ focused: true });
    }

    _renderMainContent() {
        let data = this.state.dataToRender;
        // console.log('===========> _renderMainContent', data);
        if (data && Object.keys(data).length > 0)
            return (
                <View style={styles.alphabetListView}>
                   
                    <FlatList
                        ref={(ref) => this.flatList = ref}
                        data={data}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderRowSearchChat(data.item)}
                        removeClippedSubviews={false}
                        enableEmptySections
                        showsVerticalScrollIndicator={false}
                        initialListSize={25}
                        style={styles.listContent}
                        contentContainerStyle={{ height: height - 98, width: width }}
                    />
                </View>
            );
        else return null;
    }

    _renderRowSearchChat(data) {
        // console.log('===========> _renderRowSearchChat', data);
        let imgUrl = data.memberAvatar;
        // console.log('==========> imgUrl', data, imgUrl);
        let imageGroup = { uri: imgUrl };
        let defaultCover = require('../../assets/image/register_avatar_icon.png');
        if (!imageGroup) {
            imageGroup = require('../../assets/image/register_avatar_icon.png');
        }
        let nameDefault = utils.geDefaultName(data.memberName);
        let nameColor = utils.getNameColor(nameDefault);
        return (
            <View style={styles.viewRowContact}>
                <TouchableHighlight onPress={this._onContactPress.bind(this, data)}
                                    underlayColor="rgba(30,30,30,0.8)"
                                    style={styles.viewRowChild}
                >
                    <View style={styles.viewToDoRow}>
                        { !!data.memberAvatar  ?
                            (<View style={[styles.dotView]}>
                                <Image
                                    resizeMode={"cover"}
                                    source={imageGroup}
                                    defaultSource={defaultCover}
                                    style={styles.adsCover} />
                            </View>) : (
                            <View style={[styles.dotView, {backgroundColor:'#eeedf0'}]}>
                                <Text style={[styles.textSort, {color: nameColor, fontSize: 15, fontWeight:'600'}]}>{nameDefault}</Text>
                            </View>
                        )
                        }
                        <View style={styles.viewChildContact}>
                            <Text style={styles.toDoContentText}>
                                {data.memberName}
                            </Text>
                        </View>
                    </View>
                </TouchableHighlight>
            </View>
        );
    }

    _onContactPress(data) {
        log.info('_onContactPress *******', data);
        this.setState({loading: true})

        let partner = { userID: data.member };
        let chatTitle = data.memberName;
        if (this.props.global.currentUser.userID == partner.userID) {
            this.refs.toastTop && this.refs.toastTop.show('Bạn không thể chat với chính mình.', DURATION.LENGTH_LONG);                                    
            this.setState({loading: false})
            return;
        }
        this.props.actions.startFriendChat(this.props.global.currentUser,
            partner).then((e) => {                
                let isSpam = false;
                if (e.partners)
                    e.partners.forEach((pn) => {
                        if (pn.userID == this.props.global.currentUser.userID && pn.spamStatus == 2)
                            isSpam = true;
                    })
                Actions.GroupChat({ owner: 'other', isSpam: isSpam, chatTitle: chatTitle });
                this.setState({loading: false})
            });
    }

    _onViewAllPress(data) {

        this.setState({ phanLoai: DanhMuc.hashDataTypeToTabHeader[data.type] });
        this.props.actions.onGroupFieldChange('selectedMainSearchTab', DanhMuc.hashDataTypeToTabHeader[data.type]);
        //search with current text
        let pre = this.state.text;

        this.props.actions.onChatSearchFieldChange('pageNo', 1)
        setTimeout(() => {
            this._request(pre, 1, this.props.group.chatSearchFields.limit, false);
        }, 100);

    }

    _onLoadMorePress(data) {
        let nextPageNum = this.props.group.chatSearchFields.pageNo + 1;
        this.props.actions.onChatSearchFieldChange('pageNo', nextPageNum)
        let pre = this.state.text;

        setTimeout(() => {
            this._request(pre, nextPageNum, this.props.group.chatSearchFields.limit, true);
        }, 100);
    }

    _onBackPress() {
        Actions.pop();
    }

    _loadSearchFilter(fields) {

    }

    _onSuggestPress() {
    }
}

class SectionHeader extends React.Component {

    constructor(props) {
        super(props);
    }
    render() {
        let title = this.props.title;
        let name = DanhMuc.getTypeMainAvt(title);
        return (
            <View style={{ height: 38, width: width, backgroundColor: '#fff' }}>
                <View style={styles.viewLineHeader} />
                <View style={styles.viewStyle}>
                    <View style={styles.avtHeader}>
                        <FontAwesome size={11} color={"#fff"} name={name} />
                    </View>
                    <View style={styles.viewTitleChild}>
                        <Text style={styles.textStyle}>{this.props.title}</Text>
                    </View>
                </View>
                <FullLine />
            </View>
        );
    }
}

class SectionItem extends React.Component {

    render() {
        return null
    }
}

class Cell extends React.Component {
    render() {
        let data = this.props.item;
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let title = data.type == 'GroupMember' ? data.memberName : ''
        let contactAvt = data.type == 'GroupMember' && data.memberAvatar ? { uri: data.memberAvatar } : defaultAvatar;

        // style="color:#526173;"


        // data for each cell


        if (data.footer == 'footer') {
            let footerText = 'Xem thêm kết quả'
            return (
                <TouchableOpacity
                    onPress={() => {
                        this.props.phanLoai == 'all' ?
                            (this.props.onViewAllPress && this.props.onViewAllPress(data))
                            : (this.props.onLoadMorePress && this.props.onLoadMorePress(data))
                    }}
                    style={styles.touchItemGroup2}>
                    <View style={styles.viewViewAll}>

                        <View style={[styles.viewContentChild, { width: 'auto' }]}>
                            <Text numberOfLines={1} style={styles.textViewAll}>{footerText}</Text>
                        </View>
                        <View style={[styles.viewIconLeft, { alignItems: 'flex-start', marginLeft: 8 }]}>
                            <FontAwesome size={20} color={gui.mainTextColor} name={"angle-right"} />
                        </View>
                    </View>
                    {/*<FullLine style={{ marginLeft: 8 }} />*/}
                </TouchableOpacity>
            )
        }
        if (data.type == 'GroupMember')
            return (
                <TouchableOpacity
                    onPress={() => {
                        this.props.onContactPress && this.props.onContactPress(data)
                    }}
                    style={styles.touchItemGroup}>
                    <View style={styles.viewItemGroup}>
                        <Image style={styles.viewChildAvt}
                            resizeMode={"cover"}
                            source={contactAvt}
                            defaultSource={defaultAvatar}
                        />
                        <View style={styles.viewContentChild}>
                            <Text numberOfLines={1} style={styles.textTopStyle}>{title}</Text>
                        </View>
                        <View style={styles.viewIconLeft}>
                            <FontAwesome size={20} color={gui.mainTextColor} name={"angle-right"} />
                        </View>
                    </View>
                    <FullLine style={{ marginLeft: 8 }} />
                </TouchableOpacity>
            );


    }
}


const styles = StyleSheet.create({
    container: {
        paddingTop: 0,
        backgroundColor: "white",
        flex: 1
    },
    pageHeader: {
        backgroundColor: '#fff',
        width: width,
        height: 64,
        flexDirection: 'row'
    },
    pageHeaderInput: {
        height: 44,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row'
    },
    pageHeaderWrapper: {
        height: 36,
        width: width - 50,
        justifyContent: 'center'
    },
    viewChatWith: {
        height: 44,
        width: 50,
        justifyContent: 'center',
        paddingLeft: 16
    },
    lineView: {
        borderTopWidth: 1,
        height: 1,
        borderColor: 'rgba(82,97,115,0.05)'
    },
    labelText: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: '#526173',
        textAlign: 'left'
    },
    adminAvatar: {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 8
    },
    alphabetListView: {
        flex: 1
    },
    listContent: {
        flex: 1
    },
    tabHeader: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 33,
        backgroundColor: '#fff'
    },
    tabHeaderWall: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width - 32,
        height: 32,
        paddingTop: 3,
        paddingBottom: 3,
        marginLeft: 16,
        marginRight: 16
    },
    selectedButtonTab: {
        backgroundColor: gui.mainColor
    },
    selectedButtonText: {
        color: '#fff'
    },
    viewTabSelect: {
        height: 32,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row'
    },
    viewLineHeader: {
        height: 6,
        width: width,
        backgroundColor: 'rgba(215,215,215,1)'
    },
    viewStyle: {
        backgroundColor: '#fff',
        height: 31,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 8
    },
    textStyle: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500',
        fontSize: 12
    },
    textTopStyle: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '600',
        fontSize: 15
    },
    textViewAll: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: 'normal',
        fontSize: 15
    },
    avtHeader: {
        height: 22,
        width: 22,
        backgroundColor: gui.mainAgentColor,
        borderRadius: 11,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTitleChild: {
        width: width - 38,
        paddingLeft: 8,
        justifyContent: 'center'
    },
    touchItemGroup: {
        height: 51,
        width: width
    },
    touchItemGroup2: {
        height: 36,
        width: width
    },
    viewItemGroup: {
        height: 50,
        width: width - 16,
        alignItems: 'center',
        marginLeft: 8,
        marginRight: 8,
        flexDirection: 'row'
    },
    viewViewAll: {
        height: 35,
        width: width - 16,
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 8,
        marginRight: 8,
        flexDirection: 'row'
    },
    viewChildAvt: {
        height: 34,
        width: 34,
        borderRadius: 17
    },
    viewChildPostImg: {
        height: 66,
        width: 66
    },
    viewContentChild: {
        height: 50,
        width: width - 70,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewPhoneEmail: {
        height: 50,
        width: width - 70,
        flexDirection: 'row',
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewIconLeft: {
        height: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        width: 20
    },
    viewHighlight: {
        height: 'auto',
        width: width - 16,
        marginLeft: 8,
        marginRight: 8,
        paddingBottom: 8,
        flexDirection: 'row'
    },
    viewCoverHtml: {
        height: 'auto',
        width: width - 16
    },
    viewAdsTitle: {
        width: width - 16,
        height: 45,
        flexDirection: 'row',
        borderWidth: 1,
        borderColor: 'rgba(211,211,211,0.7)',
        backgroundColor: '#F6F6F6',
        alignItems: 'center'
    },
    viewTextAdsTile: {
        width: width - 16 - 45,
        height: 44,
        justifyContent: 'center',
        paddingLeft: 8
    },
    viewIconAds: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(37,37,37,0.3)'
    },
    viewImageComment: {
        height: 66,
        width: 76,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewThinLine: {
        height: 14,
        width: 1,
        backgroundColor: gui.mainTextColor,
        marginLeft: 5,
        marginRight: 5,
        // backgroundColor: '#fff'
    },
    viewNameTop: {
        height: 14,
        width: width - 91,
        flexDirection: 'row',
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewTextPhone: {
        height: 14,
        width: 79,
        backgroundColor: '#fff',
        justifyContent: 'center'
    },
    textPhoneTop: {
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    viewEachButtonTab: {
        paddingHorizontal: 12,
        paddingVertical: 9,
        backgroundColor: '#D4D7DC',
        borderRadius: 4,
        marginLeft: 8,
        marginRight: 8,
        marginTop: 0,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textButtonTab: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        textAlign: 'center'
    },
    viewEditHome: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: gui.marginTopAgent
    },
    textEdit: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    viewCancelButton: {
        paddingTop: gui.marginTopAgent,
        height: 64,
        width: 80,
        justifyContent: 'center',
        paddingLeft: 16
    },
    viewRowContact: {
        backgroundColor: '#fff',
        flexDirection: 'column',
        overflow: 'hidden'
    },
    viewRowChild: {
        width: width,
        height: 57,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderColor: '#dcdcdc'
    },
    viewToDoRow: {
        backgroundColor: '#FFFFFF',
        width: width,
        height: 56,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    dotView: {
        width: 32,
        borderRadius: 16,
        height: 32,
        marginLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textSort: {
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
    },
    viewChildContact: {
        height: 56,
        justifyContent: 'center',
        width: width - 64,
        paddingLeft: 8
    },
    toDoContentText: {
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '600',
        color: '#526173'
    },
    adsCover: {
        width: 32,
        height: 32,
        marginLeft: 0,
        borderRadius: 16
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(ChatAutoComplete);