import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableOpacity,
    TextInput,
    Switch,
    Keyboard,
    ScrollView,
    ImageBackground,
    Alert,
    FlatList,
    ListView
} from 'react-native';
import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/FontAwesome';
import GiftedSpinner from "../GiftedSpinner";
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import FontAwesomeLight from '../font/FontAwesomeLight';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Actions } from 'react-native-router-flux';
import DanhMuc from '../../assets/DanhMuc';
import FullLine from '../line/FullLine';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
var Contacts = require('react-native-contacts')
import CheckDot from '../detail/CheckDot';
import RangeUtils from '../../lib/RangeUtils';
import FunctionModal from '../FunctionModal'

import KeyboardSpacer from 'react-native-keyboard-spacer';
import Button from 'react-native-button';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import OfflineBar from '../line/OfflineBar';
import log from "../../lib/logUtil";
import Camera from 'react-native-camera';
import moment from 'moment';
const Permissions = require('react-native-permissions');
import ImageResizer from 'react-native-image-resizer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import LinearGradient from 'react-native-linear-gradient';
import RelandIcon from '../RelandIcon';
import cfg from "../../cfg";
import Toast, { DURATION } from '../toast/Toast';


import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as groupContactActions from '../../reducers/groupContact/groupContactActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';

import gui from '../../lib/gui';
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();

import userApi from '../../lib/userApi';

const actions = [
    globalActions,
    meActions,
    searchActions,
    groupActions,
    inboxActions,
    groupContactActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var count = 0;
var uploadFiles = [];
var errorMessage = '';
var myDs = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

class ModifyContact extends Component {
    constructor(props) {
        super(props);
        this.state = {
            nameContact: props.groupContact.contactName,
            phoneContact: props.groupContact.contactPhone,
            emailContact: props.groupContact.contactEmail,
            contactSaleState: props.groupContact.contactSaleState,
            photos: props.groupContact.contactPhotos,
            isOpenImagePicker: false,
            uploadUrls: [],
            listContactNhucau: props.groupContact.listContactNhucau,
            toggleState: false,
            isFavorited: props.groupContact.isFavorited == 1,
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.groupContact.contactPhotos !== this.props.groupContact.contactPhotos) {
            this.setState({
                photos: nextProps.groupContact.contactPhotos
            });
        }

        if (nextProps.groupContact.contactSaleState !== this.props.groupContact.contactSaleState) {
            this.setState({
                contactSaleState: nextProps.groupContact.contactSaleState
            });
        }

        if (nextProps.groupContact.listContactNhucau !== this.props.groupContact.listContactNhucau) {
            this.setState({
                listContactNhucau: nextProps.groupContact.listContactNhucau
            });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <OfflineBar />
                {this._renderHeaderButton()}
                <FullLine/>

                <KeyboardAwareScrollView
                    keyboardShouldPersistTaps="handled"
                    keyboardDismissMode="none"
                    ref='scroll'
                >
                    <View contentContainerStyle={{ backgroundColor: '#fff' }}>

                        {this._renderPhoto()}
                        {this._renderContent()}

                        {this._renderLoadingView()}
                    </View>

                </KeyboardAwareScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                    style={[styles.searchButtonText2, {
                        textAlign: 'right', color: gui.mainColor,
                        backgroundColor: gui.doneKeyButton
                    }]}>Xong</Button> : null}
                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />

                {this._openImagePicker()}

                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height / 2}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{ color: '#fff' }}
                />
            </View>
        )
    }
    onKeyboardToggle(toggleState) {
        this.setState({ toggleState });
    }

    _renderLoadingView() {
        if (this.props.groupContact.savingContact) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _renderHeaderButton() {
        let addContact = 'Thêm khách hàng';
        let saveText = 'Lưu';
        // if (this.props.group.savingContact)
        //     return (
        //         <View style={styles.viewHeaderButton}>
        //             <TouchableOpacity style={styles.viewLeftIcon}
        //                 onPress={this._onBackButton.bind(this)}
        //             >
        //                 <View style={styles.viewTouchClose} >
        //                     <Ionicons name={"md-arrow-back"} size={24} color={gui.mainTextColor} />
        //                 </View>
        //                 <Text style={styles.textContact}>{addContact}</Text>
        //             </TouchableOpacity>
        //             <View style={styles.viewRightIcon}>
        //                 <View >
        //                     <Text style={styles.textSave}>{saveText}</Text>
        //                 </View>
        //             </View>
        //         </View>
        //     )
        // else
            return (
                <View style={styles.viewHeaderButton}>
                    <View style={styles.viewLeftIcon}>
                        <TouchableOpacity style={styles.viewTouchButton}
                            onPress={this._onBackButton.bind(this)}
                        >
                            <Text style={[styles.textSave, {color: gui.mainColor }]}>Hủy</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewRightIcon}>

                        <TouchableOpacity
                            style={styles.viewTouchButton}
                            onPress={this.props.groupContact.savingContact ? null : this.onPostContact.bind(this)}>
                            <Text style={[styles.textSave, {color: gui.mainColor }]}>Lưu</Text>
                        </TouchableOpacity>

                    </View>
                </View>
            );
    }

    _renderPhoto() {
        let { photos } = this.state;
        if (!photos) {
            photos = [];
        }
        let numOfPhoto = photos.length;
        let indexArr = [];
        for (let i = 0; i <= photos.length; i++) {
            if (i < 1) {
                indexArr.push(i)
            }
        }

        return (
            <View style={[styles.mimgList]} >
                {indexArr.map((e) => { if (e < 1) return this._renderPhotoItem(e) })}
            </View>
        );
    }

    _outModalImagePicker() {
        this.setState({
            isOpenImagePicker: false
        });
    }

    _openImagePicker() {
        return (
            <Modal isOpen={this.state.isOpenImagePicker}
                onClosed={this._outModalImagePicker.bind(this)}
                style={ [styles.viewModalStyle, {height:'auto'}] }
                position={"bottom"}
                swipeToClose={false}
            >
                {this._renderModalImagePicker()}
            </Modal>
        );
    }

    _renderModalImagePicker() {
        
        let items = [
            { _text: 'Máy ảnh', _function: () => this.onCamera() },
            { _text: 'Bộ sưu tập', _function: () => this.onCameraRollView() },        
          ]
          return (
            <FunctionModal
              // data={data}
              items={items}
              onCloseModal={this._outModalImagePicker.bind(this)} />
          )
    }

    onCamera() {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {
                if (e) {
                    Permissions.requestPermission('photo')
                        .then(response => {
                            if (response == 'authorized') {
                                Actions.ModifyContact2({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
                            } else {
                                Alert.alert("Thông báo", gui.INF_PhotoAccess);
                            }
                        });

                } else {
                    Alert.alert("Thông báo", gui.INF_CameraAccess);
                }
            });
    }

    onCameraRollView() {
        Permissions.requestPermission('photo')
            .then(response => {
                if (response == 'authorized') {
                    Actions.CameraRollView5({ onTakePhoto: this._outModalImagePicker.bind(this), owner: this.props.owner });
                } else {
                    Alert.alert("Thông báo", gui.INF_PhotoAccess);
                }
            });
    }

    _renderPhotoItem(imageIndex) {
        let { photos } = this.state;
        // console.log('photos =========>>>', photos);
        if (!photos) {
            photos = [];
        }
        let photo = photos[imageIndex];

        let {contactName} = this.props.groupContact;

        return (
            <ImageItem imageIndex={imageIndex}
                key={imageIndex}
                photo={photo}
                contactName={contactName}
                onTakePhoto={this.onTakePhoto.bind(this)}
                onDeletePhoto={this.onDeletePhoto.bind(this)} />
        )
    }

    onTakePhoto(imageIndex) {
        this.props.actions.onGroupContactFieldChange('contactImageIndex', imageIndex);
        // Actions.PostAds();
        this._openModalImagePicker();
    }

    _openModalImagePicker() {
        dismissKeyboard();
        this.setState({ isOpenImagePicker: true });
    }

    onDeletePhoto(imageIndex) {
        let { photos } = this.state;
        photos.splice(imageIndex, 1);
        this.setState({ deletedPhoto: imageIndex });
        this.props.actions.onGroupContactFieldChange('contactPhotos', photos);
    }

    _renderContent() {
        return (
            <View style={styles.viewContent}>
                {this._renderNameInput()}
                <View style={styles.lineContent} />
                {this._renderPhoneInput()}
                <View style={styles.lineContent} />
                {this._renderEmailInput()}
                <View style={[styles.lineContent, {width: width - 16, marginLeft: 16}]} />
                {this.renderFavorite()}
                <View style={[styles.lineContent, {width: width - 16, marginLeft: 16}]} />
                {this._renderContactType()}
                {this._renderSaleState()}
            </View>
        );
    }

    renderFavorite() {
        return(
            <View style={styles.viewFavorite}>
                <View style={styles.viewTextLeft}>
                    <Text style={[styles.textSave, {color: gui.textAgentSolid}]}>Yêu thích</Text>
                </View>
                <View style={styles.favoriteButton}>
                    <TouchableOpacity
                        onPress={this._onFavorite.bind(this)}
                        style={styles.startButton}
                        >
                        { this.state.isFavorited ?
                            <FontAwesomeSolid name={'star'}
                                              size={21}
                                              color={'rgba(255,207,86,1)'}
                                              noAction={true}
                                              iconOnly={true}
                                              mainProps={{marginBottom: 0}}
                            /> :
                            < FontAwesomeLight name={'star'}
                                               size={21}
                                               color={'rgba(255,207,86,1)'}
                                               noAction={true}
                                               iconOnly={true}
                                               mainProps={{marginBottom: 0}}
                            />
                        }
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

    _renderNameInput() {
        return (
            <View style={styles.viewNameInput}>
                <View style={styles.viewIcon}>
                    <FontAwesomeSolid name={"user"}
                                      size={15}
                                      color={gui.textPostAds}
                                      noAction={true}
                                      iconOnly={true} />
                </View>
                <TextInput
                    autoFocus={false}
                    autoCapitalize='none'
                    autoCorrect={false}
                    returnKeyType='done'
                    underlineColorAndroid='rgba(0,0,0,0)'
                    secureTextEntry={false}
                    style={styles.nameInput}
                    placeholderTextColor={'rgba(178,178,178,1)'}
                    placeholder={'Tên'}
                    value={this.state.nameContact}
                    onChangeText={(text) => this._onNameContactChange(text)}
                    onBlur={() => this.onBlurNamePost()}
                    maxLength={60}
                />
            </View>
        )
    }

    _renderPhoneInput() {
        return (
            <View style={styles.viewNameInput}>
                <View style={styles.viewIcon}>
                    <FontAwesomeSolid name={"phone"}
                                      size={15}
                                      color={gui.textPostAds}
                                      noAction={true}
                                      iconOnly={true}
                    />
                </View>
                <TextInput
                    autoFocus={false}
                    autoCapitalize='none'
                    secureTextEntry={false}
                    style={styles.nameInput}
                    keyboardType={'numeric'}
                    underlineColorAndroid='rgba(0,0,0,0)'
                    placeholderTextColor={'rgba(178,178,178,1)'}
                    placeholder={'Số điện thoại'}
                    value={this.state.phoneContact}
                    onChangeText={(text) => this._onPhoneContactChange(text)}
                    onBlur={() => this.onBlurNamePost()}
                    maxLength={15}
                />
            </View>
        )
    }

    _renderEmailInput() {
        return (
            <View style={styles.viewNameInput}>
                <View style={styles.viewIcon}>
                    <FontAwesomeSolid name={"envelope"}
                                      size={15}
                                      color={gui.textPostAds}
                                      noAction={true}
                                      iconOnly={true}
                    />
                </View>
                <TextInput
                    autoFocus={false}
                    autoCapitalize='none'
                    secureTextEntry={false}
                    style={styles.nameInput}
                    keyboardType={'twitter'}
                    underlineColorAndroid='rgba(0,0,0,0)'
                    placeholderTextColor={'rgba(178,178,178,1)'}
                    placeholder={'Email'}
                    value={this.state.emailContact}
                    onChangeText={(text) => this._onEmailContactChange(text)}
                    onBlur={() => this.onBlurNamePost()}
                    maxLength={30}
                />
            </View>
        )
    }

    onBlurNamePost() {
        Keyboard.dismiss();
    }

    _renderContactType() {
        let potentialCustomer = 'Phân loại';

        let contactTypeItems = [];
        let contactTypeKeys = Object.keys(DanhMuc.contactType);
        contactTypeKeys.forEach((aType) => {
            let contactType = DanhMuc.contactType[aType];

            contactTypeItems.push(
                <CheckDot name={aType} key={aType}
                    onPress={this._onContactType.bind(this)}
                    selected={this.props.groupContact.contactType == aType}
                    textProps={{color: 'rgba(85,85,85,1)', fontSize: 15}}
                    mainProps={[styles.viewSaleState]}>{contactType}</CheckDot>
            );
        });

        return (
            <View style={[styles.viewPotential, { height: 'auto' }]}>
                <View style={{ marginLeft: 16, marginTop: 16, marginBottom: 10, justifyContent: 'center', alignItems: 'flex-start' }}>
                    <Text style={[styles.textSave, {color: gui.textAgentSolid}]}>{potentialCustomer}</Text>
                </View>
                <View style={styles.viewTypeHide}>
                    {contactTypeItems}
                </View>
                <View style={[styles.lineContent, { width: width - 16, marginLeft: 16, marginTop: 6 }]} />
            </View>
        )


    }

    _renderSaleState() {
        let potentialCustomer = 'Đánh giá tiềm năng'
        let saleStateItems = [];
        let sateStateKeys = Object.keys(DanhMuc.contactSaleState);
        sateStateKeys.forEach((saleState) => {
            let hiddenType = DanhMuc.contactSaleState[saleState];

            saleStateItems.push(
                <CheckDot name={saleState} key={saleState}
                    onPress={this._onSaleState.bind(this)}
                    selected={this.state.contactSaleState == saleState}
                    textProps={{color: 'rgba(85,85,85,1)', fontSize: 15}}
                    mainProps={[styles.viewSaleState]}>{hiddenType}</CheckDot>
            );
        });

        return (
            <View style={[styles.viewPotential, { height: 'auto' }]}>
                <View style={{ marginLeft: 16, marginTop: 16, marginBottom: 10, justifyContent: 'center', alignItems: 'flex-start' }}>
                    <Text style={[styles.textSave, {color: gui.textAgentSolid}]}>{potentialCustomer}</Text>
                </View>
                <View style={styles.viewTypeHide}>
                    {saleStateItems.slice(0, 2)}
                </View>
                <View style={styles.viewTypeHide}>
                    {saleStateItems.slice(2, 4)}
                </View>
            </View>
        )
    }

    _onSaleState(value) {
        this.setState({ contactSaleState: value })
        this.props.actions.onGroupContactFieldChange('contactSaleState', value);
        dismissKeyboard();
    }

    _onContactType(value) {
        this.props.actions.onGroupContactFieldChange('contactType', value);
        dismissKeyboard();
    }

    _onNameContactChange(value) {
        this.setState({
            nameContact: value
        })
        this.props.actions.onGroupContactFieldChange('contactName', value);
    }

    _onPhoneContactChange(value) {
        this.setState({
            phoneContact: value
        })
        this.props.actions.onGroupContactFieldChange('contactPhone', value);
    }

    _onEmailContactChange(value) {
        this.setState({
            emailContact: value
        })
        this.props.actions.onGroupContactFieldChange('contactEmail', value);
    }

    _onBackButton() {
        Actions.pop();
    }


    _onFavorite() {
        let currentFavoriteState = this.state.isFavorited;
        this.setState({isFavorited: !currentFavoriteState});
        this.props.actions.onGroupContactFieldChange('isFavorited', !currentFavoriteState ? 1 : 0);
        // let selectedContact = this.props.group.selectedContact;
        // if (!selectedContact) {
        //     return;
        // }
        // let userID = this.props.global.currentUser.userID;
        // let token = this.props.global.currentUser.token || undefined;
        // let newFavorite = selectedContact.favorite == 1 ? 0 : 1;
        // let dto = {
        //     contactID: selectedContact.id,
        //     userID: userID,
        //     favorite: newFavorite
        // };
        // this.props.actions.favoriteContact(dto, token)
        //     .then(res => {

        //         if (res.status != 0) {
        //             Alert.alert("Thông báo", res.msg, [{
        //                 text: 'Đóng', onPress: () => {
        //                 }
        //             }]);
        //         } else {
        //             selectedContact.favorite = newFavorite;
        //             this.props.actions.onGroupContactFieldChange('selectedContact', selectedContact);

        //             let contactList = this.props.group.contactList;
        //             contactList.forEach((e) => {
        //                 if (e.id == selectedContact.id)
        //                     e.favorite = newFavorite
        //             });

        //             this.props.actions.onGroupContactFieldChange('contactList', contactList.slice(0))
        //         }
        //     });
    }

    onPostContact() {
        this.onLogEvent("Lưu danh bạ mới");
        this.props.actions.onGroupContactFieldChange("savingContact", true);
        let { contactPhotos } = this.props.groupContact;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < contactPhotos.length; i++) {
            let filepath = contactPhotos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }
        if (!this.isValidInputData()) {
            this.refs.toastTop && this.refs.toastTop.show(errorMessage, DURATION.LENGTH_LONG * 2);
            this.props.actions.onGroupContactFieldChange('error', errorMessage);
            this.props.actions.onGroupContactFieldChange("savingContact", false);
            return;
        }

        this.onPostContactChecked();

    }


    onLogEvent(title) {
        let eventDto = {
            scene: "ModifyContact",
            parentScene: undefined,  //truyen owner neu co
            componentType: "button",
            component: title,
            sessionID: this.props.global.currentUser.token,
            userID: this.props.global.currentUser.userID

        };
        userApi.logEvent(eventDto, this.props.global.currentUser.token)
            .then(function (json) {
                return json;
            });
    }

    isValidInputData() {
        let errors = '';
        let { contactName, contactPhone, contactID } = this.props.groupContact;

        if (!contactName || !contactName.trim()) {
            errors += ' (tên)';
        }

        if (!contactPhone || !contactPhone.trim()) {
            errors += ' (số điện thoại)';
        }

        if (errors != '') {
            errorMessage = 'Bạn chưa nhập' + errors + '!';
            return false;
        }

        if (!utils.validatePhone(contactPhone.trim())) {
            errorMessage = 'Số điện thoại chưa đúng định dạng!';
            return false;
        }

        let contactList = this.props.groupContact.contactList;
        let isExisted = false;
        contactList.forEach((e) => {
            if ((!contactID || contactID != e.id) && (e.contactPhone == contactPhone.trim())) {
                errorMessage = 'SĐT ' + contactPhone.trim() + ' đã tồn tại trong danh bạ của bạn!';
                isExisted = true;
            }
        })
        if (isExisted == true)
            return false;

        return true;
    }

    onPostContactChecked() {
        let { contactPhotos } = this.props.groupContact;
        errorMessage = '';
        uploadFiles = [];
        for (let i = 0; i < contactPhotos.length; i++) {
            let filepath = contactPhotos[i].uri;
            if (filepath == '') {
                continue;
            }
            uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
        }

        this.props.actions.onGroupContactFieldChange("uploading", true);

        let countUpdateFiles = this.countNeedUploadFiles();
        if (!countUpdateFiles) {
            this.onSaveContact();
            return;
        }

        count = 0;
        const userID = this.props.global.currentUser.userID;
        for (let i = 0; i < uploadFiles.length; i++) {
            if (errorMessage != '') {
                Alert.alert('Thông báo', errorMessage);
                this.props.actions.onGroupContactFieldChange('error', errorMessage);
                this.props.actions.onGroupContactFieldChange("savingContact", false);
                return;
            }
            let needUpload = uploadFiles[i].needUpload;
            if (!needUpload) {
                continue;
            }
            let index = uploadFiles[i].index;
            let filepath = uploadFiles[i].filepath;
            ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
                let ms = moment().toDate().getTime();
                let filename = 'Contact_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
                this.props.actions.onUploadGroupImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this));
            }).catch((err) => {
                this.props.actions.onGroupContactFieldChange("uploading", false);
                this.props.actions.onGroupContactFieldChange("savingContact", false);
                log.error(err);
            });
        }
    }

    countNeedUploadFiles() {
        let count = 0;
        for (let i = 0; i < uploadFiles.length; i++) {
            let file = uploadFiles[i];
            if (file.needUpload) {
                count++;
            }
        }
        return count;
    }

    uploadCallBack = function (err, result, index) {
        let data = result && result.data ? result.data : '';
        if (err || data == '') {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onGroupContactFieldChange('error', errorMessage);
            this.props.actions.onGroupContactFieldChange("uploading", false);
            this.props.actions.onGroupContactFieldChange("savingContact", false);
            return;
        }
        try {
            let { success, file } = JSON.parse(data);
            if (success) {
                let { url } = file;
                this.state.uploadUrls.push({ index: index, url: url });
                count++;
                if (count == this.countNeedUploadFiles()) {
                    this.onSaveContact();
                }
            } else {
                errorMessage = 'Upload ảnh không thành công!';
                this.props.actions.onGroupContactFieldChange('error', errorMessage);
                this.props.actions.onGroupContactFieldChange("uploading", false);
            }
        } catch (error) {
            errorMessage = 'Upload ảnh không thành công!';
            this.props.actions.onGroupContactFieldChange('error', errorMessage);
            this.props.actions.onGroupContactFieldChange("uploading", false);
        }
    }

    onSaveContact() {
        let { uploadUrls } = this.state;
        let { contactID, contactName, contactSource, contactPhone, contactEmail,
            contactSaleState, contactPhotos, contactType, recordID, listContactNhucau, isFavorited } = this.props.groupContact;

        let imageUrls = [];
        for (let i = 0; i < contactPhotos.length; i++) {
            let photo = contactPhotos[i];
            imageUrls.push(photo.uri);
        }
        for (let i = 0; i < uploadUrls.length; i++) {
            let uploadUrl = uploadUrls[i];
            let index = uploadUrl.index;
            if (index >= 0) {
                imageUrls[index] = uploadUrl.url;
            }
        }
        let image = undefined;
        if (imageUrls.length > 0) {
            image = imageUrls[0];
        }

        let currentUser = this.props.global.currentUser;
        let token = currentUser.token;
        let contactNameStandardlized = utils.standardlizeName(contactName);

        let phone = contactPhone.replace(/\D/g, '')
        if (phone.startsWith('84'))
            phone = '0' + phone.slice(2, phone.length);


        let contactDto = {
            "contactID": contactID,
            "contactName": contactNameStandardlized || undefined,
            "contactSource": contactSource,
            "nameKhongDau": utils.locDauV2(contactNameStandardlized) || undefined,
            "contactPhone": phone,
            "contactEmail": contactEmail,
            "contactType": contactType,
            "avatar": image,
            "contactSaleState": contactSaleState,
            "userID": this.props.global.currentUser.userID,
            "recordID": recordID,
            "nhuCau": listContactNhucau,
            "favorite" : isFavorited, 
            "zaloStatus": 'request'
        };

        Contacts.requestPermission((err, permission) => {
            var newContact = {
                phoneNumbers: [{
                    label: "mobile",
                    number: contactDto.contactPhone,
                }],
                givenName: contactDto.contactName,
                recordID: contactDto.recordID || undefined
            }

            if (!contactSource || contactSource != 'device') {
                if (newContact.recordID) {
                    Contacts.updateContact(newContact, (err, updatedContact) => {
                        contactDto.recordID = updatedContact ? updatedContact.recordID : undefined
                        this.props.actions.saveContact(contactDto, token)
                            .then(res => {

                                let userID = this.props.global.currentUser.userID || undefined;
                                let token = this.props.global.currentUser.token || undefined;

                                // this.props.actions.onGroupContactFieldChange("savingContact", true);

                                if (res.status != 0) {
                                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                                } else {
                                    //clear input
                                    this.props.actions.onGroupContactFieldChange('selectedContact', res.data);
                                    this.props.request && this.props.request(this.props.text)
                                    // this.props.actions.getAllContact(
                                    //     { 'userID': userID, 'orderBy': this.props.group.orderBy }
                                    //     , (res) => {
                                    //     }
                                    //     , (error) => {
                                    //         console.log('server respond data: =====>>>>>', error)
                                    //     });

                                    this.refs.toastTop && this.refs.toastTop.show(
                                        "Cập nhật thành công!", DURATION.LENGTH_LONG);

                                    // setTimeout(() => {
                                        this.props.actions.onGroupContactFieldChange('selectedContactTab', DanhMuc.contactSaleStateMap[contactSaleState]);
                                        if (this.props.owner == 'ContactImport' || this.props.owner == 'NewHomeAgent') {
                                            Actions.Home({ type: 'reset' });
                                            Actions.Contact2({ owner: 'NewHomeAgent' });
                                        }
                                        else Actions.pop();
                                    // }, 300);
                                }
                            });
                    })
                } else {
                    Contacts.addContact(newContact, (err, createdContact) => {
                        contactDto.recordID = createdContact ? createdContact.recordID : undefined
                        this.props.actions.saveContact(contactDto, token)
                            .then(res => {

                                let userID = this.props.global.currentUser.userID || undefined;
                                let token = this.props.global.currentUser.token || undefined;

                                if (res.status != 0) {
                                    Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                                } else {
                                    //clear input
                                    this.props.actions.onGroupContactFieldChange('selectedContact', res.data);
                                    this.props.request && this.props.request(this.props.text)
                                    // this.props.actions.getAllContact(
                                    //     { 'userID': userID, 'orderBy': this.props.group.orderBy }
                                    //     , (res) => {
                                    //     }
                                    //     , (error) => {
                                    //         console.log('server respond data: =====>>>>>', error)
                                    //     });

                                    // this.refs.toastTop && this.refs.toastTop.show(
                                    //     "Cập nhật thành công!", DURATION.LENGTH_LONG);

                                    // setTimeout(() => {
                                        this.props.actions.onGroupContactFieldChange('selectedContactTab', DanhMuc.contactSaleStateMap[contactSaleState]);
                                        if (this.props.owner == 'ContactImport' || this.props.owner == 'NewHomeAgent') {
                                            Actions.Home({ type: 'reset' });
                                            Actions.Contact2({ owner: 'NewHomeAgent' });
                                        }
                                        else Actions.pop();
                                    // }, 300);
                                }
                            });
                    })
                }
            } else {
                this.props.actions.saveContact(contactDto, token)
                    .then(res => {

                        let userID = this.props.global.currentUser.userID || undefined;
                        let token = this.props.global.currentUser.token || undefined;

                        if (res.status != 0) {
                            Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
                        } else {
                            //clear input
                            this.props.actions.onGroupContactFieldChange('selectedContact', res.data);
                            this.props.request && this.props.request(this.props.text)
                            // this.props.actions.getAllContact(
                            //     { 'userID': userID, 'orderBy': this.props.group.orderBy }
                            //     , (res) => {
                            //     }
                            //     , (error) => {
                            //         console.log('server respond data: =====>>>>>', error)
                            //     });

                            this.refs.toastTop && this.refs.toastTop.show(
                                "Cập nhật thành công!", DURATION.LENGTH_LONG);

                            // setTimeout(() => {
                                this.props.actions.onGroupContactFieldChange('selectedContactTab', DanhMuc.contactSaleStateMap[contactSaleState]);
                                if (this.props.owner == 'ContactImport'  || this.props.owner == 'NewHomeAgent') {
                                    Actions.Home({ type: 'reset' });
                                    Actions.Contact2({ owner: 'NewHomeAgent' });
                                }
                                else Actions.pop();
                            // }, 300);
                        }
                    });
            }
        })


    }
}

class ImageItem extends React.Component {
    constructor(props) {
        super(props);
    }

    _onPhotoPressed() {
        this.props.onTakePhoto(`${this.props.imageIndex}`);
    }

    render() {
        log.info("Contact avatar.render ");
        let photo = this.props.photo;
        let contactName = this.props.contactName;
        let nameDefault = utils.geDefaultName(contactName);
        let nameColor = utils.getNameColor(nameDefault);
        if (photo && photo.uri) {
            return (
                <View style={styles.viewAvatarContact}>
                    <TouchableOpacity style={styles.touchAvatar} onPress={this._onPhotoPressed.bind(this)} >
                        <View style={[styles.imgItem, {}]}>
                            <Image style={styles.imgItem} source={photo} >
                                <LinearGradient colors={['rgba(50, 50, 50, 0.2)', 'rgba(50, 50, 50, 0.2)']}
                                                style={styles.linearGradientMain}>
                                    <FontAwesomeSolid name={'camera-alt'}
                                                      size={15}
                                                      color={'#fff'}
                                                      iconOnly={true}
                                                      noAction={true}
                                    />
                                    <Text style={[styles.textSave, {fontSize: 13, color: '#fff', marginTop: 6}]}>Thay ảnh</Text>
                                </LinearGradient>
                            </Image>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        } else {
            return (
                <View style={styles.viewAvatarContact}>
                    <TouchableOpacity style={styles.touchAvatar} onPress={this._onPhotoPressed.bind(this)} >
                        <View style={[styles.imgItem, { backgroundColor: 'rgba(217,235,235,1)'}]}>
                            <FontAwesomeLight name={'camera-alt'}
                                              size={28}
                                              color={gui.mainColor}
                                              iconOnly={true}
                                              noAction={true}
                            />
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }


    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewHeaderButton: {
        height: 64,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewLeftIcon: {
        height: 64,
        width: width / 2,
        paddingLeft: 16,
        justifyContent: 'center',
        paddingTop: gui.marginTopAgent
    },
    viewRightIcon: {
        height: 64,
        width: width / 2,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingTop: gui.marginTopAgent
    },
    textContact: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 13
    },
    viewTouchClose: {
        marginTop: 3
    },
    viewTouchButton: {
        paddingVertical: 3,
        paddingHorizontal: 3
    },
    textSave: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor,
    },
    viewAvatarContact: {
        height: 76,
        width: width,
        marginTop: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
    touchAvatar: {
        height: 76,
        width: 76,
        borderRadius: 38,
        backgroundColor: 'rgba(82,97,115,0.1)',
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewContent: {
        //flex: 1,
        width: width,
        height: 'auto', //height - (232 + gui.marginTopAgent),
        marginTop: 24,
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderColor: 'rgba(211,211,211, 0.5)'
    },
    viewNameInput: {
        height: 48,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row',
        alignItems: 'center'
    },
    viewIcon: {
        height: 48,
        width: 50,
        justifyContent: 'center',
        paddingLeft: 4

    },
    nameInput: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 48,
        borderColor: gui.mainTextColor,
        width: width - 50,
        textAlign: 'left',
        alignSelf: 'center',
        fontWeight: 'normal',
        color: gui.mainColor
    },
    viewDotRight: {
        height: 48,
        width: 16,
        justifyContent: 'center'
    },
    dotContent: {
        height: 8,
        width: 8,
        borderRadius: 4,
        backgroundColor: gui.dotColor
    },
    lineContent: {
        height: 1,
        width: width - 50,
        backgroundColor: 'rgba(211,211,211, 0.5)',
        marginLeft: 50
    },
    viewPotential: {
        height: 63,
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'flex-end'
    },
    switchPotential: {
        height: 33,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        position: 'absolute',
        right: 0,
        bottom: 8
    },
    mimgList: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        // paddingLeft: 12,
        // paddingRight: 10,
        backgroundColor: 'white'
    },
    coverContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.8,
        bottom: 2,
        left: 2,
        alignSelf: 'auto'
    },
    coverText: {
        alignItems: 'center',
        fontFamily: gui.fontFamily,
        fontSize: 12
    },
    imgItem: {
        width: 76,
        height: 76,
        borderRadius: 38,
        backgroundColor: "#eeedf0",
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0
    },
    deleteContent: {
        position: 'absolute',
        backgroundColor: 'white',
        opacity: 0.5,
        top: 10,
        right: 10,
        alignSelf: 'auto'
    },
    deleteButton: {
        alignItems: 'center'
    },
    captureIcon: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 5
    },
    viewModalStyle: {
        justifyContent: 'flex-start',
        height: 180,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },
    viewShowModal: {
        position: 'absolute',
        bottom: 10,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent',

    },
    viewSwipeButton: {
        backgroundColor: 'transparent',
        height: 106,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewButtonModal: {
        height: 52,
        width: width - 28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    textDelete: {
        color: '#f43838',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    lineSpaceButton: {
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewSwipeButton2: {
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    viewChooseBroker: {

        width: width - 32 - 60,
        height: 33,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    viewYesBroker: {
        height: 33,
        width: 100,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    textYestBroker: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 15
    },
    viewSwitchChange: {
        height: 33,
        width: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    viewTypeHide: {
        justifyContent: 'center',
        width: width,
        height: 'auto',
        paddingLeft: 16
    },
    viewSaleState: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        margin: 5,
        marginLeft: 0,
        marginRight: 0,
        width: width / 2 - 25,
        height: 25,
    },
    viewEachInfo: {
        height: 55,
        width: width - 32,
        marginLeft: 16,
        marginRight: 16
    },
    viewKieuNha: {
        height: 41,
        width: width - 32,
        flexDirection: 'row',
        marginTop: 13,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textSavePost: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: 'normal',
        color: gui.mainTextColor
    },
    touchKieuNha: {
        position: 'absolute',
        right: 16,
        marginRight: 8
    },
    dienTichInput: {
        marginTop: 8,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        height: 30,
        borderColor: gui.mainTextColor,
        width: width / 2,
        textAlign: 'right',
        alignSelf: 'center',
        fontWeight: '500',
        color: gui.mainTextColor
    },
    viewRowCover: {
        height: 'auto', //380
        width: width - 12,
        marginLeft: 6,
        marginRight: 6,
        paddingLeft: 10,
        marginTop: 6,
        backgroundColor: '#fff'
    },
    viewListContainer: {
        height: 'auto',
        width: width
    },
    viewTitle: {
        width: width - 22,
        //paddingLeft: 16,
        height: 61,
        //paddingTop: 6,
        justifyContent: 'center'
    },
    textCommon: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        color: gui.mainTextColor
    },
    viewDetailDemand: {
        height: 83,
        width: width - 22,
        //marginLeft: 16,
        justifyContent: 'center'
    },
    textGiaNha: {
        fontFamily: gui.fontFamily,
        fontSize: 17,
        color: gui.mainAgentColor,
        fontWeight: 'bold'
    },
    viewIcons: {
        height: 14,
        width: width - 22,
        flexDirection: 'row',
        alignItems: 'flex-end',
        marginTop: 10
    },
    viewItemIcon: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 20,
        height: 14
    },
    textIcon: {
        color: 'rgba(82,97,115,1)',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        marginLeft: 3
    },
    viewSquare: {
        flexDirection: 'row',
        height: 14,
        marginLeft: 0,
        alignItems: 'center'
    },
    textDemand: {
        color: gui.mainTextColor,
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        marginTop: 12
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    linearGradientMain: {
        width: 76,
        height: 76,
        borderRadius: 38,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 0,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewFavorite: {
        height: 44,
        width: width,
        flexDirection: 'row'
    },
    viewTextLeft: {
        height: 44,
        width: width/2,
        justifyContent: 'center',
        paddingLeft: 16
    },
    favoriteButton: {
        height: 44,
        width: width/2,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 13
    },
    startButton: {
        paddingHorizontal: 3,
        paddingVertical: 3
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(ModifyContact);