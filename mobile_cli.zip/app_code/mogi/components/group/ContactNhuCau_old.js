'use strict';
import React, { Component } from 'react';

import type, {
  StyleObj
} from 'react-native/Libraries/StyleSheet/StyleSheetTypes';

import {
  View, Text, StyleSheet, TextInput, ScrollView, ListView, TouchableOpacity, ViewPropTypes, StatusBar,
  ImageBackground, Alert, TouchableWithoutFeedback
} from 'react-native';
import Button from 'react-native-button';
import { Actions } from 'react-native-router-flux';
import ScalableText from 'react-native-text';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Tag from '../group/Tag';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import GiftedSpinner from "../GiftedSpinner";
import TextInputAuto from '../postAds/TextInputAuto';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import Camera from 'react-native-camera';

const Permissions = require('react-native-permissions');
import ImageResizer from 'react-native-image-resizer';
import moment from 'moment';
import cfg from "../../cfg";

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import DanhMuc from '../../assets/DanhMuc';
import MLikeTapButton2 from '../MLikeTapButton2';

import { GooglePlacesAutocomplete3 } from '../GooglePlacesAutocomplete3';
import RelandIcon from '../RelandIcon';


import { Map } from 'immutable';

import gui from "../../lib/gui";
import log from "../../lib/logUtil";

import HomeHeader from '../home/HomeHeader';

import MeContent from "../me/MeContent";
import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const actions = [
  globalActions,
  meActions,
  searchActions,
  groupActions,
  inboxActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

let hisTopUPDs = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
var count = 0;
var uploadFiles = [];
var errorMessage = '';

class Group extends React.Component {
  constructor(props) {
    super(props);
    let allDiaChinh = props.group.allDiaChinh;
    let duAns = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.DU_AN);
    let diaBans = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.TINH);
    this.state = {
      groupType: props.group.groupType,
      photos: props.group.photos,
      isOpenImagePicker: false,
      diaBans: diaBans,
      duAns: duAns,
      allDiaChinh: allDiaChinh,
      uploadUrls: [],
      toggleState: false,
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.group.photos !== this.props.group.photos) {
      this.setState({
        photos: nextProps.group.photos
      });
    }
    if (nextProps.group.allDiaChinh !== this.props.group.allDiaChinh) {
      let allDiaChinh = nextProps.group.allDiaChinh;
      let duAns = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.DU_AN);
      let diaBans = allDiaChinh.filter((e) => e.type == DanhMuc.placeType.TINH);
      this.setState({
        diaBans: diaBans,
        duAns: duAns,
        allDiaChinh: allDiaChinh
      });
    }
    if (nextProps.group.groupType !== this.props.group.groupType) {
      this.setState({
        groupType: nextProps.group.groupType,
      });
    }
  }

  // state = {
  //   diaBans: [],
  //   duAns: [],
  //   allDiaChinh: []
  // };

  onChangeDiaBans = (diaBans) => {
    this.setState({
      diaBans,
    });
  };

  onChangeDuAns = (duAns) => {
    this.setState({
      duAns,
    });
  };

  // renderTabBar() {
  //   return <AdsMgmtTabBar />
  // }

  render() {

    return (

      <View style={{ flex: 1 }}>
        {this._renderHeader()}

        {this._renderContent()}

        {this._renderButton()}        

        {this._renderLoadingView()}
      </View>


    )
    // } else {
    //   return (
    //     <Login />
    //   );
    // }
  };

  onKeyboardToggle(toggleState) {
    this.setState({ toggleState: toggleState });
  }

  _renderLoadingView() {
    if (this.props.group.postingGroup) {
      return (<View style={styles.resultContainer}>
        <GiftedSpinner size='large' color="grey" />
      </View>)
    }
  }

  _renderHeader() {
    let title = 'Nhu cầu';
    return (
      <View style={styles.headerView}>
        <TouchableOpacity onPress={this._onBack.bind(this)} style={styles.cancelView}>
          <ScalableText style={[styles.cancelText]}>Hủy</ScalableText>
        </TouchableOpacity>
        <View style={styles.headerView2}>
          <ScalableText style={[styles.headerText]}>{title}</ScalableText>
        </View>
      </View>
    );
  }

  labelExtractor = (tag) => tag;

  onLayoutLastTag = (endPosOfTag: number) => {
    const margin = 3;
    this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
    const inputWidth = Group.inputWidth(
      this.state.text,
      this.spaceLeft,
      this.wrapperWidth,
    );
    if (inputWidth !== this.state.inputWidth) {
      this.setState({ inputWidth });
    }
  }

  static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
    if (text === "") {
      return 90;
    } else if (spaceLeft >= 100) {
      return spaceLeft - 10;
    } else {
      return wrapperWidth;
    }
  }

  removeDiaBan = (index: number) => {
    const tags = [...this.state.diaBans];
    const allDiaChinh = [...this.state.allDiaChinh];

    let toRemove = tags[index];
    tags.splice(index, 1);
    this.setState({ diaBans: tags });

    const indexInDiaChinh = allDiaChinh.indexOf(toRemove);
    allDiaChinh.splice(indexInDiaChinh, 1);
    this.setState({ allDiaChinh: allDiaChinh });
  }

  removeDuAn = (index: number) => {
    const tags = [...this.state.duAns];
    const allDiaChinh = [...this.state.allDiaChinh];

    let toRemove = tags[index];
    tags.splice(index, 1);
    this.setState({ duAns: tags });

    const indexInDiaChinh = allDiaChinh.indexOf(toRemove);
    allDiaChinh.splice(indexInDiaChinh, 1);
    this.setState({ allDiaChinh: allDiaChinh });
  }


  _renderMucGia() {
    return (

      < View style={{ width: (width-32), flexDirection: 'row', height: 48 }} >        
        <View style={[styles.viewInput, {marginTop: 9, height: 48, width: (width-32)/2}]}>
          <View onPress={this.onBlurNamePost.bind(this)} style={{ width: width - 56 - 48 - 48 }}>
            <TextInput
              returnKeyType={'default'}
              blurOnSubmit={true}
              onBlur={() => this.onBlurNamePost()}              
              autoFocus={false}
              maxLength={60}
              autoCapitalize='none'
              autoCorrect={false}
              returnKeyType='done'
              //underlineColorAndroid='rgba(0,0,0,0)'
              style={[styles.viewTextInput, { width: width - 56 - 64 }]}
              placeholder="Từ" placeholderTextColor={gui.arrowColor}
              onChangeText={(text) => { this.onValueChange("name", text) }}
              value={this.props.group.name}
            />
          </View>
          {this._renderLine()}
        </View>

        <View style={[styles.viewInput, {marginTop: 9, height: 48, width: (width-32)/2}]}>

          <View onPress={this.onBlurNamePost.bind(this)} style={{ width: width - 56 - 48 - 48 }}>
            <TextInput
              returnKeyType={'default'}
              blurOnSubmit={true}
              onBlur={() => this.onBlurNamePost()}              
              autoFocus={false}
              maxLength={60}
              autoCapitalize='none'
              autoCorrect={false}
              returnKeyType='done'
              //underlineColorAndroid='rgba(0,0,0,0)'
              style={[styles.viewTextInput, { width: width - 56 - 64 }]}
              placeholder="Đến" placeholderTextColor={gui.arrowColor}
              onChangeText={(text) => { this.onValueChange("name", text) }}
              value={this.props.group.name}
            />
          </View>
          {this._renderLine()}
        </View>

      </View >

    )
  }

  onBlurNamePost() {
    dismissKeyboard();
    this.onKeyboardToggle(false);
    // this.setState({
    //     namePostLine: false
    // })
  }

  _renderMoTa() {
    return (
      <View style={[styles.blockView, {height:'auto', paddingBottom: 4}]}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Mô tả</ScalableText>
        </View>
        <View style={[styles.viewInput, { height: 'auto', flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center'}]}>
            <TextInputAuto
              autoFocus={false}
              blurOnSubmit={true}
              onBlur={() => this.onBlurNamePost()}
              autoCapitalize='none'
              maxLength={250}
              autoCorrect={false}
              returnKeyType='done'
              style={[styles.viewTextInput, { width: width - 32 - 16, height: 'auto'}]}
              placeholder="Hoạt động, quy định của sàn" placeholderTextColor={gui.arrowColor}
              onChangeText={(text) => { this.onMoTaChange("chiTiet", utils.normalizeName(text) ) }}
              value={this.props.group.chiTiet}
              multiline={true}
              
            />
          <View style={[styles.dotView, styles.dotContent]}></View>
        </View>
        <View style={[styles.viewLine, {marginTop: -4}]}></View>

      </View>
    )
  }

  
  _onPressDiaChinhColection() {
    Actions.NewLoginAutoComplete(
      {
        onSuggestionBuyPressed: (location) => this._collectSuggestionInfo(location),
        category: ["DIA_CHINH"],
        placeHolder: 'Nhập tên tỉnh/thành phố'
      });
  }


  _onPressDuAnColection() {
    Actions.NewLoginAutoComplete(
      {
        onSuggestionBuyPressed: (location) => this._collectSuggestionInfo(location),
        category: ["DU_AN"],
        placeHolder: "Nhập tên dự án"
      });
  }

  _renderKhuVuc() {
    var tags = this.state.diaBans.map((tag, index) => (
      <Tag
        type="DiaChinh"
        index={index}
        label={tag.placeName}
        isLastTag={this.state.diaBans.length === index + 1}
        onLayoutLastTag={this.onLayoutLastTag}
        removeIndex={this.removeDiaBan.bind(this)}
        tagColor='#dddddd'
        tagTextColor='#777777'
        //tagContainerStyle={ViewPropTypes.style}
        //tagTextStyle={Text.propTypes.style}
        key={index}
        tagContainerStyle={{marginBottom: 3}}
      />
    ))

    return (
      <View style={styles.blockView2}>
        <View style={styles.titleView}>
          <ScalableText style={[styles.titleText]}>Khu vực</ScalableText>
        </View>

        <View style={styles.tagInputContainer}>{tags}</View>

        <View style={[styles.viewTags, { flexDirection: 'row' }]}>
          <View style={[{ width: width - 48 }]}>
            <TouchableOpacity
              style={styles.viewTypeCountry}
              onPress={this._onPressDiaChinhColection.bind(this)}>
              <Text style={[styles.textDeny, { color: gui.colorMainBlur }]}>Nhập khu vực hoạt động</Text>
            </TouchableOpacity>
           

          </View>


          <View style={[styles.dotView, { marginTop: 8 }]}></View>
        </View>

        {this._renderLine()}

      </View>
    )
  }


  _renderContent() {
    return (
      <View style={{ flex: 1 }}>

        <KeyboardAwareScrollView
          contentContainerStyle={styles.scrollView}
          automaticallyAdjustContentInsets={false}
          style={styles.contentView}
                  
          keyboardShouldPersistTaps="always"
          keyboardDismissMode="none"
          extraScrollHeight={200}
          >

            {/* ======== */}
            {this._renderKhuVuc()}

            
            {this._renderMucGia()}
            

        </KeyboardAwareScrollView>

        {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
          style={[styles.searchButtonText2, {
            textAlign: 'right', color: gui.mainColor,
            backgroundColor: gui.doneKeyButton
          }]}>Xong</Button> : null}
        <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)} />
      </View>

    )
  }

  _onPress(data) {
    log.enter("DinhGiaPlacesAutocomplete._onPress", data);
    this._collectSuggestionInfo(data);
    // Actions.pop();
  }

  _updateBarColor() {
    if (this.props.owner != 'home') {
      StatusBar.setBarStyle('light-content');
    }
  }

  _onCancelPress() {
    // Actions.pop();
    this._updateBarColor();
  }

  _onBack() {
    Actions.pop();
  }


  onValueChange(key: string, value: string) {
    this.props.actions.onGroupFieldChange(key, value);
  }

  onMoTaChange(key: string, value: string) {
    this.props.actions.onGroupFieldChange(key, value);
    this.setState({chiTiet: value})
  }


  _renderLine() {
    return (
      <View style={styles.viewLine}></View>
    );
  }

  _renderShortLine() {
    return (
      <View style={styles.viewLine2}></View>
    );
  }

  _renderButton() {
    if (this.props.group.postingGroup)
      return (
        <View style={styles.searchButtonView}>
          <View
            style={styles.searchButton}
          >
            <Text style={styles.searchButtonText}>Thêm</Text>
          </View>
        </View>
      )
    return (
      <View style={styles.searchButtonView}>
        <TouchableOpacity
          style={styles.searchButton}
          onPress={this.onPostGroup.bind(this)}
        >
          <Text style={styles.searchButtonText}>Thêm</Text>
        </TouchableOpacity>
      </View>
    )
  }

  onPostGroup() {
    let { photos, place } = this.props.group;
    errorMessage = '';
    uploadFiles = [];
    for (let i = 0; i < photos.length; i++) {
      let filepath = photos[i].uri;
      if (filepath == '') {
        continue;
      }
      uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
    }
    if (!this.isValidInputData()) {
      Alert.alert('Thông báo', errorMessage, [{ text: 'Đóng', onPress: () => { } }]);
      this.props.actions.onGroupFieldChange('error', errorMessage);
      return;
    }

    this.onPostGroupChecked();

  }

  isValidInputData() {
    let errors = '';

    let { name, chiTiet, groupType } = this.props.group;


    if (!name || !name.trim()) {
      errors += ' (tên)';
    }

    if (!chiTiet || !chiTiet.trim()) {
      errors += ' (mô tả)';
    }

    if (!groupType) {
      errors += ' (loại nhóm)';
    }

    if (errors != '') {
      errorMessage = 'Bạn chưa chọn' + errors + '!';
      return false;
    }
    return true;
  }

  onPostGroupChecked() {
    let { photos } = this.props.group;
    errorMessage = '';
    uploadFiles = [];
    for (let i = 0; i < photos.length; i++) {
      let filepath = photos[i].uri;
      if (filepath == '') {
        continue;
      }
      uploadFiles.push({ filepath: filepath, index: i, needUpload: filepath.indexOf('http') != 0 });
    }

    this.props.actions.onGroupFieldChange("uploading", true);

    let countUpdateFiles = this.countNeedUploadFiles();
    if (!countUpdateFiles) {
      this.onSaveGroup();
      return;
    }

    count = 0;
    const userID = this.props.global.currentUser.userID;
    for (let i = 0; i < uploadFiles.length; i++) {
      if (errorMessage != '') {
        Alert.alert('Thông báo', errorMessage);
        this.props.actions.onGroupFieldChange('error', errorMessage);
        return;
      }
      let needUpload = uploadFiles[i].needUpload;
      if (!needUpload) {
        continue;
      }
      let index = uploadFiles[i].index;
      let filepath = uploadFiles[i].filepath;
      ImageResizer.createResizedImage(filepath, cfg.maxWidth, cfg.maxHeight, 'JPEG', cfg.imageQuality, 0, null).then((resizedImageUri) => {
        let ms = moment().toDate().getTime();
        let filename = 'Group_' + userID + '_' + ms + resizedImageUri.substring(resizedImageUri.lastIndexOf('.'));
        this.props.actions.onUploadGroupImage(index, filename, resizedImageUri, this.uploadCallBack.bind(this));
      }).catch((err) => {
        this.props.actions.onGroupFieldChange("uploading", false);
        log.error(err);
      });
    }
  }

  countNeedUploadFiles() {
    let count = 0;
    for (let i = 0; i < uploadFiles.length; i++) {
      let file = uploadFiles[i];
      if (file.needUpload) {
        count++;
      }
    }
    return count;
  }

  uploadCallBack = function (err, result, index) {
    let data = result && result.data ? result.data : '';
    if (err || data == '') {
      errorMessage = 'Upload ảnh không thành công!';
      this.props.actions.onGroupFieldChange('error', errorMessage);
      this.props.actions.onGroupFieldChange("uploading", false);
      return;
    }
    try {
      let { success, file } = JSON.parse(data);
      if (success) {
        let { url } = file;
        this.state.uploadUrls.push({ index: index, url: url });
        count++;
        if (count == this.countNeedUploadFiles()) {
          this.onSaveGroup();
        }
      } else {
        errorMessage = 'Upload ảnh không thành công!';
        this.props.actions.onGroupFieldChange('error', errorMessage);
        this.props.actions.onGroupFieldChange("uploading", false);
      }
    } catch (error) {
      errorMessage = 'Upload ảnh không thành công!';
      this.props.actions.onGroupFieldChange('error', errorMessage);
      this.props.actions.onGroupFieldChange("uploading", false);
    }
  }

  onSaveGroup() {
    let { uploadUrls } = this.state;
    let { groupID, name, chiTiet, photos } = this.props.group;

    let imageUrls = [];
    for (let i = 0; i < photos.length; i++) {
      let photo = photos[i];
      imageUrls.push(photo.uri);
    }
    for (let i = 0; i < uploadUrls.length; i++) {
      let uploadUrl = uploadUrls[i];
      let index = uploadUrl.index;
      if (index >= 0) {
        imageUrls[index] = uploadUrl.url;
      }
    }
    let image = undefined;
    if (imageUrls.length > 0) {
      image = imageUrls[0];
    }

    let currentUser = this.props.global.currentUser;
    let token = currentUser.token;


    let groupDto = {
      "groupID": groupID || undefined,
      "name": name || undefined,
      "groupType": this.state.groupType,
      "chiTiet": chiTiet,
      "createdBy": currentUser.userID,
      "image": image,
      "diaBan": this.state.allDiaChinh
    };

    this.props.actions.postGroup(groupDto, token)
      .then(res => {

        let userID = this.props.global.currentUser.userID || undefined;
        let token = this.props.global.currentUser.token || undefined;
        this.props.actions.getRelatedGroup({ userID: userID }, token, () => { });

        this.props.actions.onGroupFieldChange("postingGroup", false);

        if (res.status != 0) {
          Alert.alert("Thông báo", res.msg, [{ text: 'Đóng', onPress: () => { } }]);
        } else {

          this.props.doAfterSaveGroup && this.props.doAfterSaveGroup();
          this.props.actions.onRefreshGroupInbox(userID);
          //clear input
          Alert.alert(
            "Thông báo",
            groupID ? "Cập nhật sàn thành công." :
              "Xác nhận tạo nhóm môi giới thành công và đang chờ duyệt trước khi được đưa lên landber.",
            [{ text: 'Đóng', onPress: () => { this.props.actions.onGroupFieldChange('selectedGroupTab', 'sanQuanLy'); Actions.pop() } }]);

        }
      });
  }

  _renderRowDiaBan(data) {
    return (
      <View style={styles.rowDiaBan}>
        <Text style={[{ textAlign: 'right', marginRight: 5 }]}>{data}</Text>
      </View>
    )
  }

  _getPlaceByLocation(lat, lon, callback) {
    findApi.getPlaceByLocation(lat, lon).then((res) => {
      if (res.success) {
        callback(res.result);
      }
    });
  }

  _collectSuggestionInfo(position) {
    //dismisskeyboard
    this.onBlurNamePost();

    if (position.placeType == DanhMuc.placeType.DIA_DIEM) {
      this._getPlaceByLocation(position.location.lat, position.location.lon, (res) => {
        if (res) {
          let diaChinh = {
            codeDuAn: undefined,
            codeDuong: undefined,
            codeXa: res.codeXa || undefined,
            codeHuyen: res.codeHuyen || undefined,
            codeTinh: res.codeTinh || undefined,
            duAn: undefined,
            duong: undefined,
            xa: res.xa || position.xaName || undefined,
            huyen: res.huyen || position.huyenName || undefined,
            tinh: res.tinh || position.tinhName || undefined,
          };
          this._updateDiaChinhDuAn(position, diaChinh);
        }
      });
    } else {
      let diaChinh = {
        codeDuAn: position.duAn || undefined,
        codeDuong: position.duong || undefined,
        codeXa: position.xa || undefined,
        codeHuyen: position.huyen || undefined,
        codeTinh: position.tinh || undefined,
        duAn: position.duAnName || undefined,
        duong: position.duongName || undefined,
        xa: position.xaName || undefined,
        huyen: position.huyenName || undefined,
        tinh: position.tinhName || undefined,
        type: position.placeType,
        placeName: position.placeName
      };
      this._updateDiaChinhDuAn(position, diaChinh);
    }
  }

  _updateDiaChinhDuAn(position, diaChinh) {

    if (diaChinh.type == DanhMuc.placeType.DU_AN && !this.containsDuAn(diaChinh, this.state.duAns)) {
      this.setState({ duAns: [...new Set([...this.state.duAns, diaChinh])] });
      this.setState({ allDiaChinh: [...new Set([...this.state.allDiaChinh, diaChinh])] });
    }

    if (diaChinh.type == DanhMuc.placeType.TINH && !this.containsTinh(diaChinh, this.state.diaBans)) {
      this.setState({ diaBans: [...new Set([...this.state.diaBans, diaChinh])] });
      this.setState({ allDiaChinh: [...new Set([...this.state.allDiaChinh, diaChinh])] });
    }
  }

  containsTinh(obj, list) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].codeTinh === obj.codeTinh) {
        return true;
      }
    }
    return false;
  }

  containsDuAn(obj, list) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].codeDuAn === obj.codeDuAn) {
        return true;
      }
    }
    return false;
  }

  

}


export default connect(mapStateToProps, mapDispatchToProps)(Group);

var styles = StyleSheet.create({
  headerView: {
    backgroundColor: '#FFFFFFFF',
    height: 56,
    width: width,
    flexDirection: 'row'
  },
  contentView: {
    flex: 1,
    // width: width,
    // height: height - 80 - 135.4 - 49,
    backgroundColor: gui.groupBackground,
  },
  cancelView: {
    backgroundColor: 'transparent',    
    marginLeft: 23,
    width: 26,
    height: 18
  },
  dotView: {
    backgroundColor: 'lightgrey',
    // marginRight: 8,
    // marginTop: 6,
    width: 8,
    borderRadius: 4,
    height: 8
  },
  parentDotView: {
    width: 56,
    paddingRight: 8,
    height: 20,
    justifyContent: 'center',
    alignItems: 'flex-end'
  },
  headerView2: {
    backgroundColor: 'transparent',
    marginTop: 23,
    marginLeft: 16,
    width: 208,
    height: 36
  },
  headerText: {
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  cancelText: {
    fontSize: 12,
    fontWeight: 'normal',
    fontFamily: gui.fontFamily,
    color: gui.mainColor
  },
  titleView: {
    height: 24
  },
  titleText: {
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    color: '#526173'
  },
  pickCard: {
    height: 57,
    width: (width - 32) / 2,
    borderWidth: 1,
    borderColor: '#1BA7DF',
    justifyContent: 'center',
    alignItems: 'center'
  },
  blockView: {
    width: width - 32,
    // height: 97,
    height: 'auto',
    marginTop: 23.6,
    marginLeft: 16,
    //backgroundColor: 'lightgrey'
  },
  blockView2: {
    width: width - 32,
    marginTop: 23.6,
    marginLeft: 16,
    height: 'auto',
    //backgroundColor: 'lightgrey'
  },
  viewTags: {
    marginTop: 18,
    marginLeft: 0,
    height: 'auto',
    width: width - 32
  },
  viewInput: {
    marginTop: 18,
    marginLeft: 0,
    height: 'auto',
    width: width - 32,
  },
  viewTextInput: {
    fontFamily: gui.fontFamily,
    fontSize: 15,
    width: width - 32,
    paddingBottom: 8
  },
  viewLine: {
    borderTopWidth: 0.5,
    height: 1,
    borderColor: "#99526173",
    marginLeft: 0,
    marginTop: 11,
    width: width - 32,
    opacity: 0.6
  },
  viewLine2: {
    borderTopWidth: 0.5,
    height: 1,
    borderColor: "#99526173",
    marginLeft: 16,
    marginTop: 11,
    width: width - 48 - 48,
    opacity: 0.6
  },
  searchButtonView: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    height: 80,
    bottom: 0,
    width: width,
    backgroundColor: '#fff',
    //borderRadius: 24
  },
  searchButton: {
    height: 48,
    width: width - 32,
    backgroundColor: '#1BA7DF',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center'
  },
  scrollView: {
    backgroundColor: 'transparent',
    paddingBottom: 130,
  },
  searchButtonText: {
    color: '#FFFFFFFF',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: '500'
  },
  container: {
    backgroundColor: "#f2f2f2",
    flex: 1
  },

  label: {
    fontSize: 15,
    fontWeight: "500"
  },
  tagInputContainer: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  header: {
    backgroundColor: gui.mainColor,
    height: 64
  },
  viewListContainer: {
    // paddingBottom: 50
  },
  listStyle: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  rowDiaBan: {
    flex: 1,
    justifyContent: 'flex-start',
    // height: 100,

    // flexDirection: 'column'
  },

  input: {
    fontSize: 15,
    width: 200,
    height: 30,
    borderWidth: 1,
    alignSelf: 'center',
    padding: 5

  },
  viewTabInterest: {
    flexGrow: 1,
    flexDirection: 'row',
    width: width - 32,
    height: 57,
    marginTop: 23.6,
    //marginLeft: 16,
  },
  tab1: {
    height: 57,
    width: (width - 32) / 2,
    //borderColor: '#1A526173',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderLeftWidth: 1,

  },
  tab2: {
    height: 57,
    width: (width - 32) / 2,
    //borderColor: '#1A526173',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderRightWidth: 1,
  },
  mimgList: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    // paddingLeft: 12,
    // paddingRight: 10,
    backgroundColor: 'white'
  },
  coverContent: {
    position: 'absolute',
    backgroundColor: 'white',
    opacity: 0.8,
    bottom: 2,
    left: 2,
    alignSelf: 'auto'
  },
  coverText: {
    alignItems: 'center',
    fontFamily: gui.fontFamily,
    fontSize: 12
  },
  deleteContent: {
    position: 'absolute',
    backgroundColor: 'white',
    opacity: 0.5,
    top: 2,
    right: 2,
    alignSelf: 'auto'
  },
  deleteButton: {
    alignItems: 'center'
  },
  captureIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
    padding: 5
  },
  imgItem: {
    width: 48,
    height: 48,
    backgroundColor: "#1A526173",
    justifyContent: 'center',
    borderWidth: 0,
    opacity: 0.5
    // marginLeft: 5,
    //borderColor: gui.separatorLine,
  },
  viewModalStyle: {
    justifyContent: 'flex-start',
    height: 180,
    width: width - 28,
    marginVertical: 0,
    backgroundColor: 'transparent',
    alignItems: 'center'
  },
  viewShowModal: {
    position: 'absolute',
    bottom: 50,
    justifyContent: 'flex-start',
    alignItems: 'center',
    flex: 1,
    backgroundColor: 'transparent',

  },
  viewSwipeButton: {
    backgroundColor: 'transparent',
    height: 106,
    width: width - 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewButtonModal: {
    height: 52,
    width: width - 28,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12
  },
  textDelete: {
    color: '#f43838',
    fontSize: 17,
    fontFamily: gui.fontFamily,
    fontWeight: '400'
  },
  lineSpaceButton: {
    width: width - 28,
    backgroundColor: 'rgba(80,80,80,0.6)',
    borderColor: '#fff',
    borderTopWidth: 0.5,
    height: 1
  },
  viewSwipeButton2: {
    backgroundColor: 'white',
    height: 52,
    width: width - 28,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    marginTop: 8
  },
  loadingContent: {
    position: 'absolute',
    top: -23,
    left: width / 2,
    alignItems: 'center',
    justifyContent: 'center'
  },
  resultContainer: {
    position: 'absolute',
    // top: height/2,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center'
  },
  textDeny: {
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    color: gui.mainAgentColor,
    fontSize: 15
  },
  searchButtonText2: {
    margin: 0,
    padding: 10,
    paddingRight: 17,
    color: 'white',
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  dotContent: {
    position: 'absolute',
    right: 6,
    top: 10
  }
});