import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    ListView,
    Image,
    FlatList,    
} from 'react-native';
import FullLine from '../line/FullLine';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';

import gui from '../../lib/gui';
import utils from '../../lib/utils';
let { width, height } = utils.getDimensions();


class ContactHistory extends Component {
    constructor(props) {
        super(props);
        let data = [
            {   'title' : 'Tiêu đề',
                'content' : 'Làm gì, với Nguyễn Văn A',
                'time' : '04:21',
                'image' : 'https://instagram.fhan2-1.fna.fbcdn.net/t51.2885-15/sh0.08/e35/p640x640/23507611_1811231732501799_3826042749442850816_n.jpg',
            },
            {   'title' : 'Tiêu đề',
                'content' : 'Làm gì, với Nguyễn Văn A',
                'time' : '03:00',
                'image' : '',
            },
            {  'title' : 'Tiêu đề',
                'content' : 'Làm gì, với Nguyễn Văn A',
                'time' : '22:20',
                'image' : '',
            },
            {   'title' : 'Tiêu đề',
                'content' : 'Làm gì, với Nguyễn Văn A',
                'time' : '08:21',
                'image' : 'https://instagram.fhan2-1.fna.fbcdn.net/t51.2885-15/sh0.08/e35/p640x640/23507611_1811231732501799_3826042749442850816_n.jpg',
            },
        ];

        this.state = {
            data: data,
            contactHistoryList: props.groupContact.contactHistoryList
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.groupContact.contactHistoryList !== nextProps.groupContact.contactHistoryList) {
            this.setState({ contactHistoryList: nextProps.groupContact.contactHistoryList });
        }        
    }

    render() {
        return(
            <View style={styles.container}>
                {this._renderBody()}
            </View>
        )
    }

    _renderBody() {
        let data  = this.state.contactHistoryList;
        
        let historyEmpty = 'Lịch sử là nơi lưu lại nhật ký gọi, nhắn tin và những cuộc hẹn bạn đã tạo với liên lạc này';
        let sourceEmpty =  require('../../assets/image/icon_lich_su.png');
        if (data.length>0)
            return(
                <View style={styles.viewBody}>
                    <FlatList
                        data={data}
                        keyExtractor={(item, index) => "list" + index}
                        renderItem={(data) => this._renderRow(data.item)}
                        removeClippedSubviews={false}
                        enableEmptySections
                        style={styles.viewListContainer}
                    />
                </View>
            ) 
        else return(
            <View style={[styles.contentHistory]}>
                <Image  style={styles.imageEmptyHistory}
                        source={sourceEmpty}
                        defaultSource={sourceEmpty}
                        resizeMode={'cover'}
                />
                <Text style={[styles.textPhone,{marginTop: 24}]}>{historyEmpty}</Text>
            </View>
        );
    }

    _renderRow(data) {
        return(
            <View style={styles.viewRow}>
                <TouchableOpacity style={styles.viewRowAlert}>
                    {this._renderContent(data)}
                    {this._renderImageContent(data)}
                </TouchableOpacity>
                <FullLine style={{marginLeft: 16}}/>
            </View>
        )
    }

    _renderContent(data) {
        return(
            <View style={styles.viewContent}>
                <Text style={styles.textTitle} numberOfLines={2}>{data.content}</Text>                
                <Text style={styles.textTime} numberOfLines={1}>{utils.showChatTime(data.timeCreated)}</Text>
            </View>
        )
    }

    _renderImageContent(data) {
        // let adsList = data.adsList;
        // if (!adsList || adsList.length==0)
        //     return;

        // let relatedAds = adsList[0];
        // let image = relatedAds.image;

        let image = data.image
        let uriImage = { uri: image };
        let defaultSource = require('../../assets/image/register_avatar_icon.png');
        if(!data.image) {
            return(
                <View style={styles.imageContent}>
                </View>
            );
        }
        return(
            <View style={styles.imageContent}>
                <Image style={[styles.imageStyle, {borderRadius: 2}]}
                       source={uriImage}
                       defaultSource={defaultSource}
                       resizeMode={'cover'}
                />
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewBody: {
        flex: 1
    },
    contentHistory: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imageEmptyHistory: {
        width: 156,
        height: 156,
        marginTop: 44
    },
    viewListContainer: {
        flex: 1
    },
    viewRow: {
        height: 64,
        width: width
    },
    viewRowAlert: {
        height: 64,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        flexDirection: 'row'
    },
    imageStyle: {
        height: 43,
        width: 43
    },
    imageContent: {
        height: 64,
        width: 43,
        justifyContent: 'center'
    },
    viewContent: {
        height: 64,
        width: width - 75,
        justifyContent: 'center',
    },

    textTitle: {
        color: gui.mainTextColor,
        fontWeight: '500',
        fontSize: 15,
        fontFamily: gui.fontFamily
    },
    textTime: {
        color: 'rgba(169,183,200,1)',
        fontSize: 12,
        fontFamily: gui.fontFamily
    },
    textPhone: {
        color: gui.textShare,
        fontFamily: gui.fontFamily,
        fontSize: 15,
        alignSelf: 'center',
        textAlign: 'center'
    },
});

export default ContactHistory;