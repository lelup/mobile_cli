'use strict';

import  React, {Component} from 'react';

import {
    Text, View, ListView
    , TextInput, StyleSheet, RecyclerViewBackedScrollView
    , TouchableHighlight, StatusBar
} from 'react-native'

var gui = require("../../lib/gui");
var log = require("../../lib/logUtil");

var {GooglePlacesAutocomplete} = require('../groupSearch/GroupGooglePlacesAutocomplete');

class GroupPlacesAutoComplete extends React.Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        log.info("GroupPlacesAutoComplete.constructor");
    }

    focusInputSearch() {
        this.refs.googleSuggestion.focusInputSearch();
    }

    render() {
        return (
            <GooglePlacesAutocomplete
                ref={'googleSuggestion'}
                placeholder='Nhập Tỉnh, Huyện, Xã hoặc Dự án'
                minLength={2} // minimum length of text to search
                autoFocus={true}
                fetchDetails={false}
                onPress={this.props.onSelectPress}
                onCancelPress={this.props.onCancelPress}
                getDefaultValue={() => {
                  return ''; // text input default value
                }}
                textInputProps={{
                    autoCorrect: false
                }}
                styles={{
                  description: {
                    //fontWeight: 'bold',
                    fontFamily : gui.fontFamily,
                    fontSize: 15,
                    marginLeft:10,
                    marginRight: 10,
                    color: '#3a3a3c'
                  },
                  predefinedPlacesDescription: {
                    color: '#1faadb'
                  },
                  container: {
                    paddingTop: 0,
                    backgroundColor: 'white'
                  },
                  row : {
                    height: 44
                  },
                  separator:{
                    backgroundColor: "#E9E9E9",
                    marginLeft: 0,
                    marginRight: 0
                  }
                }}

                allPlace={this.props.allPlace} // Will add a 'Vị trí Hiện tại' button at the top of the predefined places list
                predefinedPlacesAlwaysVisible={false}
                predefinedPlaces = {this.props.predefinedPlaces}
                enablePoweredByContainer={false}
                category={["DIA_CHINH", "DU_AN", "DUONG", "DIA_DIEM"]}
            />
        );
    }
}

export default GroupPlacesAutoComplete;