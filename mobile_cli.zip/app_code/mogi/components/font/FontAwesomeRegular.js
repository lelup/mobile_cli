'use strict';
import React, {Component} from 'react';

import {View, Text, StyleSheet, TouchableHighlight} from 'react-native';
import gui from '../../lib/gui';
import glyphMap from './FontAwesome5.json';

var { createIconSet } = require('react-native-vector-icons');
// var glyphMap = { 'acreage': 62237, 'bath': 62157, 'bed': 62006, 'building': 61869, 'direction': 61732, 'bell':61683, 'camera': 61488,
//                 'search':61442, 'comment':61574};

var Icon = createIconSet(glyphMap, 'Font Awesome 5 Regular', 'FontAwesomeRegular.ttf');

class FontAwesomeRegular extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        var {touchableProps, iconProps, textProps, mainProps, text, color, name,size, noAction, iconOnly} = this.props;
        if (!noAction) {
            return(
                <TouchableHighlight underlayColor='transparent' style={[styles.touchable]} onPress={this.props.onPress}>
                    <View style={[styles.container, mainProps]} >
                        <Icon color={color||gui.mainColor} name={name} size={size||22} {...iconProps} />
                        {iconOnly ? null : <Text style={[styles.text, textProps]}>
                                {text}
                            </Text>
                        }
                    </View>
                </TouchableHighlight>
            );
        }
        return(
            <View style={[styles.container, mainProps]} >
                <Icon color={color||gui.mainColor} name={name} size={size||22} {...iconProps} />
                {iconOnly ? null : <Text style={[styles.text, textProps]}>
                        {text}
                    </Text>
                }
            </View>
        );
    }
}

var styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'center',
        padding: 0
    },
    touchable: {
        overflow: 'hidden',
    },
    icon: {
        marginRight: 10,
    },
    text: {
        fontSize: 17
        , fontFamily:gui.fontFamily
        , color:gui.mainColor
        , fontWeight: '600',
        backgroundColor: 'transparent',
        paddingLeft: 10
    },
});

FontAwesomeRegular.Icon = Icon;


export default FontAwesomeRegular;

