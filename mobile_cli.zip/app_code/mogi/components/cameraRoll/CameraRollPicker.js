import React, {Component} from 'react';
import {
    CameraRoll,
    Platform,
    StyleSheet,
    View,
    Text,
    ListView,
    ActivityIndicator,
    Alert,
    RecyclerViewBackedScrollView
} from 'react-native';
import ImageItem from './ImageItem';
import gui from '../../lib/gui';
import cfg from '../../cfg';

import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

import log from '../../lib/logUtil';

import PropTypes from 'prop-types';

class CameraRollPicker extends Component {
    constructor(props) {
        super(props);

        this.state = {
            images: [],
            selected: this.props.selected,
            lastCursor: null,
            loadingMore: false,
            noMore: false,
            dataSource: new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2}),
        };
    }

    componentWillMount() {
        this.fetch();
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            selected: nextProps.selected,
        });
    }

    fetch() {
        if (!this.state.loadingMore) {
            this.setState({loadingMore: true}, () => { this._fetch(); });
        }
    }

    _fetch() {
        let {groupTypes, assetType} = this.props;

        let fetchParams = {
            first: 50,
            groupTypes: groupTypes,
            assetType: assetType,
        };

        if (Platform.OS === "android") {
            // not supported in android
            delete fetchParams.groupTypes;
        }

        if (this.state.lastCursor) {
            fetchParams.after = this.state.lastCursor;
        }

        CameraRoll.getPhotos(fetchParams)
            .then((data) => this._appendImages(data), (e) => this._alertError(e));
    }

    _alertError(err){
        if (err.message && err.message.indexOf("User denied access")>=0){
            Alert.alert("Thông báo", gui.INF_CameraAccess);
        } else {
            log.warn(err);
        }
    }


    _appendImages(data) {
        let assets = data.edges;
        let newState = {
            loadingMore: false,
        };

        if (!data.page_info.has_next_page) {
            newState.noMore = true;
        }

        if (assets.length > 0) {
            newState.lastCursor = data.page_info.end_cursor;
            newState.images = this.state.images.concat(assets);
            newState.dataSource = this.state.dataSource.cloneWithRows(
                this._nEveryRow(newState.images, this.props.imagesPerRow)
            );
        }

        this.setState(newState);
    }

    render() {
        let {maximum} = this.props;
        let {dataSource} = this.state;
        let {
            // scrollRenderAheadDistance,
            initialListSize,
            pageSize,
            removeClippedSubviews,
            imageMargin,
            backgroundColor,
            emptyText,
            emptyTextStyle,
        } = this.props;

        let listViewOrEmptyText = dataSource.getRowCount() > 0 ? (
            <ListView
                style={{flex: 1,}}
                // scrollRenderAheadDistance={scrollRenderAheadDistance}
                initialListSize={initialListSize}
                pageSize={pageSize}
                //renderScrollComponent={(props) => <RecyclerViewBackedScrollView {...props}/>}
                removeClippedSubviews={removeClippedSubviews}
                renderFooter={this._renderFooterSpinner.bind(this)}
                onEndReached={this._onEndReached.bind(this)}
                dataSource={dataSource}
                renderRow={rowData => this._renderRow(rowData)}
            />
        ) : (
            <Text style={[{textAlign: 'center'}, emptyTextStyle]}>{emptyText}</Text>
        );

        return (
            <View
                style={[styles.wrapper, {padding: imageMargin, paddingRight: 0, backgroundColor: backgroundColor}]}>
                <View style={styles.viewTotalImage}>
                    <Text style={styles.textCountImage}>Số ảnh chọn {this.state.selected.length} /{maximum}</Text>
                </View>
                {listViewOrEmptyText}
            </View>
        );
    }

    _renderImage(item) {
        let {selected} = this.state;
        let {
            imageMargin,
            selectedMarker,
            imagesPerRow,
            containerWidth
        } = this.props;
        let uri = item.node.image.uri;
        let isSelected = (this._arrayObjectIndexOf(selected, 'uri', uri) >= 0) ? true : false;

        return (
            <ImageItem
                key={uri}
                item={item}
                selected={isSelected}
                imageMargin={imageMargin}
                selectedMarker={selectedMarker}
                imagesPerRow={imagesPerRow}
                containerWidth={containerWidth}
                onClick={this._selectImage.bind(this)}
            />
        );
    }

    _renderRow(rowData) {
        let items = rowData.map((item) => {
            if (item === null) {
                return null;
            }
            return this._renderImage(item);
        });

        return (
            <View style={styles.row}>
                {items}
            </View>
        );
    }

    _renderFooterSpinner() {
        if (!this.state.noMore) {
            return <ActivityIndicator style={styles.spinner} />;
        }
        return null;
    }

    _onEndReached() {
        if (!this.state.noMore) {
            this.fetch();
        }
    }

    _selectImage(image) {
        if (image.image.width < cfg.imageMinSize || image.image.height < cfg.imageMinSize) {
            Alert.alert("Thông báo", gui.INF_InvalidImageSize);
            return;
        }

        let {maximum, imagesPerRow, callback} = this.props;
        let selected = this.state.selected,
            index = this._arrayObjectIndexOf(selected, 'uri', image.image.uri);
        
        if (index >= 0) {
            selected.splice(index, 1);
        } else {
            if (selected.length < maximum) {
                selected.push(image);
            } else if (selected.length == 1 && maximum == 1) {
                selected[0] = image;
            }
        }

        this.setState({
            selected: selected,
            dataSource: this.state.dataSource.cloneWithRows(
                this._nEveryRow(this.state.images, imagesPerRow)
            ),
        });

        callback(this.state.selected, image);
    }

    _nEveryRow(data, n) {
        let result = [],
            temp = [];

        for (let i = 0; i < data.length; ++i) {
            if (i > 0 && i % n === 0) {
                result.push(temp);
                temp = [];
            }
            temp.push(data[i]);
        }

        if (temp.length > 0) {
            while (temp.length !== n) {
                temp.push(null);
            }
            result.push(temp);
        }

        return result;
    }

    _arrayObjectIndexOf(array, property, value) {
        return array.map((o) => { return o.image[property]; }).indexOf(value);
    }

}

const styles = StyleSheet.create({
    wrapper:{
        flex: 1,
    },
    row:{
        flexDirection: 'row',
        flex: 1,
        overflow: 'hidden'
    },
    marker: {
        position: 'absolute',
        top: 5,
        backgroundColor: 'transparent',
    },
    viewTotalImage:{
        width: width,
        height: 28,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingBottom: 2
    },
    textCountImage: {
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontSize: 13,
        fontWeight: '400'
    }
});

CameraRollPicker.propTypes = {
    // scrollRenderAheadDistance: PropTypes.number,
    initialListSize: PropTypes.number,
    pageSize: PropTypes.number,
    removeClippedSubviews: PropTypes.bool,
    groupTypes: PropTypes.oneOf([
        'Album',
        'All',
        'Event',
        'Faces',
        'Library',
        'PhotoStream',
        'SavedPhotos',
    ]),
    maximum: PropTypes.number,
    assetType: PropTypes.oneOf([
        'Photos',
        'Videos',
        'All',
    ]),
    imagesPerRow: PropTypes.number,
    imageMargin: PropTypes.number,
    containerWidth: PropTypes.number,
    callback: PropTypes.func,
    selected: PropTypes.array,
    selectedMarker: PropTypes.element,
    backgroundColor: PropTypes.string,
    emptyText: PropTypes.string,
    emptyTextStyle: Text.propTypes.style,
}

CameraRollPicker.defaultProps = {
    // scrollRenderAheadDistance: 500,
    initialListSize: 1,
    pageSize: 3,
    removeClippedSubviews: true,
    // groupTypes: '',
    maximum: 15,
    imagesPerRow: 3,
    imageMargin: 5,
    assetType: 'Photos',
    backgroundColor: 'white',
    selected: [],
    multiple: true,
    callback: function(selectedImages, currentImage) {
    },
    emptyText: '',
}

export default CameraRollPicker;
