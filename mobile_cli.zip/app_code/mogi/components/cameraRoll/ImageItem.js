import React, {Component} from 'react';
import {
    View,
    Image,
    StyleSheet,
    TouchableOpacity,
    ImageBackground
} from 'react-native';

import TruliaIcon from '../TruliaIcon';

import gui from '../../lib/gui';
import utils from '../../lib/utils';

import PropTypes from 'prop-types';

class ImageItem extends Component {
    constructor(props){
        super(props)
    }

    componentWillMount() {
        var {width} = utils.getDimensions();
        var {imageMargin, imagesPerRow, containerWidth} = this.props;

        if(typeof containerWidth != "undefined") {
            width = containerWidth;
        }
        this._imageSize = (width - (imagesPerRow + 1) * imageMargin) / imagesPerRow;
    }

    render() {
        var {item, selected, selectedMarker, imageMargin} = this.props;

        var marker = selectedMarker ? selectedMarker :
                <View style={styles.marker}>
                    <TruliaIcon
                        name="check" color={'white'} size={15}
                        mainProps={{width: 15, height: 15, marginLeft: 5, marginBottom: 5}}
                    />
                </View>
            ;

        var node = item.node;

        return (
            <TouchableOpacity
                style={{marginBottom: imageMargin, marginRight: imageMargin}}
                onPress={() => this._handleClick(node)}>
                <ImageBackground
                    source={{uri: node.image.uri}}
                    style={{height: this._imageSize, width: this._imageSize}} >
                    { (selected) ? marker : null }
                </ImageBackground>
            </TouchableOpacity>
        );
    }

    _handleClick(item) {
        this.props.onClick(item);
    }
}

const styles = StyleSheet.create({
    marker: {
        position: 'absolute',
        top: 5,
        right: 5,
        backgroundColor: gui.mainColor,
        borderColor: 'white',
        width: 25,
        height: 25,
        borderRadius: 12.5,
        borderWidth: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
})

ImageItem.defaultProps = {
    item: {},
    selected: false,
}

ImageItem.propTypes = {
    item: PropTypes.object,
    selected: PropTypes.bool,
    selectedMarker: PropTypes.element,
    imageMargin: PropTypes.number,
    imagesPerRow: PropTypes.number,
    onClick: PropTypes.func,
}

export default ImageItem;
