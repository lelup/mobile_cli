'use strict';
import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  Image
} from 'react-native';

import Swiper from 'react-native-swiper';

class IntroSwiper extends React.Component {

  render() {
    return (
      <Swiper style={styles.wrapper} showsButtons={false} //autoplay={true} autoplayTimeout={5}
              dot={<View style={[styles.dot, {backgroundColor: 'transparent'}]} />}
              activeDot={<View style={[styles.dot, {backgroundColor: 'transparent'}]}/>}
      >
        <View style={styles.slide} title={
          <Text style={styles.text} numberOfLines={2}>photo_detail_blank</Text>}
        >
          <Image
            style={styles.image} resizeMode = {'cover'}
            source={require('../assets/image/photo_detail_blank.jpg')}
          />
        </View>

        <View style={styles.slide}
          title={<Text style={styles.text} numberOfLines={1}>reland_house_large</Text>}>
          <Image
            style={styles.image}
            source={require('../assets/image/reland_house_large.jpg')}
          />
        </View>
        <View style={styles.slide}
          title={<Text style={styles.text} numberOfLines={1}>react_logo</Text>}>
          <Image
            style={styles.image}
            source={require('../assets/image/react_logo.png')}
          />
        </View>
        <View style={styles.slide}
          title={<Text style={styles.text} numberOfLines={1}>logo</Text>}>
          <Image
            style={styles.image}
            resizeMode={Image.resizeMode.cover}
            source={require('../assets/image/logo.png')}
          />
        </View>

      </Swiper>
    );
  }
}


const styles = StyleSheet.create({
  wrapper: {
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'transparent',
    //
  },
  text: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    top: -250,
    alignSelf:'center',
    justifyContent: 'center',
  },
  image: {
    flex: 1,
    marginTop: 0
  },
  dot : {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
    bottom: 110
  },
});

export default IntroSwiper;