import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../lib/gui';
import ScalableText from 'react-native-text';
import utils from '../lib/utils';

const {width}= utils.getDimensions();

export default class MLikeTapButton extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';
        let mainStyle = selected ? 'wrapperSelected' : 'wrapper';

        return (
            <TouchableOpacity
                onPress={() => this.props.onPress(this.props.name)}>
                <View style={[styles.mainView, styles[mainStyle], this.props.mainProps]}>
                    <ScalableText style={styles[myStyle]} >
                        {this.props.children}
                    </ScalableText>
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    mainView: {
        flexGrow: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        borderWidth: 1,
        borderRadius: 5,
        margin: 10,
        width: width/2 - 25,
        borderColor: gui.mainColor
    },
    wrapper: {
        backgroundColor: '#fff',
        borderColor: gui.mainTextColor
    },
    wrapperSelected: {
        backgroundColor: gui.mainColor,
        borderColor: gui.mainColor
    },
    buttonText: {
        flexGrow: 1,
        alignSelf:'center',
        fontSize: 14,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: gui.mainTextColor,
        fontWeight : 'normal'
    },
    buttonTextSelected: {
        flexGrow: 1,
        alignSelf:'center',
        fontSize: 14,
        fontFamily: gui.fontFamily,
        padding: 5,
        color: '#fff',
        fontWeight : 'bold'
    }
});