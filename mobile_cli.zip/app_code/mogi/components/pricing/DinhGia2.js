'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, StatusBar} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from "../../lib/gui";
import util from "../../lib/utils";

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

const {width, height} = util.getDimensions();

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

class DinhGia2 extends React.Component {
    constructor(props) {
        super(props);
        let loaiTin = 'ban' ; //props.loaiTin;
        StatusBar.setBarStyle('dark-content');
        this.state = {
            loaiTin: loaiTin ? loaiTin : '' ,
        };
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyDinhGia()}
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                        Định giá
                    </Text>
                </View>
                <View
                    style={styles.viewEdit}>
                    <View style={{paddingLeft: 7, paddingRight: 15}}>
                    </View>
                </View>
            </View>
        );
    }


    _renderBodyDinhGia() {

        let textDuAn = 'Xác định giá nhà thuộc 1 dự án dựa theo các nhà đã bán và đang bán của dự án đó.';
        let textViTri = 'Xác định giá nhà tại 1 vị trí dựa theo các nhà đã bán và đang bán xung quanh vị trí đó.';

        return(
            <View style={styles.viewBody}>
                <View style={styles.viewTopHeader}></View>
                <FullLine/>
                {this._renderDinhGiaDuAn()}
                <FullLine/>
                <View style={styles.viewTextDetail}>
                    <Text style={styles.textDetailContent}>{textDuAn}</Text>
                </View>
                <FullLine/>
                {this._renderDinhGiaViTri()}
                <FullLine/>
                <View style={styles.viewBottom}>
                    <Text style={styles.textDetailContent}>{textViTri}</Text>
                </View>
            </View>
        );
    }

    _renderDinhGiaDuAn() {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onDuAn.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={styles.viewIcon}>
                        <FontAwesomeLight
                                    name="building"
                                    color='#fff'
                                    mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 0}}
                                    size={19}
                                    noAction={true}
                                    iconOnly={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <Text style={styles.textDuAn}>Định giá theo dự án</Text>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _renderDinhGiaViTri() {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onViTri.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={styles.viewIcon}>
                        <FontAwesomeLight
                            name="map-pin"
                            color='#fff'
                            mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 0}}
                            size={20}
                            noAction={true}
                            iconOnly={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <Text style={styles.textDuAn}>Định giá theo vị trí</Text>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        ) ;
    }

    _onDuAn () {
        Actions.DinhGiaDuAn({loaiTin: this.state.loaiTin});
    }

    _onViTri() {
        Actions.DinhGiaViTri({loaiTin: this.state.loaiTin});
    }

}
export default DinhGia2;

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 63,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewTopHeader: {
        width: width,
        height: 34,
        backgroundColor: '#f3f3f5'
    },
    viewDuAn: {
        width: width,
        height: 43,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextDetail: {
        width: width,
        height: 63,
        backgroundColor: '#F6F6F6',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 7,
        paddingLeft: 12,
        paddingRight: 8
    },
    viewBottom: {
        flex: 1,
        backgroundColor: '#F6F6F6',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 7,
        paddingLeft: 12,
        paddingRight: 8
    },
    imageHelp: {
        transform: [
            {scaleX: 0.7},
            {scaleY: 0.7}
        ],
        marginLeft: 12,
        color: '#3ab54a'
    },
    viewTextCenter: {
        width: width - 100,
        height: 43,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    textDuAn: {
        fontSize: 15,
        color: gui.textAgentSolid,
        fontWeight: 'normal',
        marginLeft: 10
    },
    viewArrow: {
        width: 40,
        height: 43,
        justifyContent: 'center',
        alignItems: 'center'
    },
    iconPosition: {
        width: 60,
        height: 43,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewIcon: {
        width: 30,
        height: 30,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5
    },
    textDetailContent: {
        fontSize: 13,
        fontFamily:gui.fontFamily,
        color:gui.textShare,
        paddingLeft: 15
    },
    titleText: {
        backgroundColor: 'transparent',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600'
    }
});