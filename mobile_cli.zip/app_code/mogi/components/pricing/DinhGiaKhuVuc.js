'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, TextInput} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";

import Toast, {DURATION} from '../toast/Toast';

import Button from 'react-native-button';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import dismissKeyboard from 'react-native-dismiss-keyboard';

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

const {width, height} = util.getDimensions();

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

class DinhGiaKhuVuc extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dienTich: '',
            soTang: '',
            duAn: ''
        };
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyDinhGia()}
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                        Định giá theo khu vực
                    </ScalableText>
                </View>
                <View
                    style={styles.viewEdit}>
                    <TouchableOpacity onPress={this._onHome.bind(this)} underlayColor="transparent"
                                      style={{paddingLeft: 7, paddingRight: 15}}
                    >
                        <Text style={styles.titleText}>Hủy</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _onHome() {
        Actions.popTo('root');
    }

    _renderBodyDinhGia() {
        return(
            <View style={styles.viewBody}>
                <ScrollView style={[styles.scrollView]}
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="none"
                            ref="_scrollview"
                >
                    <View style={styles.viewTopHeader}></View>

                    {this._renderNameKhuVuc()}
                    <View style={styles.viewDacDiem}>
                        <Text style={styles.textDetailContent}>ĐẶC ĐIỂM BẤT ĐỘNG SẢN</Text>
                    </View>
                    <FullLine/>
                    {this._renderLoaiNhaDat()}
                    <FullLine style={{marginLeft: 17}}/>
                    {this._renderDienTich()}
                    <FullLine/>
                    <View style={[styles.viewTopHeader, {height:35}]}></View>
                    <FullLine/>
                    <View style={styles.viewBottom}>
                        <View style={styles.viewThietLap}>
                            <Text style={styles.textThietLap}>Thiết lập lại</Text>
                        </View>
                        <FullLine/>
                    </View>
                </ScrollView>
                {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                  style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                              backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

                <View style={styles.viewThucHien}>
                    <Text style={styles.textAction}>Thực hiện</Text>
                </View>
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _renderNameKhuVuc() {
        return(
            <View style={styles.loaiNhaDat}>
                <View style={styles.viewWidth}>
                    <Text style={[styles.textThietLap, {fontSize: 17, color: '#000'}]}>
                        Khu vực
                    </Text>
                </View>
                <View style={styles.viewLoaiNha}>
                    <ScalableText style={[styles.textThietLap, {fontSize: 15, color: '#9fa0a4'}]}>{gui.CHON_KHU_VUC}</ScalableText>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </View>
        );
    }

    _renderLoaiNhaDat () {
        return(
            <View style={styles.loaiNhaDat}>
                <View style={styles.viewWidth}>
                    <Text style={[styles.textThietLap, {fontSize: 17, color: '#000'}]}>
                        Loại nhà đất
                    </Text>
                </View>
                <View style={styles.viewLoaiNha}>
                    <ScalableText style={[styles.textThietLap, {fontSize: 15, color: '#9fa0a4'}]}>Chọn loại nhà đất</ScalableText>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </View>
        );
    }

    _renderDienTich () {
        return(
            <View style={styles.loaiNhaDat}>
                <View style={[styles.viewWidth, {width: 75}]}>
                    <Text style={[styles.textThietLap, {fontSize: 17, color: '#000'}]}>
                        Diện tích
                    </Text>
                </View>
                <View style={styles.viewDienTich}>
                    <TextInput
                        keyboardType={'numeric'}
                        selectTextOnFocus={true}
                        returnKeyType='done'
                        underlineColorAndroid='rgba(0,0,0,0)'
                        placeholder="Nhập diện tích ..." placeholderTextColor='#adb4b7'
                        style={styles.inputVayNew}
                        onChangeText={(dienTich) => this._onDienTichChange(dienTich)}
                        value={this.state.dienTich}
                    />
                </View>
                <View style={styles.viewUnitArea}>
                    <Text style={[styles.textThietLap, {fontSize: 15, color: '#9fa0a4'}]}>m²</Text>
                </View>
            </View>
        );
    }

    _onDienTichChange(dienTich) {
        let zeroNumber = '0' || '00';
        if (dienTich === zeroNumber) {
            dienTich = '';
        }
        let dienTichNumber = util.monthNumeric(dienTich);
        let valTime = dienTichNumber && !isNaN(dienTichNumber) ? Number(dienTichNumber) : 0;
        if(valTime == 0 && Number(this.state.soTang) == 0) {
            // this.refs.toastTop && this.refs.toastTop.show('Bạn chưa chọn diện tích!',DURATION.LENGTH_SHORT);
            this.setState({dienTich: ''});
            return ;
        }

        this.setState({
            dienTich:  dienTichNumber
        });
    }

}
export default DinhGiaKhuVuc;

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width,
        borderBottomWidth: 1,
        borderColor: '#dcdcdc'
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 63,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.mainTextColor,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        backgroundColor: '#fff',
        // paddingBottom: 43,
        flex: 1
    },
    viewTopHeader: {
        width: width,
        height: 34,
        backgroundColor: '#f3f3f5'
    },
    loaiNhaDat: {
        width: width,
        backgroundColor: '#fff',
        height:42,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginLeft: 17
    },
    viewDacDiem: {
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        width: width,
        backgroundColor: '#f3f3f5',
        height: 56,
        paddingTop: 7,
        paddingBottom: 6,
        paddingRight: 8
    },
    viewThietLap: {
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        height:42
    },
    viewDuAn: {
        width: width,
        height: 43,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextCenter: {
        width: width - 100,
        height: 43,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    textDuAn: {
        fontSize: 17,
        color: '#000',
        fontWeight: '500',
        marginLeft: 10
    },
    iconPosition: {
        width: 42,
        height: 42,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewIcon: {
        width: 35,
        height: 35,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5
    },
    viewBottom: {
        flex: 1,
        backgroundColor: '#f3f3f5',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewThucHien: {
        backgroundColor: '#fa4917',
        width: width,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        bottom: 0,
        position:'absolute'
    },
    textAction: {
        color: 'white',
        fontSize: 18,
        fontFamily: gui.fontFamily,
        fontWeight: '600'
    },
    textThietLap: {
        color: '#ff0000',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    textDetailContent: {
        fontSize: 12,
        fontFamily:gui.fontFamily,
        color:'#818286',
        paddingLeft: 17,
        fontWeight: '400'
    },
    viewWidth: {
        width: 100,
        height: 42,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewLoaiNha: {
        width: width - 157,
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'flex-end',
        height: 42
    },
    viewDienTich: {
        width: width -142,
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'flex-start',
        height: 42,
        paddingLeft: 5
    },
    viewArrow: {
        width: 40,
        height: 43,
        justifyContent: 'center',
        alignItems: 'center'
    },
    inputVayNew: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 4,
        paddingRight: 10,
        height: 32,
        marginLeft: 0,
        width: width -110,
        textAlign: 'left',
        alignSelf: 'flex-start',
        color: '#000',
        paddingVertical: 0
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : '500'
    },
    viewDuAnPosition: {
        backgroundColor: '#fff',
        height: 48,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginLeft: 13
    },
    viewUnitArea: {
        width: 50,
        height: 42,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 15
    },
    titleText: {
        backgroundColor: 'transparent',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600'
    }
});