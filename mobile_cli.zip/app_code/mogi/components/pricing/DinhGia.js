import React, { Component } from 'react';
import {
  Text,
  TextInput,
  View,
  Image,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Alert,
  ScrollView,
  StatusBar
} from 'react-native';

import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

import Icon from 'react-native-vector-icons/FontAwesome';
import LikeTabButton from '../LikeTabButton';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import GiftedSpinner from 'react-native-gifted-spinner';

import {Actions} from 'react-native-router-flux';

import Button from 'react-native-button';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import gui from '../../lib/gui';

import danhMuc from '../../assets/DanhMuc';

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import Login from '../login/Login';

import TruliaIcon from '../TruliaIcon';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as pricingActions from '../../reducers/pricing/pricingActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

const actions = [
  globalActions,
  pricingActions,
  postAdsActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}


class DinhGia extends React.Component {
  constructor(props) {
    super(props);
    StatusBar.setBarStyle('light-content');
    
    this.state = {
      loaiTin: 'ban',
      loaiNhaDat: {key: null, value: 'Chọn loại nhà đất'},
      loaiNhaDatBan: {key: null, value: 'Chọn loại nhà đất'},
      loaiNhaDatChoThue: {key: null, value: 'Chọn loại nhà đất'},
      diaChi: "Chọn vị trí trên bản đồ",
      location: {},
      placeType: danhMuc.placeType.DIA_DIEM,
      duAn: {},
      dientich: '',
      showMoRong: false,
      onThucHienPressed: false,
      toggleState: false
    };
  }

  componentWillMount() {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        var location = {
          lat: position.coords.latitude,
          lon: position.coords.longitude
        };
        this.setState({ location: location });
      },
      (error) => {
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
    );
  }

  _onLoaiNhaDatSelected(selected) {
    let loaiNhaDat = {
      key: selected.key,
      value: selected.value
    }

    if (this.state.loaiTin =='ban'){
      this.setState({loaiNhaDatBan: loaiNhaDat});
    } else {
        this.setState({loaiNhaDatChoThue: loaiNhaDat});
    }
  }

  _onVitri(position) {
    this.setState({ diaChi: position.diaChi,
                    duAn: position.duAn,
                    placeType: position.placeType,
                    location: position.location});
  }

  _renderThietLap() {
    return (
      <View style={styles.viewNenMoRong}>
        <FullLine />
        <TouchableOpacity disabled={this.state.onThucHienPressed}
            onPress={this.onResetFilters.bind(this)} style={styles.viewMoRong}>
          <Text style={styles.textThietLap}>Thiết lập lại</Text>
        </TouchableOpacity>
        <FullLine />
      </View>

    );
  }

  onResetFilters() {
    this.setState(
      {
        loaiTin: 'ban',
        loaiNhaDatBan: {key: null, value: 'Chọn loại nhà đất'},
        loaiNhaDatChoThue: {key: null, value: 'Chọn loại nhà đất'},
        diaChi: '',
        duAn: '',
        dientich: '',
        location: {},
        showMoRong: false
      });
  }

  // onMoRongPress() {
  //   this.setState({ showMoRong: true });
  // }

  _onThucHien() {
    this.setState({onThucHienPressed: true});

    if (!this.isValidData()){
      this.setState({onThucHienPressed: false});
      return;
    }

    let loaiNhaDat = [this.state.loaiTin=='ban' ? this.state.loaiNhaDatBan.key : this.state.loaiNhaDatChoThue.key];


    let codeDuAn = '';

    if (this.state.duAn && this.state.duAn.duAn && this.state.duAn.duAn.length>0)
      codeDuAn = this.state.duAn.duAn;

    let dienTich = -1;
    if (this.state.dientich && this.state.dientich.length >0)
        dienTich = Number(this.state.dientich);
    
    let condition = {
      loaiTin:this.state.loaiTin == 'ban' ? 0 : 1,
      loaiNhaDat:loaiNhaDat,
      position: this.state.location,
      codeDuAn: codeDuAn.length>0 ? codeDuAn : undefined,
      dienTich: dienTich >0 ? dienTich : undefined
    }

    let duAn = (this.state.duAn && this.state.duAn.fullName && this.state.duAn.fullName.length>0) ? this.state.duAn.fullName : undefined;
    this.props.actions.calculatePricing(condition).then(
        (res) =>{
          if (res.success){
            this.setState({onThucHienPressed: false});
            Actions.KetQuaDinhGia({ loaiTin: this.state.loaiTin == 'ban' ? "bán" : "thuê",
                                    data: res.data,
                                    diaChi: this.state.diaChi,
                                    loaiNhaDat: this.state.loaiTin == 'ban' ? this.state.loaiNhaDatBan.value : this.state.loaiNhaDatChoThue.value,
                                    duAn: duAn})
          }else {
            this.setState({onThucHienPressed: false});
            Alert.alert('Thông báo', 'Không có thông tin định giá khu vực bạn cần tìm.');
          }
        }
    );

  }

  isValidData(){

      if (this.state.loaiTin == 'ban'){
          if (!this.state.loaiNhaDatBan.key){
              Alert.alert('Thông báo', 'Bạn nhập thiếu loại nhà đất.');
              return false;
          }
      } else {
          if (!this.state.loaiNhaDatChoThue.key){
              Alert.alert('Thông báo', 'Bạn nhập thiếu loại nhà đất.');
              return false;
          }
      }

      if (JSON.stringify(this.state.location) == JSON.stringify({}) || this.state.diaChi == 'Chọn vị trí trên bản đồ'){
      Alert.alert('Thông báo', 'Bạn chưa chọn vị trí trên bản đồ.');
      return false;
    }

    if (this.state.dienTich && isNaN(this.state.dienTich)) {
      Alert.alert('Thông báo', 'Diện tích sai định dạng. Bạn vui lòng nhập kiểu số!');
      return false;
    }

    return true;
  }

  // _renderMoRong() {
  //   if (!this.state.showMoRong) {
  //     return (
  //         <View style={styles.viewNenMoRong}>
  //           <FullLine />
  //           <TouchableOpacity disabled={this.state.onThucHienPressed}
  //                             onPress={this.onMoRongPress.bind(this)} style={styles.viewMoRong}>
  //             <Text style={styles.textMoRong}>Mở rộng</Text>
  //           </TouchableOpacity>
  //           <FullLine />
  //         </View>
  //     );
  //   }
  // }

  _renderDienTich() {
    if (this.state.showMoRong) {
      return (
          <View style={styles.viewNenMoRong} >
            <FullLine />
            <View style={styles.viewShowDienTich}>
              <View style={{flex:1}}>
                <Text style={styles.textViTri}>Diện tích (m²)</Text>
              </View>
              <View style={{flex:1, right: 15}}>
                <TextInput
                  keyboardType={'numeric'}
                  returnKeyType='done'
                  style={styles.inputDienTich}
                  onChangeText={(text) => this._onDienTichChange(text)}
                  value={this.state.dienTich && this.state.dienTich.length>0 ? this.state.dienTich : ''}
                />
              </View>
            </View>
            <FullLine />
          </View>
      )
    }
  }

  _onDienTichChange(text){
    let value = text.replace(',','.');
    this.setState({dienTich: value});
  }

  _onLoaiNhaDat() {
    let loaiNhaDatKeys = [];
    // TODO: need to verify this hard code block
    // Ban: Ban can ho chung cu; Ban nha rieng; 
    //
    if (this.state.loaiTin =='ban'){
      loaiNhaDatKeys = [1,2,3,4];
    } else {
      loaiNhaDatKeys = [1,2,3,4,5,6];
    }
    Actions.LoaiNhaDat({  loaiTin: this.state.loaiTin,
                          loaiNhaDatKeys: loaiNhaDatKeys,
                          loaiNhaDat: this.state.loaiTin=='ban' ? this.state.loaiNhaDatBan.key : this.state.loaiNhaDatChoThue.key,
                          onPress: this._onLoaiNhaDatSelected.bind(this) })
  }

  _onViTriPress() {
    Actions.DinhGiaMapView(
        {   onPress: this._onVitri.bind(this),
            diaChi: this.state.diaChi,
            location: this.state.location,
            placeType: this.state.placeType,
            duAn: this.state.duAn
        });
  }

  _onLoaiTinChange(value) {
    this.setState(
        { loaiTin: value,
          loaiNhaDat: {key: null, value: 'Chọn loại nhà đất'}});
  }

  _getLoaiNhaDatDisplay(){
    if (this.state.loaiNhaDat == {})
        return "";
    return this.state.loaiNhaDat.value.substring(0, 25);
  }

  render() {
    if (this.props.global.loggedIn) {
        StatusBar.setBarStyle('light-content');
        return (
          <View style={styles.container}>

            <View style={[styles.toolbar, Platform.OS === 'ios' ? { marginTop: 0 } : null]}>
              <TouchableOpacity onPress={() => Actions.pop()} style={styles.modalBack} >
                  <TruliaIcon noAction={true}
                              name="arrow-left" color="white" size={26}
                              mainProps={{paddingLeft: 0}}
                  >
                  </TruliaIcon>
              </TouchableOpacity>
              <View style={styles.viewTitle}>
                <Text style={styles.textTitle}>Định giá nhà đất</Text>
              </View>
              <View style={styles.viewCan}></View>
            </View>

            <View style={styles.viewBody}>
                {this._renderTabChoice()}
              <FullLine />
                <ScrollView
                    keyboardShouldPersistTaps="always"
                    keyboardDismissMode={'none'}
                    automaticallyAdjustContentInsets={true}
                    vertical={true}>
                  <View style={styles.viewNhaDat}>

                    <View style={styles.viewDacDiem}>
                      <Text style={styles.textDacDiem}>NHẬP THÔNG TIN CỦA NHÀ ĐẤT CẦN ĐỊNH GIÁ</Text>
                    </View>
                    <FullLine />
                    {this._renderLoaiNhaDat()}
                    <FullLine style={{marginLeft: 28}} />
                    {this._renderViTri()}
                  </View>
                  <FullLine />
                  {this._renderDienTich()}
                  {/*this._renderMoRong()*/}
                  {this._renderThietLap()}
                </ScrollView>
            </View>
              {this.state.toggleState ? <Button onPress={() => dismissKeyboard()}
                                                style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,
                                                backgroundColor: gui.doneKeyButton }]}>Xong</Button> : null}

              <KeyboardSpacer topSpacing={-40} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>

              {this._renderThucHienButton()}
          </View>

        );
    } else {
        return (
            < Login />
        );
    }
  }

  _renderTabChoice() {
    return(
        <View style={styles.viewBanThue}>
          <LikeTabButton name={'ban'}
                         onPress={this._onLoaiTinChange.bind(this)}
                         selected={this.state.loaiTin == 'ban'}>Giá Bán</LikeTabButton>
          <LikeTabButton name={'thue'}
                         onPress={this._onLoaiTinChange.bind(this)}
                         selected={this.state.loaiTin == 'thue'}>Giá Cho Thuê</LikeTabButton>
        </View>
    );
  }
  _renderLoaiNhaDat() {
    return(
        <TouchableOpacity disabled={this.state.onThucHienPressed}
                          onPress={this._onLoaiNhaDat.bind(this)} style={styles.touchViTri}>
          <View style={styles.viewWidth}>
            <Text style={styles.textStar}>*</Text>
            <Text style={styles.textViTri}>Loại nhà đất</Text>
          </View>
          <View style={styles.viewLoaiNha}>
            <ScalableText style={styles.textNhaDat}>{this._getLoaiNhaDatText()}</ScalableText>
          </View>
          <Icon name="angle-right" size={24} color="#bebec0" />
        </TouchableOpacity>
    );
  }

  _getLoaiNhaDatText(){
      if (this.state.loaiTin == 'ban') {
          return this.state.loaiNhaDatBan.value.substring(0, 25);
      } else {
          return this.state.loaiNhaDatChoThue.value.substring(0, 25);
      }
  }

  _renderViTri(){
    return(
        <TouchableOpacity disabled={this.state.onThucHienPressed}
                          onPress={this._onViTriPress.bind(this)} style={styles.touchViTri}>
          <View style={styles.viewWidth}>
            <Text style={styles.textStar}>*</Text>
            <Text style={styles.textViTri}>Vị trí</Text>
          </View>
          <View style={styles.viewLoaiNha}>
            <ScalableText style={styles.textNhaDat}>{this._getdiaChi()}</ScalableText>
          </View>
          <Icon name="angle-right" size={24} color="#bebec0" />
        </TouchableOpacity>
    );
  }

  onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
  }

  _getdiaChi() {
        var diaChi = this.state.diaChi;

        if (!diaChi || diaChi.length <= 0)
            return 'Chọn vị trí trên bản đồ';

        if (diaChi.length > 23) {
            diaChi = diaChi.substring(0, 23) + '...';
        }

        return diaChi;
  }

  _renderThucHienButton(){
    if (this.props.pricing.isLoading){
      return (
          <View style={styles.viewActions}>
            <GiftedSpinner size="small" color="white"/>
          </View>
      )
    } else {
      return (
          <TouchableOpacity onPress={this._onThucHien.bind(this)} style={styles.viewActions}>
            <Text style={styles.textActions}>Thực hiện</Text>
          </TouchableOpacity>
      )
    }
  }


}

export default connect(mapStateToProps, mapDispatchToProps)(DinhGia);

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'transparent',
    flex: 1,
    alignItems: 'stretch'
  },
  toolbar: {
    height: 64,
    flexDirection: 'row',
    backgroundColor: '#1ea7de',
    borderBottomWidth: 1,
    borderColor: '#1ea7de'
  },
  modalBack: {
    width: 40,
    height: 64,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10
  },
  viewTitle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textTitle: {
    fontSize: 17,
    color: 'white',
    marginTop: 17,
    fontFamily: gui.fontFamily,
    fontWeight: '500'
  },

  viewHuy: {
    width: 40,
    marginLeft: 12,
    marginTop: 30
  },
  textHuy: {
    fontSize: 17,
    color: 'white',
    fontFamily: gui.fontFamily,
  },

  viewCan: {
    width: 40
  },
  viewBody: {
    flex: 1,
    backgroundColor: 'white'
  },
  viewActions: {
    backgroundColor: '#fa4917',
    width: width,
    height: 43,
    justifyContent: 'center',
    alignItems: 'center',
    bottom: 0
  },
  textActions: {
    color: 'white',
    fontSize: 18,
    fontFamily: 'OpenSans-Bold'
  },
  viewBanThue: {
    height: 44,
    width: width,
    backgroundColor: 'white',
    flexDirection: 'row'
  },
  viewBan: {
    flex: 1,
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  textBan: {
    color: '#1ea7de',
    fontWeight: 'bold',
    fontSize: 17,
    fontFamily: 'OpenSans-Bold'
  },
  viewThue: {
    flex: 1,
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  textThue: {
    color: 'black',
    fontWeight: 'bold',
    fontSize: 17,
    fontFamily: 'OpenSans-Bold'
  },
  viewNenButton: {
    backgroundColor: '#1ea7de',
    height: 2,
    width: width / 2
  },
  viewNhaDat: {
    height: 110,
    width: width
  },
  viewDacDiem: {
    backgroundColor: '#f3f3f5',
    width: width,
    height: 25,
    justifyContent: 'center'
  },
  textDacDiem: {
    color: '#5e5d63',
    fontSize: 10,
    marginLeft: 28,
    fontFamily: gui.fontFamily
  },
  textDacDiem1: {
      color: '#5e5d63',
      fontSize: 12,
      marginLeft: 28,
      fontFamily: gui.fontFamily
  },
  touchViTri: {
    flex: 1,
    marginLeft: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',

  },
    textStar:{
    color: '#e70101',
    width:10,
    fontSize: 13,
    fontFamily: gui.fontFamily,
    textAlign:'center',
    paddingTop: 5,
    marginRight:5,
    backgroundColor:'transparent'
    },
  textViTri: {
    color: 'black',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    textAlign:'center'
  },
  textNhaDat: {
    color: '#9fa0a4',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    justifyContent: 'center',
    marginRight: 10
  },
  viewNenMoRong: {
    backgroundColor: '#f3f3f5',
    width: width,
    height: 80,
    justifyContent: 'flex-end'
  },
  viewMoRong: {
    backgroundColor: 'white',
    width: width,
    height: 42,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textMoRong: {
    color: '#1ea7de',
    fontSize: 17,
    fontFamily: gui.fontFamily
  },

  viewWidth: {
    width: 105,
    flexDirection: 'row',
    backgroundColor: 'transparent'
  },
  viewLoaiNha: {
    width: width - 150,
    backgroundColor: 'white',
    alignItems: 'flex-end',
    height: 21,
    paddingTop:2

  },
  viewDienTich: {
    height: 42,
    width: width,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    backgroundColor: '#f3f3f5',
  },
  viewShowDienTich:{
    backgroundColor: 'white',
    height: 42,
    flexDirection:'row',
    paddingLeft:28,
    alignItems: 'center',
  },
  inputDienTich: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    padding: 4,
    paddingRight: 10,
    height: 30,
    borderColor: '#bebec0',
    borderWidth: 1,
    borderRadius: 5,
    marginLeft: 0,
    width: 80,
    textAlign: 'right',
    alignSelf: 'flex-end'
  },
  textThietLap: {
    color: 'red',
    fontSize: 15,
    fontFamily: gui.fontFamily
  },
  searchButtonText2: {
      margin: 0,
      padding: 10,
      paddingRight: 17,
      color: 'white',
      fontSize: gui.buttonFontSize,
      fontFamily: gui.fontFamily,
      fontWeight : 'normal'
  }
});


