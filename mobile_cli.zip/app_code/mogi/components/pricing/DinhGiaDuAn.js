'use strict';
import  React, {Component} from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    ScrollView,
    Alert,
    TextInput,
    StatusBar,
    TouchableWithoutFeedback,
    Keyboard
} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import danhMuc from '../../assets/DanhMuc';

import Toast, {DURATION} from '../toast/Toast';

import MLikeTapButton from '../MLikeTapButton';
import FontAwesomeLight from '../font/FontAwesomeLight';
import Button from 'react-native-button';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import dismissKeyboard from 'react-native-dismiss-keyboard';
import GiftedSpinner from 'react-native-gifted-spinner';

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

const {width, height} = util.getDimensions();


import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as pricingActions from '../../reducers/pricing/pricingActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const actions = [
    globalActions,
    pricingActions,
    postAdsActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class DinhGiaDuAn extends React.Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
        //let loaiTin = props.loaiTin;
        this.state = {
            loaiTin: 'ban' ,
            loaiNhaDat: {key: null, value: 'Chọn loại nhà đất'},
            loaiNhaDatBan: {key: null, value: 'Chọn loại nhà đất'},
            loaiNhaDatChoThue: {key: null, value: 'Chọn loại nhà đất'},
            diaChi: "Nhập tên dự án ...",
            location: {},
            placeType: danhMuc.placeType.DIA_DIEM,
            duAn: {},
            dienTich: '',
            soTang: '',
            onThucHienPressed: false,
            toggleState: false
        };
    }

    componentWillMount() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                let location = {
                    lat: position.coords.latitude,
                    lon: position.coords.longitude
                };
                this.setState({ location: location });
            },
            (error) => {
            },
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    }

    _onLoaiNhaDat() {
        let loaiNhaDatKeys = [];
        // TODO: need to verify this hard code block
        // Ban: Ban can ho chung cu; Ban nha rieng;
        //
        if (this.state.loaiTin =='ban'){
            loaiNhaDatKeys = [1,2,3,4];
        } else {
            loaiNhaDatKeys = [1,2,3,4,5,6];
        }
        Actions.LoaiNhaDat({  loaiTin: this.state.loaiTin,
            loaiNhaDatKeys: loaiNhaDatKeys,
            loaiNhaDat: this.state.loaiTin=='ban' ? this.state.loaiNhaDatBan.key : this.state.loaiNhaDatChoThue.key,
            onPress: this._onLoaiNhaDatSelected.bind(this) })
    }

    _onLoaiNhaDatSelected(selected) {
        let loaiNhaDat = {
            key: selected.key,
            value: selected.value
        };

        if (this.state.loaiTin =='ban'){
            this.setState({loaiNhaDatBan: loaiNhaDat});
        } else {
            this.setState({loaiNhaDatChoThue: loaiNhaDat});
        }
    }

    _getLoaiNhaDatText(){
        if (this.state.loaiTin == 'ban') {
            return this.state.loaiNhaDatBan.value.substring(0, 25);
        } else {
            return this.state.loaiNhaDatChoThue.value.substring(0, 25);
        }
    }

    _onDuAnPress () {
        Actions.DinhGiaPlacesAutoComplete(
            {
                onSuggestionPressed: (location)=>this._collectSuggestionInfo(location),
                placeType: ['DU_AN']
            });
    }

    _collectSuggestionInfo(position) {
        this.setState({ diaChi: position.shortName,
            duAn: position,
            placeType: position.placeType,
            location: position.location});
    }

    _getduAn() {
        let diaChi = this.state.diaChi;

        if (!diaChi || diaChi.length <= 0)
            return 'Nhập tên dự án ...';

        if (diaChi.length > 35) {
            diaChi = diaChi.substring(0, 35) + '...';
        }

        return diaChi;
    }


    _onBackPress() {
        Actions.pop();
    }

    _renderThietLapLai() {
        return(
            <TouchableOpacity style={styles.viewThietLap}
                              disabled={this.state.onThucHienPressed}
                              onPress={this.onResetFilters.bind(this)}
            >
                <Text style={styles.textThietLap}>Thiết lập lại</Text>
            </TouchableOpacity>
        );
    }

    onResetFilters () {
        this.setState(
            {
                loaiTin: this.props.loaiTin,
                loaiNhaDatBan: {key: null, value: 'Chọn loại nhà đất'},
                loaiNhaDatChoThue: {key: null, value: 'Chọn loại nhà đất'},
                diaChi: 'Nhập tên dự án ...',
                duAn: '',
                dienTich: '',
                soTang: '',
                location: {}
            });
    }

    _renderThucHienButton() {
        if (this.props.pricing.isLoading){
            return (
                <View style={styles.viewThucHien}>
                    <GiftedSpinner size="small" color="white"/>
                </View>
            )
        } else {
            return (
                <TouchableOpacity style={styles.viewThucHien}
                      onPress={this._onThucHien.bind(this)}
                >
                    <Text style={styles.textAction}>ĐỊNH GIÁ</Text>
                </TouchableOpacity>
            )
        }
    }

    _onThucHien() {
        this.setState({onThucHienPressed: true});

        if (!this.isValidData()){
            this.setState({onThucHienPressed: false});
            return;
        }

        let loaiNhaDat = [this.state.loaiTin=='ban' ? this.state.loaiNhaDatBan.key : this.state.loaiNhaDatChoThue.key];

        let codeDuAn = '';

        if (this.state.duAn && this.state.duAn.duAn  && this.state.duAn.duAn.length>0)
            codeDuAn = this.state.duAn.duAn;

        let dienTich = -1;
        if (this.state.dienTich && this.state.dienTich.length >0)
            dienTich = Number(this.state.dienTich);

        let soTang = -1;
        if (this.state.soTang && this.state.soTang.length >0)
            soTang = Number(this.state.soTang);

        let condition = {
            loaiTin:this.state.loaiTin == 'ban' ? 0 : 1,
            loaiNhaDat:loaiNhaDat,
            codeDuAn: codeDuAn.length>0 ? codeDuAn : undefined,
            position: this.state.location,
            soTang: soTang >0 ? soTang : undefined,
            dienTich: dienTich >0 ? dienTich : undefined
        };

        let duAn = (this.state.duAn && this.state.duAn.fullName && this.state.duAn.fullName.length>0) ? this.state.duAn.fullName : undefined;
        this.props.actions.calculatePricing(condition).then(
            (res) =>{
                if (res.success){
                    this.setState({onThucHienPressed: false});
                    Actions.KetQuaDinhGia({ loaiTin: this.state.loaiTin == 'ban' ? "bán" : "thuê",
                        data: res.data,
                        diaChi: this.state.diaChi,
                        loaiNhaDat: this.state.loaiTin == 'ban' ? this.state.loaiNhaDatBan.value : this.state.loaiNhaDatChoThue.value,
                        duAn: duAn
                    })
                }else {
                    this.setState({onThucHienPressed: false});
                    Alert.alert('Thông báo', 'Không có thông tin định giá khu vực bạn cần tìm.');
                }
            }
        );
    }

    isValidData(){

        if (JSON.stringify(this.state.location) == JSON.stringify({}) || this.state.diaChi == 'Nhập tên dự án ...'){
            this.refs.toastTop && this.refs.toastTop.show('Bạn chưa chọn dự án.',DURATION.LENGTH_SHORT);
            return false;
        }

        if (this.state.loaiTin == 'ban'){
            if (!this.state.loaiNhaDatBan.key){
                this.refs.toastTop && this.refs.toastTop.show('Bạn nhập thiếu loại nhà đất.',DURATION.LENGTH_SHORT);
                return false;
            }
        } else {
            if (!this.state.loaiNhaDatChoThue.key){
                this.refs.toastTop && this.refs.toastTop.show('Bạn nhập thiếu loại nhà đất.',DURATION.LENGTH_SHORT);
                return false;
            }
        }

        if (this.state.dienTich && isNaN(this.state.dienTich)) {
            this.refs.toastTop && this.refs.toastTop.show('Diện tích sai định dạng. Bạn vui lòng nhập kiểu số!',DURATION.LENGTH_SHORT);
            return false;
        }

        return true;
    }


    render() {
        return (
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                      style={{flex: 1}}
            >
                <View style={{flex: 1}}>
                    {this._renderHeaderAds()}
                    {this.renderTabButton()}
                    <FullLine/>
                    {this._renderBodyDinhGia()}
                </View>
            </TouchableWithoutFeedback>
        );
    }

    renderTabButton() {
        return(
            <View style={styles.viewTabButton}>
                <View style={styles.viewTabInterest}>
                    <MLikeTapButton name={'ban'}
                                    onPress={this._onTypeInterest.bind(this)}
                                    selected={this.state.loaiTin == 'ban'}
                                    mainProps={styles.tabFirstMonth}>Bán</MLikeTapButton>
                    <MLikeTapButton name={'thue'}
                                    onPress={this._onTypeInterest.bind(this)}
                                    selected={this.state.loaiTin == 'thue'}
                                    mainProps={styles.tabTotalMonth}>Cho thuê</MLikeTapButton>
                </View>
            </View>
        )
    }

    _onTypeInterest(value) {
        this.setState({
            loaiTin: value
        });
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <Text style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                        Định giá theo dự án
                    </Text>
                </View>
                <View style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onHome() {
        Actions.popTo('root');
    }

    _renderBodyDinhGia() {
        return(
            <View style={styles.viewBody}>
                <ScrollView style={[styles.scrollView]}
                            keyboardShouldPersistTaps="always"
                            keyboardDismissMode="none"
                            ref="_scrollview"
                >
                    {this._renderNameDuAn()}
                    <FullLine/>
                    {this._renderLoaiNhaDat()}
                    <FullLine style={{marginLeft: 17}}/>
                    {this._renderDienTich()}
                    {this._renderLine()}
                    {this._renderSoTang()}
                    <FullLine/>
                    <View style={[styles.viewTopHeader, {height:35}]}></View>
                    <FullLine/>
                    <View style={styles.viewBottom}>
                        {this._renderThietLapLai()}
                        <FullLine/>
                    </View>
                </ScrollView>
                {/*{this.state.toggleState ? <Button onPress={() => dismissKeyboard()}*/}
                                                  {/*style={[styles.searchButtonText2, { textAlign: 'right', color: gui.mainColor,*/}
                                                              {/*backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }]}>Xong</Button> : null}*/}

                {/*<KeyboardSpacer topSpacing={0} onToggle={(toggleState) => this.onKeyboardToggle.bind(this, toggleState)}/>*/}
                <Toast
                    ref="toastTop"
                    position='bottom'
                    positionValue={300}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
                {this._renderThucHienButton()}
            </View>
        );
    }

    onKeyboardToggle(toggleState) {
        this.setState({ toggleState: toggleState });
    }

    _renderNameDuAn() {
        let diaChi = this.state.diaChi;
        let defaultName = 'Nhập tên dự án ...';
        let diaChiColor = (diaChi == defaultName) ? '#9fa0a4' : gui.textAgentSolid;
        return(
            <View style={styles.viewNameDuAn}>
                <TouchableOpacity style={styles.viewDuAnPosition}
                                  disabled={this.state.onThucHienPressed}
                                  onPress={this._onDuAnPress.bind(this)}
                >
                    <View style={styles.iconPosition}>
                        <FontAwesomeLight
                            name="building"
                            color={gui.mainColor}
                            mainProps={{paddingLeft: 16, paddingRight: 0, paddingTop: 0}}
                            size={19}
                            noAction={true}
                            iconOnly={true}
                        />
                    </View>
                    <View style={[styles.viewDienTich, {width: width - 32 - 55}]}>
                        <Text style={[styles.textThietLap, {fontSize: 15, color: diaChiColor}]}>{this._getduAn()}</Text>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _renderLoaiNhaDat () {
        let keyBan = this.state.loaiNhaDatBan.key;
        let keyThue = this.state.loaiNhaDatChoThue.key;
        let chooseColor = (Number(keyBan) >= 1 || Number(keyThue) >= 1) ? gui.textAgentSolid :'#9fa0a4';
        return(
            <TouchableOpacity style={styles.loaiNhaDat}
                  disabled={this.state.onThucHienPressed}
                  onPress={this._onLoaiNhaDat.bind(this)}
            >
                <View style={styles.viewWidth}>
                    <Text style={[styles.textThietLap, {fontSize: 15, color: gui.textAgentSolid}]}>
                        Loại nhà đất
                    </Text>
                </View>
                <View style={styles.viewLoaiNha}>
                    <Text style={[styles.textThietLap, {fontSize: 15, color: chooseColor}]}>{this._getLoaiNhaDatText()}</Text>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _renderDienTich () {
        return(
            <View style={styles.loaiNhaDat}>
                <View style={[styles.viewWidth, {width: 75}]}>
                    <Text style={[styles.textThietLap, {fontSize: 15, color: gui.textAgentSolid}]}>
                        Diện tích
                    </Text>
                </View>
                <View style={styles.viewDienTich}>
                    <TextInput
                        keyboardType={'numeric'}
                        selectTextOnFocus={true}
                        returnKeyType='done'
                        underlineColorAndroid='rgba(0,0,0,0)'
                        placeholder="Nhập diện tích ..."
                        placeholderTextColor='#adb4b7'
                        style={[styles.inputVayNew, { paddingRight: 19}]}
                        onChangeText={(dienTich) => this._onDienTichChange(dienTich)}
                        value={this.state.dienTich}
                        allowFontScaling={false}
                    />
                </View>
                <View style={styles.viewUnitArea}>
                    <Text style={[styles.textThietLap, {fontSize: 15, color: '#9fa0a4'}]}>m²</Text>
                </View>
            </View>
        );
    }

    _onDienTichChange(dienTich) {
        let zeroNumber = '0' || '00';
        if (dienTich === zeroNumber) {
            dienTich = '';
        }
        let dienTichNumber = util.interestNumeric(dienTich);
        if(util.countDot(dienTichNumber, '\\.') >= 2){
            this.refs.toastTop && this.refs.toastTop.show('Bạn nhập không đúng định dạng số!',DURATION.LENGTH_SHORT);
            return;
        }
        let valTime = dienTichNumber && !isNaN(dienTichNumber) ? Number(dienTichNumber) : 0;
        if(valTime == 0 && Number(this.state.dienTich) == 0) {
            // this.refs.toastTop && this.refs.toastTop.show('Bạn chưa chọn diện tích!',DURATION.LENGTH_SHORT);
            this.setState({dienTich: ''});
            return ;
        }

        this.setState({
           dienTich:  dienTichNumber
        });
    }


    _renderLine() {
        let keyBan = this.state.loaiNhaDatBan.key;
        let keyThue = this.state.loaiNhaDatChoThue.key;
        if (keyBan == 1 || keyThue == 1) {
            return null;
        } else {
            return <FullLine style={{marginLeft: 17}}/>
        }
    }

    _renderSoTang () {
        let keyBan = this.state.loaiNhaDatBan.key;
        let keyThue = this.state.loaiNhaDatChoThue.key;
        if (keyBan == 1 || keyThue == 1) {
            return;
        }
        return(
            <View style={styles.loaiNhaDat}>
                <View style={[styles.viewWidth, {width: 75}]}>
                    <Text style={[styles.textThietLap, {fontSize: 15, color: gui.textAgentSolid}]}>
                        Số tầng
                    </Text>
                </View>
                <View style={[styles.viewDienTich, {width: width -151}]}>
                    <TextInput
                        keyboardType={'numeric'}
                        selectTextOnFocus={true}
                        returnKeyType='done'
                        underlineColorAndroid='rgba(0,0,0,0)'
                        placeholder="Nhập số tầng ..." placeholderTextColor='#adb4b7'
                        style={styles.inputVayNew}
                        onChangeText={(soTang) => this._onSoTangChange(soTang)}
                        value={this.state.soTang}
                        allowFontScaling={false}
                    />
                </View>
            </View>
        );
    }

    _onSoTangChange (soTang) {
        let zeroNumber = '0' || '00';
        if (soTang === zeroNumber) {
            soTang = '';
        }
        let soTangNumber = util.interestNumeric(soTang);
        if(util.countDot(soTangNumber, '\\.') >= 2){
            this.refs.toastTop && this.refs.toastTop.show('Bạn nhập không đúng định dạng số!',DURATION.LENGTH_SHORT);
            return;
        }
        let valTime = soTangNumber && !isNaN(soTangNumber) ? Number(soTangNumber) : 0;
        if(valTime == 0 && Number(this.state.dienTich) == 0) {
            this.setState({soTang: ''});
            return ;
        }

        this.setState({
            soTang:  soTangNumber
        });
    }


}
export default connect(mapStateToProps, mapDispatchToProps)(DinhGiaDuAn);

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        height: 63,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:gui.textAgentSolid,
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    scrollView: {
        backgroundColor: '#fff',
        // paddingBottom: 43,
        flex: 1
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewTopHeader: {
        width: width,
        height: 34,
        backgroundColor: 'rgba(246,246,246,1)'
    },
    loaiNhaDat: {
        width: width,
        backgroundColor: '#fff',
        height:42,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginLeft: 17
    },
    viewDacDiem: {
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        width: width,
        backgroundColor: '#f3f3f5',
        height: 56,
        paddingTop: 7,
        paddingBottom: 6,
        paddingRight: 8
    },
    viewThietLap: {
        width: width,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        height:42
    },
    viewDuAn: {
        width: width,
        height: 43,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    iconPosition: {
        width: 42,
        height: 42,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewIcon: {
        width: 30,
        height: 30,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5
    },
    viewBottom: {
        flex: 1,
        backgroundColor: '#f3f3f5',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    viewThucHien: {
        backgroundColor: gui.mainColor,
        width: width - 32,
        height: 48,
        borderRadius: 24,
        marginLeft: 16,
        justifyContent: 'center',
        alignItems: 'center',
        bottom: 16,
        position:'absolute'
    },
    textAction: {
        color: 'white',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    textThietLap: {
        color: '#ff0000',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    textDetailContent: {
        fontSize: 12,
        fontFamily:gui.fontFamily,
        color:'#818286',
        paddingLeft: 17,
        fontWeight: '400'
    },
    viewWidth: {
        width: 100,
        height: 42,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewUnitArea: {
        width: 50,
        height: 42,
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 15
    },
    viewLoaiNha: {
        width: width - 157,
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'flex-end',
        height: 42
    },
    viewDienTich: {
        width: width -142,
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'flex-start',
        height: 42,
        paddingLeft: 5
    },
    viewArrow: {
        width: 40,
        height: 43,
        justifyContent: 'center',
        alignItems: 'center'
    },
    inputVayNew: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 4,
        paddingRight: 10,
        height: 32,
        marginLeft: 0,
        width: width -110,
        // textAlign: 'left',
        // alignSelf: 'flex-start',
        textAlign: 'right',
        alignSelf: 'flex-end',
        color: gui.textAgentSolid,
        paddingVertical: 0
    },
    searchButtonText2: {
        margin: 0,
        padding: 10,
        paddingRight: 17,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : '500'
    },
    viewDuAnPosition: {
        backgroundColor: '#fff',
        height: 48,
        width: width - 32,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        borderRadius: 5
    },
    titleText: {
        backgroundColor: 'transparent',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600'
    },
    viewNameDuAn: {
        height: 84,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(246,246,246,1)'
    },
    viewTabInterest: {
        flexGrow:1,
        flexDirection: 'row',
        paddingLeft: 5,
        paddingRight: 5
    },
    viewTabButton: {
        height: 50,
        width: width,
        marginBottom: 6,
        alignItems: 'center'
    },
    tabFirstMonth: {
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
        borderTopWidth: 1,
        borderLeftWidth: 1,
        borderBottomWidth: 1,
        marginLeft: 10,
        marginRight: 0,
        width: (width- 145)/2,
        borderColor: gui.mainColor
    },
    tabTotalMonth: {
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5,
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderRightWidth: 1,
        marginLeft: 0,
        marginRight: 10,
        width: (width- 145)/2,
        borderColor: gui.mainColor
    }
});