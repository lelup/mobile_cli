import React, {Component} from 'react';
import {
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    StyleSheet,
    Platform,
    Alert,
    ScrollView,
    ListView,
    StatusBar,
    ImageBackground
} from 'react-native';

import MMessage from '../message/MMessage';

import {Actions} from 'react-native-router-flux';
import LinearGradient from 'react-native-linear-gradient';
import util from "../../lib/utils";
var {width, height} = util.getDimensions();
import gui from "../../lib/gui";
import MHeartIcon from '../MHeartIcon';
import ScalableText from 'react-native-text';
import DanhMuc from '../../assets/DanhMuc';
import GiftedSpinner from 'react-native-gifted-spinner';

import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';

var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as historyActions from '../../reducers/history/historyActions';


import {Map} from 'immutable';

const actions = [
  globalActions,
  historyActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class KetQuaDinhGia extends Component {

  constructor(props) {
    super(props);
    StatusBar.setBarStyle('dark-content');
    this.state = {
      firstTime: true,
      likeAdsMessage: '',
      msgType: '',
      loaiTin: props.loaiTin,
      loaiTinKey: props.loaiTin == 'bán' ? 0 : 1,
      giaTrungBinh: props.data.giaTrungBinh || undefined,
      giaTrungBinhKhac: props.data.giaTrungBinhKhac || [],
      bdsNgangGia: props.data.bdsNgangGia,
      diaChi: props.diaChi,
      radius: props.data.radius,
      loaiNhaDat: props.loaiNhaDat,
      duAn: props.duAn,
      dataSource: props.data.giaTrungBinh ? ds.cloneWithRows(props.data.bdsNgangGia) : ds.cloneWithRows([]),
      showListNhaGan: false
    };
  }

  _renderRow (data, sectionID , rowID){
    let isLiked = this.isLiked(data.adsID);
    let color = 'white';
    let bgColor = isLiked ? '#EC1B77' : '#4A443F';
    let bgStyle = isLiked ? {} : {opacity: 0.55};

    let detail = data.diaChi && data.diaChi.length>40 ? data.diaChi.substring(0,40) + "..." : data.diaChi;

    var dienTich = '';
    if (data.dienTichFmt && data.dienTichFmt != 'Không rõ') {
      dienTich = '· ' + data.dienTichFmt;
    }
    var soPhongNgu = '';
    if (data.soPhongNguFmt) {
      soPhongNgu = "   " + data.soPhongNguFmt;
    }

    var soTang = '';
    if (data.soTangFmt) {
      soTang = "   " + data.soTangFmt;
    }

    detail = detail + this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTich, soPhongNgu, soTang);

    return(
        <View style={styles.eachViewKetQua}>
          <TouchableOpacity style={styles.listMoRong}  onPress={() => Actions.SearchResultDetail({adsID: data.adsID, source: 'server', imageDetail: data.image.cover, owner: 'KetQuaDinhGia'})} >
            <ImageBackground style={{width: width, height:180}} source={data.image.cover ? {uri: data.image.cover} : require('../../assets/image/reland_house_large.jpg')}>
              <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.5)']}
                            style={styles.linearGradient2}>
              </LinearGradient>
              <View style={styles.heartContent}>
                {this.props.history.uploadingLikedAds.uploading && this.props.history.uploadingLikedAds.adsID==data.adsID ?
                    (<View style={styles.heartButton}>
                          <GiftedSpinner size="small" color="white" />
                     </View>)
                    :
                    (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                 color={color} bgColor={bgColor}
                                 bgStyle={bgStyle} mainProps={styles.heartButton} />)
                }
              </View>
              <View style={{marginTop: -60, marginLeft: 10, paddingBottom: 8}}>
                <View style={{flexDirection:'row'}}>
                  <Text style={styles.priceText}>{data.giaFmt}</Text>
                  <Text style={[styles.priceText,
                                {marginLeft:10, fontSize:13, paddingBottom:0,
                                fontWeight: 'bold', color: gui.mainColor}]}>
                    {util.getPriceM2Display(data.giaM2, data.loaiTin)}
                  </Text>
                </View>
                <ScalableText style={styles.infoText}>{detail}</ScalableText>
              </View>
            </ImageBackground>
          </TouchableOpacity>
        </View>
    );
  }

  getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
    var moreInfo = '';
    var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
    if (loaiNhaDat == loaiNhaDatKeys[1]) {
      moreInfo = ' ' + dienTich + soPhongNgu;
    }
    else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[4])) ||
        loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
        || (loaiNhaDat == loaiNhaDatKeys[3])
        || (loaiNhaDat == loaiNhaDatKeys[6]))) {
      moreInfo = ' ' + dienTich + soTang;
    }
    else {
      moreInfo = ' ' + dienTich;
    }
    return moreInfo;
  }

  isLiked(adsID) {
    const {adsLikes} = this.props.global.currentUser;
    return adsLikes && adsLikes.indexOf(adsID) > -1;
  }

  onLike(adsID) {
    if (!this.props.global.loggedIn) {
      Actions.NewLogin();
    } else {
      if (!this.isLiked(adsID)) {
        this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
      } else {
        this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
      }
    }
  }

  _renderNhaGan(){
      return(
          <View style={{flexGrow:1, backgroundColor:'white'}}>
            <View style={styles.viewSpace}></View>
            <View style={styles.viewNhaDat}>
              <ScalableText style={styles.textNhaDat}>GIÁ ƯỚC TÍNH CỦA CÁC LOẠI NHÀ ĐẤT KHÁC</ScalableText>
            </View>
          </View>
      )
  }

  _renderDanhSachNha(){
      let mds = this.props.data.giaTrungBinh ? ds.cloneWithRows(this.props.data.bdsNgangGia) : ds.cloneWithRows([]);

      return(
          <View style={{flexGrow:1, backgroundColor:'white', borderTopWidth:1, borderColor:'#e8e8ea'}}>
            <View style={{ width:width, justifyContent:'center', alignItems:'center',marginTop:12}}>
              <Text style={{fontSize: 15, color:'black', marginTop: 1, marginBottom: 1, fontFamily: gui.fontFamily}}>
                  { this.state.duAn && this.state.duAn.length>0 ? 'NHÀ GẦN DỰ ÁN ĐỊNH GIÁ' : 'NHÀ GẦN VỊ TRÍ ĐỊNH GIÁ'}
              </Text>
              <Text style={{fontSize:12, color:'#7b8b91', marginBottom: 2, fontFamily: gui.fontFamily}}>
                {this.state.duAn && this.state.duAn.length>0 ? this.state.duAn : this.state.diaChi}
              </Text>
            </View>
            <View style={{flexGrow:1, backgroundColor:'white', marginTop:10}}>
              <ListView contentContainerStyle={{ flexDirection: 'row', flexWrap: 'wrap'}}
                        dataSource={mds}
                        renderRow={this._renderRow.bind(this)}/>
            </View>
          </View>
      )
  }

  _renderGiaKhac(){
    return (
        <View style={styles.viewKhaoSat}>
          {
            this.state.giaTrungBinhKhac.map( (e) => {
              return this._renderGiaKhacItem(e.loaiNhaDatVal, e.giaM2TrungBinh, this.state.loaiTinKey);
            })
          }
        </View>
    )
  }

  _renderGiaKhacItem(loainhaDat, gia, loaiTin){
    return (
        <View style={styles.rowLoaiKhac}>
          <ScalableText style={styles.textLoaiKhac}>{loainhaDat}</ScalableText>
          <ScalableText style={styles.textGiaLoaiKhac}>{util.getPriceM2Display(gia, loaiTin)}</ScalableText>
        </View>
    )
  }

  _renderDinhGia(){
    if (this.state.duAn && this.state.duAn.length>0){
      if (this.state.giaTrungBinh) {
        return (
            <View style={styles.viewHopGia}>
              <Text style={styles.textHopGia1}>{this.state.giaTrungBinh.loaiNhaDatVal.toUpperCase()}</Text>
              <Text style={styles.textHopGia2}>{this.state.duAn}</Text>
              <ScalableText style={styles.textHopGia3}>{util.getPriceM2Display(this.state.giaTrungBinh.giaM2TrungBinh, this.state.loaiTinKey)}</ScalableText>
              <ScalableText style={styles.textHopGia4}>Giá ước tính dựa trên dữ liệu {this.state.giaTrungBinh.count} nhà tương tự
                đã và đang {this.state.loaiTin}</ScalableText>
              <Text style={styles.textHopGia5}>thuộc dự án {this.state.duAn}</Text>
            </View>
        )
      } else {
        return (
            <View style={[styles.viewHopGia,{height: 150}]}>
              <ScalableText style={styles.textHopGia1}>{this.state.loaiNhaDat.toUpperCase()}</ScalableText>
              <ScalableText style={styles.textHopGia2}>{this.state.duAn}</ScalableText>
              <ScalableText style={styles.textHopGia4}>Không có thông tin định giá</ScalableText>
              <ScalableText style={styles.textHopGia5}>thuộc dự án {this.state.duAn}</ScalableText>
            </View>
        )
      }
    } else {
      if (this.state.giaTrungBinh) {
        return (
            <View style={styles.viewHopGia}>
              <ScalableText style={styles.textHopGia1}>{this.state.giaTrungBinh.loaiNhaDatVal.toUpperCase()}</ScalableText>
              <ScalableText style={styles.textHopGia2}>{this.state.diaChi}</ScalableText>
              <Text style={styles.textHopGia3}>{util.getPriceM2Display(this.state.giaTrungBinh.giaM2TrungBinh, this.state.loaiTinKey)}</Text>
              <ScalableText style={styles.textHopGia4}>Giá ước tính dựa trên dữ liệu {this.state.giaTrungBinh.count} nhà tương tự
                đã và đang {this.state.loaiTin}</ScalableText>
              <ScalableText style={styles.textHopGia5}>nằm trong vòng {this.state.radius}m xung quanh vị trí đã chọn</ScalableText>
            </View>
        )
      } else {
        return (
            <View style={[styles.viewHopGia,{height: 150}]}>
              <ScalableText style={styles.textHopGia1}>{this.state.loaiNhaDat.toUpperCase()}</ScalableText>
              <ScalableText style={styles.textHopGia2}>{this.state.diaChi}</ScalableText>
              <ScalableText style={styles.textHopGia4}>Không có thông tin định giá</ScalableText>
              <ScalableText style={styles.textHopGia5}>nằm trong vòng {this.state.radius}m xung quanh vị trí đã chọn</ScalableText>
            </View>
        )
      }
    }

  }

  _renderBody(){
    if(this.state.giaTrungBinh && this.state.giaTrungBinh.giaM2TrungBinh > 0){
      return(
          this._renderDanhSachNha()
      )
    } else {
      if(this.state.giaTrungBinhKhac && this.state.giaTrungBinhKhac.length >0){
        return(
            <View>
              {this._renderNhaGan()}
              {this._renderGiaKhac()}
            </View>
        )
      } else {
        return;
      }

    }
  }

  _updateLikeAdsProcessing(likeAdsMessage) {
    this.setState({firstTime: false, likeAdsMessage: likeAdsMessage});
    this._onMsgAnimationStart();
  }

  _onMsgAnimationStart() {
    this.setState({msgType: 'fadeInDown'});
    clearTimeout(this.msgTimer);
    this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 2000);
  }

  _renderLikeAdsMessage() {
    let uploading = this.props.history.uploadingLikedAds.uploading;
    if (this.state.firstTime || uploading || this.state.msgType == '') {
      return null;
    }
    let textValue = this.state.likeAdsMessage;
    return (
        <MMessage mainStyle={{top: 64}}
                  barStyle="light-content"
                  animation={this.state.msgType}
                  duration={500}
                  onAnimationEnd={this._onAnimationEnd.bind(this)}
                  textValue={textValue}/>
    );
  }

  _onAnimationEnd() {
    if (this.state.msgType === 'slideOutUp') {
      clearTimeout(this.msgTimer);
      this.msgTimer = setTimeout(() => {this.setState({msgType: ''})}, 2000);
    }
  }

  render(){
    return(
          <View style={styles.container}>
            <ScrollView
                style={styles.scrollViewBody}
            >
              <View style={styles.viewBody}>
                {this._renderDinhGia()}
                {this._renderBody()}
              </View>
            </ScrollView>
            {this._renderLikeAdsMessage()}
            <View style={[styles.toolbar, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
              <TouchableOpacity onPress={() => Actions.pop()} style={styles.modalBack} >
                <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
              </TouchableOpacity>
              <View style={styles.viewTitle}>
                <Text style={styles.textTitle}>Giá ước tính</Text>
              </View>
              <TouchableOpacity onPress={this._onHome.bind(this)} underlayColor="transparent"
                                style={styles.modalBack}
              >
                <RelandIcon noAction={true}
                            name="home-o" color={gui.mainColor} size={26}
                            mainProps={{flexDirection: 'row', paddingRight: 15}}
                />
              </TouchableOpacity>
            </View>
          </View>

    );
  }

  _onHome() {
    Actions.popTo('root');
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor:'transparent',
    flexGrow:1,
    alignItems:'center'
  },
  toolbar :{
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 64,
    flexDirection:'row',
    backgroundColor:'#fff',
    borderBottomWidth:1,
    borderColor:'rgba(211,211,211,0.5)'
  },
  modalBack: {
      width: 40,
      height: 64,
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 10
  },
  viewTitle: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textTitle: {
      fontSize: 17,
      color: gui.textAgentSolid,
      marginTop: 17,
      fontFamily: gui.fontFamily,
      fontWeight: '500'
  },

  viewCan: {
    width: 40
  },
  scrollViewBody: {
    position: 'absolute',
    top: 64,
    left: 0,
    right: 0,
    height: height-64
    },
  viewBody: {
    flexGrow:1,
    backgroundColor:'white'
  },
  viewHopGia: {
    backgroundColor:'white',
    width:width,
    height:232,
    alignItems:'center'
  },
  textHopGia1: {
    fontSize: 15,
    color:'#1ea7de',
    marginTop: 14,
    fontFamily:gui.fontFamily
  },
  textHopGia2: {
    fontSize:13,
    color:'#3a3a3c',
    marginTop: 3,
    fontFamily:gui.fontFamily
  },
  textHopGia3: {
    fontSize:45,
    color:'#ef4c23',
    marginTop: 19,
    fontFamily:gui.fontFamily,
    fontWeight:'400'
  },
  textHopGia4: {
    fontSize:12,
    color:'#58585a',
    marginTop: 24,
    fontFamily:gui.fontFamily
  },
  textHopGia5: {
    fontSize:12,
    color:'#58585a',
    marginTop: 2,
    fontFamily:gui.fontFamily
  },
  viewSpace: {
    width:width,
    height:26,
    backgroundColor:'#f3f3f5',
    borderColor:'#e8e8ea',
    borderBottomWidth:1,
    borderTopWidth:1
  },
  viewNhaDat: {
    width:width,
    height:39,
    backgroundColor:'white',
    borderColor:'#e8e8ea',
    borderBottomWidth:1,
    justifyContent:'center'
  },
  textNhaDat: {
    fontSize:12.5,
    color:'gray',
    marginLeft:19,
    fontFamily:gui.fontFamily
  },
  viewKhaoSat: {
    width:width,
    backgroundColor:'white',
    justifyContent:'center'
  },
  textLoaiKhac: {
    fontSize: 15,
    color:'gray',
    marginLeft:19,
    marginTop: 25,
    fontFamily:gui.fontFamily
  },
  centerLineLoaiKhac: {
    borderColor:'#e8e8ea',
    borderBottomWidth:1,
    width:width/3 -20,
    height:40,
    marginLeft: 5
  },
  textGiaLoaiKhac:{
    fontSize: 15,
    color:'gray',
    marginLeft:5,
    marginRight: 10,
    marginTop: 25,
    fontFamily:gui.fontFamily
  },
  rowLoaiKhac: {
    backgroundColor:'white',
    flexDirection:'row',
    justifyContent:'space-between'
  },
  listMoRong:{
    justifyContent:'center',
    width: width,
    height: 180,
  },
  eachViewKetQua:{
    justifyContent:'center',
    width: width,
    height: 180,
  },
  linearGradient2: {
    marginTop: 90,
    height: 90,
    paddingLeft: 0,
    paddingRight: 0,
    backgroundColor: "transparent",
    flexGrow: 1
  },
  heartButton: {
    marginTop: 6,
    marginLeft: 30
  },
  heartContent: {
    position: 'absolute',
    backgroundColor: 'transparent',
    top: 4,
    right: 23,
    alignSelf: 'auto'
  },

  priceText: {
    fontSize: 17,
    backgroundColor: 'transparent',
    color:'white',
    fontFamily: gui.fontFamily,
    fontWeight: 'bold',
    textAlign: 'left',
    paddingTop:2
  },
  infoText: {
    fontSize:13,
    textAlign: 'left',
    backgroundColor: 'transparent',
    marginBottom: 25,
    marginTop: 2,
    color: 'white',
    fontFamily: gui.fontFamily,
    fontWeight: '300'
  },
  titleText: {
    backgroundColor: 'transparent',
    color: 'white',
    fontFamily: gui.fontFamily,
    fontSize: 17,
    fontWeight: '600'
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(KetQuaDinhGia);
