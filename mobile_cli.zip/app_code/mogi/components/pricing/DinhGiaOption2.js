
'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import RelandIcon from '../RelandIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

const {width, height} = util.getDimensions();


class DinhGiaOption2 extends React.Component {
    constructor(props) {
        super(props);
        let type = this.props.type;
        this.state = {
            loaiTin: '',
            type: type
        };
    }

    _onBackPress() {
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyDinhGia()}
            </View>
        );
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                        Định giá
                    </ScalableText>
                </View>
                <View
                    style={styles.viewEdit}>
                    <TouchableOpacity onPress={this._onHome.bind(this)} underlayColor="transparent"
                                      style={{paddingLeft: 7, paddingRight: 15}}
                    >
                        <Text style={styles.titleText}>Hủy</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    _onHome() {
        Actions.popTo('root');
    }

    _renderBodyDinhGia() {
        return(
            <View style={styles.viewBody}>
                <View style={styles.viewTopHeader}></View>
                <FullLine/>
                {this._renderDinhGiaBan()}
                <FullLine style={{marginLeft: 70}} />
                {this._renderDinhGiaThue()}
                <FullLine/>
                <View style={styles.viewBottom}>
                </View>
            </View>
        );
    }

    _renderDinhGiaBan() {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onDinhGiaDuAnBan.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={styles.viewIcon}>
                        <RelandIcon name="sale" color='#fff' mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 10}}
                                    size={24} textProps={{}}
                                    noAction={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <Text style={styles.textDuAn}>Giá bán</Text>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _renderDinhGiaThue () {
        return(
            <TouchableOpacity style={styles.viewDuAn}
                              onPress={this._onDinhGiaDuAnThue.bind(this)}
            >
                <View style={styles.iconPosition}>
                    <View style={[styles.viewIcon, {backgroundColor: '#f7941d'}]}>
                        <RelandIcon name="rent" color='#fff' mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 10}}
                                    size={24} textProps={{}}
                                    noAction={true}
                        />
                    </View>
                </View>
                <View style={styles.viewTextCenter}>
                    <Text style={styles.textDuAn}>Giá cho thuê</Text>
                </View>
                <View style={styles.viewArrow}>
                    <TruliaIcon name="arrow-right" color={gui.arrowColor} size={20}
                                noAction={true}
                    >
                    </TruliaIcon>
                </View>
            </TouchableOpacity>
        );
    }

    _onDinhGiaDuAnBan () {
        this.setState({
            loaiTin: 'ban'
        });
        setTimeout(() => {this._pressDinhGiaDuAn()}, 100);
    }

    _onDinhGiaDuAnThue () {
        this.setState({
            loaiTin: 'thue'
        });
        setTimeout(() => {this._pressDinhGiaDuAn()}, 100);
    }
    _pressDinhGiaDuAn() {
        Actions.DinhGiaViTri({loaiTin: this.state.loaiTin});
    }
}
export default DinhGiaOption2;

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewTopHeader: {
        width: width,
        height: 34,
        backgroundColor: '#f3f3f5'
    },
    viewDuAn: {
        width: width,
        height: 43,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewTextCenter: {
        width: width - 100,
        height: 43,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    textDuAn: {
        fontSize: 17,
        color: '#000',
        fontWeight: '500',
        marginLeft: 10
    },
    viewArrow: {
        width: 40,
        height: 43,
        justifyContent: 'center',
        alignItems: 'center'
    },
    iconPosition: {
        width: 60,
        height: 43,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewIcon: {
        width: 35,
        height: 35,
        backgroundColor: '#0f76bb',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5
    },
    viewBottom: {
        flex: 1,
        backgroundColor: '#f3f3f5',
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    titleText: {
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily,
        fontSize: 17,
        fontWeight: '600'
    }
});