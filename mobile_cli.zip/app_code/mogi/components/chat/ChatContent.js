import React, {Component} from 'react';

import {
    StyleSheet,
    Text,
    View,
    Image, ListView,
    TouchableOpacity,
    TextInput,
    Alert,
    ScrollView,
    Linking
} from 'react-native';

import NavigationExperimental from 'react-native-deprecated-custom-components';

import gui from '../../lib/gui';
import {Actions} from 'react-native-router-flux';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as chatActions from '../../reducers/chat/chatActions';

import GiftedMessenger from '../giftedMessegener/GiftedMessenger';

import log from '../../lib/logUtil';
import danhMuc from '../../assets/DanhMuc';
import FullLine from '../line/FullLine';
import {MenuContext} from '../../components/menu';

import ImagePreviewChat from '../ImagePreviewChat';

import ScalableText from 'react-native-text';

import MapView from 'react-native-maps';

import LocationMarker from '../marker/LocationMarker';

import utils from '../../lib/utils';

import Camera from 'react-native-camera';

import InCallManager from 'react-native-incall-manager';

var Analytics = require('react-native-firebase-analytics');

var STATUS_BAR_HEIGHT = NavigationExperimental.Navigator.NavigationBar.Styles.General.StatusBarHeight;
var ADS_BAR_HEIGHT = 60;

var {width, height} = utils.getDimensions();
var mapWidth = 2*width/3;
var mapHeight = 2*width/3;
let defaultCover =  require('../../assets/image/no_cover.jpg');

const actions = [
  globalActions,
  chatActions,
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class  ChatContent extends React.Component {
  constructor(props) {
    super(props);

    log.info("ChatContent.constructor");

    this.state = {
      imageUri: '',
      modal: false,
      currentLocation: {}
    };
  }

  updateCurrentLocation() {
    navigator.geolocation.getCurrentPosition(
        (position) => {
          //var geoUrl = 'http://maps.apple.com/?saddr='+position.coords.latitude+','+position.coords.longitude+'&daddr='+ads.place.geo.lat+','+ads.place.geo.lon+'&dirflg=d&t=s';
          this.setState({
            currentLocation : {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude
            }
          });
        },
        (error) => {
          Alert.alert("Thông báo", gui.ERR_LocationNotOn);
        },
        {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
    );
  }

  componentWillMount() {
    this.updateCurrentLocation();
  }

  coming() {
    Alert.alert("Coming soon...");
  }

  handleSend(message = {}) {

    let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;

    const userID = this.props.global.currentUser.userID;
    const chatID = "Chat_" + userID + "_" + new Date().getTime();

    let myMsg = {
      _id : chatID,
      chatID : chatID,
      id : chatID,
      fromUserID : userID,
      fromUserAvatar: this.props.global.currentUser.avatar,
      fromFullName : this.props.global.currentUser.fullName,
      toUserID : this.props.chat.partner.userID,
      toFullName : this.props.chat.partner.fullName,
      relatedToAds : this.props.chat.ads,
      avatar: this.props.global.currentUser.avatar,
      content : message.text,
      msgType : message.type || danhMuc.CHAT_MESSAGE_TYPE.TEXT,
      read: false,
      metaInfo: {
        isFirstMessage: (msgCount<=0) ? true : undefined,
        toUserActive: this.props.chat.partner.active
      },
      date: new Date(),
      type: 'Chat'
    };

    this.props.actions.sendChatMsg(myMsg);
  }

  handleSendLocation(message = {}) {
    let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;
    const userID = this.props.global.currentUser.userID;
    const chatID = "Chat_" + userID + "_" + new Date().getTime();

    let myMsg = {
      _id : chatID,
      chatID : chatID,
      id : chatID,
      fromUserID : userID,
      fromUserAvatar: this.props.global.currentUser.avatar,
      fromFullName : this.props.global.currentUser.fullName,
      toUserID : this.props.chat.partner.userID,
      toFullName : this.props.chat.partner.fullName,
      relatedToAds : this.props.chat.ads,
      avatar: this.props.global.currentUser.avatar,
      location : message.location,
      msgType : message.type || danhMuc.CHAT_MESSAGE_TYPE.LOCATION,
      read: false,
      metaInfo: {
        isFirstMessage: (msgCount<=0) ? true : undefined,
        toUserActive: this.props.chat.partner.active
      },
      date: new Date(),
      type: 'Chat'
    };

    this.props.actions.sendChatMsg(myMsg);
  }

  handleSendVideoInvitation() {
    let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;
    const userID = this.props.global.currentUser.userID;
    const chatID = "Chat_" + userID + "_" + new Date().getTime();

    let myMsg = {
      _id : chatID,
      chatID : chatID,
      id : chatID,
      fromUserID : userID,
      fromUserAvatar: this.props.global.currentUser.avatar,
      fromFullName : this.props.global.currentUser.fullName,
      toUserID : this.props.chat.partner.userID,
      toFullName : this.props.chat.partner.fullName,
      relatedToAds : this.props.chat.ads,
      avatar: this.props.global.currentUser.avatar,
      content : 'Cuộc gọi hình',
      msgType : danhMuc.CHAT_MESSAGE_TYPE.VIDEO_CALL,
      read: false,
      metaInfo: {
        isFirstMessage: (msgCount<=0) ? true : undefined,
        toUserActive: this.props.chat.partner.active
      },
      date: new Date(),
      type: 'Chat'
    };

    this.props.actions.sendVideoInvitation(myMsg);
  }

  handleSendVideoCallCancel() {
    let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;
    const userID = this.props.global.currentUser.userID;
    const chatID = "Chat_" + userID + "_" + new Date().getTime();

    let myMsg = {
      _id : chatID,
      chatID : chatID,
      id : chatID,
      fromUserID : userID,
      fromUserAvatar: this.props.global.currentUser.avatar,
      fromFullName : this.props.global.currentUser.fullName,
      toUserID : this.props.chat.partner.userID,
      toFullName : this.props.chat.partner.fullName,
      relatedToAds : this.props.chat.ads,
      avatar: this.props.global.currentUser.avatar,
      content : 'Cuộc gọi hình',
      msgType : danhMuc.CHAT_MESSAGE_TYPE.VIDEO_CALL,
      read: false,
      metaInfo: {
        isFirstMessage: (msgCount<=0) ? true : undefined,
        toUserActive: this.props.chat.partner.active
      },
      date: new Date(),
      type: 'Chat'
    };

    this.props.actions.sendVideoCallCancel(myMsg);
  }

  onErrorButtonPress() {
    this.coming();
  }

  onLoadEarlierMessages() {
    this.coming();
  }

  onImagePress(data) {
    this.doImagePress(data.image.uri);
  }

  handlePhonePress() {
    this.coming();
  }

  handleUrlPress() {
    this.coming();
  }

  handleEmailPress() {
    this.coming();
  }

  doImagePress(uri) {
    if (this.state.modal) {
      return;
    }
    this.setState({
      imageUri: uri,
      modal: true
    });
  }

  renderCustomText(rowData) {
    if(rowData.msgType==2){
      return (
          <TouchableOpacity
              onPress={this.doImagePress.bind(this, rowData.text)}>
            <Image resizeMode = {"cover"}
                   source={{uri:rowData.text}}
                   style={styles.image}/>
          </TouchableOpacity>
      )
    } else if (rowData.msgType==3){
      let region = {latitude: rowData.location.lat, longitude: rowData.location.lon, latitudeDelta: 0.021, longitudeDelta: 0.0144};
      return (
          <MapView
              style={styles.image}
              scrollEnabled={false}
              zoomEnabled={false}
              pitchEnabled={false}
              rotateEnabled={false}
              initialRegion={region}
              onPress={() => this._onDanDuongPressed(rowData)}>
            <MapView.Marker coordinate={region} pointerEvents="none">
              <LocationMarker/>
            </MapView.Marker>
          </MapView>
      )
    } else {
      let d  = new Date(rowData.date);
      let msg = rowData.text;

      if (rowData.position === 'left') {
        return <Text style={{color:'#17242c', padding: 5, borderRadius: 8}}>{msg}</Text>;
      } else {
        return <Text style={{color:'#17242c', padding: 5, borderRadius: 8}}>{msg}</Text>;
      }
    }
  }

  _onDanDuongPressed(rowData) {
    let destLat = rowData.location.lat;
    let destLon = rowData.location.lon;

    var geoUrl = 'http://maps.apple.com/?saddr='+this.state.currentLocation.latitude+','+this.state.currentLocation.longitude+'&daddr='+destLat+','+destLon+'&dirflg=d&t=s';

    Linking.canOpenURL(geoUrl).then(supported => {
      if (supported) {
        Linking.openURL(geoUrl);
      } else {
        log.info('Don\'t know how to open URI: ' + geoUrl);
      }
    });
  }
  
  render() {
    let maxHeight = utils.getDimensions().height
        - NavigationExperimental.Navigator.NavigationBar.Styles.General.NavBarHeight
        - STATUS_BAR_HEIGHT
        - ADS_BAR_HEIGHT;

    let relatedToAds = this.props.chat.ads;
    let cover = relatedToAds.cover || relatedToAds.image && relatedToAds.image.cover;
    let diaChinhFullName = relatedToAds.diaChinhFullName || relatedToAds.place && relatedToAds.place.diaChi;
    const adsTextLine1 = relatedToAds.loaiNhaDatFmt + " - " + diaChinhFullName;
    const adsTextLine2 = relatedToAds.giaFmt;

    let imageDataItems = [];
    imageDataItems.push(this.state.imageUri);

    let ads = this.props.chat.ads;
    let dangBoiUserID = ads && ads.dangBoi.userID || undefined;

    return (
        <MenuContext style={{ flex : 1 }}>
        <View style={styles.wrapper}>
          <TouchableOpacity style = {styles.adsHeader}
                            onPress={this._onPressDetail.bind(this)}
          >
              <Image
                  resizeMode = {"cover"}
                  source={{uri: cover}}
                  defaultSource={defaultCover}
                  style={styles.adsCover}/>
            <View style={styles.adsTitle}>
              <ScalableText numberOfLines={2} style={styles.adsLine1}>{adsTextLine1}</ScalableText>
              <ScalableText style={styles.adsLine2}>{adsTextLine2}</ScalableText>
            </View>
          </TouchableOpacity>
          <FullLine />

          <GiftedMessenger
              ref={(c) => this._GiftedMessenger = c}

              //renderTextInput = {this.renderTextInput.bind(this)}

              autoFocus={false}
              location={this.state.currentLocation}
              messages={this.props.chat.messages}
              handleSend={this.handleSend.bind(this)}
              handleSendLocation={this.handleSendLocation.bind(this)}
              handleSendVideoInvitation={this.handleSendVideoInvitation.bind(this)}
              showVideoCall={dangBoiUserID != undefined}
              onLiveStream={this.onLiveStream.bind(this, false)}
              onErrorButtonPress={this.onErrorButtonPress.bind(this)}
              maxHeight={maxHeight}

              loadEarlierMessagesButton={!this.props.chat.allLoaded}
              onLoadEarlierMessages={this.onLoadEarlierMessages.bind(this)}

              senderName='Awesome Developer'
              senderImage={null}
              onImagePress={this.onImagePress.bind(this)}
              displayNames={true}

              forceRenderImage = {true}

              parseText={true} // enable handlePhonePress, handleUrlPress and handleEmailPress
              handlePhonePress={this.handlePhonePress}
              handleUrlPress={this.handleUrlPress.bind(this)}
              handleEmailPress={this.handleEmailPress}

              isLoadingEarlierMessages={this.props.chat.isLoadingEarlierMessages}

              typingMessage={this.props.chat.typingMessage}

              renderCustomText = {this.renderCustomText.bind(this)}
          />
          {this.state.modal ? <ImagePreviewChat images={imageDataItems} owner={'chat'} closeModal={() => this.setState({modal: false}) }/> : null }
        </View>
        </MenuContext>
    );
  }

  onLiveStream(ignoreSendVideoInvitation){
    // console.log("InCallManager.onLiveStream()");
    // InCallManager.start({media: 'audio'});
    // InCallManager.stop();
    //
    if (this.props.global.loggedIn) {
      this._preLiveStream(ignoreSendVideoInvitation);
    } else {
      Actions.NewLogin({doFinalAction: this._preLiveStream.bind(this, ignoreSendVideoInvitation)});
    }
  }

  _preLiveStream(ignoreSendVideoInvitation) {
    Camera.checkDeviceAuthorizationStatus().then(
        (e) => {
          if (e){
            this._doLiveStream(ignoreSendVideoInvitation);
          } else {
            Alert.alert("Thông báo", gui.INF_CameraAccess);
          }
        });
  }

  _doLiveStream(ignoreSendVideoInvitation) {
    !ignoreSendVideoInvitation && this.handleSendVideoInvitation();
    // InCallManager.startRingtone('_BUNDLE_');
    // InCallManager.setKeepScreenOn(true);
    // InCallManager.start({media: 'audio'});
    // InCallManager.setForceSpeakerphoneOn(true);
    this.props.actions.onChatFieldChange('inVideoCall', true);
    let fromUserID = this.props.global.currentUser.userID;
    let toUserID = this.props.chat.partner.userID;
    let ads = this.props.chat.ads;
    let adsID = ads.adsID || ads.id;
    let dangBoiUserID = ads.dangBoi.userID;
    let roomName = fromUserID == dangBoiUserID ? 'Room_' + fromUserID + '_' + toUserID + '_' + adsID :
                                                 'Room_' + toUserID + '_' + fromUserID + '_' + adsID;
    let fullName = this.props.global.currentUser.fullName;
    let username = this.props.global.currentUser.username;
    Actions.LiveStream({username: fullName || username, roomName: roomName, doFinalAction: this._onCallHangup.bind(this)});

    Analytics.logEvent('VIDEO_CALL', {fromUserID: fromUserID, toUserID: toUserID, adsID: adsID});
  }

  _onCallHangup() {
    // InCallManager.stopRingtone();
    // InCallManager.setKeepScreenOn(false);
    // InCallManager.stop();
    // InCallManager.setForceSpeakerphoneOn(false);
    let msg = this.props.chat.incoming.msg;
    if (msg) {
      let fromUserID = msg.fromUserID;
      let ads = msg.relatedToAds;
      let adsID = ads.adsID || ads.id;
      let partnerUserID = this.props.chat.partner.userID;
      let currentAds = this.props.chat.ads;
      let currentAdsID = currentAds.adsID || currentAds.id;
      if (fromUserID == partnerUserID && adsID == currentAdsID) {
        this.props.actions.onChatFieldChange('incoming', {...this.props.chat.incoming, calling: false});
      }
    }
    this.props.actions.onChatFieldChange('inVideoCall', false);
    this.handleSendVideoCallCancel();
  }

    _onPressDetail() {
        let ads = this.props.chat.ads;
        if (ads.adsID && ads.adsID.length>0 && ads.adsID != "EMPTY")
          Actions.SearchResultDetail({ adsID: ads.adsID, source: 'server', imageDetail: ads.cover });

    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ChatContent);


var styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'column',
    flex : 1
  },

  headerAds : {

  },

  text: {
    flex: 1,
    alignSelf:'center',
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: gui.mainColor,
    fontWeight : 'normal',
    top: 9,
  },

  rowContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderColor: '#e6e6e6',
    marginLeft: 16,
    paddingTop: 10,
    paddingBottom: 10,
  },
  rightContainer: {
    flex: 1,
  },
  name: {
    fontSize: 12,
    color: 'gray',
    flex: 1,
  },
  dateTime: {
    fontSize: 12,
    color: 'gray',
    fontFamily: gui.fontFamily,
    //borderWidth: 2,
    //borderColor: 'red',
    marginRight: 18
  },
  title: {
    fontSize: 13,
    textAlign: 'left',
    fontFamily: gui.fontFamily,
    fontWeight: '500'
  },
  content: {
    fontSize: 13,
    textAlign: 'left',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal'
  },
  image: {
    borderRadius: 8,
    height: 240
  },
  nameAndDateTime : {
    flex: 1,
    flexDirection: 'row',

  },

  rightRow2 : {
    flexDirection: 'row',
  },
  titleAndLastMsg : {
    flex: 1,
    flexDirection: 'column',
  },
  // adsCover : {
  //   width: 40,
  //   height: 40,
  //   marginLeft: 18,
  //   marginRight: 18,
  //   marginTop: 4
  // },
  bottomText : {
    fontSize: 17,
    textAlign: 'center',
    fontFamily: gui.fontFamily,
    fontWeight: '600',
    color: '#e4e4e4',
    paddingTop: 10
  },

  textInputContainer: {
    height: 44,
    borderColor: '#b2b2b2',
    flexDirection: 'row',
    paddingLeft: 10,
    paddingRight: 10,
  },
  textInput: {
    alignSelf: 'center',
    height: 30,
    width: 100,
    backgroundColor: '#FFF',
    flex: 1,
    padding: 0,
    margin: 0,
    fontSize: 18,
    fontFamily: gui.fontFamily,
  },
  sendButton: {
    marginTop: 11,
    marginLeft: 10,
  },
  adsCover : {
    width: 60,
    height: 60,
    margin:3
  },
  adsTitle : {
    flex: 1,
    flexDirection: 'column',
    paddingLeft : 10,
    paddingRight: 10
  },

  adsLine1: {
    fontSize: 15,
    textAlign: 'left',
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    color:'#000'
  },

  adsLine2: {
    fontSize: 13,
    textAlign: 'left',
    fontFamily: gui.fontFamily,
    color : '#e50e27',
    paddingTop:2
  },
  adsHeader: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomWidth: 0,
    borderColor: '#e6e6e6',
  },
  viewIncomingModal: {
    width: width,
    height: height,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom:  49,
    borderRadius: 5,
    borderWidth: 0
  },
  viewModalTop:{
    justifyContent: 'flex-end',
    alignItems: 'center',
    backgroundColor: 'rgba(169, 168, 168, 0.01)',
    padding: 10,
    marginLeft: 10,
    marginRight: 10
  },
  viewAnimatable:{
    backgroundColor: '#fff',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    paddingLeft: 15,
    paddingRight: 15
  },
  textContent: {
    color: '#5f5f5f',
    fontSize: 13,
    fontFamily: gui.fontFamily,
    fontWeight: '500',
    textAlign: 'left'
  },
  chapNhanButtonText: {
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight : 'normal',
    color: '#fff',
    textAlign: 'center',
    marginLeft: 8,
    marginRight: 8,
    marginTop: 5,
    marginBottom: 5
  },
  gacMayButtonText: {
    fontSize: gui.buttonFontSize,
    fontFamily: gui.fontFamily,
    fontWeight : 'normal',
    color: '#fff',
    textAlign: 'center',
    marginLeft: 8,
    marginRight: 8,
    marginTop: 5,
    marginBottom: 5
  },
  chapNhanButtonWrapper: {
    backgroundColor: "#3E8FE7",
    height: 30,
    width: 100,
    borderRadius: 5,
    marginBottom: 5
  },
  gacMayButtonWrapper: {
    marginLeft: 10,
    backgroundColor: "#B8000A",
    height: 30,
    width: 100,
    borderRadius: 5,
    marginBottom: 5
  }
});