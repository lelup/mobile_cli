import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableHighlight,
    Alert
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { Actions } from 'react-native-router-flux';

import gui from '../../lib/gui';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import TabGroupMain from '../group/TabGroupMain';
import Modal from 'react-native-modalbox';
import DanhMuc from '../../assets/DanhMuc';
import TruliaIcon from '../TruliaIcon';

import FullLine from '../line/FullLine';
import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as chatActions from '../../reducers/chat/chatActions';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';


let { width, height } = utils.getDimensions();

const actions = [
    globalActions,
    meActions,
    groupActions,
    inboxActions,
    chatActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupInboxV2 extends Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            searchText: '',
            textMessage: '',
            msgType: '',
            msgBgColor: null,
            msgTextColor: null,
            loaded: false,
            isOpenModalPhamViChat: false,
            isloadingPressRow: false,
        }
    }

    componentWillMount() {

        // setTimeout(() => this.fetchData(), 300);
        let deviceID = this.props.deviceID || undefined;
        let userID = this.props.currentUser.userID || undefined;
        //Analytics.logEvent('LOAD_DETAIL', {deviceID: deviceID, userID: userID, adsID: this.props.adsID});
    }

    

    _updateMessageProcessing(textMessage, bgColor, textColor) {
        this.setState({ textMessage: textMessage, msgBgColor: bgColor, msgTextColor: textColor });
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({ msgType: 'fadeInDown' });
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => { this.setState({ msgType: 'fadeOutUp' }) }, 5000);
    }

    refreshRowData(data) {
        this.setState({
            'memberList': data,
            loaded: true
        });

    }

    render() {
        return (
            <View style={styles.container}>
                {this._renderHeader()}

                <ScrollView
                    contentContainerStyle={{ width: width, height: height - 136 }}
                    automaticallyAdjustContentInsets={false}
                    showsVerticalScrollIndicator={false}
                    vertical={true}
                    style={styles.scrollView}>

                    {this._renderInbox()}
                </ScrollView>

                {this._openModalPhamViChat()}
            </View>
        );
    }


    _renderHeader() {
        let inboxType = this.props.inboxType;
        let phamViChat = this._getPhamViChatValue();
        return (
            <View style={styles.headerView}>
                <View style={styles.subHeader}>

                    <View style={styles.viewThuGon}>
                        <TouchableOpacity
                            style={{ flexDirection: 'row' }}
                            onPress={this._onThuGon.bind(this)}>
                            <View style={{ justifyContent: 'center', alignItems: 'flex-end' }}>
                                <Text style={[styles.thuGonText]}>Thu gọn</Text>
                            </View>
                            <View style={{ marginLeft: 15, justifyContent: 'center', alignItems: 'center' }}>
                                <Icon name="compress" size={16} color={gui.mainColor} pointerEvents="none" />
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewTitleHeaderChat}>
                        <Text style={[styles.headerText]}>Tin nhắn</Text>
                    </View>
                    <TouchableOpacity style={styles.viewAddTinNhan}
                                      onPress={this.onChatAutoComplete.bind(this)}
                    >
                        <Icon name="edit" size={22} color={gui.mainColor} pointerEvents="none" />
                    </TouchableOpacity>
                </View>

                <View style={styles.tabHeader}>
                    <FullLine />
                    <View style={styles.tabbar}>
                        <View style={styles.viewTabSelect}>
                            <TabGroupMain name={'all'}
                                onPress={this._onTabChange.bind(this)}
                                selected={inboxType === 'all'}>Tất cả</TabGroupMain>
                            <TabGroupMain name={'personal'}
                                onPress={this._onTabChange.bind(this)}
                                selected={inboxType === 'personal'}>Cá nhân</TabGroupMain>
                            <TabGroupMain name={'group'}
                                onPress={this._onTabChange.bind(this)}
                                selected={inboxType === 'group'}>Sàn m.giới</TabGroupMain>
                            <TabGroupMain name={'spam'}
                                onPress={this._onTabChange.bind(this)}
                                selected={inboxType === 'spam'}>Spam</TabGroupMain>
                        </View>
                    </View>
                </View>

            </View>
        );

    }

    _onModalPhamViChat() {
        this.setState({
            isOpenModalPhamViChat: true
        })
    }

    _openModalPhamViChat() {
        return (
            <Modal isOpen={this.state.isOpenModalPhamViChat}
                onClosed={this._onContentModal.bind(this)}
                style={styles.viewLoaiNhaDatStyle}
                position={"center"}
                swipeToClose={false}
                backdropPressToClose={false}
               animationDuration={200}
            >
                {this._renderPhamViChatContent()}
            </Modal>
        );
    }

    _onContentModal() {
        this.setState({
            isOpenModalPhamViChat: false
        });
    }

    _getPhamViChatValue() {
        return DanhMuc.getPhamViChatForDisplay(this.props.phamViChat).toUpperCase();
    }

    _renderPhamViChatContent() {
        let phamViChat = DanhMuc.getPhamViChatValues();
        return (
            <View style={styles.viewDetailModal}>
                <View style={[styles.touchModalPhamViChat, styles.addTopText]} onPress={this._onContentModal.bind(this)}>
                    <View style={styles.viewSortModal}>
                        <Text style={[styles.textSapxep, { fontWeight: '500', fontSize: 17 }]}>PHẠM VI</Text>
                    </View>
                    {this._renderTextCancel()}
                </View>

                {phamViChat.map((e, index) => {
                    let orderPhamViChat = this._getPhamViChatValue();
                    let checked = e == orderPhamViChat;
                    let borderTopWidth = index==0? 0:1;
                    return (
                        <TouchableOpacity style={[styles.touchModalPhamViChat, ]}
                            key={e}
                            onPress={() => { this._onTabPhamViChatChange(e) }}>
                            <Text style={styles.textSapxep}>{e}</Text>
                            <View style={styles.viewTickSapxep}>
                                {
                                    checked ?
                                        <TruliaIcon
                                            name="check" color={gui.mainColor} size={20}
                                            mainProps={styles.viewCheckIcon}
                                        /> : null
                                }

                            </View>
                        </TouchableOpacity>
                    )
                })
                }
            </View>
        )
    }

    _onTabPhamViChatChange(value) {
        let currentUser = this.props.currentUser;
        let hashPhamViChat = DanhMuc.phamViChat;
        let phamViChatKey = utils.getKeyByValue(hashPhamViChat, value);
        this.setState({ isOpenModalPhamViChat: false });

        this.props.actions.onGroupFieldChange('phamViChat', phamViChatKey);

        const dto = {userID: currentUser.userID, limit: this.props.inbox.chatMessageLimit, pageNo: 1, phamViChat: phamViChatKey};        
        this.props.actions.onRefreshGroupInbox(currentUser.userID, dto);
        
    }

    _renderTextCancel() {
        return (
            <TouchableOpacity style={styles.touchSortCancel}
                onPress={this._onContentModal.bind(this)}
            >
                <Text style={[styles.textSapxep, { color: gui.mainColor, fontSize: 17 }]}>Hủy</Text>
            </TouchableOpacity>
        );
    }

    _onTabChange(value) {
        let currentUser = this.props.currentUser;        
        this.props.actions.onGroupFieldChange('inboxType', value);

        
        let phamViChatKey = DanhMuc.hashPhamViChat[value];
        this.props.actions.onGroupFieldChange('phamViChat', phamViChatKey);

        const dto = {userID: currentUser.userID, limit: this.props.inbox.chatMessageLimit, pageNo: 1, phamViChat: phamViChatKey};        
        this.props.actions.onRefreshGroupInbox(currentUser.userID, dto);
    }

    _renderSeparator() {
        return (
            <View style={styles.separatorLine}></View>
        )
    }

    _onCancelClicked() { }

    _onThuGon() {
        this.props.onThuGonPress && this.props.onThuGonPress();
    }

    onChatAutoComplete() {
        this.props.onThuGonPress && this.props.onThuGonPress();
        Actions.ChatAutoComplete();
    }

    renderLoadingView() {
        if (this.state.loading) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    _onGroupSearchPress() {
        Actions.GroupSearch();
    }

    _onUserSearchChange(text) {
        this.setState({ searchText: text });
    }
    _renderInbox() {

        let dsGroupInbox = this.props.allGroupInboxDS;
        return (
            <View style={{ flex: 1}}>
                <ListView
                    enableEmptySections={true}
                    dataSource={dsGroupInbox}
                    renderRow={this._renderRowInbox.bind(this)}
                    contentContainerStyle={styles.viewListContainer}
                    showsVerticalScrollIndicator={false}
                    initialListSize={25}
                />
            </View>
        );
    }

    _renderRowInbox(data) {
        
        let phamViChat = this.props.phamViChat;
        let inboxType = this.props.inboxType;

        if (!data.partners || data.partners.length==0)
            return (<View></View>)

        if ((!data.groupType|| data.groupType==1) && !data.content)
            return (<View></View>)

        if (phamViChat!=0 && phamViChat!=data.groupType)
            return (<View></View>)                    

        if (inboxType!='spam' && data.spamStatus && data.spamStatus!=0)
            return (<View></View>)

        if (inboxType=='spam' && DanhMuc.hashInboxType[inboxType] != data.spamStatus)
            return (<View></View>)     
                
            
        // log.info('GroupInboxV2: inbox data render here ++++>>>>', data);
        // let imgUrl = data.partner ? data.partner.avatar : "";
        let currentUser = this.props.currentUser;
        let imgUrl = "";
        let title = "";
        let defaultCover = require('../../assets/image/no_cover.jpg');        
        let defaultAvatar = require('../../assets/image/register_avatar_icon.png');
        let content = data.content || "";
        let groupIcon = null;
        if (!data.groupType || data.groupType == 1) {// ca nhan   
            // console.log ('loggin _renderRowInbox, data.partners: ', data.partners)                      
            data.partners && data.partners.forEach((partner) => {
                if (partner.userID != currentUser.userID) {
                    imgUrl = partner.avatar;            
                    title = partner.fullName;
                }
            })            
        } else { //2: san moi gioi
            imgUrl = data.groupImage;            
            title = data.groupName ? data.groupName : "";
            let lastSentName = "";
            if (data.lastSent) {
                let lastSentUserID = data.lastSent.userID;
                if (lastSentUserID != currentUser.userID) {
                    lastSentName = data.lastSent.fullName + ": ";
                } else {
                    lastSentName = "Bạn: ";
                }
            }
            content = data.content ? lastSentName + data.content : "";
            groupIcon = this._renderGroupIcon();
        }
        
        imageGroup = imgUrl? { uri: imgUrl } : defaultAvatar;

        let timestamp = data.timestamp;
        content = content && content.length > 25 ? content.substring(0, 25) + " ..." : content
        let totalMessages = data.numOfUnreadMessage;
        // console.log('totalMessages:>>>>>', totalMessages)
        return (
            <TouchableHighlight onPress={() => this.onRowClick(data)}
                underlayColor="transparent"
            >
                <View style={[styles.viewRowContent, {}]}>
                    <View style={styles.viewContent}>
                        <View>
                            <Image
                                resizeMode={"cover"}
                                source={imageGroup}
                                defaultSource={defaultCover}
                                style={styles.adsCover} />
                            {totalMessages==0 ? (<View></View>)
                                : (<View style={styles.viewNumberMessage}>
                                    <Text style={[styles.textNameAvatar, { fontSize: 8, color: '#fff', backgroundColor: 'transparent' }]}>{totalMessages}</Text>
                                </View>)
                            }
                            {groupIcon}
                        </View>

                        <View style={styles.viewBodyContent}>
                            <View style={styles.viewNameGroup}>
                                <View style={{ width: (width - 32 - 48) / 3 * 2 }}>
                                    <Text style={[styles.textNameGroup, { marginLeft: 16 }]} numberOfLines={1}>{title}</Text>
                                </View>
                                <View style={{ width: (width - 32 - 48) / 3, alignItems: 'flex-end' }}>
                                    <Text style={[styles.textNameAvatar]}>{utils.showChatTime(timestamp)}</Text>
                                </View>
                            </View>
                            <View style={styles.viewContentChat}>
                                <Text style={[styles.textNameAvatar, { marginLeft: 16 }]}>{utils.normalizeName(content)}</Text>
                            </View>
                        </View>
                    </View>

                </View>
            </TouchableHighlight>
        )
    }

    _renderGroupIcon() {
        return (
            <View style={styles.iconGroup}>
                <View style={styles.detailIconGroup}>
                    <Icon name="users" size={8} color={'#fff'} />
                </View>
            </View>
        )
    }

    onRowClick(rowData) {
        
        this.setState({
            isloadingPressRow: true
        })
        
        let chatGroupDto = { 
            chatGroupID: rowData.chatGroupID,
            chatGroupName: rowData.groupName,
            chatGroupImage: rowData.groupImage,
            chatGroupType: rowData.groupType
        }
        let isSpam = rowData.spamStatus && rowData.spamStatus==2;

        let currentUser = this.props.currentUser;
        let chatTitle = "";
        if (!rowData.groupType || rowData.groupType == 1) {// ca nhan               
            rowData.partners && rowData.partners.forEach((partner) => {
                if (partner.userID != currentUser.userID)                     
                    chatTitle = partner.fullName;                
            })            
        } else { //2: san moi gioi            
            chatTitle = rowData.groupName ? rowData.groupName : "";
        }
        this.props.actions.onChatFieldChange('currentGroupChatPageNo', 1)
        let dto = { userID: currentUser.userID, limit: this.props.chatMessageLimit, pageNo: 1, chatGroupID: chatGroupDto.chatGroupID };

        this.props.actions.startGroupChat(currentUser, dto,
            chatGroupDto).then((e) => {
                this.props.onThuGonPress && this.props.onThuGonPress();
                Actions.GroupChat({ owner: 'inbox', isSpam: isSpam, chatTitle: chatTitle, onGroupInbox: this.props.onGroupInbox });
                this.setState({
                    isloadingPressRow: false
                })
            });

    }

    _presRowChat() {
        this.setState({
            isloadingPressRow: true
        })
    }
    _endPressRow() {
        this.setState({
            isloadingPressRow: false
        })
    }

    

    _onReject() { }

    _renderButtonChat() {
        let totalMessages = '23';
        return (
            <TouchableOpacity style={styles.viewButtonChat}>
                <View style={styles.viewCircleChat}>
                    <Icon name="comments-o" size={22} color={'#fff'} style={{ marginLeft: 0 }} />
                </View>
                <View style={styles.viewNumberMessage}>
                    <Text style={[styles.textNameAvatar, { fontSize: 8, color: '#fff' }]}>{totalMessages}</Text>
                </View>
            </TouchableOpacity>
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        flex: 1,
        backgroundColor: gui.groupBackground,
        paddingBottom: 130
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 126,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 120
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 17
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontSize: 24
    },
    viewIntroduce: {
        width: width,
        height: 100,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 19
    },
    viewTextTop: {
        width: width - 32,
        height: 60,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    viewTextEnd: {
        width: width - 32,
        height: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
    },
    textTopPattern: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontSize: 15
    },

    viewDetailEachGroup: {
        width: width - 104,
        // height: 32,
        marginTop: 6,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        marginLeft: 64
    },
    adsCover: {
        width: 48,
        height: 48,
        marginLeft: 0,
        borderRadius: 24
    },
    viewBodyContent: {
        backgroundColor: 'transparent',
        height: 48,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    viewMoreButton: {
        width: 81,//31
        height: 81,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingTop: 19
    },
    viewNameGroup: {
        backgroundColor: 'transparent',
        height: 24,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewContentChat: {
        backgroundColor: 'transparent',
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTimeChat: {
        backgroundColor: 'transparent',
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    textNameGroup: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: '500'
    },
    avatarAdmin: {
        height: 16,
        width: 16,
        borderRadius: 8
    },
    textNameAvatar: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal'
    },
    textMessage: {
        fontFamily: gui.fontFamily,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        fontSize: 12
    },
    viewRowContent: {
        height: 82,
        borderBottomWidth: 1,
        // marginTop: 16,//14
        borderColor: 'rgba(82,97,115,0.3)',
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',

    },
    viewContent: {
        marginLeft: 16,
        marginRight: 16,
        width: width - 32,
        height: 48,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'transparent',
        flexDirection: 'row'
    },
    lineEachGroup: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 64,
        opacity: 0.8
    },
    viewListContainer: {
        paddingBottom: 0
    },
    viewButtonChat: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: 56,
        height: 56,
        bottom: 88,
        right: 32
    },
    viewCircleChat: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        width: 56,
        height: 56,
        borderRadius: 28
    },

    headerView: {
        backgroundColor: '#fff',
        height: 136,
        width: width,
        borderBottomWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)'
    },
    subHeader: {
        backgroundColor: 'transparent',
        marginTop: 40,
        marginLeft: 16,
        width: width - 32,
        height: 24,
        flexDirection: 'row'
    },
    tabHeader: {
        // backgroundColor: 'blue',
        flexDirection: 'row',
        marginTop: 17,
        width: width - 32,
        height: 55,
        alignItems: 'flex-end',
        paddingBottom: 4
    },
    headerView3: {
        backgroundColor: 'transparent',
        marginTop: 23,
        marginLeft: 16,
        width: width - 32,
        height: 24
    },
    headerText: {
        fontSize: 15,
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    thuGonText: {
        fontSize: 15,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainColor
    },
    tabHeaderText: {
        fontSize: 15,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor
    },
    headerText2: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173'
    },
    approve: {
        width: 18,
        height: 18,
        backgroundColor: 'transparent',
    },
    reject: {
        width: 18,
        height: 18,
        marginLeft: 24,
        backgroundColor: 'transparent',
    },
    searchButtonView: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: 72,
        bottom: 49,
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row'
        //borderRadius: 24
    },
    searchButton: {
        height: 41,
        width: (width - 52) / 2,
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1
    },
    searchButtonText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    separatorLine: {
        borderLeftWidth: 0.5,
        width: 1,
        height: 40,
        marginTop: 7,
        borderColor: "#99526173",
        opacity: 0.6
    },
    tabbar: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: width,
        height: 33,
        backgroundColor: '#fff'
    },
    viewTabSelect: {
        height: 32,
        width: width,
        backgroundColor: 'white',
        flexDirection: 'row'
    },
    viewLoaiNhaDatStyle: {
        justifyContent: 'center',
        height: 158,
        width: width - 80,
        marginVertical: 0,
        borderRadius: 8
    },
    viewDetailModal: {
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        //paddingLeft: 8,
        flexGrow: 1,
        borderRadius: 8
    },
    touchModalPhamViChat: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        borderTopWidth: 1,
        borderColor: 'rgba(220,220,220,0.5)',
        height: 39,
        alignItems: 'center',
        marginLeft: 18
    },
    addTopText: {
        backgroundColor: '#f5f6f8',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        marginLeft: 0,
        borderTopWidth: 0,
        borderBottomWidth: 1
    },
    textSapxep: {
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
    },
    viewSortModal: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 62,
        backgroundColor: 'transparent'
    },
    touchSortCancel: {
        height: 34,
        width: 50,
        justifyContent: 'center',
        alignItems: 'flex-end',
        marginRight: 12,
        backgroundColor: 'transparent'
    },
    viewTickSapxep: {
        flexGrow: 1,
        backgroundColor: 'transparent',
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginRight: 19,
        marginBottom: 4,
        height: 34
    },
    viewCheckIcon: {
        width: 15,
        height: 18
    },
    viewNumberMessage: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: '#ff0000',
        width: 16,
        height: 16,
        borderRadius: 9,
        top: 0,
        left: 0
    },
    iconGroup: {
        height: 20,
        width: 20,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        right: 0,
        backgroundColor: '#fff'
    },
    detailIconGroup: {
        height: 18,
        width: 18,
        borderRadius: 9,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainAgentColor
    },
    viewAddTinNhan: {
        height: 24,
        width: 90,
        justifyContent: 'center',
        alignItems: 'flex-end'
    },
    viewThuGon: {
        width: 90,
        height: 24,
        justifyContent: 'center',
    },
    viewTitleHeaderChat: {
        width: width - 32 - 180,
        height: 24,
        justifyContent: 'center',
        alignItems: 'center'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },

});

export default connect(mapStateToProps, mapDispatchToProps)(GroupInboxV2);