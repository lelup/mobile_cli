import React, {
  Component,
} from 'react';
import {
  Text,
  View,
  ListView,
  FlatList,
  TextInput,
  Animated,
  Platform,
  PixelRatio,
  Alert,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  StatusBar
} from 'react-native';
import Camera from 'react-native-camera';
import TextInputAuto from '../postAds/TextInputAuto';

import Icon from 'react-native-vector-icons/FontAwesome';
import FontAwesomeLight from '../font/FontAwesomeLight';
import Message from './MessageGroup';
import GiftedSpinner from 'react-native-gifted-spinner';
import moment from 'moment';
import { setLocale } from './Locale';
import deepEqual from 'deep-equal';
import Button from 'react-native-button';
import RelandIcon from '../RelandIcon';
import gui from '../../lib/gui';
import FullLine from '../line/FullLine';
import ChatMenu from '../chat/ChatMenu'
const Permissions = require('react-native-permissions');

import PropTypes from 'prop-types';

import { Actions } from 'react-native-router-flux';
import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as Animatable from 'react-native-animatable';

import ScalableText from 'react-native-text';

import * as globalActions from '../../reducers/global/globalActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as chatActions from '../../reducers/chat/chatActions';

import utils from '../../lib/utils';
const { width, height } = utils.getDimensions();

const actions = [
  globalActions,
  meActions,
  groupActions,
  inboxActions,
  chatActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class GiftedGroup extends Component {

  constructor(props) {
    super(props);
      StatusBar.setBarStyle('dark-content');
    this.onFooterLayout = this.onFooterLayout.bind(this);
    this.renderRow = this.renderRow.bind(this);
    this.renderLoadEarlierMessages = this.renderLoadEarlierMessages.bind(this);
    this.onLayout = this.onLayout.bind(this);
    this.renderFooter = this.renderFooter.bind(this);
    this.onChangeVisibleRows = this.onChangeVisibleRows.bind(this);
    this.onKeyboardWillShow = this.onKeyboardWillShow.bind(this);
    this.onKeyboardDidShow = this.onKeyboardDidShow.bind(this);
    this.onKeyboardWillHide = this.onKeyboardWillHide.bind(this);
    this.onKeyboardDidHide = this.onKeyboardDidHide.bind(this);
    this.onChangeText = this.onChangeText.bind(this);
    this.onSend = this.onSend.bind(this);

    this._firstDisplay = true;
    this._listHeight = 0;
    this._footerY = 0;
    this._scrollToBottomOnNextRender = false;
    this._scrollToPreviousPosition = false;
    this._visibleRows = { s1: {} };

    let textInputHeight = 68;
    if (!this.props.hideTextInput) {
      if (this.props.styles.hasOwnProperty('textInputContainer')) {
        textInputHeight = this.props.styles.textInputContainer.height || textInputHeight;
      }
    }

    this.listViewMaxHeight = this.props.maxHeight; // - textInputHeight; plus height for style tab Icons chat

    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => {
        if (r1.status !== r2.status) {
          return true;
        }
        return false;
      },
    });

    this.state = {
      dataSource: ds.cloneWithRows([]),
      text: props.text,
      disabled: true,
      height: new Animated.Value(this.listViewMaxHeight),
      appearAnim: new Animated.Value(0),
      dropdownSelection: '',
      isOpenHelpStream: !props.global.help.streamHelped
    };
  }

  componentWillMount() {
    this.styles = {
      container: {
        flex: 1,
        backgroundColor: '#FFF',
      },
      listView: {
        flex: 1,
        paddingTop: 10
      },
      textInputContainer: {
        height: 68,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        paddingRight: 10,
        paddingBottom: 12, // wtf padding here for true style
        backgroundColor: '#ffffff'
      },
      plusButton: {
        width: 20,
        height: 68,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 16
      },
      imageSendButton: {
        width: 23,
        height: 68,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 16
      },
      textInputView: {
        height: 42,
        width: width - 190,
        flex: 1,
        borderColor: gui.textPostAds,
        borderRadius: 21,
        borderWidth: 1,
        backgroundColor: 'white',
        paddingVertical: 5,
        marginLeft: 18,
        paddingLeft: 16,
        // alignItems:'flex-start',
        justifyContent: 'center'
      },
      textInput: {
        textAlign: 'left',
        // alignSelf: 'center',                       
        fontSize: 15,
        // paddingTop: 11,
          height: 'auto',
          paddingRight: 9

      },
      sendButton: {
        marginLeft: 10,
        fontSize: 17,
        fontWeight: '400',
        fontFamily: gui.fontFamily
      },
      date: {
        color: '#aaaaaa',
        fontSize: 11,
        textAlign: 'center',
        fontWeight: '400',
        marginBottom: 8,
        fontFamily: gui.fontFamily
      },
      link: {
        color: '#e0f4fc',
        textDecorationLine: 'underline'
      },
      loadEarlierMessages: {
        height: 44,
        justifyContent: 'center',
        alignItems: 'center'
      },
      loadEarlierMessagesButton: {
        fontSize: 15
      },
    };

    Object.assign(this.styles, this.props.styles);

    if (this.props.dateLocale !== '')
      setLocale(this.props.dateLocale);
  }

  componentDidMount() {
    this.scrollResponder = this.refs.listView.getScrollResponder();

    if (this.props.messages.length > 0) {
      this.setMessages(this.props.messages);
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.typingMessage !== this.props.typingMessage) {
      if (this.isLastMessageVisible()) {
        this._scrollToBottomOnNextRender = true;
      }
    }

    if (nextProps.global.help.streamHelped !== this.props.global.help.streamHelped) {
      this.setState({ isOpenHelpStream: !nextProps.global.help.streamHelped })
    }

    if (deepEqual(nextProps.messages, this.props.messages) === false) {
      let isAppended = null;
      if (nextProps.messages.length === this.props.messages.length) {
        // we assume that only a status has been changed
        if (this.isLastMessageVisible()) {
          isAppended = true; // will scroll to bottom
        } else {
          isAppended = null;
        }
      } else if (deepEqual(nextProps.messages[nextProps.messages.length - 1], this.props.messages[this.props.messages.length - 1]) === false) {
        // we assume the messages were appended
        isAppended = true;
      } else {
        // we assume the messages were prepended
        isAppended = false;
      }
      this.setMessages(nextProps.messages, isAppended);
    }

    let textInputHeight = 68;
    if (nextProps.styles.hasOwnProperty('textInputContainer')) {
      textInputHeight = nextProps.styles.textInputContainer.height || textInputHeight;
    }

    if (nextProps.maxHeight !== this.props.maxHeight) {
      this.listViewMaxHeight = nextProps.maxHeight;
      Animated.timing(this.state.height, {
        toValue: this.listViewMaxHeight,
        duration: 150,
      }).start();
    }

    if (nextProps.hideTextInput && !this.props.hideTextInput) {
      this.listViewMaxHeight += textInputHeight;

      this.setState({
        height: new Animated.Value(this.listViewMaxHeight),
      });
    } else if (!nextProps.hideTextInput && this.props.hideTextInput) {
      this.listViewMaxHeight -= textInputHeight;

      this.setState({
        height: new Animated.Value(this.listViewMaxHeight),
      });
    }
  }

  takePicture() {
    Camera.checkDeviceAuthorizationStatus().then(
      (e) => {
        if (e) {
          Permissions.requestPermission('photo')
            .then(response => {
              if (response == 'authorized') {
                Actions.PostAds({ owner: 'groupchat' });
              } else {
                Alert.alert("Thông báo", gui.INF_PhotoAccess);
              }
            });
        } else {
          Alert.alert("Thông báo", gui.INF_CameraAccess);
        }
      });

  }

  onSend() {
    this.myTextInput.clear();

    const message = {
      text: this.state.text.trim(),
      name: this.props.senderName,
      image: this.props.senderImage,
      position: 'right',
      date: new Date(),
    };
    if (this.props.onCustomSend) {
      this.props.onCustomSend(message);
    } else {
      this.onChangeText('');

      this.props.handleSend(message);
    }
  }

  onKeyboardWillHide() {
    Animated.timing(this.state.height, {
      toValue: this.listViewMaxHeight,
      duration: 150,
    }).start();
  }

  onKeyboardDidHide(e) {
    if (Platform.OS === 'android') {
      this.onKeyboardWillHide(e);
    }

    // TODO test in android
    //if (this.props.keyboardShouldPersistTaps === false) {
    if (this.isLastMessageVisible()) {
      this.scrollToBottom();
    }
    //}
  }

  onKeyboardWillShow(e) {
    Animated.timing(this.state.height, {
      toValue: this.listViewMaxHeight - e.endCoordinates.height,
      duration: 200,
    }).start();
  }

  onKeyboardDidShow(e) {
    if (Platform.OS === 'android') {
      this.onKeyboardWillShow(e);
    }

    setTimeout(() => {
      this.scrollToBottom();
    }, (Platform.OS === 'android' ? 200 : 100));
  }

  onLayout(event) {
    const layout = event.nativeEvent.layout;
    this._listHeight = layout.height;

    if (this._firstDisplay === true) {
      requestAnimationFrame(() => {
        this._firstDisplay = false;
        this.scrollToBottom(false);
      });
    }
  }

  onFooterLayout(event) {
    const layout = event.nativeEvent.layout;
    const oldFooterY = this._footerY;
    this._footerY = layout.y;

    if (this._scrollToBottomOnNextRender === true) {
      this._scrollToBottomOnNextRender = false;
      this.scrollToBottom();
    }

    if (this._scrollToPreviousPosition === true) {
      this._scrollToPreviousPosition = false;
      if (this.scrollResponder) {
        this.scrollResponder.scrollTo({
          y: this._footerY - oldFooterY,
          x: 0,
          animated: false,
        });
      }
    }
  }

  onChangeVisibleRows(visibleRows) {
    this._visibleRows = visibleRows;
  }

  onChangeText(text) {
    this.setState({
      text: text,
      disabled: text.trim().length <= 0
    });

    this.props.onChangeText(text);
  }

  getLastMessageUniqueId() {
    if (this.props.messages.length > 0) {
      return this.props.messages[this.props.messages.length - 1].uniqueId;
    }
    return null;
  }

  getPreviousMessage(message) {
    for (let i = 0; i < this.props.messages.length; i++) {
      if (message.uniqueId === this.props.messages[i].uniqueId) {
        if (this.props.messages[i - 1]) {
          return this.props.messages[i - 1];
        }
      }
    }
    return null;
  }

  getNextMessage(message) {
    for (let i = 0; i < this.props.messages.length; i++) {
      if (message.uniqueId === this.props.messages[i].uniqueId) {
        if (this.props.messages[i + 1]) {
          return this.props.messages[i + 1];
        }
      }
    }
    return null;
  }

  setMessages(messages, isAppended = null) {
    this.filterStatus(messages);

    const rows = {};
    const identities = [];
    for (let i = 0; i < messages.length; i++) {
      if (typeof messages[i].uniqueId === 'undefined') {
        console.warn('messages[' + i + '].uniqueId is missing');
      }
      rows[messages[i].uniqueId] = Object.assign({}, messages[i]);
      identities.push(messages[i].uniqueId);
    }

    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(rows, identities),
    });

    if (isAppended === true) {
      this._scrollToBottomOnNextRender = true;
    } else if (isAppended === false) {
      this._scrollToPreviousPosition = true;
    }
  }

  // Keep only the status of the last 'right' message
  filterStatus(messages) {
    let lastStatusIndex = 0;
    for (let i = 0; i < messages.length; i++) {
      if (messages[i].position === 'right') {
        lastStatusIndex = i;
      }
    }

    for (let i = 0; i < lastStatusIndex; i++) {
      if (messages[i].position === 'right') {
        if (messages[i].status !== 'ErrorButton') {
          delete messages[i].status;
        }
      }
    }
  }


  isLastMessageVisible() {
    return !!this._visibleRows.s1[this.getLastMessageUniqueId()];
  }

  scrollToBottom(animated = null) {
    if (this._listHeight && this._footerY && this._footerY > this._listHeight) {
      let scrollDistance = this._listHeight - this._footerY;
      if (this.props.typingMessage) {
        scrollDistance -= 44;
      }

      if (this.scrollResponder) {
        this.scrollResponder.scrollTo({
          y: -scrollDistance,
          x: 0,
          animated: typeof animated === 'boolean' ? animated : this.props.scrollAnimated,
        });
      }
    }
  }

  preLoadEarlierMessages() {
    this.props.onLoadEarlierMessages();
  }

  renderLoadEarlierMessages() {
    if (this.props.loadEarlierMessagesButton) {
      if (this.props.isLoadingEarlierMessages) {
        return (
          <View style={this.styles.loadEarlierMessages}>
            <GiftedSpinner size="large" />
          </View>
        );
      }
      return (
        <View style={this.styles.loadEarlierMessages}>
          <Button
            style={this.styles.loadEarlierMessagesButton}
            onPress={() => { this.preLoadEarlierMessages(); }}
          >
            {this.props.loadEarlierMessagesButtonText}
          </Button>
        </View>
      );
    }
    return (
      <View style={{ height: 10 }} />
    );
  }

  renderTypingMessage() {
    if (this.props.typingMessage) {
      return (
        <View
          style={{
            height: 44,
            justifyContent: 'center',
          }}
        >
          <Text
            style={{
              marginLeft: 10,
              marginRight: 10,
              color: '#aaaaaa',
            }}
          >
            {this.props.typingMessage}
          </Text>
        </View>
      );
    }
    return null;
  }

  renderFooter() {
    return (
      <View
        onLayout={this.onFooterLayout}
      >
        {this.renderTypingMessage()}
      </View>
    );
  }

  renderDate(rowData = {}) {
    let diffMessage = null;
    diffMessage = this.getPreviousMessage(rowData);

    let currentDate = rowData.timestamp ? new Date(rowData.timestamp) : undefined;

    if (this.props.renderCustomDate) {
      return this.props.renderCustomDate(rowData, diffMessage)
    }

    if (currentDate && currentDate instanceof Date) {
      if (diffMessage === null) {
        return (
          <Text style={[this.styles.date]}>
            {moment(currentDate).calendar()}
          </Text>
        );
      } else if (new Date(diffMessage.timestamp) instanceof Date) {
        const diff = moment(currentDate).diff(moment(new Date(diffMessage.timestamp)), 'minutes');
        if (diff > 5) {
          return (
            <Text style={[this.styles.date]}>
              {moment(currentDate).calendar()}
            </Text>
          );
        }
      }
    }
    return null;
  }

  renderRow(rowData) {
    let diffMessage = null;
    diffMessage = this.getPreviousMessage(rowData);
    return (
      <View>
        {this.renderDate(rowData)}
        <Message
          rowData={rowData}
          onErrorButtonPress={this.props.onErrorButtonPress}
          displayNames={this.props.displayNames}
          displayNamesInsideBubble={this.props.displayNamesInsideBubble}
          diffMessage={diffMessage}
          position={rowData.position}
          forceRenderImage={this.props.forceRenderImage}
          onImagePress={this.props.onImagePress}
          onMessageLongPress={this.props.onMessageLongPress}
          renderCustomText={this.props.renderCustomText}

          parseText={this.props.parseText}
          handlePhonePress={this.props.handlePhonePress}
          handleUrlPress={this.props.handleUrlPress}
          handleEmailPress={this.props.handleEmailPress}

          styles={this.styles}
        />
      </View>
    );
  }

  renderAnimatedView() {
    return (
      <Animated.View
        style={{
          height: this.state.height,
          justifyContent: 'flex-end',
        }}

      >
        {/*

        <FlatList
          ref="listView"
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={this._onRefresh.bind(this)}
            />
          }

          data={this.props.messages}
          keyExtractor={(item, index) => "list" + index}
          renderItem={(data) => this.renderRow(data.item)}
          removeClippedSubviews={false}
          enableEmptySections
          showsVerticalScrollIndicator={false}
          style={this.styles.listView}

          onLayout={this.onLayout}
          renderFooter={this.renderFooter}
          onChangeVisibleRows={this.onChangeVisibleRows}
          // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
          onKeyboardWillShow={this.onKeyboardWillShow}
          onKeyboardDidShow={this.onKeyboardDidShow}
          // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
          onKeyboardWillHide={this.onKeyboardWillHide}
          onKeyboardDidHide={this.onKeyboardDidHide}
          // @issue keyboardShouldPersistTaps={false} + textInput focused = 2 taps are needed to trigger the ParsedText links
          //keyboardShouldPersistTaps={this.props.keyboardShouldPersistTaps}
          keyboardDismissMode={this.props.keyboardDismissMode}

          initialListSize={this.props.messages.length}
          pageSize={this.props.messages.length}

          {...this.props}
        />
           */}

        <ListView
          ref="listView"
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={this._onRefresh.bind(this)}
            />
          }
          dataSource={this.state.dataSource}
          renderRow={this.renderRow}
          //renderHeader={this.renderLoadEarlierMessages}
          enableEmptySections={true}
          onLayout={this.onLayout}
          renderFooter={this.renderFooter}
          onChangeVisibleRows={this.onChangeVisibleRows}
          style={this.styles.listView}

          // not supported in Android - to fix this issue in Android, onKeyboardWillShow is called inside onKeyboardDidShow
          onKeyboardWillShow={this.onKeyboardWillShow}
          onKeyboardDidShow={this.onKeyboardDidShow}
          // not supported in Android - to fix this issue in Android, onKeyboardWillHide is called inside onKeyboardDidHide
          onKeyboardWillHide={this.onKeyboardWillHide}
          onKeyboardDidHide={this.onKeyboardDidHide}
          // @issue keyboardShouldPersistTaps={false} + textInput focused = 2 taps are needed to trigger the ParsedText links
          //keyboardShouldPersistTaps={this.props.keyboardShouldPersistTaps}
          keyboardDismissMode={this.props.keyboardDismissMode}

          initialListSize={this.props.messages.length}
          pageSize={this.props.messages.length}

          {...this.props}
        />

      </Animated.View>
    );
  }

  _onRefresh() {
    let chatGroupDto = {
      chatGroupID: this.props.chat.chatGroupID,
      chatGroupName: this.props.chat.chatGroupName,
      chatGroupImage: this.props.chat.chatGroupImage,
      chatGroupType: this.props.chat.chatGroupType
    }
    let nextPageNo = this.props.chat.currentGroupChatPageNo + 1;
    let dto = { userID: this.props.global.currentUser.userID, limit: this.props.chat.chatMessageLimit, pageNo: nextPageNo, chatGroupID: chatGroupDto.chatGroupID };
    this.props.actions.refreshGroupChat(this.props.global.currentUser, dto,
      chatGroupDto).then((e) => {
        // Actions.GroupChat({ owner: 'inbox', chatTitle: chatTitle });
        this.setState({
          isloadingPressRow: false
        })
        this.props.actions.onChatFieldChange('currentGroupChatPageNo', nextPageNo)
      });
  }

  setTextInputValue(text) {
    text = text || this.state.text
    this.setState({
      text,
      disabled: text.trim().length <= 0,
    });
  }
  _renderListChat() {

  }

  renderTextInput() {
    if (this.props.renderTextInput) {
      return this.props.renderTextInput({
        ...this.props,
        ...this.state,
        onSend: this.onSend,
        onChangeText: this.onChangeText
      });
    }
    if (this.props.hideTextInput === false) {
      return (
        <View style={this.styles.textInputContainer}>
          <TouchableOpacity style={this.styles.plusButton}
            onPress={this.getLocation.bind(this)}>
            <FontAwesomeLight name='map-marker-alt'
                              size={20}
                              color={gui.textPostAds}
                              noAction={true}
                              iconOnly={true}
            />
          </TouchableOpacity>
          <TouchableOpacity style={this.styles.imageSendButton}
            onPress={this.takePicture.bind(this)}
          >
            <FontAwesomeLight name='image'
                              size={22}
                              color={gui.textPostAds}
                              noAction={true}
                              iconOnly={true} />
          </TouchableOpacity>
          <View style={this.styles.textInputView}>
            <TextInput
              ref={(e) => this.myTextInput = e}
              style={this.styles.textInput}
              placeholder={this.props.placeholder}
              placeholderTextColor={this.props.placeholderTextColor}
              onChangeText={this.onChangeText}
              value={this.state.text}
              autoFocus={this.props.autoFocus}
              returnKeyType={this.props.submitOnReturn ? 'send' : 'default'}
              onSubmitEditing={this.props.submitOnReturn ? this.onSend : () => { }}
              enablesReturnKeyAutomatically={true}
              blurOnSubmit={this.props.blurOnSubmit}
              autoCorrect={false}
              multiline={true}
              textAlignVertical={'center'}
              numberOfLines={3}
              // keyboardType="twitter"
            />
          </View>
          <Button
            style={this.styles.sendButton}
            styleDisabled={this.styles.sendButtonDisabled}
            onPress={this.onSend}
            disabled={this.state.disabled}
          >
            {this.props.sendButtonText}
          </Button>
        </View>
      );
    }
    return null;
  }

  getLocation() {
    let location = this.props.location ? { lat: this.props.location.latitude, lon: this.props.location.longitude } : {};
    Actions.MMapView({ onPress: this._onViTri.bind(this), location: location });
  }

  _onViTri(position) {
    this.props.handleSendLocation(position);
  }

  _onPressTempMsg(msg) {
    this.onChangeText(msg);
  }

  render() {
    return (
      <View style={this.styles.container}>
        {this.renderAnimatedView()}
        <FullLine />
        {this.renderTextInput()}
      </View>
    );
  }
}

GiftedGroup.defaultProps = {
  autoFocus: true,
  location: {},
  blurOnSubmit: false,
  dateLocale: '',
  displayNames: true,
  displayNamesInsideBubble: false,
  forceRenderImage: false,
  handleEmailPress: () => { },
  handlePhonePress: () => { },
  handleSend: () => { },
  handleSendLocation: () => { },
  handleUrlPress: () => { },
  hideTextInput: false,
  isLoadingEarlierMessages: false,
  keyboardDismissMode: 'interactive',
  //keyboardShouldPersistTaps: true,
  leftControlBar: null,
  loadEarlierMessagesButton: false,
  loadEarlierMessagesButtonText: 'Load earlier messages',
  maxHeight: height,
  messages: [],
  onChangeText: () => { },
  onErrorButtonPress: () => { },
  onImagePress: null,
  onLoadEarlierMessages: () => { },
  onMessageLongPress: () => { },
  parseText: false,
  placeholder: 'Aa',
  placeholderTextColor: 'rgba(178,178,178,1)',
  scrollAnimated: true,
  sendButtonText: 'GỬI',
  senderImage: null,
  senderName: 'Sender',
  styles: {},
  submitOnReturn: false,
  text: '',
  typingMessage: '',
  onLiveStream: () => { },
  showVideoCall: false
};

GiftedGroup.propTypes = {
  autoFocus: PropTypes.bool,
  location: PropTypes.object,
  blurOnSubmit: PropTypes.bool,
  dateLocale: PropTypes.string,
  displayNames: PropTypes.bool,
  displayNamesInsideBubble: PropTypes.bool,
  forceRenderImage: PropTypes.bool,
  handleEmailPress: PropTypes.func,
  handlePhonePress: PropTypes.func,
  handleSend: PropTypes.func,
  handleSendLocation: PropTypes.func,
  handleUrlPress: PropTypes.func,
  hideTextInput: PropTypes.bool,
  isLoadingEarlierMessages: PropTypes.bool,
  keyboardDismissMode: PropTypes.string,
  // keyboardShouldPersistTaps: PropTypes.bool,
  leftControlBar: PropTypes.element,
  loadEarlierMessagesButton: PropTypes.bool,
  loadEarlierMessagesButtonText: PropTypes.string,
  maxHeight: PropTypes.number,
  messages: PropTypes.array,
  onChangeText: PropTypes.func,
  onCustomSend: PropTypes.func,
  onErrorButtonPress: PropTypes.func,
  onImagePress: PropTypes.func,
  onLoadEarlierMessages: PropTypes.func,
  onMessageLongPress: PropTypes.func,
  parseText: PropTypes.bool,
  placeholder: PropTypes.string,
  placeholderTextColor: PropTypes.string,
  renderCustomText: PropTypes.func,
  renderCustomDate: PropTypes.func,
  scrollAnimated: PropTypes.bool,
  sendButtonText: PropTypes.string,
  senderImage: PropTypes.object,
  senderName: PropTypes.string,
  styles: PropTypes.object,
  submitOnReturn: PropTypes.bool,
  typingMessage: PropTypes.string,
  onLiveStream: PropTypes.func,
  showVideoCall: PropTypes.bool
};

export default connect(mapStateToProps, mapDispatchToProps)(GiftedGroup);