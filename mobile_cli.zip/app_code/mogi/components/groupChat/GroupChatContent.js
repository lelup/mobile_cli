import React, { Component } from 'react';

import {
    StyleSheet,
    Text,
    View,
    Image, ListView,
    TouchableOpacity,
    TextInput,
    Alert,
    ScrollView,
    Linking,
    StatusBar
} from 'react-native';

import NavigationExperimental from 'react-native-deprecated-custom-components';

import Icon from 'react-native-vector-icons/FontAwesome';
import gui from '../../lib/gui';
import { Actions } from 'react-native-router-flux';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Map } from 'immutable';
const Permissions = require('react-native-permissions');

import * as globalActions from '../../reducers/global/globalActions';
import * as chatActions from '../../reducers/chat/chatActions';

import GiftedGroup from './GiftedGroup';

import log from '../../lib/logUtil';
import danhMuc from '../../assets/DanhMuc';
import FullLine from '../line/FullLine';
import { MenuContext } from '../../components/menu';

import ImagePreviewChat from '../ImagePreviewChat';

import ScalableText from 'react-native-text';

import MapView from 'react-native-maps';

import LocationMarker from '../marker/LocationMarker';

import utils from '../../lib/utils';

import Camera from 'react-native-camera';

import InCallManager from 'react-native-incall-manager';

var Analytics = require('react-native-firebase-analytics');

let STATUS_BAR_HEIGHT = NavigationExperimental.Navigator.NavigationBar.Styles.General.StatusBarHeight;
const TAB_HEADER = 56;
const TAB_INPUT_CHAT = 68;

const { width, height } = utils.getDimensions();
let mapWidth = 2 * width / 3;
let mapHeight = 2 * width / 3;
let defaultCover = require('../../assets/image/no_cover.jpg');

const actions = [
    globalActions,
    chatActions,
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class GroupChatContent extends React.Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');
        log.info("ChatContent.constructor");

        this.state = {
            imageUri: '',
            modal: false,
            currentLocation: {}
        };
    }

    updateCurrentLocation() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                //var geoUrl = 'http://maps.apple.com/?saddr='+position.coords.latitude+','+position.coords.longitude+'&daddr='+ads.place.geo.lat+','+ads.place.geo.lon+'&dirflg=d&t=s';
                this.setState({
                    currentLocation: {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    }
                });
            },
            (error) => {
                Alert.alert("Thông báo", gui.ERR_LocationNotOn);
            },
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    }

    componentWillMount() {
        this.updateCurrentLocation();
    }

    coming() {
        Alert.alert("Coming soon...");
    }

    handleSend(message = {}) {

        let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;

        const userID = this.props.global.currentUser.userID;
        const chatID = "ChatMsg_" + userID + "_" + new Date().getTime();

        let myMsg = {
            _id: chatID,
            id: chatID,
            fromUserID: userID,
            fromUserAvatar: this.props.global.currentUser.thumbnail,
            fromUserEmail: this.props.global.currentUser.email,
            fromUserPhone: this.props.global.currentUser.phone,
            fromFullName: this.props.global.currentUser.fullName,
            toChatGroupID: this.props.chat.chatGroupID,
            toChatGroupType: this.props.chat.chatGroupType,
            toChatGroupName: this.props.chat.chatGroupName,
            toChatGroupImage: this.props.chat.chatGroupImage,
            partners: this.props.chat.partners,
            avatar: this.props.global.currentUser.thumbnail,
            content: message.text,
            msgType: message.type || danhMuc.CHAT_MESSAGE_TYPE.TEXT,
            timestamp: new Date().getTime(),
            // read: false,
            // metaInfo: {
            //     isFirstMessage: (msgCount<=0) ? true : undefined,
            //     toUserActive: this.props.chat.partner.active
            // },            
            type: 'ChatMsg'
        };

        // this.props.actions.sendGroupChatMsg(myMsg);        
        // console.log('handleSend ************** ', this.props.chat.kicked);
        if (!this.props.chat.kicked)
            this.props.actions.sendGroupChatMsg(myMsg);
        else {
            Alert.alert('Thông báo', 'Bạn không thể tiếp tục chat trong nhóm này', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }
    }

    handleSendLocation(message = {}) {
        let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;
        const userID = this.props.global.currentUser.userID;
        const chatID = "ChatMsg_" + userID + "_" + new Date().getTime();
        // console.log('handleSendLocation ===>>>>> message: ', message)
        let myMsg = {
            _id: chatID,
            id: chatID,
            fromUserID: userID,
            fromUserAvatar: this.props.global.currentUser.thumbnail,
            fromUserEmail: this.props.global.currentUser.email,
            fromUserPhone: this.props.global.currentUser.phone,
            fromFullName: this.props.global.currentUser.fullName,
            toChatGroupID: this.props.chat.chatGroupID,
            toChatGroupType: this.props.chat.chatGroupType,
            toChatGroupName: this.props.chat.chatGroupName,
            toChatGroupImage: this.props.chat.chatGroupImage,
            partners: this.props.chat.partners,
            avatar: this.props.global.currentUser.thumbnail,
            content: message.location,
            msgType: message.type || danhMuc.CHAT_MESSAGE_TYPE.LOCATION,
            timestamp: new Date().getTime(),
            type: 'ChatMsg'
        };

        // this.props.actions.sendGroupChatMsg(myMsg);
        if (!this.props.chat.kicked)
            this.props.actions.sendGroupChatMsg(myMsg);
        else {
            Alert.alert('Thông báo', 'Bạn không thể tiếp tục chat trong nhóm này', [{ text: 'Đóng', onPress: () => { } }]);
            return;
        }
    }

    handleSendVideoInvitation() {
        let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;
        const userID = this.props.global.currentUser.userID;
        const chatID = "Chat_" + userID + "_" + new Date().getTime();

        let myMsg = {
            _id: chatID,
            chatID: chatID,
            id: chatID,
            fromUserID: userID,
            fromUserAvatar: this.props.global.currentUser.avatar,
            fromFullName: this.props.global.currentUser.fullName,
            toUserID: this.props.chat.partner.userID,
            toFullName: this.props.chat.partner.fullName,
            relatedToAds: this.props.chat.ads,
            avatar: this.props.global.currentUser.avatar,
            content: 'Cuộc gọi hình',
            msgType: danhMuc.CHAT_MESSAGE_TYPE.VIDEO_CALL,
            read: false,
            metaInfo: {
                isFirstMessage: (msgCount <= 0) ? true : undefined,
                toUserActive: this.props.chat.partner.active
            },
            date: new Date(),
            type: 'Chat'
        };

        this.props.actions.sendVideoInvitation(myMsg);
    }

    handleSendVideoCallCancel() {
        let msgCount = this.props.chat.messages ? this.props.chat.messages.length : 0;
        const userID = this.props.global.currentUser.userID;
        const chatID = "Chat_" + userID + "_" + new Date().getTime();

        let myMsg = {
            _id: chatID,
            chatID: chatID,
            id: chatID,
            fromUserID: userID,
            fromUserAvatar: this.props.global.currentUser.avatar,
            fromFullName: this.props.global.currentUser.fullName,
            toUserID: this.props.chat.partner.userID,
            toFullName: this.props.chat.partner.fullName,
            relatedToAds: this.props.chat.ads,
            avatar: this.props.global.currentUser.avatar,
            content: 'Cuộc gọi hình',
            msgType: danhMuc.CHAT_MESSAGE_TYPE.VIDEO_CALL,
            read: false,
            metaInfo: {
                isFirstMessage: (msgCount <= 0) ? true : undefined,
                toUserActive: this.props.chat.partner.active
            },
            date: new Date(),
            type: 'Chat'
        };

        this.props.actions.sendVideoCallCancel(myMsg);
    }

    onErrorButtonPress() {
        this.coming();
    }

    onLoadEarlierMessages() {
        this.coming();
    }

    onImagePress(data) {        
        this.doImagePress(data.image.uri);
    }

    handlePhonePress() {
        this.coming();
    }

    handleUrlPress() {
        this.coming();
    }

    handleEmailPress() {
        this.coming();
    }

    doImagePress(uri) {
        if (this.state.modal) {
            return;
        }
        this.setState({
            imageUri: uri,
            modal: true
        });
    }

    renderCustomText(rowData) {
        if (rowData.msgType == 2) {
            // console.log('renderCustomText rowData *****************', rowData)
            return (
                <TouchableOpacity
                    onPress={this.doImagePress.bind(this, rowData.fullImage || rowData.text)}>
                    <Image resizeMode={"cover"}
                        source={{ uri: rowData.text }}
                        style={styles.image} />
                </TouchableOpacity>
            )
        } else if (rowData.msgType == 3) {
            let region = { latitude: rowData.content.lat, longitude: rowData.content.lon, latitudeDelta: 0.021, longitudeDelta: 0.0144 };
            return (
                <MapView
                    style={styles.image}
                    scrollEnabled={false}
                    zoomEnabled={false}
                    pitchEnabled={false}
                    rotateEnabled={false}
                    initialRegion={region}
                    onPress={() => this._onDanDuongPressed(rowData)}>
                    <MapView.Marker coordinate={region} pointerEvents="none">
                        <LocationMarker />
                    </MapView.Marker>
                </MapView>
            )
        } else {
            let d = new Date(rowData.date);
            let msg = rowData.text;
            let color = (rowData.position === 'left') ? gui.mainTextColor : '#fff';
            return (
                <View style={{
                    flexDirection: 'row', flexWrap: 'wrap', flex: 1, padding: 9, borderRadius: 4,
                }}>
                    {this._urlify(msg, color)}
                </View>
            )
        }
    }

    _urlify(text, color) {
        if (!text) {
            return text;
        }

        let lines = text.split('\n');

        let items = [];
        let index = 0;
        lines.forEach((line, index1) => {
            let words = line.split(' ');
            
            // if (index1 >0)                        
            //     items.push(
            //         <Text key={index++} style={{flex: 1}}>{'\n'}</Text>
            //     );

            words.forEach((word) => {
                if (index > 0) {
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontFamily: gui.fontFamily, color: color }}>{' '}</Text>
                    );
                }
                if (word && word.match(/(https?:\/\/[^\s]+)/g)) {
                    items.push(
                        <TouchableOpacity key={index++} onPress={() => this._onOpenURL(word)}>
                            <Text style={{ flexWrap: 'wrap', textDecorationLine: 'underline', fontFamily: gui.fontFamily, fontSize: 15, color: color }}>{word}</Text>
                        </TouchableOpacity>
                    );
                } else {
                    items.push(
                        <Text key={index++} style={{ flexWrap: 'wrap', fontFamily: gui.fontFamily, fontSize: 15, color: color }}>{word}</Text>
                    );
                }
            })

        });

        return items;
    }

    _onOpenURL(geoUrl) {
        Linking.canOpenURL(geoUrl).then(supported => {
            if (supported) {
                Linking.openURL(geoUrl);
            } else {
                log.info('Don\'t know how to open URI: ' + geoUrl);
            }
        });
    }

    _onDanDuongPressed(rowData) {
        let destLat = rowData.content.lat;
        let destLon = rowData.content.lon;

        var geoUrl = 'http://maps.apple.com/?saddr=' + this.state.currentLocation.latitude + ',' + this.state.currentLocation.longitude + '&daddr=' + destLat + ',' + destLon + '&dirflg=d&t=s';

        this._onOpenURL(geoUrl);
    }

    render() {
        let maxHeight = utils.getDimensions().height
            - TAB_HEADER
            - TAB_INPUT_CHAT;

        let imageDataItems = [];
        imageDataItems.push(this.state.imageUri);

        return (
            <MenuContext style={{ flex: 1 }}>
                <View style={styles.wrapper}>
                    <GiftedGroup
                        ref={(c) => this._GiftedMessenger = c}

                        //renderTextInput = {this.renderTextInput.bind(this)}

                        autoFocus={false}
                        location={this.state.currentLocation}
                        messages={this.props.chat.messages}
                        handleSend={this.handleSend.bind(this)}
                        handleSendLocation={this.handleSendLocation.bind(this)}
                        handleSendVideoInvitation={this.handleSendVideoInvitation.bind(this)}
                        showVideoCall={false}
                        onLiveStream={this.onLiveStream.bind(this, false)}
                        onErrorButtonPress={this.onErrorButtonPress.bind(this)}
                        maxHeight={maxHeight}

                        loadEarlierMessagesButton={!this.props.chat.allLoaded}
                        onLoadEarlierMessages={this.onLoadEarlierMessages.bind(this)}

                        senderName='Awesome Developer'
                        senderImage={null}
                        onImagePress={this.onImagePress.bind(this)}
                        displayNames={true}

                        forceRenderImage={true}

                        parseText={true} // enable handlePhonePress, handleUrlPress and handleEmailPress
                        handlePhonePress={this.handlePhonePress}
                        handleUrlPress={this.handleUrlPress.bind(this)}
                        handleEmailPress={this.handleEmailPress}

                        isLoadingEarlierMessages={this.props.chat.isLoadingEarlierMessages}

                        typingMessage={this.props.chat.typingMessage}

                        renderCustomText={this.renderCustomText.bind(this)}
                    />
                    {this.state.modal ? <ImagePreviewChat images={imageDataItems} owner={'chat'} closeModal={() => this.setState({ modal: false })} /> : null}
                </View>
            </MenuContext>
        );
    }

    onLiveStream(ignoreSendVideoInvitation) {
        console.log("InCallManager.onLiveStream()");
        // InCallManager.start({media: 'audio'});
        // InCallManager.stop();
        //
        if (this.props.global.loggedIn) {
            this._preLiveStream(ignoreSendVideoInvitation);
        } else {
            Actions.NewLogin({ doFinalAction: this._preLiveStream.bind(this, ignoreSendVideoInvitation) });
        }
    }

    _preLiveStream(ignoreSendVideoInvitation) {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {
                if (e) {
                    Permissions.requestPermission('photo')
                        .then(response => {
                            if (response == 'authorized') {
                                this._doLiveStream(ignoreSendVideoInvitation);
                            } else {
                                Alert.alert("Thông báo", gui.INF_PhotoAccess);
                            }
                        });
                } else {
                    Alert.alert("Thông báo", gui.INF_CameraAccess);
                }
            });
    }

    _doLiveStream(ignoreSendVideoInvitation) {
        !ignoreSendVideoInvitation && this.handleSendVideoInvitation();
        this.props.actions.onChatFieldChange('inVideoCall', true);
        let fromUserID = this.props.global.currentUser.userID;
        let toUserID = this.props.chat.partner.userID;
        let ads = this.props.chat.ads;
        let adsID = ads.adsID || ads.id;
        let dangBoiUserID = ads.dangBoi.userID;
        let roomName = fromUserID == dangBoiUserID ? 'Room_' + fromUserID + '_' + toUserID + '_' + adsID :
            'Room_' + toUserID + '_' + fromUserID + '_' + adsID;
        let fullName = this.props.global.currentUser.fullName;
        let username = this.props.global.currentUser.username;
        Actions.LiveStream({ username: fullName || username, roomName: roomName, doFinalAction: this._onCallHangup.bind(this) });

        Analytics.logEvent('VIDEO_CALL', { fromUserID: fromUserID, toUserID: toUserID, adsID: adsID });
    }

    _onCallHangup() {
        let msg = this.props.chat.incoming.msg;
        if (msg) {
            let fromUserID = msg.fromUserID;
            let ads = msg.relatedToAds;
            let adsID = ads.adsID || ads.id;
            let partnerUserID = this.props.chat.partner.userID;
            let currentAds = this.props.chat.ads;
            let currentAdsID = currentAds.adsID || currentAds.id;
            if (fromUserID == partnerUserID && adsID == currentAdsID) {
                this.props.actions.onChatFieldChange('incoming', { ...this.props.chat.incoming, calling: false });
            }
        }
        this.props.actions.onChatFieldChange('inVideoCall', false);
        this.handleSendVideoCallCancel();
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(GroupChatContent);


const styles = StyleSheet.create({
    wrapper: {
        flexDirection: 'column',
        flex: 1
    },
    text: {
        flex: 1,
        alignSelf: 'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: 'normal',
        top: 9,
    },
    name: {
        fontSize: 12,
        color: 'gray',
        flex: 1,
    },
    dateTime: {
        fontSize: 12,
        color: 'gray',
        fontFamily: gui.fontFamily,
        marginRight: 18
    },
    title: {
        fontSize: 13,
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    content: {
        fontSize: 13,
        textAlign: 'left',
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    },
    image: {
        borderRadius: 4,
        height: 240
    }
});