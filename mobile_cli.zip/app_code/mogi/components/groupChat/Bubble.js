import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import gui from '../../lib/gui';

import ParsedText from 'react-native-parsed-text';

import PropTypes from 'prop-types';
import utils from '../../lib/utils';
var { width, height } = utils.getDimensions();

const styles = StyleSheet.create({
  bubble: {
    borderRadius: 4,
    padding: 0,
    overflow: 'hidden',    
    // flexWrap: 'wrap',
    // flexDirection: 'row',
    // width: width/2,
    // backgroundColor:'red'
  },
  textChat: {
      color: '#000'
  },
  textLeft: {
    color: gui.mainTextColor,
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15
  },
  textRight: {
    color: '#fff',
    fontFamily: gui.fontFamily,
    fontWeight: 'normal',
    fontSize: 15,
  },
  textCenter: {
    textAlign: 'center',
  },
  bubbleLeft: {
    marginRight: 70,
    backgroundColor: 'rgba(82,97,115,0.1)',
    alignSelf: 'flex-start',
    borderRadius: 4,
  },
  bubbleRight: {
    marginLeft: 70,
    backgroundColor: gui.mainAgentColor,
    alignSelf: 'flex-end',
    borderRadius: 4,
  },
  bubbleCenter: {
    backgroundColor: '#007aff',
    alignSelf: 'center',
    borderRadius: 4,
  },
  bubbleError: {
    backgroundColor: '#e01717',
  },
});

export default class Bubble extends React.Component {

  componentWillMount() {
    Object.assign(styles, this.props.styles);
  }

  renderText(text = '', position) {
    if (this.props.renderCustomText && this.props.renderCustomText(this.props) !==false) {
      return this.props.renderCustomText(this.props);
    }

    if (this.props.parseText === true) {
      return (
          <ParsedText
              style={[styles.textChat, (position === 'left' ? styles.textLeft : position === 'right' ? styles.textRight : styles.textCenter)]}
              parse={
            [
              {
                type: 'url',
                style: {
                  textDecorationLine: 'underline',
                },
                onPress: this.props.handleUrlPress,
              },
              {
                type: 'phone',
                style: {
                  textDecorationLine: 'underline',
                },
                onPress: this.props.handlePhonePress,
              },
              {
                type: 'email',
                style: {
                  textDecorationLine: 'underline',
                },
                onPress: this.props.handleEmailPress,
              },
            ]
          }
          >
            {text}
          </ParsedText>
      );
    }

    return (
        <Text style={[styles.textChat, (position === 'left' ? styles.textLeft : position === 'right' ? styles.textRight : styles.textCenter)]}>
          {text}
        </Text>
    );
  }

  render() {
    const flexStyle = {};
    const realLength = function(str) {
      return str.replace(/[^\x00-\xff]/g, "**").length; // [^\x00-\xff] - Matching non double byte character
    };
    if (this.props.text) {
      if (realLength(this.props.text) > 40) {
        flexStyle.flex = 1;
      }
    }

    return (
        <View 
        style={[styles.bubble,
        (this.props.position === 'left' ? styles.bubbleLeft : this.props.position === 'right' ? styles.bubbleRight : styles.bubbleCenter),
        (this.props.status === 'ErrorButton' ? styles.bubbleError : null),
        flexStyle]}
        >
          {this.props.name}
          {this.renderText(this.props.text, this.props.position)}
        </View>
    );
  }
}

Bubble.propTypes = {
  position: PropTypes.oneOf(['left', 'right', 'center']),
  status: PropTypes.string,
  text: PropTypes.string,
  renderCustomText: PropTypes.func,
  styles: PropTypes.object,
  parseText: PropTypes.bool,
  name: PropTypes.element,
  handleUrlPress: PropTypes.func,
  handlePhonePress: PropTypes.func,
  handleEmailPress: PropTypes.func,
};
