import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../lib/gui';
import ScalableText from 'react-native-text';
import utils from '../lib/utils';

const {width}= utils.getDimensions();

export default class MLikeTapButton2 extends Component {
    render() {
        let selected = this.props.selected;
        let myStyle = selected? 'buttonTextSelected' : 'buttonText';
        
        let mainViewStyle = selected ? 'mainViewSelected' : 'mainView';

        if (this.props.line2) 
            return (                        
                    <TouchableOpacity
                        onPress={() => this.props.onPress(this.props.name)}>
                        <View style={[ styles[mainViewStyle], this.props.mainProps]}>

                            <ScalableText style={styles[myStyle]} >
                                {this.props.line1}
                            </ScalableText>
                            <ScalableText style={[styles[myStyle], {fontSize:12, fontWeight : 'normal'}]} >
                                {this.props.line2}
                            </ScalableText>

                        </View>
                    </TouchableOpacity>
            )
        else
            return (                        
                <TouchableOpacity
                    onPress={() => this.props.onPress(this.props.name)}>
                    <View style={[ styles[mainViewStyle], this.props.mainProps]}>

                        <ScalableText style={styles[myStyle]} >
                            {this.props.line1}
                        </ScalableText>
                        </View>
                </TouchableOpacity>
            );
    }
}

const styles = StyleSheet.create({
    mainView: {
        flexGrow: 1,
        flexDirection: 'column',           
        //borderWidth: 1,
        // borderRadius: 5,
        //margin: 10,
        // width: width/2 - 25,     
        borderColor: '#1A526173'
    },
    mainViewSelected: {
        flexGrow: 1,
        flexDirection: 'column',        
        borderWidth: 1,
        // borderRadius: 5,
        //margin: 10,
        // width: width/2 - 25,
        borderColor: gui.mainColor,
    },
    wrapper: {
        //backgroundColor: 'red',
        
    },
    wrapperSelected: {
        
    },
    buttonText: {
        //flexGrow: 1,
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        //padding: 5,
        color: '#526173',
        fontWeight : '500'
    },
    buttonTextSelected: {
        //flexGrow: 1,
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        //padding: 5,
        color: gui.mainColor,
        fontWeight : '500'
    }
});