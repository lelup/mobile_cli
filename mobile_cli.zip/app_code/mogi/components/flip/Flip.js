import React, {Component} from 'react';
import {
    View,
    StyleSheet,
    Text,
    Animated
} from 'react-native'

import utils from '../../lib/utils';
const {height, width} = utils.getDimensions();

class Flip extends Component {
    constructor(props){
        super(props);

        this.state = {
            theta: new Animated.Value(0),
            count: 0,
            animating: false
        }
    }

    componentDidMount() {

    }

    _animate() {
        const tmp = this.state.count + 1;
        this.setState({animating: true});
        Animated.timing(this.state.theta, {
            toValue: 180*tmp,
            duration: 2000,
        }).start();
        function count(){
            const tmp = this.state.count + 1;
            this.setState({count: tmp,animating: false})
        }
        setTimeout(count.bind(this),1000)
    }

    render() {
        const { count,animating } = this.state;
        const { Front, Back } = this.props;
        const awrapper = (
            <Animated.View style={[
                styles.flipCard,
                {position: 'absolute',
                    top: 0,
                    transform: [
                        {perspective: 1000},
                        {rotateY: this.state.theta.interpolate({
                            inputRange: [0, 180],
                            outputRange: ['0deg', '180deg']
                        })},
                    ]}]}>
                <Front switch={()=>{this._animate()}} />
            </Animated.View>
        );
        const bwrapper = (
            <Animated.View style={[styles.flipCard, {
                position: 'absolute',
                top: 0,
                transform: [
                    {perspective: 1000},
                    {rotateY: this.state.theta.interpolate({
                        inputRange: [0, 180],
                        outputRange: ['180deg', '360deg']
                    })},
                ]}]}>
                <Back switch={()=>{
                    this._animate()
                }} />
            </Animated.View>
        );
        let content = null;
        if (animating) {
            content = (
                <View>
                    {awrapper}
                    {bwrapper}
                </View>
            )
        }else{
            content = (
                <View>
                    {count%2==0 ? awrapper : bwrapper}
                </View>
            )
        }
        return (
            <View style={styles.flipCardContainer}>
                {content}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    flipCardContainer: {
        width: width,
        height: height,
        backgroundColor: '#000'
    },
    flipCard: {
        width: width,
        height: height,
        backgroundColor: '#fff',
        backfaceVisibility: 'hidden',
    }
});

export default Flip;