// Import some code we need
import React, { Component } from 'react';
import {View, Text, StyleSheet, AlertIOS, Alert} from 'react-native';
import {Actions} from 'react-native-router-flux';
import SortMenu from './../SortMenu';
import gui from '../../lib/gui';
import Button from 'react-native-button';
import FullLine from '../line/FullLine';
import utils from '../../lib/utils';
import DanhMuc from '../../assets/DanhMuc';
import Icon from 'react-native-vector-icons/FontAwesome';

var Analytics = require('react-native-firebase-analytics');

let { width, height} = utils.getDimensions();

import Modal from 'react-native-modalbox';
// Create our component
class SearchResultFooterFlip extends Component {
    constructor(props) {
        super(props);
    }
    render () {
        let searchAdsDisabled = this.props.isSearchDuAn && this.props.isSearchDuAn();
        let btnColor = searchAdsDisabled ? '#C5C2BA' : gui.mainColor;
        let orderByKey = this.props.orderBy || '';
        let textSort = DanhMuc.searchOrderSort[orderByKey];
        let iconName = this._getIconValue(orderByKey);
        let sortValue = iconName == 'sort';
        return (
            <View style={myStyles.viewButtomList}>
                <View style={myStyles.searchListButton}>
                    {/*<SortMenu isDiaDiem={this.props.center} scrollToTop={this.props.scrollToTop}/>*/}
                    <Button onPress={this._onPressModal.bind(this)}
                            disabled={searchAdsDisabled}
                            style={[myStyles.buttonText, {color: btnColor}]}>
                        <View style={{flexDirection: 'row', width: width/3 -1, justifyContent: 'center', alignItems: 'center', paddingTop: 8}}>
                            <Text style={myStyles.sortText}>{textSort}</Text>
                            {!sortValue ? (<Icon name={iconName} size={15} color={gui.mainColor} style={{marginLeft: 4, marginRight: 5}} />) : null}
                            <Icon name={'sort'} size={15} color={gui.mainColor} style={{marginLeft: 9}} />
                        </View>
                    </Button>
                    <View style={myStyles.viewLine}></View>
                    <Button onPress={this._onAlertSaveSearch.bind(this)}
                            disabled={searchAdsDisabled}
                            style={[myStyles.buttonText, {fontWeight : '500', color: btnColor}]}>Lưu tìm kiếm</Button>
                    <View style={myStyles.viewLine}></View>
                    <Button onPress={this._onMap.bind(this)}
                            style={myStyles.buttonText}>Bản đồ</Button>
                </View>
                <FullLine/>
            </View>
        );
    }

    _getIconValue(value) {
        let iconName = 'sort';
        let upValues = ['giaASC', 'giaM2ASC', 'dienTichASC'];
        let downValues = ['giaDESC', 'giaM2DESC', 'dienTichDESC'];
        if (upValues.includes(value)) {
            iconName = 'long-arrow-up';
        } else if (downValues.includes(value)) {
            iconName = 'long-arrow-down';
        }
        return iconName;

    }
    _onSort() {
        Actions.OrderPicker();
    }

    _onPressModal() {
        this.props.onOpenModal();
    }
    _onAlertSaveSearch() {
        if (!this.props.loggedIn) {
            Actions.Login();
        } else {
            var name = this.props.placeName;
            AlertIOS.prompt('Tên tìm kiếm cần lưu', 'Ví dụ: Gần chỗ làm, gần bệnh viện...',
                [{
                    text: 'Lưu lại',
                    onPress: this._onSaveSearch.bind(this)
                }, {
                    text: 'Hủy',
                    style: 'cancel'
                }], 'plain-text', name);
        }
    }
    _onSaveSearch(name) {
        if (!name) {
            Alert.alert('Thông báo', 'Bạn chưa nhập tên tìm kiếm cần lưu.',
                [ { text: 'Đóng', onPress: this._onAlertSaveSearch.bind(this) } ]) ;
            return;
        }
        let saveSearch = {
            name : name,
            query : this.props.query,
            timeModified : new Date().getTime()
        };
        this.props.saveSearch(this.props.userID, saveSearch, this.props.token);
        Analytics.logEvent('LIST_SAVEDSEARCH', {deviceID: this.props.deviceID, userID: this.props.userID, name: name});
    }
    _onMap() {
        this.props.onSearchViewChange("searchView","map");
        //Actions.SearchResultMap({type: "reset", viewport: this.props.viewport});
        this.props.onSwitch();
    }
};
// Later on in your styles..
const myStyles = StyleSheet.create({
    searchListButton: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        backgroundColor: 'white',
        height: 38,
        //alignItems: 'center'
    },
    buttonText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        color: gui.mainColor,
        textAlign: 'center',
        marginTop: 8,
        paddingLeft: 0,
        width: width/3 -1
    },
    sortText: {
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal',
        color: gui.mainColor,
        textAlign: 'center'
    },
    viewLine: {
        //borderWidth: 0.5,
        height: 25,
        width: 1,
        //borderColor: "#dcdcdc",
        borderRightWidth: 0.5,
        //height:1,
        borderColor: "lightgray",
        marginTop: 7
    },
    viewModalStyle : {
        position:'absolute',
        backgroundColor: 'white',
        width: width/2,
        height: height/3
    },
    viewDetailModal: {
        backgroundColor:gui.mainColor,
        flex:1,
        alignItems:'center',
        justifyContent: 'center'
    },
    viewButtomList:{
        height: 39,
        width: width,
        flexDirection: 'column'
    }
});
// Make this code available elsewhere
export default SearchResultFooterFlip;