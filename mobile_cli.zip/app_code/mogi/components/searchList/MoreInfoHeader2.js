import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import TruliaIcon from './../TruliaIcon';

import {Actions} from 'react-native-router-flux';

import gui from '../../lib/gui';

class MoreInfoHeader2 extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <View style={mStyles.container}>
                <View style={mStyles.homeIcon}>
                    <TruliaIcon onPress={this._onHome}
                                name="arrow-left" color={"white"}
                                mainProps={{paddingLeft: 20, paddingRight: 17}} size={26}/>
                </View>
                <View style={mStyles.home}>
                    <Text style={mStyles.title1Text}>{this.props.title1}</Text>
                    {/*<Text style={mStyles.title2Text}>{this.props.title2}</Text>*/}
                </View>
                <View style={mStyles.homeIcon}>
                </View>
            </View>
        )
    }

    _onHome() {
        Actions.pop();
    }
}

export default  MoreInfoHeader2;

const mStyles = StyleSheet.create({
    container: {
        top: 0,
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        flexGrow: 1
    },
    home: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        flexGrow: 1
    },
    homeIcon: {
        paddingTop: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 52
    },
    text: {
        flexDirection: 'column',
        backgroundColor: 'white',
        position: 'absolute',
    },
    title1Text: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight: '600',
        textAlign: 'center',
        color: 'white'
    },
    title2Text: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        textAlign: 'center',
        color: 'white'
    }
});
