'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../reducers/global/globalActions';
import * as searchActions from '../reducers/search/searchActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import {View, SegmentedControlIOS, Text, StyleSheet, TouchableOpacity} from 'react-native'

import {Actions} from 'react-native-router-flux';
import TruliaIcon from './TruliaIcon';
import CommonHeader from '../components/CommonHeader';
import DanhMuc from '../assets/DanhMuc';

import MultipleChoice from './MultipleChoice';

import gui from '../lib/gui';

const actions = [
    globalActions,
    searchActions
];

function mapStateToProps(state) {
    return {
        ...state,
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var huongNhaValues = DanhMuc.getHuongNhaValues();

class HuongNha extends Component {
    constructor(props) {
        super();
        var huongNha = [];
        props.huongNha && props.huongNha.map((one) => {
            huongNha.push(this.getValueByKey(huongNhaValues, one));
        });
        if (!huongNha) {
            huongNha = [huongNhaValues[0]];
        }
        this.state = {
            huongNha: huongNha
        };
    }

    render() {
        return (
            <View style={myStyles.fullWidthContainer}>
                <View style={myStyles.search}>
                    <View style={myStyles.customPageHeader}>
                        <TruliaIcon onPress={this._onBack.bind(this)}
                                    name="arrow-left" color={'white'} size={26}
                                    mainProps={myStyles.backButton}
                                    >
                        </TruliaIcon>
                        <View style={myStyles.customPageTitle}>
                            <Text style={myStyles.customPageTitleText}>
                                Hướng nhà
                            </Text>
                        </View>
                        <TouchableOpacity style={myStyles.viewHuy}
                                          onPress={this._onDone.bind(this)}
                        >
                            <Text style={[myStyles.customPageTitleText, {fontSize: 15, fontWeight: '400', marginTop: 2}]}>
                                Chọn
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <MultipleChoice
                    options={huongNhaValues}
                    style={myStyles.choiceList}
                    selectedOptions={this.state.huongNha}
                    maxSelectedOptions={huongNhaValues.length}//{this.props.search.form.fields.loaiTin=='ban' ? nhaDatBan.length : nhaDatChoThue.length}
                    onSelection={(option)=>this._onApply(option)}
                />

            </View>
        );
    }

    _onDone() {
        let huongNhaKeys = [];
        this.state.huongNha.map((one) => {
            huongNhaKeys.push(this.getKeyByValue(huongNhaValues, one));
        });
        this.props.onHuongNhaChange(huongNhaKeys);
        Actions.pop();
    }

    _onBack() {
        Actions.pop();
    }

    _onApply(option) {
        if (option == huongNhaValues[0]) {
            this.setState({huongNha: [huongNhaValues[0]]});
            return;
        }
        if (option == huongNhaValues[1]) {
            this.setState({huongNha: [huongNhaValues[1]]});
            return;
        }
        let newHuongNha = this.state.huongNha.filter((one) => {
                return one != huongNhaValues[0] && one != huongNhaValues[1]
            }) || [];
        this.setState({huongNha: newHuongNha});
    }

    getValueByKey(values, key) {
        var value = '';
        for (var i = 0; i < DanhMuc.HuongNhaKey.length; i++) {
            var loaiKey = DanhMuc.HuongNhaKey[i];
            if (key === loaiKey) {
                value = values[i];
                break;
            }
        }
        //console.log(value);
        return value;
    }

    getKeyByValue(values, value) {
        var key = '';
        for (var i = 0; i < values.length; i++) {
            var oneValue = values[i];
            if (value === oneValue) {
                key = DanhMuc.HuongNhaKey[i];
                break;
            }
        }
        //console.log(key);
        return key;
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(HuongNha);



// Later on in your styles..
var myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    choiceList: {
        paddingTop: 10,
        paddingLeft: 26,
        paddingRight: 0
    },
    searchButton: {
        alignItems: 'stretch',
        justifyContent: 'flex-end'
    },
    searchButtonWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 44
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    headerSeparator: {
        marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    search: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: gui.mainColor,
        height: 60
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    customPageTitle: {
        left:36,
        right:36,
        marginTop: 31,
        marginBottom: 10,
        position: 'absolute'
    },
    customPageTitleText: {
        color: 'white',
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    viewHuy:{
        position: 'absolute',
        right: 0,
        width: 60,
        backgroundColor: 'transparent',
        alignItems: 'center',
        marginTop: 31
    },
});

