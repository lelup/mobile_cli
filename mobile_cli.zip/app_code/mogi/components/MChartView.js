import React, {Component} from 'react';

import gui from '../lib/gui';

// import {Pie} from 'react-native-pathjs-charts';

import PieChart from 'react-native-pie-chart';
import ScalableText from 'react-native-text';

var {
    StyleSheet,
    View,
    Text
} = require('react-native');

class MChartView extends React.Component{
    constructor(props){
        super(props);
    }

    render() {
        const {mainProps, data, options, pallete, chartTitle, chartTitleBold} = this.props;
        const titleWidth = options.width - 2*(options.R - options.r) - 20;
        const chart_wh = options.width;
        const coverRadius = options.r/options.R;
        const series = [];
        const sliceColor = [];
        const chartStyle = {marginTop: options.margin.top,
                            marginBottom: options.margin.bottom,
                            marginLeft: options.margin.left,
                            marginRight: options.margin.right};
        let sum = 0, min = 0;
        data.map(function (one) {
            sum += one.value;
        });
        if (sum == 0) {
            sum = 1;
        }
        min = sum/360;
        data.map(function (one) {
            series.push(one.value >= min ? one.value : min);
        });
        pallete.map(function (one) {
            sliceColor.push('rgb(' + one.r + ',' + one.g + ',' + one.b + ')');
        });
        if (data.length == 1) {
            series.push(min);
            let one = pallete[0];
            sliceColor.push('rgb(' + one.r + ',' + one.g + ',' + one.b + ')');
        }
        return (
            <View style={mainProps||styles.chartContent}>
                <PieChart
                    chart_wh={chart_wh}
                    series={series}
                    sliceColor={sliceColor}
                    doughnut={true}
                    coverRadius={coverRadius}
                    coverFill={'#FFF'}
                    style={chartStyle}
                />
                {/*<Pie
                    data={data}
                    options={options}
                    pallete={pallete}
                    accessorKey="value" />*/}
                <View style={styles.labelContent}>
                    {this._renderSummaryLabel(chartTitle, chartTitleBold, titleWidth)}
                </View>
            </View>
        );
    }

    _renderSummaryLabel(chartTitle, chartTitleBold, titleWidth) {
        return (
            <View style={{flexDirection:'column', width: titleWidth}}>
                <ScalableText style={[styles.titleBold, {color: this.props.chartBold}]}>
                    {chartTitleBold}
                </ScalableText>
                <ScalableText style={[styles.title, {color: this.props.chartText}]}>
                    {chartTitle}
                </ScalableText>
            </View>
        )
    }

}

var styles = StyleSheet.create({
    chartContent: {
    },
    labelContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center'
    },
    title: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#9C9C9C',
        backgroundColor: 'transparent',
        textAlign: 'center'
    },
    titleBold: {
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: 'bold',
        backgroundColor: 'transparent',
        textAlign: 'center'
    }
});

module.exports = MChartView;
