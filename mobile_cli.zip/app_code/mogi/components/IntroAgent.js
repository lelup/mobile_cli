import React, { Component } from 'react';

import Swiper from 'react-native-swiper';
import log from '../lib/logUtil';
import utils from '../lib/utils';
import gui from '../lib/gui';
import LinearGradient from 'react-native-linear-gradient';
let {width, height} = utils.getDimensions();

import ScalableText from 'react-native-text';

import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    Alert
} from 'react-native';
import { Actions } from 'react-native-router-flux';
import OfflineBar from '../components/line/OfflineBar';
class IntroAgent extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        let onboarding1 = require('../assets/image/welcome/onboarding1.png');
        let onboarding2 = require('../assets/image/welcome/onboarding2.png');
        let onboarding3 = require('../assets/image/welcome/onboarding3.png');

        let title1 = 'Kết nối cung & cầu thông minh';
        let title2 = 'Cộng đồng môi giới BĐS trên\n'
            +'Landber Agent';
        let title3 = 'Quản lý KHÁCH HÀNG';

        let detail1 = 'Tự động so sánh và kết nối thông tin bất động sản với nhu '
            + 'cầu của khách hàng đã lưu trong phần quản lý khách hàng '
            + 'và nhu cầu được chia sẻ trong cộng đồng Landber Agent';
        let detail2 = 'Gắn kết môi giới toàn quốc, đẩy mạnh hợp tác\n'
            + 'gia tăng doanh số!';
        let detail3 = 'Tăng hiệu quả tư vấn và tỷ lệ chốt sale bằng\n'
            + 'cách quản lý lịch sử giao dịch và ghi chú\n'
            + 'của khách hàng một cách dễ dàng';

        let photoItems = [
            {key: 0, image: onboarding1, title: title1, detail: detail1},
            {key: 1, image: onboarding2, title: title2, detail: detail2},
            {key: 2, image: onboarding3, title: title3, detail: detail3}
        ];

        let introItems = [];
        let index = 0;
        photoItems.forEach((one) => {
            let uuid = new Date().getTime();
            let btnLabel = index == 2 ? 'Bắt đầu' : 'Bỏ qua';
            introItems.push(
                <View key={(index++) + '_' + uuid} style={styles.slide1}>
                    <Image style={styles.image}
                           source={one.image}
                           resizeMode={'cover'}
                           defaultSource={one.image}
                    >
                        {btnLabel == 'Bắt đầu' ?
                            <TouchableOpacity style={styles.viewBeginContainer} onPress={this._onHomeAgent.bind(this)}>
                                <View style={styles.viewBeginButton}>
                                    <Text style={[styles.textButton, {fontWeight: 'bold'}]}>{btnLabel}</Text>
                                </View>
                            </TouchableOpacity> :
                            <TouchableOpacity style={styles.viewIgnoreButton} onPress={this._onHomeAgent.bind(this)}>
                                <Text style={styles.textButton}>{btnLabel}</Text>
                            </TouchableOpacity>
                        }
                        <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.85)']}
                                     style={styles.linearGradient}>
                            <ScalableText style={styles.textMain}>{one.title.toUpperCase()}</ScalableText>
                            <ScalableText style={styles.textDetail1}>{one.detail}</ScalableText>
                        </LinearGradient>
                    </Image>
                    {/*<TouchableOpacity style={styles.viewButton} onPress={this._onHomeAgent.bind(this)}>
                        <Text style={styles.textButton}>{btnLabel}</Text>
                    </TouchableOpacity>*/}
                </View>
            )
        });

        // let communitySource = require('../assets/image/Community.png');
        // let chatSource = require('../assets/image/ChatGuide.png');
        // let agentGuide = require('../assets/image/LandberAgentGuide.png');
        // let mainSide1 = 'Tìm những sàn môi giới theo khu vực, dự án';
        // let mainSide2 = 'Chat - trao đổi tức thì với các thành viên trên sàn';
        // let mainSide3 = 'Tiếp cận nguồn hàng độc quyền của Landber';
        // let detailSlide1 = 'Chia sẻ thông tin, bất động sản với những thành viên trên sàn chưa bao giờ dễ dàng hơn thế.';
        // let detailSlide2 = 'Lần đầu tiên khi các nhà môi giới có thể trao đổi với nhau vô cùng tiện lợi với các công cụ đặc thù của ngành bất động sản.';
        // let detailSlide3 = 'Chúng tôi đã xây dựng một nguồn BĐS lớn có giá trị, bạn chỉ việc bán hàng và nhận tiền hoa hồng, rất đơn giản!';
        return (
            <View>
                <OfflineBar />
                <Swiper style={styles.wrapper}
                        height={height} autoplay={true} autoplayTimeout={5}
                        onMomentumScrollEnd={function(e, state, context){log.info('index:', state.index)}}
                        dot={<View style={styles.viewDot} />}
                        activeDot={<View style={styles.viewDotActive} />}
                        paginationStyle={styles.dotPosition}
                        loop={false}>
                    {introItems}
                </Swiper>
            </View>
        )
    }

    _onHomeAgent() {
        Actions.WelcomeLandber();
    }
}


const styles = StyleSheet.create({
    wrapper: {
    },
    slide: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    slide1: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    slide3: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'green',
    },
    text: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
    },
    image: {
        width: width,
        height: height,
        alignSelf: 'auto'
    },
    dotPosition: {
        position: 'absolute',
        bottom: 56,
        left: 0,
        right: 0,
    },
    viewDot: {
        backgroundColor:'transparent',
        width: 10,
        height: 10,
        borderRadius: 5,
        marginLeft: 2,
        marginRight: 2,
        marginTop: 3,
        marginBottom: 3,
        borderWidth: 1,
        borderColor: '#fff'
    },
    viewDotActive: {
        backgroundColor: '#fff',
        width: 10,
        height: 10,
        borderRadius: 5,
        marginLeft: 2,
        marginRight: 2,
        marginTop: 3,
        marginBottom: 3,
    },
    textCommon: {
        fontSize: 17,
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    viewFirstSlide: {
        height: height - 100,
        width: width,
        backgroundColor: 'yellow'
    },
    imageCommunity: {
        width: 116,
        height: 112,
        marginTop: 0.22*height
    },
    textMain: {
        marginTop: height/2-201,
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#fff',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily,
        marginHorizontal: 10
    },
    textDetail1: {
        color: '#fff',
        backgroundColor: 'transparent',
        fontSize: 14,
        fontFamily: gui.fontFamily,
        textAlign: 'center',
        marginHorizontal: 10,
        marginTop: 16
    },
    viewButton: {
        width: width - 32,
        height: 48,
        marginHorizontal: 16,
        backgroundColor: gui.mainAgentColor,
        position: 'absolute',
        justifyContent: 'center',
        alignItems: 'center',
        left: 0,
        right: 0,
        bottom: 10,
        borderRadius: 24
    },
    textButton: {
        fontSize: 15,
        color: '#fff',
        fontFamily: gui.fontFamily
    },
    linearGradient: {
        position: 'absolute',
        top: height / 2,
        left: 0,
        right: 0,
        height: height / 2,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    viewIgnoreButton: {
        backgroundColor: 'transparent',
        position: 'absolute',
        justifyContent: 'center',
        alignItems: 'flex-start',
        top: 19,
        left: 0,
        width: 120,
        height: 48,
        marginHorizontal: 16
    },
    viewBeginContainer: {
        backgroundColor: 'transparent',
        position: 'absolute',
        justifyContent: 'center',
        alignItems: 'flex-end',
        top: 19,
        right: 0,
        width: 120,
        height: 48,
        marginHorizontal: 16
    },
    viewBeginButton: {
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 5
    }

});

export default IntroAgent;
