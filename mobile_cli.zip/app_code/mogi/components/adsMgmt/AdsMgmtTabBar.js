const React = require('react');
const ReactNative = require('react-native');
const {
  StyleSheet,
  Text,
  View,
  Animated,
  // TouchableOpacity
} = ReactNative;
const Button = require('../button/Button');

import gui from '../../lib/gui';

import utils from '../../lib/utils';

var { width, height } = utils.getDimensions();

// import {Actions} from 'react-native-router-flux';
import FullLine from '../line/FullLine';

export default class AdsMgmtTabBar extends React.Component {
 
  renderTabOption(name, page) {
    const isTabActive = this.props.activeTab === page;
    const activeTextColor = this.props.activeTextColor || 'navy';
    const inactiveTextColor = this.props.inactiveTextColor || 'black';
    const textStyle = this.props.textStyle || {};

    return <Button
      key={name}
      accessible={true}
      accessibilityLabel={name}
      accessibilityTraits='button'
      onPress={() => this.props.goToPage(page)}
    >
      <View style={styles.tab}>
        <Text style={[styles.textTab, {color: isTabActive ? activeTextColor : inactiveTextColor, fontWeight: isTabActive ? 'bold' : 'normal', }, textStyle]}>
          {name}
        </Text>
      </View>
    </Button>;
  }

  render() {
    const containerWidth = this.props.containerWidth;
    const numberOfTabs = this.props.tabs.length;
    const tabUnderlineStyle = {
      position: 'absolute',
      height: 4,
      width: (width - 10)/4,
      marginLeft: 5,
      marginRight: 5,
      backgroundColor: this.props.underlineColor || gui.mainColor,
      bottom: 0,
    };

    const left = this.props.scrollValue.interpolate({
      inputRange: [0, 1, ], outputRange: [0,  containerWidth / numberOfTabs, ],
    });

    return (
      <View style={styles.outer}>
        <View style={styles.tabs}>
          {this.props.tabs.map((tab, i) => this.renderTabOption(tab, i))}
          <Animated.View
              duration={0}
              style={[tabUnderlineStyle, { left }]} />
        </View>
        <FullLine />
      </View>
    );
  }
};

const styles = StyleSheet.create({
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    //paddingBottom: 10,
    top: 0,
  },
  outer:{
    alignItems: 'stretch',
    justifyContent: 'center',
  },
  tabs: {
    height: 45,
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop:1
  },
  textTab:{
    fontSize: 15,
    textAlign:'center',
    fontFamily: gui.fontFamily,
    width: width/4,
    marginBottom:0
  }
});
