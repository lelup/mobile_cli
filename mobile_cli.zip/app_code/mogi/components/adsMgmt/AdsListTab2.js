'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import {
    Text, View, Image, ListView, StatusBar,
    RecyclerViewBackedScrollView, TouchableOpacity, Alert,
    TouchableHighlight, StyleSheet, RefreshControl, ScrollView,
    InteractionManager, ImageBackground
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import MHeartIcon from '../MHeartIcon';

import LinearGradient from 'react-native-linear-gradient';

import ScalableText from 'react-native-text';

import gui from '../../lib/gui';
import util from '../../lib/utils';

import DanhMuc from '../../assets/DanhMuc';

import GiftedSpinner from "../../components/GiftedSpinner";
import cfg from "../../cfg";

import log from '../../lib/logUtil';
import danhMuc from '../../assets/DanhMuc';
import RelandIcon from '../RelandIcon';
import FontAwesomeLight from '../font/FontAwesomeLight';
import Modal from 'react-native-modalbox';
import placeUtil from '../../lib/PlaceUtil';

import moment from 'moment';

var { width, height } = util.getDimensions();

const actions = [
    globalActions,
    adsMgmtActions,
    postAdsActions,
    needToBuyActions
];

function mapStateToProps(state) {
    return {
        //listAds: state.adsMgmt.likedList,
        loading: state.adsMgmt.loadingFromServer,
        errorMsg: state.adsMgmt.errorMsg,
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

var imgHeight = gui.ADS_IMAGE_RATIO*width;

var myDs = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

class AdsListTab2 extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        this.state = {
            scrollEnabled: true,
            isOpenModalDelFix: false,
            adsID: null
        }
    }

    componentDidMount() {
        log.info("AdsListTab - componentDidMount");
        if (this.props.name == 'likedTab') {
            this.props.actions.loadLikedList(this.props.global.currentUser.userID);
        }
        // else if (this.props.name == 'sellWToTab' || this.props.name == 'rentWToTab') {
        //     let token = this.props.global.currentUser.token;
        //     this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
        // }
        // else {
        //     this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        // }
    }

    _onRefresh() {

        if (this.props.name == 'likedTab') {
            this.props.actions.loadLikedList(this.props.global.currentUser.userID);
        }
        else if (this.props.name == 'sellWToTab' || this.props.name == 'rentWToTab') {
            let token = this.props.global.currentUser.token;
            this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
        }
        else {
            this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        }

        /*
         fetchData().then(() => {
         this.setState({refreshing: false});
         });
         */
    }

    _getListContent() {
        let myProps = this.props;

        if (myProps.errorMsg) {
            return (
                <View style={{flex:1, alignItems:'center', justifyContent:'center', marginTop: 30}}>
                    <Text style={myStyles.welcome}>{myProps.errorMsg}</Text>
                </View>
            )
        }

        if (myProps.listAds.length === 0 || myProps.listAds.size == 0) {
            return (
                <ScrollView
                    scrollEnabled={this.state.scrollEnabled}
                    refreshControl={
                        <RefreshControl
                            refreshing={this.props.adsMgmt.refreshing}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                >
                    <View style={{flex:1, alignItems:'center', justifyContent:'center'
                        , marginTop: 30}}>
                        <Text style={gui.styles.defaultText}> {gui.INF_KhongCoKetQua} </Text>

                        <TouchableOpacity
                            onPress = {this._onRefresh.bind(this)}
                        >
                            <Text style={myStyles.linkText}> {gui.INF_ClickToRefresh} </Text>
                        </TouchableOpacity>
                    </View>
                </ScrollView>
            )
        }

        let ds = myDs.cloneWithRows(myProps.listAds);
        //this.setState({dataSource:ds});

        return (
            <ListView
                scrollEnabled = {this.state.scrollEnabled}
                refreshControl={
                    <RefreshControl
                        refreshing={false}
                        onRefresh={this._onRefresh.bind(this)}
                    />
                }

                enableEmptySections = {true}

                dataSource={ds}
                renderRow={this.renderRow.bind(this)}
                //renderScrollComponent={props => <RecyclerViewBackedScrollView {...props} />}
                renderSeparator={(sectionID, rowID) => <View key={`${sectionID}-${rowID}`} style={myStyles.separator} />}
                style={myStyles.searchListView}
                renderFooter={this._renderFooter.bind(this)}
            />
        )
    }

    _renderFooter() {
        // let myAdsMgmt = this.props.adsMgmt;
        let result;
        switch (this.props.name) {
            case "likedTab" :
            case "sellTab" :
            case "rentTab" :
            case "sellWToTab" :
            case "rentWToTab" :
                result = (
                    <View style={myStyles.viewFooter}>
                        <Text style={myStyles.textFooter}>Tất cả đã được hiển thị</Text>
                        {/*<Text style={[myStyles.textFooter, {fontWeight: '400', fontSize: 13, marginTop: 0}]}>Nhấn vào trái tim để xoá lưu tin</Text>*/}
                    </View>
                );
                break;
            default:
                result = null;
                break;
        }
        return result;

    }

    render() {

        return (
            <View
                //scrollEnabled={this.state.scrollEnabled}
                style={[myStyles.container, this.props.mainStyle]}>
                {this._getListContent()}
                {this._renderLoadingView()}
                {/*this._openModalDelFix()*/}
            </View>
        )
    }

    _openModalDelFix() {
        return (
            <Modal isOpen={this.state.isOpenModalDelFix}
                   onClosed={this._outModalDelFix.bind(this)}
                   style={myStyles.viewModalStyle}
                //ref={"modalSapxep"}
                   position={"bottom"}
                   swipeToClose={false}
            >
                {this._renderDelFixContent()}
            </Modal>
        );

    }

    // Press Icon to open Modal
    _onModalDelFix(adsID) {
        this.setState({isOpenModalDelFix: true, adsID: adsID});
    }

    // Press to close Modal
    _outModalDelFix() {
        this.setState({
            isOpenModalDelFix: false, adsID: null
        });
    }

    _renderDelFixContent() {
        let adsID = this.state.adsID;
        return(
            <View style={myStyles.viewShowModal}>
                <View style={myStyles.viewSwipeButton}>
                    <TouchableOpacity onPress={this.onEditButton.bind(this, adsID)} style={[myStyles.viewButtonModal,{borderBottomLeftRadius: 0,borderBottomRightRadius: 0}]}>
                        {(this.props.postAds.loadingUpdateAds) ?
                            <View>
                                <GiftedSpinner color={gui.mainColor}></GiftedSpinner>
                            </View>
                            : <Text style={[myStyles.textDelete, {color: gui.mainColor}]}>Sửa tin</Text>
                        }

                    </TouchableOpacity>
                    <View style={myStyles.lineSpaceButton}></View>
                    <TouchableOpacity onPress={this.onDeleteButton.bind(this, adsID)} style={[myStyles.viewButtonModal, {borderTopLeftRadius: 0,borderTopRightRadius: 0}]}>
                        {(this.props.adsMgmt.deletingAds) ?
                            <View>
                                <GiftedSpinner color={gui.mainColor} ></GiftedSpinner>
                            </View>
                            : <Text style={myStyles.textDelete}>Xóa tin</Text>
                        }

                    </TouchableOpacity>
                </View>
                <TouchableOpacity onPress={() => this._outModalDelFix()} style={myStyles.viewSwipeButton2}>
                    <Text style={[myStyles.textDelete, {color: gui.mainColor, fontWeight: '500', fontSize: 18}]}>Hủy</Text>
                </TouchableOpacity>
            </View>
        )
    }

    _renderWToDefaultImage(rowData) {
        let image =  {uri: `${cfg.noCoverUrl}`};
        return (
            <View style={myStyles.slide}>
                <TouchableHighlight
                    onPress={() => Actions.NeedToBuyDetail({wtoID: rowData.wtoID})}>
                    <View>
                        <ImageBackground style={[myStyles.thumb, {height: 90}]} source={image}>
                            <LinearGradient colors={['transparent', 'rgba(50, 50, 50, 0.75)']}
                                            style={myStyles.linearGradient2}>
                            </LinearGradient>
                        </ImageBackground>
                    </View>
                </TouchableHighlight>
            </View>
        );
    }

    _renderImageStack(rowData) {
        var imageIndex = 0;
        if (rowData.image && rowData.image.cover) {
            return (
                <MyImage imageIndex={0} rowData={rowData} imageUrl={rowData.image.cover} source={this.props.source}/>
            );
        } else {
            return (
                <MyImage imageIndex={0} rowData={rowData} imageUrl={''} source={this.props.source}/>
            );
        }
    }

    onEditButton(adsID){
        this.props.actions.getUpdateAds(adsID, this.props.global.currentUser.token)
            .then(
                (res) => {
                    if (res.success){
                        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', res.data.place.diaChinh);
                        // Actions.PostAdsDetail();
                        Actions.NewPostAdsDetail();
                        this._outModalDelFix();
                    } else {
                        Alert.alert('Thông báo', 'Lỗi không tải được tin đã đăng.');
                    }
                }
            );
    }

    onDeleteButton(adsID){
        Alert.alert('Thông báo', 'Bạn có muốn xóa tin này không?',
            [ {text: 'Hủy' , onPress: () => log.info('Cancel Pressed!')},
                {text: 'Đồng ý', onPress: () => this._deleteAds(adsID)}
            ]);
    }

    onLamMoiTinButton(adsID) {
        this.props.actions.upgradeNgayDangTin(adsID, this.props.global.currentUser.token)
            .then(
                (res) => {
                    if (res.success){
                        Alert.alert('Làm mới tin thành công!', 'Ngày đăng tin đã được chuyển thành hôm nay. Tin của bạn sẽ đứng trước các tin cùng loại có ngày đăng cũ hơn.');
                        this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
                    } else {
                        Alert.alert('Thông báo', 'Lỗi không làm mới được tin đã đăng.');
                    }
                }
            );
    }

    _deleteAds(adsID){
        let token = this.props.global.currentUser.token;

        this.props.actions.deleteAds(adsID, token).then (
            (res) => {
                if (res.success){
                    this._outModalDelFix();
                    Alert.alert('Thông báo', 'Bạn đã xóa thành công tin đăng.');
                    this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
                }else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        );
    }

    upgradeAds(ads) {
        this.props.actions.changePackageField('adsID', ads.adsID);
        this.props.actions.changePackageField('ads', ads);

        if (ads.goiViTri){
            let remainDays = util.getRemainDay(ads.goiViTri);
            this.props.actions.changePackageField(
                'current_goiViTri', remainDays>0 ? util.getLevelName(ads.goiViTri) : "Chưa có");
        }

        /*
         this.props.actions.changePackageField(
         'current_goiTrangChu', this._getLevelName(ads.goiTrangChu));
         */
        if (ads.goiLogo && ads.goiLogo.length>0) {
            let index = ads.goiLogo.length - 1;
            let remainDays = util.getRemainDay(ads.goiLogo[index]);
            this.props.actions.changePackageField(
                'current_goiLogo', remainDays>0 ? ads.goiLogo[0].text : "Chưa có");
        }

        Actions.UpgradePackgeSelector();
    }

    // coming() {
    //     Alert.alert("Coming soon...");
    // }

    _getPackValue(prefix, pack) {
        if (!pack)
            return '';

        let remainDays = util.getRemainDay(pack);
        if (remainDays<=0)
            return '';

        if (prefix.indexOf("Logo")>=0){

            return prefix + pack.text + " - " + remainDays + " ngày";
        }

        if (pack && pack.level) {
            return prefix + danhMuc.package.level[pack.level] + " - " + remainDays + " ngày";
        }

        return '';
    }

    _renderGoiTin(rowData) {
        if (this.props.name == 'likedTab') {
            return null;
        }

        let viTriLabel = this._getPackValue("Vị trí : " , rowData.goiViTri);
        // let trangChuLabel =  this._getPackValue("Trang chủ : ", rowData.goiTrangChu);
        let logoLabel = rowData.goiLogo && rowData.goiLogo.length>0 ?
            this._getPackValue("Logo : " , rowData.goiLogo[rowData.goiLogo.length-1]) : '';
        let trangThai = rowData.statusFmt;
        // let trangThaiTin = rowData.statusFmt ? rowData.statusFmt : danhMuc.TIN_CHO_DUYET;

        return (
            <View style={myStyles.rightTextGroup}>
                {/*<Text numberOfLines={1} style={myStyles.tinChoDuyet}>{trangThaiTin.toUpperCase()}</Text>*/}
                {this._renderTrangThaiTin(rowData)}
                {this._renderRejectPost(rowData)}

                {/*<TouchableHighlight disabled={false} underlayColor='transparent' onPress={() => {this.upgradeAds(rowData)}}>
                    <View style={myStyles.nangCap} >
                        <RelandIcon.Icon color={'white'} name={"update"} size={12} style={{marginLeft:5, marginRight:5}} />
                        <Text style={myStyles.textNangCap}>
                            NÂNG CẤP
                        </Text>
                    </View>
                </TouchableHighlight>*/}
                {/*<Text numberOfLines={1} style={myStyles.textGoiTin}>{viTriLabel}</Text>*/}
                {/*<Text numberOfLines={1} style={myStyles.textGoiTin}>{trangChuLabel}</Text>*/}
                {/*<Text numberOfLines={1} style={[myStyles.textGoiTin, {marginTop: 0}]}>{logoLabel}</Text>*/}
            </View>
        )
    }

    _renderTrangThaiTin(rowData) {
        let trangThaiTin = rowData.statusFmt||"";
        if (trangThaiTin == "Chờ duyệt") {
            return <Text numberOfLines={1} style={myStyles.tinChoDuyet}>{trangThaiTin.toUpperCase()}</Text>
        } else if (trangThaiTin == "Đã duyệt") {
            return <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#00FF00'}]}>{trangThaiTin.toUpperCase()}</Text>
        } else if (trangThaiTin == "Bị từ chối") {
            return <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#FF0000'}]}>{trangThaiTin.toUpperCase()}</Text>
        } else if (trangThaiTin == "Hết hạn") {
            return <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#ffa500'}]}>{trangThaiTin.toUpperCase()}</Text>
        } else return <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#fff'}]}>{trangThaiTin.toUpperCase()}</Text>;
    }

    _getGiaText(rowData) {
        let {content} = rowData;
        let {giaTu, giaDen, giaTuFmt, giaDenFmt} = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _getDienTichText(rowData) {
        let {content} = rowData;
        let {dienTichTu, dienTichDen, dienTichTuFmt, dienTichDenFmt} = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    _renderWToText(rowData) {
        let {content, wtoID} = rowData;
        let title = rowData.title;
        let gia = this._getGiaText(rowData);
        let loaiTin = content.loaiTin;
        let loaiNhaDat = content.loaiNhaDat;
        let dienTich = this._getDienTichText(rowData);
        let soPhongNgu = '';
        if (content.soPhongNguFmt) {
            soPhongNgu = ' ' + content.soPhongNguFmt;
        }
        let soTang = '';
        if (content.soTangFmt) {
            soTang = ' ' + content.soTangFmt;
        }
        let diaChiFullname = this._getDiaChiFullname(content.place);
        let diaChi = diaChiFullname;
        var maxDiaChiLength = 25;
        var index = diaChi.indexOf(',', maxDiaChiLength - 5);
        var length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < diaChiFullname.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);
        return (
            <View style={[myStyles.leftTextGroup, {top: 10}]}>
                <TouchableHighlight underlayColor='transparent'
                    onPress={() => Actions.NeedToBuyDetail({wtoID: rowData.wtoID})}>
                    <View>
                        <ScalableText numberOfLines={1} style={myStyles.title}>{title}</ScalableText>
                        <ScalableText numberOfLines={1} style={[myStyles.price, {fontWeight: 'normal'}]}>{gia}</ScalableText>
                        <View style={myStyles.viewChildGia}>
                            <ScalableText numberOfLines={1} style={myStyles.smallText1}>{diaChi}{moreInfo}</ScalableText>
                        </View>
                    </View>
                </TouchableHighlight>
                {this._renderWToMoreButton(wtoID)}
            </View>
        );
    }

    _getDiaChiFullname(place) {
        if (!place) {
            return '';
        }
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    _renderText(rowData) {
        let diaChi = rowData.diaChiChiTiet || rowData.diaChi || '';
        let originDiaChi = diaChi;
        let loaiTin = rowData.loaiTin;
        let loaiNhaDat = rowData.loaiNhaDat;
        let dienTich = '';
        if (rowData.dienTichFmt && rowData.dienTichFmt != 'Không rõ') {
            dienTich = '· ' + rowData.dienTichFmt;
        }
        let soPhongNgu = '';
        if (rowData.soPhongNguFmt) {
            soPhongNgu = " " + rowData.soPhongNguFmt;
        }

        let soTang = '';
        if (rowData.soTangFmt) {
            soTang = " " + rowData.soTangFmt;
        }

        let maxDiaChiLength = 25;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < originDiaChi.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);
        let moreInfoWithoutDot = moreInfo.replace('·', '');
        moreInfoWithoutDot = moreInfoWithoutDot.trim();

        let adsID = rowData.adsID || rowData.id;

        let source = this.props.source ? this.props.source : 'server';

        if (this.props.name == 'likedTab') {
            return (
                <View style={myStyles.likedItemContainer}>
                    <TouchableHighlight underlayColor='transparent'
                                        onPress={() => Actions.GroupAdsDetail({adsID: rowData.adsID, source: source, imageDetail: rowData.image.cover})}>
                    <View style={myStyles.searchListViewRowAlign}>
                        <ScalableText style={[myStyles.price, {fontSize: 20}]}>{rowData.giaFmt}</ScalableText>
                        {/*<ScalableText style={myStyles.text}>{diaChi}{moreInfo}</ScalableText>*/}
                    </View>
                    </TouchableHighlight>

                    {this._renderHeartButton(adsID)}

                </View>
            );
        }
        //Ban or Cho Thue
        return (
            <View style={myStyles.leftTextGroup}>

                <TouchableHighlight underlayColor='transparent'
                                    onPress={() => Actions.GroupAdsDetail({adsID: rowData.adsID, source: source, imageDetail: rowData.image.cover})}>
                    <View>
                        <ScalableText numberOfLines={1} style={myStyles.price}>{rowData.giaFmt}</ScalableText>
                        <View style={myStyles.viewChildGia}>
                            <ScalableText numberOfLines={1} style={myStyles.smallText1}>{diaChi}</ScalableText>
                            <ScalableText numberOfLines={1} style={myStyles.smallText1}>{moreInfoWithoutDot}</ScalableText>
                        </View>
                    </View>
                </TouchableHighlight>
                {this._renderMoreButton(adsID)}
                {this._renderLamMoiTinButton(adsID)}
                {this._renderNgayDangTin(rowData)}
            </View>
        )
    }

    _renderNgayDangTin(rowData) {
        let ngayDangTin = util.formatDate(rowData.ngayDangTin);
        ngayDangTin = ngayDangTin ? 'Ngày đăng: ' + ngayDangTin : '';
        return(
            <View style={myStyles.ngayDangTinView}>
                <LinearGradient colors={['transparent','rgba(50, 50, 50, 0.75)','transparent']}
                                style={myStyles.ngayDangTinGradient}>
                    <ScalableText style={[myStyles.text, {fontSize: 10, fontWeight: 'bold',
                            textAlign: 'center', height: 20, paddingLeft: 5, paddingRight: 5}]}>{ngayDangTin}</ScalableText>
                </LinearGradient>
            </View>
        ); 
    }

    _renderRejectPost (rowData) {
        let trangThaiTin = rowData.statusFmt || "";
        if (trangThaiTin == "Bị từ chối") {
            return (
                <TouchableOpacity style={myStyles.viewReject}
                                  onPress={this._onPressRejectPost.bind(this, rowData)}
                >
                        <Text style={myStyles.textLyDo}>XEM LÝ DO</Text>
                </TouchableOpacity>
            );
        } else return null;
    }

    _onPressRejectPost (rowData) {
        Actions.RejectInfo({dataReject: rowData});
    }

    _renderLamMoiTinButton(adsID) {
        return(
            <View style={myStyles.lamMoiTinView}>
                <TouchableOpacity style={myStyles.lamMoiTinButton}
                                  onPress={this.onLamMoiTinButton.bind(this, adsID)}
                >
                    <Text style={myStyles.lamMoiTinText}>
                        LÀM MỚI TIN
                    </Text>
                </TouchableOpacity>
            </View>
        );
    }

    _renderWToMoreButton(wtoID) {
        return(
            <View style={[myStyles.viewChangeButton, {top: 0}]}>
                <TouchableOpacity style={myStyles.viewEditButton}
                                  onPress={this.onWToEditButton.bind(this, wtoID)}
                >
                    <RelandIcon name="edit" size={16} color="#fff"
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                </TouchableOpacity>
                <TouchableOpacity style={[myStyles.viewDeleteButton]}
                                  onPress={this.onWToDeleteButton.bind(this, wtoID)}
                >
                    <RelandIcon name="delete" size={16} color="#fff"
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                </TouchableOpacity>
            </View>
        );
    }

    onWToEditButton(wtoID){
        this.props.actions.getUpdateWTo(wtoID, this.props.global.currentUser.token)
            .then(
                (res) => {
                    if (res.success){
                        Actions.NeedToBuyFilter();
                    } else {
                        Alert.alert('Thông báo', 'Lỗi không tải được tin đã đăng.');
                    }
                }
            );
    }

    onWToDeleteButton(wtoID){
        Alert.alert('Thông báo', 'Bạn có muốn xóa tin này không?',
            [ {text: 'Hủy' , onPress: () => log.info('Cancel Pressed!')},
                {text: 'Đồng ý', onPress: () => this._deleteWTo(wtoID)}
            ]);
    }

    _deleteWTo(wtoID){
        let token = this.props.global.currentUser.token;
        let userID = this.props.global.currentUser.userID;

        this.props.actions.deleteWTo(userID, wtoID, token).then (
            (res) => {
                if (res.success){
                    Alert.alert('Thông báo', 'Bạn đã xóa thành công tin đăng.');
                    this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
                }else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        );
    }

    _renderMoreButton(adsID){
        return(
            <View style={myStyles.viewChangeButton}>
                <TouchableOpacity style={myStyles.viewEditButton}
                                  onPress={this.onEditButton.bind(this, adsID)}
                >
                    <RelandIcon name="edit" size={16} color="#fff"
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                </TouchableOpacity>
                <TouchableOpacity style={[myStyles.viewDeleteButton]}
                                  onPress={this.onDeleteButton.bind(this, adsID)}
                >
                    <RelandIcon name="delete" size={16} color="#fff"
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                </TouchableOpacity>
            </View>
        );
    }

    _renderHeartButton(adsID) {
        let isLiked = this.isLiked(adsID);
        let color = isLiked ? '#fff' : 'white';
        let bgColor = isLiked ? '#E50064' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        if (!isLiked || (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID)) {
            return (
                <View style={myStyles.heartContent}>
                    <View style={myStyles.heartButton2}>
                        <GiftedSpinner size="small" color="white" />
                    </View>
                </View>);
        } else {
            return (
                <View style={myStyles.heartContent}>
                    <MHeartIcon onPress={() => this.onLike(adsID)}
                                color={color} bgColor={bgColor}
                                bgStyle={bgStyle} mainProps={myStyles.heartButton}/>
                </View>
            );
        }
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.likeAds(this.props.global.currentUser.userID, adsID, this._loadLikedList.bind(this));
            } else {
                this.props.unlikeAds(this.props.global.currentUser.userID, adsID, this._loadLikedList.bind(this));
            }
        }
    }

    _loadLikedList(likeAdsMessage) {
        this.props.actions.loadLikedList(this.props.global.currentUser.userID);
        InteractionManager.runAfterInteractions(() => {
            this.props.updateLikeAdsProcessing && this.props.updateLikeAdsProcessing(likeAdsMessage);
        });
    }

    _renderLoadingView() {
        if (this.props.postAds.loadingUpdateAds || this.props.adsMgmt.deletingAds || this.props.adsMgmt.updatingAds) {
            return (<View style={myStyles.resultContainer}>
                <View style={myStyles.loadingContent}>
                    <GiftedSpinner color="white" />
                </View>
            </View>)
        }
    }

    renderRow(rowData, sectionID, rowID) {
        let adsID = rowData.id || rowData.adsID;

        if (this.props.name == 'likedTab'){
            // var swipeoutBtns = [
            //     {
            //         text: 'Xóa',
            //         backgroundColor:'#710900',
            //         onPress: () => this.onLike(adsID)
            //     }
            // ];
            return (
                <View key={adsID} style={{overflow: 'hidden'}}>
                    {/*<SwipeRow*/}
                    {/*previewOpenValue={0}*/}
                    {/*tension={0}*/}
                    {/*disableRightSwipe={true}*/}
                    {/*rightOpenValue={-65}*/}
                    {/*setScrollEnabled={event => this._allowScroll(event)}>*/}
                    {/*<View style={myStyles.viewSwipeButton}>*/}
                    {/*<TouchableOpacity onPress={() => this.onLike(adsID)} style={myStyles.viewXoa}>*/}
                    {/*<Text style={myStyles.textDelete}>Xóa</Text>*/}
                    {/*</TouchableOpacity>*/}
                    {/*/!*{this._renderSpinnerDelete()}*!/*/}
                    {/*</View>*/}


                    <View style={[myStyles.detail, {alignItems: 'center', marginBottom: 8}]}>
                        {this._renderImageStack(rowData)}
                        {this._renderText(rowData)}
                        {this._renderDetailPost(rowData)}
                    </View>
                    {/*</SwipeRow>*/}
                </View>
            );
        } else if (this.props.name == 'sellWToTab' || this.props.name == 'rentWToTab') {
            return (
                <View key={adsID} style={{overflow: 'hidden'}}>
                    <View style={myStyles.detail}>
                        {this._renderWToDefaultImage(rowData)}
                        {this._renderWToText(rowData)}
                    </View>
                </View>
            );
        } else {
            // var swipeoutBtns = [
            //     {
            //         text: 'Sửa',
            //         backgroundColor: '#E99409',
            //         onPress: () => this.onEditButton(adsID)
            //     },
            //     {
            //         text: 'Xóa',
            //         backgroundColor:'#710900',
            //         onPress: () => this.onDeleteButton(adsID)
            //     }
            // ];
            return (
                <View key={adsID} style={{overflow: 'hidden'}}>
                    {/*<SwipeRow*/}
                    {/*tension={0}*/}
                    {/*disableRightSwipe={true}*/}
                    {/*rightOpenValue={-130}*/}
                    {/*setScrollEnabled={event => this._allowScroll(event)}>*/}
                    {/*<View style={myStyles.viewSwipeButton}>*/}
                    {/*<View style={myStyles.viewTwoButton}>*/}
                    {/*<TouchableOpacity onPress={() => this.onEditButton(adsID)} style={myStyles.viewSua}>*/}
                    {/*{(this.props.postAds.loadingUpdateAds) ?*/}
                    {/*<View>*/}
                    {/*<GiftedSpinner color="white"></GiftedSpinner>*/}
                    {/*</View>*/}
                    {/*: <Text style={myStyles.textDelete}>Sửa</Text>*/}
                    {/*}*/}

                    {/*</TouchableOpacity>*/}
                    {/*<TouchableOpacity onPress={() => this.onDeleteButton(adsID)} style={myStyles.viewXoa}>*/}
                    {/*{(this.props.adsMgmt.deletingAds) ?*/}
                    {/*<View>*/}
                    {/*<GiftedSpinner color="white"></GiftedSpinner>*/}
                    {/*</View>*/}
                    {/*: <Text style={myStyles.textDelete}>Xóa</Text>*/}
                    {/*}*/}

                    {/*</TouchableOpacity>*/}
                    {/*</View>*/}
                    {/*</View>*/}
                    <View style={myStyles.detail}>
                        {this._renderImageStack(rowData)}
                        {this._renderText(rowData)}
                        {this._renderGoiTin(rowData)}
                    </View>
                    {/*</SwipeRow>*/}
                </View>
            );
        }
    }

    _renderDetailPost(data) {
        let addressValue = data.diaChiChiTiet || data.diaChi || '';
        let featureItems = [];
        let index = 0;
        if (data.dienTichFmt && data.dienTichFmt != 'Không rõ') {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight noAction={true}
                                name="expand" color={gui.mainTextColor}
                                mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[myStyles.textMainUser, { marginLeft: 6 }]}>{data.dienTichFmt}</Text>
                </View>
            );
        }
        if (data.soPhongNgu) {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight noAction={true}
                                name="bed" color={gui.mainTextColor}
                                mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[myStyles.textMainUser, { marginLeft: 6 }]}>{data.soPhongNgu}</Text>
                </View>
            );
        }

        if (data.soPhongTam) {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight noAction={true}
                                name="bath" color={gui.mainTextColor}
                                mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[myStyles.textMainUser, { marginLeft: 6 }]}>{data.soPhongTam}</Text>
                </View>
            );
        }

        if (data.soTang) {
            let marginLeft = index == 0 ? 0 : 12;
            featureItems.push(
                <View key={'feature_' + index++} style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center', flexDirection: 'row'
                }} >
                    <FontAwesomeLight noAction={true}
                                name="building" color={gui.mainTextColor}
                                mainProps={{ marginTop: 10, marginLeft: marginLeft }} size={15} />
                    <Text style={[myStyles.textMainUser, { marginLeft: 6 }]}>{data.soTang}</Text>
                </View>
            );
        }

        if (data.ngayDangTin) {
            let now = moment();
            let ngayDangTin = moment(data.ngayDangTin, 'YYYYMMDD');
            let soNgayDaDangTin = now.diff(ngayDangTin, 'days');
            let soNgayDaDangTinFmt = soNgayDaDangTin > 0 ? soNgayDaDangTin + ' ngày trước' :
                'hôm nay';
            featureItems.push(
                <Text key={'feature_' + index++} style={myStyles.textTimePost} numberOfLines={1}>
                    {soNgayDaDangTinFmt}
                </Text>
            );
        }

        let textMotionValue = data.title || util.getTitleAdsDetail2(data);
        return (
            <View style={myStyles.viewDetailPost}>
                <View style={myStyles.viewMainTextPost}>
                    <Text style={myStyles.textMainPost} numberOfLines={2}>{textMotionValue}</Text>
                </View>
                <View style={[myStyles.lineDangNhap, {width: width-48, marginLeft: 24, marginRight: 24}]} />
                <View style={myStyles.viewContentSource}>
                    {featureItems}
                </View>
                <View style={myStyles.viewTextAddress}>
                    <Text style={myStyles.textMainMinute} numberOfLines={1}>{addressValue}</Text>
                </View>
                {/*<View style={[styles.lineDangNhap, { marginLeft: 0, marginRight: 0, width: width - 32 }]} />*/}
            </View>
        )
    }

    // _renderSpinnerDelete(){
    //     return(
    //         <View style={myStyles.deleteSpinner}>
    //             <GiftedSpinner color="white" />
    //         </View>
    //     );
    // }

    _allowScroll(scrollEnabled) {
        this.setState({ scrollEnabled })
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        var moreInfo = '';
        var loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = ' ' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = ' ' + dienTich + soTang;
        }
        else {
            moreInfo = ' ' + dienTich;
        }
        return moreInfo;
    }
}

class MyImage extends Component {
    render() {
        let source = this.props.source ? this.props.source : 'server';

        let image =  (this.props.imageUrl && this.props.imageUrl.length>0 ) ? {uri: `${this.props.imageUrl}`}
            : {uri: `${cfg.noCoverUrl}`};

        return (
            <View style={myStyles.slide} key={"img"+(this.props.imageIndex)}>
                <TouchableHighlight
                    onPress={() => Actions.GroupAdsDetail({adsID: this.props.rowData.adsID, source: source, imageDetail: this.props.rowData.image.cover})}>
                    <View>
                        <ImageBackground style={[myStyles.thumb, {width: width - 16}]} source={image}>
                            {/*<LinearGradient colors={['transparent', 'rgba(50, 50, 50, 0.75)']}
                                            style={myStyles.linearGradient2}>
                            </LinearGradient>*/}
                        </ImageBackground>
                    </View>
                </TouchableHighlight>
            </View>
        );
    }
}

// Later on in your styles..
const myStyles = StyleSheet.create({
    welcome: {
        marginTop: -50,
        marginBottom: 50,
        fontSize: 17,
        textAlign: 'center',
        margin: 10
    },
    container: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        height: height-113
    },
    search: {
        backgroundColor: gui.mainColor,
        height: 30
    },
    searchContent: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent'
        //
    },
    separator: {
        height: 0,
        backgroundColor: 'transparent'
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 3,
        bottom: 32
    },
    detail: {
        flex: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "#fff"
    },
    linearGradient2: {
        marginTop: imgHeight / 3,
        height: 2 * (imgHeight / 3),
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    thumb: {
        justifyContent: 'flex-end',
        alignItems: 'stretch',
        height: imgHeight,
        alignSelf: 'auto'
    },
    searchListView: {
        margin: 0,
        backgroundColor: 'white'
    },

    likedItemContainer: {
        flexDirection: 'row',
        position: 'absolute',
        backgroundColor: 'transparent',
        justifyContent: 'space-between',
        top: imgHeight - 40,
        width: width
    },

    searchListViewRowAlign: {
        backgroundColor: 'transparent',
        flexDirection: 'column',
        justifyContent: 'center',
        width: 2*width/3,
        marginLeft: 17,
        bottom:7
    },

    leftTextGroup: {
        position: 'absolute',
        backgroundColor: 'transparent',
        flexDirection: 'column',
        top: imgHeight - 58,
        width: width,
        marginLeft: 17
    },
    viewChildGia:{
        backgroundColor:'transparent',
        flexDirection:'column'
    },

    title: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily
    },
    price: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily
    },
    text: {
        fontSize: 13,
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily,
        marginTop: 2,
        fontWeight: '300'
    },
    textLyDo: {
        textAlign: 'center',
        color: '#fff',
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight : 'bold'
    },
    heartContent: {
        backgroundColor: 'transparent',
        marginRight: 10,
        position: "absolute",
        left: width-65,
        top: 49-imgHeight

    },
    viewChangeButton: {
        marginTop:9,
        backgroundColor: 'rgba(211,211,211,0.9)',
        marginRight: 10,
        position: "absolute",
        left: width-116,
        top: -122,
        width: 80,
        height: 20,
        right: 26,
        justifyContent: 'center',
        flexDirection: 'row',
        borderRadius: 5
    },
    viewEditButton:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        borderTopLeftRadius: 3,
        borderBottomLeftRadius: 3
    },
    viewDeleteButton:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#ff2714',
        borderTopRightRadius: 3,
        borderBottomRightRadius: 3
    },
    ngayDangTinGradient: {
        marginTop: 0,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    lyDoGradient: {
        paddingTop: 3,
        backgroundColor: "transparent"
    },
    ngayDangTinView: {
        marginTop:9,
        backgroundColor: 'transparent',
        marginRight: 10,
        position: "absolute",
        left: 95,
        top: -122,
        height: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    lamMoiTinView: {
        marginTop:9,
        backgroundColor: 'rgba(211,211,211,0.9)',
        marginRight: 10,
        position: "absolute",
        left: 0,
        top: -122,
        width: 90,
        height: 20,
        justifyContent: 'center',
        borderRadius: 5
    },
    lamMoiTinButton:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        borderRadius: 3
    },
    lamMoiTinText: {
        color : "white",
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight : 'bold'
    },
    heartButton: {
        marginTop: 6,
        marginRight: 10
    },
    heartButton2: {
        marginTop: 8,
        marginRight: 8,
        marginLeft: 21
    },


    smallText1: {
        fontSize: 13,
        textAlign: 'left',
        color: 'white',
        fontFamily: gui.fontFamily,
        fontWeight: '300'
    },
    // smallText2: {
    //     fontSize: 13,
    //     textAlign: 'left',
    //     color: 'white',
    //     fontFamily: gui.fontFamily,
    //     marginLeft: 5,
    //     fontWeight: '300',
    //     backgroundColor:'transparent'
    // },
    linkText  : {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontSize,
        color : gui.mainColor
    },
    rightTextGroup: {
        position: 'absolute',
        backgroundColor: 'transparent',
        flexDirection: 'row',
        top: imgHeight - 110,
        width: 180,
        height: 20,
        right: 19,
        alignItems : 'center',
        justifyContent: 'flex-end'
    },

    nangCap : {
        backgroundColor: '#ff2714',
        flexDirection: 'row',
        padding: 3,
        width: 80,
        borderRadius : 3,
        marginBottom: 7,
        marginTop: 7,
    },

    textNangCap : {
        color : "white",
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight : 'bold'
    },

    textGoiTin: {
        fontSize: 11,
        textAlign: 'left',
        color: '#ffff00',
        fontFamily: gui.fontFamily,
        fontWeight : '400',
        marginTop: 5
    },

    tinChoDuyet : {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color : '#ffff00',
        fontWeight : 'bold'
    },

    editContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        height: imgHeight
    },
    editButton: {
        justifyContent: 'center',
        alignItems: 'center',
        height: 30,
        marginTop: 10,
        padding: 5,
        borderRadius : 3
    },
    editButtonText: {
        color : "white",
        fontFamily: gui.fontFamily,
        fontSize: 12,
        fontWeight : 'bold',
        width: 80,
        borderRadius : 3,
        textAlign: 'center'
    },
    loadingContent: {
        position: 'absolute',
        top: -23,
        left: width/2,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: height/2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    textDelete:{
        color:'#f43838',
        fontSize:17,
        fontFamily:gui.fontFamily,
        fontWeight:'400'
    },
    viewSwipeButton:{
        backgroundColor: 'transparent',
        height: 105,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewSwipeButton2:{
        backgroundColor: 'white',
        height: 52,
        width: width - 28,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        marginTop: 8
    },
    lineSpaceButton:{
        width: width - 28,
        backgroundColor: 'rgba(80,80,80,0.6)',
        borderColor: '#fff',
        borderTopWidth: 0.5,
        height: 1
    },
    viewShowModal:{
        justifyContent: 'flex-start',
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewTwoButton:{
        flex: 1,
        backgroundColor:'white',
        alignItems: 'center',
        justifyContent:'center',
        flexDirection:'column'
    },
    // viewXoa:{
    //     right:0,
    //     width:65,
    //     backgroundColor:'#f43838',
    //     height:imgHeight,
    //     alignItems: 'center',
    //     justifyContent:'center'
    // },
    // viewSua:{
    //     width:65,
    //     backgroundColor:'#eb9b06',
    //     height:imgHeight,
    //     alignItems: 'center',
    //     justifyContent:'center'
    // },
    viewButtonModal:{
        height: 52,
        width: width -28,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12
    },
    deleteSpinner:{
        position: 'absolute',
        backgroundColor: 'transparent',
        top: imgHeight/2 -16,
        right: 21,
        width:35,
        height:35,
        justifyContent:'center',
        alignItems:'center'
    },
    viewModalStyle : {
        justifyContent: 'flex-start',
        height: 180,
        width: width - 28,
        marginVertical: 0,
        backgroundColor: 'transparent',
        alignItems: 'center'
    },

    viewModalReject : {
        justifyContent: 'flex-start',
        height: height,
        width: width,
        marginVertical: 0,
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    viewFooter:{
        marginTop: 20,
        width: width,
        height: 50,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textFooter:{
        fontSize: 17,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'
    },
    viewReject: {
        alignItems : 'center',
        justifyContent: 'center',
        height: 20,
        marginLeft: 10,
        backgroundColor: gui.mainColor,
        left: 0,
        width: 90,
        borderRadius: 3
    },
    textMainUser: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.mainTextColor,
        fontWeight: '500',
        marginLeft: 8
    },
    viewDetailPost: {
        // height: 105,
        width: width - 16,
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(82,97,115,0.3)',
        borderRadius: 2,
        borderTopWidth: 0,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0
    },
    viewMainTextPost: {
        // height: 39,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        paddingTop: 8,
        paddingBottom: 8,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    textMainPost: {
        fontSize: 15,
        fontWeight: '500',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily
    },
    viewContentSource: {
        height: 36,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    viewTextAddress: {
        // height: 28,
        width: width - 16,
        paddingLeft: 17,
        paddingRight: 17,
        paddingBottom: 5,
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    textTimePost: {
        fontSize: 12,
        fontWeight: 'normal',
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        position: 'absolute',
        right: 17
    },
    textMainMinute: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        color: gui.colorMainBlur,
        fontWeight: 'normal',
        // marginLeft: 5
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        height: 1,
        width: width - 16,
        opacity: 0.8,
        marginLeft: 8,
        marginRight: 8
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(AdsListTab2);
