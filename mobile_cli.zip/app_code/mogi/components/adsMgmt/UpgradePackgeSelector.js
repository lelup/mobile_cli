'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as meActions from '../../reducers/me/meActions';

import React, {Component} from 'react';

import {Text, View, StyleSheet, TextInput, StatusBar, TouchableHighlight, ScrollView, Alert} from 'react-native'

import TruliaIcon from '../TruliaIcon';

import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import utils from "../../lib/utils";

import LineWithIcon from "./UpgradePackgeSelector_LineWithIcon";
import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text'

import GiftedSpinner from 'react-native-gifted-spinner';

const actions = [
  globalActions,
  adsMgmtActions,
  meActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}


class UpgradePackgeSelector extends Component {
  constructor(props) {
    super(props);
    StatusBar.setBarStyle('light-content');
  }
  _onSelect(val) {
      let currentUser = this.props.global.currentUser;
      this.props.actions.getUserBalance(currentUser.userID, currentUser.token).then(
          (res) => {
              if (res.status == 0) {
                  this.props.actions.changeSelectedPackage(val);
                  if (val == "goiViTri")
                      Actions.PackageUpdater({doViTriFinalAction: this.props.doViTriFinalAction});
                  else if (val == "goiLogo")
                      Actions.LogoPackageUpdater();
              } else {
                  Alert.alert('Thông báo', res.msg, [{text: 'Đóng', onPress: () => {}}]);
              }
          }
      );
  }

  render() {
    let ghiChuTitle = 'Để tin của bạn được nhiều người xem hơn, hãy nâng cấp tin bằng các gói dịch vụ sau: \n';
    let ghiChuViTri = 'Sử dụng các gói tin VIP để tin của bạn luôn nằm trên các tin khác trong KẾT QUẢ TÌM KIẾM của người dùng.\n';
    let ghiChuTrangChu = "Sử dụng gói TRANG CHỦ để tin của bạn luôn nằm trên các tin khác trong các BỘ SƯU TẬP ở màn hình chính.\n";
    let validTin = utils.checkNgayHetHan(this.props.ads.ngayHetHan);
    return (
      <View style={myStyles.container}>
        <View style={myStyles.customPageHeader}>
          <View style={myStyles.customPageTitle}>
            <Text style={myStyles.customPageTitleText}>
              Nâng cấp tin
            </Text>
          </View>
          <TruliaIcon onPress={this._onBack.bind(this)}
                      name="arrow-left" color={'white'} size={26}
                      mainProps={myStyles.backButton} text={this.props.backTitle}
                      textProps={myStyles.backButtonText}>
          </TruliaIcon>
        </View>

        <View style={{flex: 1, backgroundColor: '#fff'}}>
            <ScrollView
                automaticallyAdjustContentInsets={false}
                vertical={true}
                style={myStyles.scrollView}
            >
                  <Text style={myStyles.introText}>{ghiChuTitle}</Text>

                  <FullLine/>
                  <LineWithIcon iconSource = {require('../../assets/image/goi/viTri.png')}
                                onPress = {() => this._onSelect('goiViTri')}
                                value = {'Chọn gói tin'}
                                titleColor = {"#e52663"}
                                title = "Gói tin VỊ TRÍ" />
                  <FullLine/>
                    {this.renderGoiViTri()}
                  <Text style={[myStyles.introText,{paddingTop: 15}]}>{ghiChuViTri}</Text>

                  {/*<LineWithIcon iconSource = {require('../../assets/image/goi/trangChu.png')}
                                onPress = {() => this._onSelect('goiTrangChu')}
                                value = {this.props.adsMgmt.package.current_goiTrangChu}
                                titleColor = {"#ffbc34"}
                                title = "Gói TRANG CHỦ" />
                  <Text style={myStyles.introText}>{ghiChuTrangChu}</Text>
                  */}
                  {validTin ? this._renderGoiLogo() : null}
            </ScrollView>
        </View>
        {this._renderLoadingView()}

      </View>
    )
  }

    _renderLoadingView() {
        if (this.props.me.isUpdatingProfile) {
            return (
                <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                        alignItems: 'center', justifyContent: 'center'}}>
                    <GiftedSpinner size='large' color={'#d3d3d3'} />
                </View>
            )
        }
    }

    _renderGoiLogo() {
        let ghiChuLogo = "Sử dụng gói LOGO để tin của bạn thu hút được nhiều sự chú ý của người xem hơn.\n";
        return (
            <View style={{flex: 1}}>
                <FullLine/>
                <LineWithIcon iconSource = {require('../../assets/image/goi/logo.png')}
                              onPress = {() => this._onSelect('goiLogo')}
                              value = {'Chọn gói tin'}
                              titleColor = {"#2a9ad2"}
                              title = "Gói LOGO" />
                <FullLine/>
                {this.renderTotalLogo()}
                <Text style={[myStyles.introText, {paddingTop: 15}]}>{ghiChuLogo}</Text>
            </View>
        )
    }

    renderGoiViTri() {
        let usedGoiViTri = "Gói Vị trí đang sử dụng: \n";
        let {goiViTri} =  this.props.ads;
        if (!goiViTri || goiViTri.length <= 0) {
            return null;
        }

        let goiViTriName = utils.getLevelName(goiViTri);
        let remainDays = utils.getRemainDay(goiViTri);
        let dayConvert = utils.getPackValue(remainDays);
        return (
            <View style={myStyles.viewTotalGoiLogo}>
                <Text style={[myStyles.introText,{paddingLeft: 0, paddingRight: 0, paddingTop: 12}]}>{usedGoiViTri}</Text>
                <View style={[myStyles.viewEachLogo]}>
                    <View style={myStyles.viewCircleCoin} />
                    <ScalableText style={myStyles.logoTextContent}>
                        {goiViTriName.toUpperCase()}{dayConvert}
                    </ScalableText>
                </View>
            </View>
        )
    }

    renderTotalLogo () {
        let usedGoiLogo = "Những gói Logo đang sử dụng: \n";
        let currentLogo = [];
        let {goiLogo} =  this.props.ads;
        if (!goiLogo || goiLogo.length <= 0) {
          return null;
        }
        let dataLogo = goiLogo.sort((a, b) => b.startDateTime - a.startDateTime);
        let index = 0;
        let key = new Date().getTime();
        for (let i=0; i<dataLogo.length; i++) {
            let adsLogo = dataLogo[i];
            let remainDays = utils.getRemainDay(adsLogo);
            let dayConvert = utils.getPackValue(remainDays);

            currentLogo.push(
                <View key={key + index} style={[myStyles.viewEachLogo]}>
                  <View style={myStyles.viewCircleCoin} />
                  <ScalableText style={myStyles.logoTextContent}>
                      {adsLogo.text.toUpperCase()}{dayConvert}
                  </ScalableText>
                </View>
            );
            index++;
        }

        return (
            <View style={myStyles.viewTotalGoiLogo}>
              <Text style={[myStyles.introText,{paddingLeft: 0, paddingRight: 0, paddingTop: 12}]}>{usedGoiLogo}</Text>
                {currentLogo}
            </View>
        )

    }

  _onBack() {
    Actions.pop();
  }
}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'stretch',
    backgroundColor: '#f6f6f6'
  },
  headerSeparator: {
    marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: gui.separatorLine
  },
  customPageHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    backgroundColor: gui.mainColor,
    top: 0,
    height: 60
  },
  customPageTitle: {
    left: 36,
    right: 36,
    marginTop: 31,
    marginBottom: 10,
    position: 'absolute'
  },
  customPageTitleText: {
    color: 'white',
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    textAlign: 'center'
  },
  backButton: {
    marginTop: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    paddingLeft: 18,
    paddingRight: 18
  },
  backButtonText: {
    color: 'white',
    fontSize: gui.normalFontSize,
    fontFamily: gui.fontFamily,
    textAlign: 'left',
    marginLeft: 7
  },
    scrollView: {
        backgroundColor: '#fff',
        // marginBottom: 38
    },

  label: {
    fontSize: gui.normalFontSize,
    fontFamily: gui.fontFamily,
    color: '#8A8A8A'
  },

  introText: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: '#8A8A8A',
    paddingLeft: 19,
    paddingRight: 19,
    paddingTop: 10,

  },
  viewEachLogo: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    paddingLeft: 12,
    padding: 2
  },
  viewCircleCoin:{
      width: 6,
      height: 6,
      borderRadius: 3,
      marginRight: 3,
      backgroundColor: '#8A8A8A'
  },
  logoTextContent: {
      fontSize: 13,
      fontFamily: gui.fontFamily,
      fontWeight: '400',
      color: '#8A8A8A',
      marginLeft: 6
  },
  viewTotalGoiLogo: {
      justifyContent: 'flex-start',
      alignItems: 'flex-start',
      paddingLeft: 19,
      paddingRight: 19
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(UpgradePackgeSelector);

