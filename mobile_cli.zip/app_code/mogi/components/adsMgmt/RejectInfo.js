'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ListView} from 'react-native';

import FullLine from '../line/FullLine'
import TruliaIcon from '../TruliaIcon';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import util from "../../lib/utils";
import RelandIcon from '../RelandIcon';

import ScalableText from 'react-native-text'

var Intercom = require('react-native-intercom');

import {Actions} from 'react-native-router-flux';

var {width, height} = util.getDimensions();

import {Map} from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as inboxActions from '../../reducers/inbox/inboxActions';
import * as searchActions from '../../reducers/search/searchActions';

const actions = [
    globalActions, inboxActions, searchActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class RejectInfo extends Component {
    constructor(props) {
        super(props);

        this.state = {
            //loading: true,
            numOfUnreadSupportMessage: 0,
        };
    }

    componentDidMount() {
        Intercom.addEventListener(Intercom.Notifications.UNREAD_COUNT);
    }

    componentWillUnmount() {
        Intercom.removeEventListener(Intercom.Notifications.UNREAD_COUNT);
    }

    _renderHeaderAds() {
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                    //disabled={this.state.loading}
                >
                    <RelandIcon name="close" color="#fff" size={15}
                                mainProps={{paddingLeft: 0, paddingRight: 0, paddingTop: 8}}
                                noAction={true}
                    />
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 17}]}>
                       Lý do
                    </ScalableText>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        // this.setState({loading: true});
        Actions.pop();
    }

    render() {
        return (
            <View style={{flex: 1}}>
                {this._renderHeaderAds()}
                <FullLine/>
                {this._renderBodyReject()}
            </View>
        );
    }

    _renderBodyReject() {
        let rowData = this.props.dataReject;
        let lyDoTuChoi = rowData.lyDoTuChoi || rowData.landberInfo.lyDoTuChoi || '' ;
        lyDoTuChoi = lyDoTuChoi.trim();
        let extraCharacter = lyDoTuChoi.length > 0 && lyDoTuChoi[lyDoTuChoi.length - 1] != '.' ? '.' : '';
        let textModule = 'Tin đăng của bạn bị từ chối. ';
        let textConfirm = lyDoTuChoi ? lyDoTuChoi + extraCharacter : textModule;
        let textCheck = `${textConfirm}`;
        return(
            <View style={styles.viewBody}>
                <View style={styles.viewReject}>
                    <Text style={styles.textReject}>{textCheck}</Text>
                </View>
                {this._renderSupportChatButton()}
            </View>
        );
    }

    _renderSupportChatButton() {
        let supportUri = require('../../assets/image/logo.png');
        return (
            <View style={styles.supportChatView}>
                <TouchableOpacity onPress={this._onDisplayMessenger.bind(this)}>
                    <View style={styles.viewChatSupport}>
                        <View style={styles.supportIconView} >
                            <Image
                                style={styles.supportIcon}
                                resizeMode={Image.resizeMode.cover}
                                source={supportUri}
                            />
                        </View>
                        <View style={{flexDirection: 'column'}}>
                            <ScalableText style={styles.contentTitle}>
                                Chăm sóc khách hàng
                            </ScalableText>
                            <ScalableText style={styles.contentText}>
                                Bạn cần hỗ trợ? Hãy chat với chúng tôi ở đây
                            </ScalableText>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    _onDisplayMessenger() {
        try {
            if (!this.props.global.loggedIn) {
                Intercom.reset().then(() => {
                    Intercom.registerUnidentifiedUser()
                        .then(() => {
                            Intercom.displayMessenger();
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            } else {
                let userID = this.props.global.currentUser.userID || undefined;
                let email = this.props.global.currentUser.email || undefined;
                let phone = this.props.global.currentUser.phone || undefined;
                let name = this.props.global.currentUser.username || undefined;
                let fullName = this.props.global.currentUser.fullName || undefined;
                if (fullName) {
                    name = fullName;
                }
                let avatar = this.props.global.currentUser.avatar || undefined;
                Intercom.reset().then(() => {
                    Intercom.registerIdentifiedUser({ userId: userID })
                        .then(() => {
                            log.info('registerIdentifiedUser done');

                            return Intercom.updateUser({
                                email: email,
                                phone: phone,
                                name: name,
                                avatar: { type: 'avatar', image_url: avatar }
                            })
                                .then(() => {
                                    Intercom.displayMessenger();
                                });
                        })
                        .catch((err) => {
                            log.error('registerIdentifiedUser ERROR', err);
                        });
                });
            }

        } catch (error) {
            log.warn('========== onDisplayMessenger ERROR', error);
        }
    }


}
export default connect(mapStateToProps, mapDispatchToProps) (RejectInfo);

const styles = StyleSheet.create({
    pageHeader: {
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewReject: {
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingLeft: 17,
        paddingRight: 6,
        paddingTop: 10,
        paddingBottom: 10
    },
    textReject:{
        fontSize:15,
        fontFamily:gui.fontFamily,
        color:'#24211f',
        fontWeight: '400',
        textAlign: 'left'
    },
    supportChatView: {
        height: 72,
        width: width,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'flex-start',
        borderBottomWidth: 1,
        borderTopWidth: 1,
        borderColor: '#dcdcdc'
    },
    supportIconView: {
        height: 40,
        width: 40,
        borderRadius: 20,
        marginRight: 5,
        marginLeft: 8,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor
    },
    supportIcon: {
        height: 8,
        width: 33
    },
    contentTitle: {
        textAlign: 'left',
        alignItems: 'flex-start',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: '600'
    },
    contentText: {
        textAlign: 'left',
        alignItems: 'flex-start',
        fontSize: 11,
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontWeight: 'normal',
    },
    viewChatSupport: {
        flexDirection: 'row',
        width: width,
        height: 72,
        backgroundColor: 'transparent',
        justifyContent: 'flex-start',
        alignItems: 'center'
    }
});