'use strict';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';

import React, { Component } from 'react';

import {
    Text, View, StyleSheet, TextInput, StatusBar,
    TouchableHighlight, Image, Picker, Alert, ScrollView, TouchableOpacity
} from 'react-native'

import TruliaIcon from '../TruliaIcon';

import { Map } from 'immutable';
import { Actions } from 'react-native-router-flux';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";

import danhMuc from "../../assets/DanhMuc";

import FullLine from '../line/FullLine';

import util from "../../lib/utils";

import SegmentedControl from '../SegmentedControlSelector';

import MChartView from '../MChartView';

import GiftedSpinner from 'react-native-gifted-spinner';

import dismissKeyboard from 'react-native-dismiss-keyboard';
import KeyboardSpacer from 'react-native-keyboard-spacer';

import ScalableText from 'react-native-text';

const { width, height } = util.getDimensions();

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const actions = [
    globalActions,
    postAdsActions,
    adsMgmtActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class PackageUpdater extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('dark-content');

        this.state = {
            main: props.global.currentUser.account.main,
            bonus: props.global.currentUser.account.bonus,
            used: 0,
            allServices: [],
            giamGia: 0,
            enoughMoney: false,
            requireUpdate: false,
            toggleKeyboard: false
        }
    }

    componentWillMount() {
        this.props.actions.findAllService().then(e => {
            if (e.status == 0) {
                let allViTriService = e.services.filter((e) => {
                    return e.category == "Vị trí"
                }).sort((a, b) => b.level - a.level);
                this.setState({ allServices: allViTriService });
            }
        });
    }

    _getTitle() {
        return "Gói tin VỊ TRÍ";
    }

    _renderMoneyLine(label, value, dotColor) {
        return (
            <View style={{ flexDirection: 'row' }}>
                <View style={[myStyles.dot, { borderColor: dotColor }]}>
                </View>
                <View style={{ flexDirection: 'column', marginTop: 5, marginBottom: 5 }}>
                    <ScalableText style={{ fontSize: 14, fontFamily: gui.fontFamily, fontWeight: 'bold' }}>
                        {value}
                    </ScalableText>
                    <ScalableText style={{ fontSize: 12, fontFamily: gui.fontFamily, color: '#a3a3a3' }}>
                        {label}
                    </ScalableText>
                </View>
            </View>
        )
    }

    _renderTitleLine(value) {
        return (
            <View>
                <FullLine />
                <View style={myStyles.viewTitleUpdate}>
                    <Text style={myStyles.textTitleUpdate}>
                        {value}
                    </Text>
                </View>
                <FullLine />
            </View>
        );
    }

    _renderGoiTin() {
        let goiTinContent = [
            'Tin',
            {
                packageName: ' VIP Vàng',
                packageDesc: ' hiển thị ở trên tất cả các loại tin khác, được hưởng nhiều ưu tiên và hiệu quả giao dịch cao nhất.'
            },
            {
                packageName: ' VIP Bạc',
                packageDesc: ' hiển thị bên dưới Tin VIP Vàng và trên tất cả các loại tin khác.'
            },
            {
                packageName: ' VIP Đồng',
                packageDesc: ' hiển thị bên dưới các tin VIP Bạc.'
            },
            {
                packageName: ' Thường',
                packageDesc: ' hiển thị bên dưới các tin VIP.'
            },
            'Giá cước tính theo ngày: '
        ];

        let service = this.state.allServices;
        let normalPricePerDay = service.length > 0 ? util.addCommas((service[0].fees[0].price) / service[0].fees[0].soLanSuDung) : '1,000';
        let dongPricePerDay = service.length > 0 ? util.addCommas((service[1].fees[0].price) / service[1].fees[0].soLanSuDung) : '10,000';
        let bacPricePerDay = service.length > 0 ? util.addCommas((service[2].fees[0].price) / service[2].fees[0].soLanSuDung) : '40,000';
        let vangPricePerDay = service.length > 0 ? util.addCommas((service[3].fees[0].price) / service[3].fees[0].soLanSuDung) : '95,000';
        return (
            <View style={{ flex: 1 }}>
                <FullLine />
                <View style={myStyles.viewTitleUpdate}>
                    <View style={myStyles.viewTitleTop}>
                        <Text style={myStyles.textTitleUpdate}>
                            {goiTinContent[0]}
                            <Text style={[myStyles.textTitleUpdate, { fontWeight: '500' }]}>{goiTinContent[1].packageName}</Text>
                            <Text style={myStyles.textTitleUpdate}>{goiTinContent[1].packageDesc}</Text>
                        </Text>
                    </View>
                    <Text style={[myStyles.textTitleUpdate, { marginTop: 3 }]}>Được làm mới tin không giới hạn</Text>
                    <Text style={myStyles.textTitleUpdate}>Được gửi tin đăng đến người cần mua 10 lần/ngày</Text>
                    <Text style={myStyles.textTitleUpdate}>{goiTinContent[5]}{vangPricePerDay} {danhMuc.VND}</Text>
                </View>
                <FullLine />
                <View style={myStyles.viewTitleUpdate}>
                    <View style={myStyles.viewTitleTop}>
                        <Text style={myStyles.textTitleUpdate}>
                            {goiTinContent[0]}
                            <Text style={[myStyles.textTitleUpdate, { fontWeight: '500' }]}>{goiTinContent[2].packageName}</Text>
                            <Text style={myStyles.textTitleUpdate}>{goiTinContent[2].packageDesc}</Text>
                        </Text>
                    </View>
                    <Text style={[myStyles.textTitleUpdate, { marginTop: 3 }]}>Được làm mới tin 3 lần/ngày</Text>
                    <Text style={myStyles.textTitleUpdate}>Được gửi tin đăng đến người cần mua 2 lần/ngày</Text>
                    <Text style={myStyles.textTitleUpdate}>{goiTinContent[5]}{bacPricePerDay} {danhMuc.VND}</Text>
                </View>
                <FullLine />
                <View style={myStyles.viewTitleUpdate}>
                    <View style={myStyles.viewTitleTop}>
                        <Text style={myStyles.textTitleUpdate}>
                            {goiTinContent[0]}
                            <Text style={[myStyles.textTitleUpdate, { fontWeight: '500' }]}>{goiTinContent[3].packageName}</Text>
                            <Text style={myStyles.textTitleUpdate}>{goiTinContent[3].packageDesc}</Text>
                        </Text>
                    </View>
                    <Text style={[myStyles.textTitleUpdate, { marginTop: 3 }]}>Được làm mới tin 1 lần/ngày</Text>
                    <Text style={myStyles.textTitleUpdate}>{goiTinContent[5]}{dongPricePerDay} {danhMuc.VND}</Text>
                </View>
                <FullLine />
                <View style={myStyles.viewTitleUpdate}>
                    <View style={myStyles.viewTitleTop}>
                        <Text style={myStyles.textTitleUpdate}>
                            {goiTinContent[0]}
                            <Text style={[myStyles.textTitleUpdate, { fontWeight: '500' }]}>{goiTinContent[4].packageName}</Text>
                            <Text style={myStyles.textTitleUpdate}>{goiTinContent[4].packageDesc}</Text>
                        </Text>
                    </View>
                    <Text style={[myStyles.textTitleUpdate, { marginTop: 3 }]}>Được làm mới tin 2 ngày 1 lần</Text>
                    <Text style={myStyles.textTitleUpdate}>{goiTinContent[5]}{normalPricePerDay} {danhMuc.VND}</Text>
                </View>
            </View>
        );
    }

    renderUpdated() {
        return (
            this.props.adsMgmt.upgradingAds ?
                <View style={myStyles.viewButtonUpdate}>
                    <GiftedSpinner color="white" />
                </View> :
                <TouchableOpacity style={myStyles.viewButtonUpdate}
                    onPress={this.onApply.bind(this)}
                >
                    <Text style={myStyles.textUpdate}>Nâng cấp</Text>
                </TouchableOpacity>
        );
    }

    _getCurrentLevelName() {
        let current = this.props.adsMgmt.package.packageSelected;
        let levelName = this.props.adsMgmt.package[current].levelName;

        return levelName;
    }

    _getCurrentLength() {
        let current = this.props.adsMgmt.package.packageSelected;
        let length = this.props.adsMgmt.package[current].lengthName;

        return length;
    }

    _getCurrentLengthIndex() {
        let lengthName = this._getCurrentLength();
        let lengthVal = danhMuc.package.getLength(lengthName);
        let lengths = danhMuc.goiTin;
        let index = -1;
        for (var i = 0; i < lengths.length; i++) {
            if (lengthVal == Number(lengths[i])) {
                index = i;
                break;
            }
        }
        if (this.state.requireUpdate) {
            index = -1;
        }
        return index;
    }

    _renderPackageLine(title, value, onPress) {
        return (
            <TouchableHighlight
                onPress={onPress}>
                <View style={[myStyles.selectLine, myStyles.headerSeparator]}>
                    <Text style={myStyles.label}>
                        {title}
                    </Text>
                    <View style={myStyles.arrowIcon}>
                        <Text style={myStyles.label}> {value} </Text>
                        <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                    </View>
                </View>
            </TouchableHighlight>
        );
    }

    _onLevelSelect(val) {
        this.props.actions.onSelectedPackageFieldChange("levelName", val);
    }

    _renderPackageSession(levelName, levelComment) {
        let isSelectedLevel = this._getCurrentLevelName() == levelName;
        let checkColor = isSelectedLevel ? gui.mainColor : '#9f9f9f';
        let service = this.state.allServices.filter((e) => {
            return e.name == levelName;
        });

        if (!service || service.length == 0) {
            return;
        }

        let ngaySuDung = service[0].fees.map((e) => {
            return e.soLanSuDung;
        });

        let ngayVip = ngaySuDung.map((e) => {
            return e.toString();
        });
        return (
            <View style={myStyles.viewLabel} key={levelName}>
                {this._renderSegment(levelName, ngayVip, isSelectedLevel ? this._getCurrentLengthIndex() : -1,
                    this._onSegmentChanged.bind(this, levelName), checkColor)}
                {levelComment ?
                    <View style={myStyles.viewTitleUpdate}>
                        <Text style={myStyles.label}> {levelComment} </Text>
                    </View>
                    : null
                }
            </View>
        );
    }

    _onSegmentChanged(levelName, index) {
        this._onLevelSelect(levelName);
        // let lengthIndex = event.nativeEvent.selectedSegmentIndex;
        let lengthName = '0 ngày';
        let lengthVal = 0;
        if (index > -1) {
            lengthVal = Number(danhMuc.goiTin[index]);
            lengthName = danhMuc.package.length[lengthVal];
        }

        let service = this.state.allServices.filter((e) => {
            return e.name == levelName;
        });

        // Cannot read property 'fees' of undefined

        if (!service || service.length == 0) {
            return;
        }

        let fee = service[0].fees.filter((e) => {
            return e.soLanSuDung == lengthVal;
        });

        let price = fee[0].price;
        let account = this.props.global.currentUser.account;
        let main = account.main || 0;
        let bonus = account.bonus || 0;
        let sumOfAccount = main + bonus;

        let lackMoney = price - sumOfAccount;
        if (lackMoney > 0) {
            let newPackageInfo = levelName + " có thời hạn sử dụng " + lengthVal + ' ngày';
            // Alert.alert("Thông báo", "Tài khoản của bạn không đủ để sử dụng gói dịch vụ này");
            Alert.alert(
                'Thông báo',
                'Tài khoản của bạn không đủ để sử dụng gói dịch vụ ' + newPackageInfo + '. Bạn cần nạp thêm ' + util.addCommas(lackMoney) + ' ' + danhMuc.VND + '?',
                [
                    { text: 'Hủy', onPress: () => this.setState({ used: 0, giamGia: 0 }) },
                    {
                        text: 'Đồng ý', onPress: () => {
                            Actions.MoneyInPayment();
                        }
                    }
                ]
            );
            this.setState({
                requireUpdate: true, enoughMoney: false, lackMoney: lackMoney
            });

            return;
        }

        this.props.actions.onSelectedPackageFieldChange("lengthName", lengthName);
        this.props.actions.onSelectedPackageFieldChange("length", lengthVal);
        this.setState({ requireUpdate: false, enoughMoney: true, lackMoney: 0, used: fee[0].price, giamGia: fee[0].discount });
    }

    _renderSegment(label, values, selectedIndexAttribute, onChange, checkColor) {
        return (
            <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                onChange={onChange} checkColor={checkColor} />
        );
    }

    onApply() {

        if (this._getCurrentLengthIndex() < 0) {
            Alert.alert("Thông báo", "Bạn chưa chọn gói dịch vụ nào");
            return;
        }

        let newPackage = this._getNewPackage();
        let newPackageInfo = newPackage.levelName + " có thời hạn sử dụng " + newPackage.length + ' ngày';

        if (!this.state.enoughMoney) {
            // Alert.alert("Thông báo", "Tài khoản của bạn không đủ để sử dụng gói dịch vụ này");
            Alert.alert(
                'Thông báo',
                'Tài khoản của bạn không đủ để sử dụng gói dịch vụ ' + newPackageInfo + '. Bạn cần nạp thêm ' + util.addCommas(this.state.lackMoney) + ' ' + danhMuc.VND + '?',
                [
                    { text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
                    {
                        text: 'Đồng ý', onPress: () => {
                            Actions.MoneyInPayment();
                        }
                    }
                ]
            );
            return;
        }

        let oldPackage = this._getOldPackage();

        if (Object.keys(oldPackage).length > 0 && oldPackage.length > 0
            && oldPackage.levelName == newPackage.levelName
            && oldPackage.length >= newPackage.length) {
            Alert.alert(
                'Thông báo',
                'Bạn đang chọn gói nâng cấp trùng với gói đang sử dụng hiện tại, thời hạn sử dụng còn ' + oldPackage.length + ' ngày.',
                [
                    { text: 'Đóng', onPress: () => { } }
                ]
            );
            return;
        }
        let oldPackageInfo = Object.keys(oldPackage).length > 0 && oldPackage.length > 0 ?
            oldPackage.levelName + " thời hạn sử dụng còn " + oldPackage.length + ' ngày' : '';
        let msgLabel = oldPackageInfo ?
            'Bạn đang sử dụng gói ' + oldPackageInfo + '. Bạn có thật sự muốn thực hiện tiếp và gói hiện tại sẽ bị xoá?'
            : 'Bạn đồng ý mua gói dịch vụ ' + newPackageInfo + '?';
        Alert.alert(
            'Thông báo', msgLabel,
            [
                { text: 'Hủy', onPress: () => log.info('Cancel Pressed!') },
                {
                    text: 'Đồng ý', onPress: () => {
                        // this.props.actions.buyCurrentPackage(this.props.adsMgmt.package, this.props.global.currentUser.userID);
                        let service = this.state.allServices.filter((e) => {
                            return e.name == this.props.adsMgmt.package.goiViTri.levelName;
                        });

                        let couponCode = this.state.couponCode;

                        if (couponCode && couponCode.length > 0) {
                            let couponDto = {
                                serviceType: 1,
                                couponCode: couponCode,
                                serviceID: service[0].id
                            }

                            this._verifyCouponCode(couponDto, this._doAfterVerifyCouponVip.bind(this, couponCode));
                        } else {
                            this._doOrderService();
                        }

                    }
                }
            ]
        )
    }

    _doOrderService(couponCode) {
        let service = this.state.allServices.filter((e) => {
            return e.name == this.props.adsMgmt.package.goiViTri.levelName;
        });

        let fee = service[0].fees.filter((e) => {
            return e.soLanSuDung == this.props.adsMgmt.package.goiViTri.length;
        });

        let serviceOrder = {
            userID: this.props.global.currentUser.userID,
            //adsID: this.props.adsMgmt.package.adsID,
            ads: {
                id: this.props.adsMgmt.package.adsID,
                cover: this.props.adsMgmt.package.ads.image ? this.props.adsMgmt.package.ads.image.cover : undefined
            },
            workstation:
                {
                    name: this.props.global.deviceInfo.deviceModel,
                    workstationID: this.props.global.deviceInfo.deviceID,
                    appType: 'app'
                },
            price: {
                discount: fee[0].discount,
                price: fee[0].price,
                soLanSuDung: fee[0].soLanSuDung,
                type: fee[0].type
            },
            service: {
                id: service[0].id,
                name: service[0].name,
                level: service[0].level,
                //days: fee[0].soLanSuDung,
                packageType: 1,
                couponCode: couponCode || undefined
            },
            action: this.props.action
        };

        let vitriCurrentChose = this.props.adsMgmt.package.goiViTri.levelName;

        this.props.actions.orderService(serviceOrder, this.props.global.currentUser.token).then((e) => {
            if (e.status == 0) {
                setTimeout(() => {
                    this.props.doViTriFinalAction && this.props.doViTriFinalAction();
                }, 300);
                Alert.alert("Thông báo", `Nâng cấp thành công gói ${vitriCurrentChose}!`,
                    [{
                        text: 'Đóng', onPress: () => {
                            Actions.pop();
                            Actions.pop();
                        }
                    }]);
            } else {
                log.warn("PackageUpdater.onApply , result: ", e);
                Alert.alert("Thông báo", e.msg);
            }

        });
    }

    _doAfterVerifyCouponVip(couponCode, res) {
        if (res.status !== 0) {
            let msg = res.msg + '. Bạn có tiếp tục đăng tin?';
            Alert.alert('Thông báo', msg,
                [{
                    text: 'Huỷ', onPress: () => { }
                },
                {
                    text: 'Đồng ý', onPress: () => {
                        this._doOrderService();
                    }
                }
                ]);
        } else {
            let msg = res.msg + '. Bạn chắc chắn sử dụng mã khuyến mại này?';
            Alert.alert('Thông báo', msg,
                [{
                    text: 'Huỷ', onPress: () => { }
                },
                {
                    text: 'Đồng ý', onPress: () => {
                        this._doOrderService(couponCode);
                    }
                }
                ]);
        }
    }

    _verifyCouponCode(couponDto, callback) {
        let currentUser = this.props.global.currentUser;
        this.props.actions.checkCouponHieuLuc(couponDto, currentUser.token).then(
            (res) => {
                callback(res);
            });
    }

    _getOldPackage() {
        let { ads } = this.props.adsMgmt.package;
        let goiViTri = ads && ads.landberInfo && ads.landberInfo.goiViTri;
        if (!goiViTri) {
            return {};
        }
        let levelName = util.getLevelName(goiViTri);
        let remainDays = util.getRemainDay(goiViTri);
        return { levelName: levelName, length: remainDays };
    }

    _getNewPackage() {
        return this.props.adsMgmt.package.goiViTri;
    }

    render() {
        let packageNames = ['Tin Thường', 'VIP Đồng', 'VIP Bạc', 'VIP Vàng'];
        let packageComments = ['',
            '',
            ''];
        let packageSessions = [];
        for (let i = 0; i < packageNames.length; i++) {
            packageSessions.push(this._renderPackageSession(packageNames[i], packageComments[i]));
        }

        let main = this.props.global.currentUser.account.main ? this.props.global.currentUser.account.main : 0;
        let bonus = this.props.global.currentUser.account.bonus ? this.props.global.currentUser.account.bonus : 0;
        let used = this.state.used;

        let bonusLeft = bonus - used;
        let mainLeft = bonusLeft < 0 ? main + bonusLeft : main;

        let data = [];
        let pallete = [];

        if (mainLeft > 0) {
            data.push({
                "name": "",
                "fillColor": gui.mainColor,
                "value": mainLeft
            });
            pallete.push(util.hexToRgb(gui.mainColor));
        }

        if (bonusLeft > 0) {
            data.push({
                "name": "",
                "fillColor": "#DE6207",
                "value": bonusLeft
            });
            pallete.push(util.hexToRgb("#DE6207"));
        }

        if (used > 0) {
            data.push({
                "name": "",
                "fillColor": "#a6a4a4",
                "value": used
            });
            pallete.push(util.hexToRgb("#a6a4a4"));
        }

        let options = {
            margin: {
                top: 2,
                left: 2,
                bottom: 2,
                right: 2
            },
            width: 148,
            height: 148,
            r: 58,
            R: 73,
            legendPosition: 'topLeft',
            animate: {
                type: 'oneByOne',
                duration: 200,
                fillTransition: 3
            },
            label: {
                fontFamily: gui.fontFamily,
                fontSize: gui.buttonFontSize,
                fontWeight: 'normal'
            }
        };

        let chartTitle = 'Tổng tài khoản';
        let chartTitleBold = `${util.getPriceText(main + bonus)}`;
        return (
            <View style={myStyles.container}>
                <View style={myStyles.customPageHeader}>
                    <TouchableOpacity style={myStyles.viewPlusPost}
                                      onPress={this._onBack.bind(this)}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
                    </TouchableOpacity>
                    <View style={myStyles.customPageTitle}>
                        <Text style={myStyles.customPageTitleText}>
                            {this._getTitle()}
                        </Text>
                    </View>
                    <View style={myStyles.viewPlusPost}>
                    </View>
                </View>
                <FullLine />

                <ScrollView
                    ref={(scrollView) => { this._scrollView = scrollView; }}
                    automaticallyAdjustContentInsets={false}
                    showsVerticalScrollIndicator={false}
                    onLayout={event => {
                        this._scrollViewHeight = event.nativeEvent.layout.y
                    }}
                    vertical={true}
                    style={[myStyles.scrollView]}
                //onScroll={this.handleScroll.bind(this)}
                //scrollEventThrottle={1}
                >
                    <View style={myStyles.viewScrollBody}>
                        {this._renderTitleLine("TÀI KHOẢN VÀ PHÍ DỊCH VỤ")}
                        <View style={myStyles.viewChartContent}>
                            <View style={[myStyles.viewChartLeft, { width: width / 2 }]}>
                                <MChartView
                                    data={data}
                                    options={options}
                                    pallete={pallete}
                                    chartTitle={chartTitle}
                                    chartTitleBold={chartTitleBold}
                                />
                            </View>

                            <View style={[myStyles.viewChartLeft, { width: width / 2, paddingLeft: 6, marginRight: 10 }]}>
                                {/*{this._renderMoneyLine("Tài khoản chính", `${util.convertPriceToComa(mainLeft) + ' ' + danhMuc.NGHIN}`, '#1396E0')}*/}
                                {/*{this._renderMoneyLine("Tài khoản phụ", `${bonusLeft>0 ? util.convertPriceToComa(bonusLeft) + ' ' + danhMuc.NGHIN : '0 ' + danhMuc.NGHIN}`, '#DE6207')}*/}
                                {this._renderMoneyLine(`Phí dịch vụ${this.state.giamGia ? "\nGiảm giá " + this.state.giamGia + "%" : "\n"}`
                                    , `${util.getPriceText(used)}`, '#a6a4a4')}

                            </View>
                        </View>
                        {this._renderTitleLine("CÁC GÓI TIN (Tính theo ngày)")}
                        {packageSessions}
                        {this._renderCouponCode()}
                        {this._renderGoiTin()}

                    </View>
                </ScrollView>
                {this.renderUpdated()}
                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)} />
            </View>
        )
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    _renderCouponCode() {
        let labelColor = '#313131';
        let couponLabel = 'Nhập mã khuyến mại nâng cấp tin:';
        let couponPlaceholder = 'Mã khuyến mại';
        return (
            <View style={{ marginTop: 8, marginBottom: 8, width: width, alignItems: 'flex-start' }}>
                <Text style={[myStyles.couponLabel, { color: labelColor }]} >{couponLabel}</Text>
                <TextInput style={myStyles.couponInput}
                    placeholder={couponPlaceholder}
                    placeholderTextColor={gui.arrowColor}
                    value={this.state.couponCode}
                    onChangeText={(text) => this.setState({ couponCode: text })}
                    maxLength={6}
                    autoCorrect={false}
                    autoCapitalize={'characters'}
                    returnKeyType='done'
                    onSubmitEditing={() => dismissKeyboard()}
                    onFocus={() => this._onCouponCodeFocus()}
                />
            </View>
        );
    }

    _onCouponCodeFocus() {
        if (this._scrollView) {
            var scrollTo = this._scrollViewHeight + height / 3;
            this._scrollView.scrollTo({ y: scrollTo });
        }
    }

    _onBack() {
        Actions.pop();
    }

}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: '#f6f6f6'
    },
    headerSeparator: {
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    customPageHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor: '#fff',
        width: width,
        height: 64
    },
    customPageTitle: {
         flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 18
    },
    customPageTitleText: {
        color: gui.textAgentSolid,
        fontSize: 17,
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        textAlign: 'center'
    },
    backButton: {
        marginTop: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        paddingLeft: 18,
        paddingRight: 18
    },
    backButtonText: {
        color: 'white',
        fontSize: gui.normalFontSize,
        fontFamily: gui.fontFamily,
        textAlign: 'left',
        marginLeft: 7
    },

    label: {
        fontFamily: gui.fontFamily,
        fontSize: 12,
        fontWeight: '300',
        color: '#8A8A8A'
    },
    viewLabel: {
        width: width,
        justifyContent: 'center',
        alignItems: 'flex-start',

    },

    introText: {
        fontSize: 14,
        fontFamily: gui.fontFamily,
        color: '#8A8A8A',
        paddingLeft: 19,
        paddingRight: 19,
        paddingTop: 10,

    },

    picker: {
        backgroundColor: 'white',
    },

    pickerItem: {
        fontSize: 11,
        fontFamily: gui.fontFamily,
    },
    selectLine: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: 17,
        paddingRight: 10,
        backgroundColor: 'white',
        paddingTop: 8,
        paddingBottom: 8
    },

    arrowIcon: {
        flexDirection: "row",
        alignItems: "flex-end",
        paddingRight: 4
    },

    dot: {
        width: 20,
        height: 20,
        borderRadius: 10,
        marginRight: 10,
        marginTop: 10,
        backgroundColor: 'white',
        borderWidth: 5
    },
    scrollView: {
        flex: 1,
        backgroundColor: 'white',
        // marginBottom: 43
    },
    viewButtonUpdate: {
        // position:'absolute',
        // bottom: 0,
        backgroundColor: gui.mainColor,
        marginBottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 43
    },
    textUpdate: {
        fontSize: 16,
        color: '#fff',
        fontWeight: '400',
        fontFamily: gui.fontFamily
    },
    viewScrollBody: {
        flex: 1,
        alignItems: 'center'
    },
    viewTitleUpdate: {
        width: width,
        justifyContent: 'space-between',
        paddingRight: 15,
        paddingLeft: 15,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8f8f8'
    },
    viewBodyContentLogo: {
        width: width,
        marginBottom: 10
    },
    viewTitleTop: {
        flexDirection: 'row',
        width: width - 30,

    },
    textTitleUpdate: {
        fontSize: 12,
        fontFamily: gui.fontFamily,
        color: '#313131',
        justifyContent: 'space-between',
        padding: 0,
        fontWeight: "300"
    },
    viewChartContent: {
        flexDirection: "row",
        justifyContent: 'flex-start',
        backgroundColor: 'white',
        width: width,
        height: 162
    },
    viewChartLeft: {
        paddingLeft: 13,
        width: width / 2,
        height: 162,
        alignItems: 'center',
        justifyContent: 'center'
    },
    couponLabel: {
        fontSize: 14,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        paddingLeft: 15
    },
    couponInput: {
        fontSize: 14,
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        width: 200,
        height: 38,
        borderWidth: 1,
        borderColor: 'lightgray',
        borderRadius: 5,
        padding: 5,
        marginLeft: 15,
        marginTop: 5,
        marginBottom: 5
    },
    viewPlusPost: {
        height: 64,
        width: 60,
        justifyContent: 'center',
        paddingLeft: 12,
        paddingTop: 18
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(PackageUpdater);

