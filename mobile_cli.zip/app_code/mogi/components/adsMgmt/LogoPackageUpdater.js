'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as meActions from '../../reducers/me/meActions';

import React, {Component} from 'react';

import {Text, View, StyleSheet, TextInput, StatusBar, ImageBackground,
  TouchableHighlight, Image, Picker, Alert, ScrollView, TouchableOpacity} from 'react-native'

import TruliaIcon from '../TruliaIcon';

import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';
import log from "../../lib/logUtil";
import gui from "../../lib/gui";
import LinearGradient from 'react-native-linear-gradient';

import CommonUtils from '../../lib/CommonUtils';

import danhMuc from "../../assets/DanhMuc";

import util from "../../lib/utils";

import SegmentedControl from '../SegmentedControlSelector';

import MChartView from '../MChartView';

import FullLine from '../line/FullLine';

import ScalableText from 'react-native-text';

import GiftedSpinner from 'react-native-gifted-spinner';

const {width, height} = util.getDimensions();
const imgHeight = 181;

const actions = [
  globalActions,
  adsMgmtActions,
  meActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class LogoPackageUpdater extends Component {
  constructor(props) {
    super(props);
    StatusBar.setBarStyle('light-content');

    this.state = {
      main: props.global.currentUser.account.main,
      bonus: props.global.currentUser.account.bonus,
      used: 0,
      allServices: [],
      giamGia:0,
      enoughMoney: false,
      currentLogo: '',
      requireUpdate: false
    }
  }

  componentWillMount() {
    this.props.actions.findAllService().then( e => {
      if (e.status ==0 ){
        let allViTriService = e.services.filter( (e) => {
          return e.category == "Logo"
        });
        this.setState({allServices: allViTriService});
      }
    });
  }

  _getTitle() {
    return "Gói Logo";
  }

  _renderMoneyLine(label, value, dotColor) {
    return (
      <View style={{flexDirection:'row'}}>
        <View style={[myStyles.dot, {borderColor: dotColor}]}>
        </View>
        <View style={{flexDirection:'column', marginTop: 5, marginBottom: 5}}>
          <ScalableText style={{fontSize: 15, fontFamily: gui.fontFamily, fontWeight: 'bold'}}>
            {value}
          </ScalableText>
          <ScalableText style={{fontSize: 12, fontFamily: gui.fontFamily, color: '#a3a3a3'}}>
            {label}
          </ScalableText>
        </View>
      </View>
    )
  }

  _renderTitleLine(value) {
    return (
        <View>
            <FullLine />
            <View style={myStyles.viewTitleUpdate}>
              <Text style = {myStyles.textTitleUpdate}>
                  {value}
              </Text>
            </View>
            <FullLine />
        </View>
    );
  }

    _renderUpdated(){
        return(
            this.props.adsMgmt.upgradingAds ?
                <View style={myStyles.viewButtonUpdate}>
                    <GiftedSpinner color="white" />
                </View> :
                <TouchableOpacity style={myStyles.viewButtonUpdate}
                              onPress = {this.onApply.bind(this)}
                >
                  <Text style={myStyles.textUpdate}>Nâng cấp</Text>
                </TouchableOpacity>
        );
    }

    _renderTextBody() {
        let service = this.state.allServices;
        let canBanGapPerDay = service.length > 0 ? util.addCommas((service[0].fees[0].price)/7) : '5,000';
        let goiCuocText = 'Giá cước theo ngày: ';
        let goiLogoText = 'Thêm logo sẽ giúp thu hút sự chú ý của người dùng và giúp bạn bán nhà nhanh hơn.';
        return(
            <View>
                <FullLine/>
                <View style={myStyles.viewTitleUpdate}>
                    <Text style={myStyles.textTitleUpdate}>{goiCuocText}{canBanGapPerDay} {danhMuc.VND}</Text>
                    <Text style={[myStyles.textTitleUpdate, {marginTop: 6}]}>{goiLogoText}</Text>
                </View>
                <FullLine/>
            </View>

        );
    }

    _renderTextUpgraded(){
      //let addLogo = 'Thêm logo';
      //let sellUrgent = '\"Cần bán gấp\"';
      //let addTextHelp = 'Thêm logo sẽ giúp thu hút sự chú ý của người dùng và giúp bạn bán nhà nhanh hơn';
      let logoAppear = 'Logo của bạn sẽ xuất hiện như hình bên dưới';


      return(
          <View style={myStyles.viewCenterText}>
            {/*<View style={myStyles.addLogoText} >*/}
              {/*<View style={myStyles.viewCircle}></View>*/}
              {/*<Text style={myStyles.textAddLogo}>{addLogo}</Text>*/}
              {/*<Text style={[myStyles.textAddLogo, {color: '#00a8e6', marginLeft: 3, fontWeight: '600'}]}>{sellUrgent}</Text>*/}
            {/*</View>*/}
            {/*<Text style={[myStyles.textAddLogo, {color: '#5a5a5a', marginLeft: 17, marginRight: 5}]}>{addTextHelp}</Text>*/}
            <Text style={[myStyles.textAddLogo, {color: gui.mainColor, marginLeft: 17, marginTop: 10}]}>{logoAppear}</Text>
              {this._renderLogoContent()}
          </View>
      );
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        var moreInfo = '';
        var loaiNhaDatKeys = loaiTin ? danhMuc.LoaiNhaDatThueKey : danhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = ' ' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = ' ' + dienTich + soTang;
        }
        else {
            moreInfo = ' ' + dienTich;
        }
        return moreInfo;
    }


    _renderLogoContent(){
     let {ads}  = this.props.adsMgmt.package;
      let loaiTin = ads.loaiTin;
      let diaChi = ads.diaChi || ads.place.diaChi || '';
      let originDiaChi = ads.diaChi || ads.place.diaChi || '';
      let loaiNhaDat = ads.loaiNhaDat;

        let dienTichText = '';
        let dienTichFmt = util.getDienTichDisplay(ads.dienTich);
        if (dienTichFmt && dienTichFmt != 'Không rõ') {
            dienTichText = '· ' + dienTichFmt;
        }
        let dienTich = ads.dienTichFmt && ads.dienTichFmt != 'Không rõ' ? '· ' + ads.dienTichFmt : dienTichText;

        let soPhongNgu = '';
        if (ads.soPhongNgu) {
            soPhongNgu = "   " + ads.soPhongNgu + "pn";
        }

        let soTang = '';
        if (ads.soTang) {
            soTang = "   " + ads.soTang + "t";
        }

        let gia = ads.giaFmt || util.getPriceDisplay(ads.gia, ads.loaiTin);

      let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);

      let maxDiaChiLength = width*7/64 - moreInfo.length;

      let index = diaChi.indexOf(',', maxDiaChiLength - 5);
      let length = 0;
      if (index !== -1 && index <= maxDiaChiLength) {
          length = index;
      } else {
          index = diaChi.indexOf(' ', maxDiaChiLength - 5);
          length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
      }
      diaChi = diaChi.substring(0, length);
      if (diaChi.length < originDiaChi.length) {
          diaChi = diaChi + '...';
      }

      return(
          <View style={myStyles.viewContentLogo}>
            <View key={ads.adsID} style={{flexDirection: 'column'}}>
              <View style={myStyles.detail}
                    onStartShouldSetResponder={(evt) => false}
                    onMoveShouldSetResponder={(evt) => false}>
                  {this.renderImageStack(ads)}
                  { this.state.currentLogo.length > 0 ?
                      (<View style={[myStyles.searchListViewRowAlign, {top: imgHeight / 2 - 11}]}>
                          <View style={myStyles.logoContainer}>
                              <ScalableText style={myStyles.logo}
                                            onStartShouldSetResponder={(evt) => false}
                                            onMoveShouldSetResponder={(evt) => false}
                              >{this.state.currentLogo.toUpperCase()}</ScalableText>
                          </View>
                      </View>) : null
                  }

                <View style={myStyles.searchListViewRowAlign}
                      onStartShouldSetResponder={(evt) => false}
                      onMoveShouldSetResponder={(evt) => false}
                >
                  <View
                      onStartShouldSetResponder={(evt) => false}
                      onMoveShouldSetResponder={(evt) => false}
                      pointerEvents="none"
                  >

                    <ScalableText style={myStyles.viewPrice}
                                  onStartShouldSetResponder={(evt) => false}
                                  onMoveShouldSetResponder={(evt) => false}
                    >{gia}</ScalableText>
                    <ScalableText style={myStyles.viewText}>{diaChi}{moreInfo}</ScalableText>
                  </View>
                </View>

              </View>
            </View>
          </View>
      );
  }

  renderImageStack(ads) {
        let imageIndex  = 0;
        if (ads.image) {
            if (ads.image.cover) {
                return (
                    <MyImage imageIndex={0} ads={ads} imageUrl={ads.image.cover} noCoverUrl={this.props.noCoverUrl}/>
                )
            } else if (ads.image.images && ads.image.images.length > 0) {
                return (
                    <MyImage imageIndex={0} ads={ads} imageUrl={ads.image.images[0]} noCoverUrl={this.props.noCoverUrl}/>
                );
            }

        } else {
            return (
                <MyImage imageIndex={0} ads={ads} imageUrl={this.props.noCoverUrl} noCoverUrl={this.props.noCoverUrl}/>
            );
        }
  }

  _getCurrentLevelName() {
    let current = this.props.adsMgmt.package.packageSelected;
    let levelName = this.props.adsMgmt.package[current].levelName;

    return levelName;
  }

  _getCurrentLength() {
    let current = this.props.adsMgmt.package.packageSelected;
    let length = this.props.adsMgmt.package[current].lengthName;

    return length;
  }

  _getCurrentLengthIndex() {
    let lengthName = this._getCurrentLength();
    let lengthVal = danhMuc.package.getLength(lengthName);
    let lengths = danhMuc.goiTin;
    let index = -1;
    for (var i = 0; i < lengths.length; i++) {
      if (lengthVal == Number(lengths[i])) {
        index = i;
        break;
      }
    }
    if (this.state.requireUpdate) {
       index = -1;
    }
    return index;
  }

  // _renderPackageLine(title, value, onPress) {
  //   return (
  //       <TouchableHighlight
  //         onPress={onPress}>
  //         <View style={[myStyles.selectLine, myStyles.headerSeparator]}>
  //           <Text style={myStyles.label}>
  //             {title}
  //           </Text>
  //           <View style={myStyles.arrowIcon}>
  //             <Text style={myStyles.label}> {value} </Text>
  //             <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
  //           </View>
  //         </View>
  //       </TouchableHighlight>
  //   );
  // }

  _onLevelSelect(val) {
    this.props.actions.onSelectedPackageFieldChange("levelName", val);
  }

  _renderPackageSession(levelName, levelComment) {
    let isSelectedLevel = this._getCurrentLevelName() == levelName;
    let checkColor = isSelectedLevel ? gui.mainColor : 'gray';
    let service = this.state.allServices.filter( (e) => {
       return e.name == levelName;
    });

    if (!service || service.length == 0) {
       return;
    }

    let ngaySuDung = service[0].fees.map( (e) => {
       return e.soLanSuDung;
    });

    let ngayLogo = ngaySuDung.map((e) => {
       return e.toString();
    });
    return (
        <View style={myStyles.viewLabel} key={levelName}>
          {this._renderSegment(levelName, ngayLogo, isSelectedLevel ? this._getCurrentLengthIndex() : -1,
              this._onSegmentChanged.bind(this, levelName), checkColor)}
          { levelComment ?
              <View style={myStyles.viewTitleUpdate}>
                <Text style={myStyles.label}> {levelComment} </Text>
              </View>
              : null
          }
        </View>
    );
  }

  _onSegmentChanged(levelName, index) {
    this._onLevelSelect(levelName);
    // let lengthIndex = event.nativeEvent.selectedSegmentIndex;
    let lengthName = '0 ngày';
    let lengthVal = 0;
    if (index > -1) {
      lengthVal = Number(danhMuc.goiTin[index]);
      lengthName = danhMuc.package.length[lengthVal];
    }


    let service = this.state.allServices.filter( (e) => {
      return e.name == levelName;
    });

    if (!service || service.length == 0) {
          return;
      }

    let fee = service[0].fees.filter( (e) => {
      return e.soLanSuDung == lengthVal;
    });

    let price =  fee[0].price;
    let account = this.props.global.currentUser.account;
    let main =  account.main || 0;
    let bonus = account.bonus || 0;
    let sumOfAccount = main + bonus;
    let lackMoney = price-sumOfAccount;
    if (lackMoney > 0) {
        let newPackageInfo = levelName + " có thời hạn sử dụng " + lengthVal + ' ngày';
     // Alert.alert("Thông báo", "Tài khoản của bạn không đủ để sử dụng gói dịch vụ này");
        Alert.alert(
            'Thông báo',
            'Tài khoản của bạn không đủ để sử dụng gói dịch vụ ' + newPackageInfo + '. Bạn cần nạp thêm ' + util.addCommas(lackMoney) + ' ' + danhMuc.VND + '?',
            [
                {text: 'Hủy', onPress: () => this.setState({used: 0, giamGia: 0})},
                {text: 'Đồng ý', onPress: () => {
                    Actions.MoneyInPayment();
                }}
            ]
        );
        this.setState({
            requireUpdate: true, enoughMoney: false, lackMoney: lackMoney
        });

        return;
    }

    this.props.actions.onSelectedPackageFieldChange("lengthName", lengthName);
    this.props.actions.onSelectedPackageFieldChange("length", lengthVal);
    this.setState({requireUpdate: false, enoughMoney: true, lackMoney: 0, used: fee[0].price, giamGia: fee[0].discount, currentLogo: levelName});
  }

  _renderSegment(label, values, selectedIndexAttribute, onChange, checkColor) {
    return (
        <SegmentedControl label={label} values={values} selectedIndexAttribute={selectedIndexAttribute}
                          onChange={onChange} checkColor={checkColor}
        />
    );
  }

  onApply() {
    if(this._getCurrentLengthIndex() < 0){
        Alert.alert("Thông báo", "Bạn chưa chọn gói dịch vụ nào");
        return;
    }

    let newPackage = this._getNewPackage();
    let newPackageInfo = newPackage.levelName + " có thời hạn sử dụng " + newPackage.length + ' ngày';

    if(!this.state.enoughMoney){
        //Alert.alert("Thông báo", "Tài khoản của bạn không đủ để sử dụng gói dịch vụ này");
        Alert.alert(
            'Thông báo',
            'Tài khoản của bạn không đủ để sử dụng gói dịch vụ ' + newPackageInfo + '. Bạn cần nạp thêm ' + util.addCommas(this.state.lackMoney) + ' ' + danhMuc.VND + '?',
            [
                {text: 'Hủy', onPress: () => log.info('Cancel Pressed!')},
                {text: 'Đồng ý', onPress: () => {
                Actions.MoneyInPayment();
                }}
            ]
        );
        return;
    }

      let oldPackage = this._getOldPackage();

      if (Object.keys(oldPackage).length > 0 && oldPackage.length > 0
          && oldPackage.levelName == newPackage.levelName
          && oldPackage.length >= newPackage.length) {
          Alert.alert(
              'Thông báo',
              'Bạn đang chọn gói nâng cấp trùng với gói đang sử dụng hiện tại, thời hạn sử dụng còn ' + oldPackage.length + ' ngày.',
              [
                  {text: 'Đóng', onPress: () => { }}
              ]
          );
          return;
      }
      let oldPackageInfo = Object.keys(oldPackage).length > 0 && oldPackage.length > 0 ?
                    oldPackage.levelName + " thời hạn sử dụng còn " + oldPackage.length + ' ngày' : '';
      let msgLabel = oldPackageInfo ?
            'Bạn đang sử dụng gói ' + oldPackageInfo + '. Bạn có thật sự muốn thực hiện tiếp và gói hiện tại sẽ bị xoá?'
          : 'Bạn đồng ý mua gói dịch vụ ' + newPackageInfo + '?';

    Alert.alert(
      'Thông báo', msgLabel,
      [
        {text: 'Hủy', onPress: () => log.info('Cancel Pressed!')},
        {text: 'Đồng ý', onPress: () => {
          // this.props.actions.buyCurrentPackage(this.props.adsMgmt.package, this.props.global.currentUser.userID);
          let service = this.state.allServices.filter( (e) => {
              return e.name == this.props.adsMgmt.package.goiLogo.levelName;
          });

          let fee = service[0].fees.filter( (e) => {
              return e.soLanSuDung == this.props.adsMgmt.package.goiLogo.length;
          });

          let serviceOrder = {
            userID: this.props.global.currentUser.userID,
            //adsID: this.props.adsMgmt.package.adsID,
            ads: {
              id: this.props.adsMgmt.package.adsID,
              cover: this.props.adsMgmt.package.ads.image ? this.props.adsMgmt.package.ads.image.cover : undefined
            },
            workstation: { name: this.props.global.deviceInfo.deviceModel,
              workstationID: this.props.global.deviceInfo.deviceID,
              appType: 'app' },
            price: {
              discount: fee[0].discount,
              price: fee[0].price,
              soLanSuDung: fee[0].soLanSuDung,
              type: fee[0].type
            },
            service: {
              id: service[0].id,
              name: service[0].name,
              packageType: 2,
              //days: fee[0].soLanSuDung,
              level: service[0].position
            }
          };

          let logoCurrentChose = this.props.adsMgmt.package.goiLogo.levelName;

            let currentUser = this.props.global.currentUser;
            let token = currentUser.token;
            let userID = currentUser.userID;

            this.props.actions.orderService(serviceOrder, this.props.global.currentUser.token). then( (e) => {
              if (e.status ==0 ){
                  setTimeout(() => {
                      this.props.actions.getMyWTS({userID: userID}, token)
                  }, 300);
                  Alert.alert("Thông báo", `Nâng cấp thành công gói logo ${logoCurrentChose}!`,
                      [ { text: 'Đóng', onPress: () => {
                            Actions.pop();
                            Actions.pop();
                        }
                      } ]);
              } else {
                  log.warn("PackageUpdater.onApply , result: ", e);
                  Alert.alert("Thông báo", e.msg);
              }
          });
        }}
      ]
    )
  }

    _getOldPackage() {
        let {ads} = this.props.adsMgmt.package;
        let goiLogos = ads && ads.goiLogo;
        if (!goiLogos) {
            return {};
        }
        let {goiLogo} = this.props.adsMgmt.package;
        if (!goiLogo) {
            return {};
        }
        goiLogos = goiLogos.filter( (e) => {
            return e.text == goiLogo.levelName;
        });
        if (goiLogos.length == 0) {
            return {};
        }
        let oldGoiLogo = goiLogos[0];

        let remainDays = util.getRemainDay(oldGoiLogo);
        return {levelName: oldGoiLogo.text, length: remainDays};
    }

    _getNewPackage() {
        return this.props.adsMgmt.package.goiLogo;
    }

  render() {
    let packageNames = [ 'Cần bán gấp', 'Nhà chính chủ', 'Miễn phí môi giới'];
    let packageComments = ['',
       '',
       ''];
    let packageSessions = [];
    for (let i = 0; i < packageNames.length; i++) {
      packageSessions.push(this._renderPackageSession(packageNames[i], packageComments[i]));
    }

    let main = this.props.global.currentUser.account.main ? this.props.global.currentUser.account.main : 0;
    let bonus = this.props.global.currentUser.account.bonus ? this.props.global.currentUser.account.bonus : 0;
    let used = this.state.used;

    let bonusLeft = bonus - used;
    let mainLeft = bonusLeft < 0 ? main + bonusLeft : main;

    let data = [];
    let pallete = [];

    if (mainLeft>0 ) {
      data.push({
        "name": "",
        "fillColor" : "#1396E0",
        "value": mainLeft
      });
      pallete.push(util.hexToRgb("#1396E0"));
    }

    if (bonusLeft>0){
      data.push({
        "name": "",
        "fillColor" : "#DE6207",
        "value": bonusLeft
      });
      pallete.push(util.hexToRgb("#DE6207"));
    }

    if (used>0 ){
      data.push({
        "name": "",
        "fillColor" : "#a6a4a4",
        "value": used
      });
      pallete.push(util.hexToRgb("#a6a4a4"));
    }

    let options = {
      margin: {
        top: 2,
        left: 2,
        bottom: 2,
        right: 2
      },
      width: 148,
      height: 148,
      r: 58,
      R: 73,
      legendPosition: 'topLeft',
      animate: {
        type: 'oneByOne',
        duration: 200,
        fillTransition: 3
      },
      label: {
        fontFamily: gui.fontFamily,
        fontSize: gui.buttonFontSize,
        fontWeight: 'normal'
      }
    };

    let chartTitle = 'Tổng tài khoản';
    let chartTitleBold = `${util.getPriceText(main + bonus)}`;
    return (
      <View style={myStyles.container}>
        <View style={myStyles.customPageHeader}>
          <View style={myStyles.customPageTitle}>
            <Text style={myStyles.customPageTitleText}>
              {this._getTitle()}
            </Text>
          </View>
          <TruliaIcon onPress={this._onBack.bind(this)}
                      name="arrow-left" color={'white'} size={26}
                      mainProps={myStyles.backButton} text={this.props.backTitle}
                      textProps={myStyles.backButtonText}>
          </TruliaIcon>

          {/*<TouchableHighlight*/}
            {/*style={{right: 10*/}
            {/*, position:'absolute', top : 32}}*/}

            {/*onPress={this.onApply.bind(this)}>*/}
            {/*<Text style={{color: 'white', fontSize: 17*/}
            {/*, fontFamily: gui.fontFamily, fontWeight:'600'}}>*/}
                {/*Thực hiện*/}
            {/*</Text>*/}
          {/*</TouchableHighlight>*/}

        </View>

        <ScrollView
            ref={(scrollView) => { this._scrollView = scrollView; }}
            automaticallyAdjustContentInsets={false}
            vertical={true}
            style={[myStyles.scrollView]}
            //onScroll={this.handleScroll.bind(this)}
            //scrollEventThrottle={1}
        >
          <View style={myStyles.viewBodyLogo}>
          {this._renderTitleLine("TÀI KHOẢN VÀ PHÍ DỊCH VỤ")}

          <View style={myStyles.viewChartContent}>
            <View style={[myStyles.viewChartLeft, {width: width/2}]}>
              <MChartView
                  data={data}
                  options={options}
                  pallete={pallete}
                  chartTitle={chartTitle}
                  chartTitleBold={chartTitleBold}
              />
              {/*<Image
                  style={{width: 45, height: 45}}
                  resizeMode={Image.resizeMode.contain}
                  source={require('../../assets/image/goi/money.png')}
              />*/}
            </View>

            <View style={[myStyles.viewChartLeft,{width: width/2, paddingLeft: 6,marginRight: 10}]}>
              {/*{this._renderMoneyLine("Tài khoản chính", `${util.convertPriceToComa(mainLeft) + ' ' + danhMuc.NGHIN}`, '#1396E0')}*/}
              {/*{this._renderMoneyLine("Tài khoản phụ", `${bonusLeft>0 ? util.convertPriceToComa(bonusLeft) + ' ' + danhMuc.NGHIN : '0 ' + danhMuc.NGHIN}`, '#DE6207')}*/}
              {this._renderMoneyLine(`Phí dịch vụ${this.state.giamGia ? "\nGiảm giá " + this.state.giamGia + "%" : "\n"}`
                  , `${util.getPriceText(used)}`, '#a6a4a4')}
            </View>
          </View>

          {this._renderTitleLine("CÁC GÓI LOGO (Tính theo ngày)")}

          {packageSessions}
              {this._renderTextBody()}
            {this._renderTextUpgraded()}
          </View>
        </ScrollView>
          {this._renderUpdated()}
      </View>
    )
  }

  _onBack() {
    Actions.pop();
  }

}

class MyImage extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let imageUri = {uri: this.props.imageUrl};
        if (this.props.noCoverUrl == this.props.imageUrl) {
            imageUri = require('../../assets/image/reland_house_large.jpg');
        }
        return(
            <View style={myStyles.slide} key={"img"+(this.props.imageIndex)}>
                <ImageBackground style={myStyles.thumb} source={imageUri} defaultSource={CommonUtils.getNoCoverImage()} >
                  <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.55)']}
                                  style={myStyles.linearGradient2}>
                  </LinearGradient>
                </ImageBackground>
            </View>
        );
    }
}

/**
 * ## Styles
 */
const myStyles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#f6f6f6'
  },
  headerSeparator: {
    borderTopWidth: 1,
    borderTopColor: gui.separatorLine
  },
  customPageHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    backgroundColor: gui.mainColor,
    top: 0,
    height: 60
  },
  customPageTitle: {
    left: 36,
    right: 36,
    marginTop: 31,
    marginBottom: 10,
    position: 'absolute'
  },
  customPageTitleText: {
    color: 'white',
    fontSize: 17,
    fontWeight: '500',
    fontFamily: gui.fontFamily,
    textAlign: 'center'
  },
  backButton: {
    marginTop: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    paddingLeft: 18,
    paddingRight: 18
  },
  backButtonText: {
    color: 'white',
    fontSize: gui.normalFontSize,
    fontFamily: gui.fontFamily,
    textAlign: 'left',
    marginLeft: 7
  },

  label: {
    fontFamily: gui.fontFamily,
    fontSize: 12,
    fontWeight: '300',
    color: '#8A8A8A'
  },

  introText: {
    fontSize: 15,
    fontFamily: gui.fontFamily,
    color: '#8A8A8A',
    paddingLeft: 19,
    paddingRight: 19,
    paddingTop: 10,

  },

  picker : {
    backgroundColor: 'white',
  },

  pickerItem: {
    fontSize: 11,
    fontFamily: gui.fontFamily,
  },
  selectLine: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 17,
    paddingRight: 10,
    backgroundColor: 'white',
    paddingTop: 8,
    paddingBottom: 8
  },

  arrowIcon: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingRight: 4
  },

  dot : {
    width: 20,
    height: 20,
    borderRadius: 10,
    marginRight: 10,
    marginTop: 10,
    backgroundColor: 'white',
    borderWidth: 5
  },
  scrollView: {
    backgroundColor: 'white',
    marginBottom: 43
  },
  viewTitleUpdate: {
      width: width,
      justifyContent :'space-between',
      paddingRight: 15,
      paddingLeft: 17,
      paddingTop: 8,
      paddingBottom: 8,
      backgroundColor: '#f8f8f8'
  },
  textTitleUpdate: {
      fontSize: 12,
      fontFamily: gui.fontFamily,
      color: '#313131',
      justifyContent :'space-between',
      padding: 0,
      fontWeight:"300"
  },
  viewButtonUpdate: {
      position:'absolute',
      bottom: 0,
      backgroundColor: '#fa4917',
      marginBottom: 0,
      justifyContent: 'center',
      alignItems: 'center',
      width: width,
      height: 43
  },
  textUpdate:{
      fontSize: 17,
      color:'#fff',
      fontWeight: '400',
      fontFamily: gui.fontFamily
  },
  viewBodyLogo:{
      flex:1,
      alignItems: 'center'
  },
  viewLabel: {
      width: width,
      justifyContent: 'center',
      alignItems: 'flex-start',
  },
  viewCenterText: {
    width: width,
    backgroundColor: 'transparent'
  },
  addLogoText:{
    width: width,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 8,
    paddingBottom: 8,
    paddingLeft: 17
  },
  viewCircle:{
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: gui.mainColor
  },
  textAddLogo: {
    fontSize: 13,
    fontFamily: gui.fontFamily,
    color: '#191919',
    fontWeight:"400"
  },
    viewContentLogo: {
      width: width - 34,
      height: 181,
      backgroundColor: '#f861c8',
      marginLeft: 17,
      marginTop: 5
    },
    detail: {
        flex: 0
    },
    searchListViewRowAlign: {
        position: 'absolute',
        backgroundColor: 'transparent',
        flexDirection: 'row',
        justifyContent: 'space-between',
        top: imgHeight - 57,
        width: width
    },
    logoContainer: {
        marginLeft: 17,
        justifyContent: "center",
        backgroundColor: gui.mainColor,
        borderRadius: 5,
        padding: 4,
        paddingLeft: 6,
        paddingRight: 8
    },
    logo: {
        fontSize: 12,
        fontWeight: '500',
        textAlign: 'center',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily
    },
    viewPrice: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 17,
        color: 'white'
    },
    viewText: {
        fontSize: 13,
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 17,
        marginBottom: 15,
        marginRight: 0,
        marginTop: 2,
        color: 'white',
        fontWeight: '300',
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    linearGradient2: {
        marginTop: imgHeight / 2,
        height: imgHeight / 2,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    thumb: {
        justifyContent: 'flex-end',
        alignItems: 'stretch',
        height: imgHeight,
        alignSelf: 'auto'
    },
    viewChartContent: {
        flexDirection: "row",
        justifyContent: 'flex-start',
        backgroundColor:'white',
        width: width,
        height: 162
    },
    viewChartLeft: {
        paddingLeft: 13,
        width: width/2,
        height: 162,
        alignItems: 'center',
        justifyContent: 'center'
    }


});

export default connect(mapStateToProps, mapDispatchToProps)(LogoPackageUpdater);

