'use strict';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as adsMgmtActions from '../../reducers/adsMgmt/adsMgmtActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as needToBuyActions from '../../reducers/needToBuy/needToBuyActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import {
    Text, View, Image, ListView, StatusBar,
    RecyclerViewBackedScrollView, TouchableOpacity, Alert,
    TouchableHighlight, StyleSheet, RefreshControl, ScrollView,
    InteractionManager, ImageBackground, FlatList
} from 'react-native'

import {Actions} from 'react-native-router-flux';

import MHeartIcon from '../MHeartIcon';

import LinearGradient from 'react-native-linear-gradient';

import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';

import ScalableText from 'react-native-text';

import gui from '../../lib/gui';
import util from '../../lib/utils';

import DanhMuc from '../../assets/DanhMuc';

import GiftedSpinner from "../../components/GiftedSpinner";
import cfg from "../../cfg";

import log from '../../lib/logUtil';
import RelandIcon from '../RelandIcon';
import Modal from 'react-native-modalbox';
import placeUtil from '../../lib/PlaceUtil';

import Toast, {DURATION} from '../toast/Toast';

const { width, height } = util.getDimensions();


let imageUriHome = require('../../assets/image/default_cover/no_cover_03.jpg');


import CommonUtils from '../../lib/CommonUtils';

const actions = [
    globalActions,
    adsMgmtActions,
    postAdsActions,
    needToBuyActions
];

function mapStateToProps(state) {
    return {
        //listAds: state.adsMgmt.likedList,
        loading: state.adsMgmt.loadingFromServer,
        errorMsg: state.adsMgmt.errorMsg,
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

const imgHeight = 166;

const myDs = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

class NewAdsListTab extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        this.state = {
            scrollEnabled: true,
            adsID: null
        }
    }
    
    componentDidMount() {
        log.info("AdsListTab - componentDidMount");
        if (this.props.name == 'likedTab') {
            this.props.actions.loadLikedList(this.props.global.currentUser.userID);
        }
        // else if (this.props.name == 'sellWToTab' || this.props.name == 'rentWToTab') {
        //     let token = this.props.global.currentUser.token;
        //     this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
        // }
        // else {
        //     this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        // }
        this.reachBottom = false;
        this._initScrollPos();
    }
    _initScrollPos() {
        InteractionManager.runAfterInteractions(() => {
            let listScrollPos = this.props.adsMgmt.listScrollPos;
            let scrollPos = listScrollPos && listScrollPos[this.props.name];
            scrollPos && this._scrollTo(scrollPos);
        });
    }
    _scrollTo(pos) {
        if (this._listView) {
            this._listView.scrollTo({y: pos});
        }
    }

    _onRefresh() {
        let listScrollPos = {...this.props.adsMgmt.listScrollPos};
        let listScrollKey = Object.keys(listScrollPos);
        listScrollKey.forEach((key) => {listScrollPos[key] = 0});
        listScrollPos[this.props.name] = 0;
        this.props.actions.onAdsMgmtFieldChange('listScrollPos', listScrollPos);
        if (this.props.name == 'likedTab') {
            this.props.actions.loadLikedList(this.props.global.currentUser.userID);
        }
        else if (this.props.name == 'sellWToTab' || this.props.name == 'rentWToTab') {
            let token = this.props.global.currentUser.token;
            this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
        }
        else {
            this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
        }

        /*
         fetchData().then(() => {
         this.setState({refreshing: false});
         });
         */
    }

    _renderImageLoading() {
        return (
            <Image style={myStyles.viewChildRow}
                   source={imageUriHome} defaultSource={CommonUtils.getNoCoverImage()} />
        );
    }

    _renderButtonLoading() {
        return (
            <View style={myStyles.viewNewButton}>
                <View style={myStyles.viewTextContent}>
                    <View style={[myStyles.viewLineLoaderRow, {width: 38, marginTop: 3, backgroundColor: '#dadee1'}]}></View>
                    <View style={[myStyles.viewLineLoaderRow, {backgroundColor: '#dadee1', marginTop: 3}]}></View>
                </View>
                <View style={[myStyles.headerSeparate, {marginLeft: 17, marginRight: 17, width: width - 34}]}></View>
                <View style={myStyles.viewDetailButton}>
                    <View style={[myStyles.viewEachButton, {width: width - 34, marginLeft: 17}]}>
                        <View style={[myStyles.viewLineLoaderRow, {width: width - 34, backgroundColor: '#dadee1' }]}></View>
                    </View>
                </View>
                <View style={myStyles.viewBottomNeedPost}></View>
            </View>
        );
    }

    _getListContent() {
        let myProps = this.props;

        if (myProps.errorMsg) {
            return (
                <View style={{flex:1, alignItems:'center', justifyContent:'center', marginTop: 30}}>
                    <Text style={myStyles.welcome}>{myProps.errorMsg}</Text>
                </View>
            )
        }

        if (myProps.adsMgmt.refreshing || myProps.needToBuy.needToBuyLoading
            || myProps.adsMgmt.loadingAds || myProps.adsMgmt.loadingWto) {
            return (
                <ScrollView
                    scrollEnabled={this.state.scrollEnabled}
                    refreshControl={
                        <RefreshControl
                            refreshing={myProps.adsMgmt.refreshing || myProps.adsMgmt.loadingAds || myProps.adsMgmt.loadingWto}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                >
                    <View style={[myStyles.detailAds, {height: height - 110}]}>
                        {this._renderImageLoading()}
                        {this._renderButtonLoading()}

                        {this._renderImageLoading()}
                        {this._renderButtonLoading()}

                        {this._renderImageLoading()}
                        {this._renderButtonLoading()}
                    </View>

                </ScrollView>
            )
        }

        let ds = myDs.cloneWithRows(myProps.listAds);
        //this.setState({dataSource:ds});
        // let listSize = myProps.listAds.length;
        // let listSize = 25;

        return (
            // <ListView
            //     ref={(listView) => { this._listView = listView; }}
            //     scrollEnabled = {this.state.scrollEnabled}
            //     refreshControl={
            //         <RefreshControl
            //             refreshing={false}
            //             onRefresh={this._onRefresh.bind(this)}
            //         />
            //     }
            //
            //     enableEmptySections = {true}
            //
            //     dataSource={ds}
            //     renderRow={this.renderRow.bind(this)}
            //     //renderScrollComponent={props => <RecyclerViewBackedScrollView {...props} />}
            //     renderSeparator={(sectionID, rowID) => <View key={`${sectionID}-${rowID}`} style={myStyles.separator} />}
            //     style={myStyles.searchListView}
            //     renderFooter={this._renderFooter.bind(this)}
            //     onScroll={this.handleScroll.bind(this)}
            //     scrollEventThrottle={200}
            //     initialListSize={listSize}
            // />
            <View style={{flex:1}}>
                <FlatList
                    refreshControl={
                        <RefreshControl
                            refreshing={false}
                            onRefresh={this._onRefresh.bind(this)}
                        />
                    }
                    data={myProps.listAds}
                    keyExtractor={(item, index) => "list" + index}
                    renderItem={(item) => this.renderRow(item)}
                    ListFooterComponent={() => this._renderFooter()}
                    removeClippedSubviews={false}
                    enableEmptySections
                />
            </View>
        )
    }

    handleScroll(event: Object) {
        let pos = event.nativeEvent.contentOffset.y;
        let listScrollPos = {...this.props.adsMgmt.listScrollPos};
        listScrollPos[this.props.name] = pos < 0 ? 0 : pos;
        this.props.actions.onAdsMgmtFieldChange('listScrollPos', listScrollPos);
        this.reachBottom = pos > 100;
    }

    _renderFooter() {

        let result;
        switch (this.props.name) {
            case "likedTab" :
            case "sellTab" :
            case "rentTab" :
            case "sellWToTab" :
            case "rentWToTab" :
                result = (
                    <View style={myStyles.viewFooter}>
                        <Text style={myStyles.textFooter}>Tất cả đã được hiển thị</Text>
                    </View>
                );
                break;
            default:
                result = null;
                break;
        }
        return result;

    }

    render() {
        return (
            <View style={[myStyles.container, this.props.mainStyle]}>
                {this._getListContent()}
                {this._renderLoadingView()}
            </View>
        )
    }

    _renderWToDefaultImage(rowData) {
        let image =  {uri: `${cfg.noCoverUrl}`};
        return (
            <View style={myStyles.slide}>
                <TouchableOpacity
                    onPress={() => Actions.NeedToBuyDetail({wtoID: rowData.wtoID})}>
                    <ImageBackground style={myStyles.thumb} source={image}>
                        <LinearGradient colors={['rgba(50, 50, 50, 0.75)', 'rgba(50, 50, 50, 0.75)']}
                                        style={myStyles.linearGradient2}>
                        </LinearGradient>
                    </ImageBackground>
                </TouchableOpacity>
            </View>
        );
    }

    _renderImageStack(rowData) {
        let imageIndex = 0;
        if (rowData.image && rowData.image.cover) {
            return (
                <MyImage imageIndex={0} rowData={rowData} imageUrl={rowData.image.cover} source={this.props.source}/>
            );
        } else {
            return (
                <MyImage imageIndex={0} rowData={rowData} imageUrl={''} source={this.props.source}/>
            );
        }
    }

    onEditButton(adsID, hasPostAdsToOtherWebsite){
        this.props.actions.getUpdateAds(adsID, this.props.global.currentUser.token)
            .then(
                (res) => {
                    if (res.success){
                        this.props.actions.onPostAdsFieldChange('selectedDiaChinh', res.data.place.diaChinh);
                        // Actions.PostAdsDetail({hasPostAdsToOtherWebsite: hasPostAdsToOtherWebsite});
                        Actions.NewPostAdsDetail({hasPostAdsToOtherWebsite: hasPostAdsToOtherWebsite});
                    } else {
                        Alert.alert('Thông báo', 'Lỗi không tải được tin đã đăng.');
                    }
                }
            );
    }

    onDeleteButton(adsID){
        Alert.alert('Thông báo', 'Bạn có muốn xóa tin này không?',
            [ {text: 'Hủy' , onPress: () => log.info('Cancel Pressed!')},
                {text: 'Đồng ý', onPress: () => this._deleteAds(adsID)}
            ]);
    }

    onLamMoiTinButton(adsID, rowData) {
        let trangThaiTin = rowData.statusFmt || "";
        if (trangThaiTin == "Đã duyệt") {
            this.props.actions.upgradeNgayDangTin(adsID, this.props.global.currentUser.token)
                .then(
                    (res) => {
                        if (res.success){
                            Alert.alert('Làm mới tin thành công!', 'Ngày đăng tin đã được chuyển thành hôm nay. Tin của bạn sẽ đứng trước các tin cùng loại có ngày đăng cũ hơn.');
                            this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
                        } else {
                            Alert.alert('Thông báo', res.msg,
                                [ { text: 'Đóng', onPress: () => {} } ]);
                        }
                    }
                );
        } else {
            Alert.alert('Làm mới tin chỉ thực hiện cho những tin đã được duyệt!');
        }
    }

    _deleteAds(adsID){
        let token = this.props.global.currentUser.token;

        this.props.actions.deleteAds(adsID, token).then (
            (res) => {
                if (res.success){
                    Alert.alert('Thông báo', 'Bạn đã xóa thành công tin đăng.');
                    this.props.actions.loadMySellRentList(this.props.global.currentUser.userID);
                }else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        );
    }

    upgradeAds(ads) {
        let trangThaiTin = ads.statusFmt || "";
        if (trangThaiTin != "Đã duyệt") {
            Alert.alert('Thông báo', 'Bạn không thể nâng cấp cho tin chưa được duyệt.');
            return;
        }
        this.props.actions.changePackageField('adsID', ads.adsID);
        this.props.actions.changePackageField('ads', ads);

        if (ads.goiViTri){
            let remainDays = util.getRemainDay(ads.goiViTri);
            this.props.actions.changePackageField(
                'current_goiViTri', remainDays>0 ? util.getLevelName(ads.goiViTri) : "Chưa có");
        } else {
            this.props.actions.changePackageField(
                'current_goiViTri', "Chưa có");
        }

        /*
         this.props.actions.changePackageField(
         'current_goiTrangChu', util.getLevelName(ads.goiTrangChu));
         */
        if (ads.goiLogo && ads.goiLogo.length>0) {
            ads.goiLogo.sort((a, b) => a.startDateTime - b.startDateTime);
            let index = ads.goiLogo.length - 1;
            let remainDays = util.getRemainDay(ads.goiLogo[index]);
            this.props.actions.changePackageField(
                'current_goiLogo', remainDays>0 ? ads.goiLogo[index].text : "Chưa có");
        } else {
            this.props.actions.changePackageField(
                'current_goiLogo', "Chưa có");
        }

        Actions.UpgradePackgeSelector({ads:ads});
    }

    // coming() {
    //     Alert.alert("Coming soon...");
    // }

    _getPackValue(prefix, pack) {
        if (!pack)
            return '';

        let remainDays = util.getRemainDay(pack);
        // if (remainDays<=0)
        //     return '';

        if (prefix.indexOf("Logo")>=0){
            if(remainDays && remainDays > 0) {
                return prefix + pack.text + " - " + remainDays + " ngày";
            } else return prefix + pack.text + " - hết hạn"
        }

        if (pack && pack.level) {
            if(remainDays && remainDays > 0) {
                return prefix + DanhMuc.package.level[pack.level] + " - " + remainDays + " ngày";
            } else return prefix + DanhMuc.package.level[pack.level] + " - hết hạn "
        }

        return '';
    }

    _renderGoiTin(rowData) {
        if (this.props.name == 'likedTab') {
            return null;
        }
        // let trangThaiTin = rowData.statusFmt || "";
        let viTriLabel = this._getPackValue("Vị trí : " , rowData.goiViTri);
        // let trangChuLabel =  this._getPackValue("Trang chủ : ", rowData.goiTrangChu);

        let currentLogo = this._getGoiLogo(rowData);
        let logoLabel = rowData.goiLogo && rowData.goiLogo.length>0 ?
            this._getPackValue("Logo : " , rowData.goiLogo[rowData.goiLogo.length-1]) : '';
        // let trangThai = rowData.statusFmt;
        // let trangThaiTin = rowData.statusFmt ? rowData.statusFmt : DanhMuc.TIN_CHO_DUYET;

        return (
            <View style={myStyles.rightTextGroup}>
                {/*<Text numberOfLines={1} style={myStyles.tinChoDuyet}>{trangThaiTin.toUpperCase()}</Text>*/}

                {/*<TouchableHighlight disabled={false} underlayColor='transparent' onPress={() => {this.upgradeAds(rowData)}}>*/}
                    {/*<View style={myStyles.nangCap} >*/}
                        {/*<RelandIcon.Icon color={'white'} name={"update"} size={12} style={{marginLeft:5, marginRight:5}} />*/}
                        {/*<Text style={myStyles.textNangCap}>*/}
                            {/*NÂNG CẤP*/}
                        {/*</Text>*/}
                    {/*</View>*/}
                {/*</TouchableHighlight>*/}
                <Text numberOfLines={1} style={[myStyles.textGoiTin,{marginBottom: 1}]}>{viTriLabel}</Text>
                {/*<Text numberOfLines={1} style={myStyles.textGoiTin}>{trangChuLabel}</Text>*/}
                {/*<Text numberOfLines={2} style={[myStyles.textGoiTin, {marginTop: 0}]}>{logoLabel}</Text>*/}
                {currentLogo}
            </View>
        )

    }

    _getGoiLogo(data) {
        let currentLogo = [];
        let {goiLogo} =  data;
        if (!goiLogo || goiLogo.length <= 0) {
            return
        }
        let dataLogo = goiLogo.sort((a, b) => b.startDateTime - a.startDateTime);
        let index = 0;
        let key = new Date().getTime();
        for (let i=0; i<dataLogo.length; i++) {
            let adsLogo = dataLogo[i];
            let remainDays = util.getRemainDay(adsLogo);
            let dayConvert = this._getPackValueLogo(remainDays);

            currentLogo.push(
                <View key={key + index} style={[myStyles.viewEachLogo]}>
                    <Text style={[myStyles.textGoiTin, {marginTop: 0}]}>
                        {adsLogo.text}{dayConvert}
                    </Text>
                </View>
            );
            index++;
        }

        return (
            <View style={myStyles.viewTotalGoiLogo}>
                {currentLogo}
            </View>
        )
    }

    _getPackValueLogo(remainDays) {
        if(remainDays && remainDays > 0) {
            return " - " + remainDays + " ngày";
        } else return " - hết hạn"
    }

    _renderDuyetTin (rowData) {
        return (
            <View style={myStyles.viewDuyetTin}>
                {this._renderTrangThaiTin(rowData)}
                {this._renderRejectPost(rowData)}
            </View>
        );
    }

    _renderTrangThaiTin(rowData) {
        let trangThaiTin = rowData.statusFmt||"Chờ duyệt";
        if (trangThaiTin == "Chờ duyệt") {
            return (
                <View style={myStyles.viewCircleTrangThai}>
                    <View style={myStyles.circleTrangThai}></View>
                    <Text numberOfLines={1} style={myStyles.tinChoDuyet}>Tin đang chờ duyệt</Text>
                </View>
                );
        } else if (trangThaiTin == "Đã duyệt") {
            let validTin = util.checkNgayHetHan(rowData.ngayHetHan) || this.props.name == 'sellWToTab'
                || this.props.name == 'rentWToTab';
            let statusDesc = validTin ? 'Tin đã được duyệt' : 'Tin đã hết hạn';
            let statusColor = validTin ? '#3bb44b' : '#ffde15';
            return (
                <View style={myStyles.viewCircleTrangThai}>
                    <View style={[myStyles.circleTrangThai, {backgroundColor: statusColor}]}></View>
                    <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: statusColor}]}>{statusDesc}</Text>
                </View>
                );
        } else if (trangThaiTin == "Bị từ chối") {
            return  (
                <View style={myStyles.viewCircleTrangThai}>
                    <View style={[myStyles.circleTrangThai, {backgroundColor: '#ed1b24'}]}></View>
                    <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#ed1b24'}]}>Tin bị từ chối</Text>
                </View>
            );
        } else if (trangThaiTin == "Hết hạn") {
            return  (
                <View style={myStyles.viewCircleTrangThai}>
                    <View style={[myStyles.circleTrangThai, {backgroundColor: '#aeaeae'}]}></View>
                    <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#aeaeae'}]}>Tin đã hết hạn</Text>
                </View>
            );
        } else return <Text numberOfLines={1} style={[myStyles.tinChoDuyet, {color: '#fff'}]}>{trangThaiTin}</Text>;
    }

    _renderButtonWto(rowData) {

        let {content, wtoID} = rowData;
        let gia = this._getGiaText(rowData);
        let loaiTin = content.loaiTin;
        let loaiTinText = loaiTin == 0 ? 'mua' : 'thue';
        let loaiNhaDat = content.loaiNhaDat;
        let title = rowData.title || DanhMuc.getLoaiNhaDatWToForDisplay(loaiTinText, loaiNhaDat);
        let dienTich = this._getDienTichText(rowData);
        let soPhongNgu = '';
        if (content.soPhongNguFmt) {
            soPhongNgu = ' ' + content.soPhongNguFmt;
        }
        let soTang = '';
        if (content.soTangFmt) {
            soTang = ' ' + content.soTangFmt;
        }
        let diaChiFullname = this._getDiaChiFullname(content.place);
        let diaChi = diaChiFullname;
        let maxDiaChiLength = 100;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < diaChiFullname.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);

        return (
            <View style={[myStyles.viewNewButton, {height: 176}]}>
                <TouchableOpacity underlayColor='transparent'
                                    onPress={() => Actions.NeedToBuyDetail({wtoID: rowData.wtoID})}>
                    <View style={[myStyles.viewTextContent, {marginRight: 10,  height: 129}]}>
                        <Text style={[myStyles.price, {color: '#000', paddingTop: 5}]}>{title}</Text>
                        <Text style={[myStyles.text, {fontSize: 17, color: '#59595b', fontWeight: '500'}]}>{gia}</Text>
                        <Text style={[myStyles.text, {color: '#59595b'}]}>{diaChi}</Text>
                        <Text style={[myStyles.text, {color: '#59595b'}]}>{moreInfo.trim()}</Text>
                        <View style={[myStyles.viewDuyetTin, {top: 0, paddingBottom: 5}]}>
                            {this._renderTrangThaiTin(rowData)}
                            {this._renderRejectPost(rowData)}
                        </View>
                    </View>
                </TouchableOpacity>
                <View style={[myStyles.headerSeparate, {marginLeft: 17, marginRight: 17, width: width - 34}]}></View>
                <View style={myStyles.viewDetailButton}>
                    <TouchableOpacity style={[myStyles.viewEachButton, {width: width/2}]}
                                      onPress={this.onWToEditButton.bind(this, wtoID)}
                    >
                        <RelandIcon name="edit" size={18} color="#403f42"
                                    iconProps={{marginRight: 0}}
                                    mainProps={{flexDirection: 'row'}}
                                    textProps={{paddingLeft: 0}}
                                    noAction={true}

                        />
                        <Text style={myStyles.textEachButton}>
                            Chỉnh sửa
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[myStyles.viewEachButton, {width: width/2}]}
                                      onPress={this.onWToDeleteButton.bind(this, wtoID)}
                    >
                        <RelandIcon name="delete" size={18} color="#403f42"
                                    iconProps={{marginRight: 0}}
                                    mainProps={{flexDirection: 'row'}}
                                    textProps={{paddingLeft: 0}}
                                    noAction={true}

                        />
                        <Text style={myStyles.textEachButton}>
                            Xóa tin
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={myStyles.viewBottomNeedPost}></View>
            </View>
        );
    }

    _renderNewButton(rowData) {
        let diaChi = rowData.diaChiChiTiet || rowData.diaChi || '';
        let originDiaChi = diaChi;
        let loaiTin = rowData.loaiTin;
        let loaiNhaDat = rowData.loaiNhaDat;
        let dienTich = '';
        if (rowData.dienTichFmt && rowData.dienTichFmt != 'Không rõ') {
            dienTich = '· ' + rowData.dienTichFmt;
        }
        let soPhongNgu = '';
        if (rowData.soPhongNguFmt) {
            soPhongNgu = " " + rowData.soPhongNguFmt;
        }

        let soTang = '';
        if (rowData.soTangFmt) {
            soTang = " " + rowData.soTangFmt;
        }

        let maxDiaChiLength = 30;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < originDiaChi.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);
        let moreInfoWithoutDot = moreInfo.replace('·', '');
        moreInfoWithoutDot = moreInfoWithoutDot.trim();

        let adsID = rowData.adsID || rowData.id;
        let source = this.props.source ? this.props.source : 'server';

        let postAdsToOtherWebsite = rowData.postAdsToOtherWebsite;
        let hasPostAdsToOtherWebsite = postAdsToOtherWebsite != undefined;

        // let source = this.props.source ? this.props.source : 'server';
        // let giaFmt = '3.74 tỷ';
        // let moreInfo = 'FLC Landmark Tower, Tầng ... 159m2  3p ngủ';

        return (
            <View style={myStyles.viewNewButton}>
                <TouchableOpacity
                    onPress={() => Actions.SearchResultDetail({adsID: rowData.adsID, source: source, imageDetail: rowData.image.cover})}>
                    <View style={myStyles.viewTextContent}>
                        <View style={{flexDirection: 'row', justifyContent: 'space-between', width: width-32}}>
                            <Text style={[myStyles.price, {color: '#000'}]}>{rowData.giaFmt}</Text>
                            <Text style={[myStyles.price, {color: '#000'}]}>{rowData.maSo}</Text>
                        </View>
                        <ScalableText style={[myStyles.text, {color: '#59595b'}]}>{diaChi} {moreInfoWithoutDot}</ScalableText>
                    </View>
                </TouchableOpacity>
                <View style={[myStyles.headerSeparate, {marginLeft: 17, marginRight: 17, width: width - 34}]}></View>
                <View style={myStyles.viewDetailButton}>
                    <TouchableOpacity style={myStyles.viewEachButton}
                                      onPress={this.onEditButton.bind(this, adsID, hasPostAdsToOtherWebsite)}
                    >
                        <RelandIcon name="edit" size={18} color="#403f42"
                                    iconProps={{marginRight: 0}}
                                    mainProps={{flexDirection: 'row'}}
                                    textProps={{paddingLeft: 0}}
                                    noAction={true}

                        />
                        <Text style={myStyles.textEachButton}>
                            Chỉnh sửa
                        </Text>
                    </TouchableOpacity>
                    {this._renderUpgradeAdsButton(rowData)}
                    <TouchableOpacity style={myStyles.viewEachButton}
                                      onPress={this.onDeleteButton.bind(this, adsID)}
                    >
                        <RelandIcon name="delete" size={18} color="#403f42"
                                    iconProps={{marginRight: 0}}
                                    mainProps={{flexDirection: 'row'}}
                                    textProps={{paddingLeft: 0}}
                                    noAction={true}

                        />
                        <Text style={myStyles.textEachButton}>
                            Xóa tin
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={myStyles.viewBottomNeedPost}></View>
            </View>
        );
    }

    _renderUpgradeAdsButton(rowData) {
        if (rowData.statusFmt != "Đã duyệt") {
            return (
                <View style={myStyles.viewEachButton}>
                    <RelandIcon name="arrow-up" size={18} color={'#CCCCCC'}
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                    <Text style={[myStyles.textEachButton, {color: '#CCCCCC'}]}>
                        Nâng cấp
                    </Text>
                </View>
            );
        }
        return (
            <TouchableOpacity style={myStyles.viewEachButton}
                              onPress={this.upgradeAds.bind(this, rowData)}
            >
                <RelandIcon name="arrow-up" size={18} color={'#403f42'}
                            iconProps={{marginRight: 0}}
                            mainProps={{flexDirection: 'row'}}
                            textProps={{paddingLeft: 0}}
                            noAction={true}

                />
                <Text style={myStyles.textEachButton}>
                    Nâng cấp
                </Text>
            </TouchableOpacity>
        );
    }

    _getGiaText(rowData) {
        let {content} = rowData;
        let {giaTu, giaDen, giaTuFmt, giaDenFmt} = content;
        if ((giaTu == -1 || giaTu == DanhMuc.BIG) && (giaDen == -1 || giaDen == DanhMuc.BIG)) {
            return 'Giá: ' + DanhMuc.THOA_THUAN;
        }
        if (giaTu == -1 || giaTu == DanhMuc.BIG) {
            return 'Giá: <= ' + giaDenFmt;
        }
        if (giaDen == -1 || giaDen == DanhMuc.BIG) {
            return 'Giá: >= ' + giaTuFmt;
        }
        return 'Giá: ' + giaTuFmt + ' - ' + giaDenFmt;
    }

    _getDienTichText(rowData) {
        let {content} = rowData;
        let {dienTichTu, dienTichDen, dienTichTuFmt, dienTichDenFmt} = content;
        if ((dienTichTu == -1 || dienTichTu == DanhMuc.BIG) && (dienTichDen == -1 || dienTichDen == DanhMuc.BIG)) {
            return '';
        }
        if (dienTichTu == -1 || dienTichTu == DanhMuc.BIG) {
            return '<= ' + dienTichDenFmt;
        }
        if (dienTichDen == -1 || dienTichDen == DanhMuc.BIG) {
            return '>= ' + dienTichTuFmt;
        }
        return dienTichTuFmt + ' - ' + dienTichDenFmt;
    }

    _getDiaChiFullname(place) {
        if (!place) {
            return '';
        }
        let placeName = place.fullName;
        if (!placeName) {
            if (place.tenDuAn) {
                placeName = 'Dự án ' + place.tenDuAn;
            }
            let diaChinhFullName = placeUtil.getDiaChinhWToFullName(place);
            placeName = placeName ? placeName + ', ' + diaChinhFullName : diaChinhFullName;
        }
        return placeName;
    }

    _renderText(rowData) {
        let diaChi = rowData.diaChiChiTiet || rowData.diaChi || '';
        let originDiaChi = diaChi;
        let loaiTin = rowData.loaiTin;
        let loaiNhaDat = rowData.loaiNhaDat;
        let dienTich = '';
        if (rowData.dienTichFmt && rowData.dienTichFmt != 'Không rõ') {
            dienTich = '· ' + rowData.dienTichFmt;
        }
        let soPhongNgu = '';
        if (rowData.soPhongNguFmt) {
            soPhongNgu = " " + rowData.soPhongNguFmt;
        }

        let soTang = '';
        if (rowData.soTangFmt) {
            soTang = " " + rowData.soTangFmt;
        }

        let maxDiaChiLength = 25;
        let index = diaChi.indexOf(',', maxDiaChiLength - 5);
        let length = 0;
        if (index !== -1 && index <= maxDiaChiLength) {
            length = index;
        } else {
            index = diaChi.indexOf(' ', maxDiaChiLength - 5);
            length = index !== -1 && index <= maxDiaChiLength ? index : maxDiaChiLength;
        }
        diaChi = diaChi.substring(0, length);
        if (diaChi.length < originDiaChi.length) {
            diaChi = diaChi + '...';
        }

        let moreInfo = this.getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang);
        let moreInfoWithoutDot = moreInfo.replace('·', '');
        moreInfoWithoutDot = moreInfoWithoutDot.trim();

        let adsID = rowData.adsID || rowData.id;

        if (this.props.name == 'likedTab') {
            return (
                <View style={myStyles.likedItemContainer}>
                    <View style={myStyles.searchListViewRowAlign}>
                        <Text style={myStyles.price}>{rowData.giaFmt}</Text>
                        <ScalableText style={myStyles.text}>{diaChi}{moreInfo}</ScalableText>
                    </View>
                    {this._renderHeartButton(adsID)}
                </View>
            );
        }
        //Ban or Cho Thue
        return (
            <View style={myStyles.leftTextGroup}>
                {this._renderLamMoiTinButton(adsID, rowData)}
                {this._renderNgayDangTin(rowData)}
                {this._renderNgayHetHan(rowData)}
                {this._renderDuyetTin(rowData)}
                {this._renderWebsitesPost(rowData)}
            </View>
        )
    }

    _renderNgayDangTin(rowData) {
        let ngayDangTin = util.formatDate(rowData.ngayDangTin);
        ngayDangTin = ngayDangTin ? 'Ngày đăng: ' + ngayDangTin : '';
        return(
            <View style={myStyles.ngayDangTinView}>
                    <ScalableText style={[myStyles.text, myStyles.textNgayDangTin]}>
                        {ngayDangTin}
                    </ScalableText>
            </View>
        );
    }

    _renderNgayHetHan(rowData) {
        let ngayHetHan = util.formatDate(rowData.ngayHetHan);
        ngayHetHan = ngayHetHan ? 'Ngày hết hạn: ' + ngayHetHan : '';
        return(
            <View style={myStyles.ngayHetHanView}>
                <ScalableText style={[myStyles.text, myStyles.textNgayHetHan]}>
                    {ngayHetHan}
                </ScalableText>
            </View>
        );
    }

    _renderWebsitesPost(rowData) {
        let postAdsToOtherWebsite = rowData.postAdsToOtherWebsite;
        if (!postAdsToOtherWebsite) {
            return null;
        }
        return (
            <TouchableOpacity style={myStyles.viewWebsites}
                              onPress={this._onPressWebsites.bind(this, postAdsToOtherWebsite)}
            >
                <Text style={myStyles.textLyDo}>XEM WEBSITES</Text>
            </TouchableOpacity>
        );
    }

    _onPressWebsites(postAdsToOtherWebsite) {
        Actions.ReviewWebPosted({postAdsToOtherWebsite: postAdsToOtherWebsite});
    }

    _renderRejectPost (rowData) {
        let trangThaiTin = rowData.statusFmt || "";
        if (trangThaiTin == "Bị từ chối") {
            return (
                <TouchableOpacity style={myStyles.viewReject}
                                  onPress={this._onPressRejectPost.bind(this, rowData)}
                >
                    <Text style={myStyles.textLyDo}>XEM LÝ DO</Text>
                </TouchableOpacity>
            );
        } else return null;
    }

    _onPressRejectPost (rowData) {
        Actions.RejectInfo({dataReject: rowData});
    }

    _renderLamMoiTinButton(adsID, rowData) {
        let trangThaiTin = rowData.statusFmt||"";
        let lamMoiBackGround = (trangThaiTin == "Đã duyệt") ? gui.mainColor : '#9a9a9a';
        return(
            <View style={myStyles.lamMoiTinView}>
                <TouchableOpacity style={[myStyles.lamMoiTinButton, {backgroundColor: lamMoiBackGround}]}
                                  onPress={this.onLamMoiTinButton.bind(this, adsID, rowData)}
                >
                    <Text style={myStyles.lamMoiTinText}>
                        LÀM MỚI TIN
                    </Text>
                </TouchableOpacity>
            </View>
        );
    }

    _renderWToMoreButton(wtoID) {
        return(
            <View style={[myStyles.viewChangeButton, {top: 0}]}>
                <TouchableOpacity style={myStyles.viewEditButton}
                                  onPress={this.onWToEditButton.bind(this, wtoID)}
                >
                    <RelandIcon name="edit" size={16} color="#fff"
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                </TouchableOpacity>
                <TouchableOpacity style={[myStyles.viewDeleteButton]}
                                  onPress={this.onWToDeleteButton.bind(this, wtoID)}
                >
                    <RelandIcon name="delete" size={16} color="#fff"
                                iconProps={{marginRight: 0}}
                                mainProps={{flexDirection: 'row'}}
                                textProps={{paddingLeft: 0}}
                                noAction={true}

                    />
                </TouchableOpacity>
            </View>
        );
    }

    onWToEditButton(wtoID){
        this.props.actions.getUpdateWTo(wtoID, this.props.global.currentUser.token)
            .then(
                (res) => {
                    if (res.success){
                        Actions.NeedToBuyFilter();
                    } else {
                        Alert.alert('Thông báo', 'Lỗi không tải được tin đã đăng.');
                    }
                }
            );
    }

    onWToDeleteButton(wtoID){
        Alert.alert('Thông báo', 'Bạn có muốn xóa tin này không?',
            [ {text: 'Hủy' , onPress: () => log.info('Cancel Pressed!')},
                {text: 'Đồng ý', onPress: () => this._deleteWTo(wtoID)}
            ]);
    }

    _deleteWTo(wtoID){
        let token = this.props.global.currentUser.token;
        let userID = this.props.global.currentUser.userID;

        this.props.actions.deleteWTo(userID, wtoID, token).then (
            (res) => {
                if (res.success){
                    Alert.alert('Thông báo', 'Bạn đã xóa thành công tin đăng.');
                    this.props.actions.loadMyWToList(this.props.global.currentUser.userID, token);
                }else {
                    Alert.alert('Thông báo', res.msg);
                }
            }
        );
    }

    _renderHeartButton(adsID) {
        let isLiked = this.isLiked(adsID);
        let color = isLiked ? '#fff' : 'white';
        let bgColor = isLiked ? '#E50064' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        if (!isLiked || (this.props.uploadingLikedAds.uploading && this.props.uploadingLikedAds.adsID == adsID)) {
            return (
                <View style={myStyles.heartContent}>
                    <View style={myStyles.heartButton2}>
                        <GiftedSpinner size="small" color="white" />
                    </View>
                </View>);
        } else {
            return (
                <View style={myStyles.heartContent}>
                    <MHeartIcon onPress={() => this.onLike(adsID)}
                                color={color} bgColor={bgColor}
                                bgStyle={bgStyle} mainProps={myStyles.heartButton}/>
                </View>
            );
        }
    }

    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.likeAds(this.props.global.currentUser.userID, adsID, this._loadLikedList.bind(this));
            } else {
                this.props.unlikeAds(this.props.global.currentUser.userID, adsID, this._loadLikedList.bind(this));
            }
        }
    }

    _loadLikedList(likeAdsMessage) {
        this.props.actions.loadLikedList(this.props.global.currentUser.userID);
        InteractionManager.runAfterInteractions(() => {
            this.props.updateLikeAdsProcessing && this.props.updateLikeAdsProcessing(likeAdsMessage);
        });
    }

    _renderLoadingView() {
        if (this.props.postAds.loadingUpdateAds || this.props.adsMgmt.deletingAds || this.props.adsMgmt.updatingAds) {
            return (
                <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                        alignItems: 'center', justifyContent: 'center'}}>
                    <GiftedSpinner size='large' color={'#d3d3d3'} />
                </View>
            )
        }
    }

    renderRow = (data, sectionID, rowID) => {
        if(!data) {
            return
        }
        let rowData = data.item;
        let adsID = rowData.id || rowData.adsID;
        let source = this.props.source ? this.props.source : 'server';

        if (this.props.name == 'likedTab'){
            return (
                <View key={adsID} style={{overflow: 'hidden'}}>
                    <TouchableOpacity underlayColor='transparent'
                                        onPress={() => Actions.SearchResultDetail({adsID: rowData.adsID, source: source, imageDetail: rowData.image.cover})}>
                        <View style={myStyles.detail}>
                            {this._renderImageStack(rowData)}
                            {this._renderText(rowData)}
                        </View>
                    </TouchableOpacity>
                </View>
            );
        } else if (this.props.name == 'sellWToTab' || this.props.name == 'rentWToTab') {
            return (
                <View key={adsID} style={{overflow: 'hidden'}}>
                    <View style={[myStyles.detailAds, {height: 176}]}>
                        {/*{this._renderWToDefaultImage(rowData)}*/}
                        {/*{this._renderWToText(rowData)}*/}
                        {this._renderButtonWto(rowData)}
                    </View>
                </View>
            );
        } else {
            return (
                <View key={adsID} style={{overflow: 'hidden'}}>
                    <TouchableOpacity underlayColor='transparent'
                                        onPress={() => Actions.SearchResultDetail({adsID: rowData.adsID, source: source, imageDetail: rowData.image.cover})}>
                        <View style={myStyles.detailAds}>
                            {this._renderImageStack(rowData)}
                            {this._renderText(rowData)}
                            {this._renderGoiTin(rowData)}
                            {this._renderNewButton(rowData)}
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }
    }

    _allowScroll(scrollEnabled) {
        this.setState({ scrollEnabled })
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = ' ' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = ' ' + dienTich + soTang;
        }
        else {
            moreInfo = ' ' + dienTich;
        }
        return moreInfo;
    }
}

class MyImage extends Component {
    render() {
        let source = this.props.source ? this.props.source : 'server';

        let image =  (this.props.imageUrl && this.props.imageUrl.length>0 ) ? {uri: `${this.props.imageUrl}`}
            : {uri: `${cfg.noCoverUrl}`};

        return (
            <View style={myStyles.slide} key={"img"+(this.props.imageIndex)}>
                <TouchableOpacity
                    onPress={() => Actions.SearchResultDetail({adsID: this.props.rowData.adsID, source: source, imageDetail: this.props.rowData.image.cover})}>
                    <ImageBackground style={myStyles.thumb} source={image}>
                        <LinearGradient colors={['rgba(50, 50, 50, 0.6)', 'rgba(50, 50, 50, 0.6)']}
                                        style={myStyles.linearGradient2}>
                        </LinearGradient>
                    </ImageBackground>
                </TouchableOpacity>
            </View>
        );
    }
}

// Later on in your styles..
const myStyles = StyleSheet.create({
    welcome: {
        marginTop: -50,
        marginBottom: 50,
        fontSize: 17,
        textAlign: 'center',
        margin: 10
    },
    container: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        height: height-113
    },
    search: {
        backgroundColor: gui.mainColor,
        height: 30
    },
    searchContent: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    slide: {
        justifyContent: 'center',
        backgroundColor: 'transparent'
        //
    },
    separator: {
        height: 0,
        backgroundColor: 'transparent'
    },
    detail: {
        flex: 1,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "#fff"
    },
    detailAds: {
        height: 259,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "#fff"
    },
    linearGradient2: {
        marginTop: 0,
        height: imgHeight,
        width: width,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent"
    },
    thumb: {
        justifyContent: 'flex-end',
        alignItems: 'stretch',
        height: imgHeight,
        width: width,
        alignSelf: 'auto',
        right: 0
    },
    searchListView: {
        margin: 0,
        backgroundColor: 'white'
    },

    likedItemContainer: {
        flexDirection: 'row',
        position: 'absolute',
        backgroundColor: 'transparent',
        justifyContent: 'space-between',
        top: imgHeight - 53,
        width: width
    },

    searchListViewRowAlign: {
        backgroundColor: 'transparent',
        flexDirection: 'column',
        justifyContent: 'center',
        width: 2*width/3,
        marginLeft: 17,
        bottom:7
    },

    leftTextGroup: {
        position: 'absolute',
        backgroundColor: 'transparent',
        flexDirection: 'column',
        top: imgHeight - 43,
        width: width,
        marginLeft: 17
    },
    viewChildGia:{
        backgroundColor:'transparent',
        flexDirection:'column'
    },

    title: {
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily
    },
    price: {
        fontSize: 17,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily
    },
    text: {
        fontSize: 13,
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        fontFamily: gui.fontFamily,
        marginTop: 2,
        fontWeight: '300'
    },
    textLyDo: {
        textAlign: 'center',
        color: '#fff',
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight : 'bold'
    },
    heartContent: {
        backgroundColor: 'transparent',
        marginRight: 10,
        position: "absolute",
        left: width-65,
        top: -122

    },
    viewChangeButton: {
        marginTop:9,
        backgroundColor: 'rgba(211,211,211,0.9)',
        marginRight: 10,
        position: "absolute",
        left: width-116,
        top: -122,
        width: 80,
        height: 20,
        right: 26,
        justifyContent: 'center',
        flexDirection: 'row',
        borderRadius: 5
    },
    viewEditButton:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        borderTopLeftRadius: 3,
        borderBottomLeftRadius: 3
    },
    viewDeleteButton:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#ff2714',
        borderTopRightRadius: 3,
        borderBottomRightRadius: 3
    },
    ngayDangTinView: {
        marginTop:9,
        backgroundColor: 'transparent',
        // marginRight: 17,
        position: "absolute",
        left: width/2 - 19,
        top: -122,
        height: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    lamMoiTinView: {
        marginTop:9,
        backgroundColor: 'rgba(211,211,211,0.9)',
        marginRight: 10,
        position: "absolute",
        left: 0,
        top: -122,
        width: 90,
        height: 20,
        justifyContent: 'center',
        borderRadius: 5
    },
    lamMoiTinButton:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        borderRadius: 3
    },
    lamMoiTinText: {
        color : "white",
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight : 'bold'
    },
    heartButton: {
        marginTop: 6,
        marginRight: 10
    },
    heartButton2: {
        marginTop: 8,
        marginRight: 8,
        marginLeft: 21
    },

    smallText1: {
        fontSize: 13,
        textAlign: 'left',
        color: 'white',
        fontFamily: gui.fontFamily,
        fontWeight: '300'
    },
    linkText  : {
        fontFamily: gui.fontFamily,
        fontSize: gui.normalFontSize,
        color : gui.mainColor
    },
    rightTextGroup: {
        position: 'absolute',
        backgroundColor: 'transparent',
        flexDirection: 'column',
        top: imgHeight - 120,
        width: 180,
        right: 19,
        left: width/ 2,
        paddingLeft: 4,
        paddingTop: 5,
        alignItems : 'flex-start',
        justifyContent: 'flex-end'
    },
    nangCap : {
        backgroundColor: '#ff2714',
        flexDirection: 'row',
        padding: 3,
        width: 80,
        borderRadius : 3,
        marginBottom: 7,
        marginTop: 7,
    },
    textNangCap : {
        color : "white",
        fontFamily: gui.fontFamily,
        fontSize: 10,
        fontWeight : 'bold'
    },
    textEachButton: {
        color : "#403f42",
        fontFamily: gui.fontFamily,
        fontSize: 15,
        fontWeight : '500',
        marginLeft: 8
    },

    textGoiTin: {
        fontSize: 11,
        textAlign: 'left',
        color: '#ffff00',
        fontFamily: gui.fontFamily,
        fontWeight : '400',
        marginTop: 4
    },

    tinChoDuyet : {
        fontFamily: gui.fontFamily,
        fontSize: 13,
        color : '#ffde15',
        fontWeight : '500',
        marginLeft: 3
    },

    loadingContent: {
        position: 'absolute',
        top: -23,
        left: width/2,
        alignItems: 'center',
        justifyContent: 'center'
    },
    resultContainer: {
        position: 'absolute',
        top: height/2,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    viewFooter:{
        marginTop: 20,
        width: width,
        height: 50,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textFooter:{
        fontSize: 17,
        textAlign: 'center',
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        color: '#606060'
    },
    viewReject: {
        alignItems : 'center',
        justifyContent: 'center',
        height: 20,
        marginTop: 5,
        backgroundColor: '#ed1b24',
        left: 0,
        width: 90,
        borderRadius: 3
    },
    viewWebsites: {
        alignItems : 'center',
        justifyContent: 'center',
        height: 20,
        backgroundColor: gui.mainColor,
        width: 90,
        borderRadius: 3,
        marginTop: 9,
        position: "absolute",
        left: width/2 - 11,
        top: 4,
    },
    viewNewButton: {
        width: width,
        height: 93,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'column'
    },
    viewTextContent: {
        width: width,
        height: 49,
        justifyContent: 'center',
        alignItems: 'flex-start',
        backgroundColor: '#fff',
        paddingLeft: 17
    },
    viewDetailButton: {
        width: width,
        height: 33,
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row'

    },
    viewEachButton: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        flexDirection: 'row',
        width: width/ 3,
        height: 33
    },
    headerSeparate: {
        borderTopWidth: 0.5,
        height:1,
        width: width,
        borderColor: "#d3d3d3"
    },
    viewDuyetTin: {
        justifyContent:'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        flexDirection: 'column',
        top: -10
    },
    viewCircleTrangThai: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    circleTrangThai: {
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: '#ffde15'
    },
    textNgayDangTin: {
        fontSize: 10,
        fontWeight: 'bold',
        textAlign: 'center',
        height: 20,
        paddingLeft: 5,
        paddingRight: 5
    },
    viewBottomNeedPost: {
        backgroundColor: '#dadee1',
        height: 10,
        width: width,
    },
    viewLoaderAds: {
        flex:1,
        alignItems:'center',
        justifyContent:'flex-start',
    },
    viewChildRow: {
        width: width,
        height: 166,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        paddingLeft: 17,
        borderBottomWidth: 1,
        borderColor: '#eaebed'
    },
    viewLineLoaderRow: {
        height: 14,
        width: width/2 - 20,
        backgroundColor: 'rgba(167, 167, 167, 0.5)',
    },
    viewLamMoiTin : {
        marginTop: 4,
        marginRight: 10,
        position: "absolute",
        left: 17,
        top: 5,
        width: 90,
        height: 14,
    },
    viewLamMoiTin2: {
        marginTop: 4,
        marginRight: 10,
        position: "absolute",
        left: width - 154,
        top: 5,
        width: 115,
        height: 14,
    },
    viewTotalGoiLogo: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingLeft: 0,
        paddingRight: 0
    },
    viewEachLogo: {
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 0,
        padding: 2
    },
    ngayHetHanView: {
        marginTop:9,
        backgroundColor: 'transparent',
        // marginRight: 17,
        position: "absolute",
        left: width/2 - 19,
        top: -100,
        height: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textNgayHetHan: {
        fontSize: 10,
        fontWeight: 'bold',
        textAlign: 'center',
        height: 20,
        paddingLeft: 5,
        paddingRight: 5
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(NewAdsListTab);
