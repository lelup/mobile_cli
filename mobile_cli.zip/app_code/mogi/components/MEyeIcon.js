import React, {Component} from 'react';

import RelandIcon from './RelandIcon';

var {
    StyleSheet,
    View,
    TouchableOpacity
} = require('react-native');

class MEyeIcon extends React.Component{
    constructor(props){
        super(props);
    }

    render() {
        var {onPress, mainProps, color, bgColor, size, noAction, bgStyle} = this.props;

        return (
            <TouchableOpacity onPress={onPress}>
                <View style={mainProps||styles.eyeContent}>
                    <View style={styles.eyeContent2}>
                        <RelandIcon name="eye-b" mainProps={bgStyle||styles.eyeButton1}
                                    color={bgColor||'#4A443F'} size={size||35}
                                    noAction={noAction} textProps={{paddingLeft: 0}}
                                    onPress={onPress}/>

                    </View>
                    <RelandIcon name="eye-o" mainProps={styles.eyeButton2}
                                color={color||'white'} size={size||35}
                                noAction={noAction} textProps={{paddingLeft: 0}}
                                onPress={onPress}/>

                </View>
            </TouchableOpacity>
        );
    }
}

var styles = StyleSheet.create({
    eyeContent: {
    },
    eyeContent2: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 0,
        right: 0,
        left: 0,
        bottom: 0,
        paddingLeft: 20
    },
    eyeButton1: {
        opacity: 0.55,
        paddingLeft: 20
    },
    eyeButton2: {
        paddingLeft: 20
    }
});

module.exports = MEyeIcon;
