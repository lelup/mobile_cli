import React from 'react';
import {
  Text,
  TextInput,
  View,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  StyleSheet,
  Platform,
  Alert,
  AlertIOS,
  StatusBar
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import gui from '../../lib/gui';
import moment from 'moment';
import Toast, {DURATION} from '../toast/Toast';

import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();

import log from '../../lib/logUtil';

import cfg from "../../cfg";
var rootUrl = `https://${cfg.server}`;

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import ScalableText from 'react-native-text';
import GiftedSpinner from "../../components/GiftedSpinner";
import Camera from 'react-native-camera';
import DanhMuc from '../../assets/DanhMuc';
import TruliaIcon from '../TruliaIcon';

import * as globalActions from '../../reducers/global/globalActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as authActions from '../../reducers/auth/authActions';

var Analytics = require('react-native-firebase-analytics');

const actions = [
    globalActions,
    registerActions,
    postAdsActions,
    authActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class Register extends React.Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('light-content');
        this.state = {
            avatar: null,
            verifyCode: null,
            isFetching: false
        }
    }
    
    _scrollToInput(reactNode: any) {
        this.refs.scroll.scrollToFocusedInput(reactNode)
    }
    
    render(){
        let defaultImg = require('../../assets/image/user.png');
        let imgUrl = !this.props.register.image || this.props.register.image.length<=0 ?
            defaultImg : {uri: this.props.register.image};
        return(
          <View style={styles.container}>
          <View style={[styles.toolbar, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
            <TouchableOpacity onPress = {() => {this.resetRegister()}} style={styles.viewHuy} >
                   <Text style={styles.textHuy}>Hủy</Text>
            </TouchableOpacity>
            <View style={styles.viewTitle}>
                  <Text style={styles.textTitle}></Text>
            </View>
            <View style={styles.viewCan}></View>
          </View>
          <KeyboardAwareScrollView
              keyboardShouldPersistTaps="always"
              keyboardDismissMode="none"
              ref='scroll'>
            <View style={styles.viewBody}>
              <View style ={styles.viewWelcome}>
                <ScalableText style={styles.textWelcome}>Chào mừng đến với Landber</ScalableText>
              </View>
              <View style ={styles.viewInput1}>
                <TextInput
                  underlineColorAndroid='rgba(0,0,0,0)'
                  returnKeyType='next'
                  selectTextOnFocus={true}
                  editable={false}
                  style={styles.viewTextInput}
                  placeholder="(+84)978 666768" placeholderTextColor='#adb4b7'
                  onChangeText={(text) => {this.props.actions.onRegisterFieldChange('username',text)}}
                  value={this.props.register.username}
                  />
              </View>
              <View style ={styles.viewInput2}>
                <TextInput
                  autoFocus={true}
                  underlineColorAndroid='rgba(0,0,0,0)'
                  returnKeyType='next'
                  secureTextEntry={true}
                  style={styles.viewTextInput}
                  placeholder="Chọn một mật khẩu" placeholderTextColor='#adb4b7'
                  onChangeText={(text) => {this.props.actions.onRegisterFieldChange('matKhau',text)}}
                  value={this.props.register.matKhau}
                  />
              </View>
              <View style ={styles.viewInput2}>
                <TextInput
                  underlineColorAndroid='rgba(0,0,0,0)'
                  returnKeyType='go'
                  style={styles.viewTextInput}
                  placeholder="Họ và tên" placeholderTextColor='#adb4b7'
                  onChangeText={(text) => {this.props.actions.onRegisterFieldChange('fullName',text)}}
                  value={this.props.register.fullName}
                  autoCorrect={false}
                  />
              </View>
              <View style ={styles.viewInput2}>
                  <TouchableOpacity onPress={() => this._onMoiGioiPressed()}
                                    style={[styles.viewType, {flexDirection: 'row', alignItems: 'flex-start'}]}
                  >
                    <TextInput
                        underlineColorAndroid='rgba(0,0,0,0)'
                        returnKeyType='go'
                        style={styles.viewTextInput2}
                        placeholder="Vai trò" placeholderTextColor='#adb4b7'
                        value={this._getMoiGioi()}
                        autoCorrect={false}
                        editable={false}
                    />
                      <View style={styles.arrowIcon}>
                          <TruliaIcon name={"arrow-right"} color={gui.arrowColor} size={18} />
                      </View>
                    </TouchableOpacity>
              </View>
              <TouchableOpacity onPress={this._takePicture.bind(this)}>
                  <View style ={styles.changeImage}>
                      <Image style={styles.detailImage} source={imgUrl} defaultSource={defaultImg} />
                    <Text style={styles.textImage}>Chạm để thêm ảnh đại diện</Text>
                  </View>
              </TouchableOpacity>
              <TouchableOpacity onPress = {this._onThucHien.bind(this)} style={styles.viewAction} >
                  {   this.state.isFetching ?
                      <GiftedSpinner color="white" />
                      : <Text style={styles.textAction} >Thực hiện</Text>
                  }
              </TouchableOpacity>
                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/3 - 40}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
              <View style={styles.addViewBottom}></View>
            </View>
          </KeyboardAwareScrollView>
          </View>
        );
    }

    _takePicture() {
       Camera.checkDeviceAuthorizationStatus().then(
           (e) => {
               if (e){
                   Actions.PostAds({owner: 'register'});
               } else {
                   Alert.alert('Thông báo', gui.INF_CameraAccess);
               }
       });
    }

    resetRegister(){
        this.props.actions.onRegisterFieldChange('matKhau', '');
        this.props.actions.onRegisterFieldChange('fullName', '');
        this.props.actions.onRegisterFieldChange('broker', null);
        this.props.actions.onRegisterFieldChange('image', null);
        this.props.actions.onRegisterFieldChange('thumbnail', null);
        Actions.pop();
    }

    _onThucHien() {
        if (!this.validateData())
            return;

        let username = this.props.register.username;
        let destinationType = username.indexOf("@") > -1 ? "email" : "số điện thoại";

        if (this.props.needVerify){
            this.setState({isFetching: true});
            this.props.actions.requestVerifyCode({username: this.props.register.username, verifyType: DanhMuc.VERIFY_TYPE.register})
                .then ((res) => {
                    this.setState({isFetching: false});
                    if (res.success){
                        AlertIOS.prompt ('Nhập mã xác nhận',
                            `Mã xác nhận đã được gửi đến ${destinationType} của bạn`,
                            [{text: 'Xong', onPress: this._onVerifyCodePress.bind(this)}, {text: 'Hủy', style: 'cancel'}], 'plain-text');
                    } else {
                        Alert.alert("Thông báo", "Hệ thống gửi mã xác nhận không thành công. Xin vui lòng kiểm tra lại số điện thoại hoặc thực hiện lại sau 15 phút.");
                    }
                });

        } else {
            this._doRegister();
        }
    }

    _onVerifyCodePress(code){
        if (!code){
            // Alert.alert("Thông báo", gui.VERIFY_CODE_IS_EMPTY);
            this.refs.toastTop && this.refs.toastTop.show(gui.VERIFY_CODE_IS_EMPTY,DURATION.LENGTH_LONG);
            return;
        }
        this.setState({verifyCode: code});
        this._doRegister();
    }

    _doRegister(){
        var filepath = this.props.register.image;
        if (!filepath) {
            this.state.avatar = null;
            this.register();
            return;
        }
        var ms = moment().toDate().getTime();
        var userID = this.props.register.username;
        var filename = 'Avatar_' + userID + '_' + ms + filepath.substring(filepath.lastIndexOf('.'));
        this.props.actions.onUploadImage(filename, filepath, this.uploadCallBack.bind(this));
    }

    uploadCallBack(err, result) {
        var {data} = result;
        if (err || data == '') {
            return;
        }
        var {success, file} = JSON.parse(data);
        if (success) {
            var {url} = file;
            this.state.avatar = url;
            this.register();
        }
    }

    register()  {
        if (this.validateData()) {
            let username = this.props.register.username;
            let userDto = {
                username: username,
                phone: username.indexOf("@") > -1 ? undefined : username.toLowerCase(),
                email: username.indexOf("@") > -1 ? username.toLowerCase() : undefined,
                verifyCode: this.state.verifyCode || undefined,
                verifyType: DanhMuc.VERIFY_TYPE.register,
                fullName: this.props.register.fullName,
                matKhau: this.props.register.matKhau,
                avatar: this.state.avatar || undefined,
                broker: this.props.register.broker || undefined,
                source: 'mobile',
                deviceID: this.props.global.deviceInfo.deviceID || undefined,
                deviceModel: this.props.global.deviceInfo.deviceModel || undefined,
                tokenID: this.props.global.deviceInfo.tokenID || undefined,
                tokenOs: this.props.global.deviceInfo.tokenOs || undefined,
                tokenRegistered: this.props.global.deviceInfo.tokenRegistered || undefined,
                appVersion: this.props.global.deviceInfo.appVersion || undefined
            };

            this.setState({isFetching: true});

            this.props.actions.registerUser(userDto)
                .then((res) =>{
                    this.setState({isFetching: false});
                    if (!res.login || res.login==false) {
                        Alert.alert('Thông báo', res.msg);
                    } else {
                        Alert.alert('Thông báo', gui.INFO_userCreatedSuccessfully);
                        Actions.pop();
                        Actions.pop();
                        this.props.actions.registerSuccess(userDto);
                        this.doLogin(userDto);
                    }
                });

            Analytics.logEvent('REGISTER', {deviceID: userDto.deviceID, userInfo: userDto});
        }
    }

    doLogin(dto){
        let userDto = {
            username: dto.username,
            password: dto.matKhau
        };

        const deviceDto = {
            ... this.props.global.deviceInfo
        };

        this.props.actions.login(userDto.username, userDto.password, deviceDto)
            .then((res) => {
                if (res.login ===true) {
                    if (this.props.onLoginSuccess) {
                        this.props.onLoginSuccess();
                    } else {
                        Actions.pop();
                        Actions.pop();
                        if (this.props.doFinalAction){
                            this.props.doFinalAction();
                        }
                    }
                } else {
                    // Alert.alert('Thông báo', 'Mật khẩu đăng nhập không đúng!');
                    this.refs.toastTop && this.refs.toastTop.show('Mật khẩu đăng nhập không đúng!',DURATION.LENGTH_LONG);
                }
            })
            .catch((res) => {
                Alert.alert('Thông báo', res.toString());
            })
    }

    validateData() {
        if (!this.props.register.username) {
            // Alert.alert('Thông báo', gui.ERR_dataRequired + "tên đăng nhập!");
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "tên đăng nhập!",DURATION.LENGTH_LONG);
            return false;
        }
        if (!this.props.register.matKhau) {
            // Alert.alert('Thông báo', gui.ERR_dataRequired + "mật khẩu!");
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "mật khẩu!",DURATION.LENGTH_LONG);
            return false;
        }
        if (!this.props.register.fullName || this.props.register.fullName.length <=0) {
            // Alert.alert('Thông báo', gui.ERR_dataRequired + "tên đầy đủ!");
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "tên đầy đủ!",DURATION.LENGTH_LONG);

            return false;
        }

        if (!this.props.register.broker || this.props.register.broker.length <=0) {
            // Alert.alert('Thông báo', gui.ERR_dataRequired + "vai trò!");
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "vai trò!",DURATION.LENGTH_LONG);

            return false;
        }
        return true;
    }

    _onMoiGioiPressed(){
        Actions.MoiGioi({func: "register", moiGioiKey:this.props.register.broker});
    }

    _getMoiGioi(){
        return DanhMuc.MoiGioi[this.props.register.broker]||'';
    }

}

const styles = StyleSheet.create({

  toolbar :{
    height: 64,
    flexDirection:'row',
    backgroundColor:'#f5f6f7',
    borderBottomWidth:1,
    borderColor:'#e8e9e9'
  },
  container: {
    backgroundColor:'white',
    flex:1,
    alignItems:'center'
  },
  viewHuy: {
    width: 40,
    marginLeft:12, 
    marginTop: 30 
  },
  textHuy: {
    fontSize: 17,
    color: gui.mainColor,
    fontFamily: gui.fontFamily
  },
  viewTitle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textTitle: {
    fontSize: 18,
    color: 'white' 
  },
  viewCan: {width: 40},
  viewBody: {
    flex:1, 
    alignItems:'center'
  },
  viewWelcome: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:47
  },
  textWelcome: {
    fontSize:23,
    color:'black',
    fontFamily: gui.fontFamily
  },
  viewInput1: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:34
  },
  viewTextInput: {
    fontFamily: gui.fontFamily,
    backgroundColor:'white',
    width: width- 40,
    height:37,
    borderRadius: 6,
    borderWidth:1, 
    borderColor:'#c6cbce',
    fontSize: 15,
    paddingLeft: 10
  },
    viewType: {
        backgroundColor:'white',
        width: width- 40,
        height:37,
        borderRadius: 6,
        borderWidth:1,
        borderColor:'#c6cbce',
        paddingLeft: 10
    },
    viewTextInput2: {
        fontFamily: gui.fontFamily,
        backgroundColor:'white',
        width: width- 120,
        height:35,
        borderColor:'#c6cbce',
        fontSize: 15
    },
    arrowIcon: {
        backgroundColor:'transparent',
        justifyContent: 'center',
        alignItems: 'flex-end',
        width: 58,
        height:35,
        marginRight: 2
    },
  viewInput2: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:10.5
  },
  changeImage: {
    alignItems: 'center',
    marginTop:16, 
    flexDirection:'row',
    width: width- 40
  },
  detailImage: {
    width: 40,
    height: 40,
    borderRadius: 20
  },
  textImage: {
    fontSize:13,
    color:'#a9a9a9',
    marginLeft: 10,
    fontFamily: gui.fontFamily,
    marginBottom:7
  },
  viewAction: {
    backgroundColor:gui.mainColor,
    borderRadius: 6,
    marginTop: 14,
    justifyContent: 'center',
    alignItems: 'center', 
    width: width- 39,
    height: 39
  },
  textAction: {
    fontSize:18,
    color:'white',
    fontFamily: gui.fontFamily
  },
  addViewBottom: {
    height:20,
    width:width,
    backgroundColor:'#fff'
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(Register);
