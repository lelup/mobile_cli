import React from 'react';
import {
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    StyleSheet,
    Platform,
    Alert,
    StatusBar
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import utils from '../../lib/utils';
import Toast, {DURATION} from '../toast/Toast';
var {width, height} = utils.getDimensions();
var Modal  = require('react-native-modalbox');

import Icon from 'react-native-vector-icons/FontAwesome';
import gui from '../../lib/gui';
import log from '../../lib/logUtil';
import GiftedSpinner from 'react-native-gifted-spinner';
import ScalableText from 'react-native-text';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';


const actions = [
    globalActions,
    authActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class UserComeback extends React.Component {

    constructor(props) {
        log.info("UserBack.constructor");
        super(props);
        StatusBar.setBarStyle('dark-content');
        
        this.state = {
         username: props.username,
         password: '',
         email: '',
         phone: '',
         maKichHoat: '',
         newPassword: '',
         verifyCode: '',
         progressLogin: false
        };

    }

    forgetPassWord() {
        this.refs.modalForgetPassword.open();
    }

    resetPassword() {
        this.props.actions.forgotPassword(this.state.username)
            .then((e) => {
                if (!e.success){
                   this.refs.toastTop && this.refs.toastTop.show(e.msg,DURATION.LENGTH_LONG);
                }
            });
        this.refs.modalResetPassword.open();
        let username = this.state.username;
        let maXacNhanHint = username.indexOf("@")>=0 ? 'Mã xác nhận đã được gửi tới email ' + username :
        'Mã xác nhận đã được gửi tới số điện thoại ' + username;
        setTimeout(() => {this.refs.toastTop && this.refs.toastTop.show(maXacNhanHint,5000)}, 1000);
    }

    _onHuyPress(){
        Actions.pop();
    }

    _onThucHienPress(){
        log.info("UserComeback._onThucHienPress");
        if (!this.state.password){
            // Alert.alert('Thông báo', 'Bạn chưa nhập mật khẩu!');
            this.refs.toastTop && this.refs.toastTop.show('Bạn chưa nhập mật khẩu!',DURATION.LENGTH_LONG);
            return;
        }
        this.setState({progressLogin: true});
        let userDto = {
            username: this.state.username,
            password: this.state.password
        };

        const deviceDto = {
            ... this.props.global.deviceInfo
        };

        this.props.actions.login(userDto.username, userDto.password, deviceDto)
            .then((res) => {
                if (res.login ===true) {
                    this.setState({progressLogin: false});
                    if (this.props.onLoginSuccess) {
                        this.props.onLoginSuccess();
                    } else {
                        Actions.pop();
                        Actions.pop();
                        if (this.props.doFinalAction){
                            this.props.doFinalAction();
                        }
                    }
                } else {
                    // Alert.alert('Thông báo', 'Mật khẩu đăng nhập không đúng!');
                    this.refs.toastTop && this.refs.toastTop.show('Mật khẩu đăng nhập không đúng!',DURATION.LENGTH_LONG);
                    this.setState({progressLogin: false});
                }
            })
            .catch((res) => {
                // Alert.alert('Thông báo', res.toString());
                this.refs.toastTop && this.refs.toastTop.show(res.toString(),DURATION.LENGTH_LONG);
            })
    }

    _onThucHienResetPasswordPress(){
        log.info("UserComeback._onThucHienResetPasswordPress");
        let validate = this._validateData();

        if (!validate)
            return;

        this.props.actions.updatePassword(this.state.username, this.state.verifyCode, this.state.newPassword)
            .then((e) => {
                if (e.success){
                    Alert.alert('Thông báo', 'Đổi mật khẩu thành công.');
                    Actions.Home({type: 'reset'});
                    Actions.NewLogin();
                } else {
                    let msg = e.msg || "Thay đổi mật khẩu không thành công.";
                    // Alert.alert('Thông báo', msg);
                    this.refs.toastPass.show(msg,DURATION.LENGTH_LONG);
                }
            });
    }

    _validateData(){
        if (!this.state.username || this.state.username.length <=0 ){
            // Alert.alert('Thông báo', "Tên đăng nhập sai định dạng.");
            this.refs.toastPass.show("Tên đăng nhập sai định dạng.",DURATION.LENGTH_LONG);
            return false;
        }

        if (!this.state.verifyCode || this.state.verifyCode.length<=0){
            // Alert.alert('Thông báo', "Mã xác nhận sai định dạng.");
            this.refs.toastPass.show("Mã xác nhận sai định dạng.",DURATION.LENGTH_LONG);
            return false;
        }

        if (!this.state.newPassword || this.state.newPassword.length<=0){
            // Alert.alert('Thông báo', "Bạn chưa nhập mật khẩu.");
            this.refs.toastPass.show("Bạn chưa nhập mật khẩu.",DURATION.LENGTH_LONG);
            return false;
        }

        return true;
    }


    _scrollToInput(reactNode: any) {
        this.refs.scroll.scrollToFocusedInput(reactNode)
    }

    render(){
        // if (this.props.auth.isFetching ||
        //     (this.props.global.loggedIn && !this.props.global.currentUser.userID)) {
        //     return (
        //         <View style={{flex:1, alignItems:'center', justifyContent:'center', marginTop: 30}}>
        //             <GiftedSpinner size="large" />
        //         </View>
        //     )
        // }

        return(
            <View style={styles.container}>
                <View style={[styles.toolbar, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
                    <TouchableOpacity onPress = {this._onHuyPress.bind(this)} style={styles.viewHuy}>
                        <Text style={styles.textHuy}>Hủy</Text>
                    </TouchableOpacity>
                    <View style={styles.viewTitle}>
                        <Text style={styles.textTitle}></Text>
                    </View>
                    <View style={styles.viewCan}></View>
                </View>
                <View style={styles.viewBody}>
                    <View style ={styles.viewWelcome}>
                        <ScalableText style={styles.textWelcome}>Chào mừng bạn quay lại</ScalableText>
                    </View>
                    <View style ={styles.viewInput}>
                        <TextInput
                        autoFocus={true}
                         underlineColorAndroid='rgba(0,0,0,0)'
                         returnKeyType='go'
                         secureTextEntry={true}
                         style={styles.viewTextInput}
                         placeholder="Nhập mật khẩu" placeholderTextColor='#adb4b7'
                         onChangeText={(text) => this.setState({password: (text)})}
                         value={this.state.password}
                         onSubmitEditing={this._onThucHienPress.bind(this)}
                         />
                    </View>
                    <TouchableOpacity onPress = {this._onThucHienPress.bind(this)} style={styles.viewAction} >
                        { (this.props.auth.isFetching ||
                        (this.props.global.loggedIn && !this.props.global.currentUser.userID)) ?
                            <GiftedSpinner color="white" />:<Text style={styles.textAction} >Thực hiện</Text>
                        }
                    </TouchableOpacity>
                    <TouchableOpacity onPress={this.forgetPassWord.bind(this)} style ={styles.viewForgetPass}>
                        <Text style={styles.textForgetPass} >Quên mật khẩu?</Text>
                    </TouchableOpacity>
                </View>

                {this._renderQuenMkModal()}

                {this._renderCapNhatMkModal()}

                <Toast
                    ref="toastTop"
                    position='top'
                    positionValue={height/3 - 40}
                    fadeInDuration={850}
                    fadeOutDuration={1400}
                    opacity={0.56}
                    textStyle={{color:'#fff'}}
                />
            </View>

        );
    }

    _renderQuenMkModal(){
        return (
            <Modal open={this.state.open} style={styles.modalmore} ref={"modalForgetPassword"} position={"center"} swipeToClose={false}>
                <View style={styles.modalContainer}>
                    <View style={[styles.toolbarModalSend, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
                        <TouchableOpacity onPress={()=> this.refs.modalForgetPassword.close()} style={styles.passWordHuy}>
                            <Text style={styles.textPassHuy}>Hủy</Text>
                        </TouchableOpacity>
                        <View style={styles.modalViewTitle}>
                            <Text style={styles.modalTextTile}></Text>
                        </View>
                        <View style={styles.modalTextCan}></View>
                    </View>
                    <View style={styles.modalBody}>
                        <View style ={styles.bodyForget}>
                            <ScalableText style={styles.bodyTextFoget}>Quên mật khẩu?</ScalableText>
                        </View>
                        <TextInput
                         underlineColorAndroid='rgba(0,0,0,0)'
                         style={styles.modalInput}
                         editable={false}
                         value={this.state.username}
                         />

                        <TouchableOpacity onPress={this.resetPassword.bind(this)} style={styles.actionButton} >
                            <Text style={styles.textActionButton}>Tiếp tục</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={()=>this.refs.modalForgetPassword.close()} style ={styles.viewForgetPass}>
                            <Text style={styles.textForgetPass}>Nhớ lại mật khẩu? Đăng nhập.</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        )
    }

    _renderCapNhatMkModal(){
        return (
            <Modal open={this.state.open} style={styles.modalmore} ref={"modalResetPassword"} position={"center"} swipeToClose={false}>
                <View style={styles.modalContainer}>
                    <View style={[styles.toolbarModalSend, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
                        <TouchableOpacity onPress={()=>this.refs.modalResetPassword.close()} style={styles.modalBack} >
                            <Icon name="angle-left" size={40} color="white" />
                        </TouchableOpacity>
                        <View style={styles.modalViewTitle}>
                            <Text style={styles.modalTextTile}>Cập nhật mật khẩu</Text>
                        </View>
                        <View style={styles.modalTextCan}></View>
                    </View>
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'>
                    <View style={styles.modalBody}>
                        <View style ={styles.viewCapNhat}>
                            <ScalableText style={styles.textXacNhan}>Tạo mật khẩu mới cho tài khoản của bạn</ScalableText>
                        </View>

                         <TextInput
                         underlineColorAndroid='rgba(0,0,0,0)'
                         editable={false}
                         style={styles.textInput}
                         value={this.state.username}
                         />
                         <TextInput
                         underlineColorAndroid='rgba(0,0,0,0)'
                         autoCorrect={false}
                         returnKeyType='next'
                         style={styles.textInput}
                         placeholder="Mã xác nhận" placeholderTextColor='#adb4b7'
                         onChangeText={(text) => this.setState({verifyCode: (text)})}
                         value={this.state.verifyCode}
                         />
                         <TextInput
                         underlineColorAndroid='rgba(0,0,0,0)'
                         returnKeyType='go'
                         secureTextEntry={true}
                         style={styles.textInput}
                         placeholder="Mật khẩu mới" placeholderTextColor='#adb4b7'
                         onChangeText={(text) => this.setState({newPassword: (text)})}
                         value={this.state.newPassword}
                         />

                        <TouchableOpacity onPress={() => this._onThucHienResetPasswordPress()} style={styles.actionButton} >
                            <Text style={styles.textActionButton}>Thực hiện</Text>
                        </TouchableOpacity>
                        <Toast
                            ref="toastPass"
                            position='top'
                            positionValue={height/3}
                            fadeInDuration={850}
                            fadeOutDuration={1400}
                            opacity={0.56}
                            textStyle={{color:'#fff'}}
                        />
                    </View>
                    </KeyboardAwareScrollView>
                </View>
            </Modal>
        )
    }
}

const styles = StyleSheet.create({

    toolbar :{
        height: 64,
        flexDirection:'row',
        backgroundColor:'#f5f6f7',
        borderBottomWidth:1,
        borderColor:'#e8e9e9'
    },
    modalmore: {
        position:'absolute',
        backgroundColor: 'white',
        width: width,
        height: height
    },
    toolbarModalSend :{
        height: 64,
        flexDirection:'row',
        backgroundColor:gui.mainColor,
        borderBottomWidth:1,
        borderColor:'#e8e9e9'
    },
    container: {
        backgroundColor:'transparent',
        flex:1,
        alignItems:'center'
    },
    viewHuy: {
        width: 40,
        marginLeft:12,
        marginTop: 30
    },
    textHuy: {
        fontSize: 17,
        color: gui.mainColor,
        fontFamily: gui.fontFamily
    },
    viewTitle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textTitle: {
        fontSize: 18,
        color: 'white'
    },
    viewCan: {
        width: 40
    },
    viewBody: {
        flex:1,
        alignItems:'center'
    },
    viewWelcome: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:46
    },
    textWelcome: {
        fontSize:23,
        color:'black',
        fontFamily: gui.fontFamily
    },
    viewInput: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:35
    },
    viewTextInput: {
        fontFamily: gui.fontFamily,
        backgroundColor:'white',
        width: width- 39,
        height:37,
        borderRadius: 5,
        borderWidth:1,
        borderColor:'#c6cbce',
        fontSize: 15,
        paddingLeft: 10
    },
    viewAction: {
        backgroundColor:gui.mainColor,
        borderRadius: 5,
        marginTop: 10,
        justifyContent: 'center',
        alignItems: 'center',
        width: width- 39,
        height: 38
    },
    textAction: {
        fontSize:18,
        color:'white',
        fontFamily: gui.fontFamily
    },
    viewForgetPass: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:38
    },
    textForgetPass: {
        fontSize:13.5,
        color:'#7b8b91',
        fontFamily: gui.fontFamily
    },
    modalContainer: {
        backgroundColor:'transparent',
        flex:1,
        alignItems:'center'
    },
    passWordHuy: {
        width: 40,
        marginLeft:12,
        marginTop: 30
    },
    textPassHuy: {
        fontSize: 17,
        color: 'white',
        fontFamily: gui.fontFamily
    },
    modalViewTitle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:15
    },
    modalTextTile: {
        fontSize: 18,
        color: 'white'
    },
    modalTextCan: {
        width: 40
    },
    modalBody: {
        flex:1,
        alignItems:'center'
    },
    bodyForget: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:46
    },
    bodyTextFoget: {
        fontSize:21,
        color:'black',
        fontFamily: gui.fontFamily
    },
    modalInput: {
        fontFamily: gui.fontFamily,
        backgroundColor:'white',
        width: width- 39,
        height:38,
        borderRadius: 5,
        borderWidth:1,
        borderColor:'#c6cbce',
        fontSize: 15,
        marginTop:46,
        paddingLeft: 10
    },
    textInput: {
        fontFamily: gui.fontFamily,
        backgroundColor:'white',
        height:38,
        width: width- 39,
        borderRadius: 5,
        borderWidth:1,
        borderColor:'#c6cbce',
        fontSize: 15,
        marginTop:10,
        marginRight: 10,
        marginLeft: 10,
        paddingLeft: 10
    },
    actionButton: {
        backgroundColor:gui.mainColor,
        borderRadius: 5,
        marginTop: 10,
        justifyContent: 'center',
        alignItems: 'center',
        width: width-39,
        height: 38
    },
    textActionButton: {
        fontSize:18,
        color:'white',
        fontFamily: gui.fontFamily
    },
    modalBack: {
        width: 40,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:15
    },
    viewXacNhan: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:28
    },
    viewCapNhat: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:46
    },
    textXacNhan: {
        fontSize:19,
        color:'black',
        fontFamily: gui.fontFamily
    },

});

export default connect(mapStateToProps, mapDispatchToProps)(UserComeback);
