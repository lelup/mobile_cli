import React from 'react';
import {
  Text,
  TextInput,
  View,
  Image,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Alert,
  StatusBar
} from 'react-native';

const FBSDK = require('react-native-fbsdk');
const {
    LoginManager,
    AccessToken,
    GraphRequest,
    GraphRequestManager,
} = FBSDK;


import {Actions} from 'react-native-router-flux';
import gui from '../../lib/gui';
import utils from '../../lib/utils';
import log from '../../lib/logUtil';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import GiftedSpinner from "../../components/GiftedSpinner";
import Toast, {DURATION} from '../toast/Toast';
import Icon from 'react-native-vector-icons/FontAwesome';

const {width, height} = utils.getDimensions();

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';
import ScalableText from 'react-native-text';

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as registerActions from '../../reducers/register/registerActions';


const actions = [
  globalActions,
  authActions,
  registerActions
];

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  const creators = Map()
      .merge(...actions)
      .filter(value => typeof value === 'function')
      .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

class Login extends React.Component {

  constructor(props) {
    super(props);

    StatusBar.setBarStyle('default');
    this.state = {
      username: '',
      checkingUser: false,
        name : '',
        pic : ''
    };
  }

    render(){
    return(
      <View style={styles.container}>
      <View style={[styles.toolbar, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
        <TouchableOpacity style={styles.loginTouch01} onPress={this._onHuyPress.bind(this)}>
               <Text style={styles.loginText01}>Hủy</Text>     
        </TouchableOpacity>
        <View style={styles.viewCenter}>
              <Text style={styles.textViewCenter}></Text>
        </View> 
        <View style={styles.viewDoi}></View> 
      </View>
        <View style={styles.viewDetail}>
          <View style ={styles.wiewWelcome}>
            <ScalableText style={styles.textWelcome}>Đăng nhập hoặc đăng ký</ScalableText>
          </View>
          <KeyboardAwareScrollView
              keyboardShouldPersistTaps="always"
              keyboardDismissMode="none"
              ref='scroll'>
            <View style ={styles.viewInput}>
                <TextInput
                    autoFocus={false}
                    autoCapitalize='none'
                    autoCorrect={false}
                    returnKeyType='done'
                    underlineColorAndroid='rgba(0,0,0,0)'
                    style={styles.viewTextInput}
                    placeholder="Nhập số điện thoại hoặc email" placeholderTextColor={gui.arrowColor}
                    onChangeText={(text) => {this._onUsernameTextChange(text)}}
                    value={this.state.username}
                    onSubmitEditing={this._onThucHien.bind(this)}
                />
            </View>
            <TouchableOpacity onPress = {this._onThucHien.bind(this)} style={styles.buttonAction} >
                {   this.state.checkingUser ?
                    <GiftedSpinner color="white" />
                    : <Text style={styles.buttonTextAction} >Thực hiện</Text>
                }

            </TouchableOpacity>
              <Toast
                  ref="toastTop"
                  position='top'
                  positionValue={height/3 - 40}
                  fadeInDuration={850}
                  fadeOutDuration={1400}
                  opacity={0.56}
                  textStyle={{color:'#fff'}}
              />
          </KeyboardAwareScrollView>
          {/*<View style ={styles.buttonRegister}>*/}
            {/*<Text style={styles.buttonTextRegister} >Hoặc đăng nhập với</Text>*/}
            {/*<TouchableOpacity onPress={this._onFacebookLogin.bind(this)}>*/}
              {/*<Icon name="facebook-square" size={38} color="#4f7cbf" style={{marginLeft: 8}} />*/}
            {/*</TouchableOpacity>*/}

              {/*<TouchableOpacity onPress={this._onGoogleLogin.bind(this)}>*/}
                  {/*<Icon name="google-plus-square" size={38} color="#df492e" style={{marginLeft: 8}} />*/}
              {/*</TouchableOpacity>*/}
          {/*</View>*/}

          <View style ={styles.viewAccept}>
            <Text style={styles.textAccept}>Tôi đồng ý với điều khoản dịch vụ của Landber</Text>
          </View>
        </View>
      </View>

    );
  }

    _onFacebookLogin() {
        LoginManager.logInWithReadPermissions(['public_profile','email','user_friends']).then(
            (result) => {
                log.info('============> result', result);
                if (result.isCancelled) {
                    log.info('Login cancelled');
                } else {
                   log.info('Login success with permissions: ' +result.grantedPermissions.toString());
                    AccessToken.getCurrentAccessToken().then((data) => {
                        const { accessToken } = data;
                        if(data) { this.initUser(accessToken);}
                    })
                }
            },
            (error) => {
                log.info('Login fail with error: ' + error);
            }
        );
    }

    initUser(token) {
        fetch('https://graph.facebook.com/v2.10/me?fields=id,picture,email,name,friends&access_token=' + token)
            .then((response) => response.json())
            .then((json) => {
                log.info('=============> json', json);
                this.setState({
                    name: json.name,
                    pic: json.picture.data.url
                });
            })
            .catch(() => {
                reject('ERROR GETTING DATA FROM FACEBOOK')
            })
    }

    // Login Fb case:
    /*
    - Đăng nhập Fb: check tài khoản có tồn tại trong hệ thống ko, nếu tồn tại thì bắt user verify -> hệ thống gửi code
                    màn hình verifyCode -> verify thành công thì mật khẩu mới ntn ? có phải là code mã verify
                    mới gửi đến ko. lần sau khi đăng nhập băng facebook thì ntn

                    + Nếu tài khoản chưa đăng kí, sau khi đăng nhập Fb thành công thì gửi cho user 1 code
                    bắt người dùng nhập code verify ? cũng chính là passWord của User sau khi nhập code thành công.
                    Khi đăng nhập lần sau check name và Id Fb gửi lên?

     */

    _onGoogleLogin() {
        log.info('============> google Login');
    }

  _onUsernameTextChange(text){
    this.setState({username: text.replace(" ","")});
  }

  _onHuyPress(){
      if (this.props.onHuy)
          this.props.onHuy();
      Actions.pop() ;
  }

  _onThucHien(){
    if (!this.validate()){
        this.refs.toastTop && this.refs.toastTop.show('Số điện thoại hoặc địa chỉ email không đúng định dạng.',DURATION.LENGTH_LONG);
      return;
    }
    let username = this.state.username.toLowerCase();
    this.setState({checkingUser: true});
    this.props.actions.checkUserExist(username).then(
        (res) => {
          log.info("Login._onThucHien");
          if (res.exist){
            this.setState({checkingUser: false});
            Actions.UserComeback({username: username, doFinalAction: this.props.doFinalAction});
          }else {
            if (res.status == 101){
                this.setState({checkingUser: false});
                this.refs.toastTop && this.refs.toastTop.show('Không đăng ký/đăng nhập được hệ thống',DURATION.LENGTH_LONG);
            } else {
                this.setState({checkingUser: false});
                this.props.actions.onRegisterFieldChange('username',username);
                Actions.Register({needVerify: true});
                // if (res.adsList && res.adsList.length >0 ){
                //     Actions.Register({needVerify: true});
                // } else {
                //     Actions.Register({needVerify: false});
                // }

            }
          }
        }
    )
  }

  validate(){
    let username = this.state.username;

    if (!username || username.length <= 0)
        return false;

    if (username.indexOf("@")>=0){
        return utils.validateEmail(username);
    }

    return utils.validatePhone(username);
  }
}

const styles = StyleSheet.create({
 toolbar :{
  height: 64,
  flexDirection:'row',
  backgroundColor:'#f5f6f7',
  borderBottomWidth:1,
  borderColor:'#e8e9e9'
  },
  container: {
    backgroundColor:'transparent', 
    flex:1,
    alignItems:'center'
  },
  loginTouch01: {
    width: 40,
    marginLeft: 12,
    marginTop: 30 
  },
  loginText01: {
    fontSize: gui.fontSize,
    color: gui.mainColor,
    fontFamily: gui.fontFamily
  },
  viewCenter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textViewCenter: {
    fontSize: 18,
    color: 'white'
  },
  viewDoi: {
    width: 40
  },
  viewDetail: {
    flex:1,
    alignItems:'center'
  },
  wiewWelcome: {
    justifyContent: 'center',
    alignItems: 'center', 
    marginTop:36
  },
  textWelcome: {
    fontSize:23, 
    color:'black',  
    fontFamily: gui.fontFamily
  },
  viewInput: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:13
  },
  viewTextInput: {
    fontFamily: gui.fontFamily,
    fontSize: gui.normalFontSize,
    backgroundColor:'white',
    width: width- 39,
    height:38, 
    borderRadius: 5,
    borderWidth:1,
    borderColor:'#c6cbce',
    paddingLeft: 10,
    paddingRight: 10
  },
  buttonAction: {
    backgroundColor: gui.mainColor,
    borderRadius: 5, 
    marginTop: 10, 
    justifyContent: 'center', 
    alignItems: 'center',  
    width: width- 39,
    height: 38
  },
  buttonTextAction: {
    fontSize:18, 
    color:'white',
    fontFamily: gui.fontFamily
  },
  buttonRegister: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 18, 
    flexDirection:'row'
  },
  buttonTextRegister: {
    fontSize: 15,
    color:'black',
    fontFamily: gui.fontFamily
  },
  loginFacebook: {
    width: 30, 
    height: 30,
    marginLeft: 5
  },
  viewAccept: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8
  },
  textAccept: {
    fontSize:13,
    color:'#7b8b91',
    fontFamily: gui.fontFamily
  }
   
});

export default connect(mapStateToProps, mapDispatchToProps)(Login);
