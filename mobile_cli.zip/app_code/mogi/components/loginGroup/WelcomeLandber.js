import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    TouchableHighlight,
    Alert,
    StatusBar
} from 'react-native';

import GiftedSpinner from "../../components/GiftedSpinner";
import Icon from 'react-native-vector-icons/FontAwesome';
import {Actions} from 'react-native-router-flux';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';
var Analytics = require('react-native-firebase-analytics');

const FBSDK = require('react-native-fbsdk');
const {
    LoginManager,
    AccessToken,
    GraphRequest,
    GraphRequestManager,
} = FBSDK;

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as registerActions from '../../reducers/register/registerActions';

const actions = [
    globalActions,
    authActions,
    registerActions
];
import gui from '../../lib/gui';
import OfflineBar from '../line/OfflineBar';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
let {width, height} = utils.getDimensions();
import Toast, {DURATION} from '../toast/Toast';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';


function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class WelcomeLandber extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading : false
        }
    }

    componentWillMount() {
        StatusBar.setBarStyle('default');
    }

    _onChangeInitial() {
        this.props.actions.onHelpedModalChange('welcomeInitial', true);
        let {help} = this.props.global;
        let helped = utils.cloneRecord(help);
        helped.welcomeInitial = true;
        this.props.actions.updateLocalHelped(helped);
    }

    render() {
        let logoIcon = require('../../assets/image/logo.png');
        let textAccept = 'Bằng việc đăng ký tài khoản trên ứng dụng Landber Agent bạn đồng ý với các Điều khoản, Quy định dịch vụ, Chính sách thanh toán do chúng tôi đề ra.';
        return (
            <View style={styles.container}>
                <OfflineBar />
                <ScrollView contentContainerStyle={styles.scrollView}
                            style={{flex: 1}}
                            automaticallyAdjustContentInsets={false}
                            vertical={true}>
                        <TouchableOpacity style={styles.viewTextLogin}
                                          onPress={this._onPressDangNhap.bind(this)}
                        >
                            <Text style={styles.textLogin}>Đăng nhập</Text>
                        </TouchableOpacity>
                        <View style={styles.viewLogo}>
                            <Image
                                style={styles.logoIcon}
                                resizeMode={Image.resizeMode.cover}
                                source={logoIcon}
                            />
                        </View>
                        <View style={styles.viewTextWelcome}>
                            <Text style={styles.textWelCome}>Chào mừng bạn đến với Landber Agent</Text>
                        </View>
                        <Toast
                            ref="toastTop"
                            position='top'
                            positionValue={138}
                            fadeInDuration={850}
                            fadeOutDuration={1400}
                            opacity={0.56}
                            textStyle={{color:'#fff'}}
                        />
                        {this._renderButtonLogin()}
                        {/*<TouchableOpacity style={styles.viewAccept}>
                            <Text style={[styles.textFbStart,{color: '#526173'}]}
                                  onPress={this._onPressAccept.bind(this)}>
                                Bỏ qua & vào giao diện sử dụng ngay
                            </Text>
                        </TouchableOpacity>*/}
                        <View style={styles.viewChinhSach}>
                            <Text style={[styles.textFbStart,{color: '#526173', textAlign: 'justify'}]}>
                                {textAccept}
                            </Text>
                        </View>
                </ScrollView>
                {this._renderLoadingView()}
            </View>
        );
    }

    _renderLoadingView() {
        if (this.props.auth.isLoggingIn || this.props.register.loggingByFB) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' />
            </View>)
        }
    }

    _renderButtonLogin() {
        return(
          <View style={styles.viewTwoButton}>
              {/* <TouchableOpacity style={styles.viewLoginFB}
                                onPress={this._onPresFbLogin.bind(this)}
              >
                  <Icon name="facebook-square" size={22} color="#fff" style={styles.viewIconFb} />
                  <Text style={styles.textFbStart}>BẮT ĐẦU VỚI FACEBOOK</Text>
              </TouchableOpacity> */}
              <TouchableOpacity style={styles.viewCreateButton}
                                onPress={this._onPressCreate.bind(this)}
              >
                  <Text style={[styles.textFbStart, {color: '#526173'}]}>TẠO TÀI KHOẢN</Text>
              </TouchableOpacity>
          </View>
        );
    }

    _onPressDangNhap() {
        Actions.NewLogin();
        this._onChangeInitial();
    }
 
    _onPresFbLogin() {
        LoginManager.logInWithReadPermissions(['public_profile','email','user_friends']).then(
            (result) => {
                log.info('============> result', result);
                if (result.isCancelled) {
                    log.info('Login cancelled');
                } else {
                    log.info('Login success with permissions: ' +result.grantedPermissions.toString());
                    AccessToken.getCurrentAccessToken().then((data) => {
                        const { accessToken } = data;
                        // this.props.actions.onRegisterFieldChange('fbToken', accessToken);
                        if(data) { this.initUser(accessToken);}
                        else { LoginManager.logOut()}
                    })
                }
            },
            (error) => {
                log.info('Login fail with error: ' + error);
            }
        );
        this._onChangeInitial();
    }

    initUser(token) {        
        fetch('https://graph.facebook.com/v2.10/me?fields=id,picture,email,name,friends&access_token=' + token)
            .then((response) => response.json())
            .then((json) => {
                this.register(token,json);
            })
            .catch(() => {
                log.info('ERROR GETTING DATA FROM FACEBOOK')
            })
    }

    // _onPresFbLogin() {
    //     this.refs.toastTop && this.refs.toastTop.show('Coming soon!',DURATION.LENGTH_LONG);
    //     this._onChangeInitial();
    // }

    register(token, json)  {        
        let username = json.name || '';
        let email =  json.email || '';
        let phone = json.phone || '';
        let avatar = json.picture.data.url || undefined;
        let id = json.id;
        let userDto = {
            username: id,
            phone: phone,
            email: email.indexOf("@") > -1 ? email.toLowerCase() : undefined,
            fbID: id || undefined,
            verifyCode: undefined,
            verifyType: DanhMuc.VERIFY_TYPE.register,
            fullName: username || undefined,
            matKhau: '123456',
            avatar: avatar || undefined,
            broker:  undefined,
            source: 'mobile',
            deviceInfo: {
                deviceID: this.props.global.deviceInfo.deviceID || undefined,
                deviceModel: this.props.global.deviceInfo.deviceModel || undefined
            },
            tokenID: this.props.global.deviceInfo.tokenID || undefined,
            tokenOs: this.props.global.deviceInfo.tokenOs || undefined,
            tokenRegistered: this.props.global.deviceInfo.tokenRegistered || undefined,
            appVersion: this.props.global.deviceInfo.appVersion || undefined,
            fbAccessToken: token
        };
        // log.info('==============> userDto', userDto);

        this.props.actions.registerUserUsingFB(userDto)
            .then((res) =>{
                if (!res.login || res.login==false) {
                    Alert.alert('Thông báo', res.msg);
                } else {
                    Alert.alert('Thông báo', gui.INFO_userCreatedSuccessfully);
                    Actions.pop();
                    Actions.pop();
                    this.props.actions.registerSuccess(userDto);
                    this.doLogin(userDto);
                }
            });

        Analytics.logEvent('REGISTER FACEBOOK', {deviceID: userDto.deviceID, userInfo: userDto});
    }

    doLogin(dto){
        let userDto = {
            username: dto.username,
            password: dto.matKhau
        };

        const deviceDto = {
            ... this.props.global.deviceInfo
        };

        this.props.actions.login(userDto.username, userDto.password, deviceDto)
            .then((res) => {
                if (res.login ===true) {
                    if (this.props.onLoginSuccess) {
                        this.props.onLoginSuccess();
                    } else {
                        if(this.props.global.help.welcomeInitial && !this.props.global.help.initialLogin) {
                            Actions.Home({type: 'reset'});
                        }else {
                            Actions.pop();
                            Actions.pop();
                        }
                        if (this.props.doFinalAction){
                            this.props.doFinalAction();
                        }
                    }
                } else {
                    this.refs.toastTop && this.refs.toastTop.show('Mật khẩu đăng nhập không đúng!',DURATION.LENGTH_LONG);
                }
            })
            .catch((res) => {
                Alert.alert('Thông báo', res.toString());
            })
    }

    _onPressCreate() {
        Actions.UserLoginCollection({ owner: 'create' });
        this._onChangeInitial();
    }

    _onPressAccept() {
        Actions.UserLoginCollection({ owner: 'deny'});
        this._onChangeInitial();
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor : '#fff'
    },
    scrollView: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 48
    },
    viewTextLogin: {
        width: width,
        height: 61,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16,
        backgroundColor: '#fff'
    },
    textLogin: {
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontSize: 15,
        fontWeight: 'normal'
    },
    viewLogo: {
        width: width,
        height: 30,
        marginTop: 34,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        backgroundColor: '#fff'
    },
    logoIcon: {
        height: 46,
        width: 123
    },
    viewTextWelcome: {
        width: width,
        height: 32,
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 16,
        paddingRight: 16,
        marginTop: 117
    },
    textWelCome: {
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 20,
        fontWeight: 'normal',
        textAlign: 'center'
    },
    viewTwoButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 112,
        marginTop: 40
    },
    viewLoginFB: {
        width: width - 32,
        height: 48,
        backgroundColor: '#3B5998',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 24
    },
    textFbStart: {
        fontFamily: gui.fontFamily,
        color: '#fff',
        fontSize: 15,
        fontWeight: 'normal'
    },
    viewIconFb: {
        position: 'absolute',
        left: 24
    },
    viewCreateButton: {
        width: width - 32,
        height: 48,
        marginTop: 16,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 24,
        borderWidth: 2,
        borderColor: '#526173'
    },
    viewAccept: {
        height: 20,
        marginTop: 32,
        width: width,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewChinhSach: {
        width: width,
        height: 60,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        paddingRight: 16,
        marginTop: 93
    },
    resultContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
});


export default connect(mapStateToProps, mapDispatchToProps)(WelcomeLandber);