import React, {Component} from 'react';

import {
  TextInput, View, ListView, Image, Text, TouchableHighlight, TouchableWithoutFeedback
  , Platform, ActivityIndicator, ProgressBarAndroid, StyleSheet, Alert, ScrollView,
    Keyboard,
    TouchableOpacity
} from 'react-native';
const Qs = require('qs');

var gui = require("../../lib/gui");

import TruliaIcon from '../TruliaIcon';

import RelandIcon from '../RelandIcon';

import GiftedSpinner from 'react-native-gifted-spinner';

import apiUtils from '../../lib/ApiUtils';

import log from '../../lib/logUtil';
let { width, height } = utils.getDimensions();

import cfg from '../../cfg';

import utils from '../../lib/utils';

import FullLine from '../line/FullLine';

import dismissKeyboard from 'react-native-dismiss-keyboard';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import KeyboardSpacer from 'react-native-keyboard-spacer';

import Button from 'react-native-button';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SearchHeader from '../search/SearchHeaderFlip';

import PropTypes from 'prop-types';

var Analytics = require('react-native-firebase-analytics');

import * as groupSearchActions from '../../reducers/groupSearch/groupSearchActions'

import { Map } from 'immutable';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

const actions = [
    groupSearchActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}


const GooglePlacesAutocomplete = React.createClass({

  propTypes: {
    placeholder: PropTypes.string,
    onPress: PropTypes.func,
    minLength: PropTypes.number,
    fetchDetails: PropTypes.bool,
    autoFocus: PropTypes.bool,
    getDefaultValue: PropTypes.func,
    timeout: PropTypes.number,
    onTimeout: PropTypes.func,
    styles: PropTypes.object,
    textInputProps: PropTypes.object,
    enablePoweredByContainer: PropTypes.bool,
    predefinedPlaces: PropTypes.array,
    category: PropTypes.array,
    currentLocation: PropTypes.bool,
    currentLocationLabel: PropTypes.string,
    predefinedPlacesAlwaysVisible: PropTypes.bool,
  },

  getDefaultProps() {
    return {
      placeholder: 'Tìm kiếm',
      onPress: () => {
      },
      minLength: 0,
      fetchDetails: false,
      autoFocus: false,
      getDefaultValue: () => '',
      timeout: 20000,
      onTimeout: () => console.warn('Places autocomplete: request timeout'),
      styles: {},
      textInputProps: {},
      enablePoweredByContainer: true,
      predefinedPlaces: [],
      currentLocation: false,
      currentLocationLabel: gui.VI_TRI_HIEN_TAI,
      predefinedPlacesAlwaysVisible: false,
      category: ["DIA_CHINH"]
    };
  },

  getInitialState() {
    const ds = new ListView.DataSource({
      rowHasChanged: function rowHasChanged(r1, r2) {
        if (typeof r1.isLoading !== 'undefined') {
          return true;
        }
        return r1 !== r2;
      }
    });
    return {
      text: this.props.getDefaultValue(),
      focused: false,
      loading: false,
      dataSource: ds.cloneWithRows(this.buildRowsFromResults([])),
      listViewDisplayed: false,
      diaChinh: [],
      diaChinhGoogle: [],
      toggleKeyboard: false,
      mounted: false,
      lastPostAdsSearch: this.props.groupSearch.lastPostAdsSearch || []
    };
  },

    componentWillReceiveProps(nextProps) {

        if (nextProps.groupSearch.lastPostAdsSearch !== this.props.groupSearch.lastPostAdsSearch) {
            this.setState({
                lastPostAdsSearch: nextProps.groupSearch.lastPostAdsSearch || []
            })
        }
    },

    buildRowsFromResults(results) {
    var res = null;

    if ((!this.state || !this.state.text || this.state.text.length < this.props.minLength) &&
        (results.length === 0 || this.props.predefinedPlacesAlwaysVisible === true)) {
      res = this.props.predefinedPlaces.length > 0 ?
          [{
                  title: this.props.predefinedPlaces[0].placeType == 'A' ? "DỰ ÁN" : "ĐỊA CHÍNH",
                  desc: this.props.predefinedPlaces[0].placeType == 'A' ? "Tên các dự án tìm thấy" : "Thành phố, quận tìm thấy"
             }, ...this.props.predefinedPlaces] : [];
      if (this.props.currentLocation === true) {
        res.unshift({
          description: this.props.currentLocationLabel,
          shortName: this.props.currentLocationLabel,
          isCurrentLocation: true,
        });
      }
    } else {
      res = [];
    }

    res = res.map(function (place) {
      return {
        ...place,
        isPredefinedPlace: true,
      }
    });

    return [...res, ...results];
  },

  componentDidMount() {
    this.setState({mounted: true});
  },

  componentWillUnmount() {
    this._abortRequests();
    this.setState({mounted: false});

  },

  _abortRequests() {
    for (let i = 0; i < this._requests.length; i++) {
      this._requests[i].abort();
    }
    this._requests = [];
  },

  /**
   * This method is exposed to parent components to focus on textInput manually.
   * @public
   */
  triggerFocus() {
    if (this.refs.textInput) this.refs.textInput.focus();
  },

  /**
   * This method is exposed to parent components to blur textInput manually.
   * @public
   */
  triggerBlur() {
    if (this.refs.textInput) this.refs.textInput.blur();
  },

  getCurrentLocation() {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        
        this._abortRequests();

        //this._requestNearby(position.coords.latitude, position.coords.longitude);
        let data = {
          name: gui.VI_TRI_HIEN_TAI,
          fullName: gui.VI_TRI_HIEN_TAI,
          currentLocation: {
            "lat": position.coords.latitude,
            "lon": position.coords.longitude
          }
        };

        var region = {
          latitude: data.currentLocation.lat,
          longitude: data.currentLocation.lon,
          latitudeDelta: gui.LATITUDE_DELTA,
          longitudeDelta: gui.LONGITUDE_DELTA
        };

        data.viewport = apiUtils.getViewport(region);

        data.center = {lat: region.latitude, lon: region.longitude};

        dismissKeyboard();
        this.props.onPress(data, null);
        Analytics.logEvent('SEARCH_SUGGESTION', {fullName: data.fullName});
      },
      (error) => {
        this._disableRowLoaders();
        // Alert.alert("Thông báo", "Bạn vui lòng bật dịch vụ định vị!");
      },
      {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
    );
  },

  _enableRowLoader(rowData) {

    let rows = this.buildRowsFromResults(this._results);
    for (let i = 0; i < rows.length; i++) {
      if ((rows[i].place_id === rowData.place_id) || (rows[i].isCurrentLocation === true && rowData.isCurrentLocation === true)) {
        rows[i].isLoading = true;
        this.setState({
          dataSource: this.state.dataSource.cloneWithRows(rows),
        });
        break;
      }
    }
  },
  _disableRowLoaders() {
    if (this.state.mounted) {
      for (let i = 0; i < this._results.length; i++) {
        if (this._results[i].isLoading === true) {
          this._results[i].isLoading = false;
        }
      }
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(this._results)),
      });
    }
  },

  _onPress(rowData) {
    if (rowData.title && rowData.title.length>0)
        return;

    if (rowData.isPredefinedPlace !== true && this.props.fetchDetails === true) {
      if (rowData.isLoading === true) {
        // already requesting
        return;
      }

      this._abortRequests();

      this.setState({
        text: rowData.fullName
        // text: rowData.shortName
      });

      delete rowData.isLoading;

      dismissKeyboard();
      this.props.onPress(rowData);
      Analytics.logEvent('SEARCH_SUGGESTION', {fullName: rowData.fullName});

    } else if (rowData.isCurrentLocation === true) {
      // display loader
      this._enableRowLoader(rowData);

      this.setState({
        text: rowData.fullName,
      });
      this.triggerBlur(); // hide keyboard but not the results

      delete rowData.isLoading;

      this.getCurrentLocation();

    } else {
      this.setState({
        text: rowData.fullName,
      });

      this._onBlur();

      delete rowData.isLoading;

      let predefinedPlace = this._getPredefinedPlace(rowData);

      dismissKeyboard();
      // sending predefinedPlace as details for predefined places
      this.props.onPress(predefinedPlace);
      this.onPressRowData(rowData);
      Analytics.logEvent('SEARCH_SUGGESTION', {fullName: rowData.fullName});
    }
  },
  _results: [],
  _requests: [],

  _getPredefinedPlace(rowData) {
    if (rowData.isPredefinedPlace !== true) {
      return rowData;
    }
    let description = rowData.description || rowData.name;
    for (let i = 0; i < this.props.predefinedPlaces.length; i++) {
      if (this.props.predefinedPlaces[i].description === description) {
        return this.props.predefinedPlaces[i];
      }
    }
    return rowData;
  },

    onPressRowData(rowData) {
        //console.log('============> _onPress predefinedPlace', rowData);
        let lastPostAdsSearch = this.props.groupSearch.lastPostAdsSearch || [];
        if (this.state.text.length > 0 && lastPostAdsSearch.indexOf(this.state.text)==-1) {

            if (lastPostAdsSearch.length>=8)
                lastPostAdsSearch = lastPostAdsSearch.slice(1, lastPostAdsSearch.length)
            let lastLocal = rowData.fullName ? rowData.fullName : this.state.text;
            lastPostAdsSearch.unshift(lastLocal);

            this.props.actions.updateLastPostAdsSearch(lastPostAdsSearch);
            this.setState({ 'lastPostAdsSearch': lastPostAdsSearch })
        }
    },


    _filterResultsByTypes(responseJSON, types) {
    if (types.length === 0) return responseJSON.results;

    var results = [];
    for (let i = 0; i < responseJSON.results.length; i++) {
      let found = false;
      for (let j = 0; j < types.length; j++) {
        if (responseJSON.results[i].types.indexOf(types[j]) !== -1) {
          found = true;
          break;
        }
      }
      if (found === true) {
        results.push(responseJSON.results[i]);
      }
    }
    return results;
  },


  _requestDiaChinhGoogle(text) {
    const request = new XMLHttpRequest();
    this._requests.push(request);
    request.timeout = this.props.timeout;
    request.ontimeout = this.props.onTimeout;
    request.onreadystatechange = () => {
      if (request.readyState !== 4) {
        return;
      }
      if (request.status === 200) {
        this.setState({loading: false, dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([]))});
        const responseJSON = JSON.parse(request.responseText);
        if (typeof responseJSON.predictions !== 'undefined') {
          if (this.state.mounted) {
            this._results = responseJSON.predictions;
            let predictions = responseJSON.predictions;

            let diaDiem = predictions && predictions.filter((e) => {
                  return e.placeType == 'V';
                });

            let data = [];
            if (diaDiem && diaDiem.length > 0 && this.props.category.indexOf("DIA_DIEM") >= 0) {

              data = [...data, {title: "ĐỊA ĐIỂM", desc: "Tên địa điểm tìm thấy"}, ...diaDiem]
            }

            this.setState({
              //dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(responseJSON.predictions)),
              dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([...this.state.diaChinh, ...data])),
              diaChinhGoogle: data
            });
          }
        }
        if (typeof responseJSON.error_message !== 'undefined') {
          log.warn('GooglePlacesAutocomplete._requestDiaChinhGoogle: ' + responseJSON.error_message);
        }
      } else {
        // console.warn("google places autocomplete: request could not be completed or has been aborted");
      }
    };
    /*
     request.open('GET', 'https://maps.googleapis.com/maps/api/place/autocomplete/json?&input='
     + encodeURI(text) + '&' + Qs.stringify(this.props.query));
     request.send();
     */
    this.setState({loading: true});
    request.open('GET', cfg.rootUrl + "/place/autocompleteGoogle?input=" + encodeURI(text));
    request.send();
  },

  _requestDiaChinh(text) {
    const request = new XMLHttpRequest();
    this._requests.push(request);
    request.timeout = this.props.timeout;
    request.ontimeout = this.props.onTimeout;
    request.onreadystatechange = () => {
      if (request.readyState !== 4) {
        return;
      }
      if (request.status === 200) {
        this.setState({loading: false, dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([]))});
        const responseJSON = JSON.parse(request.responseText);
        if (typeof responseJSON.predictions !== 'undefined') {
          if (this.state.mounted) {
            this._results = responseJSON.predictions;
            let predictions = responseJSON.predictions;

            let diaChinh = predictions && predictions.filter((e) => {
                  return e.placeType == 'T' || e.placeType == 'H';
                });

            let duAn = predictions && predictions.filter((e) => {
                  return e.placeType == 'A';
                });

            let duong = predictions && predictions.filter((e) => {
                  return e.placeType == 'D';
                });

            let diaDiem = predictions && predictions.filter((e) => {
                  return e.placeType == 'V';
                });

            let data = [];
            if (diaChinh && diaChinh.length > 0 && this.props.category.indexOf("DIA_CHINH") >= 0) {
              data = [...data, {
                title: "ĐỊA CHÍNH",
                desc: "Thành phố, quận tìm thấy"
              }, ...diaChinh]
            }

            if (duAn && duAn.length > 0 && this.props.category.indexOf("DU_AN") >= 0) {
              data = [...data, {title: "DỰ ÁN", desc: "Tên các dự án tìm thấy"}, ...duAn]
            }

            if (duong && duong.length > 0 && this.props.category.indexOf("DUONG") >= 0) {
              data = [...data, {title: "ĐƯỜNG", desc: "Tên đường tìm thấy"}, ...duong]
            }

            this.setState({
              //dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(responseJSON.predictions)),
              dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([...data, ...this.state.diaChinhGoogle])),
              diaChinh: data
            });
          }
        }
        if (typeof responseJSON.error_message !== 'undefined') {
          log.warn('GooglePlacesAutocomplete._requestDiaChinh: ' + responseJSON.error_message);
        }
      } else {
        // console.warn("google places autocomplete: request could not be completed or has been aborted");
      }
    };
    /*
     request.open('GET', 'https://maps.googleapis.com/maps/api/place/autocomplete/json?&input='
     + encodeURI(text) + '&' + Qs.stringify(this.props.query));
     request.send();
     */
    this.setState({loading: true});
    request.open('GET', cfg.rootUrl + "/place/autocomplete?input=" + encodeURI(text));
    request.send();
  },
  _onClientSearch: function (text) {
      this.setState({loading: false});
      let textKhongDau = utils.locDauV2(text);
      let allToken = textKhongDau.split(' ');
      let diaChinh = [];
      let allTinh = this.props.predefinedPlaces;
      allTinh.forEach((tinh) => {
          let tinhTokens = tinh.tinhKhongDau.split('-');
          let matched = undefined;
          let matchedHash = {};
          allToken.forEach((token) => {
              let found = tinhTokens.find((tinhToken) => {
                  return tinhToken == token;
              });
              if (found) {
                  matchedHash[token] = true;
                  if (matched === undefined) {
                      matched = true;
                  }
              }
              else {
                  matched = false;
              }
          });
          if (matched) {
              diaChinh.push(tinh);
          } else if (Object.keys(matchedHash).length == (allToken.length - 1) && !matchedHash[allToken[allToken.length - 1]]) {
              let item = allToken[allToken.length - 1];
              let found = tinhTokens.length >= allToken.length && tinhTokens[allToken.length - 1].indexOf(item) == 0;
              if (found) {
                  diaChinh.push(tinh);
              }
          }
      });
      if (diaChinh.length > 0) {
          diaChinh = [{
              title: "ĐỊA CHÍNH",
              desc: "Thành phố, quận tìm thấy"
          }, ...diaChinh];
      }
      this.setState({
          dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(diaChinh)),
          diaChinh: diaChinh
      });
  },
  _request(text) {
    this._abortRequests();
    if (text.length >= this.props.minLength) {
      if (this.props.clientSearch) {
          this._onClientSearch(text);
      } else {
          this._requestDiaChinh(text);
          this._requestDiaChinhGoogle(text);
      }
    } else {
      this._results = [];
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults([])),
      });
    }
  },
  _onChangeText(text) {
    this.currentText = text;

    let pre = text;
    setTimeout(() => {
      if (pre == this.currentText) {
        this._request(pre);
      }
    }, 100);

    this.setState({
      text: text,
      listViewDisplayed: true,
    });
  },

  _getRowLoader() {
    if (Platform.OS === 'android') {
      return (
        <ProgressBarAndroid
          style={[defaultStyles.androidLoader, this.props.styles.androidLoader]}
          styleAttr="Inverse"
        />
      );
    }
    /*return (
      <ActivityIndicator
        animating={true}
        size="small"
      />
    );*/
    return null;
  },

  _renderLoader(rowData) {
    if (rowData.isLoading === true) {
      return (
        <View
          style={[defaultStyles.loader, this.props.styles.loader]}
        >
          {this._getRowLoader()}
        </View>
      );
    }
    return null;
  },

  _getRowHight(place) {
    if (place.isSaveSearch || place.isRecent) {
      return 50;
    }

    return 44;
  },

  _renderRowIcon(rowData) {
    let source ;
    if (rowData.isSaveSearch) {
      source = require('../../assets/image/search/savedSearch.png');
      return (
          <Image
              style={styles.avatarIcon}
              resizeMode={Image.resizeMode.contain}
              source={source}
          />
      );
    } else if (rowData.isRecent) {
      return (
          <RelandIcon name="recent" color='#4B5157' mainProps={{flexDirection: 'row'}}
                      size={26} textProps={{paddingLeft: 0}}
                      noAction={true} />
      );
    } else if (rowData.isCurrentLocation) {
      return (
          <RelandIcon name="direction" color={gui.mainColor} mainProps={{flexDirection: 'row'}}
                  size={22} textProps={{paddingLeft: 0}}
                  noAction={true} />
      );
    } else if (rowData.title == "ĐỊA CHÍNH" && rowData.title.length>0) {
        return (
            <RelandIcon name="suggest-map" color={gui.mainColor} mainProps={{flexDirection: 'row'}}
                        size={26} textProps={{paddingLeft: 0}}
                        noAction={true} />
        )
      } else if (rowData.title == "DỰ ÁN" && rowData.title.length>0) {

        return (
            <RelandIcon name="suggest-project" color={gui.mainColor} mainProps={{flexDirection: 'row'}}
                        size={26} textProps={{paddingLeft: 0}}
                        noAction={true} />
        )
    } else if (rowData.title == "ĐƯỜNG" && rowData.title.length>0) {
        return (
            <RelandIcon name="suggest-street" color={gui.mainColor} mainProps={{flexDirection: 'row'}}
                        size={26} textProps={{paddingLeft: 0}}
                        noAction={true} />
        )
    } else if (rowData.title == "ĐỊA ĐIỂM" && rowData.title.length>0) {
      return (
          <RelandIcon name="suggest-location" color={gui.mainColor} mainProps={{flexDirection: 'row'}}
                      size={26} textProps={{paddingLeft: 0}}
                      noAction={true} />
      )
    }

    return null;
  },

  _renderRowText(rowData) {
    if (rowData.isSaveSearch || rowData.isRecent) {
      return (
        <View style={styles.textView}>
          <Text
            style={styles.textLine1}
            numberOfLines={1}
          >
            {rowData.name}
          </Text>

          <Text
            style={styles.textLine2}
            numberOfLines={1}
          >
            {rowData.desc}
          </Text>
        </View>
      );
    }

    if (rowData.title && rowData.title.length>0){
      return (
          <View style={{flexDirection: 'column'}}>
            <Text style={[styles.textLine3,]}>
              {rowData.title}
            </Text>
            <Text style={[styles.textLine3, {fontSize: 12, color: '#6e6e70'}]}>
            {rowData.desc}
            </Text>
          </View>
      );
    }

    return (
      <Text
        style={[{flex: 1}, defaultStyles.description
                , this.props.styles.description
                //, rowData.isPredefinedPlace ? this.props.styles.predefinedPlacesDescription : {}
                ]}

        numberOfLines={1}
      >
        {rowData.shortName}
      </Text>
    );
  },

  _renderRow(rowData = {}, sectionID, rowID, isFirstRow) {
    // rowData.description = rowData.description || rowData.name;
    let rowHeight = this._getRowHight(rowData);
    var separatorStypeExt = isFirstRow ? {marginLeft: 0} : (!this.state.text || this.state.text.length < this.props.minLength ? {marginLeft: 47} : {marginLeft: 25});

    return (
      <TouchableHighlight
        onPress={() =>
          this._onPress(rowData)
        }
        underlayColor="#c8c7cc"
      >
        <View>
          <View style={[defaultStyles.separator, this.props.styles.separator, separatorStypeExt]} />
          <View style={[defaultStyles.row, {height: rowHeight}]}>
            <View style={{
              flex:1,
              flexDirection:'row',
              alignItems:'center',
              paddingTop: 5,
              marginBottom: 5,
              marginLeft: 15,
              marginRight: 15}}>

              {this._renderRowIcon(rowData)}

              {this._renderRowText(rowData)}
            </View>

            {this._renderLoader(rowData)}
          </View>
          <FullLine style={{ marginLeft: 15 }} />
        </View>
      </TouchableHighlight>
    );
  },

  _renderSeparator(sectionID, rowID, isLastRow) {
    if (isLastRow) {
      return (
          <View key={`${sectionID}-${rowID}`}
                style={[defaultStyles.separator, this.props.styles.separator]}/>
      );
    } else {
      return null;
    }
  },

  _onBlur() {
    this.triggerBlur();
    this.setState({listViewDisplayed: false});
  },

  _onFocus() {
    this.setState({listViewDisplayed: true, focused: true});
  },

  _getListView() {
      let lastPostAdsSearchFilter = this.props.groupSearch.lastPostAdsSearch || [];

      if (!this.state.text || this.state.text.length == 0) {
          return (
              <ScrollView
                  keyboardShouldPersistTaps="always"
                  keyboardDismissMode="on-drag"
                  style={styles.viewLastSearch}
              >
                  {
                      lastPostAdsSearchFilter && lastPostAdsSearchFilter.length > 0 ?
                          (lastPostAdsSearchFilter.map((e, index) => {
                              return (
                                  <TouchableOpacity
                                      onPress={this.onLastPostAdsPress.bind(this, e)}
                                      key={index}
                                  >
                                    <View style={styles.viewRowLastSearch}>
                                      <View style={styles.viewIconLast}>
                                        <Ionicons name="ios-search" size={20} color={gui.mainTextColor} />
                                      </View>
                                      <View style={styles.lastSearchContent}>
                                        <Text style={[styles.textViewAll, { fontWeight: '500' }]}>{e}</Text>
                                      </View>
                                    </View>
                                    <FullLine style={{ marginLeft: 16 }} />
                                  </TouchableOpacity>
                              )
                          })) : null
                  }
              </ScrollView>
          );
      }

    if ((this.state.text !== '' || this.props.predefinedPlaces.length || this.props.currentLocation === true) && this.state.listViewDisplayed === true) {
      return (
        <ListView
          keyboardShouldPersistTaps="always"
          keyboardDismissMode="none"
          enableEmptySections={true}
          style={[defaultStyles.listView, this.props.styles.listView]}
          dataSource={this.state.dataSource}
          renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0))}
          renderSeparator={(sectionID, rowID) => this._renderSeparator(sectionID, rowID, (rowID == (this.state.dataSource._dataBlob.s1.length-1)))}
          automaticallyAdjustContentInsets={false}

          {...this.props}
        />
      );
    }

    if (this.props.enablePoweredByContainer) {
      return (
        <View
          style={[defaultStyles.poweredContainer, this.props.styles.poweredContainer]}
        >
          <Image
            style={[defaultStyles.powered, this.props.styles.powered]}
            resizeMode={Image.resizeMode.contain}
            source={require('../../assets/image/powered_by_google_on_white.png')}
          />
        </View>
      );
    }

    return (<ScrollView />);
  },

    onLastPostAdsPress(value) {
        this.setState( {text: value});
        this._request(value)
    },

  _renderSearchButton() {
    if (this.state.loading){
      return (
          <View style={{paddingRight: 7, paddingTop: 1, backgroundColor: 'transparent', width: 22, alignItems: 'center'}}>
            <GiftedSpinner size="small" color="#fff" />
          </View>
      )
    } else {
      return (
          <View style={{backgroundColor: 'transparent', width: 22, alignItems: 'center'}}>
            <TruliaIcon name="search" size={14} color={'#fff'}
                        mainProps={{paddingRight: 7, paddingTop: 3}}></TruliaIcon>
          </View>
      )
    }

  },
  render() {
    let {onChangeText, onFocus, ...userProps} = this.props.textInputProps;
    return (
      <View
        style={[defaultStyles.container, this.props.styles.container]}
      >
        {/*<View
          style={[defaultStyles.textInputContainer, this.props.styles.textInputContainer]}
        >
          <View style={defaultStyles.inputView}>
            {this._renderSearchButton()}
            <TextInput
              { ...userProps }
              ref="textInput"
              autoFocus={this.props.autoFocus}
              style={[defaultStyles.textInput, this.props.styles.textInput]}
              onChangeText={onChangeText ? text => {this._onChangeText(text); onChangeText(text)} : this._onChangeText}
              value={this.state.text}
              placeholder={this.props.placeholder}
              placeholderTextColor={"#fff"}
              selectionColor={'#fff'}
              onFocus={onFocus ? () => {this._onFocus(); onFocus()} : this._onFocus}
              clearButtonMode="never"
            />
            {this.state.focused && this.state.text != '' ?
            <RelandIcon name="close-circle-f" size={18} color={'#fff'}
                        mainProps={{flexDirection: 'row', paddingTop: 1, paddingLeft: 5, paddingRight: 5}}
                        textProps={{paddingLeft: 0}}
                        onPress={() => {this._onChangeText(''); onChangeText && onChangeText('')}}></RelandIcon> : null
            }
          </View>

          <TouchableHighlight underlayColor="transparent" onPress={() => {dismissKeyboard();this.props.onCancelPress()}}>
            <Text style={defaultStyles.cancelText}>
              Hủy
            </Text>
          </TouchableHighlight>

        </View>*/}
        <View
            style={[defaultStyles.textInputContainer2, this.props.styles.textInputContainer]}
        >
          <SearchHeader activeView={'GooglePlacesAutocomplete'}
                        ref="searchHeader"
                        autoFocus={true}
                        onChangeText={onChangeText ? text => {this._onChangeText(text); onChangeText(text)} : this._onChangeText}
                        textValue={this.state.text}
                        placeholder={this.props.placeholder}
                        onFocus={onFocus ? () => {this._onFocus(); onFocus()} : this._onFocus}
                        onCancelPress={() => {dismissKeyboard();this.props.onCancelPress()}}
                        isHeaderLoading={() => {return this.state.loading}}
                        showCloseButton={this.state.focused && this.state.text != ''}
          />
        </View>
        <View style={[defaultStyles.separator, this.props.styles.separator]}/>
        <FullLine />
        {this._getListView()}
        {this.state.toggleKeyboard ? <Button onPress={() => {
                                              dismissKeyboard()
                                                let lastPostAdsSearch = this.props.groupSearch.lastPostAdsSearch || [];
                                                if (this.state.text.length > 0 && lastPostAdsSearch.indexOf(this.state.text)==-1) {

                                                    if (lastPostAdsSearch.length>=10)
                                                        lastPostAdsSearch = lastPostAdsSearch.slice(1, lastPostAdsSearch.length)
                                                    let lastLocal = this.state.text;
                                                    lastPostAdsSearch.unshift(lastLocal);

                                                    this.props.actions.updateLastPostAdsSearch(lastPostAdsSearch);
                                                    this.setState({ 'lastPostAdsSearch': lastPostAdsSearch }) }
                                                 }}
                                          style={{ paddingRight: 17, fontFamily: gui.fontFamily, fontWeight : 'normal', textAlign: 'right',
                                                    color: gui.mainColor, backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }}>Xong</Button> : null}

        <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)}/>

      </View>
    );
  },
  focusInputSearch() {
    this.refs.searchHeader.focusInputSearch();
  },
  onKeyboardToggle(toggleKeyboard) {
    this.setState({ toggleKeyboard: toggleKeyboard });
  }
});


var styles = StyleSheet.create({
  avatarIcon : {
    height: 22,
    width: 22,
    backgroundColor: 'transparent'
  },
  textLine1: {
    //fontWeight: 'bold',
    fontFamily : gui.fontFamily,
    fontSize: 15,
    color: '#323538'
  },
  textLine3: {
      fontFamily : gui.fontFamily,
      fontSize: 15,
      color: '#000',
      marginLeft: 10
  },
  textLine2: {
    //fontWeight: 'bold',
    fontFamily : gui.fontFamily,
    fontSize: 12,
    color: '#79858a',
    marginTop: 3
  },
  textView : {
    marginLeft:10,
    marginRight: 10,
    flex: 1
  },
    viewLastSearch: {
        flex: 1,
        backgroundColor: '#fff'
    },
    viewRowLastSearch: {
        height: 36,
        width: width,
        flexDirection: 'row'
    },
    viewIconLast: {
        width: 48,
        height: 36,
        paddingLeft: 16,
        justifyContent: 'center',
        alignItems: 'center'
    },
    lastSearchContent: {
        width: width - 48,
        height: 36,
        justifyContent: 'center',
        paddingLeft: 8
    },
    textViewAll: {
        fontFamily: gui.fontFamily,
        color: gui.mainTextColor,
        fontWeight: 'normal',
        fontSize: 15
    },
});

const defaultStyles = {
  container: {
    flex: 1,
  },
  textInputContainer: {
    paddingTop: 20,
    backgroundColor: gui.mainColor,
    height: 65,
    flexDirection: 'row',
    alignItems: 'center'
  },
  textInputContainer2: {
    backgroundColor: '#fff',
    height: 65,
  },
  inputView: {
    backgroundColor: '#166CA5',
    height: 28,
    borderRadius: 5,
    paddingTop: 4.5,
    paddingBottom: 4.5,
    paddingLeft: 10,
    paddingRight: 10,
    marginLeft: 15,
    marginRight: 8,
    flex: 1,
    flexDirection: 'row'
  },
  textInput: {
    backgroundColor: '#166CA5',
    color: '#fff',
    fontSize: 15,
    flex: 1
  },
  cancelText: {
    fontSize: 17,
    color: '#ffffff',
    paddingRight: 15,
    paddingTop: 4.5,
    paddingBottom: 4.5,
    height: 28
  },
  poweredContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  powered: {
    marginTop: 15,
  },
  listView: {
    // flex: 1,
  },
  row: {
    height: 44,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  separator: {
    height: 0,
    backgroundColor: '#E9E9E9',
  },
  description: {},
  loader: {
    // flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    height: 20,
  },
  androidLoader: {
    marginRight: -15,
  },
};

export default connect(mapStateToProps, mapDispatchToProps)(GooglePlacesAutocomplete);