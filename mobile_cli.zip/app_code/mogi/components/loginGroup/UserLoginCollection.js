import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    Alert,
    StatusBar
} from 'react-native';

import {Actions} from 'react-native-router-flux';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import UserTapCollection from './UserTapCollection';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
let {width, height} = utils.getDimensions();
import TagLogin from './TagLogin';
import findApi from '../../lib/FindApi';
import DanhMuc from '../../assets/DanhMuc';
import log from '../../lib/logUtil';

import localStorage  from '../../lib/localStorage';

import moment from 'moment';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';

const actions = [
    globalActions,
    searchActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class UserLoginCollection extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            userRequire: ['banNha'],
            diaBans: []
        }
    }

    componentWillMount() {
        StatusBar.setBarStyle('default');
    }

    render() {
        return(
            <View style={styles.container}>
                <ScrollView contentContainerStyle={styles.scrollView}
                            style={{flex: 1}}
                            automaticallyAdjustContentInsets={false}
                            vertical={true}>
                        <View style={styles.viewTopNewLogin}>
                            <TouchableOpacity style={styles.viewBackButton}
                                              onPress={this._onPressBack.bind(this)}
                            >
                                <TruliaIcon name="arrow-left"
                                            size={22}
                                            color={gui.mainColor}
                                            mainProps={{marginLeft: 0}}
                                            noAction={true} />
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.viewSignUpText}
                                              onPress={this._onPressDeny.bind(this)}>
                                    <Text style={styles.textDeny}>Bỏ qua</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={styles.viewNeedOption}>
                            <Text style={styles.textNeedOption}>Bạn đang hoạt động</Text>
                        </View>
                        {/*<View style={styles.viewButtonTop}>
                            <UserTapCollection name={'banNha'}
                                            onPress={this._onTypeUserRequire.bind(this)}
                                            selected={!!this.state.userRequire.find((e) => { return e == 'banNha' })}
                                            mainProps={{marginLeft: 0}}>Bán nhà</UserTapCollection>
                            <UserTapCollection name={'choThueNha'}
                                            onPress={this._onTypeUserRequire.bind(this)}
                                            selected={!!this.state.userRequire.find((e) => { return e == 'choThueNha' })}
                                            mainProps={{marginLeft: 0}}
                                            stylesButton={{marginLeft: 8}}>Cho thuê nhà</UserTapCollection>
                        </View>
                        <View style={[styles.viewButtonTop, {marginTop: 8}]}>
                            <UserTapCollection name={'muaNha'}
                                               onPress={this._onTypeUserRequire.bind(this)}
                                               selected={!!this.state.userRequire.find((e) => { return e == 'muaNha' })}
                                               mainProps={{marginLeft: 0}}>Mua nhà</UserTapCollection>
                            <UserTapCollection name={'thueNha'}
                                               onPress={this._onTypeUserRequire.bind(this)}
                                               selected={!!this.state.userRequire.find((e) => { return e == 'thueNha' })}
                                               mainProps={{marginLeft: 0}}
                                               stylesButton={{marginLeft: 8}}>Thuê nhà</UserTapCollection>
                        </View>*/}

                        <View style={[styles.viewKhuVuc, {marginTop: 10}]}>
                            <Text style={[styles.textNeedOption, {fontSize: 20}]}>tại khu vực</Text>
                        </View>
                        <TouchableOpacity style={styles.viewTypeCountry}
                                          onPress={this._onPressCityColection.bind(this)}
                        >
                            <Text style={[styles.textDeny, {color: gui.colorMainBlur}]}>Nhập tên thành phố, quận</Text>
                        </TouchableOpacity>
                        <View style={styles.lineDangNhap}/>
                        {this._renderKhuVuc()}
                </ScrollView>
                {this._renderButtonDone()}
            </View>
        );
    }

    _onPressCityColection() {
        let diaChinhDto = {
            placeType: DanhMuc.placeType.TINH
        };
        findApi.getDiaChinhByCondition(diaChinhDto).then(
            (e) => {
                let allTinh = [];
                if (e && e.status === 0 && e.predictions){
                    allTinh = e.predictions.slice(0);
                    allTinh.forEach((one) => {
                        one.description = one.fullName;
                        one.shortName = one.fullName;
                    });
                }
                this._onLoadNewLoginAutoComplete(allTinh);
            }
        );
    }

    _onLoadNewLoginAutoComplete(allTinh) {
        Actions.NewLoginAutoComplete(
            {
                onSuggestionBuyPressed: (location)=>this._collectSuggestionInfo(location),
                allTinh: allTinh,
                category: ["DIA_CHINH"],
                placeHolder: 'Nhập tên thành phố, quận'
            });
    }

    _collectSuggestionInfo(position) {
        if (position.placeType == DanhMuc.placeType.DIA_DIEM) {
            this._getPlaceByLocation(position.location.lat, position.location.lon, (res) => {
                if (res) {
                    let diaChinh = {
                        codeDuAn: undefined,
                        codeDuong: undefined,
                        codeXa: res.codeXa || undefined,
                        codeHuyen: res.codeHuyen || undefined,
                        codeTinh: res.codeTinh || undefined,
                        duAn: undefined,
                        duong: undefined,
                        xa: res.xa || position.xaName || undefined,
                        huyen: res.huyen || position.huyenName || undefined,
                        tinh: res.tinh || position.tinhName || undefined,
                        viewport: res.viewport || undefined
                    };
                    this._updateDiaChinhCity(diaChinh);
                }
            });
        } else {
            let diaChinh = {};
            if (position.codeTinh) {
                diaChinh = {
                    codeTinh: position.codeTinh || undefined,
                    tinh: position.tinh || undefined,
                    type: position.placeType,
                    viewport: position.viewport || undefined,
                    placeName: position.placeName
                };
            } else {
                diaChinh = {
                    codeDuAn: position.duAn || undefined,
                    codeDuong: position.duong || undefined,
                    codeXa: position.xa || undefined,
                    codeHuyen: position.huyen || undefined,
                    codeTinh: position.tinh || undefined,
                    duAn: position.duAnName || undefined,
                    duong: position.duongName || undefined,
                    xa: position.xaName || undefined,
                    huyen: position.huyenName || undefined,
                    tinh: position.tinhName || undefined,
                    type: position.placeType,
                    viewport: position.viewport || undefined,
                    placeName: position.placeName
                };
            }
            this._updateDiaChinhCity(diaChinh);
        }
    }

    _updateDiaChinhCity(diaChinh) {
        if (!this.containsDiaChinh(diaChinh, this.state.diaBans)) {
            this.setState({ diaBans: [...this.state.diaBans, diaChinh] });
        }
    }

    containsDiaChinh(obj, list) {
        for (var i = 0; i < list.length; i++) {
            if (obj.type == DanhMuc.placeType.TINH && list[i].type === obj.type && list[i].codeTinh === obj.codeTinh) {
                return true;
            }
            if (obj.type == DanhMuc.placeType.HUYEN && list[i].type === obj.type && list[i].codeHuyen === obj.codeHuyen) {
                return true;
            }
        }
        return false;
    }

    _getPlaceByLocation(lat, lon, callback) {
        findApi.getPlaceByLocation(lat, lon).then((res) => {
            if (res.success) {
                callback(res.result);
            }
        });
    }

    _renderKhuVuc() {
        let tags = this.state.diaBans.map((tag, index) => (
            <TagLogin
                type="DiaChinh"
                index={index}
                label={tag.placeName}
                isLastTag={this.state.diaBans.length === index + 1}
                onLayoutLastTag={this.onLayoutLastTag}
                removeIndex={this.removeDiaBan.bind(this)}
                tagColor={gui.mainColor}
                tagTextColor='#fff'
                key={index}
            />
        ));

        return (
            <View style={styles.blockView2}>
                <View style={styles.tagInputContainer}>{tags}</View>
            </View>
        )
    }


    onLayoutLastTag = (endPosOfTag: number) => {
        const margin = 3;
        this.spaceLeft = this.wrapperWidth - endPosOfTag - margin - 10;
        const inputWidth = UserLoginCollection.inputWidth(
            this.state.text,
            this.spaceLeft,
            this.wrapperWidth,
        );
        if (inputWidth !== this.state.inputWidth) {
            this.setState({ inputWidth });
        }
    }

    static inputWidth(text: string, spaceLeft: number, wrapperWidth: number) {
        if (text === "") {
            return 90;
        } else if (spaceLeft >= 100) {
            return spaceLeft - 10;
        } else {
            return wrapperWidth;
        }
    }

    removeDiaBan = (index: number) => {
        const tags = [...this.state.diaBans];
        tags.splice(index, 1);
        this.setState({ diaBans: tags });
    }

    removeDiaBan = (index) => {
        const tags = [...this.state.diaBans];
        tags.splice(index, 1);
        this.setState({ diaBans: tags });
    }

    _onTypeUserRequire(value) {
        let userRequire = this.state.userRequire;
        if (userRequire.find((e) => { return e == value })) {
            userRequire = userRequire.filter((e) => { return e != value });
        } else {
            userRequire = [...userRequire, value];
        }
        this.setState({
            userRequire: userRequire
        });
    }

    _renderButtonDone() {
        return(
            <View style={styles.viewTwoButton}>
                <TouchableOpacity style={styles.viewCreateButton}
                                  onPress={this._onPressDone.bind(this)}
                >
                    <Text style={[styles.textDeny, {color: '#fff'}]}>HOÀN TẤT</Text>
                </TouchableOpacity>
            </View>
        );
    }

    _onPressBack() {
        Actions.pop();
    }

    _onPressDone() {
        let khuVuc = [];
        this.state.diaBans.forEach((one) => {
            one.name = one.placeName;
            khuVuc.push(one);
        });
        this.props.actions.onSearchGroupFieldChange('khuVuc', khuVuc);
        let diaChinh = this.state.diaBans.length > 0 && this.state.diaBans[0];
        if (diaChinh) {
            let searchName = diaChinh.placeName;
            let loaiTin = this.state.userRequire.find((e) => { return e == 'banNha' || e == 'muaNha' }) ? 0 : 1;
            let viewport = diaChinh.viewport;
            let newDiaChinh = {
                tinhKhongDau: diaChinh.codeTinh,
                huyenKhongDau: diaChinh.codeHuyen,
                fullName: diaChinh.placeName
            };
            let query = {
                loaiTin: loaiTin,
                diaChinh: newDiaChinh,
                viewport: viewport
            };
            let searchObj = {
                key: searchName + '  ' + moment().format("DD-MM-YYYY HH:mm:ss"),
                name: searchName,
                timeModified: new Date().getTime(),
                query: query,
                isRecent: true,
                desc: findApi.convertQuery2String(query)
            };
            localStorage.setLastSearch(JSON.stringify(searchObj));

            this.props.actions.setSearchLoaiTin(loaiTin == 0 ? 'ban' : 'thue');
            this.props.actions.onSearchFieldChange("viewport", viewport);
            this.props.actions.onSearchFieldChange("diaChinh", newDiaChinh);
        }

        let deviceID = this.props.global.deviceInfo.deviceID || undefined;
        let userID = this.props.global.currentUser.userID || undefined;
        this.props.actions.loadAgentHomeData(
            () => { this._loadAllCalendarEvent(userID) },
            (error) => {
                this._loadAllCalendarEvent(userID);
                Alert.alert('Thông báo',
                    error,
                    [{
                        text: 'Đóng',
                        onPress: () => {}
                    }]);
            }, {deviceID: deviceID, userID: userID});

        if(this.props.owner == 'create') {
            Actions.CreateAccount();
        }
        if(this.props.owner == 'deny') {
            Actions.Home({type: 'reset'});
        }
    }

    _loadAllCalendarEvent(userID) {
        if (!userID) {
            return;
        }
        this.props.actions.getAllCalendarEvent(
            { 'userID': userID }
            , (res) => {
                //console.log('server respond data: =====>>>>> ', res);
            }
            , (error) => {
                console.log('server respond data: =====>>>>> ', error);
            }
        );
    }

    _onPressDeny() {
        if(this.props.owner == 'create') {
            Actions.CreateAccount();
        }
        if(this.props.owner == 'deny') {
            Actions.Home({type: 'reset'});
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        flex: 1
    },
    textDeny: {
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        color: gui.mainAgentColor,
        fontSize: 15
    },
    viewNeedOption: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 43
    },
    textNeedOption: {
        fontSize: 24,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: '500'
    },
    viewButtonTop: {
        width: width,
        height: 32,
        paddingLeft: 16,
        marginTop: 12,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        flexDirection: 'row'
    },
    viewKhuVuc: {
        width: width,
        height: 32,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 42
    },
    viewTypeCountry: {
        width: width,
        height: 20,
        paddingLeft: 16,
        marginTop: 17,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width - 32,
        opacity: 0.8,
        marginLeft: 16,
        marginRight: 16
    },
    viewTwoButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 48,
        position: 'absolute',
        top: height - 64
    },
    viewCreateButton: {
        width: width - 32,
        height: 48,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 24
    },
    blockView2: {
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        marginTop: 7,
        height: 'auto',
        backgroundColor: '#fff'
    },
    tagInputContainer: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    viewBackButton: {
        width: width/2,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    viewTopNewLogin: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        flexDirection: 'row'
    },
    viewSignUpText: {
        width: width/2,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(UserLoginCollection);