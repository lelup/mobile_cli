import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import ScalableText from 'react-native-text';

export default class UserTapCollection extends React.Component {
    render() {
        const selected = this.props.selected;
        const myStyle = selected ? 'buttonTextSelected' : 'buttonText';
        const wrapper = selected ? 'buttonViewSelected' : 'buttonView';

        return (
            <View style={[styles[wrapper], this.props.stylesButton]}>
                <TouchableOpacity
                    onPress={() => this.props.onPress(this.props.name)}>
                    <ScalableText style={[styles[myStyle], this.props.mainProps]} >
                        {this.props.children}
                    </ScalableText>
                </TouchableOpacity>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    lineunder: {
        borderStyle: "solid"
    },
    buttonViewSelected: {
        flexDirection: 'column',
        justifyContent: 'center',
        borderRadius: 16,
        paddingHorizontal: 15,
        paddingVertical: 6,
        backgroundColor: gui.mainAgentColor,
        borderWidth: 2,
        borderColor: gui.mainAgentColor,

    },
    buttonView: {
        flexDirection: 'column',
        justifyContent: 'center',
        borderRadius: 16,
        borderWidth: 2,
        borderColor: 'rgba(82,97,115,0.5)',
        paddingHorizontal: 15,
        paddingVertical: 6,
        backgroundColor: '#fff'
    },
    buttonText: {
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 0,
        color: 'rgba(82,97,115,0.5)',
        fontWeight : 'bold'
    },

    buttonTextSelected: {
        alignSelf:'center',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        padding: 0,
        color: '#fff',
        fontWeight : 'bold'
    }
});