import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    TouchableHighlight,
    Alert,
    TouchableWithoutFeedback,
    Keyboard
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import GiftedSpinner from "../../components/GiftedSpinner";
import Icon from 'react-native-vector-icons/FontAwesome';
import {Actions} from 'react-native-router-flux';
var Analytics = require('react-native-firebase-analytics');

import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import FloatInput from './FloatInput';
let {width, height} = utils.getDimensions();
import Toast, {DURATION} from '../toast/Toast';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';

const FBSDK = require('react-native-fbsdk');
const {
    LoginManager,
    AccessToken,
    GraphRequest,
    GraphRequestManager,
} = FBSDK;

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as meActions from '../../reducers/me/meActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as groupActions from '../../reducers/group/groupActions';

const actions = [
    globalActions,
    authActions,
    registerActions,
    meActions,
    searchActions,
    groupActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class NewLogin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            password: '',
            checkingUser: false
        }
    }

    render() {
        let checkingUser = (this.props.auth.isFetching || (this.props.global.loggedIn && !this.props.global.currentUser.userID)) || this.state.checkingUser || this.props.auth.isLoggingIn;
        return(
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                      style={{flex: 1}}
            >
              <View style={styles.container}>
                  <ScrollView contentContainerStyle={styles.scrollView}
                              style={{flex: 1}}
                              automaticallyAdjustContentInsets={false}
                              vertical={true}
                              keyboardShouldPersistTaps="always"
                              keyboardDismissMode="on-drag"
                  >
                      <View style={styles.viewTopNewLogin}>
                          {this.props.disableBackButton ? null :
                              <TouchableOpacity style={styles.viewBackButton}
                                                                             onPress={this._onPressBack.bind(this)}
                              >
                                  <TruliaIcon name="arrow-left"
                                              size={22}
                                              color={gui.mainColor}
                                              mainProps={{marginLeft: 0}}
                                              noAction={true}/>
                              </TouchableOpacity>
                          }
                          <TouchableOpacity style={styles.viewSignUpText}
                                            onPress={this._onPressSignUp.bind(this)}
                          >
                              <Text style={styles.textSignUp}>
                                  Chưa có tài khoản?
                              </Text>
                          </TouchableOpacity>
                      </View>
                      <View style={styles.viewDangNhap}>
                          <Text style={styles.textDangNhap}>Đăng nhập</Text>
                      </View>
                      <View style={styles.lineDangNhap}/>
                      <View style={styles.viewEmail}>
                          <FloatInput
                              placeholder={"Số điện thoại"}
                              autoCorrect={false}
                              style={styles.floatInput}
                              onChangeTextValue={(text) => {this._onUsernameTextChange(text)}}
                              value={this.state.username}
                              autoCapitalize='none'
                              onSubmitEditing={() => {this.refs.txtPassword.focus()}}
                              returnKeyType='done'
                              keyboardType={'numeric'}
                          />
                      </View>
                      <View style={[styles.viewEmail, { marginTop: 8}]}>
                          <FloatInput
                              ref="txtPassword"
                              placeholder={"Mật khẩu"}
                              autoCorrect={false}
                              style={styles.floatInput}
                              onChangeTextValue={(text) => this.setState({password: (text)})}
                              value={this.state.password}
                              secureTextEntry={true}
                              autoCapitalize='none'
                              onSubmitEditing={this._onPressLogin.bind(this)}
                              returnKeyType='done'
                          />
                      </View>
                      <View style={styles.viewTwoButton}>
                          {   checkingUser ?
                              <View style={styles.viewCreateButton}>
                                <GiftedSpinner color="white" />
                              </View>
                              :
                              <TouchableOpacity style={styles.viewCreateButton}
                                                onPress={this._onPressLogin.bind(this)}
                              >
                                  <Text style={styles.textFbStart}>ĐĂNG NHẬP</Text>
                              </TouchableOpacity>
                          }
                      </View>
                      <TouchableOpacity style={styles.viewAccept}
                                        onPress={this._onPressForgetPassword.bind(this)}>
                          <Text style={[styles.textFbStart,{color: gui.mainColor, opacity: 0.8}]}>
                              Quên mật khẩu?
                          </Text>
                      </TouchableOpacity>
                      {/* <View style={[styles.viewTwoButton, {marginTop: 91}]}>
                          <TouchableOpacity style={styles.viewLoginFB}
                                            onPress={this._onPresFbLogin.bind(this)}
                          >
                              <Icon name="facebook-square" size={22} color="#fff" style={styles.viewIconFb} />
                              <Text style={styles.textFbStart}>ĐĂNG NHẬP VỚI FACEBOOK</Text>
                          </TouchableOpacity>
                      </View> */}
                  </ScrollView>
                {/*{this._renderLoadingView()}*/}
                  <Toast
                      ref="toastTop"
                      position='top'
                      positionValue={height/3}
                      fadeInDuration={850}
                      fadeOutDuration={1400}
                      opacity={0.56}
                      textStyle={{color:'#fff'}}
                  />
              </View>
            </TouchableWithoutFeedback>
        );
    }

    _onUsernameTextChange(text){
        this.setState({username: text.replace(" ","")});
    }

    _onPressLogin(){
        if (!this.validate()){
            this.refs.toastTop && this.refs.toastTop.show('Số điện thoại không đúng định dạng.',DURATION.LENGTH_LONG);
            return;
        }
        this._onLoginPress();
        // let username = this.state.username.toLowerCase();
        // this.setState({checkingUser: true});
        // this.props.actions.checkUserExist(username).then(
        //     (res) => {
        //         log.info("Login._onThucHien");
        //         if (res.exist){
        //             this.setState({checkingUser: false});
        //             //Actions.UserComeback({username: username, doFinalAction: this.props.doFinalAction});
        //             this._onLoginPress();
        //         }else {
        //             if (res.status == 101){
        //                 this.setState({checkingUser: false});
        //                 this.refs.toastTop && this.refs.toastTop.show('Không đăng ký/đăng nhập được hệ thống',DURATION.LENGTH_LONG);
        //             } else {
        //                 this.setState({checkingUser: false});
        //                 // this.props.actions.onRegisterFieldChange('username',username);
        //                 // Actions.Register({needVerify: true});
        //                 this.refs.toastTop && this.refs.toastTop.show('Số điện thoại hoặc địa chỉ email chưa được đăng kí!',DURATION.LENGTH_LONG);
        //             }
        //         }
        //     }
        // )
    }

    _renderLoadingView() {
        if (this.props.auth.isLoggingIn || this.props.register.loggingByFB) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    validate(){
        let username = this.state.username;

        if (!username || username.trim().length == 0)
            return false;

        username = username.trim();

        if (username.indexOf("@")>=0){
            // return utils.validateEmail(username);
            return false;
        }

        return utils.validatePhone(username);
    }

    _onLoginPress(){
        log.info("user exist ==========> check password");
        if (!this.state.password){
            this.refs.toastTop && this.refs.toastTop.show('Bạn chưa nhập mật khẩu!',DURATION.LENGTH_LONG);
            return;
        }
        let username = this.state.username.toLowerCase().trim();
        this.props.actions.checkUserExist(username).then(
            (res) => {
                log.info("Login._onThucHien");
                if (res.status != 0) {
                    let msg = this._getErrorMessage();
                    this.refs.toastTop && this.refs.toastTop.show(msg,DURATION.LENGTH_LONG);
                }
                else if (res.exist){
                    this._doLogin();
                } else {
                    let msg = this._getUserNotExistMessage();
                    this.refs.toastTop && this.refs.toastTop.show(msg,DURATION.LENGTH_LONG);
                }
            }
        );
    }

    _getUserNotExistMessage() {
        let username = this.state.username;
        let msg = 'Không đăng nhập được hệ thống';

        if (!username || username.length <= 0)
            return msg;

        if (username.indexOf("@")>=0) {
            msg = 'Email không tồn tại trong hệ thống';
        } else {
            msg = 'Số điện thoại không tồn tại trong hệ thống';
        }

        return msg;
    }

    _getErrorMessage() {
        let username = this.state.username;
        let msg = 'Hệ thống hiện tại không kiểm tra được trạng thái tài khoản của bạn';

        if (!username || username.length <= 0)
            return msg;

        if (username.indexOf("@")>=0) {
            msg = 'Hệ thống hiện tại không kiểm tra được trạng thái email của bạn';
        } else {
            msg = 'Hệ thống hiện tại không kiểm tra được trạng thái số điện thoại của bạn';
        }

        return msg;
    }

    _doLogin() {
        let userDto = {
            username: this.state.username.toLowerCase().trim(),
            password: this.state.password
        };

        const deviceDto = {
            ... this.props.global.deviceInfo
        };

        this.props.actions.login(userDto.username, userDto.password, deviceDto)
            .then((res) => {
                if (res.login === true) {
                    if (this.props.onLoginSuccess) {
                        this.props.onLoginSuccess();
                    } else {
                        // if(this.props.global.help.welcomeInitial && !this.props.global.help.initialLogin){
                        //     Actions.Home({type: 'reset'});
                        // } else {Actions.pop()}

                        let deviceID = deviceDto.deviceID;
                        let userID = res.userID;

                        this.props.actions.loadAgentHomeData(
                            () => { },
                            (error) => {
                                Alert.alert('Thông báo',
                                    error,
                                    [{
                                        text: 'Đóng',
                                        onPress: () => {
                                        }
                                    }]);
                            }, {deviceID: deviceID, userID: userID});

                        // this._loadNewFeed(userID); //da goi new feed trong NewHomeAgent.componentWillMount

                        Actions.Home({type: 'reset'});

                        if (this.props.doFinalAction) {
                            this.props.doFinalAction();
                        }
                    }
                } else {
                    this.refs.toastTop && this.refs.toastTop.show('Mật khẩu đăng nhập không đúng!', DURATION.LENGTH_LONG);
                }
            })
            .catch((res) => {
                this.refs.toastTop && this.refs.toastTop.show(res.toString(), DURATION.LENGTH_LONG);
            })
    }

    _loadNewFeed = async(userID) => {
        if (!userID) {
            return;
        }
        let dto = {
            'userID': userID,
            'limit': 5,
            'pageNo': 1,
            'textSearch': ''
        }
        await this.props.actions.newFeedWall(dto
            , (res) => {
                log.info('_loadNewFeed server respond data: =====>>>>> ', res.data);
            }
            , (error) => {
                console.info('_loadNewFeed server respond error: =====>>>>> ', error);
            }
        );
    }

    _onPressForgetPassword() {
        //this.refs.toastTop && this.refs.toastTop.show('Coming soon!',DURATION.LENGTH_LONG);
        Actions.ForgetPassword();
    }

    _onPresFbLogin() {
        LoginManager.logInWithReadPermissions(['public_profile','email','user_friends']).then(
            (result) => {
                log.info('============> result', result);
                if (result.isCancelled) {
                    log.info('Login cancelled');
                } else {
                    log.info('Login success with permissions: ' +result.grantedPermissions.toString());
                    AccessToken.getCurrentAccessToken().then((data) => {
                        const { accessToken } = data;
                        if(data) 
                            { this.initUser(accessToken);}
                        else { LoginManager.logOut()}
                    })
                }
            },
            (error) => {
                log.info('Login fail with error: ' + error);
            }
        );
    }

    initUser(token) {
        fetch('https://graph.facebook.com/v2.10/me?fields=id,picture,email,name,friends&access_token=' + token)
            .then((response) => response.json())
            .then((json) => {
                this.register(token,json);
            })
            .catch(() => {
                log.info('ERROR GETTING DATA FROM FACEBOOK')
            })
    }

    register(token, json)  {        
        let username = json.name || '';
        let email =  json.email || '';
        let phone = json.phone || '';
        let avatar = json.picture.data.url || undefined;
        let id = json.id;
        let userDto = {
            username: id,
            phone: phone,
            email: email.indexOf("@") > -1 ? email.toLowerCase() : undefined,
            fbID: id || undefined,
            verifyCode: undefined,
            verifyType: DanhMuc.VERIFY_TYPE.register,
            fullName: username || undefined,
            matKhau: '123456',
            avatar: avatar || undefined,
            broker:  undefined,
            source: 'mobile',
            deviceInfo: {
                deviceID: this.props.global.deviceInfo.deviceID || undefined,
                deviceModel: this.props.global.deviceInfo.deviceModel || undefined
            },
            tokenID: this.props.global.deviceInfo.tokenID || undefined,
            tokenOs: this.props.global.deviceInfo.tokenOs || undefined,
            tokenRegistered: this.props.global.deviceInfo.tokenRegistered || undefined,
            appVersion: this.props.global.deviceInfo.appVersion || undefined,
            fbAccessToken: token
        };

        log.info('==============> userDto', userDto);

        this.props.actions.registerUserUsingFB(userDto)
            .then((res) =>{
                if (!res.login || res.login==false) {
                    Alert.alert('Thông báo', res.msg);
                } else {
                    Alert.alert('Thông báo', gui.INFO_userLoginSuccessfully);
                    Actions.pop();
                    Actions.pop();
                    this.props.actions.registerSuccess(userDto);
                    this.doLogin(userDto);
                }
            });

        Analytics.logEvent('REGISTER FACEBOOK', {deviceID: userDto.deviceID, userInfo: userDto});
    }

    doLogin(dto){
        let userDto = {
            username: dto.username,
            password: dto.matKhau
        };

        let phone = dto.phone;
        let fbID = dto.fbID;
        let email = dto.email;
        const deviceDto = {
            ... this.props.global.deviceInfo
        };

        this.props.actions.login(userDto.username, userDto.password, deviceDto)
            .then((res) => {
                if (res.login ===true) {
                    if(fbID && (!res.email && !res.phone)) {                           
                        // console.log('doLogin ***************', res)
                        this.props.actions.profile(res.userID, res.token).then(
                            (res) => {
                                if (res.success) {
                                    Actions.Profile({ owner : 'VerifyFacebook', doFinalAction: this.props.doFinalAction});
                                } else {
                                    Alert.alert('Thông báo', 'Tải thông tin cá nhân không thành công.');
                                }
                            }
                        );                        
                    } else  { 
                        this.onCheckLoginFb()
                    }
                } else {
                    this.refs.toastTop && this.refs.toastTop.show('Mật khẩu đăng nhập không đúng!',DURATION.LENGTH_LONG);
                }
            })
            .catch((res) => {
                Alert.alert('Thông báo', res.toString());
            })
    }

    onCheckLoginFb() {
        if (this.props.onLoginSuccess) {
            this.props.onLoginSuccess();
        } else {
            if(this.props.global.help.welcomeInitial && !this.props.global.help.initialLogin) {
                Actions.Home({type: 'reset'});
            }else {
                Actions.pop();
                Actions.pop();
            }
            if (this.props.doFinalAction){
                this.props.doFinalAction();
            }
        }
    }

    _onPressSignUp() {
        Actions.UserLoginCollection({ owner: 'create' });
    }

    _onPressBack() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 48
    },
    viewBackButton: {
        width: width/2,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    viewSignUpText: {
        width: width/2,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    textSignUp: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainAgentColor,
        fontSize: 15
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 22
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 24
    },
    viewEmail: {
        width: width,
        height: 48,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        marginTop: 41
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width,
        opacity: 0.8
    },
    floatInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        backgroundColor:'rgba(82,97,115,1)',
        width: width - 32,
        height: 48
    },
    textFbStart: {
        fontFamily: gui.fontFamily,
        color: '#fff',
        fontSize: 15,
        fontWeight: 'normal'
    },
    viewTwoButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 48,
        marginTop: 32
    },
    viewCreateButton: {
        width: width - 32,
        height: 48,
        marginTop: 16,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 24
    },
    viewAccept: {
        height: 20,
        marginTop: 27, // 17
        width: width,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewLoginFB: {
        width: width - 32,
        height: 48,
        backgroundColor: '#3B5998',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 24
    },
    viewIconFb: {
        position: 'absolute',
        left: 24
    },
    viewTopNewLogin: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        flexDirection: 'row'
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(NewLogin);