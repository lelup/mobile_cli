import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Alert,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
    Keyboard
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import {Actions} from 'react-native-router-flux';

import KeyboardSpacer from 'react-native-keyboard-spacer';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import CodeInput from './ConfirmationCodeInput';
import FullLine from '../line/FullLine';
let {width, height} = utils.getDimensions();
import DanhMuc from '../../assets/DanhMuc';
import Toast, {DURATION} from '../toast/Toast';
import log from '../../lib/logUtil';
import GiftedSpinner from "../../components/GiftedSpinner";

import moment from 'moment';
var Analytics = require('react-native-firebase-analytics');

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import * as globalActions from '../../reducers/global/globalActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as authActions from '../../reducers/auth/authActions';

var Intercom = require('react-native-intercom');
const actions = [
    globalActions,
    registerActions,
    postAdsActions,
    authActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class VerifyCode extends Component {
    constructor(props){
        super(props);
        this.state = {
            code: '',
            getCode: '',
            codeGuide: props.codeGuide,
            verifyCode: null,
            avatar: null,
            thumbnail: null,
            isFetching: false
        }
    }

    render() {
        let { codeGuide }  =  this.state ;
        return(
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                      style={{flex: 1}}
            >
                <View style={styles.container}>
                        <View style={styles.viewBackButton}>
                            <TouchableOpacity style={styles.touchBackButton}
                                              onPress={this._onPressBack.bind(this)}
                            >
                                <TruliaIcon name="arrow-left"
                                            size={22}
                                            color={gui.mainColor}
                                            mainProps={{marginLeft: 0}}
                                            noAction={true} />
                            </TouchableOpacity>
                            <View style={styles.viewSendCodeAgain}>
                                {/*<Text style={styles.textSendCodeAgain}>Gửi lại SMS</Text>*/}
                            </View>
                        </View>
                        <View style={styles.viewDangNhap}>
                            <Text style={styles.textDangNhap}>Nhập mã xác nhận</Text>
                        </View>
                        <View style={styles.lineDangNhap}/>
                        <View style={styles.viewCodeGuide}>
                            <Text style={[styles.textSendCodeAgain, {color: 'rgba(82,97,115,0.5)'}]}>
                                {codeGuide}
                            </Text>
                        </View>
                        <View style={styles.viewCodeElement}>
                            <CodeInput
                                ref="codeInputRef"
                                keyboardType="numeric"
                                codeLength={5}
                                className={'border-circle'}
                                //compareWithCode='12345'
                                autoFocus={true}
                                codeInputStyle={styles.codeInputStyle}
                                onFulfill={(code) => this._onFinishCheckingCode(code)}
                            />
                        </View>
                        {this._renderRowChatSupport()}
                        {this.state.isFetching ?
                            (<View style={styles.viewIsFetching}>
                                <GiftedSpinner size="large" color={gui.mainTextColor} />
                            </View>) : null
                        }
                        <Toast
                            ref="toastTop"
                            position='top'
                            positionValue={292}
                            fadeInDuration={850}
                            fadeOutDuration={1400}
                            opacity={0.56}
                            textStyle={{color:'#fff'}}
                        />
                </View>
            </TouchableWithoutFeedback>
        );
    }

    _renderRowChatSupport() {
        let title = "Chăm sóc khách hàng";
        let subtitle = "Trò chuyện trực tiếp với tư vấn viên.";
        let supportUri = require('../../assets/image/p_support.png');
        return (
            <TouchableOpacity onPress={this._onDisplayMessenger.bind(this)} style={styles.viewNewSupport}>
                <View style={styles.viewIconSupport}>
                    <Image
                        style={styles.supportIcon}
                        resizeMode={Image.resizeMode.cover}
                        source={supportUri}
                    />
                </View>
                <View style={styles.viewContentSupport}>
                    <Text style={[styles.textSendCodeAgain, { color: gui.mainAgentColor, fontSize: 15 }]} numberOfLines={1}>{title}</Text>
                    <Text style={[styles.textSendCodeAgain, { fontSize: 13, color: 'rgba(178,178,178,1)' }]} numberOfLines={1}>{subtitle}</Text>
                </View>
            </TouchableOpacity>
        );
    }

    _onDisplayMessenger() {
        try {
            Intercom.reset().then(() => {
                Intercom.registerUnidentifiedUser()
                    .then(() => {
                        Intercom.displayMessenger();
                    })
                    .catch((err) => {
                        log.error('registerIdentifiedUser ERROR', err);
                    });
            });

        } catch (error) {
            log.warn('========== onDisplayMessenger ERROR', error);
        }
    }


    _onFinishCheckingCode(code) {
        if (!code){
            this.refs.toastTop && this.refs.toastTop.show(gui.VERIFY_CODE_IS_UNFULFILLED,DURATION.LENGTH_LONG);
            return;
        }
        this.setState({verifyCode: code}, this._doRegister);                
        
    }

    _doRegister(){
        this.state.avatar = null;
        this.state.thumbnail = null;
        
        let filepath = this.props.register.image;
        let thumbnailPath = this.props.register.thumbnail;
        if (!filepath) {
            
            this.register();
            return;
        }
        let ms = moment().toDate().getTime();
        let userID = this.props.register.username;
        let filename = 'Avatar_' + userID + '_' + ms + filepath.substring(filepath.lastIndexOf('.'));
        this.props.actions.onUploadImage(filename, filepath, this.uploadCallBack.bind(this), 'normal');

        let thumbnailName = 'Thumbnail_Avatar_' + userID + '_' + ms + thumbnailPath.substring(filepath.lastIndexOf('.'));
        this.props.actions.onUploadImage(thumbnailName, thumbnailPath, this.uploadCallBack.bind(this), 'thumbnail');
    }

    uploadCallBack(err, result, type) {
        let {data} = result;
        if (err || data == '') {
            return;
        }
        let {success, file} = JSON.parse(data);
        if (success) {
            let {url} = file;
            if (type=='normal')
                this.state.avatar = url;
            else if (type=='thumbnail')
                this.state.thumbnail = url;

            if (this.state.avatar && this.state.thumbnail)
                this.register();
        }
    }

    register()  {
        console.log('calling register **********************************************************')
        let username = this.props.register.username.trim();
        let email = this.props.register.email.trim();
        let userDto = {
            username: username,
            phone: username.indexOf("@") > -1 ? undefined : username.toLowerCase(),
            email: email.toLowerCase() || undefined,
            verifyCode: this.state.verifyCode || undefined,
            verifyType: DanhMuc.VERIFY_TYPE.register,
            fullName: this.props.register.fullName || username,
            matKhau: this.props.register.matKhau,
            avatar: this.state.avatar || undefined,
            thumbnail: this.state.thumbnail || undefined,
            broker: true, //this.props.register.broker || undefined,
            source: 'mobile',
            deviceID: this.props.global.deviceInfo.deviceID || undefined,
            deviceModel: this.props.global.deviceInfo.deviceModel || undefined,
            tokenID: this.props.global.deviceInfo.tokenID || undefined,
            tokenOs: this.props.global.deviceInfo.tokenOs || undefined,
            tokenRegistered: this.props.global.deviceInfo.tokenRegistered || undefined,
            appVersion: this.props.global.deviceInfo.appVersion || undefined,
            refUser: this.props.register.refUser
        };

        // console.log('***********************> userDto', userDto);

        this.setState({isFetching: true});

        this.props.actions.registerUser(userDto)
            .then((res) =>{
                this.setState({isFetching: false});
                if (!res.login || res.login==false) {
                    Alert.alert('Thông báo', res.msg);
                } else {
                    Alert.alert('Thông báo', gui.INFO_userCreatedSuccessfully);
                    Actions.pop();
                    Actions.pop();
                    this.props.actions.registerSuccess(userDto);
                    this.doLogin(userDto);
                }
            });

        Analytics.logEvent('REGISTER', {deviceID: userDto.deviceID, userInfo: userDto});
    }

    doLogin(dto){
        let userDto = {
            username: dto.username,
            password: dto.matKhau
        };

        const deviceDto = {
            ... this.props.global.deviceInfo
        };

        this.props.actions.login(userDto.username, userDto.password, deviceDto)
            .then((res) => {
                if (res.login ===true) {
                    if (this.props.onLoginSuccess) {
                        this.props.onLoginSuccess();
                    } else {
                        if(this.props.global.help.welcomeInitial && !this.props.global.help.initialLogin) {
                            Actions.Home({type: 'reset'});
                        }else {
                            Actions.pop();
                            Actions.pop();
                        }
                        if (this.props.doFinalAction){
                            this.props.doFinalAction();
                        }
                    }
                } else {
                    this.refs.toastTop && this.refs.toastTop.show('Mật khẩu đăng nhập không đúng!',DURATION.LENGTH_LONG);
                }
            })
            .catch((res) => {
                Alert.alert('Thông báo', res.toString());
            })
    }

    _onPressBack() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 48
    },
    viewBackButton: {
        width: width,
        height: 60,
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        paddingLeft: 16,
        flexDirection: 'row'
    },
    touchBackButton: {
        height: 60,
        width: 20,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        backgroundColor: '#fff'
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 22
    },
    textDangNhap: {
        fontWeight: '500',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 24
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width,
        opacity: 0.8
    },
    viewSendCodeAgain: {
        height: 20,
        width: 80,
        justifyContent: 'center',
        alignItems: 'flex-end',
        position: 'absolute',
        right: 16,
        backgroundColor: '#fff'
    },
    textSendCodeAgain: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainColor,
        fontSize: 15
    },
    viewCodeGuide: {
        width: width,
        height: 40,
        paddingLeft: 16,
        paddingRight: 23,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        marginTop: 18
    },
    viewCodeElement: {
        height: 64,
        width: width,
        paddingLeft: 16,
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 50, //55
        backgroundColor: '#fff'
    },
    codeInputStyle: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        color: '#526173',
        fontWeight: '500',
        fontFamily: gui.fontFamily
    },
    viewIsFetching: {
        marginTop: 50,
        width: width,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewNewSupport: {
        height: 85,
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        marginTop: 60
    },
    viewIconSupport: {
        height: 85,
        width: 80,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    viewContentSupport: {
        height: 85,
        width: width - 38 - 80,
        paddingRight: 8,
        justifyContent: 'center',
        backgroundColor: '#fff'
    },
    supportIcon: {
        height: 45,
        width: 45
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(VerifyCode);