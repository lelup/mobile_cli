import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    Switch,
    StatusBar,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
    Keyboard
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {Actions} from 'react-native-router-flux';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import GiftedSpinner from "../../components/GiftedSpinner";
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';
import Camera from 'react-native-camera';

import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import FloatInput from './FloatInput';
let {width, height} = utils.getDimensions();
import Toast, {DURATION} from '../toast/Toast';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';

const Permissions = require('react-native-permissions');
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';
import dismissKeyboard from 'react-native-dismiss-keyboard';

import * as globalActions from '../../reducers/global/globalActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as postAdsActions from '../../reducers/postAds/postAdsActions';
import * as authActions from '../../reducers/auth/authActions';
const minLength = 0;

const actions = [
    globalActions,
    registerActions,
    postAdsActions,
    authActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class CreateAccount extends Component {
    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');
        this.state = {
            verifyLoading:  false,
            phoneNumber: '',
            email: '',
            password:'',
            passwordAgain: '',
            brokerValue: true,
            avatar: null,
            verifyCode: null,
            userExist: null,            
            userIntro: props.register.userIntro,
            refUser: props.register.refUser
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.register.userIntro !== nextProps.register.userIntro) {
            this.setState({ userIntro: nextProps.register.userIntro });
        }        
        if (this.props.register.refUser !== nextProps.register.refUser) {
            this.setState({ refUser: nextProps.register.refUser });
        }  
    }

    render() {
        let introBonus = 'Bạn biết đến Landber Agent qua người giới thiệu?';
        let checkColor = this.state.refUser && this.state.refUser.id ? 'rgba(49,207,100,1)' : 'rgb(191,189,197)';
        return(
                <View style={styles.container}>
                    <View style={styles.viewTopNewLogin}>
                        <TouchableOpacity style={styles.viewBackButton}
                                          onPress={this._onPressBack.bind(this)}
                        >
                            <TruliaIcon name="arrow-left"
                                        size={22}
                                        color={gui.mainColor}
                                        mainProps={{marginLeft: 0}}
                                        noAction={true} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.viewDangNhap}>
                        <Text style={styles.textDangNhap}>Tạo tài khoản</Text>
                    </View>
                    <View style={styles.lineDangNhap}/>
                    <ScrollView style={{flex: 1}}>
                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}
                                                  style={{flex: 1}}
                        >
                            <View style={styles.scrollView}>
                                <View style={[styles.viewEmail, { flexDirection: 'row'}]}>
                                    <FloatInput
                                        ref="txtUserIntro"
                                        placeholder={"Số điện thoại người giới thiệu"}
                                        autoCorrect={false}
                                        container={{width: width - 68}}
                                        style={[styles.floatInput,{width: width - 68}]}
                                        // onChangeTextValue={(text) => {this.props.actions.onRegisterFieldChange('userIntro',text)}}
                                        onChangeTextValue={this._onChangeText.bind(this)}
                                        value={this.state.userIntro}
                                        autoCapitalize='none'
                                        onSubmitEditing={() => {this.refs.txtName.focus()}}
                                        returnKeyType='done'
                                        keyboardType={'numeric'}
                                    />
                                    <View style={styles.viewIconIntro}>
                                            <FontAwesomeSolid name={'check-circle'}
                                                          size={20}
                                                          color={checkColor}
                                                          mainProps={{marginTop: 12, marginRight: 5 }}
                                            />
                                    </View>
                                </View>

                                <View style={styles.viewIntroBonus}>
                                    <Text style={styles.textIntroBonus}>{introBonus}</Text>
                                </View>

                                <View style={[styles.viewEmail, { marginTop: 8}]}>
                                    <FloatInput
                                        ref="txtName"
                                        placeholder={"Họ tên"}
                                        autoCorrect={false}
                                        style={styles.floatInput}
                                        onChangeTextValue={(text) => {this.props.actions.onRegisterFieldChange('fullName',text)}}
                                        value={this.props.register.fullName}
                                        autoCapitalize='words'
                                        onSubmitEditing={() => {this.refs.txtPhone.focus()}}
                                        returnKeyType='done'
                                    />
                                </View>
                                <View style={[styles.viewEmail, { marginTop: 8}]}>
                                    <FloatInput
                                        ref="txtPhone"
                                        placeholder={"Số điện thoại"}
                                        autoCorrect={false}
                                        style={styles.floatInput}
                                        onChangeTextValue={(text) => {this.props.actions.onRegisterFieldChange('username',text)}}
                                        value={this.props.register.username}
                                        autoCapitalize='none'
                                        onSubmitEditing={() => {this.refs.txtEmail.focus()}}
                                        returnKeyType='done'
                                        keyboardType={'numeric'}
                                    />
                                </View>
                                <View style={[styles.viewEmail, { marginTop: 8}]}>
                                    <FloatInput
                                        ref="txtEmail"
                                        placeholder={"Email"}
                                        autoCorrect={false}
                                        style={styles.floatInput}
                                        onChangeTextValue={(text) => {this.props.actions.onRegisterFieldChange('email',text)}}
                                        value={this.props.register.email}
                                        autoCapitalize='none'
                                        onSubmitEditing={() => {this.refs.txtPassword.focus()}}
                                        returnKeyType='done'
                                    />
                                </View>
                                <View style={[styles.viewEmail, { marginTop: 8}]}>
                                    <FloatInput
                                        ref="txtPassword"
                                        placeholder={"Mật khẩu"}
                                        autoCorrect={false}
                                        style={styles.floatInput}
                                        onChangeTextValue={(text) => {this.props.actions.onRegisterFieldChange('matKhau',text)}}
                                        value={this.props.register.matKhau}
                                        secureTextEntry={true}
                                        autoCapitalize='none'
                                        onSubmitEditing={() => {this.refs.txtConfirmPassword.focus()}}
                                        returnKeyType='done'
                                    />
                                </View>
                                <View style={[styles.viewEmail, { marginTop: 8}]}>
                                    <FloatInput
                                        ref="txtConfirmPassword"
                                        placeholder={"Nhập lại mật khẩu"}
                                        autoCorrect={false}
                                        style={styles.floatInput}
                                        onChangeTextValue={(text) => this.setState({passwordAgain: (text)})}
                                        value={this.state.passwordAgain}
                                        secureTextEntry={true}
                                        autoCapitalize='none'
                                        onSubmitEditing={() => dismissKeyboard()}
                                        returnKeyType='done'
                                    />
                                </View>
                                {/* {this._renderMoiGioiOption()} */}
                                {this._renderUploadAvatar()}
                                <View style={styles.viewTwoButton}>
                                        {   this.state.verifyLoading ?
                                            <View style={styles.viewCreateButton}>
                                                <GiftedSpinner color="white" />
                                            </View>
                                            :
                                            <TouchableOpacity style={styles.viewCreateButton}
                                                              onPress={this._onPressAcceptCode.bind(this)}
                                            >
                                                <Text style={styles.textFbStart}>TIẾP THEO</Text>
                                            </TouchableOpacity>
                                        }
                                </View>
                                <KeyboardSpacer />
                            </View>
                        </TouchableWithoutFeedback>
                    </ScrollView>
                    <Toast
                        ref="toastTop"
                        position='top'
                        positionValue={height/3}
                        fadeInDuration={850}
                        fadeOutDuration={1400}
                        opacity={0.56}
                        textStyle={{color:'#fff'}}
                    />
                </View>
        );
    }

    _onChangeText(text) {

        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            userIntro: text
        });
        this.props.actions.onRegisterFieldChange('userIntro',text)
    }

    _request(text) {
        if (text && text.length > minLength) {
            this._requestUserIntro(text);
        }
    }

    _requestUserIntro(text) {
        let searchPhone = text || undefined;
                
        this.props.actions.getUserIntro(
            {
                'phone': searchPhone
            }
            , (res) => {
                
            }
            , (error) => {
                console.log('server respond error: =====>>>>>', error)
            });
    }

    _renderMoiGioiOption() {
        let textDetail = 'Việc trả lời câu hỏi này giúp chúng tôi hiểu bạn hơn để tối ưu nội dung hiển thị và tính năng phù hợp nhất';
        let textBroker = this.state.brokerValue ? 'Có' : 'Không';
        let colorBroker = this.state.brokerValue ? '#78BC61' : gui.colorMainBlur;
        return(
            <View style={styles.viewMoiGioiOption}>
                <View style={styles.viewSwitchBroker}>
                    <View style={styles.viewTextBroker}>
                        <Text style={styles.textBroker}>Bạn có phải môi giới?</Text>
                    </View>
                    <View style={styles.viewChooseBroker}>
                        <View style={styles.viewYesBroker}>
                            <Text style={[styles.textYestBroker, {color: colorBroker}]}>{textBroker}</Text>
                        </View>
                        <View style={styles.viewSwitchChange}>
                                <Switch
                                    onValueChange={(value) => this._onBrokerChange('brokerValue', value)}
                                    value={this._getBrokerValue()}
                                    onTintColor={'#78BC61'}
                                    tintColor={'rgba(82,97,115,0.1)'}
                                    style={styles.viewAswitch}
                                />
                        </View>
                    </View>
                </View>
                <View style={styles.viewTextDetail}>
                    <Text style={[styles.textBroker, styles.addTextBroker]}>
                        {textDetail}
                    </Text>
                </View>
            </View>
        );
    }

    _renderUploadAvatar() {
        let defaultImg = require('../../assets/image/user.png');
        let imgUrl = !this.props.register.image || this.props.register.image.length<=0 ?
            defaultImg : {uri: this.props.register.image};
        return(
            <TouchableOpacity onPress={this._takePicture.bind(this)}>
                <View style ={styles.changeImage}>
                    <Image style={styles.detailImage} source={imgUrl} defaultSource={defaultImg} />
                    <Text style={styles.textImage}>Chạm để thêm ảnh đại diện</Text>
                </View>
            </TouchableOpacity>
        );
    }

    _takePicture() {
        Camera.checkDeviceAuthorizationStatus().then(
            (e) => {                
                if (e){

                    Permissions.requestPermission('photo')
                    .then(response => {
                        if (response == 'authorized') {
                            Actions.PostAds({owner: 'register'});
                        } else {
                        Alert.alert("Thông báo", gui.INF_PhotoAccess);
                        }
                    });                    
                } else {
                    Alert.alert('Thông báo', gui.INF_CameraAccess);
                }
            });
    }

    _onPressAcceptCode() {
        if (!this.validateData())
            return;
        if (this.props.register.username) {
            let username = this.props.register.username.toLowerCase().trim();
            this.props.actions.checkUserExist(username).then(
                (res) => {
                    log.info("=====> checkUserExist");
                    if (res.exist){
                        this.refs.toastTop && this.refs.toastTop.show('Số điện thoại đã tồn tại trong hệ thống!', DURATION.LENGTH_LONG);
                    } else {
                        if (res.status == 101){
                            this.refs.toastTop && this.refs.toastTop.show('Không đăng ký được hệ thống',DURATION.LENGTH_LONG);
                        }
                        else {
                            this.sendVerifyCode();
                        }
                    }
                }
            )
        }
    }

    sendVerifyCode() {
        this.setState({ verifyLoading: true});
        if(this.state.brokerValue) {
            this.props.actions.onRegisterFieldChange('broker','Y');
        } else {
            this.props.actions.onRegisterFieldChange('broker','N');
        }
        let username = this.props.register.username.toLowerCase().trim();
        let destinationType = username.indexOf("@") > -1 ? "email" : "số điện thoại";
        this.props.actions.requestVerifyCode({username: username, verifyType: DanhMuc.VERIFY_TYPE.register})
            .then ((res) => {
                if (res.success){
                    this.setState({ verifyLoading: false});
                    let codeGuide = `Mã xác nhận gồm 5 chữ số vừa được gửi đến ${destinationType} của bạn.`;
                    Actions.VerifyCode({ codeGuide: codeGuide, doFinalAction: () => Actions.Home({type: 'reset'}) });
                } else {
                    this.setState({ verifyLoading: false});
                    let codeSendError = 'Hệ thống gửi mã xác nhận không thành công. Xin vui lòng kiểm tra lại số điện thoại hoặc thực hiện lại sau 15 phút.';
                    this.refs.toastTop && this.refs.toastTop.show(codeSendError,DURATION.LENGTH_LONG);
                }
            });
    }

    validateData() {
        let username = this.props.register.username;
        let email = this.props.register.email;
        let fullName = this.props.register.fullName;
        
        if (!fullName || fullName.trim().length == 0) {
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "họ tên!",DURATION.LENGTH_LONG);
            return false;
        }
        
        if (!username || username.trim().length == 0) {
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "số điện thoại!",DURATION.LENGTH_LONG);
            return false;
        }
        if (email) {
            email = email.trim();
            if (!utils.validateEmail(email)){
                this.refs.toastTop && this.refs.toastTop.show( "Địa chỉ email không đúng định dạng!",DURATION.LENGTH_LONG);
                return false;
            }
        }
        username = username.trim();
        if (username.indexOf("@")<0 && !utils.validatePhone(username)){
            this.refs.toastTop && this.refs.toastTop.show( "Số điện thoại không đúng định dạng!",DURATION.LENGTH_LONG);
            return false;
        }
        if (!this.props.register.matKhau) {
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "mật khẩu!",DURATION.LENGTH_LONG);
            return false;
        }

        if (!this.state.passwordAgain || this.state.passwordAgain.length <=0) {
            this.refs.toastTop && this.refs.toastTop.show( gui.ERR_dataRequired + "lại mật khẩu!",DURATION.LENGTH_LONG);
            return false;
        }
        if (this.props.register.matKhau != this.state.passwordAgain) {
            this.refs.toastTop && this.refs.toastTop.show( "Mật khẩu nhập lại không trùng khớp!",DURATION.LENGTH_LONG);
            return false;
        }
        

        return true;
    }

    _onBrokerChange(key, value) {
        let newState = {};
        newState[key] = value;
        this.setState(newState);
    }

    _getBrokerValue() {
        return this.state.brokerValue;
    }

    _onPressBack() {
        this.props.actions.onRegisterFieldChange('matKhau', '');
        this.props.actions.onRegisterFieldChange('username', '');
        this.props.actions.onRegisterFieldChange('email', '');
        this.props.actions.onRegisterFieldChange('fullName', '');
        this.props.actions.onRegisterFieldChange('broker', null);
        this.props.actions.onRegisterFieldChange('image', null);
        this.props.actions.onRegisterFieldChange('thumbnail', null)
        this.props.actions.onRegisterFieldChange('userIntro', '')
        this.props.actions.onRegisterFieldChange('refUser', null)
        Actions.pop();
    }

    _onPressSignIn() {
        this.props.actions.onRegisterFieldChange('matKhau', '');
        this.props.actions.onRegisterFieldChange('username', '');
        this.props.actions.onRegisterFieldChange('email', '');
        this.props.actions.onRegisterFieldChange('fullName', '');
        this.props.actions.onRegisterFieldChange('broker', null);
        this.props.actions.onRegisterFieldChange('image', null);
        this.props.actions.onRegisterFieldChange('thumbnail', null)
        Actions.NewLogin({doFinalAction: () => Actions.Home({type: 'reset'})});
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        alignItems: 'center',
        flex: 1,
        backgroundColor: 'white'
    },
    viewDangNhap: {
        width: width,
        height: 36,
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingLeft: 16,
        marginTop: 22
    },
    textDangNhap: {
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 24
    },
    viewEmail: {
        width: width,
        height: 48,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        marginTop: 41
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width,
        opacity: 0.8
    },
    floatInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        backgroundColor:'rgba(82,97,115,1)',
        width: width - 32,
        height: 48
    },
    viewMoiGioiOption: {
        height: 121,
        width: width,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 32
    },
    viewSwitchBroker: {
        width: width - 32,
        height: 32,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderColor: 'rgba(82,97,115,0.1)',
    },
    viewTextDetail: {
        marginTop: 8,
        height: 60,
        width: width - 32,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    textBroker: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: '#526173',
        fontSize: 15,
    },
    textIntroBonus: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: 'rgba(178,178,178,1)',
        fontSize: 13,
        textAlign: 'left',
        alignSelf: 'flex-start'
    },
    viewTextBroker: {
        height: 32,
        width: width - 144,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    addTextBroker: {
        color: 'rgba(82,97,115,0.6)',
        textAlign: 'center',
        fontSize: 12
    },
    viewChooseBroker: {
        width: 112,
        height: 32,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-end'
    },
    viewYesBroker: {
        height: 32,
        width: 64,
        justifyContent: 'flex-start',
        alignItems: 'flex-end'
    },
    textYestBroker: {
        fontWeight: 'bold',
        fontFamily: gui.fontFamily,
        color: '#78BC61',
        fontSize: 15
    },
    viewSwitchChange: {
        height: 32,
        width: 40,
        justifyContent: 'flex-end',
        alignItems: 'flex-start'
    },
    viewAswitch: {
        transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
        marginBottom: 6
    },
    viewTwoButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 48,
        marginTop: 31,
        marginBottom: 48
    },
    viewCreateButton: {
        width: width - 32,
        height: 48,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 24
    },
    textFbStart: {
        fontFamily: gui.fontFamily,
        color: '#fff',
        fontSize: 15,
        fontWeight: 'bold'
    },
    viewTopNewLogin: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        flexDirection: 'row'
    },
    textSignUp: {
        fontWeight: 'normal',
        fontFamily: gui.fontFamily,
        color: gui.mainAgentColor,
        fontSize: 15
    },
    viewBackButton: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    viewSignUpText: {
        width: width/2,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 16
    },
    changeImage: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop:8,
        flexDirection:'row',
        width: width,
        height: 38
    },
    textImage: {
        fontSize:13,
        color: gui.mainTextColor,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        marginLeft: 8
    },
    detailImage: {
        width: 40,
        height: 40,
        borderRadius: 20
    },
    viewIconIntro: {
        backgroundColor: 'rgba(82,97,115,0.07)',
        width: 36,
        height: 48,
        justifyContent: 'center'
    },
    viewIntroBonus: {
        width: width - 32,
        height: 58 - 30,
        marginTop: 8
    }

});

export default connect(mapStateToProps, mapDispatchToProps)(CreateAccount);
