import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    TouchableHighlight,
    Alert,
    StatusBar,
    Platform
} from 'react-native';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {Map} from 'immutable';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import GiftedSpinner from "../../components/GiftedSpinner";
import {Actions} from 'react-native-router-flux';

import ScalableText from 'react-native-text';
import gui from '../../lib/gui';
import TruliaIcon from '../TruliaIcon';
import utils from '../../lib/utils';
import FullLine from '../line/FullLine';
import FloatInput from './FloatInput';
let {width, height} = utils.getDimensions();
import Toast, {DURATION} from '../toast/Toast';
import log from '../../lib/logUtil';
import DanhMuc from '../../assets/DanhMuc';

import * as globalActions from '../../reducers/global/globalActions';
import * as authActions from '../../reducers/auth/authActions';
import * as registerActions from '../../reducers/register/registerActions';
import * as meActions from '../../reducers/me/meActions';

const actions = [
    globalActions,
    authActions,
    registerActions,
    meActions
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class UpdatePassword extends Component {
    constructor(props) {
        StatusBar.setBarStyle('dark-content');
        super(props);
        let username = props.username;
        this.state = {
            username: username,
            newPassword: '',
            verifyCode: '',
        }
    }

    componentDidMount() {
        let value = this.state.username;
        let maXacNhanHint = value.indexOf("@")>=0 ? 'Mã xác nhận đã được gửi tới email ' + value :
        'Mã xác nhận đã được gửi tới số điện thoại ' + value;
        setTimeout(() => {this.refs.toastPass && this.refs.toastPass.show(maXacNhanHint,5000)}, 1000);
    }

    render() {
        return(
            <View style={styles.container}>
                <View style={styles.modalContainer}>
                    <View style={[styles.toolbarModalSend, Platform.OS === 'ios' ? {marginTop: 0} : null]}>
                        <TouchableOpacity onPress={this._onPressBack.bind(this)} style={styles.modalBack} >
                            <TruliaIcon name="arrow-left"
                                        size={22}
                                        color="#fff"
                                        mainProps={{marginLeft: 0}}
                                        noAction={true} />
                        </TouchableOpacity>
                        <View style={styles.modalViewTitle}>
                            <Text style={styles.modalTextTile}>Cập nhật mật khẩu</Text>
                        </View>
                        <View style={styles.modalTextCan}></View>
                    </View>
                    <KeyboardAwareScrollView
                        keyboardShouldPersistTaps="always"
                        keyboardDismissMode="none"
                        ref='scroll'>
                        <View style={styles.modalBody}>
                            <View style ={styles.viewCapNhat}>
                                <ScalableText style={styles.textXacNhan}>Tạo mật khẩu mới cho tài khoản của bạn</ScalableText>
                            </View>
                            <View style={[styles.viewEmail,{marginTop: 41}]}>
                                <FloatInput
                                    placeholder={"Tài khoản"}
                                    style={styles.floatInput}
                                    //onChangeTextValue={(text) => {this._onUsernameTextChange(text)}}
                                    value={this.state.username}
                                    autoCapitalize='none'
                                    editable={false}
                                />
                            </View>
                            <View style={[styles.viewEmail, {marginTop: 16}]}>
                                <FloatInput
                                    placeholder={"Mã xác nhận"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => {this._onVerifyCodeChange(text)}}
                                    value={this.state.verifyCode}
                                    autoCapitalize='none'
                                />
                            </View>
                            <View style={[styles.viewEmail, {marginTop: 16}]}>
                                <FloatInput
                                    placeholder={"Mật khẩu mới"}
                                    autoCorrect={false}
                                    style={styles.floatInput}
                                    onChangeTextValue={(text) => {this._onVerifyPasswordChange(text)}}
                                    value={this.state.newPassword}
                                    autoCapitalize='none'
                                    secureTextEntry={true}
                                />
                            </View>
                            <View style={styles.viewTwoButton}>
                                <TouchableOpacity style={styles.viewCreateButton}
                                                  onPress={() => this._onThucHienResetPasswordPress()}>
                                    <Text style={styles.textFbStart}>THỰC HIỆN</Text>
                                </TouchableOpacity>
                            </View>
                            <Toast
                                ref="toastPass"
                                position='top'
                                positionValue={height/3}
                                fadeInDuration={850}
                                fadeOutDuration={1400}
                                opacity={0.56}
                                textStyle={{color:'#fff'}}
                            />
                        </View>
                    </KeyboardAwareScrollView>
                </View>
            </View>
        );
    }


    _onVerifyCodeChange(value) {

        log.info('=================> _onVerifyCodeChange', value);
        this.setState({
            verifyCode: value.replace(" ","")
        })
    }

    _onVerifyPasswordChange(value) {
        this.setState({
            newPassword: value.replace(" ","")
        })
    }

    _onThucHienResetPasswordPress(){
        let { verifyCode, newPassword } = this.state;

        log.info("===========._onThucHienResetPasswordPress value", this.state);
        let validate = this._validateData();

        if (!validate)
            return;

        this.props.actions.updatePassword(this.state.username, this.state.verifyCode, this.state.newPassword)
            .then((e) => {
                if (e.success){
                    Alert.alert('Thông báo', 'Đổi mật khẩu thành công');
                    Actions.Home({type: 'reset'});
                    Actions.NewLogin();
                } else {
                    let msg = e.msg || "Thay đổi mật khẩu không thành công";
                    this.refs.toastPass.show(msg,DURATION.LENGTH_LONG);
                }
            });
    }

    _validateData(){

        if (!this.state.username || this.state.username.length <=0 ){
            this.refs.toastPass.show("Tên đăng nhập sai định dạng",DURATION.LENGTH_LONG);
            return false;
        }

        if (!this.state.verifyCode || this.state.verifyCode.length<=0){
            this.refs.toastPass.show("Mã xác nhận sai định dạng",DURATION.LENGTH_LONG);
            return false;
        }

        if (!this.state.newPassword || this.state.newPassword.length<=0){
            this.refs.toastPass.show("Bạn chưa nhập mật khẩu",DURATION.LENGTH_LONG);
            return false;
        }

        return true;
    }

    _renderLoadingView() {
        if (this.props.auth.isLoggingIn || this.props.register.loggingByFB) {
            return (<View style={styles.resultContainer}>
                <GiftedSpinner size='large' color="grey" />
            </View>)
        }
    }

    validate(){
        let username = this.state.username;

        if (!username || username.length <= 0)
            return false;

        if (username.indexOf("@")>=0){
            return utils.validateEmail(username);
        }

        return utils.validatePhone(username);
    }

    _onPressBack() {
        Actions.pop();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    scrollView: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 48
    },
    viewBackButton: {
        width: width,
        height: 60,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        paddingLeft: 16
    },
    viewEmail: {
        width: width,
        height: 48,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        marginTop: 41 + 48
    },
    lineDangNhap: {
        backgroundColor: '#dcdcdc',
        marginTop: 18,
        height: 1,
        width: width,
        opacity: 0.8
    },
    floatInput: {
        fontFamily: gui.fontFamily,
        fontSize: 15,
        backgroundColor:'rgba(82,97,115,1)',
        width: width - 32,
        height: 48
    },
    textFbStart: {
        fontFamily: gui.fontFamily,
        color: '#fff',
        fontSize: 15,
        fontWeight: 'normal'
    },
    viewTwoButton: {
        justifyContent: 'center',
        alignItems: 'center',
        width: width,
        height: 48,
        marginTop: 32
    },
    viewCreateButton: {
        width: width - 32,
        height: 48,
        marginTop: 16,
        backgroundColor: gui.mainColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 24
    },
    resultContainer: {
        position: 'absolute',
        // top: height/2,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'
    },
    modalContainer: {
        backgroundColor:'transparent',
        flex:1,
        alignItems:'center'
    },
    toolbarModalSend :{
        height: 64,
        flexDirection:'row',
        backgroundColor:gui.mainColor,
        borderBottomWidth:1,
        borderColor:'#e8e9e9'
    },
    modalBack: {
        width: 40,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:15
    },
    modalViewTitle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:15
    },
    modalTextTile: {
        fontSize: 20,
        color: 'white'
    },
    modalTextCan: {
        width: 40
    },
    modalBody: {
        flex:1,
        alignItems:'center'
    },
    viewCapNhat: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:46
    },

    textXacNhan: {
        fontSize:19,
        color:'black',
        fontFamily: gui.fontFamily
    },
    modalmore: {
        position:'absolute',
        backgroundColor: 'white',
        width: width,
        height: height
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(UpdatePassword);