import React, {Component} from 'react';

import * as Animatable from 'react-native-animatable';

import gui from '../../lib/gui';

var {
    StyleSheet,
    View,
    Text,
    StatusBar
} = require('react-native');

import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();

class MMessage extends React.Component{
    constructor(props){
        super(props);
    }

    render() {
        var {hideStatus, barStyle, animation, duration, onAnimationEnd, onAnimationBegin, textValue, textValue2, mainStyle,
            bgColor, textColor} = this.props;
        return (
        <View style={[styles.container, mainStyle]}
              pointerEvents="none"
        >
            <StatusBar barStyle={barStyle} hidden={hideStatus} />
            <Animatable.View animation={animation}
                             duration={duration}
                             onAnimationEnd={onAnimationEnd}
                             onAnimationBegin={onAnimationBegin}
            >
                <View style={[styles.textView, {backgroundColor: bgColor||'#166CA5'}]}>
                    <Text style={[styles.textLabel, {color: textColor||'white'}]}>  {textValue} </Text>
                    {textValue2 && textValue2 != '' ? <Text style={[styles.textLabel, {color: textColor||'white'}]}>  {textValue2} </Text> : null}
                </View>
            </Animatable.View>
        </View>);
    }
}

var styles = StyleSheet.create({
    container: {
        position: 'absolute',
        top: 0,
        width: width,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        marginVertical: 0,
        marginBottom: 0,
        backgroundColor: 'transparent'
    },
    textView: {
        width: width,
        alignItems: 'center',
        justifyContent: 'flex-start',
        // backgroundColor: '#262626',
        backgroundColor: '#166CA5',
        paddingBottom: 2,
        // opacity: 0.85
    },
    textLabel: {
        color: 'white',
        fontSize: gui.capitalizeFontSize,
        fontFamily: gui.fontFamily,
        backgroundColor: 'transparent',
        fontWeight : '600',
        textAlign: 'center'
    }
});

module.exports = MMessage;
