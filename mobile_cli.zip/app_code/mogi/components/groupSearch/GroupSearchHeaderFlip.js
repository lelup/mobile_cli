// Import some code we need
import React, {Component} from 'react';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';

import gui from '../../lib/gui';

import PropTypes from 'prop-types';

import SearchInputExt from './GroupSearchInputExt2';

// Create our component
class GroupSearchHeaderFlip extends Component {

    constructor(props) {
        super(props)
    }

   static propTypes = {
        autoFocus: PropTypes.bool,
        onChangeText: PropTypes.func,
        textValue: PropTypes.string,
        placeholder: PropTypes.string,
        onFocus: PropTypes.func,
        showCloseButton: PropTypes.bool
    };
   static defaultProps = {
            autoFocus: false,
            onChangeText: () => {},
            textValue: '',
            placeholder: '',
            onFocus: () => {},
            showCloseButton: false
        } ;

  render () {
    return <View style={mStyles.container}>
      <View style={mStyles.home}>
          <TouchableOpacity style={mStyles.viewBackButton}
                            onPress={this._onSearch.bind(this)}>
              <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainColor} />
          </TouchableOpacity>
      </View>
      <View style={mStyles.text}>
        <SearchInputExt    ref="searchInputExt"
                           placeName={this.props.placeName} refreshRegion={this.props.refreshRegion}
                           onShowMessage={this.props.onShowMessage} isHeaderLoading={this.props.isHeaderLoading}
                           loadHomeData={this.props.loadHomeData} owner={this.props.owner}
                           resetAllMarkers={this.props.resetAllMarkers}
                           onChangePositionSearch={this.props.onChangePositionSearch}
                           onSuggestPress={this.props.onSuggestPress}
                           onSelectPress={this.props.onSelectPress}
                           activeView={this.props.activeView}
                           autoFocus={this.props.autoFocus}
                           onChangeText={this.props.onChangeText}
                           textValue={this.props.textValue}
                           placeholder={this.props.placeholder}
                           onFocus={this.props.onFocus}
                           showCloseButton={this.props.showCloseButton}
                           disabled={this.props.disabled} />
      </View>
    </View>
  }
  focusInputSearch() {
      this.refs.searchInputExt.focusInputSearch();
  }

  _onSearch (){
    if (this.props.activeView == 'SearchResult') {
        // Actions.Search2({needBack:true, onShowMessage: this.props.onShowMessage, refreshRegion: this.props.refreshRegion,
        //     owner: this.props.owner, resetAllMarkers: this.props.resetAllMarkers, 
        //     deviceID: this.props.deviceID, userID: this.props.userID});
        this.props.onSearchFilterPress && this.props.onSearchFilterPress();
    } else {
        this.props.onCancelPress && this.props.onCancelPress();
    }
  }
}

// Make this code available elsewhere
export default GroupSearchHeaderFlip;

const mStyles = StyleSheet.create({
  container: {
      top: 0,
      flexDirection: 'row',
      alignItems: 'stretch',
      justifyContent: 'space-between',
      //backgroundColor: gui.mainColor,
      backgroundColor: 'transparent',
      height: 64
  },
  search: {
      marginTop: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent',
      //backgroundColor: gui.mainColor
  },
  home: {
      marginTop: 15,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'transparent',
      //backgroundColor: gui.mainColor
  },
  text: {
    backgroundColor: 'transparent',
    position: 'absolute',
    left:56,
    right: 6
  },
  titleText: {
      backgroundColor: 'transparent',
      color: 'white',
      fontFamily: gui.fontFamily,
      fontSize: 17,
      fontWeight: '600'
  },
  viewBackButton: {
      width: 56,
      height: 30,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#fff'
  }
});
