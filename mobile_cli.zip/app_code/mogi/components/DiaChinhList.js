'use strict';

import React, {Component} from 'react';

import {View, Text, StyleSheet, TouchableOpacity, ListView, StatusBar} from 'react-native'

import {Actions} from 'react-native-router-flux';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import MultipleChoice from './MultipleChoice';

import SearchInput from '../components/group/SearchInputAgent';

import dismissKeyboard from 'react-native-dismiss-keyboard';
import KeyboardSpacer from 'react-native-keyboard-spacer';

import Button from 'react-native-button';

import danhMuc from '../assets/DanhMuc';

import gui from '../lib/gui';
import utils from '../lib/utils';

var {width} = utils.getDimensions();

class DiaChinhList extends Component {
    _results = [];

    constructor(props) {
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: function rowHasChanged(r1, r2) {
                if (typeof r1.isLoading !== 'undefined') {
                    return true;
                }
                return r1 !== r2;
            }
        });

        var {diaChinhList, selectedDiaChinh} = props;

        // var diaChinhOption = [];

        // if (diaChinhList) {
        //     for (var i = 0; i < diaChinhList.length; i++) {
        //         diaChinhOption.push(diaChinhList[i].placeName);
        //     }
        //     // diaChinhOption = diaChinhOption.sort();
        // }

        var diaChinh = selectedDiaChinh ? selectedDiaChinh.placeName : '';

        this.state = {
            dataSource: ds.cloneWithRows(this.buildRowsFromResults(diaChinhList || [])),
            diaChinhList: diaChinhList,
            diaChinh: diaChinh,
            text: '',
            focused: false,
            mounted: false,
            toggleKeyboard: false
        };
    }

    buildRowsFromResults(results) {
        let data = [];
        let uuid = new Date().getTime();
        results.forEach((one) => {
            let row = {...one};
            row.key = row.id + '_' + uuid;
            data.push(row);
        });
        return data;
    }

    componentWillMount() {
        setTimeout(() => this.focusInputSearch(), 300);
    }

    componentDidMount() {
        this.setState({mounted: true});
    }

    componentWillUnmount() {
        this.setState({mounted: false});
    }

    render() {
        let header = this.getHeader();
        let message = this.props.message ? this.props.message : 'Bạn cần chọn Địa điểm/Dự án trước khi chọn đường';
        let placeholder = 'Nhập tên ' + header.toLowerCase();
        let showSearchInput = this.props.diaChinhList && this.props.diaChinhList.length>0;
        return (
            <View style={myStyles.fullWidthContainer}>
                {/*<CommonHeader headerTitle={header} />*/}
                <View style={myStyles.pageHeader}>
                    <TouchableOpacity style={myStyles.backButton}
                                      onPress={this._onBackPress.bind(this)}
                    >
                        <MaterialCommunityIcons name="arrow-left" size={24} color={gui.mainTextColor} />
                    </TouchableOpacity>
                    <View style={myStyles.pageHeaderWrapper}>
                        <SearchInput ref="searchInput"
                                     placeholder={placeholder} textValue={this.state.text}
                                     loadSearchFilter={() => {}}
                                     onSuggestPress={() => {}}
                                     onChangeText={this._onChangeText.bind(this)}
                                     onFocus={this._onFocus.bind(this)}
                                     showCloseButton={this.state.focused && this.state.text != ''}
                                     editable={showSearchInput}
                                     disabled={!showSearchInput}
                        />
                    </View>
                </View>
                <View style={{flex: 1, marginTop: 64}}>
                    <View style={myStyles.headerSeparator} />
                    {showSearchInput ?
                        this._renderDiaChinhList() :
                        (<View style = {{alignItems: 'center', paddingTop: 15, width: width}}>
                                <Text style={[myStyles.label, {color: gui.mainColor}]}>
                                    {message}
                                </Text>
                         </View>
                        )
                    }
                </View>

            </View>
        );
    }

    _renderDiaChinhList() {
        // return (
        //     <MultipleChoice
        //         options={this.state.diaChinhOption}
        //         style={myStyles.choiceList}
        //         selectedOptions={[this.state.diaChinh]}
        //         maxSelectedOptions={1}
        //         onSelection={(option)=>this._onApply(option)}
        //     />
        // );
        return (
            <View style={[myStyles.mainView, {top: 1}]}>
                {this._renderListResult()}
                {this.state.toggleKeyboard ? <Button onPress={() => dismissKeyboard()}
                                                     style={{ paddingRight: 17, fontFamily: gui.fontFamily, fontWeight : 'normal', textAlign: 'right',
                                                         color: gui.mainColor, backgroundColor: '#f0f1f3', height: 40, paddingTop: 8 }}>Xong</Button> : null}

                <KeyboardSpacer topSpacing={0} onToggle={(toggleKeyboard) => this.onKeyboardToggle.bind(this, toggleKeyboard)}/>

            </View>
        )
    }

    _renderListResult() {
        return (
            <View style={myStyles.listResultView}>
                <ListView style={myStyles.placeListView}
                          keyboardShouldPersistTaps="always"
                          keyboardDismissMode="on-drag"
                          ref={(listView) => { this._listView = listView; }}
                          dataSource={this.state.dataSource}
                          renderRow={(rowData, sectionID, rowID) => this._renderRow(rowData, sectionID, rowID, (rowID == 0))}
                          stickyHeaderIndices={[]}
                          enableEmptySections={true} />
            </View>
        );
    }

    _renderRow(rowData = {}, sectionID, rowID, isFirstRow) {
        return (
            <TouchableOpacity onPress={this._onSelectedPlacePress.bind(this, rowData)}>
                <View style={myStyles.placeResultView}>
                    <View style={myStyles.placeSubView}>
                        <Text style={myStyles.placeNameText} numberOfLines={1}>{rowData.placeName}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    _onSelectedPlacePress(rowData) {
        this.props.onApply(rowData);
        StatusBar.setBarStyle('default');
        Actions.pop();
    }

    onKeyboardToggle(toggleKeyboard) {
        this.setState({ toggleKeyboard: toggleKeyboard });
    }

    focusInputSearch() {
        let showSearchInput = this.props.diaChinhList && this.props.diaChinhList.length>0;
        if (showSearchInput) {
            this.refs.searchInput && this.refs.searchInput.focusInputSearch();
        }
    }

    _onChangeText(text) {
        this.currentText = text;

        let pre = text;
        setTimeout(() => {
            if (pre == this.currentText) {
                this._request(pre);
            }
        }, 100);

        this.setState({
            text: text
        });
    }

    _onFocus() {
        this.setState({focused: true});
    }

    _request(text) {
        if (text.length >= 1) {
            let textKhongDau = utils.locDauV2(text);
            let allToken = textKhongDau.split(' ');
            let diaChinhList = [];
            let allDiaChinh = this.props.diaChinhList || [];
            allDiaChinh.forEach((diaChinh) => {
                let diaChinhKhongDau = '';
                let placeType = diaChinh.placeType;
                if (placeType == 'T') {
                    diaChinhKhongDau = diaChinh.tinhKhongDau;
                }
                if (placeType == 'H') {
                    diaChinhKhongDau = diaChinh.huyenKhongDau;
                }
                if (placeType == 'X') {
                    diaChinhKhongDau = diaChinh.xaKhongDau;
                }
                if (placeType == 'D') {
                    diaChinhKhongDau = diaChinh.duongKhongDau;
                }
                if (placeType == 'A') {
                    diaChinhKhongDau = diaChinh.duAnKhongDau;
                }
                let diaChinhTokens = diaChinhKhongDau.split('-');

                let matched = undefined;
                let matchedHash = {};
                allToken.forEach((token) => {
                    let found = diaChinhTokens.find((diaChinhToken) => {
                        return diaChinhToken == token;
                    });
                    if (found) {
                        matchedHash[token] = true;
                        if (matched === undefined) {
                            matched = true;
                        }
                    }
                    else {
                        matched = false;
                    }
                });
                if (matched) {
                    diaChinhList.push(diaChinh);
                } else if (Object.keys(matchedHash).length == (allToken.length-1) && !matchedHash[allToken[allToken.length-1]]) {
                    let item = allToken[allToken.length-1];
                    let found = diaChinhTokens.length >= allToken.length && diaChinhTokens[allToken.length-1].indexOf(item) == 0;
                    if (found) {
                        diaChinhList.push(diaChinh);
                    }
                }
            });
            this.setState({
                dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(diaChinhList)),
                diaChinhList: diaChinhList
            });
        } else {
            this._results = [];
            this.setState({
                dataSource: this.state.dataSource.cloneWithRows(this.buildRowsFromResults(this.props.diaChinhList || [])),
                diaChinhList: this.props.diaChinhList || []
            });
        }
    }

    getHeader() {
        if (danhMuc.placeType.DU_AN == this.props.placeType)
            return "Dự Án";

        if (danhMuc.placeType.DUONG == this.props.placeType)
            return "Đường";

        return "Địa chính";
    }

    _onApply(option) {
        let diaChinhList = this.props.diaChinhList || [];
        for (let i=0; i< diaChinhList.length; i++){
            if (option == diaChinhList[i].placeName){
                this.props.onApply(diaChinhList[i]);
                break;
            }
        }
        StatusBar.setBarStyle('default');
        Actions.pop();
    }

    _onBackPress() {
        StatusBar.setBarStyle('default');
        Actions.pop();
    }
}

export default DiaChinhList;

// Later on in your styles..
var myStyles = StyleSheet.create({
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white'
    },
    choiceList: {
        paddingTop: 10,
        paddingLeft: 26,
        paddingRight: 0
    },
    searchButton: {
        alignItems: 'stretch',
        justifyContent: 'flex-end'
    },
    searchButtonWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 44
    },
    searchButtonText: {
        marginLeft: 17,
        marginRight: 17,
        marginTop: 10,
        marginBottom: 10,
        color: 'white',
        fontSize: gui.buttonFontSize,
        fontFamily: gui.fontFamily,
        fontWeight : 'normal'
    },
    headerSeparator: {
        // marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    pageHeader: {
        top: 0,
        position: 'absolute',
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: '#fff',
        width: width,
        height: 64
    },
    pageHeaderWrapper: {
        position: 'absolute',
        left: 50,
        right: 6,
        top: 0,
        height: 64
    },
    backButton: {
        height: 64,
        width: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: gui.marginTopAgent
    },
    mainView: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: '#F2F2F2',
        borderTopWidth: 1,
        borderTopColor: 'rgba(82,97,115,0.1)'
    },
    listResultView: {
        flex: 1,
        marginLeft: 16,
        marginRight: 16,
        marginBottom: 10
    },
    placeListView: {
        flex: 1
    },
    placeResultView: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(82,97,115,0.1)',
        marginTop: 8
    },
    placeSubView: {
        flex: 1,
        marginLeft: 12,
        marginTop: 4,
        marginBottom: 4
    },
    placeNameText: {
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight : '500',
        color: '#526173',
        textAlign: 'left'
    }
});

