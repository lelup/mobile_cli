'use strict';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';

import {Map} from 'immutable';

import React, {Component} from 'react';

import { Text, View, StyleSheet, Navigator, TouchableOpacity, StatusBar, Linking, TouchableHighlight } from 'react-native'
import {Actions} from 'react-native-router-flux';
import MapView from 'react-native-maps';

import CommonHeader from '../CommonHeader';

import LocationMarker from '../marker/LocationMarker';

import gui from '../../lib/gui';

import log from '../../lib/logUtil';

import TruliaIcon from '../TruliaIcon';

const {
    MAP_STATE_LOADING,
} = require('../../lib/constants').default;

import utils from '../../lib/utils';
const { width, height } = utils.getDimensions();

const ASPECT_RATIO = width / (height-110);

/**
 * ## Redux boilerplate
 */
const actions = [
    globalActions,
    searchActions
];

function mapStateToProps(state) {


    //var listAds = state.search.result.listAds;

    //var viewport = state.search.result.viewport;
    //console.log(viewport);
    //var geoBox = [viewport.southwest.lon, viewport.southwest.lat,
    //  viewport.northeast.lon, viewport.northeast.lat];

    //var region = apiUtils.getRegion(geoBox);
    //region.longitudeDelta = region.latitudeDelta * ASPECT_RATIO;

    return {
        ... state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

class SearchMapDuAn extends Component {

    constructor(props) {
        super(props);
        StatusBar.setBarStyle('default');

        this.state = {
            mapType: "standard",
            mmarker:{},
            region: props.region,
            mapName: "Satellite",
            showCallout: false
        }
    }

    render() {

        // var region = this.props.region;
        // region.longitudeDelta = region.latitudeDelta * ASPECT_RATIO;

        let ads = this.props.ads;

        let marker = {};

        if (ads && ads.place.geo.lat && ads.place.geo.lon) {
            let uuid = new Date().getTime();
            marker = {
                coordinate: {latitude: ads.place.geo.lat, longitude: ads.place.geo.lon},
                price: ads.giaFmt ?  ads.giaFmt : '',
                id: uuid,
                cover: ads.coverImage,
                diaChi: ads.place.diaChi,
                dienTich: ads.tongDienTich ? ads.tongDienTich : ''
            };
        }

        return (
            <View style={styles.fullWidthContainer}>

                <View style={styles.search}>
                    <CommonHeader backTitle={"Trở lại"} />
                    <View style={styles.headerSeparator} />
                </View>

                <View style={styles.map}>
                    <MapView
                        region={this.state.region}
                        style={styles.mapView}
                        mapType={this.state.mapType}
                        rotateEnabled={false}
                    >
                        {/*markerList.map( marker =>(
                         <MapView.Marker key={marker.id} coordinate={marker.coordinate} calloutOffset={{x: 0, y: 10}}
                         ref={(marker) => this._marker = marker}
                         onPress={() => this._onMMarkerPress()}
                         >
                         <LocationMarker/>
                         <MapView.Callout tooltip height={58} onPress={()=>this._onMapGetCurrentLocation(marker)}
                         style={{position: 'relative', alignItems: 'center', justifyContent: 'center'}}>
                         <DirectionMarker fontSize={17} diaChi={marker.diaChi} onPress={()=>this._onMapGetCurrentLocation(marker)}/>
                         </MapView.Callout>
                         </MapView.Marker>
                         ))*/}

                        <MapView.Marker
                            // key={marker.id}
                            coordinate={marker.coordinate}
                            ref={(marker) => this._marker = marker}
                            pointerEvents="none"
                        >
                            <LocationMarker/>
                        </MapView.Marker>
                    </MapView>
                    <View style={styles.mapButtonContainer}>
                        <TouchableOpacity onPress={this._onChangeMapPress.bind(this)} style={[styles.bubble, styles.button]}>
                            <Text style={styles.mapIcon}>{this.state.mapName}</Text>
                        </TouchableOpacity>
                    </View>
                    {this._renderDirectionView(marker)}
                </View>
            </View>
        )
    }

    _renderDirectionView(marker) {
        const diaChi = marker.diaChi;
        return(
            <View style={styles.directionContainer} >
                <TouchableHighlight underlayColor='transparent' style={[styles.directionTouchable]} onPress={()=>this._onMapGetCurrentLocation(marker)}>
                    <View style={styles.directionTextSubview}>
                        <View style={{flexDirection: 'column', width: width-160}}>
                            <Text style={[styles.diaChi, { fontSize: 17 }]} numberOfLines={1}>{diaChi} </Text>
                        </View>
                        <View style={{margin: 0}}>
                            <TruliaIcon name={"car"} size={24} color={"white"} mainProps={styles.carIcon}/>
                        </View>
                    </View>
                </TouchableHighlight>
            </View>
        );
    }

    // _onCloseModal() {
    //     this.setState({showCallout: false});
    // }
    //
    // _onMMarkerPress() {
    //     // this.state.showCallout = !this.state.showCallout;
    //     // if (this.state.showCallout) {
    //     //   this._marker.showCallout();
    //     // } else {
    //     //   this._marker.hideCallout();
    //     // }
    // }

    _onChangeMapPress() {
        const {mapName} = this.state;
        this.setState({
            mapType: "Satellite" == mapName ? "satellite" : "standard",
            mapName: "Satellite" == mapName ? "Standard" : "Satellite"
        });
    }

    // _onSatellitePress(){
    //     this.setState({
    //         mapType: "satellite"
    //     });
    // }
    //
    // _onHybridPress(){
    //     this.setState({
    //         mapType: "hybrid"
    //     });
    // }
    //
    // _onStandardPress(){
    //     this.setState({
    //         mapType: "standard"
    //     });
    // }

    _onMapGetCurrentLocation(marker) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                this._onMarkerPress(marker, position.coords);
            },
            (error) => {
                this._onMarkerPress(marker, {});
            },
            {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000}
        );
    }

    _onMarkerPress(marker, coords) {
        if (coords && !isNaN(coords.latitude) && !isNaN(coords.longitude)) {
            let geoUrl = 'http://maps.apple.com/?saddr='+coords.latitude+','+coords.longitude+'&daddr='+marker.coordinate.latitude+','+marker.coordinate.longitude+'&dirflg=d&t=s';
            this._onDanDuong(geoUrl);
        } else {
            let geoUrl = 'http://maps.apple.com/?daddr='+marker.coordinate.latitude+','+marker.coordinate.longitude+'&dirflg=d&t=s';
            this._onDanDuong(geoUrl);
        }
    }

    _onDanDuong(geoUrl) {
        Linking.canOpenURL(geoUrl).then(supported => {
            if (supported) {
                Linking.openURL(geoUrl);
            } else {
                log.info('Don\'t know how to open URI: ' + geoUrl);
            }
        });
    }

    _onListPressed() {
        Actions.pop();
    }

}

// Later on in your styles..
const styles = StyleSheet.create({
    headerSeparator: {
        // marginTop: 2,
        borderTopWidth: 1,
        borderTopColor: gui.separatorLine
    },
    fullWidthContainer: {
        flex: 1,
        alignItems: 'stretch',
        backgroundColor: 'white',
    },
    container: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    searchListButtonText: {
        marginLeft: 15,
        marginRight: 15,
        marginTop: 0,
        marginBottom: 0,
        flexDirection: 'column',
    },

    map: {
        flex: 1,
        marginTop: 0,
        marginBottom: 0
    },
    mapView: {
        flex: 1,
        marginTop: 0,
        marginBottom: 0
    },
    title: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
        backgroundColor: 'white'
    },
    search: {
        top:0,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    bubble: {
        backgroundColor: gui.mainColor,
        paddingHorizontal: 5,
        paddingVertical: 5,
        borderRadius: 3
    },
    button: {
        width: 85,
        paddingTop: 8,
        paddingBottom: 8,
        alignItems: 'center',
        backgroundColor: gui.mainColor,
        marginLeft: 15,
        left: width - 110
    },
    mapIcon: {
        color: 'white',
        textAlign: 'center'
    },
    text: {
        color: 'white'
    },
    mapButtonContainer: {
        position: 'absolute',
        top: height-105,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },

    tabbar: {
        position: 'absolute',
        top: height-50,
        left: 0,
        right: 0,
        bottom: 0,
        borderTopWidth: 1,
        borderColor : 'lightgray'
    },
    searchListButton: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        backgroundColor: 'white',
    },
    sumBds: {
        marginBottom: 10,
        paddingLeft: 20,
        color: 'white',
    },
    directionContainer: {
        position: 'absolute',
        top: height-105,
        left: 10,
        flexDirection: 'column',
        alignSelf: 'flex-start'
    },
    directionTouchable: {
        overflow: 'hidden'
    },
    directionTextSubview: {
        flex: 0,
        flexDirection: 'row',
        alignSelf: 'flex-start',
        alignItems: 'center',
        backgroundColor: 'white',
        padding: 0,
        borderRadius: 3,
        borderColor: 'lightgray',
        borderWidth: 0.5
    },
    diaChi: {
        color: gui.mainColor,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal',
        fontSize: 15,
        marginLeft: 15,
        marginRight: 10
    },
    carIcon: {
        paddingRight: 10,
        paddingLeft: 10,
        paddingTop: 3,
        paddingBottom: 3,
        borderTopRightRadius: 3,
        borderBottomRightRadius: 3,
        backgroundColor: gui.mainColor
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(SearchMapDuAn);