'use strict';
import  React, {Component} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ListView,
    Linking, TouchableHighlight, ImageBackground} from 'react-native';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as globalActions from '../../reducers/global/globalActions';
import * as searchActions from '../../reducers/search/searchActions';
import * as historyActions from '../../reducers/history/historyActions';

import {Map} from 'immutable';

import FullLine from '../line/FullLine';
import TruliaIcon from '../TruliaIcon';
import gui from "../../lib/gui";
import util from "../../lib/utils";
import CommonUtils from '../../lib/CommonUtils';
import FindApi from "../../lib/FindApi";
import MHeartIcon from '../MHeartIcon';
import DanhMuc from '../../assets/DanhMuc';
import MMessage from '../message/MMessage';

import ImagePreview from '../ImagePreviewChat';

import ScalableText from 'react-native-text'

import {Actions} from 'react-native-router-flux';

import GiftedSpinner from 'react-native-gifted-spinner';

import LinearGradient from 'react-native-linear-gradient';

import MapView from 'react-native-maps';

import LocationMarker from '../marker/LocationMarker';

const {width, height} = util.getDimensions();
const mapWidth = width-30;
const mapHeight = (width-width%2)/2+3;

let imageUriNoCover = require('../../assets/image/default_cover/no_cover_03.jpg');

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

const actions = [
    globalActions,
    searchActions,
    historyActions
];

const ds_nhaThue = new ListView.DataSource({rowHasChanged: (r1,r2) => r1!== r2});
const ds_nhaBan = new ListView.DataSource({rowHasChanged: (r1,r2) => r1!== r2});

class DetailDuAn extends React.Component {
    constructor(props) {
        super(props);
        // let dataNhaThuocDuAn = [
        //     {'diaChi': 'Phường Kim Giang, Thanh Xuân, Hà Nội', 'dienTich': '80m²', 'soPhongNgu' : '3p.ngủ', 'soTang' : '3', 'giaFmt' : '1.49 tỷ' , 'uri': 'https://img.landber.com/01/0/20170513142601-e3a6_wm.jpg'},
        //     {'diaChi': 'Phường Nhân Chính, Thanh Xuân, Hà Nội', 'dienTich': '102m²', 'soPhongNgu' : '2p.ngủ', 'soTang' : '2', 'giaFmt' : '2 tỷ' , 'uri': 'https://img.landber.com/01/0/20170522101615-ba98_wm.jpg'},
        //     {'diaChi': 'Phường Thanh Xuân Nam, Thanh Xuân, Hà Nội', 'dienTich': '96.2m²', 'soPhongNgu' : '4p.ngủ', 'soTang' : '2', 'giaFmt' : '5.5 tỷ' , 'uri': 'https://landber.com/images/no-image05.jpg'},
        //     {'diaChi': 'Phường Thanh Xuân Trung, Thanh Xuân, Hà Nội', 'dienTich': '150m²', 'soPhongNgu' : '2p.ngủ', 'soTang' : '5', 'giaFmt' : '8.1 tỷ' , 'uri': 'https://img.landber.com/01/0/20170513162159-7c35_wm.jpg'},
        //     {'diaChi': 'Phường Kim Giang, Thanh Xuân, Hà Nội', 'dienTich': '128m²', 'soPhongNgu' : '2p.ngủ', 'soTang' : '3', 'giaFmt' : '3.22 tỷ' , 'uri': 'https://img.landber.com/01/0/20170513154314-0661_wm.jpg'},
        // ];
        this.state = {
            data: null,
            modal: false,
            dataNhaThueThuocDuAn: [],
            dataNhaBanThuocDuAn: [],
            firstTime: true,
            likeAdsMessage: '',
            msgType: '',
        };
    }

    componentWillMount() {
        setTimeout(() => this.fetchData(), 300);
    }

    fetchData() {
        FindApi.getDetailDuAn({"duAnID": this.props.duAnID})
            .then((data) => {
                if (!data.errMsg) {
                    this.setState({
                        data: data
                    });
                }
                this.getNhaBanCungDuAn(data);
                setTimeout(() =>  {this.getNhaThueCungDuAn(data)}, 300);

            });
    }

    getNhaBanCungDuAn(data) {
        this.setState({
            dataNhaBanThuocDuAn: []
        });
        let newLimit = this.props.global.setting.maxAdsInMapView;
        let searchBanNhaCungDuAn = {
            loaiTin: 0,
            diaChinh: {
                duAnKhongDau: data.duAn.codeDuAn,
                tinhKhongDau: data.duAn.place.diaChinh.codeTinh,
                huyenKhongDau: data.duAn.place.diaChinh.codeHuyen,
                fullName: data.duAn.codeDuAn + ", " + data.duAn.place.diaChinh.huyen + ", " + data.duAn.place.diaChinh.tinh
            },
            limit : newLimit,
            pageNo : 1,
            isIncludeCountInResponse : false,
            updateLastSearch: false,
            orderBy : {"name": "ngayDangTin", "type":"DESC"}
        };

        FindApi.getItems(searchBanNhaCungDuAn)
            .then((data) => {
                if (!data.errMsg && data.list) {
                    let nhaBanDuAn = data.list;
                    this.setState({
                        dataNhaBanThuocDuAn: nhaBanDuAn
                    });
                }
            });
    }

    getNhaThueCungDuAn(data) {
        this.setState({
            dataNhaThueThuocDuAn: []
        });
        let newLimit = this.props.global.setting.maxAdsInMapView;
        let searchThueNhaCungDuAn = {
            loaiTin: 1,
            diaChinh: {
                duAnKhongDau: data.duAn.codeDuAn,
                tinhKhongDau: data.duAn.place.diaChinh.codeTinh,
                huyenKhongDau: data.duAn.place.diaChinh.codeHuyen,
                fullName: data.duAn.codeDuAn + ", " + data.duAn.place.diaChinh.huyen + ", " + data.duAn.place.diaChinh.tinh
            },
            limit : newLimit,
            pageNo : 1,
            isIncludeCountInResponse : false,
            updateLastSearch: false,
            orderBy : {"name": "ngayDangTin", "type":"DESC"}
        };

        FindApi.getItems(searchThueNhaCungDuAn)
            .then((data) => {
                if (!data.errMsg && data.list) {
                    let nhaThueDuAn = data.list;
                    this.setState({
                        dataNhaThueThuocDuAn: nhaThueDuAn
                    });
                }
            });
    }

    _renderHeaderAds() {
        let data = this.state.data;
        let duAn = data && data.duAn;
        let tenDuAn = duAn && duAn.tenDuAn ? duAn.tenDuAn : ' ' ;
        return (
            <View style={styles.pageHeader}>
                <TouchableOpacity
                    onPress={() => this._onBackPress()}
                    style={styles.searchButton}
                    activeOpacity={0}
                    disabled={this.state.loading}
                >
                    <TruliaIcon name="arrow-left" color="white" size={26}
                                mainProps={{paddingLeft: 0, paddingRight: 0}}
                                noAction={true}
                    >
                    </TruliaIcon>
                </TouchableOpacity>
                <View style={styles.viewEditHome}>
                    <ScalableText style={[styles.textEdit, {fontWeight: '500', fontSize: 15}]}>
                        {tenDuAn}
                    </ScalableText>
                </View>
                <View
                    style={styles.viewEdit}>
                </View>
            </View>
        );
    }

    _onBackPress() {
        Actions.pop();
    }

    _renderImagePreviewModal() {
        let imageDataItems = [];
        let data = this.state.data;
        if(data) {
            let duAn = data.duAn;
            imageDataItems.push(duAn.coverImage);
        }
        return (
            <ImagePreview images={imageDataItems}
                          closeModal={() => this.setState({modal: false}) }
            />
        );
    }

    _onImagePreviewPressed() {
        let rowData =  this.state.data;
        if(!rowData) {
            return;
        }
        if (this.state.modal) {
            return;
        }
        this.setState({
            modal: true
        });
    }

    render() {
        if(!this.state.data){
            return (
                <View style={styles.viewLoaderAds}>
                    <View style={styles.headerNoData}/>
                    <Image style={styles.viewChildRow}
                           source={imageUriNoCover} defaultSource={CommonUtils.getNoCoverImage()}
                    >
                    </Image>
                    <View style={[styles.viewTextContent, {marginLeft: 17}]}>
                        <View style={styles.viewLineLoader}></View>
                        <View style={styles.viewLineLoader1}></View>
                        <View style={[styles.lineNoData, {marginTop: 20}]}>
                            <View style={[styles.viewLineLoader1, {width: 90}]}></View>
                            <View style={[styles.viewLineLoader1, {width: 160, marginLeft: 50}]}></View>
                        </View>
                        <View style={[styles.lineNoData, {marginTop: 12}]}>
                            <View style={[styles.viewLineLoader1, {width: 90}]}></View>
                            <View style={[styles.viewLineLoader1, {width: 160, marginLeft: 50}]}></View>
                        </View>
                        <View style={[styles.lineNoData, {marginTop: 12}]}>
                            <View style={[styles.viewLineLoader1, {width: 90}]}></View>
                            <View style={[styles.viewLineLoader1, {width: 160, marginLeft: 50}]}></View>
                        </View>
                        <View style={[styles.lineNoData, {marginTop: 12}]}>
                            <View style={[styles.viewLineLoader1, {width: 90}]}></View>
                            <View style={[styles.viewLineLoader1, {width: 160, marginLeft: 50}]}></View>
                        </View>
                        <View style={[styles.viewLineLoader, {marginTop: 30}]}></View>
                        <View style={styles.viewLineLoader1}></View>
                        <View style={styles.viewLineLoader2}></View>
                    </View>
                </View>
            );
        }
        return (
            <View style={{flex: 1}}>
                {this._renderBodyBorrow()}
                {this._renderLikeAdsMessage()}
                {this._renderHeaderAds()}
                {this.state.modal ?
                    <View style={styles.previewModal}>
                        {this._renderImagePreviewModal()}
                    </View> : null
                }
            </View>
        );
    }

    _renderLoadingView() {
        return (<View style={styles.viewBody}>
                <GiftedSpinner color="white" />
            </View>
        );
    }

    _renderBodyBorrow() {
        let image = require('../../assets/image/reland_house_large.jpg');
        // let tenDuAn = 'SkyView Trần Thái Tông';
        // let diaChi = 'Số 5 -Trần Thái Tông - Cầu Giấy - Hà Nội';
        // let chuDauTu = 'Tập Đoàn SkyCorp';
        // let dienTich = '1000 000 m2';
        // let link = 'https://facebook.github.io/react-native/';
        let data = this.state.data;
        let duAn = data && data.duAn;
        if(!duAn) {
            return ;
        }
        let duAnItems = [];
        if (duAn.tenDuAn) {
            let tenDuAn = duAn.tenDuAn;
            duAnItems.push(this.renderTitleProps("Tên dự án", tenDuAn, {marginTop: 3, marginBottom: 2.2}));
        }
        if (duAn.place.diaChi) {
            let diaChi = duAn.place.diaChi;
            duAnItems.push(this.renderTitleProps("Địa chỉ", diaChi , {marginTop: 3, marginBottom: 2.2}));
        }
        if (duAn.chuDauTu) {
            let chuDauTu = duAn.chuDauTu;
            duAnItems.push(this.renderTitleProps("Chủ đầu tư", chuDauTu, {marginTop: 3, marginBottom: 2.2}));
        }
        let tongDienTich = ' ';
        if (duAn.tongDienTichFmt && duAn.tongDienTichFmt != 'Không rõ') {
            tongDienTich = ' ' + duAn.tongDienTichFmt;
            duAnItems.push(this.renderTitleProps("Tổng diện tích", tongDienTich, {marginTop: 3, marginBottom: 2.2}));
        }
        let link = duAn.url;
        if (link && !this._isBlacklistDuAnWebsite(link)) {
            duAnItems.push(this.renderTitleProps("Website", link, {marginTop: 3, marginBottom: 2.2}, () => this.onPressLink(link)));
        }
        // let mapUrl = 'http://maps.google.com/maps/api/staticmap?zoom=16&size='+mapWidth+'x'+mapHeight+'&markers=color:red|'+data.duAn.place.geo.lat+','+data.duAn.place.geo.lon+'&sensor=false';
        // let mapUrl = 'http://maps.google.com/maps/api/staticmap?zoom=16&size='+mapWidth+'x'+mapHeight+'&markers=color:red|'+21.0086565+','+105.7966651+'&sensor=false';
        let imageUriHome = {uri: duAn.coverImage};
        if (!imageUriHome) {
         imageUriHome = require('../../assets/image/photo_detail_blank.jpg');
         }
        let imagePreviewAction = this._onImagePreviewPressed.bind(this);

        let geo = data.duAn.place.geo;
        let region = {latitude: geo.lat, longitude: geo.lon, latitudeDelta: 0.021, longitudeDelta: 0.0144};

        return(
            <View style={styles.viewBody}>
                <ScrollView
                    automaticallyAdjustContentInsets={false}
                    vertical={true}
                    contentContainerStyle={[styles.scrollView]}
                >
                        <TouchableHighlight onPress={imagePreviewAction} underlayColor="transparent" >
                            <Image style={{width: width, height: height/2 - 64}}
                                   source={imageUriHome}
                                   resizeMode={'cover'}
                                   defaultSource={CommonUtils.getNoCoverImage()}
                            />
                        </TouchableHighlight>
                        <View style={styles.viewTextContent}>
                            <Text style={styles.titleTop}>Đặc Điểm</Text>
                            <Text style={styles.textFullWidth}>
                                Thông tin tổng quan về dự án
                            </Text>
                            {duAnItems}
                            <Text style={{fontSize: 5}} />
                        </View>
                        <View style={[styles.viewTextContent, {marginTop: 2}]}>
                            <Text style={styles.titleTop}>Vị Trí</Text>
                            <Text style={styles.textFullWidth}>
                                Vị trí của dự án này trên bản đồ
                            </Text>
                            <TouchableOpacity onPress={() => this._onMapPressed()}
                                                style={styles.mapViewButton}>
                                <View>
                                    <MapView
                                        style={styles.imgMapView}
                                        scrollEnabled={false}
                                        zoomEnabled={false}
                                        pitchEnabled={false}
                                        rotateEnabled={false}
                                        initialRegion={region}>
                                        <MapView.Marker coordinate={region} pointerEvents="none">
                                            <LocationMarker/>
                                        </MapView.Marker>
                                    </MapView>
                                </View>
                            </TouchableOpacity>
                            <Text style={{fontSize: 5}} />
                        </View>
                        {this._renderNhaBanThuocDuAn()}
                        {this._renderNhaThueThuocDuAn()}
                </ScrollView>
            </View>
        );
    }

    _isBlacklistDuAnWebsite(link) {
        let valid = true;
        let blacklistWebsites = DanhMuc.blacklistDuAnWebsites;
        for (let i=0; i<blacklistWebsites.length; i++) {
            let blacklistWebsite = blacklistWebsites[i];
            if (blacklistWebsite.indexOf(link) >= 0) {
                valid = false;
                break;
            }
        }
        return valid;
    }

    renderTitleProps(title, prop, textStyle, onPress) {
        if (prop) {
            if (onPress) {
                return (
                    <View style={styles.searchDetailRowAlign} key={title} >
                        <Text style={[styles.textHalfWidth2, textStyle]}>
                            {title}
                        </Text>
                        <TouchableOpacity onPress={onPress} underlayColor="transparent">
                            <Text style={[styles.textHalfWidthBold2, {color: gui.mainColor}, textStyle]}>
                                {prop}
                            </Text>
                        </TouchableOpacity>
                    </View>
                );
            } else {
                return (
                    <View style={styles.searchDetailRowAlign} key={title} >
                        <Text style={[styles.textHalfWidth2, textStyle]}>
                            {title}
                        </Text>
                        <Text style={[styles.textHalfWidthBold2, textStyle]}>
                            {prop}
                        </Text>
                    </View>
                );
            }
        }
    }

    _onMapPressed() {
        let {geo} = this.state.data.duAn.place;
        let region = {
            latitude: geo.lat,
            longitude: geo.lon,
            latitudeDelta: 0.021,
            longitudeDelta: 0.0144
        };
        Actions.SearchMapDuAn({region: region, ads: this.state.data.duAn});
    }

    onPressLink(link) {
        Linking.canOpenURL(link).then(supported => {
            if (!supported) {
                console.log('Can\'t handle url: ' + link);
            } else {
                return Linking.openURL(link);
            }
        }).catch(err => console.error('An error occurred', link));
    }

    _renderNhaBanThuocDuAn () {
        let dataNhaBan = this.state.dataNhaBanThuocDuAn;
        if(dataNhaBan.length <= 0) {
            return;
        }
        let data = this.state.data;
        let duAn = data.duAn;
        let tenDuAn = duAn.tenDuAn ?  duAn.tenDuAn : '';
        return (
            <View style={styles.viewCungLoai}>
                <FullLine style={{marginLeft: 15, marginRight: 10}}/>
                <View style={styles.viewBdsCungLoai}>
                    <View style={styles.viewTextTile}>
                        <Text style={styles.textTitleSuggest}>Bất động sản đang bán thuộc dự án</Text>
                        <Text style={[styles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
                            {tenDuAn}
                        </Text>
                    </View>
                    <View style={styles.viewListView}>
                        <ListView style={styles.viewListNhaGan}
                                  horizontal={true}
                                  enableEmptySections={true}
                                  showsHorizontalScrollIndicator={false}
                                  showsVerticalScrollIndicator={false}
                                  dataSource={ds_nhaBan.cloneWithRows(this.state.dataNhaBanThuocDuAn)}
                                  renderRow={this._renderRowBanDuAn.bind(this)} />
                    </View>
                </View>
            </View>
        );
    }

    _renderNhaThueThuocDuAn() {
        let dataNhaThue = this.state.dataNhaThueThuocDuAn;
        if(dataNhaThue.length <= 0) {
            return;
        }
        let data = this.state.data;
        let duAn = data.duAn;
        let tenDuAn = duAn.tenDuAn ?  duAn.tenDuAn : '';
        return (
            <View style={styles.viewCungLoai}>
                <FullLine style={{marginLeft: 15, marginRight: 10}}/>
                <View style={styles.viewBdsCungLoai}>
                    <View style={styles.viewTextTile}>
                        <Text style={styles.textTitleSuggest}>Bất động sản cho thuê thuộc dự án</Text>
                        <Text style={[styles.textFullWidth,{fontSize: 13, marginTop: 0, color: '#9C9C9C'}]}>
                            {tenDuAn}
                        </Text>
                    </View>
                    <View style={styles.viewListView}>
                        <ListView style={styles.viewListNhaGan}
                                  horizontal={true}
                                  enableEmptySections={true}
                                  showsHorizontalScrollIndicator={false}
                                  showsVerticalScrollIndicator={false}
                                  dataSource={ds_nhaThue.cloneWithRows(this.state.dataNhaThueThuocDuAn)}
                                  renderRow={this._renderRowThueDuAn.bind(this)} />
                    </View>
                </View>
            </View>
        );
    }

    _renderRowThueDuAn(data) {
        let isLiked = this.isLiked(data.adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let shortedAddress = data.diaChi && data.diaChi.length>55 ? data.diaChi.substring(0,55) + "..." : data.diaChi;
        let dienTich = '';
        if (data.dienTichFmt && data.dienTichFmt != 'Không rõ') {
            dienTich = data.dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNguFmt) {
            soPhongNgu = "   " + data.soPhongNguFmt;
        }

        let soTang = '';
        if (data.soTangFmt) {
            soTang = "   " + data.soTangFmt;
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTich, soPhongNgu, soTang);
        return(
            <TouchableOpacity style={styles.eachViewKetQua}  onPress={() => Actions.SearchResultDetail({adsID: data.adsID, source: 'server', imageDetail: data.image.cover})} >
                <ImageBackground style={{width: width - 92, height: 142, marginRight: 9}}
                       source={{uri: data.image.cover}}
                       resizeMode={'cover'}
                       defaultSource={CommonUtils.getNoCoverImage()}
                >
                    <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                    style={styles.linearGradient2}>
                    </LinearGradient>
                    <View style={styles.heartContent}>
                        {this.props.history.uploadingLikedAds.uploading && this.props.history.uploadingLikedAds.adsID == data.adsID ?
                            (<View style={styles.heartButton2}>
                                <GiftedSpinner size="small" color="white"/>
                            </View>)
                            :
                            (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                         color={color} bgColor={bgColor}
                                         bgStyle={bgStyle}
                                         mainProps={styles.heartButton}/>)
                        }
                    </View>
                    <View style={styles.viewTextContent2}>
                        <Text style={styles.priceText}>{data.giaFmt}</Text>
                        <Text style={styles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                        <Text style={styles.infoText}>{detail}</Text>
                    </View>
                </ImageBackground>
            </TouchableOpacity>
        );
    }

    _renderRowBanDuAn (data) {
        let isLiked = this.isLiked(data.adsID);
        let color = 'white';
        let bgColor = isLiked ? '#EC1B77' : '#4A443F';
        let bgStyle = isLiked ? {} : {opacity: 0.55};
        let shortedAddress = data.diaChi && data.diaChi.length>55 ? data.diaChi.substring(0,55) + "..." : data.diaChi;
        let dienTich = '';
        if (data.dienTichFmt && data.dienTichFmt != 'Không rõ') {
            dienTich = data.dienTichFmt;
        }
        let soPhongNgu = '';
        if (data.soPhongNguFmt) {
            soPhongNgu = "   " + data.soPhongNguFmt;
        }

        let soTang = '';
        if (data.soTangFmt) {
            soTang = "   " + data.soTangFmt;
        }

        let detail = this.getMoreInfo(data.loaiTin, data.loaiNhaDat, dienTich, soPhongNgu, soTang);
        return(
            <TouchableOpacity style={styles.eachViewKetQua}  onPress={() => Actions.SearchResultDetail({adsID: data.adsID, source: 'server', imageDetail: data.image.cover})} >
                <ImageBackground style={{width: width - 92, height: 142, marginRight: 9}}
                       source={{uri: data.image.cover}}
                       resizeMode={'cover'}
                       defaultSource={CommonUtils.getNoCoverImage()}
                >
                    <LinearGradient colors={['transparent', 'rgba(0, 0, 0, 0.75)']}
                                    style={styles.linearGradient2}>
                    </LinearGradient>
                    <View style={styles.heartContent}>
                        {this.props.history.uploadingLikedAds.uploading && this.props.history.uploadingLikedAds.adsID == data.adsID ?
                            (<View style={styles.heartButton2}>
                                <GiftedSpinner size="small" color="white"/>
                            </View>)
                            :
                            (<MHeartIcon onPress={() => this.onLike(data.adsID)}
                                         color={color} bgColor={bgColor}
                                         bgStyle={bgStyle}
                                         mainProps={styles.heartButton}/>)
                        }
                    </View>
                    <View style={styles.viewTextContent2}>
                        <Text style={styles.priceText}>{data.giaFmt}</Text>
                        <Text style={styles.infoText} numberOfLines={1}>{shortedAddress}</Text>
                        <Text style={styles.infoText}>{detail}</Text>
                    </View>
                </ImageBackground>
            </TouchableOpacity>
        );
    }

    getMoreInfo(loaiTin, loaiNhaDat, dienTich, soPhongNgu, soTang) {
        let moreInfo = '';
        let loaiNhaDatKeys = loaiTin ? DanhMuc.LoaiNhaDatThueKey : DanhMuc.LoaiNhaDatBanKey;
        if (loaiNhaDat == loaiNhaDatKeys[1]) {
            moreInfo = '' + dienTich + soPhongNgu;
        }
        else if ( !loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[4])) ||
            loaiTin && ((loaiNhaDat == loaiNhaDatKeys[2])
            || (loaiNhaDat == loaiNhaDatKeys[3])
            || (loaiNhaDat == loaiNhaDatKeys[6]))) {
            moreInfo = '' + dienTich + soTang;
        }
        else {
            moreInfo = '' + dienTich;
        }
        return moreInfo;
    }


    isLiked(adsID) {
        const {adsLikes} = this.props.global.currentUser;
        return adsLikes && adsLikes.indexOf(adsID) > -1;
    }

    onLike(adsID) {
        if (!this.props.global.loggedIn) {
            Actions.NewLogin();
        } else {
            if (!this.isLiked(adsID)) {
                this.props.actions.likeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            } else {
                this.props.actions.unlikeAds(this.props.global.currentUser.userID, adsID, this._updateLikeAdsProcessing.bind(this));
            }
        }
    }

    _updateLikeAdsProcessing(likeAdsMessage) {
        this.setState({firstTime: false, likeAdsMessage: likeAdsMessage});
        this._onMsgAnimationStart();
    }

    _onMsgAnimationStart() {
        this.setState({msgType: 'fadeInDown'});
        clearTimeout(this.msgTimer);
        this.msgTimer = setTimeout(() => {this.setState({msgType: 'fadeOutUp'})}, 2000);
    }

    _renderLikeAdsMessage() {
        let uploading = this.props.history.uploadingLikedAds.uploading;
        if (this.state.firstTime || uploading || this.state.msgType == '') {
            return null;
        }
        let textValue = this.state.likeAdsMessage;
        return (
            <MMessage mainStyle={{top: 64}}
                      barStyle="light-content"
                      animation={this.state.msgType}
                      duration={500}
                      onAnimationEnd={this._onAnimationEnd.bind(this)}
                      textValue={textValue}/>
        );
    }

    _onAnimationEnd() {
        if (this.state.msgType === 'slideOutUp') {
            clearTimeout(this.msgTimer);
            this.msgTimer = setTimeout(() => {this.setState({msgType: ''})}, 2000);
        }
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(DetailDuAn);

const styles = StyleSheet.create({
    pageHeader: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        alignItems: 'stretch',
        justifyContent: 'space-between',
        backgroundColor: gui.mainColor,
        height: 64,
        width: width
    },
    searchButton: {
        paddingTop: 20,
        paddingRight: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
        height: 64,
        width: 64
    },
    viewEdit: {
        paddingTop: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: gui.mainColor,
        height: 64,
        width: 64
    },
    viewEditHome:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 18
    },
    textEdit:{
        fontSize:gui.buttonFontSize,
        fontFamily:gui.fontFamily,
        color:'#fff',
        paddingRight: 10,
        paddingLeft: 10,
        fontWeight: '500'
    },
    viewBody: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: '#fff'
    },
    previewModal: {
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'transparent'
    },
    viewListDetail: {
        flexDirection: 'column',
        flexWrap: 'wrap'
    },
    viewTextContent: {
        backgroundColor: 'transparent',
        marginLeft: 15,
        marginRight: 10,
        overflow:'hidden',
        width: width-25,
        marginTop: 10,
        marginBottom: 8
    },
    textNameDuAn: {
        fontSize: 17,
        backgroundColor: 'transparent',
        color: gui.mainColor,
        fontFamily: gui.fontFamily,
        fontWeight: '400',
        textAlign: 'left'
    },
    scrollView: {
        backgroundColor: '#fff',
        paddingBottom: 49,
        flexDirection: 'column'
    },
    viewTextLink: {
        width: width - 25,
        height: 20,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    textFullWidth: {
        textAlign: 'justify',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontFamily: gui.fontFamily,
        marginBottom: 7,
        marginLeft: 0,
        marginRight: 0,
        fontSize: 13,
        marginTop: 3,
        color: '#9C9C9C'
    },
    searchDetailRowAlign: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-around',
    },
    textHalfWidth2: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        color: '#000',
        marginTop: 3,
        marginBottom: 2,
        marginLeft: 10,
        marginRight: 9.5,
        width: width/2 - 55
    },
    textHalfWidthBold2: {
        textAlign: 'left',
        alignItems: 'flex-start',
        backgroundColor: 'transparent',
        fontSize: 15,
        fontFamily: gui.fontFamily,
        fontWeight: 'bold',
        color: '#000',
        marginTop: 3,
        marginBottom: 2,
        marginLeft: 10,
        marginRight: 9.5,
        width: width/2 + 17
    },
    titleTop : {
        color   :'#000',
        fontSize: 18,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0,
        marginTop: 0
    },
    mapViewButton: {
        backgroundColor: 'transparent',
        width: mapWidth
    },
    imgMapView: {
        width: mapWidth,
        height: mapHeight,
    },
    viewCungLoai: {
        height: 221,
        width: width,
        paddingLeft: 0,
        justifyContent: 'center',
        flexDirection: 'column'
    },
    viewBdsCungLoai: {
        height: 220,
        width: width,
        paddingLeft: 25,
        justifyContent: 'center',
        alignItems: 'center'
    },
    viewTextTile: {
        marginTop: 11,
        height: 40,
        width: width,
        justifyContent: 'flex-start',
        alignItems: 'flex-start'
    },
    textTitleSuggest: {
        color   :'#000',
        fontSize: 17,
        fontFamily: gui.fontFamily,
        fontWeight: '600',
        textAlign: 'left',
        backgroundColor: 'transparent',
        marginLeft: 0,
    },
    viewListView: {
        flexGrow:1,
        backgroundColor:'white',
        marginTop:6,
        width: width - 25,
        height: 142,
        marginRight: 25
    },
    viewListNhaGan: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    eachViewKetQua:{
        justifyContent:'center',
        width: width - 92,
        height: 142,
        marginRight: 9
    },
    linearGradient2: {
        marginTop: 71,
        height: 71,
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "transparent",
        flexGrow: 1
    },
    heartContent: {
        position: 'absolute',
        backgroundColor: 'transparent',
        top: 8,
        right: 8,
        width: 35,
        height: 35,
        justifyContent:'center',
        alignItems:'center'
    },
    heartButton: {
        marginTop: 0,
        marginLeft: -10
    },
    heartButton2: {
        marginTop: -6,
        marginLeft: 10
    },
    priceText: {
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white',
        paddingTop:1
    },
    infoText: {
        marginTop:2,
        fontSize: 12,
        fontWeight: '300',
        textAlign: 'left',
        backgroundColor: 'transparent',
        color: 'white'
    },
    viewTextContent2: {
        paddingTop: 8,
        marginTop: -71,
        marginLeft: 12,
        height: 71,
        width: 180
    },
    viewLoaderAds: {
        flex:1,
        alignItems:'flex-start',
        justifyContent:'flex-start'
    },
    viewChildRow: {
        width: width,
        height: height/2 - 64
    },
    headerNoData: {
        width: width,
        height: 64,
        backgroundColor: gui.mainColor
    },
    viewLineLoader: {
        marginTop: 2,
        height: 20,
        width: 80,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
    },
    viewLineLoader1: {
        height: 17,
        width: 160,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
        marginTop: 8
    },
    lineNoData: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginTop: 10
    },
    viewLineLoader2: {
        height: 150,
        width: width - 27,
        backgroundColor:'rgba(234, 235, 237, 0.85)',
        marginTop: 8
    }
});