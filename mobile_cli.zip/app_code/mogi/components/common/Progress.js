import React, { PropTypes } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import gui from "../../lib/gui";
import utils from '../../lib/utils';

const propTypes = {
    progressed: PropTypes.number.isRequired,
    screnWidth: PropTypes.number,
    color: PropTypes.string,
};
var {width, height} = utils.getDimensions();
const Progress = ({ progressed = 0, color = '#fff', height = 12 }) => {
    if (progressed > 100 || progressed < 0) {
        throw new Error('Value for progressed from 0-100');
    }
    const screenWidth = width * 0.8;
    const progressWidth = (screenWidth * progressed) / 100;

    return (
        <View style={styles.progressContainerStyle}>
            <View style={styles.viewProgressing}>
                <Text style={styles.textProgress}>Đang tải dữ liệu</Text>
                <Text style={[styles.textProgress,{marginLeft: 4}]}>{progressed}%</Text>
            </View>
            <View style={[styles.progressBarContainerStyle, { borderColor: '#fff', height, width: screenWidth }]}>
                <View style={[styles.progressBarContentStyle, { width: progressWidth > 1 ? progressWidth - 1 : 1, backgroundColor: color }]} />
            </View>
        </View>
    );
};

Progress.propTypes = propTypes;
const styles = StyleSheet.create({
    progressContainerStyle: {
        width: width,
        height: 52,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
        marginBottom: 2
    },
    progressBarContainerStyle: {
        borderWidth: 1,
        borderRadius: 5,
        marginTop: 8,
        justifyContent: 'center'
    },
    progressBarContentStyle: {
        borderRadius: 6,
        height: 10
    },
    viewProgressing : {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 3
    },
    textProgress: {
        color: '#fff',
        fontSize: 20,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    }
});
export { Progress };
