import React, { PropTypes, Component } from 'react';
import { View, Text, TouchableWithoutFeedback, StyleSheet, Image } from 'react-native';
import gui from "../../lib/gui";
import utils from '../../lib/utils';
var {width, height} = utils.getDimensions();

const propTypes = {
    children: PropTypes.object,
    content: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
};
class Modal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            circleSource: require('../../assets/image/welcome/circle-01.png'),
            cirleRadius: 0.345*width,
            frameIndex: 0
        };
    }

    componentDidMount () {
        this.startAnimation();
    }

    componentWillUnmount() {
        clearInterval(this.defaultAnimationInterval);
    }

    startAnimation () {
        this.frameIndex = -1;
        this.fps = 4;
        clearInterval(this.defaultAnimationInterval);
        this.defaultAnimationInterval = setInterval(()=>{
            this.frameIndex++;
            if (this.animationSequenceComplete(this.frameIndex)) {
                this.frameIndex = 0;
            }
            let cirleRadius = this.getCircleSize();
            this.setState({
                frameIndex: this.frameIndex,
                cirleRadius: cirleRadius
            });
        }, 1000 / this.fps);
    }

    getCircleSize() {
        let cirleRadius = 0.345*width;
        if (this.frameIndex == 0) {
            cirleRadius = 0.345*width;
        }
        if (this.frameIndex == 1) {
            cirleRadius = 0.46*width;
        }
        if (this.frameIndex == 2) {
            cirleRadius = 0.57*width;
        }
        return cirleRadius;
    }

    animationSequenceComplete(frameIndex) {
        return (frameIndex > 2);
    }

    render() {
        const { title, content, children} = this.props;
        let cirleRadius = this.state.cirleRadius;
        return (
            <View style={styles.modalContainer}>
                <Image
                    style={styles.imageIntro} resizeMode = {'cover'}
                    source={require('../../assets/image/welcome/welcome.png')}
                />
                {this.state.frameIndex >= 0 ? <View style={[styles.circleView, {top: 0.246*height-cirleRadius/2}]}>
                    <Image
                        style={{backgroundColor: 'transparent', width: cirleRadius, height: cirleRadius}} resizeMode = {'cover'}
                        source={this.state.circleSource}
                    >
                    </Image>
                </View> : null}
                <View style={styles.childView}>
                    {children}
                </View>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    modalTitle: {
        color: '#fff',
        fontSize: 22,
        fontFamily: gui.fontFamily,
    },
    modalContent: {
        margin: 15,
        justifyContent: 'center',
        alignItems: 'center',
    },
    textContent: {
        color: gui.mainColor,
        fontSize: 22,
        fontFamily: gui.fontFamily,
        fontWeight: '400'
    },
    imageIntro: {
        backgroundColor: 'transparent',
        // transform: [
        //     {scaleX: 0.20},
        //     {scaleY: 0.20}
        // ],
        width: width,
        height: height,
        alignSelf: 'auto'
    },
    childView: {
        position: 'absolute',
        bottom: 30,
        left: 0,
        right: 0,
        justifyContent: 'center',
        alignItems: 'center'
    },
    circleView: {
        position: 'absolute',
        top: 181-0.175*width,
        left: 0,
        right: 6,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

Modal.propTypes = propTypes;
export { Modal };
