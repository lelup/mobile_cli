var cfg = {
    // server : '127.0.0.1'
    server : 'dev.landber.com'
    // server : 'dev2.landber.com'
    //  server: 'landberagent.com'
    // server : 'dev2.gipxy.com'
    //server : '192.168.0.109'
};

//run on local server
// cfg.rootUrl = `http://${cfg.server}:5000/api`;
// cfg.serverUrl = `http://${cfg.server}:5000`;
// cfg.noCoverUrl = `http://${cfg.server}:5000/web/asset/img/reland_house_large.jpg`;


//run on dev server
cfg.rootUrl = `https://${cfg.server}/api`;
cfg.serverUrl = `https://${cfg.server}`;
cfg.noCoverUrl = `https://${cfg.server}/web/asset/img/reland_house_large.jpg`;


cfg.maxWidth = 745;
cfg.maxHeight = 745;
cfg.imageQuality = 100;
cfg.topupSMSNumber = "9029";
cfg.imageMinSize = 380;
cfg.thumbWidth = 200;
cfg.thumbHeight = 200;

cfg.adsThumbWidth = 300;
cfg.adsThumbHeight = 300;

cfg.anonymousUserID = "User_U";

cfg.environment = '';

cfg.groupLandberID = 'Group_Landber_1';

export default cfg;