const InitialState = require('./homeInitialState').default;
const {
    HOME_DATA_LOADING,
    HOME_ACTIVITY_LOADING,
    LOAD_HOME_DATA_SUCCESS,
    LOAD_HOME_DATA_FAILURE,
    ON_HOME_FIELD_CHANGE,
    USER_LOGOUT1,
    ALERT_DATA_LOADING,
    LOAD_ALERT_DATA_SUCCESS,
    LOAD_ALERT_DATA_FAILURE,
} = require('../../lib/constants').default;

const initialState = new InitialState;
export default function homeReducer(state = initialState, action) {
    if (!(state instanceof InitialState)) return initialState.mergeDeep(state);

    switch (action.type) {
        case HOME_DATA_LOADING: {
            let nextState = state.set('isHomeLoading', true);
                // .set('getProjectType', true);
            return nextState;
        }
        case LOAD_HOME_DATA_SUCCESS: {
            let {data} = action.payload;
            let newData = null;
            if (data) {
                newData = data.slice(0);
            }
            let nextState = state.set('isHomeLoading', false)
                .set('data', newData);

            return nextState;
        }
        case LOAD_HOME_DATA_FAILURE: {
            let nextState = state.set('isHomeLoading', false)
                .set('data', null);
            return nextState;
        }
        case ON_HOME_FIELD_CHANGE: {
            const { field, value } = action.payload;
            let nextState = state.set(field, value);
            return nextState;
        }
        case USER_LOGOUT1: {
            let nextState = state.set('data', null)
                .set('getProjectType',true)
                .set('isHomeLoading',false);
        }
        default:
            return state
    }
}
