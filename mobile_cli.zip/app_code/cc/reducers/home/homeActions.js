import homeApi from '../../lib/homeApi';

const {
    HOME_DATA_LOADING,
    LOAD_HOME_DATA_SUCCESS,
    LOAD_HOME_DATA_FAILURE,
    ALERT_DATA_LOADING,
    LOAD_ALERT_DATA_SUCCESS,
    LOAD_ALERT_DATA_FAILURE,
    ON_HOME_FIELD_CHANGE,
    USER_LOGOUT1,
} = require('../../lib/constants').default;

export function onHomeFieldChange(field, value) {
    return {
        type: ON_HOME_FIELD_CHANGE,
        payload: {field: field, value: value}
    };
}

export function userLogout1() {
    return {
        type: USER_LOGOUT1,
        payload: null
    };
}

export function loadHomeDataRequest() {
    return {
        type: HOME_DATA_LOADING,
        payload: null
    }
}

export function loadHomeDataSuccess(payload) {
    return {
        type: LOAD_HOME_DATA_SUCCESS,
        payload: payload
    }
}

export function loadHomeDataFailure() {
    return {
        type: LOAD_HOME_DATA_FAILURE,
        payload: null
    }
}

export function fetchHomeData(token) {
    return (dispatch) => {
        if (!token) {
            return;
        }
        dispatch(loadHomeDataRequest());
        return homeApi.getAnnounceData(token).then((res) => {
            if (res.status === 0) {
                dispatch(loadHomeDataSuccess({data: res.data}));
            }
            else {
                dispatch(loadHomeDataFailure());
            }
            return res;
        });
    }
}

export function loadAlertDataRequest() {
    return {
        type: ALERT_DATA_LOADING,
        payload: null
    }
}

export function loadAlertDataSuccess(payload) {
    return {
        type: LOAD_ALERT_DATA_SUCCESS,
        payload: payload
    }
}

export function loadAlertDataFailure() {
    return {
        type: LOAD_ALERT_DATA_FAILURE,
        payload: null
    }
}

export function fetchAlertData(token) {
    return (dispatch) => {
        if (!token) {
            return;
        }
        dispatch(loadAlertDataRequest());
        return homeApi.alertData(token).then((res) => {
            if (res.status === 0) {
                dispatch(loadAlertDataSuccess({data: res.data}));
            }
            else {
                dispatch(loadAlertDataFailure());
            }
            return res;
        });
    }
}