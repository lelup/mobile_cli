import { Record } from 'immutable';

let InitialState = Record ({
    isHomeLoading: false,
    data: null,
    getProjectType: true
});

export default InitialState;