const {
    LOGIN_REQUEST,
    LOGIN_SUCCESS,
    LOGIN_FAILURE,
    ON_USER_FIELD_CHANGE,
    USER_CONFIRM_CODE_SUCCESS,
    USER_ADD_ANNOUNCE_SUCCESS,
    USER_ADD_ALERT_COMMENT_SUCCESS,
    USER_GET_ALERT_COMMENT_SUCCESS,
    USER_GET_NAME_SUCCESS,
    USER_LOGOUT,
    USER_CLEAN_DATA_COMMENT,

} = require('../../lib/constants').default;
import log from '../../lib/logUtil';
import userApi from '../../lib/userAPI';

export function userConfirmCodeSuccess(payload) {
    return {
        type: USER_CONFIRM_CODE_SUCCESS,
        payload: payload
    };
}

export function userLogout() {
    return {
        type: USER_LOGOUT,
        payload: null
    };
}

export function userCleanDataComment() {
    return {
        type: USER_CLEAN_DATA_COMMENT,
        payload: null
    };
}

export function userAddAnnounceSuccess(payload) {
    return {
        type: USER_ADD_ANNOUNCE_SUCCESS,
        payload: payload
    };
}

export function userAddAlertCommentSuccess(payload) {
    return {
        type: USER_ADD_ALERT_COMMENT_SUCCESS,
        payload: payload
    };
}

export function onUserFieldChange(field, value) {
    return {
        type: ON_USER_FIELD_CHANGE,
        payload: {field: field, value: value}
    };
}

export function loginRequest() {
    return {
        type: LOGIN_REQUEST,
        payload: null
    }
}

export function loginSuccess(payload) {
    return {
        type: LOGIN_SUCCESS,
        payload: payload
    };
}

export function loginFailure() {
    return {
        type: LOGIN_FAILURE,
        payload: null
    };
}

export function userLogin(dto) {

    return dispatch => {
        dispatch(loginRequest());
        return userApi.Login(dto)
            .then(res => {
                if (res.status === 0) {
                    dispatch(loginSuccess({data: dto, token: res.token}));
                } else {
                    dispatch(loginFailure());
                }
                return res;
            });
    };
}

export function userConfirmCodeApartment(dto, token) {

    return dispatch => {
        return userApi.confirmCode(dto, token)
            .then(res => {
                if (res.status === 0) {
                    dispatch(userConfirmCodeSuccess());
                }
                return res;
            });
    };
}

export function userAddAnnounce(dto, token) {

    return dispatch => {
        return userApi.createAnnounce(dto, token)
            .then(res => {
                if (res.status === 0) {
                    dispatch(userAddAnnounceSuccess({data: dto}));
                }
                return res;
            });
    };
}

export function userAddAlertComment(dto, token) {

    return dispatch => {
        return userApi.addAlertComment(dto, token)
            .then(res => {
                if (res.status === 0) {
                    dispatch(userAddAlertCommentSuccess({data: dto}));
                }
                return res;
            });
    };
}

export function getAlertComment(id, pageNo, token) {

    return dispatch => {
        return userApi.getAlertComment(id, pageNo, token)
            .then(res => {
                if (res.status === 0) {
                    dispatch(userGetAlertCommentSuccess({data: res.datum}));
                }
                return res;
            });
    };
}

export function userGetAlertCommentSuccess(payload) {
    return {
        type: USER_GET_ALERT_COMMENT_SUCCESS,
        payload: payload
    };
}

export function getAlertName(token) {

    return dispatch => {
        return userApi.me(token)
            .then(res => {
                if (res.status === 0) {
                    dispatch(userGetNameSuccess({data: res.datum}));
                }
                return res;
            });
    };
}

export function userGetNameSuccess(payload) {
    return {
        type: USER_GET_NAME_SUCCESS,
        payload: payload
    };
}