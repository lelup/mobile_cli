import {Record} from 'immutable';

let InitialState = Record({
    isLoginRequest: false,
    phone: null,
    password: null,
    token: null,
    logined: false,
    codeAparment: false,
    title: null,
    content: null,
    buildingCode:null,
    image: null,
    alertComment: null,
    comment: null,
    pageNo: 1,
    dataComment: [],
    username: null,
    flatCode: null,
    images: [],
    indexImage:null,
    imageOnly:null
});

export default InitialState;