const InitialState = require('./userInitialState').default;
const {
    LOGIN_REQUEST,
    LOGIN_SUCCESS,
    LOGIN_FAILURE,
    ON_USER_FIELD_CHANGE,
    USER_CONFIRM_CODE_SUCCESS,
    USER_ADD_ANNOUNCE_SUCCESS,
    USER_ADD_ALERT_COMMENT_SUCCESS,
    USER_GET_ALERT_COMMENT_SUCCESS,
    USER_GET_NAME_SUCCESS,
    USER_LOGOUT,
    USER_CLEAN_DATA_COMMENT,
} = require('../../lib/constants').default;

const initialState = new InitialState;
export default function userReducer(state = initialState, action) {
    if (action.type === 'UP') return {pageNo: state.pageNo + 1};

    if (!(state instanceof InitialState)) return initialState.mergeDeep(state);

    switch (action.type) {
        case LOGIN_REQUEST: {
            let nextState = state.set('isLoginRequest', true);
            return nextState;
        }
        case LOGIN_SUCCESS: {
            let data = action.payload.data;
            let phone = data.phone;
            let password = data.password;
            let token = data.token;

            let nextState = state.set('isLoginRequest', false)
                .set('phone', phone)
                .set('password', password)
                .set('token', token)
                .set('logined', true);
            return nextState;
        }
        case LOGIN_FAILURE: {
            let nextState = state.set('isLoginRequest', false);
            return nextState;
        }
        case ON_USER_FIELD_CHANGE: {
            const {field, value} = action.payload;
            let nextState = state.set(field, value);
            return nextState;
        }
        case USER_CONFIRM_CODE_SUCCESS: {
            let nextState = state.set('codeAparment', true);
            return nextState;
        }
        case USER_ADD_ANNOUNCE_SUCCESS: {
            let data = action.payload.data;
            let title = data.title;
            let content = data.content;
            let image = data.image;

            let nextState = state.set('title', title)
                .set('content', content)
                .set('image', image);
            return nextState;
        }
        case USER_ADD_ALERT_COMMENT_SUCCESS: {
            let data = action.payload.data;
            let comment = data.comment;
            let nextState = state.set('comment', comment);
            return nextState;
        }
        case USER_GET_ALERT_COMMENT_SUCCESS: {
            let data = action.payload.data;
            let dataComment = state.dataComment.slice(0) || [];
            dataComment = dataComment.concat(data);
            let nextState = state.set('dataComment', dataComment);
            return nextState;
        }
        case USER_GET_NAME_SUCCESS: {
            let data = action.payload.data;
            let username = data.username;
            let buildingCode = data.buildingCode;
            let nextState = state.set('username', username)
                .set('buildingCode', buildingCode);
            return nextState;
        }
        case USER_LOGOUT : {
            let nextState = state
                .set('dataComment', []).set('codeAparment', false).set('logined', false)
                .set('isLoginRequest', false);
            return nextState;
        }
        case USER_CLEAN_DATA_COMMENT : {
            let nextState = state.set('pageNo', 1);
            return nextState
        }
        default:
            return state;
    }
}