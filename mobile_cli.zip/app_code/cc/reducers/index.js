import home from './home/homeReducer';
import { combineReducers } from 'redux';
import user from './user/userReducer';
console.disableYellowBox = true;
const rootReducer = combineReducers({
    home,
    user,
});


export default rootReducer;