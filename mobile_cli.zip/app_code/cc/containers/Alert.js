import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Platform,
    TouchableOpacity,
    ActivityIndicator
} from 'react-native';
import Header2 from '../components/header/Header2';
import gui from '../lib/gui';
import NoiDungThongBao from '../components/alert/AlertND';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../reducers/home/homeActions';
import * as userAction from '../reducers/user/userActions';
import homeApi from '../lib/homeApi';

class Alert extends Component {
    constructor(props){
        super(props);
        this.state = {
            data: null
        }
    }
    componentDidMount(){
        homeApi.alertData(this.props.user.token).then((res) => {
            this.props.actions.onHomeFieldChange('getProjectType', false);
            this.setState({data: res});
        });
    }
    render() {
        if (this.props.home.getProjectType === true) {
            return (
                <View style={styles.viewLoading}>
                    <ActivityIndicator size="large" color="#5D66DD"/>
                </View>
            )
        }
        return (
            <View style={{flex: 1}}>
                <Header2/>
                <Text style={styles.titelText}>Thông báo tòa nhà</Text>
                <TouchableOpacity style={styles.icon}>
                    <Text/>
                </TouchableOpacity>
                <View style={{flex: 1, marginTop: -60, zIndex: 1}}>
                    <NoiDungThongBao data={this.state.data} />
                </View>
            </View>

        );

    }
}

const styles = StyleSheet.create({
    titelText: {
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        marginTop: Platform.OS === 'ios' ? 46 : 10,
        position: 'absolute',
        alignSelf: 'center',
    },
    icon: {
        marginTop: Platform.OS === 'ios' ? 46 : 10,
        position: 'absolute',
        marginLeft: gui.screenWidth - 44
    },
    viewLoading: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    }
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}


export default connect(mapStateToProps, mapDispatchToProps)(Alert)
