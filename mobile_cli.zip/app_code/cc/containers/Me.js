import React, {Component} from 'react';
import {
    View,
    ScrollView,
    ActivityIndicator,
    StyleSheet
} from 'react-native';
import Header from '../components/header/Header';
import gui from '../lib/gui';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../reducers/home/homeActions';
import * as userAction from '../reducers/user/userActions';
import UserInformation from '../components/me/UserInformation'
class Me extends Component {
    render() {
        if (this.props.home.getProjectType === true) {
            return (
                <View style={styles.viewLoading}>
                    <ActivityIndicator size="large" color="#5D66DD"/>
                </View>
            )
        }
        return (
            <View style={{flex:1}}>
                <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0}}>
                    <Header/>
                </View>
                <ScrollView keyboardDismissMode='none'
                            style={{flex: 1, marginTop:15}}>
                    <View style={{flex: 1, height: gui.screenHeight+165}}>
                        <UserInformation {...this.props}/>
                    </View>
                </ScrollView>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    viewLoading: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    }
});
const actions = [
    homeAction,
    userAction
];
function mapStateToProps(state) {
    return {
        ...state
    };
}
function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();
    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}
export default connect(mapStateToProps, mapDispatchToProps)(Me)