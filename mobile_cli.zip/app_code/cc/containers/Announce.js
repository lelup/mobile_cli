import React, {Component} from 'react';
import {
    StyleSheet,
    View,
} from 'react-native';
import NewAnnounce from '../components/announce/NewAnnounce';
import MyAnnounce from '../components/announce/MyAnnounce';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../reducers/home/homeActions';
import * as userAction from '../reducers/user/userActions';

class Announce extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.actions.getAlertName(this.props.user.token);
        this._doRefreshData();
    }
    render() {

        let mainJSX = this.props.home.data === null
            ? <NewAnnounce
                doRefreshData={this._doRefreshData.bind(this)}
            />
            : <MyAnnounce
                username={this.props.user.username}
                data={this.props.home.data}
                doRefreshData={this._doRefreshData.bind(this)}
                token = {this.props.user.token}
            />;
        return (
            <View style={{flex: 1}}>
                {mainJSX}
            </View>

        );
    }
    _doRefreshData = async() => {
        this.props.actions.fetchHomeData(this.props.user.token);
    };
}

const styles = StyleSheet.create({
    viewLoading: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    }
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Announce)
