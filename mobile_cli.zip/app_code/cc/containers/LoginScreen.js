import React, {Component} from "react";
import {ScrollView, Alert, View} from "react-native";
import {bindActionCreators} from 'redux';
import {Map} from 'immutable';
import {connect} from 'react-redux';
import gui from "../lib/gui";
import styles from "../lib/styleLogReForScreen";
import {Actions} from 'react-native-router-flux';
import LoginForm from "../components/form/Login";
import Banner from '../components/login/Banner'
import * as homeAction from '../reducers/home/homeActions';
import * as userAction from '../reducers/user/userActions';
import LinearGradient from 'react-native-linear-gradient';
import localStorage from '../lib/localStorage';

class LoginScreen extends Component {
    constructor(props) {
        super(props);
        this.onLoginPress = this.onLoginPress.bind(this);
        this.onPhoneNumberTextChange = this.onPhoneNumberTextChange.bind(this);
        this.onPasswordTextChange = this.onPasswordTextChange.bind(this);
    }

    render() {
        let {scrollViewDefault, containerAuto, formDefault} = styles;
        return (
            <ScrollView
                keyboardDismissMode="none"
                contentContainerStyle={{
                    width: gui.screenWidth,
                    height: gui.screenHeight * 1.1
                }}
                style={scrollViewDefault}
            >
                <LinearGradient colors={['#6F8EF6', '#5D66DD']} start={{
                    x: 0.0,
                    y: 0.7
                }} end={{
                    x: 0.5,
                    y: 1.0
                }}>
                    <View style={containerAuto}/>
                </LinearGradient>

                <LoginForm
                    FormStyle={formDefault}
                    onLoginPress={this.onLoginPress}
                    onPhoneNumberTextChange={this.onPhoneNumberTextChange}
                    onPasswordTextChange={this.onPasswordTextChange}
                />
                <Banner/>
            </ScrollView>
        );
    }

    onLoginPress() {
        let {phone, password} = this.props.user;
        let dto = {
            password: password,
            phone: phone
        };
        this.props.actions.userLogin(dto)
            .then((res) => {
                this.doAfterLogin(res);
            })
            .catch((res) => {
                Alert.alert('Error', 'phone or password is incorrect!' + res);
            });
    }

    doAfterLogin = async (res) => {
        if (res.status === 0) {
            await this.props.actions.onUserFieldChange('token', res.token);
            let {phone, password} = this.props.user;
            let dto = {
                phone: phone,
                password: password
            };
            localStorage.setLoginInfo(dto);
            Actions.Main({type: 'reset'});
            // if (this.props.user.codeAparment === true) {
            //     Actions.Main({type: 'reset'});
            // } else {
            //     //Actions.Home();
            //     Actions.ConfirmCodeScreenPhone();
            // }
        } else {
            Alert.alert(
                'Lỗi đăng nhập',
                'Sai tài khoản hoặc mật khẩu',
                [
                    // {text: 'Ask me later', onPress: () => console.log('Ask me later pressed')},
                    // {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
                    {
                        text: 'Đồng ý'
                    },
                ],
                {cancelable: false}
            );

        }
    };

    onPhoneNumberTextChange(value) {
        this.props.actions.onUserFieldChange('phone', value);
    }

    onPasswordTextChange(value) {
        this.props.actions.onUserFieldChange('password', value);
    }
}

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();
    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginScreen);

