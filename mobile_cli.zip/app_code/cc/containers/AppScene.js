import React, {Component} from "react";
import {StyleSheet, Text, View} from "react-native";
import {Scene, Router, Tabs} from "react-native-router-flux";
import {connect} from "react-redux";
import Home from "./Home";
import Alert from "./Alert";
import Announce from "./Announce";
import Me from "./Me";
import DetailHome from "../components/home/DetailHome";
import HomeAll from "../components/home/HomeAll";
import AddAnnounce from "../components/announce/AddAnnounce";
import DetailImageAnnounce from "../components/announce/DetailImageAnnounce";
import NewAnnounce from "../components/announce/NewAnnounce";
import DetailAlert from "../components/alert/DetailAlert";
import SplashScreen from "../components/login/SplashScreen";
import RegisterScreen from "../components/login/RegisterScreen";
import ForgetPasswordScreen from "../components/login/ForgetPasswordScreen";
import ConfirmCodeScreen from "../components/login/ConfirmCodeScreen";
import ConfirmCodeScreenPhone from "../components/login/ConfirmCodeScreenPhone";
import CreateNewPasswordScreen from "../components/login/CreateNewPasswordScreen";
import DetailAnnounce from '../components/announce/DetailAnnounce';
import TabIcon from "../components/tab/TabIcon";
import gui from "../lib/gui";
import LoginScreen from './LoginScreen';
import ConfirmCodeScreenApartment from "../components/login/ConfirmCodeScreenApartment";
import failure from "../components/subAlert/failure";
import Sucess from "../components/subAlert/Sucess";
import warning from "../components/subAlert/warning";
import commentAlert from "../components/subAlert/commentAlert";
import ConfirmCodeScreenApartmentAndHouse from '../components/login/ConfirmCodeScreenApartmentAndHouse';
import testCameraRollPicker from "../components/CameraRollPicker/testCameraRollPicker";


const AppScene = (props) => {
    return (
        <View style={{flex: 1}}>
            <RouterWithRedux>
                <Scene
                    key="root"
                    hideNavBar={true}
                    titleStyle={styles.titleStyle}
                    duration={300}
                >
                    <Tabs
                        key="Main"
                        gestureEnabled={false}
                        tabBarPosition="bottom"
                        showLabel={false}
                        tabs
                        tabBarStyle={styles.tabBarStyle}
                        activeBackgroundColor="#fff"
                        animationEnabled={false}
                        default="Home"
                        initial={props.logined}

                    >
                        <Scene
                            key="Home"
                            component={Home}
                            title="TRANG CHỦ"
                            hideNavBar={true}
                            icon={TabIcon}
                            iconSize={22}
                            iconName={"home"}
                            selectedIconName={"home"}
                            navigationBarStyle={{backgroundColor: gui.mainColor}}
                            titleStyle={{color: "white", alignSelf: "center"}}
                        />
                        <Scene
                            key="Alert"
                            component={Alert}
                            title="THÔNG BÁO"
                            hideNavBar={true}
                            icon={TabIcon}
                            iconSize={22}
                            iconName={"bell"}
                            selectedIconName={"bell"}
                            navigationBarStyle={{backgroundColor: gui.mainColor}}
                            titleStyle={{color: "white", alignSelf: "center"}}
                        />
                        <Scene
                            key="Announce"
                            component={Announce}
                            title="PHẢN ÁNH"
                            hideNavBar={true}
                            icon={TabIcon}
                            iconSize={22}
                            iconName={"comment-alt-lines"}
                            selectedIconName={"comment-alt-lines"}
                            navigationBarStyle={{backgroundColor: gui.mainColor}}
                            titleStyle={{color: "white", alignSelf: "center"}}
                        />
                        <Scene
                            key="Me"
                            component={Me}
                            title="TÔI"
                            hideNavBar={true}
                            icon={TabIcon}
                            iconSize={22}
                            iconName={"user"}
                            selectedIconName={"user"}
                            navigationBarStyle={{backgroundColor: gui.mainColor}}
                            titleStyle={{color: "white", alignSelf: "center"}}
                        />
                    </Tabs>
                    <Scene
                        key="SplashScreen"
                        component={SplashScreen}
                        hideNavBar={true}
                    />
                    <Scene
                        key="LoginScreen"
                        component={LoginScreen}
                        hideNavBar={true}
                        initial={!props.logined}
                    />
                    <Scene
                        key="RegisterScreen"
                        component={RegisterScreen}
                        hideNavBar={true}
                        onBack={() => {
                        }}
                    />
                    <Scene
                        key="ForgetPasswordScreen"
                        component={ForgetPasswordScreen}
                        hideNavBar={true}
                    />
                    <Scene
                        key="ConfirmCodeScreen"
                        component={ConfirmCodeScreen}
                        hideNavBar={true}
                    />
                    <Scene
                        key="ConfirmCodeScreenApartment"
                        component={ConfirmCodeScreenApartment}
                        hideNavBar={true}
                    />
                    <Scene
                        key="CreateNewPasswordScreen"
                        component={CreateNewPasswordScreen}
                        hideNavBar={true}
                    />
                    <Scene
                        key="DetailAlert"
                        title="Chi tiết thông báo"
                        component={DetailAlert}
                        hideNavBar={true}
                    />
                    <Scene
                        key="Alert"
                        title="Thông báo chung cư"
                        component={Alert}
                        hideNavBar={true}
                    />
                    <Scene
                        key="AddAnnounce"
                        title="Tạo phản ánh"
                        component={AddAnnounce}
                        hideNavBar={true}
                    />
                    <Scene
                        key="NewAnnounce"
                        title="Phản ánh của bạn"
                        component={NewAnnounce}
                        hideNavBar={true}
                    />
                    <Scene
                        key="Me"
                        title="Tôi"
                        component={Me}
                        hideNavBar={true}
                    />
                    <Scene
                        key="DetailAnnounce"
                        title="Chi tiết thông báo"
                        component={DetailAnnounce}
                        hideNavBar={true}
                    />
                    <Scene
                        key="DetailHome"
                        title="Chi tiết thông báo"
                        component={DetailHome}
                        hideNavBar={true}
                    />
                    <Scene
                        key="HomeAll"
                        title="Trang chủ"
                        component={HomeAll}
                        hideNavBar={true}
                    />
                    <Scene
                        key="failure"
                        title="Thất bại"
                        component={failure}
                        hideNavBar={true}
                    />
                    <Scene
                        key="Sucess"
                        title="Thành công"
                        component={Sucess}
                        hideNavBar={true}
                    />
                    <Scene
                        key="warning"
                        title="Vui lòng chờ"
                        component={warning}
                        hideNavBar={true}
                    />
                    <Scene
                        key="commentAlert"
                        title="Vui lòng chờ"
                        component={commentAlert}
                        hideNavBar={true}
                    />
                    <Scene
                        key="ConfirmCodeScreenPhone"
                        title="Nhập mã điện thoại"
                        component={ConfirmCodeScreenPhone}
                        hideNavBar={true}
                    />
                    <Scene
                        key="ConfirmCodeScreenApartmentAndHouse"
                        title="Vui lòng chờ"
                        component={ConfirmCodeScreenApartmentAndHouse}
                        hideNavBar={true}
                    />
                    <Scene
                        key="testCameraRollPicker"
                        title="Vui lòng chờ"
                        component={testCameraRollPicker}
                        hideNavBar={true}
                        //initial
                    />
                    <Scene
                        key="DetailImageAnnounce"
                        title="Chi tiết hình ảnh"
                        component={DetailImageAnnounce}
                        hideNavBar={true}
                        //initial
                    />


                </Scene>
            </RouterWithRedux>
        </View>
    );
};

const RouterWithRedux = connect()(Router);
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center"
    },
    tabBarStyle: {
        backgroundColor: "#fff",
        height: 49,
        borderTopWidth: 1,
        borderTopColor: "rgba(235,235,235,1)"
    },
    titleStyle: {
        color: "white"
    }
});

export default AppScene;
