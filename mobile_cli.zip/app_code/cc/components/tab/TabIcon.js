import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity
} from 'react-native';

import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import FontAwesomeSolid from '../font/FontAwesomeSolid';

export default class TabIcon extends Component {
    render() {
        let color = this.props.focused ? gui.mainColor : gui.blurTextColor;
        let iconName = this.props.selected ? this.props.selectedIconName : this.props.iconName;

        return (
            <View style={styles.tabIcon}>
                <View style={{ marginTop: 2 }}>
                    {this.props.focused ?
                        <FontAwesomeSolid color={color} name={iconName} size={this.props.iconSize} noAction={true} iconOnly={true} /> :
                        <FontAwesomeLight color={color} name={iconName} size={this.props.iconSize} noAction={true} iconOnly={true} />
                    }
                </View>
                <Text style={[styles.tabIconText, { color: color, top: 3 }]}>{this.props.title}</Text>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    tabIcon: {
        flex: 1,
        alignItems: 'center',
        alignSelf: 'center',
        top: 5
    },

    tabIconText: {
        top: 2,
        fontSize: 9,
        fontFamily: gui.fontFamily,
        fontWeight: 'normal'
    }
});