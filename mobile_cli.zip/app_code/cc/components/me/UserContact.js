import React, {Component} from 'react';
import {
    StyleSheet, View, Text, Switch, Platform, TouchableOpacity,Alert,
} from 'react-native';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
class UserContact extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: true
        };
    }
   
    onPressFlatInfomation(){
        Alert.alert(
            'Thông tin căn hộ',
            'Chưa có giao diện thiết kế\n',
            [
              {text: 'Thoát', onPress: () => {}},
              {text: 'Đồng ý', onPress: () => {}},
            ]
          );
    }
    onPressBuildingInfomation(){
        Alert.alert(
            'Thông tin toà nhà',
            'Chưa có giao diện thiết kế\n',
            [
              {text: 'Thoát', onPress: () => {}},
              {text: 'Đồng ý', onPress: () => {}},
            ]
          );
    }onPressIntroduce(){
        Alert.alert(
            'Giới thiệu',
            'Chưa có giao diện thiết kế\n',
            [
              {text: 'Thoát', onPress: () => {}},
              {text: 'Đồng ý', onPress: () => {}},
            ]
          );
    }
    onPressTermsOfUse(){
        Alert.alert(
            'Điều khoản sử dụng',
            'Chưa có giao diện thiết kế\n',
            [
              {text: 'Thoát', onPress: () => {}},
              {text: 'Đồng ý', onPress: () => {}},
            ]
          )
    }
    render() {
        if (!this.props.data || !this.props.data.datum) {
            return (
                <View>
                </View>
            )
        }
        let user =Object.assign({},this.props.data.datum);
        let {bgMainTop, textRight1, rowInformation, textLeft, textRight, dongKe, bgFlatInformation, rowFlatInformation, rowIntroAndRules, introAndRules, textAll} = styles;
        return (
            <View style={this.props.UserInformation}>
                <View style={bgMainTop}>
                    <Text style={{alignSelf: 'center',fontSize: 17,fontFamily: 'SF UI Display',marginTop: 80,fontWeight: 'bold'}}>{(!user.username)?'empty username':user.username}</Text>
                    <Text style={{alignSelf: 'center',fontSize: 17,fontFamily: 'SF UI Display',marginTop: 4,color: '#5D66DD'}}>{(!user.phone)?'empty phone':user.phone}</Text>
                    <View style={rowInformation}>
                        <Text style={textLeft}>Ngày sinh</Text>
                        <Text style={textRight}>{(!user.birthDate)?'... birthDate':user.birthDate}</Text>
                    </View>
                    <View style={dongKe}/>
                    <View style={rowInformation}>
                        <Text style={textLeft}>Nghề nghiệp</Text>
                        <Text style={textRight}>{(!user.job)?'... job':user.job}</Text>
                    </View>
                    <View style={dongKe}/>
                    <View style={rowInformation}>
                        <Text style={textLeft}>Sở thích</Text>
                        <Text style={textRight}>{(!user.hobby)?'...hobby':user.hobby}</Text>
                    </View>
                    <View style={dongKe}/>
                    <View style={rowInformation}>
                        <Text style={textLeft}>Email</Text>
                        <Text style={textRight}>{(!user.email)?'empty username':user.email}</Text>
                    </View>
                    <View style={dongKe}/>
                    <View style={rowInformation}>
                        <Text style={textLeft}>Chủ nhà</Text>
                        <View style={textRight1}>
                            <Switch color='yellow' style={{marginRight: 20, marginBottom: 10}}>
                            </Switch>
                        </View>
                    </View>
                </View>
                <View style={bgFlatInformation}>
                    <View>
                        <TouchableOpacity style={rowFlatInformation} onPress={this.onPressFlatInfomation}>
                            <FontAwesomeLight name="home" color="#5D66DD" size={25}/>
                            <Text style={textLeft}>Thông tin căn hộ</Text>
                        </TouchableOpacity>
                    </View>
                    <View >
                        <TouchableOpacity style={rowFlatInformation} onPress={this.onPressBuildingInfomation}>
                            <FontAwesomeLight name="building" color="#5D66DD" size={25}/>
                            <Text style={textLeft}>Thông tin tòa nhà</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={rowIntroAndRules}>
                        <TouchableOpacity onPress={this.onPressIntroduce}>
                            <View style={introAndRules}>
                                <FontAwesomeLight name="comment-alt-lines" color="#5D66DD" size={25}/>
                            </View>
                            <Text style={textAll}>Giới thiệu</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={this.onPressTermsOfUse}>
                            <View style={introAndRules}>
                                <FontAwesomeLight name="question" color="#5D66DD" size={25}/>
                            </View>
                            <Text style={textAll}>Điều khoản sử dụng</Text>
                        </TouchableOpacity>
                    </View>
                    <View>
                        <TouchableOpacity style={rowFlatInformation}>
                            <FontAwesomeLight name="sign-out" color="#5D66DD" size={25}/>
                            <Text style={textLeft}>Đăng xuất</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    //user information
    bgMainTop: {
        height: 342,
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12
    },
    rowInformation: {
        flex: 1,
        paddingTop: 12,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    textLeft: {
        fontSize: 17,
        fontFamily: 'SF UI Display',
        marginLeft: 20
    },
    textRight: {
        marginRight: 20,
        fontSize: 17,
        fontFamily: 'SF UI Display',
        color: '#5D66DD'
    },
    dongKe: {
        height: 1,
        width: gui.screenWidth - 64,
        backgroundColor: '#E4EAFF',
        marginLeft: 16,
    },
    //user extra
    bgFlatInformation: {
        height: 362,
        width: gui.screenWidth - 32,
        marginLeft: 16,
        borderRadius: 12,
        marginTop: 16
    },
    rowFlatInformation: {
        height: 56,
        backgroundColor: '#FFFFFF',
        width: gui.screenWidth - 32,
        borderRadius: 12,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 20,
        shadowColor: '#333',
        marginTop:16
    },
    rowIntroAndRules: {
        height: 130,
        backgroundColor: '#FFFFFF',
        width: gui.screenWidth - 32,
        borderRadius: 12,
        paddingLeft: 20,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        shadowColor: '#333',
        marginTop:16
    },
    introAndRules: {
        height: 68,
        width: 68,
        borderWidth: 1,
        borderRadius: 34,
        alignSelf: 'center',
        borderColor: '#E4EAFF',
        paddingTop: 22
    },
    textAll: {
        fontSize: 15,
        fontFamily: 'SF UI Display'
    }
});
export default UserContact