import React, {Component} from 'react';
import {StyleSheet, Image, View} from 'react-native';

export default class UserImg extends Component {
    constructor(props){
        super(props);}

    render() {
        return (
            <View style={[styles.container, this.props.userImgStyle]}>
                <Image
                    style={styles.image}
                    resizeMode={"cover"}
                    source={this.props.data && this.props.data.datum ? 
                    {uri : this.props.data.datum.image} : undefined }
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        alignSelf: 'center',
        elevation: 2
    },
    image: {
        height: 104,
        width: 104,
        borderRadius: 52,
    }
});
