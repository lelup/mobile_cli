import React, {Component} from 'react';
import {
    View,
} from 'react-native';
import UserContact from './UserContact';
import UserImg from './UserImg';
import userApi from "../../lib/userAPI";
class UserInformation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: null
        }
    }
    componentWillMount() {
        userApi.me(this.props.user.token).then((res) => {
            this.props.actions.onHomeFieldChange('getProjectType', false);
            this.setState({data: res});
        });

    }
    render() {
        return (
            <View style={{flex: 1}}>
                <UserContact data={this.state.data} UserInformation={{marginTop:90}}/>
                <UserImg data={this.state.data} userImgStyle={{position:'absolute',top:42}}/>
            </View>
        )
    }
}
export default UserInformation;