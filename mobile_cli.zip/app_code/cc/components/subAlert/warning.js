import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';

export default class failure extends Component {
    render() {
        const {container, titleText, contentText} = styles;
        return (
            <View style={container}>
                <FontAwesomeLight name="exclamation-triangle" color="#FFF" size={25}/>
                <View>
                    <Text style={titleText}> Vui lòng chờ </Text>
                    <Text style={contentText}>Hệ thống đang tải dữ liệu.</Text>
                </View>

                <Text/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFC850",
        flexDirection: 'row',
        justifyContent: "space-between",
        alignItems: 'center',
        height: 50,
        width: gui.screenWidth - 24,
        paddingLeft: 12,
        marginLeft: 12,
        marginTop: 12,
        borderRadius: 5,
    },
    titleText: {
        color: "white",
        marginLeft: 35,
        fontWeight: "500"
    },
    contentText: {
        color: '#FFF',
        marginRight: 30
    }
});