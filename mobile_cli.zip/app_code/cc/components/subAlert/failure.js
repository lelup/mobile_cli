import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';

export default class failure extends Component {
    render() {
        const {container, titleText, contentText} = styles;
        return (
            <View style={container}>
                <FontAwesomeLight name="times-circle" color="#FFF" size={25}/>
                <View>
                    <Text style={titleText}> Không thành công </Text>
                    <Text style={contentText}>Hình như bạn đang làm sai điều gì đó.</Text>
                </View>

                <Text/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#DF405A",
        flexDirection: 'row',
        justifyContent: "space-between",
        alignItems: 'center',
        height: 50,
        width: gui.screenWidth - 24,
        paddingLeft: 12,
        marginLeft: 12,
        marginTop: 12,
        borderRadius: 5,
    },
    titleText: {
        color: "white",
        marginLeft: 40,
        fontWeight:"500"
    },
    contentText: {
        color: '#FFF'
    }
});