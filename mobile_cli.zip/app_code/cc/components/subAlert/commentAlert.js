import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';

export default class failure extends Component {
    render() {
        const {container, titleText, contentText, viewImageAvatar, downUp} = styles;
        return (
            <TouchableOpacity>
                <View style={container}>
                    <View style={viewImageAvatar}>
                    </View>
                    <View>
                        <Text style={titleText}> ThaoJ
                            <Text style={contentText}> Đã bình luận một bài viết trong nhóm </Text>
                        </Text>
                        <Text style={titleText}>
                            siêu nguyên & những người bạn
                        </Text>
                        <Text/>
                        <TouchableOpacity style={downUp}/>
                    </View>
                </View>
                <View style={{width: gui.screenWidth, height: 1, backgroundColor: '#EBEBEB'}}/>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF",
        flexDirection: 'row',
        justifyContent: "space-between",
        alignItems: 'center',
        height: 'auto',
        width: gui.screenWidth,
        paddingLeft: 12,
        borderRadius: 5,
        paddingRight: 12,
        paddingBottom: 3,
        paddingTop: 10,
    },
    viewImageAvatar: {
        height: 38,
        width: 38,
        borderRadius: 19,
        backgroundColor: '#333',

    }
    ,
    titleText: {
        color: '#363636',
        fontWeight: "bold",
    },
    contentText: {
        color: '#363636',
    },
    downUp: {
        width: 34,
        height: 5,
        backgroundColor: '#BFBFBF',
        borderRadius: 3,
        alignSelf: 'center',
        marginRight: 40,

    }
});