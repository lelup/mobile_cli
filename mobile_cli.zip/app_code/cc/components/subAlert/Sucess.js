import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';

export default class failure extends Component {
    render() {
        const {container, titleText, contentText} = styles;
        return (
            <View style={container}>
                <FontAwesomeLight name="check-circle" color="#FFF" size={25}/>
                <View>
                    <Text style={titleText}> Thành công </Text>
                    <Text style={contentText}>Chúc mừng, bạn đã thành công.</Text>
                </View>

                <Text/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#31CF64",
        flexDirection: 'row',
        justifyContent: "space-between",
        alignItems: 'center',
        height: 50,
        width: gui.screenWidth - 24,
        paddingLeft: 12,
        marginLeft: 12,
        marginTop: 12,
        borderRadius: 5,
    },
    titleText: {
        color: "white",
        marginLeft: 50,
        fontWeight:"500"
    },
    contentText: {
        color: '#FFF',
        marginRight:25
    }
});