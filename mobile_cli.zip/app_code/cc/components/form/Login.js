import React, {Component} from "react";
import {View, TextInput, Text, Alert,TouchableOpacity} from "react-native";
import {Button} from "native-base";
import {Actions} from "react-native-router-flux";
import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";
import FloatLabelTextInput from 'react-native-floating-label-text-input';
import {TextField} from 'react-native-material-textfield';

const widthScreen = gui.screenWidth;

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            phone: '',
            password: ''
        }
    }

    render() {
        let {viewDefault,floatTextInputLogin, textHeader, textTitle, textInput, buttonConfirm, textButton} = styles;
        return (
            <View style={this.props.FormStyle}>
                <View style={viewDefault}>
                    <Text style={textHeader}>Đăng nhập</Text>
                </View>

                    <View style={floatTextInputLogin}>
                        <TextField
                            label={"Số điện thoại"}
                            onChangeText ={(text) => {
                                this._onPhoneNumberTextChange(text)
                            }}
                            tintColor={gui.mainColor}
                            baseColor={'#A9ADDF'}
                            fontSize={15}
                            keyboardType="numeric"
                            underlineColorAndroid = 'transparent'
                            autoCapitalize={'none'}
                            characterRestriction={10}

                        />
                    </View>
                    <View style={floatTextInputLogin}>
                        <TextField
                            label={"Mật khẩu"}
                            onChangeText ={(text) => {
                                this._onPasswordTextChange(text)
                            }}
                            tintColor={gui.mainColor}
                            baseColor={'#A9ADDF'}
                            fontSize={15}
                            keyboardType="default"
                            underlineColorAndroid = 'transparent'
                            secureTextEntry={true}
                            autoCapitalize={'none'}
                        />
                    </View>
                <View style={viewDefault}>
                    <Button style={{alignSelf:'center'}} transparent light onPress={() => {
                        Actions.ForgetPasswordScreen();
                    }}>
                        <Text style={textTitle}>Quên mật khẩu</Text>
                    </Button>
                </View>
                <View style={{marginTop: widthScreen * 0.12}}>
                    <Button full style={buttonConfirm} onPress={this._onLoginPress.bind(this)}>
                        <Text style={textButton}>Đăng nhập</Text>
                    </Button>
                </View>
                <View style={{alignItems: "center", marginTop: 15}}>
                    <Text style={{fontSize: 13, color: "#363636"}}>
                        Bạn chưa có tài khoản?{" "}
                        <Text style={{color: "#5D66DD"}} onPress={() => Actions.RegisterScreen()}>Đăng ký</Text>
                    </Text>
                </View>
            </View>
        );
    }

    _onLoginPress() {
        this.props.onLoginPress();
    }

    _onPhoneNumberTextChange(value) {
        this.props.onPhoneNumberTextChange(value);
    }

    _onPasswordTextChange(value) {
        this.props.onPasswordTextChange(value);
    }

}
export default Login;
