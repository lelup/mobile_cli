import React, {Component} from "react";
import {
    View,
    TextInput,
    Text
} from "react-native";
import {Button} from "native-base";
import {Actions} from "react-native-router-flux";
import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";

const widthScreen = gui.screenWidth;
export default class ForgetPasswordForm extends Component {
    render() {
        let {viewDefault, textHeader, textButton, buttonConfirm} = styles;
        return (
            <View style={this.props.FormStyle}>
                <View style={viewDefault}>
                    <Text style={textHeader}>Quên mật khẩu</Text>
                </View>
                <View>
                    <Text
                        style={{
                            fontSize: 16,
                            marginHorizontal: 48,
                            marginBottom: widthScreen * 0.219
                        }}
                    >
                        Chúng tôi sẽ gửi cho bạn mã để xác nhận tài khoản của bạn
                    </Text>
                </View>
                <View>
                    <TextInput
                        placeholder={"Số điện thoại"}
                        placeholderTextColor={"#A9ADDF"}
                        underlineColorAndroid={"#A9ADDF"}
                        style={{marginBottom: widthScreen * 0.243}}
                    />
                </View>
                <View>
                    <Button
                        full
                        style={buttonConfirm}
                        onPress={() => {
                            Actions.ConfirmCodeScreen();
                        }}
                    >
                        <Text style={textButton}>Tiếp tục</Text>
                    </Button>
                </View>
            </View>
        );
    }
}
