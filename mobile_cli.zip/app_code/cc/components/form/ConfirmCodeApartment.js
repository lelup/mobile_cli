import React, {Component} from "react";
import {View, Text} from "react-native";
import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";
import CodeInput from 'react-native-confirmation-code-input';

const widthScreen = gui.screenWidth;
export default class ConfirmCodeApartment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            code: ''
        };
    }

    render() {
        let {viewDefault,textHeader,textButton,buttonConfirm,textInputConfirmCode} = styles;
        return (
            <View style={this.props.FormStyle}>
                <View style={viewDefault}>
                    <Text style={textHeader}>Nhập mã căn hộ</Text>
                </View>
                <View>
                    <Text
                        style={{
                            fontSize: 16,
                            marginHorizontal: 48,
                            marginBottom: widthScreen * 0.077
                        }}
                    >
                        Mỗi căn hộ đều có mã riêng gồm 6 ký tự.
                        <Text>
                            Liên hệ với ban quản lý để lấy
                            mã căn hộ của bạn
                        </Text>
                    </Text>
                </View>
                <View
                    style={{
                        flex: 1,
                        width: widthScreen - widthScreen * 0.136,
                        flexDirection: "row",
                        justifyContent: "space-between",
                        paddingHorizontal: widthScreen * 0.068
                    }}
                >
                        <CodeInput
                            ref="codeInputRef2"
                            activeColor='blue'
                            inactiveColor='gray'
                            keyboardType="default"
                            codeLength={6}
                            className='border-circle'
                            autoFocus={false}
                            autoCapitalize={'none'}
                            codeInputStyle={{ fontWeight: '800' }}
                            onFulfill={( code) => this._onFinishCheckingCode( code)}
                        />
                </View>
                <View
                    style={{alignItems: "center", marginBottom: widthScreen * 0.157}}
                >
                </View>
            </View>
        );
    }
    _onFinishCheckingCode(code) {
        this.props.onConfirmCode(code);
    }
}
