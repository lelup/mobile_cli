import React, {Component} from "react";
import {View, StyleSheet, TextInput, Text, ToastAndroid} from "react-native";
import {Button} from "native-base";
import {Actions} from "react-native-router-flux";
import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";
import CodeInput from 'react-native-confirmation-code-input';

const widthScreen = gui.screenWidth;
export default class ConfirmForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            code: ''
        };
    }

    render() {
        let {viewDefault, textButton, buttonConfirm, textHeader, textInputConfirmCode} = styles;
        return (
            <View style={this.props.FormStyle}>
                <View style={viewDefault}>
                    <Text style={textHeader}>Nhập mã</Text>
                </View>
                <View>
                    <Text
                        style={{
                            fontSize: 16,
                            marginHorizontal: 48,
                            marginBottom: widthScreen * 0.077
                        }}
                    >
                        Chúng tôi đã gửi mã tới điện thoại của bạn
                    </Text>
                </View>
                <View
                    style={{
                        flex: 1,
                        width: widthScreen - widthScreen * 0.136,
                        flexDirection: "row",
                        justifyContent: "space-between",
                        //paddingHorizontal: widthScreen * 0.068,
                        paddingBottom:30
                    }}
                >
                    <CodeInput
                        ref="codeInputRef2"
                        activeColor='blue'
                        inactiveColor='gray'
                        keyboardType="default"
                        codeLength={5}
                        className='border-circle'
                        autoFocus={false}
                        codeInputStyle={{ fontWeight: '800' }}
                        // onFulfill={( code) => this._onFinishCheckingCode( code)}
                    />
                </View>
                <View
                    style={{alignItems: "center", marginBottom: widthScreen * 0.157}}
                >
                    <Text>
                        Bạn đã nhận được mã?<Text
                        style={{color: "#5D66DD", marginLeft: 8}}
                    >
                        Gửi lại
                    </Text>
                    </Text>
                </View>
                <View>
                    <Button
                        full
                        style={buttonConfirm}
                        onPress={() => {
                             Actions.CreateNewPasswordScreen();
                            //Actions.ConfirmCodeScreenApartment();
                        }}
                    >
                        <Text style={textButton}>Tiếp tục</Text>
                    </Button>
                </View>
            </View>
        );
    }
}
