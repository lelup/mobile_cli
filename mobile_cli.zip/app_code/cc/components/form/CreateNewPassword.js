import React, { Component } from "react";
import {
  ScrollView,
  View,
  StyleSheet,
  Image,
  TextInput,
  Text,
  TouchableHighlight
} from "react-native";
import { Button } from "native-base";

import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";

const widthScreen = gui.screenWidth;
export default class CreateNewPasswordForm extends Component {
  render() {
      let {viewDefault,textHeader,textTitle,buttonConfirm,textButton} = styles;
    return (
      <View style={this.props.FormStyle}>
        <View style={viewDefault}>
          <Text style={textHeader}>Tạo mật khẩu mới</Text>
        </View>
        <Text style={textTitle}>Số điện thoại</Text>
        <View>
          <TextInput
            placeholder={"Số điện thoại"}
            placeholderTextColor={"#A9ADDF"}
            underlineColorAndroid={"#A9ADDF"}
          />
        </View>
        <View>
          <TextInput
            placeholder={"Mật khẩu mới"}
            secureTextEntry={true}
            placeholderTextColor={"#A9ADDF"}
            underlineColorAndroid={"#A9ADDF"}
          />
        </View>
        <View>
          <TextInput
            placeholder={"Nhập lại mật khẩu"}
            secureTextEntry={true}
            placeholderTextColor={"#A9ADDF"}
            underlineColorAndroid={"#A9ADDF"}
          />
        </View>
        <View style={{ marginTop: 60 }}>
          <Button full style={buttonConfirm}>
            <Text style={textButton}>Thực hiện</Text>
          </Button>
        </View>
      </View>
    );
  }
}
