import React, {Component} from "react";
import {
    View,
    Text,
    Alert
} from "react-native";
import {Button} from "native-base";
import {Actions} from 'react-native-router-flux';

import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";
import FloatLabelTextInput from 'react-native-floating-label-text-input';
import {TextField} from 'react-native-material-textfield';

export default class RegisterForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            phone: '',
            password: '',
            rePassword: ''
        }
    }

    render() {
        let {viewDefault, textHeader, textButton, floatTextInput} = styles;
        return (
            <View style={this.props.FormStyle}>
                <View style={viewDefault}>
                    <Text style={textHeader}>Đăng ký</Text>
                </View>

                <View style={floatTextInput}>
                    <TextField
                        label={"Số điện thoại"}
                        tintColor={gui.mainColor}
                        baseColor={'#A9ADDF'}
                        fontSize={15}
                        characterRestriction={10}
                        value={this.state.phone}
                        keyboardType="numeric"
                        onChangeText={text => this.setState({phone: text})}
                    />
                </View>
                <View style={floatTextInput}>
                    <TextField
                        label={"Mật khẩu"}
                        secureTextEntry={true}
                        tintColor={gui.mainColor}
                        baseColor={'#A9ADDF'}
                        fontSize={15}
                        value={this.state.password}
                        onChangeText={text => this.setState({password: text})}
                        //onChangeText={'none'} // đổi chữ bàn phìm thành chữ thường hết.
                    />
                </View>
                <View style={floatTextInput}>
                    <TextField
                        label={"Nhập lại mật khẩu"}
                        secureTextEntry={true}
                        tintColor={gui.mainColor}
                        baseColor={'#A9ADDF'}
                        fontSize={15}
                        value={this.state.rePassword}
                        onChangeText={text => this.setState({rePassword: text})}
                        autoCapitalize={'none'}
                    />
                </View>
                <View style={{marginTop: 60}}>
                    <Button
                        onPress={this.registerUser.bind(this)}
                        full
                        style={{
                            borderRadius: 18,
                        }}
                    >
                        <Text style={textButton}>Tiếp theo</Text>
                    </Button>
                </View>
                <View style={{alignItems: "center", marginTop: 15}}>
                    <Text style={{fontSize: 13, color: "#363636"}}>
                        Bạn đã có tài khoản?{" "}
                        <Text style={{color: "#5D66DD"}} onPress={() => Actions.LoginScreen()}>Đăng nhập</Text>
                    </Text>
                </View>
            </View>
        );
    }

    validate(str){
        let srcsets = str.match(/^[0-9]*$/);
        return srcsets;
    }
    registerUser() {
        let {phone, password, rePassword} = this.state;
        if (password !== rePassword) {
            Alert.alert('Lỗi', 'Mật khẩu không trùng khớp');
            return;
        }
        else if (!this.validate(phone)){
            Alert.alert('Lỗi','Nhập sai định dạng số điện thoại');
            return;
        }
        else if (phone === '') {
            Alert.alert('Lỗi', 'Bạn chưa nhập số điện thoại');
            return;
        } else if (password === '') {
            Alert.alert('Lỗi', 'Bạn chưa nhập mật khẩu');
            return;
        }
        else {
            Actions.ConfirmCodeScreenApartmentAndHouse({
                phone: this.state.phone,
                password: this.state.password
            })
        }

    }
}
