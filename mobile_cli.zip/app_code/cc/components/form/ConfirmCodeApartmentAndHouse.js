import React, {Component} from "react";
import {
    View,
    TextInput,
    Text,
    Alert
} from "react-native";
import {Button} from "native-base";
import {Actions} from 'react-native-router-flux';

import {bindActionCreators} from 'redux';
import {Map} from 'immutable';
import {connect} from 'react-redux';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';

import gui from "../../lib/gui";
import styles from "../../lib/stylesForm";
import register from '../../api/register';
import localStorage from '../../lib/localStorage';
import FloatLabelTextInput from 'react-native-floating-label-text-input';
import {TextField} from 'react-native-material-textfield';

const widthScreen = gui.screenWidth;
class ConfirmCodeApartmentAndHouse extends Component {
    constructor(props) {
        super(props);
        this.state = {
            flatCode: '',
            buildingCode: '',
        }
    }

    render() {
        let {viewDefault, textHeader, textButton, floatTextInput} = styles;
        return (
            <View style={this.props.FormStyle}>
                <View style={viewDefault}>
                    <Text style={textHeader}>Nhập mã</Text>
                </View>

                <View style={floatTextInput}>
                    <TextField
                        label={"Mã tòa nhà"}
                        tintColor={gui.mainColor}
                        baseColor={'#A9ADDF'}
                        fontSize={15}
                        characterRestriction={2}
                        value={this.state.buildingCode}
                        keyboardType="default"
                        onChangeText={text => this.setState({buildingCode: text})}
                        autoCapitalize={'none'} // đổi chữ bàn phìm thành chữ thường hết.
                    />
                </View>
                <View style={floatTextInput}>
                    <TextField
                        label={"Mã căn hộ"}
                        tintColor={gui.mainColor}
                        baseColor={'#A9ADDF'}
                        fontSize={15}
                        characterRestriction={6}
                        value={this.state.flatCode}
                        onChangeText={text => this.setState({flatCode: text})}
                        autoCapitalize={'none'} // đổi chữ bàn phìm thành chữ thường hết.
                    />
                </View>
                <View style={{marginTop: gui.screenWidth / 3}}>
                    <Button
                        onPress={this.registerUser.bind(this)}
                        full
                        style={{
                            borderRadius: 18,
                        }}
                    >
                        <Text style={textButton}>Đăng ký</Text>
                    </Button>
                </View>

            </View>
        );
    }


    registerUser() {
        let {flatCode, buildingCode} = this.state;
        let {phone, password} = this.props;
        if (buildingCode === '') {
            Alert.alert('Lỗi', 'Bạn chưa nhập mã căn hộ');
            return;
        }
        else if (flatCode === '') {
            Alert.alert('Lỗi', 'Bạn chưa nhập mã tòa nhà');
            return;
        }
        else {
            register(phone, password, flatCode, buildingCode)
                .then(res => {
                    if (res.status === 0) {
                        return this.onSuccess()
                    }
                    else if (res.status === -1) {
                        return this.onError()
                    }
                    else {
                        return this.onFalse()
                    }
                });
        }

    }

    onSuccess() {
        let {flatCode, buildingCode} = this.state;
        let {phone, password} = this.props;
        let dto = {
            phone: phone,
            password: password
        };
        localStorage.setLoginInfo(dto);
        let flatDto = {
            flatCode: flatCode,
            buildingCode: buildingCode
        };
        localStorage.setFlatInfo(flatDto);
        Alert.alert(
            'Thông báo',
            'Đăng ký thành công',
            [
                {text: 'Đồng ý', onPress: () => {
                    this.props.actions.userLogin(dto).then((res) => {
                        this.doAfterLogin(res);
                    });
                }}
            ],
            {cancelable: false}
        )
    }

    doAfterLogin = async(res) => {
        if (res.status === 0) {
            this.props.actions.fetchHomeData(res.token);
            await this.props.actions.onUserFieldChange('token', res.token);
            await this.props.actions.onUserFieldChange('codeAparment', true);
            Actions.Main({type: 'reset'});
        }
    };

    onFalse() {
        Alert.alert(
            'Thông báo',
            'Số điện thoại đã được đăng ký',
            [
                {text: 'Đồng ý', onPress: () => this.removePhoneNumber.bind(this)}
            ],
            {cancelable: false}
        )
    }

    onError() {
        Alert.alert(
            'Thông báo',
            'Lỗi do đường truyền vui lòng thử lại',
            [
                {text: 'Đồng ý', onPress: () => console.log('Dang ky that bai')}
            ],
            {cancelable: false}
        )
    }

    removePhoneNumber() {
        this.setState({flatCode: ''});
        this.setState({buildingCode: ''});
    }

}

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();
    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ConfirmCodeApartmentAndHouse);