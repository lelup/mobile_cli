import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    TouchableOpacity,
    Image,
    ListView,
    ScrollView
} from 'react-native';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';

const dsListItems = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

class DetailImageAnnounce extends Component {
    render() {
        let {container, imageND, iconBack} = styles;
        return (
            <View style={container}>
                <TouchableOpacity style={iconBack} onPress={() => {
                    Actions.pop()
                }}>
                    <FontAwesomeLight name="times" color="white" size={25}/>
                </TouchableOpacity>

                <ScrollView
                    horizontal={true}
                    pagingEnabled={true}
                >
                    <ListView
                        horizontal={true}
                        dataSource={dsListItems.cloneWithRows(this.props.imgObject.imageSoon)}
                        renderRow={value => (
                            <View>
                                <Image
                                    pagingEnabled={true}
                                    style={imageND}
                                    resizeMode="contain"
                                    source={{uri: value.uri}}
                                />
                            </View>
                        )}
                    />
                </ScrollView>

            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: gui.screenWidth,
        height: gui.screenHeight,
        backgroundColor: 'black'
    },
    imageND: {
        flex: 1,
        height: 'auto',
        width: gui.screenWidth,
        alignSelf: 'center',
    },
    iconBack: {
        marginLeft: -gui.screenWidth / 1.13,
        marginTop: 8
    }
});

export default DetailImageAnnounce
