import React, {Component} from 'react';
import {StyleSheet, Text, View, Platform, ScrollView, TouchableOpacity, Image, Alert} from 'react-native';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import DetailAnnounceComment from './DetailAnnounceComment';
import {Card} from 'native-base';
import userAPI from '../../lib/userAPI';
import homeApi from '../../lib/homeApi';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';
import ReadMore from 'react-native-read-more-text';
import Header3 from "../header/Header3";
import Header2 from "../header/Header2";
import Modal from 'react-native-modalbox';
import Lightbox from 'react-native-lightbox';
import Carousel from 'react-native-looped-carousel';

var moment = require('moment');

class DetailAnnounce extends Component {
    constructor(props) {
        super(props);
        this.state = {
            //dataComment: [],
            isOpenModalModify: false,
        }
    }

    renderCarousel = () => (
        <Carousel style={{width: gui.screenWidth, height: gui.screenWidth}}>
            <Image
                style={{flex: 1}}
                resizeMode="contain"
                source={{uri: `${this.props.data.image}`}}
            />
            {/*<View style={{ backgroundColor: '#6C7A89', flex: 1 }}/>*/}
            {/*<View style={{ backgroundColor: '#019875', flex: 1 }}/>*/}
            {/*<View style={{ backgroundColor: '#E67E22', flex: 1 }}/>*/}
        </Carousel>
    );


    // componentDidMount() {
    //     this._refreshAlertComment();
    // }

    render() {
        let {title, content, id, buildingName, timeCreated, image} = this.props.data;
        //let commentLength = this.state.dataComment.datum && this.state.dataComment.datum.length || 0;
        contentJSX = (<Text>{content}</Text>);
        notContentJSX = (<ReadMore numberOfLines={3}><Text>{content}</Text></ReadMore>);
        let contentLength = content.length < 100 ? contentJSX : notContentJSX;
        let {bgMainTop, bgTopCard, nameAndTime, contentAnnounce, imageStyle, iconOption, timeSubmit, textTitle, imageND, mainContent, textLeft, textRight, userNameStyle} = styles;
        let showImageContent = image === 'null' ? <View/> : this.renderImageContent();
        return (
            <View>
                <Header3 doRefreshData={this.props.doRefreshData}/>
                <ScrollView keyboardDismissMode='none'
                            style={{width: gui.screenWidth, height: gui.screenHeight, marginTop:-8.5}}>
                    <Card style={bgMainTop}>
                        <View style={bgTopCard}>
                            <TouchableOpacity style={nameAndTime}>
                                <Image style={imageStyle} resizeMode={"cover"} source={{
                                    uri: "https://hinhanhdep.org/wp-content/uploads/2016/08/anh-che-hai-huoc-luc-thi-cu-1.jpg"
                                }}/>
                                <View style={{marginLeft: 8}}>
                                    <Text style={userNameStyle}>{this.props.user.username}</Text>
                                    <Text style={timeSubmit}>
                                        Tới: {buildingName} - {moment(timeCreated).format('DD/MM/YYYY | HH:mm')}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity style={iconOption} onPress={this.onModifyClick.bind(this)}>
                                <FontAwesomeLight name="ellipsis-h-alt" color="#5D66DD" size={25}/>
                            </TouchableOpacity>
                        </View>
                        <Text style={textTitle}>{title}</Text>
                        <Lightbox
                            springConfig={{tension: 15, friction: 7}}
                            underlayColor="white"
                            renderContent={this.renderCarousel}
                            swipeToDismiss={true}>
                            {showImageContent}
                        </Lightbox>
                        <View style={contentAnnounce}>
                            {contentLength}
                        </View>
                        {/*<View style={mainContent}>*/}
                        {/*<Text style={textLeft}>{commentLength} bình luận</Text>*/}
                        {/*<TouchableOpacity style={textRight}>*/}
                        {/*<FontAwesomeLight name="comment-alt-lines" color="#5D66DD" size={25}/>*/}
                        {/*</TouchableOpacity>*/}
                        {/*</View>*/}
                        {/*<View>*/}
                        {/*<DetailAnnounceComment*/}
                        {/*id={id} dataComment={this.state.dataComment}*/}
                        {/*refreshAlertComment={this._refreshAlertComment.bind(this)}*/}
                        {/*loadTenComments={this._loadTenComments.bind(this)}*/}
                        {/*quantityCMT={quantityCMT}*/}
                        {/*/>*/}
                        {/*</View>*/}
                    </Card>
                </ScrollView>
                {this.renderModalModify()}
            </View>
        );
    }

    // _refreshAlertComment() {
    //     userAPI.getAlertComment(this.props.data.id, 1, this.props.user.token).then((res) => {
    //         this.setState({dataComment: res});
    //     });
    // }
    //
    // _loadTenComments() {
    //     let pageNo = this.props.user.pageNo + 10;
    //     let commentLength = this.state.dataComment.datum && this.state.dataComment.datum.length || 0;
    //     if ((pageNo + 10 > commentLength )) {
    //         console.log('abc', pageNo)
    //     }
    //     this.props.actions.onUserFieldChange('pageNo', pageNo);
    //     userAPI.getAlertComment(this.props.data.id, pageNo, this.props.user.token).then((res) => {
    //         this.setState({dataComment: res});
    //     });
    //
    // }

    renderImageContent(){
        return(
            <Image
                style={styles.imageND}
                resizeMode="cover"
                source={{uri: `${this.props.data.image}`}}
            />
        );
    }

    onModifyClick() {
        this.setState({isOpenModalModify: true})
    }

    deleteAnnounces() {
        let dto = {
            postID: this.props.data.id
        };
        homeApi.deleteAnnounce(this.props.user.token, dto)
            .then((res) => {
                if (res.status === 0) {
                    this.props.doRefreshData && this.props.doRefreshData();
                    Actions.pop();

                } else {
                    Alert.alert('loi', 'xoa khong thanh cong')
                }
            })
            .catch((res) => {
                Alert.alert('Error', res);
            });
    }

    renderModalModify() {
        let {
            mainModal, mainModal1, SUA, HUY, XOA
        } = styles;
        return (
            <Modal
                style={styles.modalContent}
                position={"bottom"}
                isOpen={this.state.isOpenModalModify}
                backdropPressToClose={true}
                swipeToClose={false}
            >
                <View style={mainModal}>
                    <View style={mainModal1}>
                        <TouchableOpacity
                            style={SUA}
                            onPress={() => {
                            }}>
                            <Text style={{fontSize: 20, color: '#3897F1'}}>Sửa</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={XOA}
                            onPress={this.deleteAnnounces.bind(this)}>
                            <Text style={{fontSize: 20, color: '#ED1C24'}}>Xóa</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={HUY}
                            onPress={() => {
                                this.setState({isOpenModalModify: false})
                            }}>
                            <Text style={{fontSize: 20, color: '#3897F1'}}>Hủy</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        )
    }
}

const styles = StyleSheet.create({
    bgMainTop: {
        height: 'auto',
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
        paddingTop: 16,
        flex: 1,
        marginBottom: 120
    },
    textTitle: {
        fontSize: 17,
        fontFamily: 'SF UI Display',
        fontWeight: 'bold',
        marginLeft: 16,
        marginTop: 8
    },
    textLeft: {
        fontSize: 15,
        fontFamily: 'SF UI Display',
        marginLeft: 16,
        color: '#A9ADDF',
        marginTop: 10,
    },
    textRight: {
        marginRight: 16,
        marginTop: 10
    },
    mainContent: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    midContent: {
        height: 112,
        backgroundColor: 'red'
    },
    imageStyle: {
        height: 40,
        width: 40,
        borderRadius: 20
    },
    imageND: {
        flex: 1,
        height: gui.screenHeight / 3,
        width: gui.screenWidth - 64,
        alignSelf: 'center',
        marginTop: 8,
        marginBottom: 6
    },
    userNameStyle: {
        fontWeight: 'bold',
        fontSize: 15
    },
    timeSubmit: {
        fontSize: 13,
        color: '#5D66DD'
    },
    iconOption: {
        marginLeft: gui.screenWidth - 90,
        position: 'absolute',
        marginTop: -5
    },
    contentAnnounce: {
        marginLeft: 16,
        marginRight: 16,
        marginBottom: 16
    },
    bgTopCard: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginLeft: 16
    },
    nameAndTime: {
        flexDirection: 'row',
        justifyContent: 'flex-start'
    },
    HUY: {
        height: 52, width: gui.screenWidth - 32,
        backgroundColor: '#FFF', alignSelf: 'center', alignItems: 'center',
        borderRadius: 7,
        marginBottom: 8, marginTop: 8,
        justifyContent: 'center'
    },
    XOA: {
        height: 52, width: gui.screenWidth - 32,
        backgroundColor: '#FFF', alignSelf: 'center',
        alignItems: 'center',
        borderBottomRightRadius: 7, borderBottomLeftRadius: 7, marginTop: 1,
        justifyContent: 'center'
    },
    SUA: {
        height: 52, width: gui.screenWidth - 32,
        backgroundColor: '#FFF', alignSelf: 'center',
        alignItems: 'center',
        borderTopRightRadius: 7, borderTopLeftRadius: 7,
        justifyContent: 'center'
    },
    mainModal: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'flex-end',
        backgroundColor: 'transparent'
    },
    mainModal1: {
        height: 'auto',
        width: gui.screenWidth,
        marginBottom: 85
    },
    modalContent: {
        flex: 1,
        backgroundColor: 'transparent',
    }
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(DetailAnnounce)
