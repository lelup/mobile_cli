import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Platform,
    TouchableOpacity,
    Image,
    FlatList,
    ListView,
    ScrollView
} from 'react-native';
import Header21 from '../header/Header21';
import gui from '../../lib/gui';
import homeApi from '../../lib/homeApi';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import {Card} from 'native-base';
import DropdownAlert from 'react-native-dropdownalert';
import Modal from 'react-native-modalbox';
import Lightbox from 'react-native-lightbox';
import Carousel from 'react-native-looped-carousel';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';

var moment = require('moment');
const dsListItems = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
const imgDemo = "https://hinhanhdep.org/wp-content/uploads/2016/08/anh-che-hai-huoc-luc-thi-cu-1.jpg";

class FlatListItems extends Component {
    constructor(props) {
        super(props);

    }

    render() {
        let {title, content, buildingName, timeCreated, image} = this.props.data.default;
        let imgObject = JSON.parse(image);
        let {
            bgMainTop, bgMainTop1, iconOpenModal, contentAnnounce, userTimeStyle, textTitle,
            userNameStyle1, bgMainTopView1, imageND,
        } = styles;
        let showImageContent = imgObject.imageSoon === 'null' ?
            <View/> : this.renderImageContent(this.props.data.default);
        return (
            <View activeOpacity={0.9} onPress={() => {
                this.actionToDetail();
            }}>
                <Card style={bgMainTop}>
                    <View style={bgMainTopView1}>
                        <View style={bgMainTop1}>
                            <Image style={styles.image} source={{
                                uri: imgDemo
                            }}/>
                            <View style={{marginLeft: 8}}>
                                <Text style={userNameStyle1}>{this.props.username}</Text>
                                <Text style={userTimeStyle}>
                                    Tới: {buildingName} - {moment(timeCreated).format('DD/MM/YYYY | HH:mm')}
                                </Text>
                            </View>
                        </View>
                        <TouchableOpacity style={iconOpenModal} onPress={this.props.onModifyClick}>
                            <FontAwesomeLight name="ellipsis-h-alt" color="#5D66DD" size={25}/>
                        </TouchableOpacity>
                    </View>
                    <Text style={textTitle}>
                        {title}
                    </Text>

                    {imgObject.imageSoon === 'null' ? <View/> : this.renderHeader(this.props.data.default)}

                    {imgObject.id === 1
                        ? <Image
                            style={imageND}
                            resizeMode="cover"
                            source={{uri: imgObject.imageSoon[0]}}/>
                        : showImageContent}

                    <Text style={contentAnnounce}>
                        {content.length < 125 ? content : content.slice(0, 125) + '...'}
                    </Text>

                    {/*<View style={mainContent}>
                    <Text style={textLeft}>
                    {quantityCMT} bình luận
                     </Text>
                     <View style={textRight}>
                     <FontAwesomeLight name="comment-alt-lines" color="#5D66DD" size={25}/>
                     </View>
                     </View>*/}
                </Card>
            </View>
        );
    }

    renderHeader(data) {
        this.state = {
            pageImageNumber : 1,
        };
        let image = data.image;
        let imgObject = JSON.parse(image);
        let {headerImage, textHeaderImage} = styles;
        return (
            <View style={headerImage}>
                <Text style={textHeaderImage}>
                    {this.state.pageImageNumber}/{imgObject.imageSoon.length}
                </Text>
            </View>
        );

    }

    renderImageContent(data) {
        let image = data.image;
        let imgObject = JSON.parse(image);
        return (
            <View>
                <ScrollView
                    horizontal={true}
                    pagingEnabled={true}
                    showsHorizontalScrollIndicator={false}

                >
                    <ListView
                        horizontal={true}
                        dataSource={dsListItems.cloneWithRows(imgObject.imageSoon)}
                        renderRow={value => (
                            <TouchableOpacity
                                activeOpacity={0.9}
                                onPress={() => {
                                    Actions.DetailImageAnnounce({
                                        imgObject: imgObject
                                    });
                                }}
                            >
                                <Image
                                    style={styles.imageND}
                                    resizeMode="cover"
                                    source={{uri: value.uri}}
                                />
                            </TouchableOpacity>
                        )}
                        // renderHeader={this.renderHeader}
                    />
                </ScrollView>
            </View>
        );
    }

    actionToDetail() {
        Actions.DetailAnnounce({
            data: this.props.data.default,
            doRefreshData: this.props.doRefreshData,
        })
    }
}

class MyAnnounce extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpenModalModify: false,
            item: null
        }
    }

    render() {
        let {container1, titelText, icon} = styles;
        return (
            <View style={container1}>
                <Header21/>
                <Text style={titelText}>Phản ánh của bạn</Text>
                <TouchableOpacity
                    style={icon}
                    onPress={() => {
                        Actions.AddAnnounce({doRefreshData: this.doAfterAdd.bind(this)})
                    }}>
                    <FontAwesomeLight name="plus" color="#FFFFFF" size={25}/>
                </TouchableOpacity>

                <View style={{flex: 1}}>
                    <FlatList
                        ref="listRef"
                        style={{backgroundColor: 'transparent', flex: 1}}
                        contentContainerStyle={{marginBottom: 100}}
                        data={this.props.data}
                        renderItem={({item, index}) => {
                            return (
                                <FlatListItems data={item}
                                               index={index}
                                               doRefreshData={this.props.doRefreshData}
                                               username={this.props.username}
                                               onModifyClick={this.onModifyClick.bind(this, item)}
                                />
                            );
                        }}
                        keyExtractor={(item, index) => 'list' + item.default.id}>
                    </FlatList>
                </View>
                {this.renderModalModify()}
                <DropdownAlert
                    ref={ref => this.dropDown = ref}
                    successColor='green'
                    defaultContainer={{
                        backgroundColor: "#31CF64",
                        flexDirection: 'row',
                        justifyContent: "space-between",
                        alignItems: 'center',
                        height: 50,
                        width: gui.screenWidth,
                    }}
                />
            </View>
        );
    }


    onModifyClick(item) {
        this.setState({isOpenModalModify: true, item: item})
    }

    doDeleteAnnounces() {
        let item = this.state.item;
        if (!item) {
            return
        }
        let dto = {
            postID: item.default.id
        };
        homeApi.deleteAnnounce(this.props.token, dto)
            .then((res) => {
                if (res.status === 0) {

                    this.props.doRefreshData && this.props.doRefreshData();
                    this.setState({isOpenModalModify: false});
                } else {
                    console.log('Xoa khong thanh cong');
                }
            })
            .catch((res) => {
                Alert.alert('Error', res);
            });
    }

    doAfterAdd() {
        this.props.doRefreshData && this.props.doRefreshData();
        this.refs.listRef.scrollToOffset({x: 0, y: 0, animated: true});
        this.itemAction('Bạn có thể kiểm tra tin trong "Phản Ánh"');
    }

    itemAction(msg) {
        this.dropDown.alertWithType('success', 'Đăng phản ánh thành công', msg);
    }

    renderModalModify() {
        let {
            mainModal, mainModal1, SUA, HUY, XOA, modalContent
        } = styles;
        return (
            <Modal
                style={modalContent}
                position={"bottom"}
                isOpen={this.state.isOpenModalModify}
                swipeToClose={false}
                backdropPressToClose={true}
            >
                <View style={mainModal}>
                    <View style={mainModal1}>
                        <TouchableOpacity
                            style={SUA}
                            onPress={() => {
                            }}>
                            <Text style={{fontSize: 20, color: '#3897F1'}}>Sửa</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={XOA}
                            onPress={this.doDeleteAnnounces.bind(this)}>
                            <Text style={{fontSize: 20, color: '#ED1C24'}}>Xóa</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={HUY}
                            onPress={() => {
                                this.setState({isOpenModalModify: false})
                            }}>
                            <Text style={{fontSize: 20, color: '#3897F1'}}>Hủy</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        )
    }
}

const styles = StyleSheet.create({
    container1: {
        width: gui.screenWidth,
        height: gui.screenHeight,
        paddingBottom: 75,
        elevation: 2
    },
    titelText: {
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        marginTop: Platform.OS === 'ios' ? 46 : 10,
        position: 'absolute',
        alignSelf: 'center',
    },
    icon: {
        marginTop: Platform.OS === 'ios' ? 46 : 10,
        position: 'absolute',
        marginLeft: gui.screenWidth - 44
    },
    icon1: {
        position: 'absolute',
        paddingTop: Platform.OS === 'ios'
            ? 46
            : 20,
        paddingLeft: 15
    },
    bgMainTop: {
        height: 'auto',
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
    },
    textTitle: {
        fontSize: 17,
        fontFamily: 'SF UI Display',
        marginTop: 10,
        fontWeight: 'bold',
        marginLeft: 16
    },
    textLeft: {
        fontSize: 15,
        fontFamily: 'SF UI Display',
        marginLeft: 16,
        color: '#A9ADDF',
        paddingTop: 10
    },
    textRight: {
        marginRight: 16,
        paddingTop: 10
    },
    mainContent: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    image: {
        height: 40,
        width: 40,
        borderRadius: 20
    },
    imageND: {
        flex: 1,
        height: gui.screenHeight / 3.8,
        width: gui.screenWidth - 32,
        alignSelf: 'center',
        marginTop: 8,
        marginBottom: 6,
    },
    headerImage: {
        backgroundColor: '#000000',
        height: 24,
        width: 34,
        marginTop: gui.screenHeight / 5.5,
        position: 'absolute',
        borderRadius: 16,
        justifyContent: 'center',
        marginLeft: gui.screenWidth - 80,
        opacity: 0.8,
        elevation: 33
    },
    textHeaderImage: {
        color: 'white',
        fontSize: 13,
        alignSelf: 'center',
    },
    HUY: {
        height: 52, width: gui.screenWidth - 32,
        backgroundColor: '#FFF', alignSelf: 'center', alignItems: 'center',
        borderRadius: 7,
        marginBottom: 8, marginTop: 8,
        justifyContent: 'center'
    },
    XOA: {
        height: 52, width: gui.screenWidth - 32,
        backgroundColor: '#FFF', alignSelf: 'center',
        alignItems: 'center',
        borderBottomRightRadius: 7, borderBottomLeftRadius: 7, marginTop: 1,
        justifyContent: 'center'
    },
    SUA: {
        height: 52, width: gui.screenWidth - 32,
        backgroundColor: '#FFF', alignSelf: 'center',
        alignItems: 'center',
        borderTopRightRadius: 7, borderTopLeftRadius: 7,
        justifyContent: 'center'
    },
    bgMainTop1: {
        flexDirection: 'row',
        justifyContent: 'flex-start'
    },
    bgMainTopView1: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginLeft: 16,
        marginTop: 16
    },
    userNameStyle1: {
        fontWeight: 'bold',
        fontSize: 15
    },
    userTimeStyle: {
        fontSize: 13,
        color: '#5D66DD'
    },
    iconOpenModal: {
        marginLeft: gui.screenWidth - 90,
        position: 'absolute',
        marginTop: -5
    },
    contentAnnounce: {
        paddingTop: 4,
        marginLeft: 16,
        marginRight: 16,
        marginBottom: 16
    },
    mainModal: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'flex-end',
        backgroundColor: 'transparent'
    },
    mainModal1: {
        height: 'auto',
        width: gui.screenWidth,
        marginBottom: 70
    },
    modalContent: {
        flex: 1,
        backgroundColor: 'transparent'
    },
    viewCommonHeader: {
        height: gui.navBarHeight,
        width: gui.screenWidth,
    }

});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(MyAnnounce)
