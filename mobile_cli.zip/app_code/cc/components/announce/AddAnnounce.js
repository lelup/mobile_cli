import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Platform,
    ScrollView,
    TouchableOpacity,
    Alert,
    Image,
    FlatList
} from 'react-native';
import Header from '../header/Header';
import gui from '../../lib/gui';
import userAPI from '../../lib/userAPI';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import {Card} from 'native-base';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';
import ImagePicker from 'react-native-image-picker';
import {TextField} from 'react-native-material-textfield';
import Modal from 'react-native-modalbox';
import Slider from 'react-native-slider';

class FlastListItem extends Component {
    render() {
        return (
            <View style={{
                flex: 1,
                flexDirection: 'column',
            }}>
                <View>
                    <Image style={{width: 92, height: 92, borderRadius: 10, marginRight: 4}}
                           resizeMode={"cover"}
                           source={{uri: this.props.item.uri}}/>
                </View>
                <TouchableOpacity style={{
                    width: 20, height: 20,
                    borderRadius: 10,
                    backgroundColor: '#000000',
                    position: 'absolute',
                    marginTop: 6,
                    marginLeft: 67,
                }}>
                    <View style={{marginTop: 5}}>
                        <FontAwesomeLight name="times" color="#FFFFFF" size={9}/>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }
}

class AddAnnounce extends Component {
    constructor(props) {
        super(props);
        this.state = {
            title: '',
            content: '',
            image: [],
            avatarSource: null,
            notTitle: null,
            notContent: null,
            showButtonAnnounce: true,
            isOpenModal: false,
        }
    }

    render() {
        let {
            addImage, floatTextInput2, floatTextInput, TextTaoPhanAnh,
            ViewTaoPhanAnh, imageContent, showImage, choseImage, bgMainTop,
            imageAnnounce, dotImageAnnounce, container, titelText1, titelText
        } = styles;
        showImageJSX = (
            <View style={showImage}>
                <TouchableOpacity>
                    <Image style={imageAnnounce} source={{
                        uri: `${this.props.user.imageOnly}`
                    }}/>
                </TouchableOpacity>
                <TouchableOpacity style={dotImageAnnounce}
                                  onPress={() => {
                                      this.props.actions.onUserFieldChange('imageOnly', null);
                                  }}>
                    <View style={{marginTop: 5}}>
                        <FontAwesomeLight name="times" color="#FFFFFF" size={9}/>
                    </View>
                </TouchableOpacity>
            </View>
        );

        showImageFlatListJSX = (
            <FlatList
                horizontal={true}
                data={this.props.user.images}
                renderItem={({item, index}) => {
                    return (
                        <FlastListItem
                            item={item}
                            index={index}
                            parentFlatList={this}
                        />

                    );
                }}
                keyExtractor={(item, index) => item.uri}
            >
            </FlatList>
        );
        let image = this.props.user.imageOnly === null ? showImageFlatListJSX : showImageJSX;
        return (
            <ScrollView keyboardDismissMode='none'
                        style={{width: gui.screenWidth, height: gui.screenHeight + 50}}>
                <View style={container}>
                    <Header/>

                    <Text style={titelText1} onPress={() => {
                        this.props.actions.onUserFieldChange('title', null);
                        this.props.actions.onUserFieldChange('content', null);
                        this.props.actions.onUserFieldChange('images', []);
                        this.props.actions.onUserFieldChange('imageOnly', null);
                        this.setState({
                            image: '',

                        });
                        Actions.pop()
                    }}>
                        Hủy
                    </Text>
                    <Text style={titelText}>Tạo phản ánh</Text>

                    <Card style={bgMainTop}>
                        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                            <View style={floatTextInput}>
                                <TextField
                                    label={"Nhập tiêu đề"}
                                    onChangeText={(text) => {
                                        this.onTitleChange(text)
                                    }}
                                    maxLength={80}
                                    keyboardType='default'
                                    spellCheck={false}
                                    autoCorrect={false}
                                    multiline={true}
                                    tintColor={gui.mainColor}
                                    baseColor={'#A9ADDF'}
                                    fontSize={15}
                                />
                            </View>
                            <Text style={{marginTop: 55, marginRight: 15, color: '#6F8EF6'}}>
                                {80 - (this.props.user.title || '').length}/80
                            </Text>
                        </View>

                        <View style={floatTextInput2}>
                            <TextField
                                label="Nhập nội dung"
                                //value = {this.state.content}
                                onChangeText={(text) => {
                                    this.onContentChange(text)
                                }}
                                multiline={true}
                                keyboardType='default'
                                spellCheck={false}
                                autoCorrect={false}
                                tintColor={gui.mainColor}
                                baseColor={'#A9ADDF'}
                                fontSize={15}
                            />
                        </View>
                        <View style={choseImage}>

                            {/*<TouchableOpacity style={addImage} onPress={this.showImage.bind(this)}>*/}
                            {/*<View style={{marginTop: 33}}>*/}
                            {/*<FontAwesomeLight name="plus" color="#5D66DD" size={30}/>*/}
                            {/*</View>*/}
                            {/*<Text style={{alignSelf: 'center', color: '#5D66DD'}}>Thêm ảnh</Text>*/}
                            {/*</TouchableOpacity>*/}

                            <TouchableOpacity
                                style={addImage}
                                onPress={() => {
                                    Actions.testCameraRollPicker({
                                        doRefreshImages: this.doRefreshImages.bind(this)
                                    });
                                }}
                            >
                                <View style={{marginTop: 33}}>
                                    <FontAwesomeLight name="plus" color="#5D66DD" size={30}/>
                                </View>
                                <Text style={{alignSelf: 'center', color: '#5D66DD'}}>Thêm ảnh</Text>
                            </TouchableOpacity>

                            <View style={imageContent}>
                                {image}
                            </View>
                        </View>
                        {this.state.showButtonAnnounce === true ? this.renderButtonAnnounce() : null}
                    </Card>
                </View>
            </ScrollView>
        );
    }

    doRefreshImages(images) {
        // if (this.props.user.images === null || this.props.user.images === undefined) {
        //     return;
        // } else {
        let newImages = [...this.props.user.images, ...images];
        this.props.actions.onUserFieldChange('images', newImages);
        // }
    }

    renderButtonAnnounce() {
        let {ViewTaoPhanAnh, TextTaoPhanAnh} = styles;
        return (
            <TouchableOpacity
                style={ViewTaoPhanAnh}
                onPress={this.onAddAnnounce.bind(this)}>
                <Text style={TextTaoPhanAnh}>GỬI PHẢN ÁNH</Text>
            </TouchableOpacity>
        );
    }

    validate(str) {
        let srcsets = str.replace(/[, -.]+/g, "");
        return srcsets;
        //value.replace(/[, -.]+/g,"")
    }

    onAddAnnounce() {

        let {token, title, content, buildingCode, images, imageOnly} = this.props.user;
        if (title === null) {
            Alert.alert('Lỗi', 'Chưa nhập tiêu đề');
            return;
        } else if (!this.validate(title)) {
            Alert.alert("Lỗi", 'Nhập sai định dạng tiêu đề');
            return;
        } else if (content === null) {
            Alert.alert('Lỗi', 'Chưa nhập nội dung');
            return;
        } else if (!this.validate(content)) {
            Alert.alert("Lỗi", 'Nhập sai định dạng nội dung');
            return;
        }
        else {
            this.setState({
                showButtonAnnounce: false
            });
            let imgObj = {
                id: (new Date()).getMilliseconds(),
                imageSoon: images.length > 0 ? images : 'null'
            };
            let imgJSON = JSON.stringify(imgObj);

            let imgObjOnly = {
                id: 1,
                imageSoon: [imageOnly]
            };
            imgOnlyJSON = JSON.stringify(imgObjOnly);
            let dto = {
                title: title,
                content: content,
                image: imageOnly === null ? imgJSON : imgOnlyJSON,
                buildingCode: buildingCode
            };
            console.log('+++++++DTO======', dto);
            this.props.actions.userAddAnnounce(dto, token)
                .then((res) => {
                    this.doAfterAddAnnounce(res);
                })
                .catch((res) => {
                    alert('Error', 'Is incorrect!' + res);
                });
        }
    }

    doAfterAddAnnounce = (res) => {
        if (res.status === 0) {
            this.props.doRefreshData && this.props.doRefreshData();
            this.props.actions.onUserFieldChange('title', null);
            this.props.actions.onUserFieldChange('content', null);
            this.props.actions.onUserFieldChange('images', []);
            this.props.actions.onUserFieldChange('imageOnly', null);
            this.setState({
                image: '',

            });
            Actions.pop();
        } else {
            console.log(" This is add announce screen new announce! ");
        }
    };

    onTitleChange(value) {
        this.props.actions.onUserFieldChange('title', value);
    }

    onContentChange(value) {
        this.props.actions.onUserFieldChange('content', value);
    }

}

const styles = StyleSheet.create({
    container: {
        width: gui.screenWidth,
        height: gui.screenHeight + 50,
    },
    addImage: {

        marginLeft: 16,
        height: 92,
        width: 92,
        borderRadius: 10,
        backgroundColor: '#E4EAFF'
    },
    titelText: {
        alignSelf: 'center',
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        position: 'absolute',

        paddingTop: Platform.OS === 'ios'
            ? 46
            : 20
    },
    titelText1: {

        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        position: 'absolute',
        marginLeft: 16,
        paddingTop: Platform.OS === 'ios'
            ? 46
            : 20
    },
    bgMainTop: {
        height: 565,
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
        shadowOpacity: 0.5,
        position: 'absolute',
        shadowColor: 'black',
        shadowOffset: {
            width: 2,
            height: 2
        },
        marginTop: Platform.OS === 'ios'
            ? 94
            : 60
    },
    ViewTaoPhanAnh: {
        position: 'absolute', height: 40, width: gui.screenWidth - 64,
        borderWidth: 1,
        borderRadius: 20,
        alignSelf: 'center',
        marginTop: 445 + 64,
        backgroundColor: '#5D66DD',
        borderColor: '#5D66DD',
    },
    TextTaoPhanAnh: {
        color: '#FFFFFF',
        fontSize: 15,
        marginTop: 9,
        alignSelf: 'center'
    },
    showImage: {
        flex: 1,
        flexDirection: 'column'
    },
    imageAnnounce: {
        width: 92,
        height: 92,
        borderRadius: 10,
        marginRight: 4
    },
    dotImageAnnounce: {
        width: 20, height: 20,
        borderRadius: 10,
        backgroundColor: '#000000',
        position: 'absolute',
        marginTop: 6,
        marginLeft: 67,
    },
    choseImage: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        width: gui.screenWidth,
        marginTop: 236,
        flex: 1
    },
    imageContent: {
        marginLeft: 4,
        flex: 1,
        marginRight: 40
    },
    floatTextInput: {
        marginTop: 15,
        height: 50,
        width: gui.screenWidth - 100,
        marginLeft: 16
    },
    floatTextInput2: {
        marginTop: 30,
        height: 50,
        width: gui.screenWidth - 64,
        marginLeft: 16
    },
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(AddAnnounce)
