import React, {Component} from 'react';
import {StyleSheet, Text, View, Platform, ScrollView, TouchableOpacity, Image} from 'react-native';
import Header from '../header/Header';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import {Card} from 'native-base';

class NewAnnounce extends Component {

    render() {
        let {container,titelText,bgMainTop,icon} = styles;
        return (
            <View style={container}>
                <Header/>

                <Text style={titelText}>Phản ánh của bạn</Text>
                <TouchableOpacity style={icon} onPress={() => Actions.AddAnnounce({
                    doRefreshData: this.props.doRefreshData
                })}>
                    <FontAwesomeLight name="plus" color="#FFFFFF" size={25}/>
                </TouchableOpacity>

                <Card style={bgMainTop}>
                    <View style={{marginTop: 72, alignSelf: 'center'}}>
                        <Image style={{width: 155, height: 155}} source={require('../../assets/images/phan_anh.png')}/>
                    </View>

                    <View style={{marginTop: 45, alignSelf: 'center'}}>
                        <Text style={{paddingLeft: 5, fontWeight: 'bold', fontSize: 15}}>
                            Gửi phản hồi đến ban quản lý tòa nhà
                        </Text>
                        <Text style={{fontSize: 15}}>
                            Bạn đang có vấn đề muốn phản hồi với
                        </Text>
                        <Text style={{paddingLeft: 55, fontSize: 15}}>ban quản lý tòa nhà?</Text>
                    </View>
                    <View style={{marginTop: 19, alignSelf: 'center', marginLeft: 110}}>
                        <Image style={{
                            width: 200,
                            height: 86
                        }} source={require('../../assets/images/phan_anh_bg.png')}/>
                    </View>
                    <TouchableOpacity
                        style=
                            {{
                                position: 'absolute', height: 40, width: 158,
                                borderWidth: 1,
                                borderRadius: 20,
                                alignSelf: 'center',
                                marginTop: 365,
                                backgroundColor: '#FFFFFF',
                                borderColor: '#5D66DD'
                            }}>
                        <Text style={{
                            color: '#5D66DD',
                            fontSize: 15,
                            marginTop: 9,
                            marginLeft: 25
                        }}
                              onPress={() => Actions.AddAnnounce({
                                  doRefreshData: this.props.doRefreshData
                              })}>TẠO PHẢN ÁNH</Text>
                    </TouchableOpacity>
                </Card>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: gui.screenWidth,
        height: gui.screenHeight,
    },
    titelText: {
        alignSelf: 'center',
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        position: 'absolute',


        paddingTop: Platform.OS === 'ios'
            ? 46
            : 20
    },
    icon: {
        position: 'absolute',
        paddingTop: Platform.OS === 'ios'
            ? 46
            : 20,
        paddingLeft: gui.screenWidth - 40
    },
    icon1: {
        position: 'absolute',
        paddingTop: Platform.OS === 'ios'
            ? 46
            : 20,
        paddingLeft: 15
    },
    bgMainTop: {
        height: 444,
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
        shadowOpacity: 0.5,
        position: 'absolute',
        shadowColor: 'black',
        shadowOffset: {
            width: 2,
            height: 2
        },
        marginTop: Platform.OS === 'ios'
            ? 94
            : 60
    }
});

export default NewAnnounce
