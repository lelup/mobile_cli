import React, {Component} from 'react';
import {
    View,
    StyleSheet,
    Image,
    Text,
    TextInput,
    FlatList,
    TouchableOpacity,
    Alert
} from 'react-native';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';

class FlatListItem extends Component {

    render() {
        let {ten, comment} = this.props.item.default;
        let {image, containerF, dongke1} = styles;
        return (
            <View style={{paddingTop: 10}}>
                <View style={containerF}>
                    <Image style={image} resizeMode={"cover"} source={{
                        uri: "https://hinhanhdep.org/wp-content/uploads/2016/08/anh-che-hai-huoc-luc-thi-cu-1.jpg"
                    }}/>
                    <View style={{marginLeft: 8}}>
                        <Text style={{
                            fontWeight: 'bold',
                            fontSize: 15
                        }}>Cần xem lại</Text>
                        <Text style={{fontSize: 15}}>{comment}</Text>
                        <Text style={{
                            fontSize: 13,
                            color: '#A9ADDF'
                        }}>{this.props.item.ngaydang}</Text>
                    </View>
                </View>
                <View style={dongke1}>
                </View>
            </View>

        );
    }
}

class DetailAlertComment extends Component {

    render() {
        showReadMoreJSX = (
            <Text
                style={{color: gui.mainColor, paddingTop: 5}}
                onPress={this.addTenComments.bind(this)}>
                Xem thêm bình luận
            </Text>
        );
        readMoreJSX = this.props.user.pageNo + 9 < this.props.quantityCMT ? showReadMoreJSX : null;
        let {container, dongke, iconComment, textInputComment, iconAddImage} = styles;

        return (<View style={[container, this.props.alertImgStyle]}>
            <View style={dongke}/>
            <TouchableOpacity>
                {readMoreJSX}
            </TouchableOpacity>
            <FlatList
                data={this.props.dataComment.datum}
                renderItem={({item, index}) => {
                    return (
                        <FlatListItem item={item} index={index}/>
                    );
                }}
                keyExtractor={(item, index) => item.default.id}
            >
            </FlatList>
            <View>
                <View style={{paddingTop: 10}}>
                    <TouchableOpacity style={iconAddImage}>
                        <FontAwesomeLight name="camera-alt" color="#5D66DD" size={25}/>
                    </TouchableOpacity>
                    <TextInput placeholder="Nhập bình luận"
                               style={textInputComment}
                               value={this.props.user.comment}
                               underlineColorAndroid='transparent'
                               onChangeText={(text) => {
                                   this.onCommentChange(text)
                               }}
                    >
                    </TextInput>
                    <TouchableOpacity
                        style={iconComment}
                        onPress={this.onAddAlertComment.bind(this)}>
                        <FontAwesomeLight name="paper-plane" color="#5D66DD" size={25}/>
                    </TouchableOpacity>
                </View>
                <View style={dongke}>
                </View>
            </View>

        </View>);
    }

    addTenComments() {
        this.props.loadTenComments && this.props.loadTenComments();
    }

    onAddAlertComment() {
        if (this.props.user.comment === '' || this.props.user.comment === null) {
            Alert.alert('Không thể bình luận', 'Ban can nhap loi binh luan !')
        } else {
            let {token, comment} = this.props.user;
            let dto = {
                postID: this.props.id,
                comment: comment,
            };
            this.props.actions.userAddAlertComment(dto, token)
                .then((res) => {
                    this.doAfterAddAlertComment(res);
                })
                .catch((res) => {
                    Alert.alert('Error', 'Is incorrect!' + res);
                });
        }

    }

    doAfterAddAlertComment = (res) => {

        if (res.status === 0) {
            this.props.actions.onUserFieldChange('comment', '');
            this.props.refreshAlertComment && this.props.refreshAlertComment();
        } else {
            console.log(" This is add alert comment screen new detail alert comment! ");
        }
    };

    onCommentChange(value) {
        this.props.actions.onUserFieldChange('comment', value);
    }

}

const styles = StyleSheet.create({
    container: {
        marginLeft: 16,
        flexDirection: 'column',
        justifyContent: 'space-between',
        height: 260,
        marginBottom: 16
    },
    containerF: {
        width: gui.screenWidth - 64,
        flexDirection: 'row',
        justifyContent: 'flex-start'
    }
    ,
    image: {
        height: 40,
        width: 40,
        borderRadius: 20
    },
    dongke: {
        height: 1,
        width: gui.screenWidth - 64,
        backgroundColor: '#E4EAFF'
    },
    dongke1: {
        height: 1,
        width: gui.screenWidth - 115,
        backgroundColor: '#E4EAFF',
        marginLeft: gui.screenWidth - 310,
        marginTop: 10
    },
    iconComment: {
        position: 'absolute',
        marginLeft: 270,
        paddingTop: 10
    },
    textInputComment: {
        width: gui.screenWidth - 110,
        alignSelf: 'center',
    },
    iconAddImage: {
        position: 'absolute',
        paddingTop: 10
    }
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(DetailAlertComment)
