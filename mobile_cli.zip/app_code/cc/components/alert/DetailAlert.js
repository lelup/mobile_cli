import React, {Component} from 'react';
import {StyleSheet, Text, View, Platform, ScrollView, TouchableOpacity} from 'react-native';
import Header2 from '../header/Header2';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import DetailAlertComment from './DetailAlertComment';
import {Card} from 'native-base';
import userAPI from '../../lib/userAPI';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';
import ReadMore from 'react-native-read-more-text';

class DetailAlert extends Component {
    constructor(props) {
        super(props);
        this.state = {
            //dataComment: []
        }
    }

    // componentDidMount() {
    //     this._refreshAlertComment();
    // }

    render() {
        let {title, content, date, id, quantityCMT} = this.props.data;
        // let commentLength = this.state.dataComment.datum && this.state.dataComment.datum.length || 0;
        contentJSX = (<Text>{content}</Text>);
        notContentJSX = (<ReadMore numberOfLines={1}><Text>{content}</Text></ReadMore>);
        let contentLength = content.length < 100 ? contentJSX : notContentJSX;
        let {icon1, titelText, textRight, textLeft, mainContent, icon, bgMainTop, textTitle, textTime, ViewQuanTrong, quantrong} = styles;
        QTJSX = (
            <View style={ViewQuanTrong}>
                <Text style={quantrong}>Quan trọng</Text>
            </View>
        );
        showQTJSX = quantityCMT >= 10 ? QTJSX : <View/>;
        return (
            <ScrollView keyboardDismissMode='none' style={{width: gui.screenWidth, height: gui.screenHeight}}>
                <View>
                    <Header2/>
                    <TouchableOpacity style={icon1}
                                      onPress={() =>{
                                          this._doRefreshAlertData.bind(this);
                                          this.props.actions.userCleanDataComment();
                                          Actions.pop()
                                      }}>
                        <FontAwesomeLight name="arrow-left" color="#FFFFFF" size={25}
                                          noAction={true} iconOnly={true}/>
                    </TouchableOpacity>
                    <Text style={titelText}>Chi tiết thông báo</Text>
                    <View style={icon}>
                        <Text/>
                    </View>

                    <Card style={bgMainTop}>
                        <Text style={textTitle}>{title}</Text>
                        <View style={{flexDirection: 'row', justifyContent: 'flex-start'}}>
                            <Text style={textTime}>Từ: {date}</Text>
                            {showQTJSX}
                        </View>
                        <View style={{marginLeft: 16, marginRight: 16, marginBottom:16}}>
                            {contentLength}
                        </View>
                        <TouchableOpacity style={{flexDirection:'row', justifyContent:'flex-start', paddingBottom:16}}>
                            <View style={{marginLeft:16,marginRight:6}}>
                                <FontAwesomeLight name="tags" color="#5D66DD" size={20}/>
                            </View>
                            <Text>Đây là chỗ để file đính kèm</Text>
                        </TouchableOpacity>
                        {/*<View style={mainContent}>*/}
                            {/*<TouchableOpacity>*/}
                                {/*<Text style={textLeft}>*/}
                                    {/*/!*{commentLength} *!/*/}
                                    {/*bình luận</Text>*/}
                            {/*</TouchableOpacity>*/}
                            {/*<TouchableOpacity style={textRight}>*/}
                                {/*<FontAwesomeLight name="comment-alt-lines" color="#5D66DD" size={25}/>*/}
                            {/*</TouchableOpacity>*/}
                        {/*</View>*/}
                        {/*<View>*/}
                            {/*<DetailAlertComment*/}
                                {/*id={id} dataComment={this.state.dataComment}*/}
                                {/*refreshAlertComment={this._refreshAlertComment.bind(this)}*/}
                                {/*loadTenComments={this._loadTenComments.bind(this)}*/}
                                {/*quantityCMT={quantityCMT}*/}
                            {/*/>*/}
                        {/*</View>*/}
                    </Card>
                </View>
            </ScrollView>
        );
    }

    _doRefreshAlertData = async() => {
        this.props.actions.fetchAlertData(this.props.user.token);
    };

    // _refreshAlertComment() {
    //     userAPI.getAlertComment(this.props.data.id, 1, this.props.user.token).then((res) => {
    //         this.setState({dataComment: res});
    //     });
    // }
    //
    // _loadTenComments() {
    //     let pageNo = this.props.user.pageNo + 10;
    //     this.props.actions.onUserFieldChange('pageNo', pageNo);
    //     userAPI.getAlertComment(this.props.data.id, pageNo, this.props.user.token).then((res) => {
    //         this.setState({dataComment: res});
    //     });
    // }

}

const styles = StyleSheet.create({
    titelText: {
        alignSelf: 'center',
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10
    },
    icon: {
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        paddingLeft: gui.screenWidth - 40
    },
    icon1: {
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        paddingLeft: 15
    },
    bgMainTop: {
        height: 'auto',
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
        shadowOpacity: 0.5,
        shadowColor: 'black',
        shadowOffset: {
            width: 2,
            height: 2
        },
        marginTop: Platform.OS === 'ios'
            ? -94
            : -44,
        flex: 1, zIndex: 1,
        marginBottom: 16
    },
    textTitle: {
        fontSize: 17,
        fontFamily: 'SF UI Display',
        marginTop: 16,
        fontWeight: 'bold',
        marginLeft: 16
    },
    textTime: {
        fontSize: 13,
        fontFamily: 'SF UI Display',
        marginTop: 7,
        color: '#5D66DD',
        marginLeft: 16
    },
    textLeft: {
        fontSize: 15,
        fontFamily: 'SF UI Display',
        marginLeft: 16,
        color: '#A9ADDF',
        marginTop: 10
    },
    textRight: {
        marginRight: 16,
        marginTop: 10
    },
    mainContent: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    midContent: {
        height: 112,
        backgroundColor: 'red'
    },
    quantrong: {
        color: '#FFFFFF',
        fontFamily: 'SF UI Display',
        fontSize: 13,
        alignSelf: 'center'
    },
    ViewQuanTrong: {
        backgroundColor: '#FFC850',
        height: 20,
        width: 73,
        borderRadius: 10,
        marginTop: 5,
        marginLeft: 3
    }
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(DetailAlert)
