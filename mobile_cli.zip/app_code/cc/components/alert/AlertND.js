import React, {Component} from 'react';
import {StyleSheet, View, Text, TouchableOpacity, FlatList} from 'react-native';
import gui from '../../lib/gui';
import userAPI from '../../lib/userAPI';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import {Card} from 'native-base';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';

class FlatListItem extends Component {

    render() {
        let {title, content, date, quantityCMT} = this.props.item.default;
        let {
            bgMainTop, textTitle, textTime, ViewQuanTrong,
            quantrong, mainContent, textLeft, textRight, contentAlert, mainMini
        } = styles;
        QTJSX = (
            <View style={ViewQuanTrong}>
                <Text style={quantrong}>Quan trọng</Text>
            </View>
        );
        showQTJSX = this.props.item.default.quantityCMT >= 10 ? QTJSX : <View/>;
        return (
            <TouchableOpacity activeOpacity={0.9} onPress={() => {
                Actions.DetailAlert({data: this.props.item.default})
            }}>
                <Card style={bgMainTop}>
                    <Text style={textTitle}>
                        {title}
                    </Text>
                    <View style={mainMini}>
                        <Text style={textTime}>Từ: {date}</Text>
                        {showQTJSX}
                    </View>
                    <Text style={contentAlert}>
                        {content.length < 100 ? content : content.slice(0, 100) + '...'}
                    </Text>
                    <TouchableOpacity
                        style={{flexDirection: 'row', justifyContent: 'flex-start', paddingTop: 10, paddingBottom: 16}}>
                        <View style={{marginLeft: 16, marginRight: 6}}>
                            <FontAwesomeLight name="tags" color="#5D66DD" size={20}/>
                        </View>
                        <Text>Đây là chỗ để file đính kèm</Text>
                    </TouchableOpacity>

                    {/*<View style={mainContent}>*/}
                    {/*<Text style={textLeft}>*/}
                    {/*{quantityCMT} bình luận*/}
                    {/*</Text>*/}
                    {/*<View style={textRight}>*/}
                    {/*<FontAwesomeLight name="comment-alt-lines" color="#5D66DD" size={25}/>*/}
                    {/*</View>*/}
                    {/*</View>*/}

                </Card>
            </TouchableOpacity>
        );
    }
}

class NoiDungThongBao extends Component {

    render() {
        if (!this.props.data) {
            return (
                <View/>
            )
        }
        return (
            <View>
                <FlatList
                    style={{backgroundColor: 'transparent'}}

                    data={this.props.data.datum}
                    renderItem={({item, index}) => {

                        return (
                            <FlatListItem item={item} index={index} token={this.props.user.token}/>

                        );
                    }}
                    keyExtractor={(item, index) => item.default.id}>
                </FlatList>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    bgMainTop: {
        height: 'auto',
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
        shadowOpacity: 0.5,
        shadowColor: 'black',
        shadowOffset: {
            width: 2,
            height: 2
        },
        marginTop: 16
    },
    textTitle: {
        fontSize: 17,
        fontFamily: 'SF UI Display',
        marginTop: 16,
        fontWeight: 'bold',
        marginLeft: 16
    },
    textTime: {
        fontSize: 13,
        fontFamily: 'SF UI Display',
        marginTop: 7,
        color: '#5D66DD',
        marginLeft: 16
    },
    textLeft: {
        fontSize: 15,
        fontFamily: 'SF UI Display',
        marginLeft: 16,
        color: '#A9ADDF',
        paddingTop: 10
    },
    textRight: {
        marginRight: 16,
        paddingTop: 10
    },
    mainContent: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    midContent: {
        height: 112,
        backgroundColor: 'red'
    },
    quantrong: {
        color: '#FFFFFF',
        fontFamily: 'SF UI Display',
        fontSize: 13,
        alignSelf: 'center'
    },
    ViewQuanTrong: {
        backgroundColor: '#FFC850',
        height: 20,
        width: 73,
        borderRadius: 10,
        marginTop: 5,
        marginLeft: 3
    },
    contentAlert: {
        paddingTop: 4,
        marginLeft: 16,
        marginRight: 16
    },
    mainMini: {
        flexDirection: 'row',
        justifyContent: 'flex-start'
    }

});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(NoiDungThongBao)
