import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import CameraRollPicker from 'react-native-camera-roll-picker';
import FontAwesomeLight from '../font/FontAwesomeLight';
import gui from '../../lib/gui';
import LinearGradient from 'react-native-linear-gradient';
import userAPI from '../../lib/userAPI';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';
import ImagePicker from 'react-native-image-picker';
import Modal from 'react-native-modalbox';
import Slider from 'react-native-slider';
import Alert from "../../containers/Alert";

class testCameraRollPicker extends Component {
    constructor(props) {
        super(props);

        this.state = {
            num: 0,
            selected: [],
            avatarSource1: ''
        };
    }

    render() {
        return (
            <View style={styles.container}>
                <LinearGradient colors={['#6F8EF6', '#5D66DD']} start={{
                    x: 0.0,
                    y: 0.7
                }} end={{
                    x: 0.5,
                    y: 1.0
                }}>
                    <View style={styles.content}>
                        <Text style={styles.text}>
                            <Text style={styles.bold}> {this.state.num} </Text> hình ảnh đã chọn
                        </Text>
                    </View>
                </LinearGradient>
                <TouchableOpacity
                    style={{
                        alignItems: 'center',
                        height: 40,
                        justifyContent: 'center'
                    }}
                    onPress={() => {
                        this.openCamera();
                    }}
                >
                    <View style={{justifyContent: 'flex-start', flexDirection: 'row'}}>
                        <FontAwesomeLight name="camera-alt" color="#5D66DD" size={25}/>
                        <Text style={{alignSelf: 'center'}}> Chụp ảnh</Text>
                    </View>
                </TouchableOpacity>
                {this.renderCameraRollPicker()}
                <TouchableOpacity
                    onPress={() => {
                        this.actionToAddAnnounce();
                    }}
                    style={{
                        position: 'absolute',
                        marginTop: gui.screenHeight / 1.2,
                        marginLeft: gui.screenWidth / 1.25,
                    }}
                >
                    <FontAwesomeLight name="share-square" color="#5D66DD" size={40}/>
                </TouchableOpacity>
            </View>
        );
    }

    renderCameraRollPicker() {
        return (
            <CameraRollPicker
                //scrollRenderAheadDistance={500}
                initialListSize={1}
                pageSize={3}
                removeClippedSubviews={false}
                groupTypes='SavedPhotos'
                batchSize={5}
                maximum={5}
                selected={this.state.selected}
                assetType='Photos'
                imagesPerRow={4}
                imageMargin={5}
                callback={this.getSelectedImages.bind(this)}
            />
        );
    }

    openCamera() {
        ImagePicker.launchCamera(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled image picker');
            }
            else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            }
            else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            }
            else {
                let source = {uri: response.uri};
                userAPI.onUpload
                (
                    'Announce_' + (new Date()).getMilliseconds() + '.jpg',
                    response.uri,
                    (err, result) => {
                        if (!err) {
                            let data = JSON.parse(result.data);
                            let image = data.file.url;
                            this.props.actions.onUserFieldChange('imageOnly', image);
                        } else {
                            alert('Lỗi: ' + err);
                        }
                    }
                );
                this.setState({
                    selectedImages: source
                });
                Actions.pop();
            }
        });
    }

    _arrayObjectIndexOf(array, property, value) {
        return array.map((o) => {
            return o[property];
        }).indexOf(value);
    }

    getSelectedImages(images, current) {
        let index = this._arrayObjectIndexOf(images, 'uri', current.uri);
        if (index < 0) {
            return
        }

        var num = images.length;

        this.setState({
            num: num,
            selectedImages: images
        });

        userAPI.onUpload
        (
            'Announce_' + (new Date()).getMilliseconds() + '.jpg',
            current.uri,
            (err, result) => {
                if (!err) {
                    let data = JSON.parse(result.data);
                    let image = data.file.url;
                    let selectedImages = images.slice(0);
                    selectedImages[index].uri = image;
                    this.setState({
                        num: num,
                        selectedImages: selectedImages
                    });
                    // this.props.actions.onUserFieldChange('indexImage', index);
                    // console.log('selectedImages=============', this.state.selectedImages);
                    // console.log('selected---------', this.state.selected);
                    // console.log('images---------', images);
                    // console.log('image---------', image);
                } else {
                    alert('Lỗi: ' + err);
                }
            }
        );
    }

    actionToAddAnnounce() {
        Actions.pop();
        this.props.doRefreshImages && this.props.doRefreshImages(this.state.selectedImages);
    }
}

const options = {
    title: 'Chọn ảnh phản ánh',
    storageOptions: {
        skipBackup: true,
        path: 'images'
    },
    cancelButtonTitle: 'Hủy bỏ',
    takePhotoButtonTitle: 'Sử dụng Camera',
    chooseFromLibraryButtonTitle: null
};
const styles = StyleSheet.create({
    container: {
        flex: 1,

    },
    content: {
        height: 50,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        flexWrap: 'wrap',
    },
    text: {
        fontSize: 16,
        alignItems: 'center',
        color: '#fff',
    },
    bold: {
        fontWeight: 'bold',
    },
    info: {
        fontSize: 12,
    },
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(testCameraRollPicker)