import React, {Component} from "react";
import {View, TouchableOpacity, Platform} from "react-native";
import gui from "./../../lib/gui";
import {StyleSheet} from "react-native";
import LinearGradient from 'react-native-linear-gradient';

import {Actions} from 'react-native-router-flux';
import FontAwesomeLight from '../font/FontAwesomeLight';

export default class splashScreen extends Component {
    constructor(props) {
        super(props);
        this.setState = {};
    }

    render() {
        return (
            <View>
                <LinearGradient colors={['#6F8EF6', '#5D66DD']} start={{
                    x: 0.0,
                    y: 0.7
                }} end={{
                    x: 0.5,
                    y: 1.0
                }}>
                    <View style={styles.containerAuto}/>
                </LinearGradient>
                <TouchableOpacity style={styles.icon1} onPress={() => {
                    Actions.pop()
                }}>
                    <FontAwesomeLight name="arrow-left" color="#FFFFFF" size={25} noAction={true} iconOnly={true}/>
                </TouchableOpacity>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    containerAuto: {
        width: gui.screenWidth,
        height: gui.screenWidth * 0.68,
        alignItems: "center"
    },
    icon1: {
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        paddingLeft: 15,
        // elevation: 3
    },
});
