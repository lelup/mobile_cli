import React, {Component} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import gui from '../../lib/gui';

class Header2 extends Component {
    render() {
        return (<View>
            <LinearGradient colors={['#6F8EF6', '#5D66DD']} start={{
                x: 0.0,
                y: 0.7
            }} end={{
                x: 0.5,
                y: 1.0
            }}>
                <View style={styles.viewCommonHeader}/>

                <View style={styles.viewHeader}/>
            </LinearGradient>
        </View>);
    }
}

const styles = StyleSheet.create({
    viewHeader: {
        width: gui.screenWidth,
        height: 50,
        elevation: 1,
    },
    viewCommonHeader: {
        height: gui.navBarHeight,
        width: gui.screenWidth,
    }
});
export default Header2
