import React, {Component} from 'react';
import {StyleSheet, View, Text, Platform, TouchableOpacity} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import gui from '../../lib/gui';
import {Actions} from 'react-native-router-flux';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';

class Header3 extends Component {
    render() {
        return (
            <View >
                <LinearGradient colors={['#6F8EF6', '#5D66DD']} start={{
                    x: 0.0,
                    y: 0.7
                }} end={{
                    x: 0.5,
                    y: 1.0
                }}>
                    <View style={styles.viewHeader}/>
                </LinearGradient>
                <TouchableOpacity style={styles.icon1} onPress={() =>{
                    this.props.doRefreshData();
                    this.props.actions.userCleanDataComment();
                    Actions.pop()
                }}>
                    <FontAwesomeLight name="arrow-left" color="#FFFFFF" size={25} noAction={true} iconOnly={true}/>
                </TouchableOpacity>
                <Text style={styles.titleText}>Chi tiết phản ánh</Text>
                <Text/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    viewHeader: {
        width: gui.screenWidth,
        height: 50,
    },
    viewCommonHeader: {
        height: gui.navBarHeight,
        width: gui.screenWidth,
    },
    icon1: {
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        paddingLeft: 15,
        // elevation: 3
    },
    titleText: {
        alignSelf: 'center',
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        //elevation: 3
    },
});

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Header3)

