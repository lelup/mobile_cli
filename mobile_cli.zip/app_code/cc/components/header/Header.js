import React, {Component} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import gui from '../../lib/gui';

class Header extends Component {
    render() {
        return (
            <View>
                <LinearGradient colors={['#6F8EF6', '#5D66DD']} start={{
                    x: 0.0,
                    y: 0.7
                }} end={{
                    x: 0.5,
                    y: 1.0
                }}>
                    <View style={styles.bgMainTop}/>
                </LinearGradient>
                <View style={{background:'reg',height: 100,width:gui.screenWidth}}/>
            </View>);
    }
}

const styles = StyleSheet.create({
    bgMainTop: {
        height: gui.headerHeight
    }
});

export default Header
