import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Image,
    TouchableOpacity
} from 'react-native';
import {Container, DeckSwiper, Card, CardItem, Text, Button} from 'native-base';
import gui from '../../lib/gui';
import HeaderHome from "../header/HeaderHome";
import {Actions} from 'react-native-router-flux';
import FontAwesomeLight from '../font/FontAwesomeLight';
var moment = require('moment');

export default class HomeAll extends Component {
    render() {
        if (!this.props.data || this.props.data.length === 0) {
            return <View/>
        }
        let {imageND,TextTime,TextTitle,TextContent,viewView,midContent2in2} = styles;
        return (
            <Container>
                <HeaderHome/>
                <View>
                    <DeckSwiper
                        ref={(c) => this._deckSwiper = c}
                        dataSource={this.props.data}
                        renderItem={(one) => {
                            let item = one.default || {};
                            return (
                                <TouchableOpacity activeOpacity = {0.9} onPress={() => Actions.DetailHome({data: one.default})}>
                                <Card style={{elevation: 3}}>
                                    <CardItem cardBody>
                                        <Image
                                            style={imageND}
                                            source={{uri:`${item.image}`}}/>
                                    </CardItem>

                                    <View>
                                        <Text style={TextTime}>
                                            {moment(item.timeCreated).format('HH:mm - DD/MM/YYYY')}
                                            </Text>
                                        <Text
                                              style={TextTitle}>
                                            {item.title}
                                        </Text>
                                        <Text style={TextContent}>{item.content.slice(0, 50)}</Text>
                                    </View>
                                </Card>
                                </TouchableOpacity>
                            )
                        }
                        }
                    />
                </View>
                <View style={viewView}>

                    <TouchableOpacity onPress={() => this._deckSwiper._root.swipeLeft()}>
                        <View style={midContent2in2}>
                            <FontAwesomeLight name="arrow-left" color="#5D66DD" size={25}/>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => this._deckSwiper._root.swipeRight()}>
                        <View style={midContent2in2}>
                            <FontAwesomeLight name="arrow-right" color="#5D66DD" size={25}/>
                        </View>
                    </TouchableOpacity>
                </View>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    ViewMain: {
        height: 321,
        width: gui.screenWidth,
        backgroundColor: '#F8F8F8',

    },
    imageND: {
        width: gui.screenWidth - 32,
        height: gui.screenHeight / 3,
        marginLeft: 14,
        marginTop: 16,
        borderRadius: 5
    },
    TextTime: {
        color: '#5D66DD',
        fontSize: 13,
        marginTop: 10,
        marginLeft: 14
    },
    TextTitle: {
        fontSize: 17,
        fontWeight: 'bold',
        marginLeft: 14,
    },
    TextContent: {
        marginLeft: 14,
        marginBottom: 10
    },
    midContent2in2: {
        height: 40,
        width: 40,
        borderWidth: 1,
        borderRadius: 20,
        alignSelf: 'center',
        justifyContent: 'center',
        borderColor: '#E4EAFF',
    },
    viewView:{
        flexDirection: "row",
        flex: 1,
        position: "absolute",
        paddingTop: gui.screenHeight / 4,
        left: 0,
        right: 0,
        justifyContent: 'space-between',
        padding: 16,

    }

});