import React, {Component} from 'react';
import {StyleSheet, Text, View, Platform, ScrollView, TouchableOpacity, Image} from 'react-native';
import Header2 from '../header/Header2';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import {Actions} from 'react-native-router-flux';
import {CardItem, Card} from 'native-base';
var moment = require('moment');

class DetailHome extends Component {
    render() {
        let {title, content, timeCreated, image} = this.props.data;
        let {icon1,titelText,icon,bgMainTop,textTitle,textTime,imageND,viewTime,scrollViewStyle,contentHome} = styles;
        return (
            <ScrollView keyboardDismissMode='none' style={scrollViewStyle}>
                <View>
                    <Header2/>
                    <TouchableOpacity style={icon1} onPress={() => Actions.pop()}>
                        <FontAwesomeLight onPress={() => Actions.Alert({})} name="arrow-left" color="#FFFFFF" size={25}
                                          noAction={true} iconOnly={true}/>
                    </TouchableOpacity>
                    <Text style={titelText}>Chi tiết quảng cáo</Text>
                    <View style={icon}>
                        <Text/>
                    </View>

                    <View style={bgMainTop}>
                        <Text style={textTitle}>{title}</Text>
                        <View style={viewTime}>
                            <Text style={textTime}>
                                Thời gian: {moment(timeCreated).format('DD/MM/YYYY | HH:mm')}
                                </Text>
                        </View>
                        <CardItem cardBody>
                            <Image
                                style={imageND}
                                source={{uri: `${image}`}}/>
                        </CardItem>
                        <Text style={contentHome}>
                            {content}

                        </Text>
                    </View>
                </View>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    titelText: {
        alignSelf: 'center',
        fontFamily: 'SF UI Display',
        fontSize: 17,
        color: '#FFFFFF',
        fontWeight: '500',
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10
    },
    icon: {
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        paddingLeft: gui.screenWidth - 40
    },
    icon1: {
        position: 'absolute',
        marginTop: Platform.OS === 'ios'
            ? 46
            : 10,
        paddingLeft: 15
    },
    bgMainTop: {
        height: 'auto',
        width: gui.screenWidth - 32,
        backgroundColor: '#FFFFFF',
        marginLeft: 16,
        borderRadius: 12,
        marginTop: Platform.OS === 'ios'
            ? -94
            : -44,
        flex: 1, zIndex: 1,
        marginBottom: 16,
        shadowColor: '#333',
        shadowOffset: {width: 0, height: 1},
        shadowOpacity: 0.1,
        shadowRadius: 1,
        elevation: 2
    },
    textTitle: {
        fontSize: 17,
        fontFamily: 'SF UI Display',
        marginTop: 16,
        fontWeight: 'bold',
        marginLeft: 16
    },
    textTime: {
        fontSize: 13,
        fontFamily: 'SF UI Display',
        marginTop: 7,
        color: '#5D66DD',
        marginLeft: 16
    },
    textLeft: {
        fontSize: 15,
        fontFamily: 'SF UI Display',
        marginLeft: 16,
        color: '#A9ADDF',
        marginTop: 10
    },
    textRight: {
        marginRight: 16,
        marginTop: 10
    },
    mainContent: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10
    },
    midContent: {
        height: 112,
        backgroundColor: 'red'
    },
    imageND: {
        width: gui.screenWidth - 64,
        height: gui.screenHeight / 2.5,
        marginLeft: 14,
        marginTop: 10,
        borderRadius: 5
    },
    viewTime:{flexDirection: 'row', justifyContent: 'flex-start'},
    scrollViewStyle:{width: gui.screenWidth, height: gui.screenHeight},
    contentHome:{paddingTop: 8, marginLeft: 16, paddingBottom: 8}
});

export default DetailHome
