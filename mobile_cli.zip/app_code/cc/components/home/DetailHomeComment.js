import React, {Component} from 'react';
import {View, StyleSheet, Image, Text, TextInput, FlatList, ScrollView, TouchableOpacity} from 'react-native';
import gui from '../../lib/gui';
import FontAwesomeLight from '../font/FontAwesomeLight';
import DataComment from '../../lib/DataComment';

class FlatListItem extends Component {
    render() {
        let {image,dongke1,commentLine,nameAdvert,contentAdvert,timeAdvert,commentLineMini,viewTotal} = styles;
        return (
            <View style={viewTotal}>
                <View style={commentLine}>
                    <Image style={image} source={{uri: this.props.item.hinhanh}}/>
                    <View style={commentLineMini}>
                        <Text style={nameAdvert}>{this.props.item.ten}</Text>
                        <Text style={contentAdvert}>{this.props.item.noidung}</Text>
                        <Text style={timeAdvert}>{this.props.item.ngaydang}</Text>
                    </View>
                </View>
                <View style={dongke1}>
                </View>
            </View>

        );
    }
}

export default class DetailHomeComment extends Component {
    render() {
        return (<View style={[styles.container, this.props.alertImgStyle]}>
            <View style={styles.dongke}/>
            <FlatList
                data={DataComment}
                renderItem={({item, index}) => {
                    return (
                        <ScrollView keyboardDismissMode='none'>
                            <FlatListItem item={item} index={index}>
                            </FlatListItem>
                        </ScrollView>
                    );
                }}
            >
            </FlatList>
            <View>
                <View>
                    <TouchableOpacity style={{
                        position: 'absolute'
                    }}>
                        <FontAwesomeLight name="camera-alt" color="#5D66DD" size={25}/>
                    </TouchableOpacity>
                    <TextInput placeholder="Nhập bình luận" style={{
                        width: gui.screenWidth - 110,
                        alignSelf: 'center',
                    }}
                               underlineColorAndroid='transparent'>
                    </TextInput>
                    <TouchableOpacity style={{
                        position: 'absolute',
                        marginLeft: 270
                    }}>
                        <FontAwesomeLight name="paper-plane" color="#5D66DD" size={25}/>
                    </TouchableOpacity>
                </View>

                <View style={styles.dongke}>

                </View>
            </View>

        </View>);
    }
}

const styles = StyleSheet.create({
    container: {
        marginLeft: 16,
        flexDirection: 'column',
        justifyContent: 'space-between',
        height: 260,
        marginBottom: 16
    },
    image: {
        height: 40,
        width: 40,
        borderRadius: 20
    },
    dongke: {
        height: 1,
        width: gui.screenWidth - 64,
        backgroundColor: '#E4EAFF'
    },
    dongke1: {
        height: 1,
        width: gui.screenWidth - 115,
        backgroundColor: '#E4EAFF',
        marginLeft: gui.screenWidth - 310,
        marginTop: 10
    },
    commentLine:{
        width: gui.screenWidth - 64,
        flexDirection: 'row',
        justifyContent: 'flex-start'
    },
    nameAdvert:{
        fontWeight: 'bold',
        fontSize: 15
    },
    contentAdvert:{
        fontSize: 15
    },
    timeAdvert:{
        fontSize: 13,
        color: '#A9ADDF'
    },
    commentLineMini:{marginLeft: 8},
    viewTotal:{paddingTop: 10}
});
