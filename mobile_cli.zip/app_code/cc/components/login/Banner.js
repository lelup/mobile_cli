import React, { Component } from "react";
import { View, Image } from "react-native";

import styles from "../../lib/styleLogReForScreen";
class Banner extends Component {
  render() {
    return (
      <View style={styles.logoHint}>
          <Image
            style={{
              width: "90%",
              height: "90%",
              marginTop: 0
            }}
            source={require("../../assets/images/bg_icon_dangkydangnhap.png")}
          />
          <Image
            style={styles.iconHint}
            source={require("../../assets/images/icon_dangkydangnhap.png")}
          />
        </View>
    );
  }
}
export default Banner;
