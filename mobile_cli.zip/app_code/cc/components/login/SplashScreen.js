import React, {Component} from "react";
import {View, Image, StyleSheet} from "react-native";
import {Actions} from "react-native-router-flux";
import gui from "../../lib/gui";

export default class SplashScreen extends Component {
    constructor(props) {
        super(props);
        setTimeout(() => {
            Actions.LoginScreen();
        }, 3000);
    }

    render() {
        return (
            <View style={styles.containerAuto}>
                <View style={styles.contentAuto}>
                    <Image
                        style={styles.imageAuto}
                        source={require("../../assets/images/splash_screen.jpg")}
                    />
                </View>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    containerAuto: {},
    contentAuto: {
        flex: 1
    },
    imageAuto: {
        width: gui.screenWidth,
        height: gui.screenHeight
    }
});
