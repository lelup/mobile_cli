import React, { Component } from "react";
import { View, Image, StyleSheet, ScrollView } from "react-native";

import gui from "../../lib/gui";
import styles from "../../lib/styleLogReForScreen";

import HeaderLogin from "../header/HeaderLogin";
import ConfirmForm from "../form/ConfirmCode";
import Banner from "../../components/login/Banner";

export default class ConfirmCodeScreen extends Component {
  constructor(props) {
    super(props);
    this.setState = {};
  }
  render() {
    return (
      <ScrollView
        keyboardDismissMode="none"
        contentContainerStyle={{
          width: gui.screenWidth,
          height: gui.screenHeight + 32
        }}
        style={styles.scrollViewDefault}
      >
        <HeaderLogin />
        <ConfirmForm FormStyle={styles.formDefault} />
        <Banner />
      </ScrollView>
    );
  }
}
