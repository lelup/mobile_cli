import React, {Component} from "react";
import {ScrollView} from "react-native";
import gui from "../../lib/gui";
import styles from "../../lib/styleLogReForScreen";
import HeaderLogin from "../header/HeaderLogin";
import RegisterForm from "../form/Register";
import Banner from "../../components/login/Banner";

export default class RegisterScreen extends Component {
    render() {
        return (
            <ScrollView
                keyboardDismissMode="none"
                contentContainerStyle={{
                    width: gui.screenWidth,
                    height: gui.screenHeight + 55
                }}
                style={styles.scrollViewDefault}
            >
                <HeaderLogin/>
                <RegisterForm FormStyle={styles.formDefault}/>
                <Banner/>
            </ScrollView>
        );
    }
}
