import React, {Component} from "react";
import {ScrollView} from "react-native";
import gui from "../../lib/gui";
import styles from "../../lib/styleLogReForScreen";
import HeaderLogin from "../header/HeaderLogin";
import CreatNewPassword from "../form/CreateNewPassword";
import Banner from "../../components/login/Banner";

export default class CreateNewPasswordScreen extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <ScrollView
                keyboardDismissMode="none"
                contentContainerStyle={{width: gui.screenWidth, height: gui.screenHeight + 32}}
                style={styles.scrollViewDefault}>
                <HeaderLogin/>
                <CreatNewPassword FormStyle={styles.formDefault}/>
                <Banner/>
            </ScrollView>
        );
    }
}
