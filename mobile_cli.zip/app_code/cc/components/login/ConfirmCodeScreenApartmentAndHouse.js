import React, {Component} from "react";
import {ScrollView} from "react-native";
import gui from "../../lib/gui";
import styles from "../../lib/styleLogReForScreen";
import HeaderLogin from "../header/HeaderLogin";
import ConfirmCodeApartmentAndHouse from "../form/ConfirmCodeApartmentAndHouse";
import Banner from "../../components/login/Banner";

export default class ConfirmCodeScreenApartmentAndHouse extends Component {
    render() {
        return (
            <ScrollView
                keyboardDismissMode="none"
                contentContainerStyle={{
                    width: gui.screenWidth,
                    height: gui.screenHeight + 55
                }}
                style={styles.scrollViewDefault}
            >
                <HeaderLogin/>
                <ConfirmCodeApartmentAndHouse
                    FormStyle={styles.formDefault}
                    phone={this.props.phone}
                    password={this.props.password}
                />
                <Banner/>
            </ScrollView>
        );
    }
}
