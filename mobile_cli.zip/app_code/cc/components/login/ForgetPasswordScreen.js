import React, {Component} from "react";
import {ScrollView} from "react-native";
import gui from "../../lib/gui";
import styles from "../../lib/styleLogReForScreen";
import HeaderLogin from "../header/HeaderLogin";
import ForgetPasswordForm from "../form/ForgetPassword";
import Banner from "../../components/login/Banner";

export default class ForgetPasswordScreen extends Component {
    render() {
        return (
            <ScrollView
                keyboardDismissMode="none"
                contentContainerStyle={{
                    width: gui.screenWidth,
                    height: gui.screenHeight + 32
                }}
                style={styles.scrollViewDefault}
            >
                <HeaderLogin/>
                <ForgetPasswordForm FormStyle={styles.formDefault}/>
                <Banner/>

            </ScrollView>
        );
    }
}