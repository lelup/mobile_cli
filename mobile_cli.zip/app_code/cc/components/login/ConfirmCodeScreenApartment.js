import React, { Component } from "react";
import {  ScrollView,Alert } from "react-native";
import gui from "../../lib/gui";
import styles from "../../lib/styleLogReForScreen";
import HeaderLogin from "../header/HeaderLogin";
import ConfirmCodeApartment from "../form/ConfirmCodeApartment";
import Banner from "../../components/login/Banner";
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import {Actions} from 'react-native-router-flux';
import * as homeAction from '../../reducers/home/homeActions';
import * as userAction from '../../reducers/user/userActions';
import localStorage from '../../lib/localStorage';
import DropdownAlert from 'react-native-dropdownalert';

class ConfirmCodeScreenApartment extends Component {
    constructor(props) {
        super(props);
        this.onConfirmCode = this.onConfirmCode.bind(this);
        this.onCodeChange = this.onCodeChange.bind(this);
    }
    componentDidMount(){
        this.dropDown.alertWithType('success', 'Đăng nhập thành công', 'Mời bạn nhập mã căn hộ');
    }
    render() {
        return (
            <ScrollView
                keyboardDismissMode="none"
                contentContainerStyle={{
                    width: gui.screenWidth,
                    height: gui.screenHeight + 32
                }}
                style={styles.scrollViewDefault}
            >
                <HeaderLogin />
                <ConfirmCodeApartment
                    FormStyle={styles.formDefault}
                    onConfirmCode={this.onConfirmCode}
                    onCodeChange={this.onCodeChange}
                />
                <Banner />
                <DropdownAlert
                    ref={ref => this.dropDown = ref}
                    successColor='green'
                    defaultContainer={{
                        backgroundColor: "#31CF64",
                        flexDirection: 'row',
                        justifyContent: "space-between",
                        alignItems: 'center',
                        height: 60,
                        width: gui.screenWidth,
                    }}
                />
            </ScrollView>
        );
    }

    onConfirmCode(verifyCode) {
        let {token} = this.props.user;
        let dto = {
            flatCode : verifyCode
        };
        console.log(token);
        this.props.actions.userConfirmCodeApartment(dto, token)
            .then((res) => {
                this.doAfterConfirmCode(res);
            })
            .catch((res) => {
                Alert.alert('Error', 'phone or password is incorrect!' + res);
            });
    }

    doAfterConfirmCode = async (res) => {
        if (res.status === 0) {
            await this.props.actions.onUserFieldChange('codeAparment', true);
            let {phone, password} = this.props.user;
            let dto = {
                phone: phone,
                password: password
            };
            localStorage.setLoginInfo(dto);
            Actions.Main({type: 'reset'});
        } else {
            Alert.alert(
                'Nhập mã sai',
                'Xin vui lòng nhập lại mã',
                [{text: 'OK'}],
                { cancelable: false }
            );
        }
    };

    onCodeChange(value) {
        this.props.actions.onUserFieldChange('apartmentCode', value);
    }
}

const actions = [
    homeAction,
    userAction
];

function mapStateToProps(state) {
    return {
        ...state
    };
}

function mapDispatchToProps(dispatch) {
    const creators = Map()
        .merge(...actions)
        .filter(value => typeof value === 'function')
        .toObject();

    return {
        actions: bindActionCreators(creators, dispatch),
        dispatch
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ConfirmCodeScreenApartment)
