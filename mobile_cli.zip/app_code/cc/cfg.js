let cfg = {
    //server: 'dev2.gipxy.com'
    server: '172.104.167.189'
};

cfg.rootUrl = `http://${cfg.server}:81/api`;
cfg.root = `http://${cfg.server}:8889/api`;
cfg.api = `http://${cfg.server}:5000/`;
export default cfg;

// log server: tail -f /u01/code/mitirisk/mitirisk-server/target/logs/mitirik.log