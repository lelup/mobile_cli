import cfg from '../cfg';


const apiRegister = `${cfg.api}accounts/auth/register`;

const register = (phone, password, flatCode, buildingCode) => (
    fetch(apiRegister,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json'
            },
            body: JSON.stringify({phone, password, flatCode, buildingCode}),

        })

        .then(res => res.json())
        .catch((err) => {
            console.log('==============> Loi :' + err)
        })
);

module.exports = register;