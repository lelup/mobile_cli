import cfg from '../cfg';


const apiAdverts = `${cfg.api}adverts`;

const adverts = () => (
    fetch(apiAdverts,
        {
            method: 'GET',
            headers: {
                "Accept": "*/*",
                'Content-Type': 'application/json',
            },
        })
        .then(response => {
            console.log('==========> ProjectType', response);
            return response.json()
        })
        .catch(e => {
            console.log('=================>Loi: ', e)
            }
        )
);

module.exports = register;
